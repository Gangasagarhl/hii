"""What do the free models' raw answers look like to the DDXPlus grader?

Reads a run's calls.jsonl and writes a short Markdown report: per model, how often a diagnosis
answer parses to a valid label the way the grader reads it (only the FIRST "<digits>." counts),
how often it refuses or rambles, how often the self-tag answer is helpful/harmful/neutral,
speed and reasoning tokens, and 5 raw example answers. Changes nothing; fixes nothing.

    .venv/bin/python runs/prelim_opencode/answer_report.py <calls.jsonl> <out.md> [--gate]

With --gate it exits 10 when a model looks broken (fewer than half of its diagnosis answers
parse, or fewer than half of its self-tags are one of the three words). The gate only keeps
the free allowance from being spent on a broken setup; it is not a research decision.
"""
import json
import re
import statistics
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from msr import data as D  # noqa: E402
from msr import grade as G  # noqa: E402

DIAG_STAGES = {"write", "build0", "build", "probe", "probe0", "probe_extra"}
MARKS = ("helpful", "harmful", "neutral")
REFUSAL = re.compile(r"\b(i can(no|')t|i am unable|i'm unable|cannot (provide|diagnose|determine|give)|"
                     r"not able to|consult (a|your) (doctor|physician|healthcare)|as an ai)\b", re.I)


def main(calls_path: str, out_md: str, gate: bool) -> int:
    tasks = D.task_index("ddxplus")
    by = defaultdict(lambda: defaultdict(list))
    rows = [json.loads(x) for x in Path(calls_path).read_text(encoding="utf-8").splitlines() if x.strip()]
    for r in rows:
        by[r["model"]][r["meta"].get("stage")].append(r)
    lines = [f"# Free-model answers as the grader sees them", "",
             f"Source: `{calls_path}` ({len(rows)} logged calls).", ""]
    examples = []
    broken = []
    for model in sorted(by):
        st = by[model]
        diag = [r for s in DIAG_STAGES for r in st.get(s, [])]
        tags = st.get("selfmark", [])
        n = len(diag)
        n_valid = n_correct = n_zero = n_multi = n_refuse = n_ramble = 0
        for r in diag:
            a = r["answer"] or ""
            nums = re.findall(r"(\d+)\.", a.lower().strip())
            label = G.parse_ddxplus(a)
            valid = label != D.NOTINLABEL and label in D.LABEL2TEXT
            n_valid += valid
            n_zero += len(nums) == 0
            n_multi += len(nums) > 1
            n_refuse += bool(REFUSAL.search(a))
            n_ramble += len(a) > 120 or a.strip().count("\n") >= 2
            tid = r["meta"].get("task_id")
            if tid in tasks:
                n_correct += bool(G.grade_detail("ddxplus", tasks[tid], a)["correct"])
        t_valid = sum(1 for r in tags if (re.findall(r"[a-z]+", (r["answer"] or "").lower()) or [""])[0] in MARKS)
        t_exact = sum(1 for r in tags if (r["answer"] or "").strip().lower().rstrip(".") in MARKS)
        t_dist = defaultdict(int)
        for r in tags:
            w = (re.findall(r"[a-z]+", (r["answer"] or "").lower()) or ["(none)"])[0]
            t_dist[w if w in MARKS else "other"] += 1
        fresh = [r for r in rows if r["model"] == model and not r.get("cached")]
        lat = sorted(r["latency_s"] for r in fresh)
        mlat = sorted((r["meta"].get("route_info") or {}).get("model_latency_s") or 0 for r in fresh)
        reas = [(r["meta"].get("route_info") or {}).get("reasoning_tokens") or 0 for r in fresh]
        pct = lambda k, d: f"{100 * k / d:.0f}%" if d else "n/a"  # noqa: E731
        lines += [f"## {model}", "",
                  f"- diagnosis answers: {n}; parse to a valid label: {n_valid} ({pct(n_valid, n)}); "
                  f"graded correct: {n_correct} ({pct(n_correct, n)})",
                  f"- no `<digits>.` at all: {n_zero}; more than one (first one counts): {n_multi}; "
                  f"refusal wording: {n_refuse}; long or multi-line: {n_ramble}",
                  f"- self-tag answers: {len(tags)}; first word is helpful/harmful/neutral: {t_valid} "
                  f"({pct(t_valid, len(tags))}); exactly one such word: {t_exact}; split: {dict(t_dist)}",
                  f"- fresh calls: {len(fresh)}; wall time per call median {statistics.median(lat):.1f} s, "
                  f"90th percentile {lat[int(0.9 * (len(lat) - 1))]:.1f} s; model time median "
                  f"{statistics.median(mlat):.1f} s; reasoning tokens median {statistics.median(reas):.0f}"
                  if fresh else "- no fresh calls", ""]
        if (n and n_valid < 0.5 * n) or (tags and t_valid < 0.5 * len(tags)) or not n:
            broken.append(model)
        # examples: one valid, one invalid or long, one self-tag per model
        ok = [r for r in diag if G.parse_ddxplus(r["answer"]) in D.LABEL2TEXT]
        bad = [r for r in diag if r not in ok or len(r["answer"] or "") > 120]
        for pick in (ok[:1], bad[:1], tags[:1]):
            examples += [(model, r["meta"].get("stage"), r["answer"]) for r in pick]
    lines += ["## Example raw answers", ""]
    for model, stage, a in examples[:5] if len(examples) <= 5 else _spread(examples):
        lines.append(f"- {model} ({stage}): `{json.dumps((a or '')[:300])}`")
    lines += ["", f"Gate (setup check only): {'FAIL for ' + ', '.join(broken) if broken else 'pass'}", ""]
    Path(out_md).write_text("\n".join(lines), encoding="utf-8")
    print("\n".join(lines))
    return 10 if (gate and broken) else 0


def _spread(ex: list) -> list:
    """Five examples spread over models and kinds."""
    seen, out = set(), []
    for e in ex:
        key = (e[0], e[1] == "selfmark")
        if key not in seen:
            seen.add(key)
            out.append(e)
    for e in ex:
        if len(out) >= 5:
            break
        if e not in out:
            out.append(e)
    return out[:5]


if __name__ == "__main__":
    a = [x for x in sys.argv[1:] if not x.startswith("--")]
    sys.exit(main(a[0], a[1], "--gate" in sys.argv))
