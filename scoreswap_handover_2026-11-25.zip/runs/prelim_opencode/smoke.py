"""One real DDXPlus call per model of the preliminary study, never from the cache.

    .venv/bin/python runs/prelim_opencode/smoke.py [study.yaml]

Exit 0: every model answered. Exit 2: the free allowance is used up (the text says
"free allowance used up"). Exit 1: some other failure. Calls are logged under
runs/prelim_opencode/smoke/.
"""
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

import msr.llm as L  # noqa: E402
from msr import data as D  # noqa: E402
from msr import opencode_route as OR  # noqa: E402
from msr.prompts import build_prompt  # noqa: E402
from msr.study import load_study  # noqa: E402


def main(study_path: str) -> int:
    st = load_study(study_path)
    L.RUNS = ROOT / "runs" / "prelim_opencode" / "smoke"
    L.SPEND_PATH = L.RUNS / "spend.json"
    llm = L.LLM(run_name="smoke", config=st.models_cfg)
    task = D.load_stream("ddxplus")[0]
    prompt = build_prompt("ddxplus", task)
    rep = 900_000_000 + int(time.time())      # a fresh repeat number: never answered from the cache
    rc = 0
    for m in st.models:
        try:
            r = llm.call(m, user=prompt, repeat=rep, meta={"stage": "smoke", "task_id": task["task_id"]})
            print(f"smoke {m}: ok in {r.latency_s:.1f} s: {r.answer[:80]!r}", flush=True)
        except OR.OpencodeLimitReached as e:
            print(f"smoke {m}: free allowance used up: {e}", flush=True)
            return 2
        except Exception as e:   # noqa: BLE001 - report and go on to the next model
            print(f"smoke {m}: FAILED: {type(e).__name__}: {e}", flush=True)
            rc = 1
    return rc


if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else str(ROOT / "config" / "prelim_opencode.yaml")))
