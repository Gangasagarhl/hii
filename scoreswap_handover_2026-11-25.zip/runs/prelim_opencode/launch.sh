#!/usr/bin/env bash
# Preliminary run on the free opencode models, unattended. Started as the systemd user unit
# msr-prelim (see runs/prelim_opencode/README in ROUTE_NOTES.md). Order:
#   1. smoke: one real call per model. If the free allowance is used up, wait for the next
#      reset (00:00 UTC + 5 min) and try again.
#   2. tiny slice (tiny_study.yaml, its own folder tiny/): build, probe, then answer_report.py
#      --gate -> TINY_REPORT.md. A failed gate stops everything here.
#   3. full run (config/prelim_opencode.yaml): build, probe, probe_extra. NOT evaluate.
#      -> ANSWER_REPORT.md at the end.
# A step stopped by the used-up allowance waits for the next reset and resumes; answers
# already received come from the cache, so nothing is asked twice. Any other failure: wait
# 15 minutes and retry, at most 8 times, then stop. Progress: progress.log; phase: STATE.
set -u
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT" || exit 1
PY="$ROOT/.venv/bin/python"
P="$ROOT/runs/prelim_opencode"
LOG="$P/progress.log"
STATE="$P/STATE"
export PYTHONUNBUFFERED=1

say() { echo "$(date -u +%FT%TZ) $*" >> "$LOG"; }
state() { echo "$(date -u +%FT%TZ) $*" > "$STATE"; say "STATE: $*"; }

wait_reset() {
  local now next
  now=$(date -u +%s)
  next=$(( (now / 86400 + 1) * 86400 + 300 ))
  state "waiting for the free allowance to reset ($1); next try $(date -u -d @"$next" +%FT%TZ)"
  sleep $(( next - now ))
}

attempt() {   # attempt <label> <command...>: run until it succeeds
  local label=$1; shift
  local fails=0 out rc
  while true; do
    state "running: $label"
    out=$(mktemp)
    "$@" 2>&1 | tee -a "$LOG" > "$out"
    rc=${PIPESTATUS[0]}
    if [ "$rc" -eq 0 ]; then rm -f "$out"; say "done: $label"; return 0; fi
    if grep -q "OpencodeLimitReached\|free allowance used up" "$out"; then
      rm -f "$out"; wait_reset "$label"; continue
    fi
    rm -f "$out"
    fails=$((fails + 1))
    if [ "$fails" -ge 8 ]; then state "STOPPED: $label failed 8 times (exit $rc); see progress.log"; exit 1; fi
    say "failed (exit $rc): $label; retry $fails of 8 in 15 minutes"
    sleep 900
  done
}

# Sourced with MSR_LAUNCH_FUNCS_ONLY=1 (to test the functions above), stop here.
if [ "${MSR_LAUNCH_FUNCS_ONLY:-}" = 1 ]; then return 0 2>/dev/null || exit 0; fi

say "==== launch.sh started (pid $$)"
attempt "smoke (one call per model)" "$PY" "$P/smoke.py" "$ROOT/config/prelim_opencode.yaml"

TINY=(--study "$P/tiny_study.yaml" --runs-dir "$P/tiny" --yes)
attempt "tiny slice: build" "$PY" run.py "${TINY[@]}" --stage build
attempt "tiny slice: probe" "$PY" run.py "${TINY[@]}" --stage probe
"$PY" "$P/answer_report.py" "$P/tiny/prelim_opencode_tiny/calls.jsonl" "$P/TINY_REPORT.md" --gate >> "$LOG" 2>&1
if [ $? -ne 0 ]; then
  state "STOPPED: the tiny slice's answers failed the setup gate; see TINY_REPORT.md"
  exit 2
fi
say "tiny slice passed the setup gate; TINY_REPORT.md written"

FULL=(--study "$ROOT/config/prelim_opencode.yaml" --yes)
attempt "full run: build" "$PY" run.py "${FULL[@]}" --stage build
attempt "full run: probe" "$PY" run.py "${FULL[@]}" --stage probe
attempt "full run: probe_extra" "$PY" run.py "${FULL[@]}" --stage probe_extra
"$PY" "$P/answer_report.py" "$P/calls.jsonl" "$P/ANSWER_REPORT.md" >> "$LOG" 2>&1
state "FINISHED: build, probe and probe_extra done (evaluate NOT run); ANSWER_REPORT.md written"
