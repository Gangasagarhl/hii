"""Check, with no model and no network, exactly what the opencode route sends to a model.

It starts capture_server.py (a local stand-in endpoint that records every request and
answers "OK"), points the route's opencode server at it (inspect_base_url), makes two calls
through the normal msr.llm.LLM.call path (a real DDXPlus prompt and a self-tag prompt), and
compares the recorded requests with our prompts. Run from the project folder:

    .venv/bin/python runs/prelim_opencode/route_check/check_route.py [model ...]

Writes route_check/capture_<model>.jsonl and route_check/summary.json; exits 1 on a mismatch.
"""
import json
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT))

import msr.llm as L  # noqa: E402
from msr import data as D  # noqa: E402
from msr import opencode_route as OR  # noqa: E402
from msr.build import selftag_prompt  # noqa: E402
from msr.prompts import build_prompt  # noqa: E402


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def main(models: list) -> int:
    cfg = L.load_config()
    pc = dict(cfg["providers"]["opencode_cli"])
    port = free_port()
    summary = {"opencode_version": None, "models": {}}
    ok_all = True
    tasks = D.load_stream("ddxplus")
    ddx = build_prompt("ddxplus", tasks[0])
    item = build_prompt("ddxplus", tasks[1])
    tag = selftag_prompt("ddxplus", tasks[0], item, "0. Acute COPD exacerbation / infection", True, False)
    for name in models:
        cap = HERE / f"capture_{name}.jsonl"
        cap.unlink(missing_ok=True)
        srv = subprocess.Popen([sys.executable, str(HERE / "capture_server.py"), str(port), str(cap)])
        try:
            time.sleep(0.5)
            pc2 = {**pc, "inspect_base_url": f"http://127.0.0.1:{port}/v1", "retries": 0}
            cfg2 = {**cfg, "providers": {**cfg["providers"], "opencode_cli": pc2}}
            with tempfile.TemporaryDirectory() as tmp:
                L.RUNS = Path(tmp) / "runs"
                L.SPEND_PATH = L.RUNS / "spend.json"
                llm = L.LLM(run_name="route_check", config=cfg2, dry_run=False)
                answers = [llm.call(name, user=p, repeat=7_000_001 + i).answer for i, p in enumerate((ddx, tag))]
                settings = json.loads((L.RUNS / "route_check" / "model_settings.json").read_text())[name]
            OR.close_all()
        finally:
            srv.terminate()
        reqs = [json.loads(x) for x in cap.read_text().splitlines()]
        res = {"requests": len(reqs), "answers": answers, "settings": settings, "checks": {}}
        for i, (want, r) in enumerate(zip((ddx, tag), reqs)):
            b = r["body"]
            msgs = b.get("messages") or []
            if isinstance(b.get("system"), list):   # Anthropic format
                sys_text = "".join(x.get("text", "") for x in b["system"])
                user_text = "".join(x.get("text", "") for m in msgs for x in (m["content"] if isinstance(m["content"], list) else [{"text": m["content"]}]))
            else:
                sys_text = "".join(m["content"] for m in msgs if m["role"] == "system")
                user_text = "".join(m["content"] for m in msgs if m["role"] == "user")
            c = {"path": r["path"],
                 "system_is_sentence": sys_text == pc.get("system_sentence", OR.DEFAULT_SENTENCE),
                 "user_is_prompt_byte_for_byte": user_text == want,
                 "messages": [m["role"] for m in msgs],
                 "no_tools": not b.get("tools"),
                 "other_fields": {k: v for k, v in b.items() if k not in ("messages", "system")}}
            res["checks"][f"call{i}"] = c
            ok_all &= c["system_is_sentence"] and c["user_is_prompt_byte_for_byte"] and c["no_tools"]
        ok_all &= len(reqs) == 2   # one request per call: no title call, no retries
        summary["models"][name] = res
        summary["opencode_version"] = settings.get("opencode", {}).get("opencode_version")
    summary["all_ok"] = bool(ok_all)
    (HERE / "summary.json").write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2)[:4000])
    return 0 if ok_all else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:] or ["oc-deepseek-v4.1-flash"]))
