"""A local stand-in for the model endpoint, used ONLY to see what opencode sends.

opencode is pointed at http://127.0.0.1:<port>/v1 for the run being inspected (config
override in OPENCODE_CONFIG_CONTENT). Every request body is written to a JSONL file;
headers that could carry a key (authorization, x-api-key, anything with key/token/auth)
are dropped before writing. It answers every chat request with the fixed text "OK".
Usage: python capture_server.py <port> <out.jsonl> [smart]
With "smart" it answers "helpful" to the self-tag question and "12. Pneumonia" otherwise, so a
pipeline run against it exercises grading and tag parsing.
"""
import json
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PORT, OUT = int(sys.argv[1]), sys.argv[2]
SMART = len(sys.argv) > 3 and sys.argv[3] == "smart"
SECRET_WORDS = ("auth", "key", "token", "cookie", "secret")


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _record(self, body):
        hdr = {k: v for k, v in self.headers.items() if not any(w in k.lower() for w in SECRET_WORDS)}
        with open(OUT, "a", encoding="utf-8") as f:
            f.write(json.dumps({"method": self.command, "path": self.path, "headers": hdr, "body": body}) + "\n")

    def do_GET(self):
        self._record(None)
        self.send_response(404)
        self.end_headers()

    def do_POST(self):
        n = int(self.headers.get("content-length") or 0)
        raw = self.rfile.read(n).decode("utf-8", "replace")
        try:
            body = json.loads(raw)
        except ValueError:
            body = raw
        self._record(body)
        model = body.get("model", "x") if isinstance(body, dict) else "x"
        answer = "OK"
        if SMART:
            answer = "helpful" if "helpful, harmful or neutral" in json.dumps(body) else "12. Pneumonia"
        if self.path.endswith("/messages"):   # Anthropic format (e.g. qwen4-max-free)
            self.send_response(200)
            self.send_header("content-type", "text/event-stream")
            self.end_headers()
            events = [
                ("message_start", {"type": "message_start", "message": {
                    "id": "m1", "type": "message", "role": "assistant", "model": model, "content": [],
                    "stop_reason": None, "stop_sequence": None, "usage": {"input_tokens": 11, "output_tokens": 0}}}),
                ("content_block_start", {"type": "content_block_start", "index": 0,
                                         "content_block": {"type": "text", "text": ""}}),
                ("content_block_delta", {"type": "content_block_delta", "index": 0,
                                         "delta": {"type": "text_delta", "text": answer}}),
                ("content_block_stop", {"type": "content_block_stop", "index": 0}),
                ("message_delta", {"type": "message_delta", "delta": {"stop_reason": "end_turn", "stop_sequence": None},
                                   "usage": {"output_tokens": 1}}),
                ("message_stop", {"type": "message_stop"}),
            ]
            for name, data in events:
                self.wfile.write(f"event: {name}\ndata: {json.dumps(data)}\n\n".encode())
            self.wfile.flush()
            return
        if isinstance(body, dict) and body.get("stream"):
            self.send_response(200)
            self.send_header("content-type", "text/event-stream")
            self.end_headers()
            chunks = [
                {"id": "c1", "object": "chat.completion.chunk", "created": 0, "model": model,
                 "choices": [{"index": 0, "delta": {"role": "assistant", "content": answer}, "finish_reason": None}]},
                {"id": "c1", "object": "chat.completion.chunk", "created": 0, "model": model,
                 "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}],
                 "usage": {"prompt_tokens": 11, "completion_tokens": 1, "total_tokens": 12}},
            ]
            for c in chunks:
                self.wfile.write(f"data: {json.dumps(c)}\n\n".encode())
            self.wfile.write(b"data: [DONE]\n\n")
            self.wfile.flush()
        else:
            out = {"id": "c1", "object": "chat.completion", "created": 0, "model": model,
                   "choices": [{"index": 0, "message": {"role": "assistant", "content": answer}, "finish_reason": "stop"}],
                   "usage": {"prompt_tokens": 11, "completion_tokens": 1, "total_tokens": 12}}
            data = json.dumps(out).encode()
            self.send_response(200)
            self.send_header("content-type", "application/json")
            self.send_header("content-length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)


ThreadingHTTPServer(("127.0.0.1", PORT), H).serve_forever()
