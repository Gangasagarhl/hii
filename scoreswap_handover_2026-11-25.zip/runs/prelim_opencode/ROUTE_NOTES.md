# Route notes: free models through the opencode tool (preliminary run only)

Written 23 Nov 2026. opencode **1.19.4** (`~/.nvm/versions/node/v22.23.2/bin/opencode`; its
requests identify as `opencode/1.19.4 ai-sdk/provider-utils/4.0.23 runtime/bun/1.4.4`).

**What a paper reader must be told.** These calls pass through a wrapper. The models are free
promotional endpoints of the opencode service ("OpenCode Zen", `opencode.ai/inference`), which
does not publish the host, precision or version behind each name. They may change or vanish
without notice. All of them are reasoning models, and they ran at their host's default
reasoning setting. Results from this route are preliminary. They never enter the main analysis.

## 1. What exists and what could be measured on 23 Nov

- **The list changes within a day.** In the morning, `opencode models` listed 13 free models. In the
  afternoon it listed 11: beam, big-pickle, deepseek-v4.1-flash, flint-40b, hy4-flash, iceman,
  mimo-v2.6-flash, nemotron-3.5-lightning, nemotron-3.5-super-vl, qwen4-max and tidepool-alpha (all `-free`
  except big-pickle).
  - Gone since the morning: glm-5.3-flash, inkling-2-small, longcat-2.5 and minimax-m3.1-flash. Asked anyway,
    they gave no answer within 30 s.
  - New: qwen4-max and tidepool-alpha.
- **The free allowance was used up, and it is shared.** At about 10:30 UTC every listed model answered with
  opencode's retry state:
  - `"Free usage exceeded, subscribe to Go"`, reason `free_tier_limit`
  - next try `1795478400000` ms, which is **2026-11-24 00:00:00 UTC** (a daily reset)

  opencode does not fail on this. It keeps the request waiting until the reset. The route reads that state
  and stops at once (`OpencodeLimitReached`). The opencode log records the same message, "Free usage limit
  reached ... subscribe to OpenCode Go", on 13 Nov, after about 33 free calls that day. The size of the
  allowance is not published. It is probably small, and the same allowance serves every opencode user on
  this computer, including the field-to-test app's opencode agent.
- **Not measurable today, because of the used-up allowance:**
  - speed of each model
  - following "answer with one number"
  - behaviour under 4 and 8 calls at once

  The only speed figure is the manager's from that morning: deepseek-v4.1-flash answered "OK" in 5.8 s with
  `opencode run`. About 3.2 s of that is the tool's own start-up (measured below), which leaves about
  2.6 s for the model.
- **Earlier successful use**, from opencode's own log:
  - deepseek-v4.1-flash (9–16 Nov)
  - nemotron-3.5-super-vl (23 Oct – 9 Nov)
  - nemotron-3.5-lightning (5 Nov)
- **Catalogue facts** (`opencode models opencode --verbose`):

| model (`opencode/…-free`) | maker | wire format | reasoning variants offered | context | listed since |
|---|---|---|---|---|---|
| deepseek-v4.1-flash | DeepSeek | OpenAI chat | low, high, max | 200k | 17 Oct 2026 |
| mimo-v2.6-flash | Xiaomi | OpenAI chat | none offered | 200k | 22 Sep 2026 |
| nemotron-3.5-super-vl | NVIDIA | OpenAI chat | none, minimal, low, medium, high, xhigh | 1M | 15 Oct 2026 |
| nemotron-3.5-lightning | NVIDIA | OpenAI chat | none offered | 262k | 11 Aug 2026 |
| hy4-flash | Tencent | OpenAI chat | none, high | 1M | 16 Nov 2026 |
| qwen4-max | Alibaba (Qwen) | Anthropic messages | low, high, xhigh | 1M | 16 Nov 2026 |
| beam, flint-40b, iceman, tidepool-alpha, big-pickle | not stated ("stealth") | | | | left out |

## 2. One process per call, or one server

**`opencode run`, one process per call.** Each call costs about 3.2 s of start-up, measured 3 times against
a local stand-in that answers at once. It also has two traps:
- It wraps every argument that contains a space in double quotes, with inner quotes escaped. So
  `Reply with exactly one word: OK` reaches the model as `"Reply with exactly one word: OK"`. Text passed on
  stdin arrives unchanged.
- It makes an extra title-generation call to the same model unless `--title` is given. That call has a long
  "title generator" system prompt, temperature 0.5 and reasoning_effort low.

**`opencode serve`, one local server per Python process, over HTTP.** About 0.05 s per call with the
synchronous endpoint. The request body is identical.

**Chosen: `opencode serve`.** The route polls (`prompt_async`, then the session status) so that it can see
opencode's retry state. With a stand-in that answers at once, a call costs about 0.4–0.6 s in total.

## 3. Exactly what the model receives

These requests were captured on this computer with a local stand-in endpoint
(`route_check/capture_server.py`, which records each request body and drops any header that could hold a
key). `route_check/check_route.py` sends a real DDXPlus prompt and a real self-tag prompt through the
normal `msr.llm.LLM.call` path; the results are in `route_check/summary.json`, with `all_ok: true`.

- **System message:** `You are a helpful assistant.` and nothing else.
- **User message:** our prompt, byte for byte. There is one user message and no history.
- **Other fields, OpenAI format** (deepseek, mimo, nemotron, hy4):
  - `model`
  - `max_tokens: 8192` (our cap; opencode's default is 32000)
  - `stream: true`
  - `stream_options: {include_usage: true}`
- **Anthropic format** (qwen4-max): the system and user texts are content blocks, each marked
  `cache_control: {type: ephemeral}`, plus `max_tokens: 8192` and `stream: true`.
- **Not sent:** temperature, top_p, seed and tools. `reasoning_effort` is not sent either, unless a model
  sets `opencode_variant` in `config/models.yaml`; none does.
- **Headers:**
  - User-Agent, as above
  - `x-opencode-client: cli`
  - `x-opencode-project: global`
  - `x-opencode-request` and `x-opencode-session(-id)`, which are random ids

  The authorisation header was not recorded.
- **What opencode would add without our measures:**
  - A system prompt made of the agent prompt, plus "You are powered by the model named <id>. The exact
    model ID is opencode/<id>", plus an `<env>` block with the working folder path, workspace root, git
    yes/no, platform and today's date.
  - From the project folder: CLAUDE.md or AGENTS.md (found by searching upwards) and a list of the owner's
    Claude skills.
  - The separate title-generation call.
- **What cannot be seen:** what the opencode service does between our request and the model's host. It may
  add text, change settings, or send different calls to different hosts or precisions. The capture shows
  only what leaves this computer.

## 4. How the route keeps it clean (`msr/opencode_route.py`)

**The private folder `runs/_opencode_home/work/`** holds only:
- `opencode.json`: agent `plain`, every tool off, all permissions denied, the sentence as its prompt
- `.opencode/plugins/plain_system.js`: replaces opencode's assembled system prompt with the sentence, and
  logs one line per call to `runs/_opencode_home/plugin_calls.log`

opencode installed its own plugin library next to these (`.opencode/node_modules`, 64 MB, and
`package.json`). The route refuses to start if AGENTS.md, CLAUDE.md or CONTEXT.md appear in the folder.

**The server's environment:**
- These flags are on: `OPENCODE_DISABLE_CLAUDE_CODE`, `_EXTERNAL_SKILLS`, `_AUTOUPDATE`, `_LSP_DOWNLOAD`,
  `_MODELS_FETCH`, `_DEFAULT_PLUGINS`, `_AUTOCOMPACT`.
- Any `OPENCODE_CONFIG*` override is removed.
- Sessions go to a private database, `runs/_opencode_home/opencode.db`.
- The server listens on 127.0.0.1 only, on a random free port, behind a random password.

**Every call:**
- a new session with a title, so no title call is made
- the prompt is sent as JSON over HTTP, never through a shell
- the session is deleted afterwards
- the call **fails unless the plugin logged this session**, which is proof that the clean system prompt
  was used
- the agent is checked at server start, and the route refuses to run if any tool is on
- only model ids ending in `-free` are accepted
- a custom system prompt is refused (every study call has none)

**Failures raise and are never stored as an answer or cached:**

| Failure | What the route does |
|---|---|
| Used-up allowance (retry state `free_tier_limit`, or a "Free usage…/subscribe to OpenCode Go" text) | `OpencodeLimitReached` at once, with the reset time |
| Any of the following, retried 3 times at 10, 30 and 90 s, then `OpencodeCallFailed`: | |
| – an empty answer | |
| – an error in the answer | |
| – a server-error or rate-limit text | |
| – opencode retrying for more than 120 s | |
| – a timeout (300 s) | |
| – a server that died (it is restarted) | |
| – a missing plugin line | |

**Concurrency cap:** `providers.opencode_cli.max_parallel`, which is 4, whatever `run.workers` says.

**What gets logged:**
- `calls.jsonl` gets `served_by: "opencode-cli 1.19.4"`, `model_id: "opencode/<id>"`, tokens as opencode
  reports them (output plus reasoning in `tokens_out`, estimated by length when missing),
  `meta.route_info` (reasoning tokens, variant, model time) and cost 0.
- `model_settings.json` gets an `opencode` block: version, sentence, variant, cap, "temperature not sent".

## 5. Checks done on 23 Nov (no model needed)

- **Route check** against the stand-in: system = sentence, user = prompt byte for byte, no tools, one
  request per call. This held for deepseek, mimo and qwen4-max (both wire formats).
- **The whole pipeline**, `run.py` build and probe of the tiny slice (356 calls), ran through the route
  against the stand-in. Grading, self-tags, the cache, `served_by` and `model_settings` all worked.
- **The real service:** the smoke check (`smoke.py`) saw the used-up allowance and stopped in about 12 s.
  Nothing was logged or cached as an answer, and no server was left running.
- **Tests:** `tests/test_opencode_route.py` (20 tests) uses a fake opencode program with no network. It
  covers:
  - success
  - empty answer
  - limit text and limit state
  - server error and server-error text
  - rate-limit retries
  - timeout
  - flaky recovery
  - a crash at start
  - a tool switched on
  - a restart after the server dies
  - the concurrency cap
  - estimated tokens
  - free-only and no-system-prompt
  - the variant
  - a stray AGENTS.md

## 6. The preliminary run

- **Study:** `config/prelim_opencode.yaml`.
  - Models: deepseek-v4.1-flash, mimo-v2.6-flash and nemotron-3.5-super-vl (three makers), every ordered
    pair.
  - DDXPlus, seed 99.
  - 100 write tasks, then 200 score tasks × 2 passes.
  - 100 probe tasks (25 for calibration) × 4 candidates × 2 repeats, and 1 extra home repeat.
  - No subsets, no second bank, the run after the swap off.
  - `--estimate` gives **12,300 calls, $0.00**.
- **Tiny slice first:** `tiny_study.yaml` (deepseek and mimo; 10 write, 20 score, 12 probe; 356 calls).
- **Launcher:** `launch.sh` runs these in order:
  1. smoke
  2. the tiny slice, then `answer_report.py --gate`, which writes `TINY_REPORT.md`
  3. full build, probe and probe_extra (**not evaluate**), then `ANSWER_REPORT.md`

  A used-up allowance makes it wait until 00:05 UTC and resume (the cache makes resuming free). Other
  failures are retried 8 times, 15 minutes apart.

To watch it:
```
systemctl --user status msr-prelim
cat runs/prelim_opencode/STATE
tail -f runs/prelim_opencode/progress.log
```

To stop it, use `systemctl --user stop msr-prelim`; the opencode server stops with it. To restart, use the
same `systemd-run` command. It is safe to re-run, because the cache holds every answer already received.
