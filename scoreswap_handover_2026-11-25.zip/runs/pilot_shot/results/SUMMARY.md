# Study `pilot_shot`: summary

Written 2026-11-24 17:56 UTC from the files in `results/`. No model was called to make this page. Intervals are 95 % intervals from resampling tasks within each stream order, the same draws for every cell (10,000 draws).

## What was run

- Models: `haiku-4.5` (anthropic), `haiku-5.5` (anthropic)
- Swaps: 2 ordered pairs, plus each model with itself (home and self-swap).
- Streams: ddxplus; stream orders (seeds): 99.
- Build: 250 write tasks (no memory; one shot item each, then frozen), 500 score tasks x 3 passes; 4 candidates, 1 shown, exploration 0.3, mix 0.5 x score + 0.5 x relevance, driven by `ema_grade`; self tags without the grade.
- Probe: 200 tasks (50 for fresh checks, 150 evaluated), top 4 owner items each shown alone 2 times, 2 runs with no item, 2 extra home repeats (self-swap reference).
- Evaluate: headline family `ema_grade`; 200 random draws of the k checks, 200 shuffles, k = 8, 16, 32, 64, 128; probabilities clipped to [0.01, 0.99].
- Calls made: 17,900 (planned 17,900); answered fresh 15,744; dollars 15.80 (estimated 7.88); answers cut at the token limit 0, refused 0, unparseable 122.

How to read: *Cw* is the weighted concordance (0.5 = coin toss): of two candidates whose results differ, how often the one with the higher OLD score did better, each pair weighted by how much the results differ. *Home*: the owner's own results. *After swap*: the reader's results (for a model with itself: fresh repeats, the self-swap reference). *Drop* = home - after; *beyond floor* = the drop test rejects (unadjusted) and the drop exceeds the upper end of the owner's self-swap interval. *Kept* = (after - 0.5) / (home - 0.5), shown only when the home signal is at least 4 standard errors above 0.5. Rules are scored by the percent of evaluation tasks solved with the item each rule shows first.

## Pilot gate (pre-registration 9.3): PASS / FAIL per line

**haiku-4.5, ddxplus**

1. FAIL: memory helps: FS_keep - FS_none at home (ema_grade, all 200 probe tasks) +3.5 points [-2.8, +9.5] (needs >= 3 with the interval above 0).
2. PASS: scores valid at home: best usefulness family `ema_grade` Cw 0.63 [0.55, 0.71]; families that pass: ema_grade,beta_grade,credit (needs >= 0.58 with lower end > 0.5).
3. PASS: repeats agree: home cells whose repeats 1 and 2 differ 8.2 % over all models (11.1 % for this model) (fails only above 40 %).
4. FAIL: enough visits and spread: items with 5+ visits 104 (needs >= 150); probe tasks whose candidates differ 46.5 % (needs >= 30 %).
5. FAIL: cost as estimated: USD per 1,000 paid calls, all calls, measured 1.004 vs estimated 0.440 (needs at most 2x the estimate).

Home Cw per family (all models, all probe tasks): haiku-4.5 ema_grade 0.63, beta_grade 0.61, tags_self 0.55, credit 0.61, visits 0.56; haiku-5.5 ema_grade 0.68, beta_grade 0.65, tags_self 0.56, credit 0.60, visits 0.52.

## Validity of the old scores per swap: ddxplus, family `ema_grade` (pooled over the stream orders)

| owner -> reader | kind | Cw home | Cw after swap | drop [CI] | owner's self-swap drop (upper end) | beyond floor | kept [CI] | noise ref. |
|---|---|---|---|---|---|---|---:|---:|
| haiku-4.5 -> haiku-4.5 | home | 0.62 | 0.63 | -0.00 [-0.06, 0.06] | -0.00 (0.06) | no | undefined | 0.76 |
| haiku-5.5 -> haiku-5.5 | home | 0.69 | 0.69 | 0.00 [-0.06, 0.06] | 0.00 (0.06) | no | 1.00 [0.69, 1.47] | 0.83 |
| haiku-4.5 -> haiku-5.5 | same_maker | 0.62 | 0.64 | -0.02 [-0.14, 0.10] | -0.00 (0.06) | no | undefined | 0.84 |
| haiku-5.5 -> haiku-4.5 | same_maker | 0.69 | 0.58 | 0.10 [-0.02, 0.21] | 0.00 (0.06) | yes | 0.45 [-0.01, 1.15] | 0.74 |

### Decision quality: ddxplus, family `ema_grade` (percent solved with the first-shown item, pooled over the orders)

| owner -> reader | none | relevance | keep | wipe | shuffled | fixed_0.5 | powerprior_16 | powerprior_flat_16 | recal_16 | retest_16 | audit_16 | pooled_16 | fresh_16 | split_half | ceiling | own |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| haiku-4.5 -> haiku-4.5 | 66.7 | 65.0 | 70.0 | 65.0 | 65.1 | 70.0 | 69.6 | 69.5 | 69.9 | 65.0 | 68.5 | 69.9 | 64.9 | 74.3 | 82.3 | 70.0 |
| haiku-5.5 -> haiku-5.5 | 51.3 | 64.7 | 68.0 | 64.7 | 64.0 | 68.0 | 68.0 | 68.0 | 68.2 | 64.2 | 67.2 | 67.9 | 64.4 | 75.0 | 79.3 | 68.0 |
| haiku-4.5 -> haiku-5.5 | 51.3 | 63.0 | 66.3 | 63.0 | 63.6 | 66.3 | 65.7 | 65.8 | 66.2 | 62.8 | 64.8 | 66.5 | 63.4 | 73.3 | 78.3 | 68.0 |
| haiku-5.5 -> haiku-4.5 | 66.7 | 66.7 | 67.3 | 66.7 | 65.0 | 67.0 | 66.0 | 67.1 | 67.1 | 66.4 | 67.1 | 67.1 | 66.1 | 77.3 | 84.3 | 70.0 |

### Held-out log score: ddxplus, family `ema_grade` (higher is better; 0 is perfect)

| owner -> reader | keep | wipe | fixed_0.5 | powerprior_16 | powerprior_flat_16 | recal_16 | audit_16 | pooled_16 | fresh_16 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| haiku-4.5 -> haiku-4.5 | -0.644 | -0.693 | -0.612 | -0.594 | -0.644 | -0.605 | -0.658 | -0.643 | -0.688 |
| haiku-5.5 -> haiku-5.5 | -0.520 | -0.693 | -0.554 | -0.523 | -0.530 | -0.507 | -0.561 | -0.520 | -0.686 |
| haiku-4.5 -> haiku-5.5 | -0.641 | -0.693 | -0.606 | -0.600 | -0.646 | -0.607 | -0.666 | -0.636 | -0.686 |
| haiku-5.5 -> haiku-4.5 | -0.718 | -0.693 | -0.628 | -0.640 | -0.695 | -0.630 | -0.708 | -0.718 | -0.689 |

### Every score family: ddxplus (Cw home / after swap, pooled over orders)

| owner -> reader | ema_grade | beta_grade | tags_self | credit | visits |
|---|---|---|---|---|---|
| haiku-4.5 -> haiku-4.5 | 0.62 / 0.63 | 0.60 / 0.60 | 0.55 / 0.57 | 0.61 / 0.65 | 0.59 / 0.63 |
| haiku-5.5 -> haiku-5.5 | 0.69 / 0.69 | 0.64 / 0.64 | 0.54 / 0.58 | 0.59 / 0.57 | 0.49 / 0.52 |
| haiku-4.5 -> haiku-5.5 | 0.62 / 0.64 | 0.60 / 0.63 | 0.55 / 0.66 | 0.61 / 0.60 | 0.59 / 0.45 |
| haiku-5.5 -> haiku-4.5 | 0.69 / 0.58 | 0.64 / 0.61 | 0.54 / 0.56 | 0.59 / 0.62 | 0.49 / 0.58 |

By kind of swap (mean Cw after the swap; home rows are the self-swap): ema_grade: home 0.66, same maker 0.61, cross maker –; beta_grade: home 0.62, same maker 0.62, cross maker –; tags_self: home 0.58, same maker 0.61, cross maker –; credit: home 0.61, same maker 0.61, cross maker –; visits: home 0.57, same maker 0.52, cross maker –.

Content-only control (old scores permuted across all items, mean Cw after the swap): ema_grade 0.50, beta_grade 0.50, tags_self 0.50, credit 0.50, visits 0.50.

## Sensitivity analyses (pre-registration 1.4-1.6, 8.2.14)

- `limit_refusal_missing`: identical to the primary analysis: no call hit the token limit or was refused.
- `available_case`: not needed: no cell dropped more than 2 % of its tasks.
- `bird_original`: not applicable: no BIRD stream in this study.

## Files

- `validity.csv`, `retained.csv`, `arms.csv`, `agreement.csv`, `costs.csv`, `gate.json`, `sensitivity.json`; per-task values in `per_task/*.npz` (msr.evaluate.load_per_task), raw cells in `cells/*.npz`, random draws in `draws/`; every file and column is listed in `SCHEMA.md`.
