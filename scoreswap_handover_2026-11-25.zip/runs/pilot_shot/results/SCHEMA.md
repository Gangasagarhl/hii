# results/: files and columns (written by msr/evaluate.py, Stage C)

Every number follows prediction/PREREGISTRATION.md; the part is named where it helps. A
"cell" is one (owner, reader, stream, order); "order" is the stream order, the `seed`
column. Missing values are empty in CSV files and NaN in npz files. Columns are only ever
added, never removed or renamed; read them by name.

## validity.csv: one row per cell and family

| column | meaning |
|---|---|
| owner, reader, kind, stream, seed, family | the cell; kind = home, same_maker or cross_maker (swap groups are named by maker; "family" is the score family) |
| home, swap, floor | weighted concordance Cw (2.2) of the owner's ranking score x on the evaluation tasks of this order: with the owner's own results (repeats 1-2), with the reader's results (for a home cell: the extra repeats 3-4), and with the extra home repeats (the self-swap) |
| home_u, swap_u, floor_u | the same, unweighted (Harrell's C, 8.2.7) |
| home_pairs, swap_pairs | informative pairs (outcomes differ) |
| home_weight, swap_weight | the sum of pair weights: Cw pooled over orders = sum(Cw x weight) / sum(weight) |
| drop, floor_drop | home - swap; home - floor (this order) |
| ratio, ratio_status, home_se | retained ratio (swap - 0.5) / (home - 0.5) for this order, with the 4-standard-error rule of 2.4 (home_se = SD of C_home over the bootstrap draws of this order); status `defined`, `undefined: home signal too weak` or `defined; interval unbounded`. Per-order ratios are descriptive only; the pooled ones are in retained.csv |
| ceiling_home, ceiling_swap, ceiling_home_extra | split-half noise references (2.5): repeat 1 vs repeat 2 of the owner's / reader's results; repeats 1-2 vs 3-4 at home. Not upper bounds |
| top1_home, top1_swap, top2_home, top2_swap | top-1 / top-2 agreement (2.9) on tasks with an informative pair; `_chance` columns: their chance values |
| tau_b_home, tau_b_swap, tau_b_floor | Kendall's tau-b between x and the outcomes, pairs within tasks pooled over tasks (8.2.7) |
| tie_share_home/_swap/_floor | share of informative pairs tied in x |
| home_noties, swap_noties, floor_noties | Cw over the pairs not tied in x |
| home_visits_low/_mid/_high (and swap_, floor_) | Cw over the pairs whose less-visited item is in that third of the bank's visit counts (cut at the 1/3 and 2/3 percentiles of the score-phase visits of all items of the bank) |
| home_bank2, swap_bank2, floor_bank2 | Cw with the SECOND bank's scores (same items, other exploration seed), where a second bank exists |
| home_net, swap_net, floor_net | counter families (beta_grade, tags_self): Cw with x = helpful - harmful (the sensitivity ranking of 0.4 and 8.2.14) |
| home_shuffled, swap_shuffled | mean Cw over the permutations of the content-only control (`shuffled`, 2.6) |
| eval_tasks, valid_tasks, dropped_tasks | evaluation tasks of the order; those kept and dropped by the missing-cell rule (1.6) |

## retained.csv: one row per (owner, reader), stream level and family

`stream` is a stream (Cw pooled over its orders by summing numerators and weights, 2.2) or
`all` (each C averaged over the streams, 2.4). Bootstrap (the secondary, task-only interval):
task IDS resampled per stream with all their appearances in every order (a task in two orders is
one cluster; `msr.metrics.task_cluster_counts`), the same draws for every cell (4.1), `bootstrap`
draws. The primary two-way (task x item) intervals are in runs/<study>/analysis/.

| column | meaning |
|---|---|
| c_home, c_swap, se_home | C_home, C_swap (for a home cell: C_fresh) and SD of C_home over the draws |
| drop, drop_lo, drop_hi, p_drop | D = C_home - C_swap, its 95 % interval, p_upper of 4.2 (unadjusted) |
| self_drop, self_drop_hi | the owner's self-swap drop Dself and U_self, the upper end of its 95 % interval (4.4) |
| drop_beyond_floor | True when the unadjusted drop test rejects at 0.05 AND D > U_self (4.4) |
| ratio, ratio_lo, ratio_hi, ratio_status, ratio_bad_draws | R with the 4-SE rule (2.4); the interval is unbounded (-inf, inf) when more than 0.5 % of draws have C_home - 0.5 <= 0 (ratio_bad_draws = that share) |
| ni_stat, p_ni | N = 0.75 (C_home - 0.5) - (C_swap - 0.5) and p_lower(N) (secondary since the round-1 revision); p_ni only where R is defined |
| v_home, v_swap | mean signed validity V per valid task (V = 2 x numerator - weight of Cw; `msr.metrics`), summed over the streams for `all` |
| theta, theta_lo_task, theta_hi_task, se_v_home_task | the HEADLINE retained share theta = v_swap / v_home (2.4 as revised), always written, with its task-only percentile interval and SE of v_home (secondary; the primary interval is two-way, in the analysis) |
| z_cal, theta_status_calibration | theta's HEADLINE reporting flag (2.4 as revised, 24 Nov 2026): the owner's signed validity on its CALIBRATION tasks (no estimate uses them), z = sum / (sd sqrt(n)); `defined` when z >= 2 |
| theta_status | the former same-task rule (V_home >= 4 SE on the same tasks), SECONDARY: it selects on the estimate's own noise and decides nothing |

## arms.csv: one row per cell, family and arm

Arms: `none`, `relevance`, `split_half` (pick on one repeat, score on the other: a one-repeat
reference, NOT an upper bound; called `oracle` before the round-1 revision), `ceiling` (the best
candidate by the mean of both repeats, scored on the same repeats: an in-sample ceiling) (family
`-`); `keep`, `wipe`, `constant` (every item at the reader's no-memory success on the calibration
tasks; ranks like wipe), `fixed_<lambda>`, `shuffled`, `own`, and `<arm>_<k>` for powerprior,
powerprior_flat (an extra comparison, Beta(1, 1) base, not pre-registered), recal, retest, audit,
pooled, fresh. k runs over
evaluate.k_values; a k larger than the calibration pool (calibration tasks x candidates)
is skipped with a one-line note (printed, and in plan.json's notes).

| column | meaning |
|---|---|
| value, regret, n_tasks | first-shown success and regret (2.7), mean over the valid evaluation tasks of the order; drawn arms: per-task means over the draws (4.5) |
| no_memory | the reader's no-memory success on the same tasks |
| log_score, brier | held-out log and Brier scores (2.8), p clipped to evaluate.prob_clip |
| log_score_lc, brier_lc | the same after the level correction (2.8 as revised): the arm's p shifted by one logit constant so that its mean over the (calibration task, candidate) cells equals the reader's no-memory success on the calibration tasks |
| log_score_lcw, brier_lcw | base-rate sensitivity (revision 2, R6 W7): the same shift with the target set to the reader's mean success WITH an item on those (calibration task, candidate) cells (the cells recal_k draws from), each cell the mean of its repeats; the gap to log_score_lc is the average memory effect's share of the level |
| value_w0.25, value_w0.75, value_wz | first-shown success at score weight 0.25 / 0.75 and under the z-scored mix (8.3.1): 0.5 z(relevance) + 0.5 z(u), relevance and u both z-scored within each task's candidates (population sd; a constant gives 0) |
| draws, draw_sd, value_p05, value_p95, log_p05, log_p95 | number of draws (or permutations), SD and 5th/95th percentiles over draws of the pooled value and log score ("what a single swap day may look like", 4.5) |
| lam, lam_sd, lam_median, lam_q25, lam_q75 | powerprior: the chosen weight over draws |
| level, level_sd, slope, slope_sd, slope_q25, slope_q75 | recal: the fitted a and b over draws (8.2.10); x' is centred on the bank mean and divided by the population sd over the items with at least one visit (2.6); when that sd is 0 only the level is fitted and the slope is empty (NaN) |
| keep_share | audit: share of draws that kept the old scores |
| checks | fresh checks per draw |
| dropped_tasks | tasks dropped in this cell by the missing-cell rule |

## agreement.csv: one row per cell (calibration tasks only, 2.11)

cells, agree, chance, kappa, rate_a (owner at home), rate_b (reader; for a home cell the
extra repeats), and the counts that add over orders: same, pairs, succ_a, n_a, succ_b, n_b
(`msr.metrics.kappa_from_counts` pools them).

## costs.csv: one row per model and stage, from calls.jsonl

calls, cached_calls, fresh_calls, tokens_in, tokens_out, usd, hit_limit (stop reason
max_tokens / length), refusals (refusal / content_filter), unparseable (no parseable
diagnosis or SQL) (1.4).

## gate.json: one entry per (model, stream), the pilot gate (9.3)

memory_gain_pts/_lo/_hi (gate 1, FS_keep - FS_none at home over ALL probe tasks, gate1_family,
probe_tasks), home_cw_<family>/_lo/_hi (gate 2, all probe tasks), gate2_families, gate2_family
and headline_rule_family (the first passing family in the order of 9.2), repeat_disagreement
(this model) and repeat_disagreement_all_models (gate 3), items_5plus_visits and
differing_task_share (gate 4), usd_per_1000_measured / _estimated (gate 5, all calls), pass_1
... pass_5, old_model.

## per_task/<owner>__<reader>__<stream>__seed<k>.npz: per evaluation task of the order

`tasks` (E,), `valid` (E,) the missing-cell rule. NaN marks a dropped task (or, for top-k, a
task without an informative pair). Keys `<family>|...`:

- `conc_home`, `conc_swap`, `conc_floor` (E, 2): numerator and weight of Cw per task; `_u`:
  unweighted; `_shuffled` (home, swap): mean numerator over the permutations and the weight;
  `_noties`, `_visits_low/_mid/_high`, `_bank2`, `_net` (counters): as in validity.csv.
- `tau_home`, `tau_swap`, `tau_floor` (E, 4): concordant, discordant, tied in x only, tied in
  outcome only (`msr.engine.tau_b` turns summed parts into tau-b).
- `ties_home/_swap/_floor` (E, 2): informative pairs tied in x, informative pairs.
- `top1_home`, `top1_swap`, `top2_home`, `top2_swap` (E,): hit 1/0; `_chance`: chance value.
- `<family>|<arm>|value`, `|regret`, `|log`, `|brier`, `|value_w0.25`, `|value_w0.75`,
  `|value_wz` (E,): the arm's per-task values (drawn arms: means over the draws).
- `<family>|<arm>|log_lc`, `|brier_lc` (E,): the level-corrected log and Brier scores.
- `<family>|<arm>|log_lcw`, `|brier_lcw` (E,): the same with the with-item level target (base-rate
  sensitivity of PC3/PC4, revision 2).
- `-|none|value`, `-|relevance|value`, `-|split_half|value`, `-|ceiling|value` and their `|regret`.

## cells/<owner>__<reader>__<stream>__seed<k>.npz: the raw cells, every probe task

| array | meaning |
|---|---|
| tasks (T,), is_calib (T,) | every probe task of the order; calibration tasks marked |
| items (T, C) | item ids of the owner's candidates in retrieval order ("" = none) |
| relevance, visits, visit_third (T, C) | raw relevance; score-phase visits; third 0/1/2 as above |
| shows, prob_sum, ips_num, ips_den (T, C) | over the build's score phase: shows, the sum of the logged selection probabilities, sum(y / pi) and sum(1 / pi) (the self-normalised IPS score is ips_num / ips_den, 8.3.5) |
| score_<family> (T, C) | the owner's ranking score x; `_net` for counters (helpful - harmful); `_bank2` with the second bank |
| y (T, C, R) | the reader's results per repeat (1 / 0 / NaN missing) |
| y_home (T, C, R) | the owner's own results per repeat |
| y_extra (T, C, R2) | home cells only: the extra home repeats 3-4 |
| none (T, Rz) | the reader's no-memory results per repeat |

## draws/<cell>.jsonl: one line per random draw of a drawn arm

family, arm (`<arm>_<k>`), k, draw, then lam (powerprior), level and slope (recal) or
decision (audit), and value and log (the draw's pooled first-shown success and log score).

## Other files

- repeatability.csv: second bank against the first (spearman, pair_agreement,
  home_validity_bank1, home_validity_bank2) per model, stream, seed, family.
- subsets.csv, shapley.csv: the realism check (8.3.2).
- variants.csv: the second wording (8.3.3), one row per cell, stream, order and family, on
  the first `variants.tasks` evaluation tasks of the order. validity_v1 / validity_variant:
  Cw of the owner's scores against the reader's results under each wording; weight_v1 /
  weight_variant: the sums of pair weights (Cw over orders = sum(Cw x weight) / sum(weight));
  outcome_agreement, outcome_kappa: the reader's results under the two wordings compared.
  Swap cells also carry, side by side for `v1` and `variant`: home_<w> (the owner's home Cw
  under that wording on the same tasks), drop_<w> = home_<w> - validity_<w>, ratio_<w>,
  ratio_status_<w> and home_se_<w> (the retained ratio with the 4-standard-error rule of
  2.4; per order, descriptive). The home cells of every model in `variants.pairs` are run
  under the second wording, so D exists under it; the raw results are kept in
  runs/<study>/variants/<variant>/.
- variants_retained.csv: per swap of `variants.pairs`, level (`stream` = a stream with its
  orders pooled, or `all` = each C averaged over the streams) and family, side by side for
  `v1` and `variant`: c_home_<w>, c_swap_<w>, drop_<w> with drop_<w>_lo / _hi (95 %),
  ratio_<w> with ratio_<w>_lo / _hi, ratio_status_<w> and se_home_<w> (2.4); and
  drop_difference = drop_variant - drop_v1 with its 95 % interval. Bootstrap: the variant
  tasks resampled within each (stream, order), the same draws for both wordings
  (`bootstrap` draws).
- online.csv, online_curves.csv: written by Stage D (msr/online.py).
- sensitivity.json and sensitivity/<name>/: limit_refusal_missing (token-limit and refused
  cells treated as missing), *_available_case (when a cell drops more than 2 % of its tasks),
  bird_original (BIRD graded with StreamBench's original parser, offline: regrade.json, the
  replayed banks/, and the same CSV and per_task files). An analysis that changes no input is
  recorded as identical to the primary one and not re-run.
- model_identity.csv: one row per model with the settings that are part of its identity (route,
  host, precision, reasoning, temperature, top_p, top_k or "provider default", answer limit) and
  the model strings the API returned (round-1 revision, S6).
- inputs.json: fingerprint of the inputs and the seconds Stage C took. SUMMARY.md: the summary.
