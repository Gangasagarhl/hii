# ScoreSwap research folder: instructions for the coding agent

You are continuing a research project in this folder. Read this file, then `docs/STATUS.md` from the last
"Running now" heading to the end, then `CLAUDE.md`. `docs/STATUS.md` is the running record: every decision is in it,
newest at the bottom. Append to it when you finish a piece of work; do not create other planning files.

## What the project is

A paper for ICML 2027 (abstract 14 Jan 2027, paper 22 Jan 2027) and a reusable benchmark:
"ScoreSwap: Are Learned Memory Scores Worth Keeping After a Model Swap?"
An agent stores past examples and learns a usefulness score for each. When the model is swapped for a newer one,
are those old scores still worth keeping? We measure this over old and new model pairs.

- `msr/` the pipeline and analysis; `run.py` runs a study from a config in `config/`.
- `scoreswap/` the scoring tool for outside researchers; `release/` the data packs it reads.
- `legs/memrl/` a side check on a real agent memory (MemRL).
- `paper/` the LaTeX paper (`main.pdf` is the real version, `dryrun.pdf` uses practice data).
- `prediction/PREREGISTRATION.md` the written plan; NOT frozen yet.
- `docs/` records: `STATUS.md`, `dress_rehearsal/`, `handover/`, `power/`, `checks_2026-11-24/`.

## Rules that must not be broken

1. Keys. The research keys are only in `.env` in this folder. Never print, log, copy or paste a key. Never open the
   key files of other applications on this machine. Hide key text in any output.
2. Money. Every paid run goes through `run.py`, which prints the cost first (`--estimate`) and obeys the spending
   cap `budget.hard_cap_usd` in `config/models.yaml` (USD 30 on 24 Nov 2026). Raise the cap only when the owner says
   yes to a stated amount. State the cost before every paid run. The account's credit is also what pays for this
   agent's own calls, so keep an eye on both.
3. Order of paid work: smoke test, the three pilots (Haiku pair), the gate checks, freeze the pre-registration,
   then the main runs. Claude Haiku 4.5 calls go first: that model may be retired from about 23 Jan 2027.
4. Never promise that the paper will be accepted. Never write a result that was not measured. No simulated number
   may appear in `paper/main.pdf`; practice numbers live only under `\ifdryrun`.
5. The paper is anonymous: no names, emails or home-folder paths in `paper/`, `release/`, or anything public.
   Public benchmarks only (DDXPlus, BIRD); no company or customer data.
6. Processes: never use `pkill -f` or `killall`. Long jobs run under `systemd-run --user` with a memory limit
   (`MemoryMax=6G`, analysis `8G`) and `CPUQuota=500%`. Stop a job only by its own unit name.
7. Do not push to GitHub unless the owner says so. No assistant name in commits.
8. Use `.venv/bin/python`. Tests: `.venv/bin/python -m pytest -q`. LaTeX: `tectonic`.
9. Words: plain and short. Say "maker" (not vendor/family in text), "transfer decomposition" (never "law" or
   "mediation"), `split_half` (not oracle). Do not write "a few dozen checks".

## Useful commands

```bash
.venv/bin/python scripts/check_keys.py                              # which keys are present (never shows them)
.venv/bin/python run.py --study config/pilot_shot.yaml --estimate   # calls and dollars; nothing is called
.venv/bin/python run.py --study config/sim.yaml                     # small practice study, simulated models, free
.venv/bin/python scripts/make_paper_assets.py --study sim           # numbers and tables for the paper
.venv/bin/python -m scoreswap check examples/ips_score.py --pack release/sim
cd paper && tectonic main.tex                                       # build the paper
```

## State on 24 Nov 2026 (details in `docs/STATUS.md`)

Done without spending: design, statistics, theory, agent-leg design, correctness checks, scoring tool, a full-size
practice run on simulated models, and the paper text (all result numbers are still practice data).
A working Anthropic key is in `.env` since 24 Nov 2026 (it expires on 24 Dec 2026). Keys for OpenAI and OpenRouter
are still missing, so only Anthropic models can be called.

What is left, in order:
1. Finish the pipeline fixes and new stages (see "Running now" in `docs/STATUS.md`); whole test suite must pass.
2. Smoke test on the two Haiku models, then the three pilots: `config/pilot_shot.yaml`, `config/pilot_bird.yaml`,
   `config/pilot_memprompt.yaml` (USD 28.90 in total by the estimate).
3. One re-run of the full-size practice study (`docs/dress_rehearsal/`), re-export of `release/`, scorer parity.
4. Last paper pass, then a mock review by three fresh reviewers; fix what they find.
5. Give the owner the full cost; after the owner's yes, freeze and deposit the pre-registration and run the main
   study, Anthropic cells first.
6. Analysis on real data, final paper with real numbers.

Things only the owner can do are listed at the end of `docs/STATUS.md` ("Owner-only items").
