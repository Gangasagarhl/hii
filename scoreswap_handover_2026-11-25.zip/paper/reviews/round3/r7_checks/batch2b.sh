#!/bin/bash
# R7 batch 2b (trimmed): hubs, drop boundary, weak home, caching, mild sharing, PC2 null
cd <project>
PY=.venv/bin/python
R=paper/reviews/round3/r7_checks
$PY $R/r7_run_theta.py hubs_spiky_b75 800 $R/out/hubs_spiky_b75.jsonl --groups upgrade --no-s --no-fresh
$PY $R/r7_run_theta.py benign_b100 600 $R/out/benign_b100.jsonl --groups upgrade --no-s --codings owner
$PY $R/r7_run_theta.py weak_b75 800 $R/out/weak_b75.jsonl --groups upgrade --no-s --no-fresh --codings owner
$PY $R/r7_run_theta.py copy30_b75 400 $R/out/copy30_b75.jsonl --groups upgrade --no-fresh --codings owner
$PY $R/r7_run_theta.py pc2null_benign 600 $R/out/pc2null_benign.jsonl --groups upgrade --pc2-only --codings owner
$PY $R/r7_run_theta.py mild_b75 200 $R/out/mild_b75.jsonl --groups cross --no-s --no-fresh
