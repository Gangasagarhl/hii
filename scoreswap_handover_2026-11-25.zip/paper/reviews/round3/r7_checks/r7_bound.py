"""R7 checks of the information lower bound (Theorem "Information limit") with the authors' functions.

1. Independent solution of the least-favourable problem on small tables (scipy SLSQP) against
   msr.sequential.least_favourable (the KKT bisection).
2. Exact least-favourable bound against the second-order closed form K = (th1-th0)^2 Abar^2 / (2 E s2)
   that the paper reports for the study (macro CheckBoundKeepTasks = column bound_tasks_chi2), on R7's
   task worlds (hetero, sparse, near-deterministic): is the reported number a lower bound?
3. The adaptive factor (msr.sequential.adaptive_constants) in R7's worlds against the paper's "1.24-1.56,
   only slightly".
4. The plug-in estimate of the second-order bound from the owner's two home repeats and the coverage of
   its 95 % task-bootstrap interval (msr.sequential.plugin_task_parts, plugin_bound_interval) against the
   world's true second-order and exact bounds.
"""
from __future__ import annotations

import json
import math
import os
import sys
from pathlib import Path

for k in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(k, "1")
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
sys.path.insert(0, str(ROOT))
import numpy as np  # noqa: E402
from scipy import optimize  # noqa: E402
from msr import sequential as S  # noqa: E402

C = 4
ALPHA, POWER = 0.05, 0.8
DKL = float(S.binary_kl(POWER, ALPHA))


def world(name, rng, n=20000):
    if name == "hetero":
        lev = rng.beta(0.4, 0.4, n)
        eff = rng.uniform(-0.2, 0.2, (n, C))
        p = np.clip(lev[:, None] + eff, 0, 1)
        q = np.clip(0.5 + 1.5 * eff + rng.normal(0, 0.15, (n, C)), 0, 1)
    elif name == "sparse":
        inf = rng.random(n) < 0.15
        gaps = np.where(inf[:, None], rng.choice([-0.45, 0.45], (n, C)), 0.0)
        lev = rng.uniform(0.2, 0.8, n)
        p = np.clip(np.where(inf[:, None], 0.5 + gaps, lev[:, None]), 0, 1)
        q = np.clip(0.5 + 0.5 * gaps + rng.normal(0, 0.2, (n, C)), 0, 1)
    elif name == "neardet":
        # LLM-like: most cells near 0 or 1; usefulness flips a candidate between them
        lev = rng.choice([0.03, 0.97], n, p=[0.4, 0.6])
        flip = rng.random((n, C)) < 0.15
        p = np.where(flip, 1.0 - lev[:, None], lev[:, None]) + rng.uniform(-0.02, 0.02, (n, C))
        p = np.clip(p, 0, 1)
        useful = p - p.mean(-1, keepdims=True)
        q = np.clip(0.5 + 0.6 * useful + rng.normal(0, 0.25, (n, C)), 0, 1)
    elif name == "smooth":
        lev = rng.uniform(0.3, 0.7, n)
        eff = rng.uniform(-0.15, 0.15, (n, C))
        p = np.clip(lev[:, None] + eff, 0, 1)
        q = np.clip(0.5 + 1.5 * eff + rng.normal(0, 0.15, (n, C)), 0, 1)
    else:
        raise ValueError(name)
    c, _ = S.stat_coefficients(q, np.ones((n, C), bool))
    return p, q, c


def slsqp_lf(p1, c, target):
    """min mean_tau sum_i kl(p1 || q) s.t. mean_tau sum_i c q = target, 0 < q < 1 (independent solver)."""
    P = p1.shape[0]
    use = np.abs(c) > 0
    x0 = np.clip(p1.ravel(), 1e-4, 1 - 1e-4)
    cf = (c / P).ravel()
    pf = p1.ravel()
    uf = use.ravel()

    def f(qv):
        qv = np.clip(qv, 1e-9, 1 - 1e-9)
        return float(np.where(uf, S.binary_kl(pf, qv), 0.0).sum() / P)

    def g(qv):
        qv = np.clip(qv, 1e-9, 1 - 1e-9)
        return np.where(uf, (qv - pf) / (qv * (1 - qv)), 0.0) / P

    cons = {"type": "eq", "fun": lambda qv: float(cf @ qv) - target, "jac": lambda qv: cf}
    r = optimize.minimize(f, x0, jac=g, constraints=[cons], bounds=[(1e-6, 1 - 1e-6)] * len(x0),
                          method="SLSQP", options={"maxiter": 500, "ftol": 1e-14})
    return r.fun, r.success


def main():
    out = {}
    rng = np.random.default_rng(31)
    # 1. independent check of least_favourable on small tables
    chk = []
    for name in ("hetero", "sparse", "neardet", "smooth"):
        p, q, c = world(name, rng, n=40)
        abar = float((c * p).sum(-1).mean())
        for th0 in (0.75, 0.0):
            k_kkt, _ = S.least_favourable(p, c, th0 * abar)
            k_sl, ok = slsqp_lf(p, c, th0 * abar)
            chk.append({"world": name, "theta0": th0, "kkt": k_kkt, "slsqp": k_sl, "slsqp_ok": bool(ok),
                        "rel_diff": (k_kkt - k_sl) / k_sl if k_sl > 0 else float("nan")})
    out["lf_check"] = chk
    # 2-3. exact vs second order; adaptive factor
    rows = []
    for name in ("hetero", "sparse", "neardet", "smooth"):
        p, q, c = world(name, np.random.default_rng([31, len(name)]))
        abar = float((c * p).sum(-1).mean())
        es2 = float((c ** 2 * p * (1 - p)).sum(-1).mean())
        for dec, th1, th0 in (("keep", 1.0, 0.75), ("margin0", 1.0, 0.0)):
            k_lf, _ = S.least_favourable(p, c, th0 * abar)
            k2 = (th1 - th0) ** 2 * abar ** 2 / (2 * es2)
            ad = S.adaptive_constants(c, p, th0 * abar)
            rows.append({"world": name, "decision": dec, "abar_home": abar, "e_sigma2": es2,
                         "bound_tasks_exact": DKL / k_lf, "bound_tasks_chi2": DKL / k2,
                         "chi2_over_exact": (DKL / k2) / (DKL / k_lf),
                         "adaptive_factor_exact": ad["factor_exact"], "adaptive_factor_chi2": ad["factor_chi2"]})
    out["bound_rows"] = rows
    for r in rows:
        print(json.dumps(r), flush=True)
    # 4. plug-in estimate and its interval from the owner's two home repeats
    cov = []
    for name in ("hetero", "neardet", "smooth"):
        p, q, c = world(name, np.random.default_rng([32, len(name)]), n=200000)
        abar = float((c * p).sum(-1).mean())
        es2 = float((c ** 2 * p * (1 - p)).sum(-1).mean())
        g_true = 2 * es2 / abar ** 2                       # bound_tasks_chi2 = DKL g / (th1-th0)^2
        k_lf, _ = S.least_favourable(p, c, 0.75 * abar)
        g_exact = (DKL / k_lf) * (0.25 ** 2) / DKL         # the exact bound on the same scale
        for n_tasks, n_cells in ((400, 1), (400, 6)):
            hits = hits_ex = 0
            est = []
            reps = 300
            r2 = np.random.default_rng([33, len(name), n_tasks, n_cells])
            for _ in range(reps):
                parts, owners = [], []
                for k in range(n_cells):
                    idx = r2.integers(0, len(p), n_tasks)
                    pp = p[idx]
                    y = (r2.random(pp.shape + (2,)) < pp[..., None]).astype(float)
                    parts.append(S.plugin_task_parts(q[idx], y))
                    owners.append(f"o{k % 3}")
                iv = S.plugin_bound_interval(parts, owners, "keep", n_boot=400, seed=int(r2.integers(1 << 30)))
                est.append(iv["g"])
                hits += iv["g_lo"] <= g_true <= iv["g_hi"]
                hits_ex += iv["g_lo"] <= g_exact <= iv["g_hi"]
            est = np.array(est)
            f = DKL / 0.25 ** 2
            cov.append({"world": name, "tasks_per_cell": n_tasks, "cells": n_cells, "reps": reps,
                        "true_bound_tasks_chi2": f * g_true, "true_bound_tasks_exact": f * g_exact,
                        "plugin_median": float(f * np.median(est)), "plugin_mean": float(f * np.mean(est[np.isfinite(est)])),
                        "plugin_q10": float(f * np.percentile(est, 10)), "plugin_q90": float(f * np.percentile(est, 90)),
                        "coverage_chi2_truth": hits / reps, "coverage_exact_truth": hits_ex / reps,
                        "mc_se": math.sqrt(0.05 * 0.95 / reps)})
            print(json.dumps(cov[-1]), flush=True)
    out["plugin_coverage"] = cov
    (HERE / "out").mkdir(exist_ok=True)
    (HERE / "out" / "bound_checks.json").write_text(json.dumps(out, indent=1))


if __name__ == "__main__":
    main()
