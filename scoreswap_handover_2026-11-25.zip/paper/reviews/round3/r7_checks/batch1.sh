#!/bin/bash
# R7 batch 1: the shared-write-task worlds (cross-owner item dependence)
cd <project>
PY=.venv/bin/python
R=paper/reviews/round3/r7_checks
$PY $R/r7_run_theta.py shared_b75 500 $R/out/shared_b75.jsonl --groups upgrade,cross --no-s --no-fresh
$PY $R/r7_run_theta.py shared_b100 300 $R/out/shared_b100.jsonl --groups cross --no-s
$PY $R/r7_run_theta.py common_b75 300 $R/out/common_b75.jsonl --groups upgrade,cross --no-s --no-fresh
$PY $R/r7_run_theta.py pc2null_shared 300 $R/out/pc2null_shared.jsonl --groups upgrade,cross --pc2-only
