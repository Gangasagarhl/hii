"""Run R7's worlds through the authors' msr.metrics.theta_tests; one JSON line per replication.

Usage: python r7_run_theta.py WORLD REPS OUT.jsonl [--groups upgrade,cross] [--workers 2] [--codings owner,write]
                              [--no-s] [--no-fresh] [--pc2]
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time
import zlib
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

for k in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(k, "1")
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import numpy as np  # noqa: E402
import r7_dgp as D  # noqa: E402

# Worlds. th = the TRUE theta (exact by construction). See r7_dgp's docstring for the symbols.
WORLDS = {
    # benign: owner-specific items, uniform popularity, reader-specific item effects per (reader, owner, item)
    "benign_b75": dict(th=0.75),
    "benign_b100": dict(th=1.0, lam_g=0.10),
    # few dominant items, strong hubs, no sharing across owners
    "hubs_spiky_b75": dict(th=0.75, item_kind="spiky", gam_kind="spiky", pop_sigma=1.5, lam_g=0.13),
    # S: the owners' items share the write task's usefulness (scores follow it: cross-owner score
    # correlation about 0.67), and a reader's reaction to a write task is shared over the banks it reads
    # (g_{r,w}); item effects carry much of the variance (lam_g 0.25, +-1 reactions, hubs)
    "shared_b75": dict(th=0.75, lam=0.15, base_task=0.05, base_model=0.03, wu=0.8, wv=0.2, we=0.0, sx=0.3,
                       lam_g=0.25, rg=1.0, rh=0.0, gam_kind="rad", pop_sigma=1.0),
    "shared_b100": dict(th=1.0, lam=0.15, base_task=0.05, base_model=0.03, wu=0.8, wv=0.2, we=0.0, sx=0.3,
                        lam_g=0.25, rg=1.0, rh=0.0, gam_kind="rad", pop_sigma=1.0),
    # S with half of the reaction common to every reader (reaches the same-maker groups too)
    "common_b75": dict(th=0.75, lam=0.15, base_task=0.05, base_model=0.03, wu=0.8, wv=0.2, we=0.0, sx=0.3,
                       lam_g=0.25, rc=0.5, rg=0.5, rh=0.0, gam_kind="rad", pop_sigma=1.0),
    "common_b100": dict(th=1.0, lam=0.15, base_task=0.05, base_model=0.03, wu=0.8, wv=0.2, we=0.0, sx=0.3,
                        lam_g=0.25, rc=0.5, rg=0.5, rh=0.0, gam_kind="rad", pop_sigma=1.0),
    # weaker version of S (reaction 0.15, half shared): is the effect still there at moderate item shares?
    "mild_b75": dict(th=0.75, lam=0.20, base_task=0.06, base_model=0.03, wu=0.6, wv=0.4, we=0.0, sx=0.4,
                     lam_g=0.15, rg=0.5, rh=0.5, pop_sigma=1.0),
    # weak home signal (lam small) at the 0.75 boundary
    "weak_b75": dict(th=0.75, lam=0.06, lam_g=0.06, sx=1.2),
    # within-session copying of the earlier repeat (the later-session condition fails)
    "copy30_b75": dict(th=0.75, copy_rate=0.3),
    # PC2 null: the reader ignores the owner's usefulness (th = 0); shared reader reactions
    "pc2null_shared": dict(th=0.0, lam=0.15, base_task=0.05, base_model=0.03, wu=0.8, wv=0.2, we=0.0, sx=0.3,
                           lam_g=0.25, rc=0.5, rg=0.5, rh=0.0, gam_kind="rad", pop_sigma=1.0),
    "pc2null_benign": dict(th=0.0),
    # reversed home order (scores anti-correlated with the owner's usefulness): V_home < 0; reader at th = 0.25
    # of it, so V_swap - 0.75 V_home = -0.5 V_home > 0: the NI contrast alone would 'show no material drop'
    "neghome_th025": dict(th=0.25, home_sign=-1.0),
}

KEYS = ("theta", "lo", "hi", "p_home", "p_md_c", "p_ni_c", "p_drop_c", "p_self_c", "p_drop", "p_md", "p_ni",
        "home_est", "home_se", "md_c_est", "md_c_se", "ni_c_est", "ni_c_se", "drop_c_est", "drop_c_se",
        "self_c_est", "self_c_se", "ni_c_item_share", "ni_c_eff_items", "ni_c_df_satt", "stakes", "stakes_lo",
        "stakes_hi", "order", "order_lo", "order_hi", "order_status", "interval")


def one(args):
    world, seed, groups, codings, with_s, with_fresh, pc2, pc2_only = args
    cfg = WORLDS[world]
    rng = np.random.default_rng([2027, seed, zlib.crc32(world.encode())])
    sim = D.simulate(cfg, rng, groups=groups)
    rec = {"world": world, "seed": seed}
    for g in groups:
        cells = D.GROUPS[g]
        cw_num = sum(float(sim[("V_home", s, b)].sum()) for s in sorted({s for s, _ in cells}) for b in range(D.N_STREAMS))
        cw_den = sum(float(sim[("W_home", s, b)].sum()) for s in sorted({s for s, _ in cells}) for b in range(D.N_STREAMS))
        rec[f"{g}|Cw_home"] = 0.5 + cw_num / (2 * cw_den)
        for cd in codings:
            if pc2_only:
                est, se, p, sh = D.pc2_test(sim, cells, cd)
                rec[f"{g}|{cd}|pc2_est"], rec[f"{g}|{cd}|pc2_se"], rec[f"{g}|{cd}|pc2_p"] = est, se, p
                rec[f"{g}|{cd}|pc2_item_share"] = float(sh)
                continue
            r = D.group_tests(sim, cells, cd, with_fresh=with_fresh, with_s=with_s)
            for k in KEYS:
                if k in r:
                    v = r[k]
                    rec[f"{g}|{cd}|{k}"] = v if isinstance(v, str) else float(v)
            if pc2:
                est, se, p, sh = D.pc2_test(sim, cells, cd)
                rec[f"{g}|{cd}|pc2_est"], rec[f"{g}|{cd}|pc2_se"], rec[f"{g}|{cd}|pc2_p"] = est, se, p
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("world")
    ap.add_argument("reps", type=int)
    ap.add_argument("out")
    ap.add_argument("--groups", default="upgrade,cross")
    ap.add_argument("--codings", default="owner,write")
    ap.add_argument("--workers", type=int, default=2)
    ap.add_argument("--start", type=int, default=0)
    ap.add_argument("--no-s", action="store_true")
    ap.add_argument("--no-fresh", action="store_true")
    ap.add_argument("--pc2", action="store_true")
    ap.add_argument("--pc2-only", action="store_true")
    a = ap.parse_args()
    groups = tuple(a.groups.split(","))
    codings = tuple(a.codings.split(","))
    jobs = [(a.world, a.start + i, groups, codings, not a.no_s, not a.no_fresh, a.pc2, a.pc2_only) for i in range(a.reps)]
    t0 = time.time()
    with open(a.out, "a") as f, ProcessPoolExecutor(a.workers) as ex:
        for i, rec in enumerate(ex.map(one, jobs, chunksize=1)):
            f.write(json.dumps(rec) + "\n")
            f.flush()
            if (i + 1) % 50 == 0:
                print(f"{a.world}: {i + 1}/{a.reps} in {time.time() - t0:.0f} s", flush=True)
    print(f"done {a.world} {a.reps} in {time.time() - t0:.0f} s", flush=True)


if __name__ == "__main__":
    main()
