#!/bin/bash
# R7 batch 1b (trimmed remainder of batch 1)
cd <project>
PY=.venv/bin/python
R=paper/reviews/round3/r7_checks
$PY $R/r7_run_theta.py pc2null_shared 200 $R/out/pc2null_shared.jsonl --groups upgrade,cross --pc2-only
$PY $R/r7_run_theta.py common_b75 200 $R/out/common_b75.jsonl --groups upgrade,cross --no-s --no-fresh
$PY $R/r7_run_theta.py shared_b100 150 $R/out/shared_b100.jsonl --groups cross --no-s
$PY $R/r7_run_theta.py neghome_th025 300 $R/out/neghome_th025.jsonl --groups upgrade --no-s --no-fresh --codings owner
