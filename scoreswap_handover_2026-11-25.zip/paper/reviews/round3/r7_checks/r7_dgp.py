"""R7 (round-3 reviewer) independent data-generating process for the primary theta tests.

Written from the paper's description only (Sections 3-4, Appendix "Statistics in Full"), not from the
authors' simulators. It calls the authors' functions (msr.metrics.theta_tests) on data assembled the way
msr.analysis.TwoWay.theta assembles them (one component per (statistic, cell, stream), pooled over the
three orders; psi = (v - mean_c) / n_c; task clusters = stream|task id; item clusters as the analysis
codes them: owner|stream|item, where an item id is "<write task id>@<owner>").

Design features that matter here (all stated in the paper):
  * every model writes its bank from the SAME 250 write tasks of an order, and retrieval uses the
    write task's text only, so for a probe task every owner's 4 candidates are the same 4 write tasks
    (msr/build.py make_item_id: "<write task id>@<model>"; msr/probe.py: items found by the embedding of
    the write task that made them);
  * the three orders reshuffle one pool of 1,500 tasks per stream;
  * 400 evaluation tasks per order, 4 candidates, 2 repeats (home cells 4, repeats 3-4 a later session).

Outcome model (probability scale, linear, no clipping; asserted), for owner s, reader r, task tau,
candidate w (a write task id):
    mu_s(tau, w)    = B_s(tau) + lam * beta_s(tau, w)
    mu_r|s(tau, w)  = B_r(tau) + th * lam * beta_s(tau, w) + lam_g * gam_r,s(tau, w)
    beta_s(tau, w)  = wu * u_w + wv * v_{s,w} + we * e_{tau,w}             (owner's item usefulness)
    gam_r,s(tau, w) = rc * c_w + rg * g_{r,w} + rh * h_{r,s,w} + rz * z_{r,tau,w}
    x_{s,w,o}       = wu * u_w + wv * v_{s,w} + sx * eps_{s,w,o}           (owner's score in order o)
u, v, e, c, g, h, z are independent, mean 0, in [-1, 1]; gam is independent of the scores, so
E[V_swap] = th * E[V_home] EXACTLY over the item and task populations: the true theta is th.
u_w and c_w are properties of the write task (shared by every owner's version of item w);
g_{r,w} is reader r's reaction to write task w (shared over the owners whose bank reader r reads).
"""
from __future__ import annotations

import math
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[4]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from msr import metrics as M  # noqa: E402  (read-only use of the authors' code)

# ----------------------------------------------------------------------------------------- design
N_STREAMS, N_ORDERS, POOL, N_WRITE, N_EVAL, N_CAL, K = 2, 3, 1500, 250, 400, 100, 4
# 12 models: 6 makers x (old, new); makers 0-3 = core grid, 4-5 = extension pairs
MODELS = [(mk, g) for mk in range(6) for g in (0, 1)]
CORE = [i for i, (mk, _) in enumerate(MODELS) if mk < 4]
UPGRADES = [(2 * mk, 2 * mk + 1) for mk in range(6)]                     # 6 disjoint same-maker pairs
DOWNGRADES = [(2 * mk + 1, 2 * mk) for mk in range(6)]
CROSS = [(i, j) for i in CORE for j in CORE if MODELS[i][0] != MODELS[j][0]]   # 48 swaps
GROUPS = {"upgrade": UPGRADES, "downgrade": DOWNGRADES, "cross": CROSS}


def bounded(rng, size, kind: str, kappa: float = 0.15, nu: float = 1.5):
    """Mean-0 draws in [-1, 1]. 'unif': U(-1, 1); 'spiky': sign(T) min(1, kappa |T|) with T ~ t_nu
    (most values small, a few at +-1: a few dominant items); 'rad': +-1."""
    if kind == "unif":
        return rng.uniform(-1.0, 1.0, size)
    if kind == "spiky":
        t = rng.standard_t(nu, size)
        return np.sign(t) * np.minimum(1.0, kappa * np.abs(t))
    if kind == "rad":
        return rng.choice([-1.0, 1.0], size)
    raise ValueError(kind)


DEFAULT = dict(lam=0.25, wu=0.0, wv=0.8, we=0.2, sx=0.6, p_tie=0.10,
               lam_g=0.12, rc=0.0, rg=0.0, rh=1.0, rz=0.0,
               item_kind="unif", gam_kind="unif", pop_sigma=0.0, th=0.75,
               base_task=0.08, base_model=0.04, copy_rate=0.0, home_sign=1.0)


def simulate(cfg: dict, rng, groups=("upgrade", "cross"), need_models=None):
    """One replication: per (stream, order) the split, candidates and outcomes; returns per (cell,
    stream) the per-task arrays over the three orders: V_home (owner reps 1-2), V_fresh (owner reps
    3-4), V_swap (reader reps 1-2), S_owner, S_reader, the task ids, the candidate write-task ids,
    and the keep / wipe first-shown successes."""
    c = {**DEFAULT, **cfg}
    th = c["th"]
    cells = sorted({sw for g in groups for sw in GROUPS[g]})
    owners = sorted({s for s, _ in cells})
    models = sorted({m for sw in cells for m in sw})
    nm = len(MODELS)
    out = {"cells": cells, "owners": owners}
    per = {}   # (key, s, r, b) -> list over orders of arrays
    for b in range(N_STREAMS):
        # pool-level latent quantities of this stream
        d_task = rng.uniform(-1, 1, POOL)
        d_mt = rng.uniform(-1, 1, (nm, POOL))
        u = bounded(rng, POOL, c["item_kind"])
        cw = bounded(rng, POOL, c["gam_kind"])
        v = bounded(rng, (nm, POOL), c["item_kind"])
        g = bounded(rng, (nm, POOL), c["gam_kind"])
        h = bounded(rng, (nm, nm, POOL), c["gam_kind"])
        logpop = c["pop_sigma"] * rng.standard_normal(POOL)
        for o in range(N_ORDERS):
            perm = rng.permutation(POOL)
            write, ev = perm[:N_WRITE], perm[N_WRITE:N_WRITE + N_EVAL]
            # candidates: 4 distinct write tasks drawn with probability ~ popularity (Gumbel top-k);
            # the SAME 4 write tasks for every owner (retrieval on the write task's text)
            gum = logpop[write][None, :] + rng.gumbel(size=(N_EVAL, N_WRITE))
            top = np.argsort(-gum, axis=1)[:, :K]
            cand = write[top]                                       # (E, K) pool ids of write tasks
            rel = np.take_along_axis(gum, top, axis=1)
            rel = 0.5 + 0.5 * (rel - rel.min()) / (rel.max() - rel.min() + 1e-12)
            e = bounded(rng, (N_EVAL, K), c["item_kind"])
            zz = bounded(rng, (nm, N_EVAL, K), c["gam_kind"])
            B = 0.5 + c["base_task"] * d_task[ev][None, :, None] + c["base_model"] * d_mt[:, ev][:, :, None]  # (nm, E, 1)
            # scores per owner in this order (a new score phase per order), ties for unvisited items
            x = {}
            for s in owners:
                # the same item has the same score on every task of the order: draw per write task
                xw = c["home_sign"] * (c["wu"] * u[write] + c["wv"] * v[s][write]) + c["sx"] * rng.standard_normal(N_WRITE)
                xw = np.where(rng.random(N_WRITE) < c["p_tie"], 0.0, xw)
                xs = xw[top]
                x[s] = xs
            beta = {s: c["wu"] * u[cand] + c["wv"] * v[s][cand] + c["we"] * e for s in owners}
            mu_home = {s: B[s] + c["lam"] * beta[s] for s in owners}

            def draw(mu, reps):
                assert mu.min() >= 0.0 and mu.max() <= 1.0, (mu.min(), mu.max())
                y = (rng.random(mu.shape + (reps,)) < mu[..., None]).astype(float)
                if c["copy_rate"] > 0:     # within-session copying of the earlier repeat (pairs 1-2, 3-4)
                    for a_, b_ in ((0, 1), (2, 3)):
                        if b_ < reps:
                            cp = rng.random(mu.shape) < c["copy_rate"]
                            y[..., b_] = np.where(cp, y[..., a_], y[..., b_])
                return y

            yh = {s: draw(mu_home[s], 4) for s in owners}
            for s in owners:
                a = x[s]
                vh, wh = M.signed_validity_parts(a, yh[s][..., :2].mean(-1))
                per.setdefault(("W_home", s, b), []).append(wh)
                vf, _ = M.signed_validity_parts(a, yh[s][..., 2:].mean(-1))
                so = M.cross_repeat_parts(yh[s][..., :2].mean(-1), yh[s][..., 2:].mean(-1))
                per.setdefault(("V_home", s, b), []).append(vh)
                per.setdefault(("V_fresh", s, b), []).append(vf)
                per.setdefault(("S_owner", s, b), []).append(so)
            for (s, r) in cells:
                gam = c["rc"] * cw[cand] + c["rg"] * g[r][cand] + c["rh"] * h[r, s][cand] + c["rz"] * zz[r]
                mu_r = B[r] + th * c["lam"] * beta[s] + c["lam_g"] * gam
                y = draw(mu_r, 2)
                vs, _ = M.signed_validity_parts(x[s], y.mean(-1))
                sr = M.cross_repeat_parts(y[..., 0], y[..., 1])
                per.setdefault(("V_swap", s, r, b), []).append(vs)
                per.setdefault(("S_reader", s, r, b), []).append(sr)
                # first-shown success of keep (0.5 u + 0.5 rel, u = score rank-normalised in [0, 1]) and wipe
                xs = x[s]
                uu = (xs - xs.min()) / (xs.max() - xs.min() + 1e-12)
                k_pick = np.argmax(0.5 * uu + 0.5 * rel + 1e-9 * rel, axis=1)
                w_pick = np.argmax(rel, axis=1)
                yb = y.mean(-1)
                per.setdefault(("FS", s, r, b), []).append(yb[np.arange(N_EVAL), k_pick] - yb[np.arange(N_EVAL), w_pick])
            per.setdefault(("task", b), []).append(ev)
            per.setdefault(("cand", b), []).append(cand)
    for k, lst in per.items():
        out[k] = np.concatenate(lst, axis=0)
    return out


def assemble(sim: dict, cells: list, item_coding: str = "owner", with_fresh: bool = True, with_s: bool = True):
    """Rows, influence columns, clusters and component ids exactly as msr.analysis.TwoWay.theta builds
    them for a group (one component per (statistic, cell, stream), pooled over the orders)."""
    parts = {"swap": [], "home": [], "fresh": [], "so": [], "sr": []}
    for (s, r) in cells:
        for b in range(N_STREAMS):
            parts["swap"].append((("V_swap", s, r, b), s, b))
            parts["home"].append((("V_home", s, b), s, b))
            if with_fresh:
                parts["fresh"].append((("V_fresh", s, b), s, b))
            if with_s:
                parts["so"].append((("S_owner", s, b), s, b))
                parts["sr"].append((("S_reader", s, r, b), s, b))
    colix = {"swap": 0, "home": 1, "fresh": 2, "so": 3, "sr": 4}
    P, T, I, C, pt = [], [], [], [], {}
    comp = 0
    for name, lst in parts.items():
        tot = 0.0
        for key, s, b in lst:
            vals = sim[key]
            n = len(vals)
            mu = float(vals.mean())
            tot += mu
            col = np.zeros((n, 5))
            col[:, colix[name]] = (vals - mu) / n
            P.append(col)
            T.append(b * 100000 + sim[("task", b)])
            cand = sim[("cand", b)]
            if item_coding == "owner":          # the analysis: owner | stream | item id (= write task @ owner)
                I.append(1_000_000 * (s + 1) + b * 100000 + cand)
            elif item_coding == "write":        # the write task within its stream, shared by the owners
                I.append(b * 100000 + cand)
            else:
                raise ValueError(item_coding)
            C.append(np.full(n, comp))
            comp += 1
        pt[name] = tot
    return pt, np.vstack(P), np.concatenate(T), np.vstack(I), np.concatenate(C)


def group_tests(sim: dict, cells: list, item_coding: str = "owner", with_fresh=True, with_s=True, margin=0.75):
    pt, P, T, I, C = assemble(sim, cells, item_coding, with_fresh, with_s)
    kw = {}
    if with_fresh:
        kw.update(v_fresh=pt["fresh"], psi_fresh=P[:, 2])
    if with_s:
        kw.update(s_owner=pt["so"], s_reader=pt["sr"], psi_so=P[:, 3], psi_sr=P[:, 4])
    return M.theta_tests(pt["swap"], pt["home"], P[:, 0], P[:, 1], T, I, C, margin=margin, **kw)


def pc2_test(sim: dict, cells: list, item_coding: str = "owner"):
    """PC2 (keep - wipe first-shown success after the swap) with the registered jackknife, assembled as
    msr.analysis.TwoWay.linear: components (FS_keep - FS_wipe per cell and stream), coef 1/n."""
    n_c = len(cells) * N_STREAMS
    P, T, I, C = [], [], [], []
    est = 0.0
    comp = 0
    for (s, r) in cells:
        for b in range(N_STREAMS):
            vals = sim[("FS", s, r, b)]
            n = len(vals)
            mu = float(vals.mean())
            est += mu / n_c
            P.append((vals - mu) / n / n_c)
            T.append(b * 100000 + sim[("task", b)])
            cand = sim[("cand", b)]
            I.append(1_000_000 * (s + 1) + b * 100000 + cand if item_coding == "owner" else b * 100000 + cand)
            C.append(np.full(n, comp))
            comp += 1
    rv = M.robust_variance(np.concatenate(P), np.concatenate(T), np.vstack(I), np.concatenate(C))
    se = math.sqrt(rv["V"]) if rv["V"] > 0 else float("nan")
    return est, se, M.normal_p(est, se)["p_two"], rv["item_share"]


def population_stakes(cfg: dict, cells: list, n_rep: int = 40, seed: int = 12345) -> tuple:
    """True stakes and order of a group by Monte Carlo over the item and task populations (noise-free
    second moments of the true chances, same pooling as the estimator)."""
    c = {**DEFAULT, **cfg}
    rng = np.random.default_rng(seed)
    so_t = sr_t = 0.0
    for _ in range(n_rep):
        d_task = rng.uniform(-1, 1, (N_EVAL,))
        u = bounded(rng, (N_EVAL, K), c["item_kind"])
        tot_o = tot_r = 0.0
        for (s, r) in cells:
            v = bounded(rng, (N_EVAL, K), c["item_kind"])
            e = bounded(rng, (N_EVAL, K), c["item_kind"])
            beta = c["wu"] * u + c["wv"] * v + c["we"] * e
            gam = (c["rc"] * bounded(rng, (N_EVAL, K), c["gam_kind"]) + c["rg"] * bounded(rng, (N_EVAL, K), c["gam_kind"])
                   + c["rh"] * bounded(rng, (N_EVAL, K), c["gam_kind"]) + c["rz"] * bounded(rng, (N_EVAL, K), c["gam_kind"]))
            mo = c["lam"] * beta
            mr = c["th"] * c["lam"] * beta + c["lam_g"] * gam
            for i in range(K):
                for j in range(i + 1, K):
                    tot_o += float(((mo[:, i] - mo[:, j]) ** 2).mean())
                    tot_r += float(((mr[:, i] - mr[:, j]) ** 2).mean())
        so_t += tot_o
        sr_t += tot_r
    stakes = math.sqrt(sr_t / so_t)
    return stakes, c["th"] / stakes
