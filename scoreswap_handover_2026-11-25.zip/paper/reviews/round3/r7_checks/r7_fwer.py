"""Approximate familywise error of the 12-member Holm family in a world where theta = 0.75 in every group
(MD and NI nulls true; the drop alternative true), from R7's per-replication p-values: upgrade and cross
from the same replication, the downgrade group approximated by the upgrade group of the next replication,
and the three PC2 members treated as clear rejections (p = 0; keep beats wipe in these worlds).
A family error = any MD or NI member rejected by Holm (msr.analysis.holm_steps)."""
import json, math, sys
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[3]))
from msr.analysis import holm_steps

def fwer(path, coding):
    recs = []
    for l in open(path):
        try:
            recs.append(json.loads(l))
        except json.JSONDecodeError:
            pass
    errs = []
    for i in range(len(recs) - 1):
        r, r2 = recs[i], recs[i + 1]
        ps, nulls = [], []
        for src, g in ((r, "upgrade"), (r2, "upgrade"), (r, "cross")):
            pre = f"{g}|{coding}|"
            ps += [src[pre + "p_drop"], src[pre + "p_md"], src[pre + "p_ni"]]
            nulls += [False, True, True]
        ps += [0.0, 0.0, 0.0]
        nulls += [False, False, False]
        rej = holm_steps(ps, 0.05)["reject"]
        errs.append(any(a and b for a, b in zip(rej, nulls)))
    n = len(errs)
    p = sum(errs) / n
    return {"coding": coding, "fwer": round(p, 4), "mc_se": round(math.sqrt(p * (1 - p) / n), 4), "n": n}

if __name__ == "__main__":
    out = {}
    for w in sys.argv[1:]:
        f = HERE / "out" / f"{w}.jsonl"
        out[w] = [fwer(f, c) for c in ("owner", "write")]
        print(w, out[w])
    (HERE / "out" / "fwer_approx.json").write_text(json.dumps(out, indent=1))
