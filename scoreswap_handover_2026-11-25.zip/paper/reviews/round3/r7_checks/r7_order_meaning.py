"""R7: what 'retained order' measures. Noise-free check with the authors' estimator pieces
(msr.metrics.signed_validity_parts, cross_repeat_parts with the true chances as both 'repeats').
The reader's item effects keep the owner's order EXACTLY (a strictly increasing map of the owner's
chances), yet the paper's 'retained order' theta / stakes differs from 1."""
import sys, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT))
import numpy as np
from msr import metrics as M

rng = np.random.default_rng(5)
E, C = 200000, 4
lev = rng.uniform(0.3, 0.7, E)
eff = rng.uniform(-0.25, 0.25, (E, C))
mu_o = np.clip(lev[:, None] + eff, 0.01, 0.99)
x = eff + rng.normal(0, 0.10, (E, C))           # a good but imperfect score
rows = []
for name, f in (("identity", lambda m: m),
                ("steeper logit x2 (increasing)", lambda m: 1 / (1 + np.exp(-2 * np.log(m / (1 - m))))),
                ("threshold-like logit x6 (increasing)", lambda m: 1 / (1 + np.exp(-6 * np.log(m / (1 - m))))),
                ("convex m^3 (increasing)", lambda m: m ** 3),
                ("flatter logit x0.5 (increasing)", lambda m: 1 / (1 + np.exp(-0.5 * np.log(m / (1 - m)))))):
    mu_r = f(mu_o)
    vh, _ = M.signed_validity_parts(x, mu_o)
    vs, _ = M.signed_validity_parts(x, mu_r)
    so = M.cross_repeat_parts(mu_o, mu_o)
    sr = M.cross_repeat_parts(mu_r, mu_r)
    theta = vs.sum() / vh.sum()
    stakes = np.sqrt(sr.sum() / so.sum())
    # share of within-task candidate pairs whose order is the same for owner and reader
    same = []
    for i in range(C):
        for j in range(i + 1, C):
            d1, d2 = mu_o[:, i] - mu_o[:, j], mu_r[:, i] - mu_r[:, j]
            same.append(np.mean(np.sign(d1) == np.sign(d2)))
    rows.append({"reader": name, "pairs_in_same_order": round(float(np.mean(same)), 4), "theta": round(float(theta), 3),
                 "stakes": round(float(stakes), 3), "retained_order": round(float(theta / stakes), 3)})
for r in rows:
    print(json.dumps(r))
(Path(__file__).resolve().parent / "out" / "order_meaning.json").write_text(json.dumps(rows, indent=1))
