#!/bin/bash
# R7 batch 2: benign, hubs, weak home, caching (group of 6 disjoint same-maker pairs; fast)
cd <project>
PY=.venv/bin/python
R=paper/reviews/round3/r7_checks
$PY $R/r7_run_theta.py benign_b75 1500 $R/out/benign_b75.jsonl --groups upgrade
$PY $R/r7_run_theta.py hubs_spiky_b75 1500 $R/out/hubs_spiky_b75.jsonl --groups upgrade --no-s
$PY $R/r7_run_theta.py benign_b100 1000 $R/out/benign_b100.jsonl --groups upgrade --no-s
$PY $R/r7_run_theta.py weak_b75 1500 $R/out/weak_b75.jsonl --groups upgrade --no-s --no-fresh --codings owner
$PY $R/r7_run_theta.py copy30_b75 600 $R/out/copy30_b75.jsonl --groups upgrade --no-fresh --codings owner
$PY $R/r7_run_theta.py mild_b75 300 $R/out/mild_b75.jsonl --groups upgrade,cross --no-s --no-fresh
$PY $R/r7_run_theta.py pc2null_benign 1000 $R/out/pc2null_benign.jsonl --groups upgrade --pc2-only
