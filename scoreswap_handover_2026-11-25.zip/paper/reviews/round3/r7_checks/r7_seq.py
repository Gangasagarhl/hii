"""R7 checks of the swap-day tests with the authors' functions (msr.sequential, msr.metrics) on R7's own task
worlds. Everything simulated; no model calls.

Worlds (a finite table of tasks, 4 candidates each; owner chances p_o, scores q in [0, 1], relevance):
  hetero   task levels from Beta(0.4, 0.4) (many near-deterministic tasks), item effects +-0.2
  sparse   85 % of tasks uninformative (all four candidates at the same chance), 15 % with large gaps
  depend   as hetero, but the reader's four checks of a task share one uniform with prob 0.6 (positively
           dependent checks; the marginals stay Bernoulli(p))
Reader tables are built so that the table mean of the tested statistic sits EXACTLY on the boundary.

Checks:
  1. margin 0, ranking form (A_swap) and decision form (d = y_keep - y_wipe): P(KEEP) and P(WIPE) at the
     exact boundary, i.i.d. tasks from the table, fresh checks (decide_margin0).
  2. the paired 0.75 test (decide_keep_or_drop) with a fresh home result per task (two owner repeats, as
     11.4.1) and the flag from 100 fresh calibration tasks (sequential.home_signal_flag): P(KEEP) at
     theta = 0.75 and P(DROP) at theta = 0.25; and with a negative home signal.
  3. a non-random check order (topic blocks): margin-0 false keeps.
Output: JSON to stdout and out/seq_checks.json.
"""
from __future__ import annotations

import json
import math
import os
import sys
import time
from pathlib import Path

for k in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(k, "1")
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
sys.path.insert(0, str(ROOT))
import numpy as np  # noqa: E402
from msr import sequential as S  # noqa: E402
from msr import metrics as M  # noqa: E402

C = 4


def make_world(name: str, rng, n: int = 20000) -> dict:
    if name in ("hetero", "depend", "neghome"):
        lev = rng.beta(0.4, 0.4, n)
        eff = rng.uniform(-0.2, 0.2, (n, C))
        p_o = np.clip(lev[:, None] + eff, 0.0, 1.0)
        q = np.clip(0.5 + 1.5 * eff + rng.normal(0, 0.15, (n, C)), 0, 1)       # scores follow the effects
        if name == "neghome":
            q = 1.0 - q                                                           # a reversed home order
    elif name == "sparse":
        inf = rng.random(n) < 0.15
        lev = rng.uniform(0.2, 0.8, n)
        gaps = np.where(inf[:, None], rng.choice([-0.45, 0.45], (n, C)), 0.0)
        p_o = np.clip(np.where(inf[:, None], 0.5 + gaps, lev[:, None]), 0, 1)
        q = np.clip(0.5 + 0.5 * gaps + rng.normal(0, 0.2, (n, C)), 0, 1)
    else:
        raise ValueError(name)
    rel = rng.uniform(0.5, 1.0, (n, C))
    usable = np.ones((n, C), bool)
    c, _ = S.stat_coefficients(q, usable)
    k, w = S.shown_pair(q, rel, usable, 0.5)
    e = S.shown_coef(k, w, C)
    return {"name": name, "p_o": p_o, "q": q, "rel": rel, "c": c, "e": e, "usable": usable,
            "abar_home": float((c * p_o).sum(-1).mean()), "gap_home": float((e * p_o).sum(-1).mean())}


def reader_table(W: dict, coef: np.ndarray, target: float, rng, eta_sd: float = 0.08) -> np.ndarray:
    """p_r = m + kappa (p_o - m) + eta (clipped), kappa found by bisection so that the TABLE mean of
    sum coef p_r equals target exactly (to 1e-10); eta: a reader-specific perturbation independent of the
    scores (fixed seed per world)."""
    p_o = W["p_o"]
    m = p_o.mean(-1, keepdims=True)
    eta = rng.normal(0, eta_sd, p_o.shape)

    def tab(kap):
        return np.clip(m + kap * (p_o - m) + eta, 0.0, 1.0)

    def f(kap):
        return float((coef * tab(kap)).sum(-1).mean())
    lo, hi = -3.0, 3.0
    inc = f(hi) > f(lo)
    for _ in range(200):
        mid = 0.5 * (lo + hi)
        if (f(mid) < target) == inc:
            lo = mid
        else:
            hi = mid
    p = tab(0.5 * (lo + hi))
    err = f(0.5 * (lo + hi)) - target
    # remove the last rounding error exactly by a tiny shift on one candidate of informative rows
    return p, err


def streams(W, p_r, R, T, rng, depend: float = 0.0, coef_key="c", blocks: bool = False):
    """R streams of T tasks drawn i.i.d. from the table (or in topic blocks): the reader's single checks
    (statistic with coef), the owner's fresh two-repeat home statistic A_h = sum c ybar, both (R, T)."""
    n = len(p_r)
    if blocks:
        # non-random order: tasks sorted by the sign of their true keep-minus-wipe value, blocks of 200
        val = (W[coef_key] * p_r).sum(-1)
        pos, neg = np.flatnonzero(val > 0), np.flatnonzero(val <= 0)
        idx = np.empty((R, T), dtype=np.int64)
        for r_ in range(R):
            out, t, turn = [], 0, rng.random() < 0.5
            while t < T:
                pool = pos if turn else neg
                b = rng.choice(pool, size=min(200, T - t))
                out.append(b)
                t += len(b)
                turn = not turn
            idx[r_] = np.concatenate(out)[:T]
    else:
        idx = rng.integers(0, n, size=(R, T))
    pr = p_r[idx]                                                    # (R, T, C)
    if depend > 0:
        common = rng.random((R, T, 1)) < depend
        U = np.where(common, rng.random((R, T, 1)), rng.random((R, T, C)))
    else:
        U = rng.random((R, T, C))
    ys = (U < pr).astype(np.float32)
    co = W[coef_key][idx].astype(np.float32)
    a_s = (co * ys).sum(-1)
    po = W["p_o"][idx]
    yh = ((rng.random((R, T, C)) < po).astype(np.float32) + (rng.random((R, T, C)) < po).astype(np.float32)) / 2
    a_h = (W["c"][idx].astype(np.float32) * yh).sum(-1)
    return a_s, a_h


def flags(W, R, rng, n_cal: int = 100):
    """The home flag per stream from n_cal fresh calibration tasks (owner's repeats 1-2)."""
    out = np.zeros(R, bool)
    zs = np.zeros(R)
    n = len(W["p_o"])
    for r_ in range(R):
        idx = rng.integers(0, n, n_cal)
        po = W["p_o"][idx]
        yb = ((rng.random(po.shape) < po).astype(float) + (rng.random(po.shape) < po).astype(float)) / 2
        v, _ = M.signed_validity_parts(W["q"][idx], yb)
        ok, z = S.home_signal_flag(v)
        out[r_], zs[r_] = ok, z
    return out, zs


def rate(x):
    x = np.asarray(x, float)
    r = float(x.mean())
    return {"rate": r, "mc_se": math.sqrt(max(r * (1 - r), 1e-12) / len(x)), "n": int(len(x))}


def main(R: int = 2000, T: int = 2000, chunk: int = 250):
    res = {"R": R, "T": T}
    t0 = time.time()
    for wname in ("hetero", "sparse", "depend"):
        rng = np.random.default_rng([7, hash_name(wname)])
        W = make_world("hetero" if wname == "depend" else wname, rng)
        dep = 0.6 if wname == "depend" else 0.0
        out = {"abar_home": W["abar_home"], "gap_home": W["gap_home"],
               "share_tasks_keep_wipe_differ": float((np.abs(W["e"]).sum(-1) > 0).mean())}
        # 1. margin 0: ranking (E A_swap = 0) and decision form (E d = 0)
        for form, key, tgt in (("ranking", "c", 0.0), ("decision", "e", 0.0)):
            p_r, err = reader_table(W, W[key], tgt, rng)
            keeps, wipes = [], []
            for _ in range(R // chunk):
                a_s, _ = streams(W, p_r, chunk, T, rng, dep, key)
                dec, used, tk, td = S.decide_margin0(a_s)
                keeps.append(tk <= T)
                wipes.append(td <= T)
            out[f"margin0_{form}"] = {"table_mean_error": err, "false_keep_by_T": rate(np.concatenate(keeps)),
                                      "false_wipe_by_T": rate(np.concatenate(wipes))}
        # 2. paired 0.75 test at the KEEP boundary (theta = 0.75) and the DROP boundary (theta = 0.25)
        for th, which in ((0.75, "keep"), (0.25, "drop")):
            p_r, err = reader_table(W, W["c"], th * W["abar_home"], rng)
            dec_all = []
            for _ in range(R // chunk):
                a_s, a_h = streams(W, p_r, chunk, T, rng, dep, "c")
                fl, _ = flags(W, chunk, rng)
                d = S.decide_keep_or_drop(a_s, a_h, fl)
                dec_all.append(d["decision"])
            dec = np.concatenate(dec_all)
            out[f"paired_theta{th}"] = {"table_mean_error": err,
                                        "keep": rate(dec == S.KEEP), "drop": rate(dec == S.DROP),
                                        "not_testable": rate(dec == S.NOT_TESTABLE)}
        res[wname] = out
        print(wname, json.dumps(out), f"{time.time() - t0:.0f}s", flush=True)
    # 3. negative home signal: reader at theta = 1 relative to a negative home (A_swap = A_home < 0): the
    #    proposition's statement 'drops with probability at most alpha whenever theta >= 0.25'
    rng = np.random.default_rng([7, 99])
    W = make_world("neghome", rng)
    p_r, err = reader_table(W, W["c"], 1.0 * W["abar_home"], rng)
    a_s, a_h = streams(W, p_r, 1000, T, rng)
    fl, z = flags(W, 1000, rng)
    d = S.decide_keep_or_drop(a_s, a_h, fl)
    dec_nogate, _, _, _ = S.decide_paired(a_s, a_h)
    res["neghome_theta1"] = {"abar_home": W["abar_home"], "flag_positive": rate(fl),
                             "keep": rate(d["decision"] == S.KEEP), "drop": rate(d["decision"] == S.DROP),
                             "not_testable": rate(d["decision"] == S.NOT_TESTABLE),
                             "drop_without_gate": rate(dec_nogate == S.DROP)}
    print("neghome", json.dumps(res["neghome_theta1"]), flush=True)
    # 4. non-random check order (blocks of 200 tasks sorted by their keep-minus-wipe sign), margin 0
    rng = np.random.default_rng([7, 101])
    W = make_world("hetero", rng)
    p_r, err = reader_table(W, W["e"], 0.0, rng)
    a_s, _ = streams(W, p_r, 1000, T, rng, 0.0, "e", blocks=True)
    dec, used, tk, td = S.decide_margin0(a_s)
    res["blocks_margin0_decision"] = {"false_keep_by_T": rate(tk <= T), "false_wipe_by_T": rate(td <= T)}
    print("blocks", json.dumps(res["blocks_margin0_decision"]), flush=True)
    (HERE / "out").mkdir(exist_ok=True)
    (HERE / "out" / "seq_checks.json").write_text(json.dumps(res, indent=1))


def hash_name(s: str) -> int:
    import zlib
    return zlib.crc32(s.encode())


if __name__ == "__main__":
    R = int(sys.argv[1]) if len(sys.argv) > 1 else 2000
    T = int(sys.argv[2]) if len(sys.argv) > 2 else 2000
    main(R, T)
