"""Summaries of R7's theta-test runs: rejection rates at the boundary (one-sided 0.05 and the first Holm step
0.05/12), the SD of the null z, coverage of theta's union Fieller set, stakes and order sets, with
Monte-Carlo standard errors."""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import r7_run_theta as RT  # noqa: E402
import r7_dgp as D  # noqa: E402

Z05 = 1.6448536269514722


def rate(x):
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    if not len(x):
        return None
    r = float(x.mean())
    return [round(r, 4), round(math.sqrt(max(r * (1 - r), 1e-12) / len(x)), 4), int(len(x))]


def sd(x):
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    return [round(float(x.std(ddof=1)), 3), round(float(x.std(ddof=1)) / math.sqrt(2 * (len(x) - 1)), 3), int(len(x))]


def summarize(path: Path, stakes_truth: bool = False):
    recs = []
    for line in open(path):
        try:
            recs.append(json.loads(line))
        except json.JSONDecodeError:
            pass
    if not recs:
        return {}
    world = recs[0]["world"]
    th = RT.WORLDS[world].get("th", D.DEFAULT["th"])
    out = {"world": world, "theta_true": th, "reps": len(recs)}
    groups = sorted({k.split("|")[0] for k in recs[0] if k.count("|") == 2})
    for g in groups:
        codings = sorted({k.split("|")[1] for k in recs[0] if k.startswith(g + "|") and k.count("|") == 2})
        out[f"{g}|Cw_home_mean"] = round(float(np.mean([r[f"{g}|Cw_home"] for r in recs if f"{g}|Cw_home" in r])), 4)
        for cd in codings:
            pre = f"{g}|{cd}|"
            o = {}
            if pre + "pc2_p" in recs[0]:
                p = np.array([r[pre + "pc2_p"] for r in recs])
                z = np.array([r[pre + "pc2_est"] / r[pre + "pc2_se"] for r in recs])
                o["pc2_size_two_sided_0.05"] = rate(p <= 0.05)
                o["pc2_size_at_0.05/12"] = rate(p <= 0.05 / 12)
                o["pc2_null_z_sd"] = sd(z)
                out[f"{g}|{cd}"] = o
                continue
            if pre + "theta" not in recs[0]:
                continue
            get = lambda k: np.array([r.get(pre + k, np.nan) for r in recs], dtype=float)  # noqa: E731
            if abs(th - 0.75) < 1e-9:
                zn = get("ni_c_est") / get("ni_c_se")
                zm = get("md_c_est") / get("md_c_se")
                o["ni_contrast_null_z_sd"] = sd(zn)
                o["ni_contrast_null_z_mean"] = round(float(np.nanmean(zn)), 3)
                o["size_PC1-NI_0.05"] = rate(get("p_ni") <= 0.05)
                o["size_PC1-MD_0.05"] = rate(get("p_md") <= 0.05)
                o["size_PC1-NI_0.05/12"] = rate(get("p_ni") <= 0.05 / 12)
                o["size_PC1-MD_0.05/12"] = rate(get("p_md") <= 0.05 / 12)
            if abs(th - 1.0) < 1e-9:
                zd = get("drop_c_est") / get("drop_c_se")
                o["drop_contrast_null_z_sd"] = sd(zd)
                o["size_PC1-drop_contrast_0.05"] = rate(get("p_drop_c") <= 0.05)
                o["size_PC1-drop_member_0.05"] = rate(get("p_drop") <= 0.05)
                o["size_PC1-drop_member_0.05/12"] = rate(get("p_drop") <= 0.05 / 12)
            lo, hi = get("lo"), get("hi")
            o["theta_cover_union_fieller"] = rate((lo <= th) & (th <= hi))
            o["theta_hat_mean"] = round(float(np.nanmean(get("theta"))), 4)
            o["theta_hat_sd"] = round(float(np.nanstd(get("theta"))), 4)
            o["median_item_share_ni"] = round(float(np.nanmedian(get("ni_c_item_share"))), 3)
            o["median_eff_items_ni"] = round(float(np.nanmedian(get("ni_c_eff_items"))), 1)
            o["median_home_z"] = round(float(np.nanmedian(get("home_est") / get("home_se"))), 2)
            if pre + "stakes" in recs[0] and stakes_truth:
                cells = D.GROUPS[g]
                st_true, or_true = D.population_stakes(RT.WORLDS[world], cells)
                o["stakes_true"], o["order_true"] = round(st_true, 4), round(or_true, 4)
                s_lo, s_hi = get("stakes_lo"), get("stakes_hi")
                o_lo, o_hi = get("order_lo"), get("order_hi")
                o["stakes_cover"] = rate((s_lo <= st_true) & (st_true <= s_hi))
                ident = np.array([r.get(pre + "order_status", "") == "defined" for r in recs])
                o["order_identifiable_share"] = round(float(ident.mean()), 3)
                ok = (o_lo <= or_true) & (or_true <= o_hi)
                o["order_cover_identifiable"] = rate(ok[ident])
                o["stakes_hat_mean"] = round(float(np.nanmean(get("stakes"))), 4)
                o["order_hat_mean"] = round(float(np.nanmean(get("order"))), 4)
            out[f"{g}|{cd}"] = o
    return out


if __name__ == "__main__":
    paths = [Path(p) for p in sys.argv[1:]] or sorted((HERE / "out").glob("*.jsonl"))
    allr = []
    for p in paths:
        s = summarize(p, stakes_truth=True)
        allr.append(s)
        print(json.dumps(s, indent=1))
    (HERE / "out" / "theta_summary.json").write_text(json.dumps(allr, indent=1))
