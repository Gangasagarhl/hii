# Review R8: novelty, positioning, significance and honesty of claims

Submission: "ScoreSwap: Are Learned Memory Scores Worth Keeping After a Model Swap?" (`paper/main.pdf`, with
`paper/dryrun.pdf` as the simulated practice version). Reviewed 24 November 2026.

**How I checked.**
- I read the sources in `paper/sections/`, `paper/main.tex`, `paper/references.bib`, the reference ledger,
  `prediction/PREREGISTRATION.md` (power, cost, pilot gate and stopping parts), `docs/BENCHMARK_GUIDE.md`,
  `legs/memrl/README.md` and `config/models.yaml`.
- I did not open the folders I was told not to read, and I did not read the other round-3 reports.
- Every work cited about prior systems, memory transfer, per-item value across models and model-change decisions was
  opened on the web and checked against the sentence the paper writes about it. I opened the decisive sources myself
  (marked **[me]**). The rest were read by research assistants I briefed, who returned the deciding source sentences
  (marked **[asst]**).
- OpenReview blocks automated access. For the ICLR 2027 submissions I read the public metadata mirror
  `github.com/papercopilot/paperlists` (`iclr/iclr2027.json`, 24 Nov 2026), which gives title, status, area and
  abstract but not reviews or author responses.
- Excerpts of the two most important sources are saved in `paper/reviews/round3/r8_notes/evidence_excerpts.md`:
  Chang & Jia's Table 4 and the ICLR 2027 records.

---

## Summary of the submission

1. **The setting.** Some research memories for LLM agents keep a usefulness score per stored item, learned from task
   outcomes under one model (MemRL-style moving averages, success counts, helpful/harmful tags, with-minus-without
   credit). The paper asks whether these scores are still worth using after the model behind the memory is replaced,
   and what an operator should do on the day of the swap.
2. **The memory.** The main study uses "exemplar memory". Each item is a past single-call task stored with the old
   model's unlabelled answer. For each new task the 4 most similar items are retrieved and one is shown, chosen by
   0.5 × score + 0.5 × relevance.
3. **The data.** For every ordered pair of 8 models from 4 makers, plus two further same-maker pairs, the benchmark
   freezes the content and records the new model's graded result with each of the 4 candidates shown alone (twice).
   Any rule that re-scores the items can then be scored offline.
4. **The measures.** The headline θ is a ratio of signed pairwise success differences, swap over home, and is not
   biased by outcome noise. A self-swap reference shows what "no change" looks like.
5. **The rules and tests.** Swap-day rules (keep, wipe, discounts, power prior, recalibration, re-test, audit, relearn,
   judge) are compared at a stated cost. Two sequential tests and a lower bound say how many fresh checks an operator
   needs to decide "keep beats wipe" and "at most a quarter of the value lost".
6. **The agent leg.** A side study on MemRL's released code asks whether the learned order still matters after a swap
   in a multi-step bash agent.
7. **Status.** No real-model run has been made. Every result in `main.pdf` is a placeholder. The only numbers on real
   data are a recomputation from Beyond Gain's released skill scores (App. H) and method-validation numbers from
   simulation.

---

## Strengths

- **S1. The question is concrete and has a real motivation.** MemRL (NeurIPS 2026) says in App. E.4 that "the learned
  utility over memories generalizes beyond any single model's inherent strength" **[me]**. Several published systems
  carry outcome-learned per-item scores to a new backbone without checking them: MemRL, RoMeRL, EvoKernel, CHIME,
  ExpHarness and CompSkill, and, uncited, Skill-Pro and XferAgent. Testing that claim with the content held fixed is a
  sensible thing to do.
- **S2. The design separates what earlier transfer studies mixed.**
  - Content is frozen and only the scores change.
  - Each candidate is probed alone.
  - A self-swap reference and a content-only (shuffled) control are included.
  - The headline is unbiased by outcome noise, and the stakes are reported in success points.
  - The question is split into "is the order kept" (Q1) and "is it worth anything" (Q2).

  This fixes the confound the paper correctly identifies in MemRL, RoMeRL and EvoKernel, whose end-task numbers mix
  content with order (`01_introduction.tex:33`).
- **S3. The operator framing is useful.** It asks what each rule costs in calls to the old model before it retires
  and to the new model on the day. It also separates the cheap question ("is keeping still better than wiping?") from
  the expensive one ("was at most a quarter lost?", which needs the old model's results collected in advance). The
  second point is practical and, as far as I found, not made elsewhere for memory scores.
- **S4. Unusual care with references.** I found no hallucinated reference: every cited work exists. The ledger
  records the page opened, the date and a quoted sentence, and it flags thin evidence. That is better than most
  submissions.
- **S5. Pre-registration, a pilot gate and an offline sealed scorer.** These make the eventual results easier to
  trust and the benchmark cheap to enter: an entry is scored offline in minutes, with no model call.
- **S6. Honest scoping in many sentences.**
  - "Every claim is about the pairs we ran" (`01_introduction.tex:43`).
  - The limitations say models are treated as fixed (`08_limitations.tex:12`).
  - The agent leg states its minimum detectable effect and that smaller effects are "undetermined, not absent"
    (`06_agent_leg.tex:13-14`).

---

## Weaknesses

Tags: FATAL (blocks acceptance on its own), MAJOR (must be fixed for acceptance), MINOR.

### W1 (FATAL). There are no results: every claim the paper makes about its question is a placeholder.

**Where.**
- The abstract's headline and its two check sizes (`00_abstract.tex:7-8`).
- The "Findings" paragraph (`01_introduction.tex:50-53`).
- All of Sections 5–8, the agent-leg readings (`06_agent_leg.tex:17`), and the decision table promised in
  `07_discussion.tex:17`.
- `main.pdf` prints 17 "TODO" markers and 26 "pending" boxes.
- The only real-data result is App. H, a recomputation from another paper's released skill scores.

**Why it is fatal.**
- ICML 2027 has no registered-report track.
- The Call for Papers (https://icml.cc/Conferences/2027/CallForPapers, opened by me) warns that
  "submissions with 'placeholder' abstracts that are substantially rewritten for the full submission risk being
  removed".
- Contribution (i), the benchmark, is also not yet real: the probe tables that make up the benchmark do not exist.

**Fix.** Run at least the registered core (the full grid on both streams, the self-swap reference and the
content-only control). Fill every number from the frozen pre-registration and file the abstract only once the
headline is known.

### W2 (MAJOR). The novelty claim is overstated: per-item usefulness scores have been compared across models before, with content fixed, and some of that work is in the authors' own bibliography but not cited.

**The sentences.**
- `01_introduction.tex:35`: "What has not been measured is how much of a learned memory score's order, and of its
  value, survives a swap when the content is held fixed and outcome noise is allowed for."
- `02_related_work.tex:18`: "None of these measures how much of a learned memory score's order and value survives
  with the content fixed and outcome noise allowed for."
- `A10_related_table.tex:61`: "...they do not measure how much of a learned per-example score's order survives net
  of outcome noise."

**What I found.**

- **Chang & Jia, "Data Curation Alone Can Stabilize In-context Learning", ACL 2023**
  (https://aclanthology.org/2023.acl-long.452/) **[me]**.
  - Their CondAcc score is "the expected accuracy conditioned on this example appearing in a prompt". It is an
    outcome-learned per-example usefulness score of the same kind as `beta_grade` and `ema_grade`.
  - Sec. 6.3, "Do LLMs find the same stable examples?", reports in Table 4 the Pearson correlation of these scores
    between models, on fixed examples:

    | Model pair | SST-2 | AGNews | BoolQ | Subj | Scicite |
    |---|---|---|---|---|---|
    | GPT-J-6B vs OPT-13B (cross-maker) | 0.15 | 0.46 | 0.41 | −0.03 | 0.02 |
    | OPT-6.7B vs OPT-13B (same family) | 0.76 | 0.42 | — | — | — |

    Only 1–4 examples are shared between the stable subsets.
  - This is the Q1 question for demonstration scores, with a cross-maker versus same-family contrast.
  - It is in `references.bib` (`chang2023curation`) but cited nowhere in the body.
  - The authors' own ledger says: "The cross-model correlation figures quoted in the team's report are in the paper
    body and were not re-read; the paper text does not rely on them" (`reference_ledger.md`, entry
    `chang2023curation`).
- **Nguyen & Wong, "In-context Example Selection with Influences", arXiv 2302.11042** **[me]**.
  - Sec. "Do models agree on high-influence examples?": across 7 LLMs the models "rarely agree on the most positive
    and negative influence examples (≤4 for all tasks)", while "within the same model families, we identify a decent
    overlap".
  - Their influence is a with-minus-without score, like `credit`.
  - It is in `references.bib` (`nguyen2023influences`) but not cited.
- **Selection via Proxy, ICLR 2020 (cited)** **[asst]**. Sec. 3.4 compares cross-model rank correlation of per-example
  selection scores with the correlation "between runs of the same model". That is a noise reference for exactly the
  "net of outcome noise" part of the claim. The paper cites SVP only for "signals carry" (`02_related_work.tex:17`).
- **Ethayarajh, Choi & Swayamdipta, ICML 2022 (V-usable information)** **[asst]**. Cross-model correlation of
  per-instance PVI, shown beside cross-seed correlation. Not cited.
- **Superfiltering (ACL 2024) and Mekala et al. (Findings ACL 2024)** **[asst]**. Spearman and Kendall rank survival
  of per-sample LLM scores across model sizes, with much lower top-k overlap. Not cited.
- **Yang, Chowdhury, Yan, Thakur, "What Is This Memory Useful For?", arXiv 2611.03930 (2 Nov 2026, concurrent)**
  **[me]**. Fixed agent memories; per memory–task utility labels by with/without runs. A second reader
  (gemma-4-31B-it against gpt-oss-120b) gives labels that "agree at Cohen's κ = 0.58" over 275 cells. This is the same
  question for agent memory, at the item-and-task level. Not cited.
- **Beyond Gain (cited)** **[asst]**. It reports per-skill verdict flips between models (14–23%), a skill×model
  variance share, and a resampling noise floor (5–9% flips). The paper's own App. H rests on this data, so a
  per-item transfer measurement with a noise reference exists on released real data before ScoreSwap's.
- **"Refreshing Agent Memory with Policy-Response Drift", ICLR 2027, withdrawn (OpenReview 6YeGSweiCZ)** **[me]**.
  - Its abstract: "An agent memory card can help one policy and hurt its successor".
  - It re-estimates per-card effects under the successor policy for two Qwen updates, with purchased target tasks
    and a pre-specified non-inferiority margin.
  - That is contribution (iii) for agent memory.
  - It is cited only as one row of the appendix table (`A10_related_table.tex:25`), where "item-level rank after the
    swap" is marked "no".

**What is still new.** The combination: online-learned agent-memory scores rather than offline example valuations;
a noise-unbiased value ratio with a self-swap reference; current models in a same-maker/cross-maker grid; and swap-day
rules priced in checks, with a lower bound. That is a fair incremental contribution, but the paper must say it is
incremental.

**Fix.**
- Cite and describe Chang & Jia, Nguyen & Wong, SVP's run-to-run reference, Ethayarajh et al., Yang et al. 2026 and
  Policy-Response Drift in the body.
- Rewrite the three sentences above to name the actual difference.
- Report one statistic comparable with the 2023 numbers, for example the Pearson or Spearman correlation between the
  owner's scores and the scores the reader learns in `relearn`, and top-k overlap, so readers can place θ against
  them.

### W3 (MAJOR). Several sentences about prior work are wrong or unsupported.

The brief rightly treats a wrong description of prior work as serious. Each item gives file and line, the source and
the fix.

1. **Beyond Gain's 14–23% is not a skill effect** (`02_related_work.tex:13`). The sentence reads: "Skill effects
   depend on the backbone ..., with verdicts flipping between models for 14–23% of skills".
   - Beyond Gain's flip is the verdict based on the score *without* the skill, i.e. whether a model can already do the
     task (Sec. 4.4: "Between pairs of models, verdicts flip for 14% to 23% of skills") **[asst]**.
   - The paper's own App. H gets this right ("unaided verdict", `A11_outside_check.tex:30`).
   - Fix: "...and whether a skill can be retired, judged from the score without it, flips between models for 14–23%
     of skills".
2. **LLM-specific utility did swap passages** (`A10_related_table.tex:60`). The sentence reads: "the same question for
   retrieval passages, without a swap or an order measure."
   - Sec. 4.3 of Zhang et al. (https://arxiv.org/html/2510.11358; CIKM 2026) uses "passages constructed for one LLM ...
     by other LLMs" and concludes they "are not shareable with other LLMs" **[me]**.
   - Sec. 4.2 reports cross-LLM overlap counts.
   - Fix: "it swaps utilitarian passage sets across LLMs and counts shared passages, but reports no rank correlation
     and no noise reference."
3. **Only Zhang et al. 2022 found a learned policy weaker on larger models** (`A10_related_table.tex:61`). The sentence
   reads: "Peng et al., MDR and Zhang, Feng and Tan find example value partly model-specific and a learned selection
   policy weaker on larger models."
   - Peng et al.'s method is training-free and "consistently outperforms previous methods across different model
     scales" **[asst]**.
   - MDR's abstract does not say this.
   - Fix: attribute the second half to Zhang et al. only, as `02_related_work.tex:16` already does.
4. **One of the "three submissions under review" was desk-rejected** (`02_related_work.tex:24`). The sentence reads:
   "According to their abstracts and author responses, three submissions under review ...".
   - "When Can Historical Scores Be Reused After Judge Replacement?" (fmDOTwVZes) has status "Desk Reject" **[me]**.
     The bib entry says so (`references.bib:222`); the text does not.
   - Separately, "compare own, pooled and donor execution credit" is attributed to "Beyond Semantic Relevance"
     (W5fHCH5rOE). Its abstract says nothing about own, pooled or donor credit. That wording matches the abstract of a
     different submission, wSdg23aQOr ("records of the same proposal at other receivers ... receiver-only and pooled
     histories") **[me]**.
   - The ledger says the attribution rests on author responses, which are not archival and which I could not read.
   - Fix: say "two submissions under review and one desk-rejected"; describe each from its abstract; do not cite
     rebuttal numbers.
5. **MemRL's rule is misdescribed** (`03_benchmark.tex:18`). The sentence reads: "`ema_grade` is MemRL's reward moving
   average q ← q + 0.3(y − q) from q = 0.5 ...; MemRL's released configuration uses the same start and rewards."
   - MemRL's paper gives "Q_init — Initial Q-value — 0.0" (Table 8, App. E.2) and "a scalar reward r_t ∈ [−1, 1]"
     (App. A.1) **[me]**.
   - Only the one config file at commit c1b322c has 0.5 and 0/1 rewards. The code's own defaults follow the paper
     (`q_init` 0.0, `failure_reward` −1.0) **[asst]**.
   - The same applies to "the episodes' 0/1 rewards" in `06_agent_leg.tex:7`.
   - Fix: "as in the LifelongAgentBench configuration released with MemRL (the paper uses Q_init = 0 and rewards in
     [−1, 1])".
6. **A design choice is supported by a citation that does not support it** (`04_setup.tex:8`). The sentence reads:
   "Reasoning is switched off on every model that has a switch, the same way within a pair [anon2026execrecords]."
   - The cited submission's abstract says nothing about reasoning settings **[me]**. The ledger points to an author
     response.
   - Fix: drop the citation and state the choice as the authors' own.
7. **Skill repair is done by an LLM, not by replay** (`A10_related_table.tex:77`). The sentence reads: "When Agent
   Skills Go Stale ... repairs them by replaying checks."
   - In that paper, replay detects conflicts; "an LLM maintainer updates only the affected skill state" **[asst]**.
   - Fix: "detects them by replaying checks and repairs them with an LLM maintainer".
8. **SwapBench's "half" depends on the replay size** (`02_related_work.tex:22`). The sentence reads: "a full scenario
   replay returned 'not enough evidence' on half of the swaps it scored."
   - The page reports 5 of 10 at 260 scenarios and 6 of 10 at 60 scenarios **[me]**.
   - More importantly, this is an undated, unauthored vendor web page (ZenML) presented as an empirical finding in
     Related Work.
   - Fix: give the replay size, and label it as an industry web report.
9. **Smaller overstatements.**
   - `A10_related_table.tex:65`: EPR's gains are "similar" for GPT-3 but about half on Codex.
   - `A10_related_table.tex:66`: LLM-R's "consistent" gains fall to +0.4 on GPT-3.5-Turbo (the paper's own Table 4).
   - `02_related_work.tex:10` / `01_introduction.tex:41`: StreamBench's shared memory "helps" on BIRD by only +1.07
     over the three-model average, and scores below Claude-3-haiku with its own memory.
   - `A10_related_table.tex:25`: Policy-Response Drift does estimate item-level value after the swap, so "partly"
     fits better than "no".

   All **[asst]** except the last **[me]**.

### W4 (MAJOR). The title claims more than the setting supports, and the agent leg is unlikely to close the gap.

**The setting.**
- The title (`main.tex:94`) asks about "Learned Memory Scores" in general.
- The measured setting is narrow: single-call tasks; unlabelled stored answers; reasoning switched off; one item
  shown; the score acting only among 4 embedding neighbours; and a fixed 0.5 weight on relevance (`03_benchmark.tex:10`).
- The systems that motivate the paper show several items at once: MemRL shows 5 of 10 (its Table 8). StreamBench's
  memory stores only outputs that ground-truth feedback marked correct **[asst]**, which this study removes.
- θ measures the score's full pairwise order among 4 items. With 4 candidates and half the weight on relevance, the
  score can change the first-shown choice on only part of the tasks. Whatever θ is, how much it matters is capped by
  the design.

**The agent leg cannot repair this.**
- By its own power analysis it detects "about 5 success points per pair" (`06_agent_leg.tex:13`).
- MemRL's whole gain over its strongest baseline on these tasks was 2.6 points (`06_agent_leg.tex:19`, confirmed
  **[asst]**). The part due to the learned *order*, keep minus visit-stratified shuffle, can only be smaller.
- So the likely registered reading for most pairs is "uninformative" or "undetermined"
  (`legs/memrl/README.md`, Sec. 2.5 says as much).

**Fix.**
- Scope the title, e.g. "... in Exemplar Memory".
- In the abstract and Sec. 8, state the leg's expected outcome given its detectable effect.
- Either run the priced one-memory probe in the leg (`legs/memrl/README.md`, Sec. 2.6), or report the realism check
  (exact Shapley values over all 16 subsets, `A13_secondary_results.tex:109-110`) in the body, for all kinds of swap
  rather than only upgrades.

### W5 (MAJOR). With the configured models, the "kind of swap" conclusions cannot carry the weight the headline puts on them.

**The models.** Per `04_setup.tex:5-6`, Table 1 and `config/models.yaml`, all exist as of Nov 2026 **[asst]**:
- Core pairs: Haiku 4.5→5.5, GPT-5.6-luna→GPT-6-luna, Qwen3.5-27B→Qwen3.8-27B, Gemma 3 27B→Gemma 4 31B.
- Extension pairs (same-maker only): Mistral Small 3→3.2, DeepSeek V4.1-Flash→1017.

**What can be concluded:**
- θ with intervals for each of these 6 same-maker pairs and 48 cross-maker swaps.
- Whether keep beats wipe on these pairs.
- A descriptive same-maker versus cross-maker contrast within this grid.

**What cannot:**
- **A statement about "same-maker upgrades" as a class.**
  - The group holds 6 heterogeneous changes: a version step, a size increase, a minor checkpoint update, a vision
    encoder.
  - Models are fixed effects (`08_limitations.tex:12`).
  - A t(k−2) prediction interval with k = 6 (`05_q1_order.tex:10`) will be very wide.
- **Anything about frontier models.** Every model is a cost tier (Haiku, Luna, a 24–31B open model, a Flash model).
  A Sonnet pair sits in the config as a fallback only.
- **Open versus closed.** Two closed makers against two open makers, confounded with maker, fp8 hosting and
  sampling control.
- **Reasoning-on deployments.** Most agents now run with reasoning on.
- **What "upgrade" means.** Both closed "upgrades" are 2–10 times cheaper than the old model (`config/models.yaml`),
  so "upgrade" mixes newer with smaller or cheaper.
- **Cross-maker swaps as a population.** The 48 swaps rest on 8 models, so the effective number of independent units
  is small.

The abstract's sentence "after same-maker upgrades and less across makers" (`00_abstract.tex:7`, dry-run wording)
will read as general.

**Fix.**
- Make per-pair θ the primary display and keep group values descriptive.
- Add one frontier-tier same-maker pair; the Sonnet 4.6→5.5 pair is already configured.
- Add a reasoning-on sensitivity for one pair.
- Phrase group results as "in these six pairs".

### W6 (MAJOR). Significance rests on research systems, and the transferable part may be "the stored answer is right".

**Who keeps such scores.** The paper is candid that "learned per-item usefulness scores belong to research
memories" (`01_introduction.tex:14`). That matches what was found **[asst]**:
- Of the products checked, only Cognee keeps an outcome-updated per-item weight, and it is off by default
  (`feedback_influence` = 0).
- Mem0 stores feedback labels with no documented ranking use.
- Zep's fact ratings are model-assigned, not learned from outcomes.
- Letta and LangMem keep none.

So the practical audience is research-system builders. The paper under-uses its strongest motivation: MemRL's explicit
portability claim (S1) and the systems that apply "keep" without checking it. Quote them in the introduction.

**What the score may really measure.** In exemplar memory with unlabelled answers, much of a learned score's home
signal may be "this stored answer is correct", or a near-duplicate with the same diagnosis (`05_q1_order.tex:33-37`).
That property is model-independent, so θ would look high for an uninteresting reason. And an operator could replace
the score with a one-time grade of the stored answer whenever labels exist. The registered stored-answer-correct
reference and residualised θ address this, but they are observational (`08_limitations.tex:9`).

**Fix.**
- Pre-state in the paper what result would mean "the learned score carries model-specific usefulness beyond
  correctness".
- Make the residualised θ a co-headline, not an appendix number.

### W7 (MAJOR). As a benchmark contribution it is not yet something others can adopt.

Compared with benchmark papers this track accepts, the following are missing.

**Content.**
- Item and task text ship only as identifiers and hashes until licences "are cleared" (`07_discussion.tex:14`;
  `A3_licences.tex:10`).
- Yet DDXPlus is CC BY 4.0, by the paper's own table, so its text could be released now.
- Rules that read item content, show several items, or call a model cannot be scored offline
  (`docs/BENCHMARK_GUIDE.md`, "What cannot be tested offline").
- The rule space is "choose among 4 fixed candidates with at most 2 checks per cell".

**Governance.**
- "The maintainers" are unnamed (`07_discussion.tex:9`).
- There is no hosting plan, funding, commitment period or stated submission limit; the guide says only that
  maintainers "limit submissions".
- Item 11 of the release checklist (contact, issue tracker) is deferred to camera-ready (`A6_release_checklist.tex:21`).

**Data statement.**
- These are TODO: funding, row counts, collection window and removed tasks (`A2_datasheet.tex:5,7,9,11`), and the
  output terms of Qwen, Gemma and the closed models (`A3_licences.tex:14`).
- There is no machine-readable metadata (for example Croissant, which the bib already contains).

**Held-out handling.**
- The sha256 commitment and yearly replacement are good.
- But by the guide's own text, home rows of the test half can be partly inferred from public score-phase diaries.
- Model names are public inputs, so rules can be tuned to these 8 models.

**Shelf life.**
- Adding one reader costs about 0.2 M calls (`A2_datasheet.tex:17`).
- Closed models will retire (Haiku 4.5 is already past its "not sooner than" date, `04_setup.tex:33`, confirmed
  **[asst]**).
- The board will therefore freeze on the open-weight core within a year.

**Fix.**
- Release DDXPlus text now.
- Name the maintainers, the host, the submission limit and the support period.
- Provide Croissant metadata and complete the datasheet.
- State plainly that the long-lived board is the open-weight grid.

### W8 (MINOR). Presentation: three places where I got lost, and body versus appendix balance.

**Three places I got lost.**
1. **The measures, Sec. 3.2 (`03_benchmark.tex:44-61`).**
   - V, θ, S_m ("freed of outcome noise by multiplying differences measured in two separate sessions"), stakes as a
     square-root ratio, retained order, the identifiability rule and the "home signal too weak" flag arrive in about
     15 lines, with no worked example.
   - I could not tell from the text how θ relates to the success an operator actually gets (see W9).
2. **The statistics paragraph (`03_benchmark.tex:74-80`).** PC1-drop, PC1-MD, PC1-NI and PC2, an intersection-union
   construction with "its linear contrast (drop also beyond the owner's second home session)", "p is the larger of
   the two parts", two-way jackknives and union Fieller sets. In the body this is unreadable; it belongs in App. C,
   with a three-line summary left in the body.
3. **Q3 (`05c_q3_operator.tex:4-14`) and the matching sentence in the introduction (`01_introduction.tex:53`).**
   - "Checks", "tasks of four checks", "the break-even test", "the paired test", "the bound for any rule that checks
     whole tasks drawn at random" and "the fixed audit" appear in quick succession.
   - The operator's actual recommendation sits in an appendix decision table (`07_discussion.tex:17`).

**Move.**
- Out of the body: the sandboxing guarantees (`07_discussion.tex:8-11`, kernel limits and byte-identical reruns),
  into App. B.
- Into the body: one worked example of V and θ for a single task with 4 candidates, and the decision table, since the
  title asks what to do.
- The transfer decomposition sits after the proofs (`main.tex`, `\input{sections/03b_transfer_law}`); it belongs with
  the other secondary results.

**Vocabulary.** Coined terms (owner, reader, home, bank, check, first-shown success, stakes, retained order,
swap-day rule) are each defined. But nine new terms in one page is a lot for a reader from the field; a small glossary
box would help.

### W9 (MINOR). The plain-language reading of θ does not match its definition, and θ scores a different choice from the one deployed.

- `03_benchmark.tex:50` glosses θ as "how much success the old order buys the reader, relative to a random choice
  among the candidates".
- V is a sum over all 6 candidate pairs of signed success differences. That is a pairwise-order statistic, not the
  success of the top-1 choice against a random one.
- θ also uses the score alone, while the deployed choice mixes score and relevance 50/50 (`03_benchmark.tex:10`).
- Fix: state the exact relation, for example "V/6 is the expected success gain of picking the higher-scored of a
  random pair over the lower-scored", and put first-shown success (PC2) beside θ in Figure 1.

### W10 (MINOR). Non-archival and unverifiable sources carry claims in the body.

- A vendor web page with no author or date (SwapBench) is used as evidence in Related Work (`02_related_work.tex:22`).
- Rebuttal content of anonymous submissions under review is used for specific claims: the ledger cites numbers from
  author responses for W5fHCH5rOE and for the reasoning setting. Rebuttals can change or vanish.
- Two withdrawn submissions and one desk-rejected submission appear in the appendix table without their status.
- Fix: keep such sources out of the body, or mark their status in the text.

### W11 (MINOR). Formatting and policy points I could verify.

- **Page limit: OK.** The body ends on page 8, within the "8 pages for the main paper" (CFP, opened). Accessibility
  and Software and Data sit on pages 8–9. The CFP exempts only "references, the impact statement, and appendices"
  and the AI Disclosure Statement, so check whether these two count.
- **Anonymity: OK.** I saw no identifying URL, acknowledgement or self-citation.
- **AI Disclosure Statement: incomplete.** It carries a TODO for the tools and versions (`92_ai_use_statement.tex:5`).
  The anonymous code link is a TODO (`91_software_data.tex:3`).
- **Placeholder abstract:** the CFP removal risk is under W1.

---

## Questions for the authors

1. How does θ for `beta_grade` or `ema_grade` compare with Chang & Jia's cross-model Pearson correlations of CondAcc
   (0.15–0.46 across makers, 0.42–0.76 within OPT)? Will you report a correlation-type statistic so the two can be
   compared?
2. Your ledger notes Chang & Jia's cross-model figures. Why is the paper not cited in the body, given the claim at
   `01_introduction.tex:35`?
3. What share of the home signal do you expect "the stored answer is correct" to explain? What θ for the residualised
   score would you call evidence of model-specific usefulness?
4. If most agent-leg pairs come out "uninformative" (likely, given a 5-point detectable effect against a 2.6-point
   total MemRL gain), what will the paper say about agent memory? Will you run the one-memory probe?
5. Why is reasoning switched off, when agent deployments mostly run with it on? Is there a sensitivity check?
6. Who maintains the hidden test half, where is it hosted, for how long, and with what submission limit?
7. DDXPlus is CC BY 4.0. Why is its task text withheld?
8. For `02_related_work.tex:24`: which statements rest on author responses rather than abstracts? Can they be removed?
9. If the pilot gate fails (home Cw < 0.58), the pre-registration stops the study (`PREREGISTRATION.md`, Part 9.4).
   Would you then submit a negative-results paper? The CFP lists "Negative Results" as a contribution type.
10. In the closed "upgrades" the new model is much cheaper than the old (Haiku 5.5 costs a tenth of Haiku 4.5).
    How will you separate "newer" from "smaller"?

---

## Closest prior and concurrent work

| Work | Link | What it measured | Overlap with this paper | Cited? | Described correctly? |
|---|---|---|---|---|---|
| Chang & Jia 2023 (ACL) | https://aclanthology.org/2023.acl-long.452/ | Pearson r of per-example CondAcc scores (outcome-based usefulness) between GPT-J, OPT-6.7B and OPT-13B; overlap of stable subsets | High for Q1: same object type, content fixed, cross-maker vs same-family; no noise reference, no rules | In bib, **not in body** | n/a |
| Nguyen & Wong 2023 | https://arxiv.org/abs/2302.11042 | Overlap of top and bottom in-context influence examples across 7 LLMs: ≤4 across families, "decent" within | High for Q1 (with-minus-without score); overlap only | In bib, **not in body** | n/a |
| Yang, Chowdhury, Yan, Thakur 2026 | https://arxiv.org/abs/2611.03930 | Fixed agent memories; per memory–task utility labels; second reader κ = 0.58 over 275 cells | Close and concurrent: agent memory, cross-reader agreement; paired labels, not learned scores | No | n/a |
| Policy-Response Drift (ICLR 2027, withdrawn) | https://openreview.net/forum?id=6YeGSweiCZ | Per-card memory effects re-estimated under a successor policy (two Qwen updates) with purchased tasks and a non-inferiority margin | Close to (iii) for agent memory | Appendix table only | Partly ("item-level rank: no" understates it) |
| Beyond Gain (Wang et al. 2026) | https://arxiv.org/abs/2610.32322 | Per-skill verdict flips 14–23% between 4 models; skill×model variance share; resampling noise floor | Partial: per-item transfer with a noise reference, measured not learned | Yes | Body sentence wrong (W3.1); App. H right |
| CompSkill (Shen et al. 2026) | https://arxiv.org/abs/2611.01115 | Reuses per-skill utility offsets across executor version changes; task success and 88% same outcome | Close: the "keep" rule for learned per-item scores, same maker | Yes | Correct |
| MemRL (Zhang et al. 2026) | https://arxiv.org/abs/2601.03192 | Q-scored bank moved from Gemini-3-pro to 3 models; end-task only; claims utility "generalizes" | Motivating claim the paper tests | Yes | Transfer correct; update rule wrong (W3.5) |
| LLM-specific utility (Zhang et al., CIKM 2026) | https://arxiv.org/abs/2510.11358 | Passage utility per LLM; swaps passage sets across LLMs; overlap counts | Partial (RAG passages) | Yes | Wrong in App. D (W3.2) |
| SkillEval (Han et al. 2026) | https://arxiv.org/abs/2608.06891 | Concordance 0.724 of per-task skill uplift across 18 executors | Partial | Yes | Correct |
| Selection via Proxy (ICLR 2020) | https://arxiv.org/abs/1906.11829 | Cross-model rank correlation of per-example selection scores against a same-model run-to-run reference | Partial; has the noise reference the novelty claim says is missing | Yes | Under-described |
| Ethayarajh et al. 2022 (ICML) | https://arxiv.org/abs/2110.08420 | Cross-model correlation of per-instance PVI beside cross-seed correlation | Partial (training data) | No | n/a |
| Superfiltering (ACL 2024); Mekala et al. (Findings ACL 2024) | https://aclanthology.org/2024.acl-long.769/ ; https://aclanthology.org/2024.findings-acl.623/ | Rank survival (Spearman, Kendall) and top-k overlap of per-sample scores across model sizes | Partial | No | n/a |
| Judge replacement (ICLR 2027, desk-rejected) | https://openreview.net/forum?id=fmDOTwVZes | Keep vs rescore vs audit after a judge swap; audit-budget frontier | Close to (iii), for judges | Yes | Status wrong in text (W3.4) |
| HEIRS (ICLR 2027 submission) | https://openreview.net/forum?id=Ds8Nz1GuuQ | Re-test archived skill versions on the new executor | Partial (retest_k) | Yes | Correct |
| Statistical Rank Transport (ICLR 2027 submission) | https://openreview.net/forum?id=gxTTerbmox | Cached scores stale after a model update; monotone old→new map from a small sample; rescore one block | Methodological analogue of recal_k / retest_k | No | n/a |
| Certified Reuse or Recalibration of LLM Judges (ICLR 2027 submission) | https://openreview.net/forum?id=Lm5VaLpqlE | Reuse vs recalibrate as a finite-sample decision with an audit | Analogue of the swap-day decision | No | n/a |
| Goyal & Ray 2026 | https://arxiv.org/abs/2609.05339 | Memory portability by format; aggregate; 20-probe check ρ = 0.86 | Partial (whole memory, not per item) | Yes | Correct |
| SwapBench (ZenML web page) | https://www.zenml.io/benchmarks/swapbench | Cheap checks for whole-agent model swaps | Tangential (whole agents) | Yes | Mostly correct (W3.8) |
| Skill-Pro (arXiv 2602.01869); XferAgent (arXiv 2610.19581) | https://arxiv.org/abs/2602.01869 ; https://arxiv.org/abs/2610.19581 | Carry outcome-learned per-skill or per-experience scores to other backbones (keep; shrinkage prior) without checking rank | Motivation: "keep" applied silently | No | n/a (not opened by me) |

---

## Every sentence about prior work that was checked

Verdicts: **C** correct, **I** inaccurate, **N** could not verify. [me] = I opened the source; [asst] = a briefed
assistant opened it and returned the deciding quote.

| # | File:line | Sentence (short) | Verdict | Note |
|---|---|---|---|---|
| 1 | 01_introduction.tex:13 | MemRL and CHIME rank by learned values | C [me/asst] | MemRL Eq. 7; CHIME Eq. 5 |
| 2 | 01_introduction.tex:13 | RoMeRL and MemQ learn them from rewards | C [asst] | |
| 3 | 01_introduction.tex:13 | EvolveR prunes items below a threshold | C [asst] | θ_prune = 0.3; score (s+1)/(n+2) |
| 4 | 01_introduction.tex:13 | ACE keeps helpful/harmful counters | C [asst] | |
| 5 | 01_introduction.tex:14 | Generative Agents' importance is a write-time model rating | C [asst] | |
| 6 | 01_introduction.tex:15 | Anthropic: "at least 60 days' notice" | C [asst] | Verbatim |
| 7 | 01_introduction.tex:33 | Systems that move a scored memory report end-task success | C [asst] | Incomplete: ExpHarness also moves a scored graph |
| 8 | 01_introduction.tex:34 | SkillEval concordance 0.724 across 18 executors | C [asst] | App. F |
| 9 | 01_introduction.tex:34 | RAG passages useful to one model often not to another | C [me] | |
| 10 | 01_introduction.tex:34 | In-context examples partly model-specific | C [asst] | Peng's evidence is one qualitative reversal |
| 11 | 01_introduction.tex:35 | "What has not been measured ..." | I [me] | W2 |
| 12 | 01_introduction.tex:41 | StreamBench memory "without its correctness feedback" | C [asst] | StreamBench stores only ground-truth-correct outputs |
| 13 | 01_introduction.tex:41 | Shared memory of three makers' models helps on both streams | C [asst] | vs the average; BIRD +1.07 only |
| 14 | 02_related_work.tex:6 | Learned values / success counts / counters / credit / uplift systems | C [asst] | ExpHarness reward is not pure with-minus-without |
| 15 | 02_related_work.tex:6 | Generative Agents: recency, relevance, importance | C [asst] | |
| 16 | 02_related_work.tex:7 | Values from retrieval logs can be undetermined | C [asst] | |
| 17 | 02_related_work.tex:7 | Self-assessed scores inflate wrong episodes | C [asst] | |
| 18 | 02_related_work.tex:10 | StreamBench DDXPlus 83.5 vs 70.6 | C [asst] | Table 2 |
| 19 | 02_related_work.tex:11 | Moved memory helps against none (5 works) | C [asst] | |
| 20 | 02_related_work.tex:11 | Own memory tends to win (Kim et al.) | C [asst] | Tie for Qwen3-Coder |
| 21 | 02_related_work.tex:11 | Naive transfer can hurt (MemCollab) | C [asst] | |
| 22 | 02_related_work.tex:11 | Memory formats port differently (Goyal & Ray) | C [asst] | |
| 23 | 02_related_work.tex:11 | Rewritten per reader (Rosetta); needs an aligned reader | C [asst] | |
| 24 | 02_related_work.tex:12 | CHIME quote "encodes reusable guidance ..." | C [asst] | Verbatim |
| 25 | 02_related_work.tex:12 | CompSkill reuses per-skill offsets across a version change | C [asst] | |
| 26 | 02_related_work.tex:13 | Skill effects depend on the backbone (MASA, AFTER, SkillRevise) | C [asst] | AFTER's transfer example is across roles |
| 27 | 02_related_work.tex:13 | "verdicts flipping ... 14–23% of skills" as skill effects | I [asst] | W3.1 |
| 28 | 02_related_work.tex:13 | Carried history passes on habits | C [asst] | |
| 29 | 02_related_work.tex:16 | Example value model-specific; small-model policy helps larger ones less | C [asst] | |
| 30 | 02_related_work.tex:16 | Retrievers chosen with one model's feedback help others | C [asst] | |
| 31 | 02_related_work.tex:17 | Anchor Points, tinyBenchmarks, PromptBridge, SVP, Small-to-Large | C [asst] | SVP's run-to-run reference omitted |
| 32 | 02_related_work.tex:18 | "None of these measures ..." | I [asst/me] | SVP has the noise reference; W2 |
| 33 | 02_related_work.tex:21 | Swap-day decision studied for judges, adapters, hand-offs, updates | C [asst] | |
| 34 | 02_related_work.tex:22 | SwapBench numbers | C in part [me] | "Half" holds at 260 scenarios only; vendor page |
| 35 | 02_related_work.tex:22 | Goyal & Ray: 20 probes ρ = 0.86, "too large for final approval" | C [asst] | Verbatim |
| 36 | 02_related_work.tex:24 | "three submissions under review" | I [me] | fmDOTwVZes desk-rejected |
| 37 | 02_related_work.tex:24 | Own/pooled/donor credit (Beyond Semantic Relevance) | N [me] | Abstract silent; wording matches wSdg23aQOr |
| 38 | 02_related_work.tex:24 | HEIRS re-tests archived versions | C [me] | |
| 39 | 02_related_work.tex:24 | Judge paper: keep, rescore or audit | C [me] | |
| 40 | 02_related_work.tex:25 | Anytime-valid tests in evaluation and agent gates | C [asst] | Skill-lifecycle is a NeurIPS workshop paper (bib correct) |
| 41 | 03_benchmark.tex:18 | `ema_grade` = MemRL's rule from q = 0.5; config "same start and rewards" | I [me] | W3.5 |
| 42 | 03_benchmark.tex:19 | ACE counters; ranking by them is our choice | C [asst] | |
| 43 | 04_setup.tex:8 | Reasoning off, cited to anon2026execrecords | N [me] | W3.6 |
| 44 | 04_setup.tex:25 | Mistral Small 3→3.2 "adds a vision encoder" | C [asst] | Vision arrived in 3.1 |
| 45 | 04_setup.tex:33 | Haiku 4.5 past its "not sooner than" date | C [asst] | 15 Oct 2026 |
| 46 | 06_agent_leg.tex:6 | Up to 15 turns, shown 5 of up to 10 | C in part [asst] | 5 of 10 from MemRL Table 8; 15 turns from MemRL's config, not the LLB paper |
| 47 | 06_agent_leg.tex:7 | 10 passes over 350 tasks; 0/1 rewards | C in part [me/asst] | 0/1 is the config; the paper says [−1, 1] |
| 48 | 06_agent_leg.tex:10 | MemRL credits every shown memory | C [asst] | Sec. 4.3 |
| 49 | 06_agent_leg.tex:19 | MemRL's gain about 3 points, 2.6 on OS | C [asst] | 0.746 vs 0.720 |
| 50 | A10_related_table.tex:50 | MemRL "fully trained"; RoMeRL "frozen memory state" | C [me/asst] | Verbatim |
| 51 | A10_related_table.tex:51 | CHIME does not say whether values travel | C [asst] | Eq. 3 includes values, so they most likely travel |
| 52 | A10_related_table.tex:52 | EPR and LLM-R move labels in distilled form | C [asst] | |
| 53 | A10_related_table.tex:59 | SkillEval appendix, margin 0.333 | C [asst] | |
| 54 | A10_related_table.tex:60 | LLM-utility "without a swap or an order measure" | I [me] | W3.2 |
| 55 | A10_related_table.tex:61 | Peng and MDR find learned policy weaker on larger models | I [asst] | W3.3 |
| 56 | A10_related_table.tex:62-64 | CompSkill, UpgradeBench, SwapBench | C [asst] | |
| 57 | A10_related_table.tex:65 | EPR "similar gains" on larger models | C in part [asst] | About half on Codex |
| 58 | A10_related_table.tex:66 | LLM-R consistent gains | C in part [asst] | +0.4 on GPT-3.5 |
| 59 | A10_related_table.tex:67-68 | SVP; Small-to-Large | C [asst] | |
| 60 | A10_related_table.tex:69 | MUSCLE | C [asst] | Setting is a base model with adapters |
| 61 | A10_related_table.tex:70-72 | Old Habits; switch matrix ~70%; MASA | C [asst] | |
| 62 | A10_related_table.tex:73 | AFTER | C [asst] | AFTER is the benchmark's name |
| 63 | A10_related_table.tex:74 | Judge Version Shift | C [asst] | |
| 64 | A10_related_table.tex:75 | Reward inflation incl. BIRD | C [asst] | |
| 65 | A10_related_table.tex:76 | ERRAND | C [asst] | |
| 66 | A10_related_table.tex:77 | Stale skills "repairs them by replaying checks" | I [asst] | W3.7 |
| 67 | A10_related_table.tex:78-79 | Rosetta; Learning on the Job | C [asst] | |
| 68 | A10_related_table.tex:25 | Policy-Response Drift row ("item-level rank: no") | I in part [me] | Also withdrawn, which is not shown |
| 69 | A11_outside_check.tex:7,14,30 | Beyond Gain: 1,251 skills, 4 open models, Qwen3.6 adversarial target and judge, 14–23% unaided flips | C [asst] | |

**References I could not find: none.** All works cited in the sections above resolve to the stated record, and I
found no hallucinated reference. Minor metadata points:
- The MemRL author order differs between arXiv and the NeurIPS page (the ledger already flags this).
- The author names of the withdrawn Policy-Response Drift submission are not shown in the public metadata I could
  read. The bib lists three authors; please confirm on the forum.

---

## Scores

| | Score |
|---|---|
| Soundness | **2** (fair): careful design and statistics, but no evidence yet, and several descriptions of prior work are wrong |
| Presentation | **2** (fair): meticulous, but dense; the measures, statistics and Q3 are hard to follow in one pass |
| Significance | **2** (fair): narrow setting; the practical audience is research memories; the benchmark is not yet adoptable |
| Originality | **2** (fair): new framing and swap-day economics, but the core measurement has 2022–2023 precedents and close 2026 concurrent work |
| Confidence | **4** |

**Overall (1–6):**
- **(a) The submission as it stands today (placeholders, no real data): 1, strong reject.** This is a judgement of
  completeness, not of the design: the paper's question is not answered anywhere in it, and the ICML 2027 CFP's
  placeholder-abstract rule applies.
- **(b) If the real results show the dry-run pattern: 3, weak reject as written; 4 once W2–W3 are fixed.** The
  dry-run pattern is: same-maker θ ≈ 0.73 with an interval reaching 0.47–1.08; cross-maker ≈ 0.20; keep minus wipe
  about 9 points at home and about 1.5 points after a cross-maker swap; about 280 checks for break-even; 260 or more
  tasks for the 0.75 question. That would be a clean, useful, honest measurement. But the novelty must be repositioned
  against Chang & Jia and the others, the misdescriptions fixed, and the title scoped, and the agent leg would still
  likely be uninformative.
- **(c) If the real results show no usable signal even at home: 2, reject.** θ has no denominator, the primary tests
  are uninformative, and the boards would rank noise. Reframed as a negative result ("outcome-learned scores do not
  rank exemplars even for their own model"), it could fit the CFP's Negative Results type, but that is a different
  paper.

---

## What would move my score up by one

1. **Real confirmatory results.** Run at least the full grid on both streams with the self-swap reference and the
   shuffled control, analysed from the frozen pre-registration, with the anonymous registry link. Without this,
   nothing else matters.
2. **Honest novelty.**
   - Cite and describe Chang & Jia 2023, Nguyen & Wong 2023, SVP's run-to-run reference, Ethayarajh et al. 2022,
     Yang et al. 2026 and Policy-Response Drift in the body.
   - Rewrite `01_introduction.tex:35` and `02_related_work.tex:18` to name the real difference.
   - Report one correlation-type statistic so θ can be compared with the 2023 numbers.
3. **Fix every inaccurate sentence in W3.** Drop claims that rest on author responses, and label the vendor page as
   such.
4. **Scope the title and the agent leg.** Scope the title to exemplar memory. Either run the agent leg with enough
   power (the one-memory probe) or state in the abstract that it can only detect effects of about 5 points.
5. **One stronger pair and one reasoning-on check.** Add a frontier-tier same-maker pair (Sonnet 4.6→5.5 is already
   configured) and a reasoning-on sensitivity check, and make per-pair θ the primary display.
6. **Make the benchmark adoptable.** Release DDXPlus text now, add Croissant metadata, name the maintainers, host,
   submission limit and support period, and complete the datasheet.
