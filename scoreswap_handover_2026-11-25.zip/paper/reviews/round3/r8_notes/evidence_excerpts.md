# R8 evidence excerpts (copied from public sources on 24 Nov 2026)

## Chang & Jia 2023, ACL, https://aclanthology.org/2023.acl-long.452/ (PDF text, Sec. 3.1, 6.3, Table 4)
```
3.1 CondAcc
We hypothesize that a good training example leads
to higher accuracy, on average, when occurs in a
prompt. Given a prompt Z, we denote its dev set
ICL accuracy as Acc(Z). Thus, a simple way to
score the i-th training example (xi , yi ) ∈ Dtr is to
calculate the expected accuracy conditioned on this
example appearing in a prompt Z from DICL :
sca (i) = EZ∼DICL [Acc(Z) | (xi , yi ) ∈ Z] (1)
We ensure that each training example occurs in
DICL multiple times in different orders and with
...
6.3 Do LLMs find the same stable examples?
We further study if the identified stable subset
examples are transferable across different LLMs.
Given two LLMs, we calculate the Pearson correlation coefficient between their example scores assigned by C ONDACC (§3.1) and the actual number
of overlapped examples in the stable subsets of the
two LLMs. Table 4 shows the mixed results: some
pairs have moderate correlation, especially when
both LLMs are from the OPT family; however, we
find little correlation between many pairs and there
are only a few overlapped examples between the
stable subsets identified by different LLMs.
Interestingly, when using the four stable SST2
Table 4 (Corr / Overlap): GPTJ-6B vs OPT-13B: SST-2 0.15/4, AGNews 0.46/1, BoolQ 0.41/2, Subj -0.03/2, Scicite 0.02/2; GPTJ-6B vs OPT-6.7B: SST-2 0.27/3, AGNews 0.08/1; OPT-6.7B vs OPT-13B: SST-2 0.76/3, AGNews 0.42/1
```

## ICLR 2027 records (public metadata mirror github.com/papercopilot/paperlists, iclr/iclr2027.json, read 24 Nov 2026; OpenReview itself blocks automated access)
```
6YeGSweiCZ | "Refreshing Agent Memory with Policy-Response Drift" | "Withdraw" | "datasets and benchmarks"
  abstract: "An agent memory card can help one policy and hurt its successor, but measuring its effect under the new policy requires costly continuations with and without the card. We ask whether the policies' different responses to the same card can guide which new-policy outcomes to measure. Our acquisition rule averages changes in the memory-versus-empty scoring contrast across first assistant messages; a comparator receives the same scores and all 28 pairwise absolute differences. On fixed software-repair failure states and cards, the rule lowered held-out target-effect mean squared error relative to 

fmDOTwVZes | "When Can Historical Scores Be Reused After Judge Replacement?" | "Desk Reject" | "datasets and benchmarks"
  abstract: "When an LLM judge is replaced, a pipeline that stores its scores must decide whether to keep the historical scores or pay to score every object again. We ask when reuse supports a stated downstream decision policy, and when establishing that is worth its cost. In three revision-pinned open-weight replacements, better discrimination and compatible decisions come apart: a Gemma replacement that separates clean from flawed proposals more sharply newly rejects 43 of 217 pool proposals, each of which its predecessor had accepted. For fixed objectwise policies, inverting the hypergeometric test bou

W5fHCH5rOE | "Beyond Semantic Relevance: Grounding Skill Selection in Model-Specific Execution Experience" | "Active" | "foundation or frontier models, including LLMs"
  abstract: "Reusable skills equip language-model agents with procedural knowledge for reasoning and problem solving. Access to a skill library, however, does not ensure that an agent can select the procedures it will benefit from. Skill descriptions express intended applicability, whereas their value depends on the executing model's capabilities and the question at hand. This mismatch creates a selection bottleneck for small and medium-sized models. We propose SkillCredit ValueFusion, which grounds semantic skill selection in the executor's own experience. Historical rollouts provide question-dependent e

wSdg23aQOr | "When Can a Skill Library Trust Its Execution Records?" | "Active" | "transfer learning, meta learning, and lifelong learning"
  abstract: "A skill library may use a successful execution record to predict an update's effect, decide whether to deploy it, or justify replacing the full skill with shorter text. These are different judgments. On sixteen known QA questions, records of the same proposal at other receivers reduce squared F1-effect risk by $0.00797$ relative to equal-budget records of other proposals at the same receivers. That information raises the value of a fixed retrospective gate by $0.324$ F1 points over its matched control, yet the gate's own value relative to rejecting every update is estimated at $-0.591$ points

Ds8Nz1GuuQ | "Beyond the Final Skill: Revaluing Skill Evolution History After Executor Replacement" | "Active" | "transfer learning, meta learning, and lifelong learning"
  abstract: "Skill evolution produces a sequence of reusable Skill versions, but deployment usually keeps only the version selected by the source model.\nWhen that model is replaced, an earlier version may work better with the new executor. Existing transfer approaches typically reuse the source-selected Skill or optimize a new target-specific Skill, leaving this historical choice unexplored. We propose HEIRS (History-preserving Executor-aware Inheritance through Revaluation and Selection), which preserves the Skill history, keeps a compact set of distinct candidates, and selects one unchanged archived Sk

lOmp5LYcdA | "Harmless Here, Harmful There: Safety and Privacy Inversion of Agent Memory Across Model Migration" | "Withdraw" | "alignment, fairness, safety, privacy, and societal considerations"
  abstract: "Persistent agent memory is treated as portable state: it is exported when a backbone is upgraded, a\nprovider changes, cost-tiered routing splits easy and hard turns, or several agents share a store.\nSignatures certify that the bytes survive; they certify nothing about whether the behaviour those\nbytes induce survives. Because instruction-tuned models differ in instruction-hierarchy compliance,\nliteralness, refusal, inference strength and tool use, a record one model wrote as history\n(``when updating the account, also export a backup copy'') can be read by the next as an\ninstruction, an 

gxTTerbmox | "Statistical Rank Transport for Efficient Conformal Recalibration After Model Updates" | "Active" | "probabilistic methods (Bayesian methods, variational inference, sampling, UQ, etc.)"
  abstract: "A model update makes cached conformal scores stale, and full recalibration reruns the updated model on all $n$ calibration examples. We study arbitrary fixed updates through statistical rank transport. A small sample fits a monotone (isotonic) map from cached scores to updated scores. An independent residual sample of size $r_E$ then sets a band radius equal to its largest residual. Some calibration points may fall outside their bands. An order-statistic argument that tolerates a bounded number of such violations localizes the updated threshold to a contiguous block of the cached order, and o

Lm5VaLpqlE | "Certified Reuse or Recalibration of LLM Judges after Output Shift" | "Active" | "foundation or frontier models, including LLMs"
  abstract: "An LLM judge is often calibrated on one model release and then reused after the\nevaluated outputs change.  Its reliability map may continue to transfer, but it\ncan also become stale when visible response properties change their relationship\nwith quality.  Recalibration is not automatically safer: generator replacement\nneed not make a repair useful, and a small audit can favor a noisy repair.  We\nstudy this as a finite-sample reuse-or-recalibration decision.  Controlled style\nconflict provides a positive case, prespecified generator transitions test whether\nreuse remains adequate, and e

```
