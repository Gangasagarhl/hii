# eb_slope_shrink: swap-day rule at budget k = 16

**Tasks scored: the DEV half of the evaluation tasks, which is public. You may have tuned on it, and a rule can memorise it, so this is a development number, not a ranking. The board ranks on the held-out TEST half, scored by the maintainers from your entry file.**

Scored from the frozen tables of study `sim` with no model call (pack fingerprint `c209acb9e99a07ef`). Each value is a mean over the evaluation tasks; 200 seeded draw(s), each task's value the mean over the draws. Differences use the same tasks and the same draws.

Brackets: 95 % intervals. Two-way = tasks and tips both treated as sampled: msr.metrics.robust_variance, the delete-one-cluster jackknife over task ids and tips (a tip that recurs in several stream orders is one cluster; the primary interval). Theta's bracket is the union of its two-way and task-only Fieller sets (msr.metrics.theta_tests). Task-only = the task-id cluster bootstrap, 10,000 draws, seed 0 (secondary; the paper's tables of rule values use this one, so on all evaluation tasks they match it digit for digit).

First-shown success: the reader's success with the candidate the rule shows first (higher is better). Regret: the gap to the task's best candidate (lower is better). Theta: the share of the owner's home ranking signal (its `ema_grade` score with its own results) that the rule's order keeps for the reader; at a home cell the reader is the owner itself with the same results, so keep's theta there is exactly 1. Theta = order x stakes; order is 'not identifiable' where the reader's spread cannot be told from zero, and theta reads 'no home signal' where the owner's score has no ranking signal on its calibration tasks (msr.metrics.home_signal_flag).

- Run sealed: one fresh process per call, forked from a launcher that never runs the entry.
- landlock: ABI 7: read-only access to 7 folder(s) and file(s); no writes, no execution; no TCP; signals and abstract sockets scoped
- seccomp: no threads; no pipes, sockets, IPC, shared memory, key rings, ptrace, exec, xattrs or file metadata changes

## By kind of swap, dev half (public) (ddxplus)

| kind | first-shown success | minus keep | minus wipe | minus fixed_0.5 | minus powerprior_16 | minus recal_16 | minus retest_16 | minus audit_16 | regret | log score (level-corrected) | theta | order | checks used |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| same-maker upgrades | 0.676 [0.578, 0.774] (task-only [0.603, 0.746]) | -0.012 [-0.033, 0.010] | 0.029 [-0.023, 0.081] | -0.007 [-0.026, 0.011] | -0.003 [-0.036, 0.030] | 0.009 [-0.005, 0.023] | 0.001 [-0.053, 0.055] | 0.003 [-0.012, 0.019] | 0.186 | -0.706 [-0.758, -0.653] | 0.698 [0.448, 1.090] | 1.03 [0.62, 3.03] | 16.0 |
| same-maker downgrades | 0.561 [0.472, 0.649] (task-only [0.495, 0.627]) | 0.007 [-0.029, 0.044] | 0.039 [-0.016, 0.093] | -0.015 [-0.052, 0.022] | 0.023 [-0.011, 0.058] | 0.016 [-0.006, 0.038] | 0.047 [-0.023, 0.118] | 0.018 [-0.009, 0.045] | 0.261 | -0.697 [-0.735, -0.658] | 0.665 [0.356, 1.411] | 0.78 [0.43, 2.07] | 16.0 |
| cross-maker swaps | 0.570 [0.513, 0.626] (task-only [0.515, 0.623]) | 0.007 [-0.023, 0.038] | 0.029 [-0.007, 0.065] | 0.008 [-0.015, 0.031] | 0.028 [0.006, 0.049] | 0.019 [0.001, 0.037] | 0.013 [-0.019, 0.044] | 0.017 [0.001, 0.033] | 0.278 | -0.720 [-0.737, -0.703] | 0.244 [0.078, 0.440] | 0.28 [0.10, 0.49] | 16.0 |
| home cells (each owner reading its own bank) | 0.655 [0.594, 0.717] (task-only [0.602, 0.707]) | -0.023 [-0.047, 0.000] | 0.071 [0.018, 0.123] | -0.014 [-0.030, 0.002] | -0.010 [-0.039, 0.020] | 0.003 [-0.010, 0.016] | 0.017 [-0.017, 0.051] | -0.003 [-0.015, 0.010] | 0.208 | -0.694 [-0.723, -0.664] | 0.924 [0.869, 1.004] | 0.88 [0.73, 1.09] | 16.0 |

### Every ordered pair, dev half (public)

| owner -> reader | kind | first-shown success | minus keep | minus wipe | regret | theta |
|---|---|---|---|---|---|---|
| sim-a-old -> sim-a-old | home | 0.616 [0.522, 0.710] | -0.009 | 0.134 | 0.179 | 0.92 |
| sim-a-old -> sim-a-new | same_maker_upgrade | 0.695 [0.548, 0.841] | -0.028 | 0.043 | 0.189 | 0.56 |
| sim-a-old -> sim-b-old | cross_maker | 0.522 [0.439, 0.605] | 0.013 | 0.031 | 0.318 | 0.18 |
| sim-a-old -> sim-b-new | cross_maker | 0.611 [0.512, 0.709] | 0.013 | -0.032 | 0.273 | 0.03 |
| sim-a-new -> sim-a-old | same_maker_downgrade | 0.609 [0.514, 0.704] | -0.007 | 0.055 | 0.266 | 1.13 |
| sim-a-new -> sim-a-new | home | 0.685 [0.578, 0.792] | -0.021 | -0.021 | 0.217 | 1.02 |
| sim-a-new -> sim-b-old | cross_maker | 0.493 [0.399, 0.586] | 0.002 | 0.082 | 0.257 | 0.63 |
| sim-a-new -> sim-b-new | cross_maker | 0.627 [0.545, 0.709] | 0.020 | 0.011 | 0.221 | 0.48 |
| sim-b-old -> sim-a-old | cross_maker | 0.566 [0.446, 0.686] | 0.012 | 0.030 | 0.300 | 0.31 |
| sim-b-old -> sim-a-new | cross_maker | 0.594 [0.459, 0.729] | -0.031 | 0.049 | 0.272 | 0.13 |
| sim-b-old -> sim-b-old | home | 0.611 [0.475, 0.747] | -0.023 | 0.066 | 0.238 | 0.92 |
| sim-b-old -> sim-b-new | same_maker_upgrade | 0.657 [0.547, 0.766] | 0.005 | 0.014 | 0.182 | 0.81 |
| sim-b-new -> sim-a-old | cross_maker | 0.531 [0.427, 0.635] | -0.005 | 0.022 | 0.317 | 0.17 |
| sim-b-new -> sim-a-new | cross_maker | 0.613 [0.513, 0.714] | 0.033 | 0.042 | 0.262 | 0.21 |
| sim-b-new -> sim-b-old | same_maker_downgrade | 0.513 [0.376, 0.650] | 0.022 | 0.022 | 0.255 | 0.38 |
| sim-b-new -> sim-b-new | home | 0.710 [0.626, 0.795] | -0.040 | 0.103 | 0.200 | 0.87 |

Per-stream values, the Brier scores, the uncorrected log score, Cw, both intervals of every number and the paper's rules' own values are in summary.csv and compare.csv; one row per cell is in cells.csv.
