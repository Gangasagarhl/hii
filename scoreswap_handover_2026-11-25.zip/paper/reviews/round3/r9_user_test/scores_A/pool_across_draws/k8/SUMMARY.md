# pool_across_draws: swap-day rule at budget k = 8

**Tasks scored: the DEV half of the evaluation tasks, which is public. You may have tuned on it, and a rule can memorise it, so this is a development number, not a ranking. The board ranks on the held-out TEST half, scored by the maintainers from your entry file.**

Scored from the frozen tables of study `sim` with no model call (pack fingerprint `c209acb9e99a07ef`). Each value is a mean over the evaluation tasks; 200 seeded draw(s), each task's value the mean over the draws. Differences use the same tasks and the same draws.

Brackets: 95 % intervals. Two-way = tasks and tips both treated as sampled: msr.metrics.robust_variance, the delete-one-cluster jackknife over task ids and tips (a tip that recurs in several stream orders is one cluster; the primary interval). Theta's bracket is the union of its two-way and task-only Fieller sets (msr.metrics.theta_tests). Task-only = the task-id cluster bootstrap, 10,000 draws, seed 0 (secondary; the paper's tables of rule values use this one, so on all evaluation tasks they match it digit for digit).

First-shown success: the reader's success with the candidate the rule shows first (higher is better). Regret: the gap to the task's best candidate (lower is better). Theta: the share of the owner's home ranking signal (its `ema_grade` score with its own results) that the rule's order keeps for the reader; at a home cell the reader is the owner itself with the same results, so keep's theta there is exactly 1. Theta = order x stakes; order is 'not identifiable' where the reader's spread cannot be told from zero, and theta reads 'no home signal' where the owner's score has no ranking signal on its calibration tasks (msr.metrics.home_signal_flag).

- Run sealed: one fresh process per call, forked from a launcher that never runs the entry.
- landlock: ABI 7: read-only access to 7 folder(s) and file(s); no writes, no execution; no TCP; signals and abstract sockets scoped
- seccomp: no threads; no pipes, sockets, IPC, shared memory, key rings, ptrace, exec, xattrs or file metadata changes

## By kind of swap, dev half (public) (ddxplus)

| kind | first-shown success | minus keep | minus wipe | minus fixed_0.5 | minus powerprior_8 | minus recal_8 | minus retest_8 | minus audit_8 | regret | log score (level-corrected) | theta | order | checks used |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| same-maker upgrades | 0.698 [0.600, 0.797] (task-only [0.621, 0.773]) | 0.011 [-0.022, 0.043] | 0.051 [-0.008, 0.110] | 0.015 [-0.017, 0.048] | 0.022 [-0.014, 0.059] | 0.034 [0.009, 0.060] | 0.013 [-0.041, 0.068] | 0.026 [-0.001, 0.054] | 0.163 | -0.762 [-0.833, -0.691] | 0.774 [0.477, 1.225] | 1.14 [0.61, 3.72] | 8.0 |
| same-maker downgrades | 0.579 [0.503, 0.654] (task-only [0.507, 0.649]) | 0.025 [-0.044, 0.094] | 0.056 [-0.022, 0.134] | 0.003 [-0.064, 0.069] | 0.040 [-0.017, 0.096] | 0.039 [-0.021, 0.098] | 0.067 [-0.011, 0.146] | 0.037 [-0.023, 0.098] | 0.243 | -0.734 [-0.808, -0.660] | 0.756 [0.386, 1.520] | 0.89 [0.50, 2.12] | 8.0 |
| cross-maker swaps | 0.606 [0.549, 0.663] (task-only [0.550, 0.662]) | 0.044 [0.009, 0.078] | 0.066 [0.016, 0.116] | 0.045 [0.017, 0.072] | 0.064 [0.030, 0.099] | 0.055 [0.029, 0.081] | 0.057 [0.008, 0.105] | 0.054 [0.024, 0.083] | 0.241 | -0.789 [-0.847, -0.730] | 0.442 [0.193, 0.735] | 0.51 [0.25, 0.82] | 8.0 |
| home cells (each owner reading its own bank) | 0.673 [0.608, 0.739] (task-only [0.616, 0.729]) | -0.005 [-0.046, 0.036] | 0.089 [0.038, 0.140] | 0.004 [-0.029, 0.037] | 0.015 [-0.019, 0.048] | 0.029 [-0.003, 0.060] | 0.049 [0.010, 0.088] | 0.023 [-0.005, 0.051] | 0.190 | -0.721 [-0.765, -0.678] | 1.150 [0.991, 1.423] | 1.09 [0.90, 1.44] | 8.0 |

### Every ordered pair, dev half (public)

| owner -> reader | kind | first-shown success | minus keep | minus wipe | regret | theta |
|---|---|---|---|---|---|---|
| sim-a-old -> sim-a-old | home | 0.633 [0.531, 0.734] | 0.008 | 0.151 | 0.162 | 1.07 |
| sim-a-old -> sim-a-new | same_maker_upgrade | 0.727 [0.592, 0.862] | 0.004 | 0.075 | 0.157 | 0.52 |
| sim-a-old -> sim-b-old | cross_maker | 0.545 [0.413, 0.678] | 0.036 | 0.054 | 0.294 | 0.27 |
| sim-a-old -> sim-b-new | cross_maker | 0.626 [0.521, 0.732] | 0.028 | -0.017 | 0.258 | 0.17 |
| sim-a-new -> sim-a-old | same_maker_downgrade | 0.653 [0.555, 0.751] | 0.037 | 0.099 | 0.222 | 1.37 |
| sim-a-new -> sim-a-new | home | 0.731 [0.623, 0.838] | 0.025 | 0.025 | 0.171 | 1.61 |
| sim-a-new -> sim-b-old | cross_maker | 0.570 [0.459, 0.682] | 0.079 | 0.160 | 0.180 | 1.14 |
| sim-a-new -> sim-b-new | cross_maker | 0.642 [0.538, 0.745] | 0.034 | 0.026 | 0.207 | 0.98 |
| sim-b-old -> sim-a-old | cross_maker | 0.643 [0.552, 0.735] | 0.090 | 0.108 | 0.223 | 0.50 |
| sim-b-old -> sim-a-new | cross_maker | 0.640 [0.507, 0.773] | 0.015 | 0.095 | 0.226 | 0.29 |
| sim-b-old -> sim-b-old | home | 0.607 [0.453, 0.760] | -0.027 | 0.062 | 0.241 | 1.07 |
| sim-b-old -> sim-b-new | same_maker_upgrade | 0.670 [0.549, 0.791] | 0.018 | 0.027 | 0.170 | 0.98 |
| sim-b-new -> sim-a-old | cross_maker | 0.575 [0.445, 0.705] | 0.040 | 0.066 | 0.273 | 0.47 |
| sim-b-new -> sim-a-new | cross_maker | 0.608 [0.474, 0.742] | 0.027 | 0.036 | 0.267 | 0.11 |
| sim-b-new -> sim-b-old | same_maker_downgrade | 0.505 [0.400, 0.609] | 0.014 | 0.014 | 0.263 | 0.38 |
| sim-b-new -> sim-b-new | home | 0.723 [0.618, 0.829] | -0.027 | 0.116 | 0.187 | 1.01 |

Per-stream values, the Brier scores, the uncorrected log score, Cw, both intervals of every number and the paper's rules' own values are in summary.csv and compare.csv; one row per cell is in cells.csv.
