# pool_across_draws: swap-day rule at budget k = 16

**Tasks scored: the DEV half of the evaluation tasks, which is public. You may have tuned on it, and a rule can memorise it, so this is a development number, not a ranking. The board ranks on the held-out TEST half, scored by the maintainers from your entry file.**

Scored from the frozen tables of study `sim` with no model call (pack fingerprint `c209acb9e99a07ef`). Each value is a mean over the evaluation tasks; 200 seeded draw(s), each task's value the mean over the draws. Differences use the same tasks and the same draws.

Brackets: 95 % intervals. Two-way = tasks and tips both treated as sampled: msr.metrics.robust_variance, the delete-one-cluster jackknife over task ids and tips (a tip that recurs in several stream orders is one cluster; the primary interval). Theta's bracket is the union of its two-way and task-only Fieller sets (msr.metrics.theta_tests). Task-only = the task-id cluster bootstrap, 10,000 draws, seed 0 (secondary; the paper's tables of rule values use this one, so on all evaluation tasks they match it digit for digit).

First-shown success: the reader's success with the candidate the rule shows first (higher is better). Regret: the gap to the task's best candidate (lower is better). Theta: the share of the owner's home ranking signal (its `ema_grade` score with its own results) that the rule's order keeps for the reader; at a home cell the reader is the owner itself with the same results, so keep's theta there is exactly 1. Theta = order x stakes; order is 'not identifiable' where the reader's spread cannot be told from zero, and theta reads 'no home signal' where the owner's score has no ranking signal on its calibration tasks (msr.metrics.home_signal_flag).

- Run sealed: one fresh process per call, forked from a launcher that never runs the entry.
- landlock: ABI 7: read-only access to 7 folder(s) and file(s); no writes, no execution; no TCP; signals and abstract sockets scoped
- seccomp: no threads; no pipes, sockets, IPC, shared memory, key rings, ptrace, exec, xattrs or file metadata changes

## By kind of swap, dev half (public) (ddxplus)

| kind | first-shown success | minus keep | minus wipe | minus fixed_0.5 | minus powerprior_16 | minus recal_16 | minus retest_16 | minus audit_16 | regret | log score (level-corrected) | theta | order | checks used |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| same-maker upgrades | 0.700 [0.594, 0.807] (task-only [0.627, 0.772]) | 0.013 [-0.030, 0.055] | 0.053 [-0.008, 0.114] | 0.017 [-0.030, 0.065] | 0.022 [-0.031, 0.074] | 0.033 [-0.010, 0.077] | 0.026 [-0.031, 0.082] | 0.028 [-0.013, 0.069] | 0.161 | -0.765 [-0.843, -0.687] | 0.751 [0.456, 1.193] | 1.11 [0.59, 3.54] | 16.0 |
| same-maker downgrades | 0.602 [0.522, 0.682] (task-only [0.527, 0.676]) | 0.048 [-0.004, 0.100] | 0.079 [-0.003, 0.162] | 0.026 [-0.025, 0.077] | 0.064 [0.006, 0.123] | 0.056 [0.008, 0.105] | 0.088 [0.012, 0.165] | 0.059 [0.005, 0.113] | 0.220 | -0.705 [-0.766, -0.643] | 1.009 [0.591, 2.305] | 1.19 [0.68, 3.57] | 16.0 |
| cross-maker swaps | 0.613 [0.556, 0.671] (task-only [0.556, 0.670]) | 0.051 [0.023, 0.079] | 0.073 [0.027, 0.120] | 0.052 [0.029, 0.075] | 0.072 [0.040, 0.103] | 0.063 [0.038, 0.088] | 0.057 [0.020, 0.094] | 0.061 [0.037, 0.085] | 0.234 | -0.800 [-0.854, -0.746] | 0.470 [0.227, 0.790] | 0.54 [0.29, 0.88] | 16.0 |
| home cells (each owner reading its own bank) | 0.673 [0.610, 0.737] (task-only [0.616, 0.730]) | -0.005 [-0.043, 0.033] | 0.088 [0.033, 0.144] | 0.004 [-0.026, 0.034] | 0.008 [-0.025, 0.041] | 0.021 [-0.011, 0.052] | 0.035 [-0.005, 0.074] | 0.015 [-0.015, 0.045] | 0.191 | -0.737 [-0.809, -0.666] | 1.073 [0.937, 1.275] | 1.02 [0.82, 1.34] | 16.0 |

### Every ordered pair, dev half (public)

| owner -> reader | kind | first-shown success | minus keep | minus wipe | regret | theta |
|---|---|---|---|---|---|---|
| sim-a-old -> sim-a-old | home | 0.642 [0.540, 0.744] | 0.017 | 0.160 | 0.153 | 1.07 |
| sim-a-old -> sim-a-new | same_maker_upgrade | 0.714 [0.551, 0.878] | -0.009 | 0.063 | 0.170 | 0.51 |
| sim-a-old -> sim-b-old | cross_maker | 0.554 [0.416, 0.692] | 0.045 | 0.063 | 0.285 | 0.40 |
| sim-a-old -> sim-b-new | cross_maker | 0.665 [0.566, 0.763] | 0.067 | 0.022 | 0.219 | 0.30 |
| sim-a-new -> sim-a-old | same_maker_downgrade | 0.695 [0.608, 0.783] | 0.079 | 0.142 | 0.180 | 1.74 |
| sim-a-new -> sim-a-new | home | 0.704 [0.576, 0.832] | -0.001 | -0.001 | 0.198 | 1.26 |
| sim-a-new -> sim-b-old | cross_maker | 0.588 [0.477, 0.699] | 0.097 | 0.177 | 0.162 | 1.41 |
| sim-a-new -> sim-b-new | cross_maker | 0.660 [0.559, 0.761] | 0.053 | 0.044 | 0.189 | 1.08 |
| sim-b-old -> sim-a-old | cross_maker | 0.640 [0.544, 0.736] | 0.086 | 0.104 | 0.226 | 0.53 |
| sim-b-old -> sim-a-new | cross_maker | 0.623 [0.479, 0.768] | -0.002 | 0.079 | 0.243 | -0.03 |
| sim-b-old -> sim-b-old | home | 0.642 [0.510, 0.774] | 0.008 | 0.097 | 0.206 | 1.13 |
| sim-b-old -> sim-b-new | same_maker_upgrade | 0.687 [0.568, 0.805] | 0.035 | 0.044 | 0.153 | 0.95 |
| sim-b-new -> sim-a-old | cross_maker | 0.562 [0.441, 0.683] | 0.027 | 0.053 | 0.286 | 0.43 |
| sim-b-new -> sim-a-new | cross_maker | 0.616 [0.508, 0.725] | 0.036 | 0.045 | 0.259 | 0.19 |
| sim-b-new -> sim-b-old | same_maker_downgrade | 0.508 [0.386, 0.630] | 0.017 | 0.017 | 0.260 | 0.56 |
| sim-b-new -> sim-b-new | home | 0.705 [0.603, 0.807] | -0.045 | 0.098 | 0.206 | 0.91 |

Per-stream values, the Brier scores, the uncorrected log score, Cw, both intervals of every number and the paper's rules' own values are in summary.csv and compare.csv; one row per cell is in cells.csv.
