#!/bin/bash
cd <project>
W=<project>/paper/reviews/round3/r9_user_test
run() { # name outdir args...
  local tag=$1; shift
  local s=$(date +%s.%N)
  nice .venv/bin/python -m scoreswap score "$@" --pack release/sim --workers 2 > $W/logs/40_$tag.txt 2>&1
  local rc=$?
  echo "$tag rc=$rc secs=$(echo "$(date +%s.%N) - $s" | bc)" >> $W/logs/40_batch1_times.txt
}
: > $W/logs/40_batch1_times.txt
run pool_k16_A $W/attacks/pool_across_draws.py --budget 16 --out $W/scores_A
run pool_k16_B $W/attacks/pool_across_draws.py --budget 16 --out $W/scores_B
run template_k16 $W/entries/template_rule.py --budget 16 --out $W/scores
run pool_k8 $W/attacks/pool_across_draws.py --budget 8 --out $W/scores_A
run template_k8 $W/entries/template_rule.py --budget 8 --out $W/scores
run template_k64 $W/entries/template_rule.py --budget 64 --out $W/scores
run calib_k64 $W/attacks/calib_embed.py --budget 64 --out $W/scores
run eb_k16_A $W/entries/eb_slope_shrink.py --budget 16 --out $W/scores_A
run eb_k16_B $W/entries/eb_slope_shrink.py --budget 16 --out $W/scores_B
run eb_k0 $W/entries/eb_slope_shrink.py --budget 0 --out $W/scores
run logit_k16 $W/entries/logit_p_cand.py --budget 16 --out $W/scores
run logit_k0 $W/entries/logit_p_cand.py --budget 0 --out $W/scores
run lift_score $W/entries/lift_js_score.py --out $W/scores
echo DONE >> $W/logs/40_batch1_times.txt
