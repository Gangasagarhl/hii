# Board of swap-day rules, budget k = 16

Study `sim`. Every entry was re-run by the harness from the released tables, sealed (one fresh process per call).

**Ranked on the public DEV half: provisional.** The dev half is public, so an entry may have been tuned on it or may even have memorised it. The real ranking is on the held-out test half, which the maintainers score from submitted entry files.

Brackets: 95 % intervals. Two-way = tasks and tips both treated as sampled: msr.metrics.robust_variance, the delete-one-cluster jackknife over task ids and tips (a tip that recurs in several stream orders is one cluster; the primary interval). Theta's bracket is the union of its two-way and task-only Fieller sets (msr.metrics.theta_tests). Task-only = the task-id cluster bootstrap, 10,000 draws, seed 0 (secondary; the paper's tables of rule values use this one, so on all evaluation tasks they match it digit for digit).

Ranked by first-shown success per kind of swap (higher is better), with the difference from keep on the same tasks and draws and its two-way 95 % interval; 'vs keep' groups the ranks: above keep, below keep, or not distinguishable (the interval holds 0, so the order between such rows means little). Then regret, the level-corrected log score (when the rule returns p) and the checks used. To relate a row to the paper's table, use the task-only interval with --split all (maintainers): it is the paper's.

## same-maker upgrades (ddxplus)

| rank | rule | source | first-shown success (dev) | minus keep (dev) | vs keep | regret | theta (order kept) | order | log score (lc) | checks used |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | pool_across_draws | outside entry | 0.692 [0.586, 0.797] (task-only [0.616, 0.767]) | 0.004 [-0.028, 0.037] | not distinguishable | 0.170 | 0.842 [0.541, 1.312] | 1.24 [0.68, 3.98] | -0.754 | 16.0 |
| 2 | template_rule | outside entry | 0.690 [0.593, 0.786] (task-only [0.614, 0.762]) | 0.002 [-0.009, 0.013] | not distinguishable | 0.172 | 0.790 [0.504, 1.240] | 1.16 [0.70, 3.44] | -0.749 | 16.0 |
| 3 | calib_embed | outside entry | 0.688 [0.588, 0.787] (task-only [0.605, 0.768]) | 0.000 [-0.037, 0.037] | not distinguishable | 0.174 | 0.913 [0.599, 1.421] | 1.35 [0.86, 3.89] | -0.773 | 0.0 |
| 4 | keep | paper (ema_grade) | 0.688 [0.587, 0.788] (task-only [0.612, 0.759]) | - | (keep) | 0.174 | no home signal | not identifiable | -0.742 | 0.0 |
| 5 | logit_p_cand | outside entry | 0.688 [0.587, 0.788] (task-only [0.612, 0.759]) | 0.000  | - | 0.174 | 0.750 [0.456, 1.195] | 1.10 [0.64, 3.29] | -0.713 | 16.0 |
| 6 | fixed_0.5 | paper (ema_grade) | 0.683 [0.576, 0.790] (task-only [0.605, 0.759]) | -0.004 [-0.022, 0.013] | not distinguishable | 0.179 | no home signal | not identifiable | -0.688 | 0.0 |
| 7 | powerprior_16 | paper (ema_grade) | 0.679 [0.575, 0.783] (task-only [0.605, 0.749]) | -0.009 [-0.046, 0.029] | not distinguishable | 0.183 | no home signal | not identifiable | -0.700 | 16.0 |
| 8 | eb_slope_shrink | outside entry | 0.676 [0.578, 0.774] (task-only [0.603, 0.746]) | -0.012 [-0.033, 0.010] | not distinguishable | 0.186 | 0.698 [0.448, 1.090] | 1.03 [0.62, 3.03] | -0.706 | 16.0 |
| 9 | retest_16 | paper (ema_grade) | 0.675 [0.560, 0.790] (task-only [0.605, 0.741]) | -0.013 [-0.073, 0.048] | not distinguishable | 0.187 | no home signal | not identifiable | -0.710 | 16.0 |
| 10 | audit_16 | paper (ema_grade) | 0.673 [0.574, 0.772] (task-only [0.599, 0.743]) | -0.015 [-0.033, 0.003] | not distinguishable | 0.189 | no home signal | not identifiable | -0.733 | 16.0 |
| 11 | recal_16 | paper (ema_grade) | 0.667 [0.566, 0.768] (task-only [0.593, 0.738]) | -0.020 [-0.038, -0.002] | below keep | 0.195 | no home signal | not identifiable | -0.708 | 16.0 |
| 12 | wipe | paper (ema_grade) | 0.647 [0.557, 0.738] (task-only [0.568, 0.723]) | -0.040 [-0.104, 0.023] | not distinguishable | 0.214 | no home signal | not identifiable | -0.712 | 0.0 |

## same-maker downgrades (ddxplus)

| rank | rule | source | first-shown success (dev) | minus keep (dev) | vs keep | regret | theta (order kept) | order | log score (lc) | checks used |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | pool_across_draws | outside entry | 0.600 [0.521, 0.678] (task-only [0.523, 0.675]) | 0.046 [-0.010, 0.102] | not distinguishable | 0.222 | 0.882 [0.491, 2.086] | 1.04 [0.57, 3.25] | -0.717 | 16.0 |
| 2 | fixed_0.5 | paper (ema_grade) | 0.576 [0.461, 0.691] (task-only [0.500, 0.650]) | 0.022 [-0.005, 0.049] | not distinguishable | 0.246 | no home signal | not identifiable | -0.677 | 0.0 |
| 3 | calib_embed | outside entry | 0.571 [0.486, 0.657] (task-only [0.495, 0.645]) | 0.018 [-0.041, 0.077] | not distinguishable | 0.250 | 0.839 [0.454, 1.871] | 0.99 [0.56, 2.70] | -0.695 | 0.0 |
| 4 | template_rule | outside entry | 0.566 [0.481, 0.650] (task-only [0.497, 0.636]) | 0.012 [-0.011, 0.036] | not distinguishable | 0.256 | 0.758 [0.411, 1.579] | 0.89 [0.49, 2.37] | -0.752 | 16.0 |
| 5 | eb_slope_shrink | outside entry | 0.561 [0.472, 0.649] (task-only [0.495, 0.627]) | 0.007 [-0.029, 0.044] | not distinguishable | 0.261 | 0.665 [0.356, 1.411] | 0.78 [0.43, 2.07] | -0.697 | 16.0 |
| 6 | keep | paper (ema_grade) | 0.554 [0.455, 0.652] (task-only [0.477, 0.632]) | - | (keep) | 0.268 | no home signal | not identifiable | -0.758 | 0.0 |
| 7 | logit_p_cand | outside entry | 0.554 [0.455, 0.652] (task-only [0.477, 0.632]) | 0.000  | - | 0.268 | 0.720 [0.356, 1.440] | 0.85 [0.44, 2.10] | -0.712 | 16.0 |
| 8 | recal_16 | paper (ema_grade) | 0.545 [0.448, 0.643] (task-only [0.474, 0.617]) | -0.008 [-0.034, 0.017] | not distinguishable | 0.276 | no home signal | not identifiable | -0.696 | 16.0 |
| 9 | audit_16 | paper (ema_grade) | 0.543 [0.453, 0.633] (task-only [0.470, 0.617]) | -0.011 [-0.029, 0.008] | not distinguishable | 0.279 | no home signal | not identifiable | -0.739 | 16.0 |
| 10 | powerprior_16 | paper (ema_grade) | 0.537 [0.452, 0.623] (task-only [0.463, 0.612]) | -0.016 [-0.068, 0.035] | not distinguishable | 0.284 | no home signal | not identifiable | -0.688 | 16.0 |
| 11 | wipe | paper (ema_grade) | 0.522 [0.435, 0.610] (task-only [0.438, 0.607]) | -0.031 [-0.096, 0.034] | not distinguishable | 0.299 | no home signal | not identifiable | -0.692 | 0.0 |
| 12 | retest_16 | paper (ema_grade) | 0.514 [0.420, 0.607] (task-only [0.434, 0.593]) | -0.040 [-0.125, 0.045] | not distinguishable | 0.308 | no home signal | not identifiable | -0.690 | 16.0 |

## cross-maker swaps (ddxplus)

| rank | rule | source | first-shown success (dev) | minus keep (dev) | vs keep | regret | theta (order kept) | order | log score (lc) | checks used |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | calib_embed | outside entry | 0.613 [0.555, 0.671] (task-only [0.555, 0.669]) | 0.050 [0.013, 0.088] | above keep | 0.234 | 0.547 [0.253, 0.915] | 0.63 [0.32, 1.05] | -0.776 | 0.0 |
| 2 | pool_across_draws | outside entry | 0.606 [0.545, 0.667] (task-only [0.546, 0.665]) | 0.044 [0.011, 0.076] | above keep | 0.241 | 0.430 [0.169, 0.760] | 0.50 [0.22, 0.85] | -0.804 | 16.0 |
| 3 | template_rule | outside entry | 0.573 [0.509, 0.636] (task-only [0.514, 0.630]) | 0.010 [-0.002, 0.022] | not distinguishable | 0.275 | 0.256 [0.028, 0.492] | 0.29 [0.04, 0.55] | -0.832 | 16.0 |
| 4 | eb_slope_shrink | outside entry | 0.570 [0.513, 0.626] (task-only [0.515, 0.623]) | 0.007 [-0.023, 0.038] | not distinguishable | 0.278 | 0.244 [0.078, 0.440] | 0.28 [0.10, 0.49] | -0.720 | 16.0 |
| 5 | keep | paper (ema_grade) | 0.562 [0.494, 0.631] (task-only [0.501, 0.623]) | - | (keep) | 0.285 | no home signal | not identifiable | -0.840 | 0.0 |
| 6 | logit_p_cand | outside entry | 0.562 [0.494, 0.631] (task-only [0.501, 0.623]) | 0.000  | - | 0.285 | 0.198 [-0.043, 0.437] | 0.23 [-0.05, 0.49] | -0.745 | 16.0 |
| 7 | fixed_0.5 | paper (ema_grade) | 0.561 [0.495, 0.628] (task-only [0.499, 0.622]) | -0.001 [-0.016, 0.014] | not distinguishable | 0.286 | no home signal | not identifiable | -0.718 | 0.0 |
| 8 | retest_16 | paper (ema_grade) | 0.557 [0.495, 0.618] (task-only [0.496, 0.615]) | -0.006 [-0.060, 0.048] | not distinguishable | 0.290 | no home signal | not identifiable | -0.700 | 16.0 |
| 9 | audit_16 | paper (ema_grade) | 0.553 [0.495, 0.610] (task-only [0.495, 0.609]) | -0.010 [-0.037, 0.017] | not distinguishable | 0.295 | no home signal | not identifiable | -0.782 | 16.0 |
| 10 | recal_16 | paper (ema_grade) | 0.550 [0.494, 0.607] (task-only [0.495, 0.605]) | -0.012 [-0.044, 0.020] | not distinguishable | 0.297 | no home signal | not identifiable | -0.725 | 16.0 |
| 11 | powerprior_16 | paper (ema_grade) | 0.542 [0.482, 0.601] (task-only [0.483, 0.599]) | -0.021 [-0.061, 0.020] | not distinguishable | 0.305 | no home signal | not identifiable | -0.707 | 16.0 |
| 12 | wipe | paper (ema_grade) | 0.540 [0.480, 0.600] (task-only [0.483, 0.597]) | -0.022 [-0.080, 0.035] | not distinguishable | 0.307 | no home signal | not identifiable | -0.700 | 0.0 |

## home cells (each owner reading its own bank) (ddxplus)

| rank | rule | source | first-shown success (dev) | minus keep (dev) | vs keep | regret | theta (order kept) | order | log score (lc) | checks used |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | keep | paper (ema_grade) | 0.679 [0.607, 0.751] (task-only [0.618, 0.737]) | - | (keep) | 0.185 | no home signal | not identifiable | -0.725 | 0.0 |
| 2 | logit_p_cand | outside entry | 0.679 [0.607, 0.751] (task-only [0.618, 0.737]) | 0.000  | - | 0.185 | 1.000 [1.000, 1.000] | 0.95 [0.80, 1.15] | -0.701 | 16.0 |
| 3 | template_rule | outside entry | 0.671 [0.605, 0.738] (task-only [0.613, 0.726]) | -0.007 [-0.020, 0.006] | not distinguishable | 0.193 | 1.021 [0.986, 1.066] | 0.97 [0.83, 1.18] | -0.727 | 16.0 |
| 4 | pool_across_draws | outside entry | 0.671 [0.610, 0.732] (task-only [0.617, 0.724]) | -0.008 [-0.060, 0.045] | not distinguishable | 0.193 | 1.143 [0.942, 1.475] | 1.08 [0.85, 1.50] | -0.722 | 16.0 |
| 5 | fixed_0.5 | paper (ema_grade) | 0.670 [0.605, 0.734] (task-only [0.611, 0.725]) | -0.009 [-0.019, 0.002] | not distinguishable | 0.194 | no home signal | not identifiable | -0.675 | 0.0 |
| 6 | calib_embed | outside entry | 0.667 [0.603, 0.731] (task-only [0.614, 0.719]) | -0.011 [-0.073, 0.051] | not distinguishable | 0.196 | 1.129 [0.896, 1.469] | 1.07 [0.80, 1.50] | -0.720 | 0.0 |
| 7 | powerprior_16 | paper (ema_grade) | 0.665 [0.600, 0.730] (task-only [0.608, 0.720]) | -0.014 [-0.056, 0.029] | not distinguishable | 0.199 | no home signal | not identifiable | -0.691 | 16.0 |
| 8 | audit_16 | paper (ema_grade) | 0.658 [0.590, 0.726] (task-only [0.601, 0.713]) | -0.020 [-0.037, -0.004] | below keep | 0.206 | no home signal | not identifiable | -0.719 | 16.0 |
| 9 | eb_slope_shrink | outside entry | 0.655 [0.594, 0.717] (task-only [0.602, 0.707]) | -0.023 [-0.047, 0.000] | not distinguishable | 0.208 | 0.924 [0.869, 1.004] | 0.88 [0.73, 1.09] | -0.694 | 16.0 |
| 10 | recal_16 | paper (ema_grade) | 0.653 [0.587, 0.718] (task-only [0.596, 0.706]) | -0.026 [-0.043, -0.009] | below keep | 0.211 | no home signal | not identifiable | -0.694 | 16.0 |
| 11 | retest_16 | paper (ema_grade) | 0.638 [0.565, 0.712] (task-only [0.582, 0.694]) | -0.040 [-0.085, 0.005] | not distinguishable | 0.225 | no home signal | not identifiable | -0.698 | 16.0 |
| 12 | wipe | paper (ema_grade) | 0.585 [0.505, 0.665] (task-only [0.520, 0.649]) | -0.094 [-0.164, -0.023] | below keep | 0.279 | no home signal | not identifiable | -0.703 | 0.0 |

## Every ordered pair (first-shown success, dev)

| owner -> reader | audit_16 | calib_embed | eb_slope_shrink | fixed_0.5 | keep | logit_p_cand | pool_across_draws | powerprior_16 | recal_16 | retest_16 | template_rule | wipe |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| sim-a-old -> sim-a-old | 0.595 | 0.616 | 0.616 | 0.625 | 0.625 | 0.625 | 0.632 | 0.584 | 0.602 | 0.585 | 0.630 | 0.482 |
| sim-a-old -> sim-a-new | 0.699 | 0.705 | 0.695 | 0.714 | 0.723 | 0.723 | 0.705 | 0.707 | 0.701 | 0.695 | 0.720 | 0.652 |
| sim-a-old -> sim-b-old | 0.513 | 0.562 | 0.522 | 0.491 | 0.509 | 0.509 | 0.543 | 0.484 | 0.524 | 0.497 | 0.511 | 0.491 |
| sim-a-old -> sim-b-new | 0.608 | 0.607 | 0.611 | 0.589 | 0.598 | 0.598 | 0.623 | 0.605 | 0.595 | 0.600 | 0.591 | 0.643 |
| sim-a-new -> sim-a-old | 0.596 | 0.652 | 0.609 | 0.634 | 0.616 | 0.616 | 0.699 | 0.583 | 0.589 | 0.564 | 0.629 | 0.554 |
| sim-a-new -> sim-a-new | 0.701 | 0.661 | 0.685 | 0.688 | 0.705 | 0.705 | 0.660 | 0.760 | 0.684 | 0.713 | 0.697 | 0.705 |
| sim-a-new -> sim-b-old | 0.454 | 0.571 | 0.493 | 0.509 | 0.491 | 0.491 | 0.587 | 0.442 | 0.459 | 0.457 | 0.519 | 0.411 |
| sim-a-new -> sim-b-new | 0.612 | 0.616 | 0.627 | 0.616 | 0.607 | 0.607 | 0.635 | 0.620 | 0.603 | 0.591 | 0.626 | 0.616 |
| sim-b-old -> sim-a-old | 0.540 | 0.688 | 0.566 | 0.545 | 0.554 | 0.554 | 0.668 | 0.543 | 0.522 | 0.561 | 0.570 | 0.536 |
| sim-b-old -> sim-a-new | 0.598 | 0.616 | 0.594 | 0.607 | 0.625 | 0.625 | 0.606 | 0.548 | 0.594 | 0.569 | 0.626 | 0.545 |
| sim-b-old -> sim-b-old | 0.625 | 0.652 | 0.611 | 0.634 | 0.634 | 0.634 | 0.641 | 0.618 | 0.617 | 0.623 | 0.622 | 0.545 |
| sim-b-old -> sim-b-new | 0.646 | 0.670 | 0.657 | 0.652 | 0.652 | 0.652 | 0.678 | 0.651 | 0.633 | 0.655 | 0.659 | 0.643 |
| sim-b-new -> sim-a-old | 0.524 | 0.589 | 0.531 | 0.527 | 0.536 | 0.536 | 0.580 | 0.510 | 0.512 | 0.543 | 0.540 | 0.509 |
| sim-b-new -> sim-a-new | 0.572 | 0.652 | 0.613 | 0.607 | 0.580 | 0.580 | 0.607 | 0.584 | 0.595 | 0.635 | 0.598 | 0.571 |
| sim-b-new -> sim-b-old | 0.490 | 0.491 | 0.513 | 0.518 | 0.491 | 0.491 | 0.500 | 0.492 | 0.502 | 0.463 | 0.503 | 0.491 |
| sim-b-new -> sim-b-new | 0.712 | 0.741 | 0.710 | 0.732 | 0.750 | 0.750 | 0.750 | 0.699 | 0.707 | 0.632 | 0.737 | 0.607 |
