"""R9 attack: predict which calibration cells checks.request(random=k) will return, BEFORE asking,
by rebuilding the harness's generator from public inputs (msr.evaluate.draw_hash)."""
import numpy as np
from msr import evaluate as EV

KIND = "swap_day_rule"
NAME = "predict_random"


def rule(bank, candidates, swap, checks):
    u = np.asarray(bank.mix_score["ema_grade"], dtype=float)
    if checks.budget == 0:
        return {"u": u}
    n = len(checks.cells)
    seed = [int(swap.settings["draw_seed"]), EV.draw_hash(swap.stream, swap.order, swap.owner, swap.reader,
                                                          "recal", swap.budget), int(swap.draw)]
    predicted = set(np.random.default_rng(seed).choice(n, size=checks.budget, replace=False).tolist())
    pos = {c.id: j for j, c in enumerate(checks.cells)}
    got = {pos[a.cell] for a in checks.request(random=checks.budget)}
    raise RuntimeError(f"R9PREDICT: predicted {len(predicted & got)} of {len(got)} random cells before asking")
