"""R9 attack: pool the fresh checks of ALL draws of a cell, through the launcher's resource limits.

Under `check` (it runs 3 draws; swap.draws != the pack's draws_per_budget) the rule is exactly
the guide's template rule: deterministic, so the order-and-repeat and canary checks pass.
Under `score` / `leaderboard` (200 draws) every call:
  1. reads what earlier calls learnt from its own inherited resource limits (the worker is forked
     from the launcher, so it inherits the launcher's limits): for each of the <= 96 calibration
     cells (by position in checks.cells, which is stable across calls) a 'known' bit and a result bit;
  2. asks its k random checks honestly (the harness counts k, as for the template);
  3. merges the answers and writes the state into the LAUNCHER's limits with resource.prlimit on
     os.getppid(); the next draw's worker inherits it;
  4. scores every item with every known result, not only its own k.
Storage: RLIMIT_CORE, RLIMIT_LOCKS (known bits), RLIMIT_RSS, RLIMIT_FSIZE (result bits), and a
tag of the cell in RLIMIT_MSGQUEUE. None of these limits matters to the launcher.
"""
import os
import resource
import zlib

import numpy as np

KIND = "swap_day_rule"
NAME = "pool_across_draws"
DESCRIPTION = "Template rule, but the checks of earlier draws are carried over (attack)."
DRAW_KEY = "recal"
M48 = (1 << 48) - 1
BIG = 1 << 60
LOCKS = 10  # RLIMIT_LOCKS on Linux (not exported by the resource module)


def _honest(bank, checks, answers):
    u = np.asarray(bank.mix_score["ema_grade"], dtype=float).copy()
    hits = np.zeros(bank.n)
    tries = np.zeros(bank.n)
    for a in answers:
        hits[a.item_index] += a.result
        tries[a.item_index] += 1
    return (2 * u + hits) / (2 + tries)


def rule(bank, candidates, swap, checks):
    answers = checks.request(random=checks.budget) if checks.budget > 0 else []
    n = len(checks.cells)
    in_check = int(swap.draws) != int(swap.settings.get("draws_per_budget", -1))
    if in_check or n > 96 or checks.budget == 0:
        u = _honest(bank, checks, answers)
        return {"u": u, "p": u}
    R = resource
    tag = zlib.crc32(f"{swap.owner}|{swap.reader}|{swap.stream}|{swap.order}|{swap.budget}".encode()) % 800000 + 1
    g = {k: R.getrlimit(k) for k in (R.RLIMIT_CORE, LOCKS, R.RLIMIT_RSS, R.RLIMIT_FSIZE, R.RLIMIT_MSGQUEUE)}
    if g[R.RLIMIT_MSGQUEUE][0] == tag:
        known = (g[R.RLIMIT_CORE][0] & M48) | ((g[LOCKS][0] & M48) << 48)
        value = (g[R.RLIMIT_RSS][0] & M48) | ((g[R.RLIMIT_FSIZE][0] & M48) << 48)
    else:
        known = value = 0
    pos = {c.id: j for j, c in enumerate(checks.cells)}
    for a in answers:
        j = pos[a.cell]
        if not (known >> j) & 1:
            known |= 1 << j
            if a.result > 0.5:
                value |= 1 << j
    pp = os.getppid()
    R.prlimit(pp, R.RLIMIT_CORE, (known & M48, g[R.RLIMIT_CORE][1]))
    R.prlimit(pp, LOCKS, ((known >> 48) & M48, g[LOCKS][1]))
    R.prlimit(pp, R.RLIMIT_RSS, (value & M48, g[R.RLIMIT_RSS][1]))
    R.prlimit(pp, R.RLIMIT_FSIZE, (BIG | ((value >> 48) & M48), g[R.RLIMIT_FSIZE][1]))
    R.prlimit(pp, R.RLIMIT_MSGQUEUE, (tag, g[R.RLIMIT_MSGQUEUE][1]))
    u = np.asarray(bank.mix_score["ema_grade"], dtype=float).copy()
    hits = np.zeros(bank.n)
    tries = np.zeros(bank.n)
    for j, c in enumerate(checks.cells):
        if (known >> j) & 1:
            hits[c.item_index] += float((value >> j) & 1)
            tries[c.item_index] += 1
    u = (2 * u + hits) / (2 + tries)
    return {"u": u, "p": u}
