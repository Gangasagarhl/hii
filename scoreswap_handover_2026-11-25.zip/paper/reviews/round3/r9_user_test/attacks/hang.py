"""R9 attack: a call that never returns (busy loop)."""
KIND = "swap_day_rule"
NAME = "hang"


def rule(bank, candidates, swap, checks):
    while True:
        pass
