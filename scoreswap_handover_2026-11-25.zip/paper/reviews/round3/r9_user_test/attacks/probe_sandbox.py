"""R9 attack probe: what can one sealed call see or touch? It reports ONLY flags, sizes and
error codes (never file contents) by raising an error whose message the harness prints."""
import numpy as np

KIND = "swap_day_rule"
NAME = "probe_sandbox"


def _try(label, fn, out):
    try:
        out.append(f"{label}: OK {fn()}")
    except BaseException as e:  # noqa: BLE001
        out.append(f"{label}: {type(e).__name__} {getattr(e, 'errno', '')} {str(e)[:90]}")


def rule(bank, candidates, swap, checks):
    import os
    import sys
    import gc
    import resource
    out = []
    root = "<project>"
    # 1. metadata of files outside the allowed folders (stat is not an 'open')
    for p in (root + "/.env", root + "/release/sim_private/test_results.csv", root + "/release/sim/dev_results.csv",
              root + "/CLAUDE.md"):
        _try("stat " + p.replace(root, "ROOT"), lambda p=p: (os.path.exists(p), os.stat(p).st_size,
                                                              int(os.stat(p).st_mtime)), out)
    # 2. the launcher's resource limits (another process): read, change, read back
    ppid = os.getppid()
    _try("getppid", lambda: ppid, out)
    _try("prlimit(ppid, CORE) read", lambda: resource.prlimit(ppid, resource.RLIMIT_CORE), out)

    def setcore():
        old = resource.prlimit(ppid, resource.RLIMIT_CORE)
        resource.prlimit(ppid, resource.RLIMIT_CORE, (12345, old[1]))
        new = resource.prlimit(ppid, resource.RLIMIT_CORE)
        resource.prlimit(ppid, resource.RLIMIT_CORE, old)
        return (old, new)
    _try("prlimit(ppid, CORE) write+restore", setcore, out)
    _try("my own CORE (inherited)", lambda: resource.getrlimit(resource.RLIMIT_CORE), out)
    _try("sched_getaffinity(ppid)", lambda: sorted(os.sched_getaffinity(ppid)), out)
    _try("getpriority(ppid)", lambda: os.getpriority(os.PRIO_PROCESS, ppid), out)
    # 3. find the audit hook and its closure (gc is disabled in the worker but get_objects still works)
    hooks = [o for o in gc.get_objects() if callable(o) and getattr(o, "__name__", "") == "hook"
             and getattr(o, "__closure__", None)]
    out.append(f"audit hooks found: {len(hooks)}")
    neutered = False
    for h in hooks:
        names = h.__code__.co_freevars
        out.append(f"hook freevars: {names}")
        try:
            cells = dict(zip(names, h.__closure__))
            if "block" in cells:
                cells["block"].cell_contents = ("no.such.event.",)
            if "ok_path" in cells:
                cells["ok_path"].cell_contents = (lambda p: True)
            if "write_flags" in cells:
                cells["write_flags"].cell_contents = 0
            neutered = True
        except BaseException as e:  # noqa: BLE001
            out.append(f"neuter failed: {type(e).__name__} {e}")
    out.append(f"neutered: {neutered}")
    # 4. with the hook neutered, does the KERNEL stop these? (open only; read a length, never contents)
    def open_len(p):
        fd = os.open(p, os.O_RDONLY)
        try:
            return len(os.read(fd, 1 << 20))
        finally:
            os.close(fd)
    _try("kernel: open sim_private/test_results.csv", lambda: open_len(root + "/release/sim_private/test_results.csv"), out)
    _try("kernel: open ROOT/.env (length only)", lambda: open_len(root + "/.env"), out)
    _try("kernel: open release/sim/dev_results.csv", lambda: open_len(root + "/release/sim/dev_results.csv"), out)
    _try("kernel: open /etc/hostname", lambda: open_len("/etc/hostname"), out)
    _try("kernel: open /proc/self/status", lambda: open_len("/proc/self/status"), out)
    _try("kernel: listdir anaconda3", lambda: len(os.listdir("~/anaconda3")), out)
    _try("kernel: write /dev/shm/r9", lambda: os.open("/dev/shm/r9probe", os.O_WRONLY | os.O_CREAT), out)
    _try("kernel: signal 0 to the launcher", lambda: os.kill(ppid, 0), out)
    _try("kernel: thread", lambda: __import__("threading").Thread(target=lambda: None).start(), out)
    # 5. what the worker's inherited memory holds: the launcher's main() frame
    f = sys._getframe()
    frames = []
    while f is not None:
        frames.append((f.f_code.co_name, sorted(k for k in f.f_locals.keys())[:25]))
        f = f.f_back
    out.append("frames: " + repr(frames)[:900])
    f = sys._getframe()
    while f is not None:
        if f.f_code.co_name == "_worker" and "denied" in f.f_locals:
            out.append(f"denied list had {len(f.f_locals['denied'])} entries: {f.f_locals['denied'][:3]}; clearing it")
            f.f_locals["denied"].clear()
        f = f.f_back
    raise RuntimeError("R9PROBE\n" + "\n".join(out))
