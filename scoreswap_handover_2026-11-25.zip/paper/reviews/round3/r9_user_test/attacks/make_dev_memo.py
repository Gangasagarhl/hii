"""Writes dev_memo.py: memorises the PUBLIC dev outcomes (best candidate per dev task and cell),
shows that candidate first on dev tasks, and behaves like keep on every other task (the public
manifest says which tasks are test). Usage: python make_dev_memo.py <pack> <out>"""
import csv, json, sys
from collections import defaultdict
pack, out = sys.argv[1], sys.argv[2]
man = json.load(open(f"{pack}/manifest.json"))
acc = defaultdict(lambda: defaultdict(list))
for r in csv.DictReader(open(f"{pack}/dev_results.csv")):
    if r["set"] != "regular" or r["position"] == "":
        continue
    acc[f"{r['owner']}|{r['reader']}|{r['stream']}|{r['order']}|{r['task_id']}"][int(r["position"])].append(int(r["result"]))
best = {k: max(v, key=lambda p: (sum(v[p]) / len(v[p]), -p)) for k, v in acc.items()}
tasks = {k: v["tasks"] for k, v in man["probe_tasks"].items()}
src = f'''"""R9 attack: memorised public dev outcomes; keep's order elsewhere."""
import numpy as np
KIND = "swap_day_rule"
NAME = "dev_memo"
TASKS = {json.dumps(tasks)}
BEST = {json.dumps(best)}


def rule(bank, candidates, swap, checks):
    q = np.asarray(bank.mix_score["ema_grade"], dtype=float)
    idx = candidates.item_index
    U = np.where(idx >= 0, q[np.maximum(idx, 0)], 0.5)
    names = TASKS[f"{{swap.stream}}|{{swap.order}}"]
    for t in range(candidates.T):
        b = BEST.get(f"{{swap.owner}}|{{swap.reader}}|{{swap.stream}}|{{swap.order}}|{{names[t]}}")
        if b is not None:
            U[t] = 0.0
            U[t, b] = 1.0
    return {{"u_cand": U}}
'''
open(out, "w").write(src)
print(out, len(src), "bytes", len(best), "dev task-cells")
