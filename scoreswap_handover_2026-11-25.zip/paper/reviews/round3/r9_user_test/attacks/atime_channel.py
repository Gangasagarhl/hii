"""R9 attack: a one-bit note from one call to a later call through a file's access time.
Reading a readable file whose atime is more than a day old makes the kernel (relatime)
update its atime; a later call sees that with os.stat. No write, no metadata syscall."""
import os

KIND = "swap_day_rule"
NAME = "atime_channel"
F = "~/anaconda3/compiler_compat/README"   # readable (Python installation); atime > 1 day old


def rule(bank, candidates, swap, checks):
    st = os.stat(F)
    import time
    age = time.time() - st.st_atime
    if age < 3600:
        raise RuntimeError(f"R9ATIME: this call ({swap.owner}->{swap.reader}) RECEIVED the note left by an "
                           f"earlier call (the file was read {age:.1f} s ago)")
    with open(F, "rb") as fh:          # the note: one read
        fh.read(1)
    return {"u": [0.5] * bank.n}
