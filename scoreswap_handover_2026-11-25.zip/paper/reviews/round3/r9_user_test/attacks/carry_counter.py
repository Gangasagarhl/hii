"""R9 attack, minimal: does anything survive from one call to the next? Each call reads a number
from its OWN inherited resource limit (RLIMIT_CORE soft), adds 1, and writes it into the
launcher's limit (resource.prlimit on os.getppid()); the next worker is forked from the launcher
and inherits it. The output is keep's, except that the count is reported by failing on purpose
once it reaches 5 (so the check prints it)."""
import numpy as np
import resource
import os

KIND = "swap_day_rule"
NAME = "carry_counter"


def rule(bank, candidates, swap, checks):
    soft, hard = resource.getrlimit(resource.RLIMIT_CORE)
    count = soft if soft < (1 << 40) else 0
    resource.prlimit(os.getppid(), resource.RLIMIT_CORE, (count + 1, hard))
    if count + 1 >= 5:
        raise RuntimeError(f"R9CARRY: this call is number {count + 1} in this launcher; "
                           f"cell {swap.owner}->{swap.reader} order {swap.order} draw {swap.draw}")
    u = np.asarray(bank.mix_score["ema_grade"], dtype=float)
    return {"u": u, "p": u}
