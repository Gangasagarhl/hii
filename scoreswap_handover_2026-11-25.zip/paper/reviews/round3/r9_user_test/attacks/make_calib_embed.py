"""Writes attacks/calib_embed.py: a swap-day rule that carries the PUBLIC calibration results of
release/sim inside its own code, so at budget k = 0 (or any k) it knows every check result of
every cell without asking. Usage: python make_calib_embed.py <pack dir> <out file>"""
import csv
import json
import sys
from collections import defaultdict

pack, out = sys.argv[1], sys.argv[2]
man = json.load(open(f"{pack}/manifest.json"))
res = defaultdict(lambda: ["", ""])
for r in csv.DictReader(open(f"{pack}/calibration_results.csv")):
    if r["set"] != "regular":
        continue
    key = f"{r['owner']}|{r['reader']}|{r['stream']}|{r['order']}|{r['task_id']}|{r['position']}"
    res[key][int(r["repeat"]) - 1] = r["result"]
table = {k: "".join(v) for k, v in res.items()}
tasks = {k: v["tasks"] for k, v in man["probe_tasks"].items()}
src = f'''"""R9 attack: carries the public calibration results in its code (no file is read).
At any budget it uses EVERY stored check result of the cell: the k-check budget is not binding."""
import numpy as np

KIND = "swap_day_rule"
NAME = "calib_embed"
DESCRIPTION = "Template rule fed with every public calibration result, embedded in the file."
DRAW_KEY = "recal"
TASKS = {json.dumps(tasks)}
TABLE = {json.dumps(table)}


def rule(bank, candidates, swap, checks):
    u = np.asarray(bank.mix_score["ema_grade"], dtype=float).copy()
    names = TASKS[f"{{swap.stream}}|{{swap.order}}"]
    tpos = {{t: j for j, t in enumerate(candidates.tasks)}}
    hits = np.zeros(bank.n)
    tries = np.zeros(bank.n)
    for c in checks.cells:
        key = f"{{swap.owner}}|{{swap.reader}}|{{swap.stream}}|{{swap.order}}|{{names[tpos[c.task]]}}|{{c.position}}"
        for ch in TABLE.get(key, ""):
            hits[c.item_index] += float(ch)
            tries[c.item_index] += 1.0
    u = (2.0 * u + hits) / (2.0 + tries)
    return {{"u": u, "p": u}}
'''
open(out, "w").write(src)
print(out, len(src), "bytes;", len(table), "cells embedded")
