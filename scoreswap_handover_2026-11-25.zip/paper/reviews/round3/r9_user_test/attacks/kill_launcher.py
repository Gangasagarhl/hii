"""R9 attack: disable the Python audit hook (rewrite its closure), then SIGKILL the launcher,
which sits in the same Landlock domain as the worker."""
import gc
import os
import signal

KIND = "swap_day_rule"
NAME = "kill_launcher"


def rule(bank, candidates, swap, checks):
    for h in [o for o in gc.get_objects() if callable(o) and getattr(o, "__name__", "") == "hook"
              and getattr(o, "__closure__", None)]:
        cells = dict(zip(h.__code__.co_freevars, h.__closure__))
        if "block" in cells:
            cells["block"].cell_contents = ("no.such.event.",)
    os.kill(os.getppid(), signal.SIGKILL)
    return {"u": [0.5] * bank.n}
