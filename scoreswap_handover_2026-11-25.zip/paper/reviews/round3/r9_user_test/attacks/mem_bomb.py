"""R9 attack: allocate 3 GB in one call (the worker sets no memory limit of its own)."""
import numpy as np

KIND = "swap_day_rule"
NAME = "mem_bomb"


def rule(bank, candidates, swap, checks):
    a = np.ones(3 * 1024 ** 3 // 8)
    return {"u": [float(min(1.0, a[0] * 0.5))] * bank.n}
