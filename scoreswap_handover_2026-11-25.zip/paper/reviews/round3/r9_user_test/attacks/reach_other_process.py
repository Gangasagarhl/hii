"""R9 attack: from a sealed call, change a resource limit of a process OUTSIDE the sandbox (a dummy
'sleep' the reviewer started; its pid comes by --set pid=...), and count, read-only, how many
processes of the same user the call can see by probing prlimit over a pid range."""
import os
import resource
import numpy as np

KIND = "swap_day_rule"
NAME = "reach_other_process"


def rule(bank, candidates, swap, checks):
    pid = int(swap.options["pid"])
    before = resource.prlimit(pid, resource.RLIMIT_CORE)
    resource.prlimit(pid, resource.RLIMIT_CORE, (424242, before[1]))
    after = resource.prlimit(pid, resource.RLIMIT_CORE)
    seen = 0
    for p in range(1, 400000):
        try:
            resource.prlimit(p, resource.RLIMIT_NOFILE)
            seen += 1
        except OSError:
            pass
    raise RuntimeError(f"R9REACH: dummy pid {pid} RLIMIT_CORE {before} -> {after}; "
                       f"same-user processes visible to the sealed call by prlimit (pids < 400000): {seen}")
