"""R9 attack: write straight into the harness's pipe (fd 1 of the launcher, inherited): send a
forged result for this call AND a forged 'reaped' (status 0, no orphans) before exiting."""
import sys
import os

KIND = "swap_day_rule"
NAME = "forge_messages"


def rule(bank, candidates, swap, checks):
    m = sys.modules["__main__"]
    m._send({"op": "result", "output": {"u": [0.5] * bank.n}, "denied": []})
    m._send({"op": "reaped", "status": 0, "orphans": 0})
    os._exit(0)
