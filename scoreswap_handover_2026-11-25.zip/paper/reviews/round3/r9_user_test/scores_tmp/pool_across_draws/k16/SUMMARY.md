# pool_across_draws: swap-day rule at budget k = 16

**Tasks scored: the DEV half of the evaluation tasks, which is public. You may have tuned on it, and a rule can memorise it, so this is a development number, not a ranking. The board ranks on the held-out TEST half, scored by the maintainers from your entry file.**

Scored from the frozen tables of study `sim` with no model call (pack fingerprint `c209acb9e99a07ef`). Each value is a mean over the evaluation tasks; 200 seeded draw(s), each task's value the mean over the draws. Differences use the same tasks and the same draws.

Brackets: 95 % intervals. Two-way = tasks and tips both treated as sampled: msr.metrics.robust_variance, the delete-one-cluster jackknife over task ids and tips (a tip that recurs in several stream orders is one cluster; the primary interval). Theta's bracket is the union of its two-way and task-only Fieller sets (msr.metrics.theta_tests). Task-only = the task-id cluster bootstrap, 10,000 draws, seed 0 (secondary; the paper's tables of rule values use this one, so on all evaluation tasks they match it digit for digit).

First-shown success: the reader's success with the candidate the rule shows first (higher is better). Regret: the gap to the task's best candidate (lower is better). Theta: the share of the owner's home ranking signal (its `ema_grade` score with its own results) that the rule's order keeps for the reader; at a home cell the reader is the owner itself with the same results, so keep's theta there is exactly 1. Theta = order x stakes; order is 'not identifiable' where the reader's spread cannot be told from zero, and theta reads 'no home signal' where the owner's score has no ranking signal on its calibration tasks (msr.metrics.home_signal_flag).

- Run sealed: one fresh process per call, forked from a launcher that never runs the entry.
- landlock: ABI 7: read-only access to 7 folder(s) and file(s); no writes, no execution; no TCP; signals and abstract sockets scoped
- seccomp: no threads; no pipes, sockets, IPC, shared memory, key rings, ptrace, exec, xattrs or file metadata changes

## By kind of swap, dev half (public) (ddxplus)

| kind | first-shown success | minus keep | minus wipe | minus fixed_0.5 | minus powerprior_16 | minus recal_16 | minus retest_16 | minus audit_16 | regret | log score (level-corrected) | theta | order | checks used |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| same-maker upgrades | 0.709 [0.618, 0.800] (task-only [0.633, 0.781]) | 0.022 [-0.011, 0.055] | 0.062 [0.001, 0.123] | 0.026 [-0.013, 0.065] | 0.030 [-0.017, 0.078] | 0.042 [0.010, 0.074] | 0.034 [-0.031, 0.100] | 0.037 [0.008, 0.066] | 0.152 | -0.765 [-0.837, -0.693] | 0.839 [0.527, 1.320] | 1.24 [0.67, 4.04] | 16.0 |
| same-maker downgrades | 0.598 [0.513, 0.683] (task-only [0.526, 0.669]) | 0.045 [-0.011, 0.100] | 0.076 [-0.005, 0.157] | 0.022 [-0.033, 0.078] | 0.061 [0.003, 0.118] | 0.053 [0.005, 0.100] | 0.085 [-0.000, 0.170] | 0.055 [0.003, 0.108] | 0.223 | -0.712 [-0.767, -0.657] | 0.984 [0.607, 2.118] | 1.16 [0.69, 3.35] | 16.0 |
| cross-maker swaps | 0.617 [0.558, 0.675] (task-only [0.559, 0.674]) | 0.054 [0.022, 0.086] | 0.077 [0.027, 0.126] | 0.055 [0.025, 0.086] | 0.075 [0.039, 0.110] | 0.066 [0.038, 0.095] | 0.060 [0.021, 0.100] | 0.064 [0.036, 0.092] | 0.230 | -0.783 [-0.831, -0.736] | 0.465 [0.206, 0.798] | 0.54 [0.26, 0.90] | 16.0 |
| home cells (each owner reading its own bank) | 0.653 [0.584, 0.722] (task-only [0.592, 0.713]) | -0.026 [-0.054, 0.002] | 0.068 [0.006, 0.130] | -0.017 [-0.045, 0.011] | -0.012 [-0.048, 0.024] | 0.000 [-0.027, 0.028] | 0.014 [-0.028, 0.057] | -0.005 [-0.032, 0.022] | 0.211 | -0.738 [-0.788, -0.688] | 1.063 [0.883, 1.331] | 1.01 [0.81, 1.33] | 16.0 |

### Every ordered pair, dev half (public)

| owner -> reader | kind | first-shown success | minus keep | minus wipe | regret | theta |
|---|---|---|---|---|---|---|
| sim-a-old -> sim-a-old | home | 0.617 [0.511, 0.722] | -0.008 | 0.135 | 0.178 | 0.99 |
| sim-a-old -> sim-a-new | same_maker_upgrade | 0.732 [0.599, 0.865] | 0.009 | 0.080 | 0.152 | 0.57 |
| sim-a-old -> sim-b-old | cross_maker | 0.587 [0.485, 0.689] | 0.078 | 0.096 | 0.252 | 0.56 |
| sim-a-old -> sim-b-new | cross_maker | 0.615 [0.481, 0.749] | 0.017 | -0.028 | 0.269 | 0.11 |
| sim-a-new -> sim-a-old | same_maker_downgrade | 0.687 [0.595, 0.779] | 0.071 | 0.134 | 0.188 | 1.68 |
| sim-a-new -> sim-a-new | home | 0.664 [0.518, 0.810] | -0.042 | -0.042 | 0.238 | 1.25 |
| sim-a-new -> sim-b-old | cross_maker | 0.613 [0.506, 0.720] | 0.122 | 0.202 | 0.137 | 1.42 |
| sim-a-new -> sim-b-new | cross_maker | 0.643 [0.540, 0.746] | 0.036 | 0.027 | 0.205 | 0.85 |
| sim-b-old -> sim-a-old | cross_maker | 0.667 [0.576, 0.759] | 0.113 | 0.131 | 0.199 | 0.58 |
| sim-b-old -> sim-a-new | cross_maker | 0.650 [0.515, 0.785] | 0.025 | 0.105 | 0.216 | 0.05 |
| sim-b-old -> sim-b-old | home | 0.634 [0.501, 0.766] | -0.000 | 0.089 | 0.214 | 1.07 |
| sim-b-old -> sim-b-new | same_maker_upgrade | 0.686 [0.582, 0.791] | 0.035 | 0.044 | 0.153 | 1.06 |
| sim-b-new -> sim-a-old | cross_maker | 0.552 [0.419, 0.686] | 0.016 | 0.043 | 0.296 | 0.42 |
| sim-b-new -> sim-a-new | cross_maker | 0.607 [0.498, 0.717] | 0.027 | 0.036 | 0.268 | 0.20 |
| sim-b-new -> sim-b-old | same_maker_downgrade | 0.509 [0.379, 0.639] | 0.018 | 0.018 | 0.259 | 0.55 |
| sim-b-new -> sim-b-new | home | 0.697 [0.595, 0.799] | -0.053 | 0.090 | 0.214 | 0.99 |

Per-stream values, the Brier scores, the uncorrected log score, Cw, both intervals of every number and the paper's rules' own values are in summary.csv and compare.csv; one row per cell is in cells.csv.
