#!/bin/bash
cd <project>
W=<project>/paper/reviews/round3/r9_user_test
s=$(date +%s.%N)
nice .venv/bin/python -m scoreswap score $W/attacks/pool_across_draws.py --budget 16 --pack release/sim --workers 2 --out $W/scores_A > $W/logs/41_pool_k16_A.txt 2>&1
echo "pool_k16_A rc=$? secs=$(echo "$(date +%s.%N) - $s" | bc)" >> $W/logs/41_batch2_times.txt
s=$(date +%s.%N)
nice .venv/bin/python -m scoreswap score $W/attacks/pool_across_draws.py --budget 16 --pack release/sim --workers 2 --out $W/scores_B > $W/logs/41_pool_k16_B.txt 2>&1
echo "pool_k16_B rc=$? secs=$(echo "$(date +%s.%N) - $s" | bc)" >> $W/logs/41_batch2_times.txt
s=$(date +%s.%N)
nice .venv/bin/python -m scoreswap leaderboard $W/board2_entries --pack release/sim --budgets 0,16 --workers 2 --out $W/board2 > $W/logs/42_board2.txt 2>&1
echo "board2 rc=$? secs=$(echo "$(date +%s.%N) - $s" | bc)" >> $W/logs/41_batch2_times.txt
echo DONE >> $W/logs/41_batch2_times.txt
