"""R9 honest entry (c): probabilities per (task, candidate), to exercise the log-score path.

u: the old ema score (keep's order). p: a calibrated chance of success for the new model,
from a ridge-penalised logistic fit of the k checked results on (old score, relevance), with the
prior centred on the owner's own mapping (intercept = logit of the owner's mean, slope 0 on
relevance, slope 1 on the old score's logit). No checks: the prior alone. The fit uses a few
Newton steps; everything is deterministic.
"""
import numpy as np

KIND = "swap_day_rule"
NAME = "logit_p_cand"
DESCRIPTION = "Keep's order; p per task and candidate from a ridge logistic fit on the checks."
LAM = 4.0


def _logit(p):
    p = np.clip(p, 0.02, 0.98)
    return np.log(p / (1 - p))


def rule(bank, candidates, swap, checks):
    q = np.asarray(bank.mix_score["ema_grade"], dtype=float)
    idx = candidates.item_index
    rel = np.where(idx >= 0, np.asarray(candidates.relevance, dtype=float), 0.0)
    rel_c = rel - rel[idx >= 0].mean()
    lq = _logit(q)
    m0 = float(_logit(np.array([q.mean()]))[0])
    beta0 = np.array([m0, 1.0, 0.0])               # intercept, slope on centred logit(old), slope on relevance
    beta = beta0.copy()
    answers = checks.request(random=checks.budget) if checks.budget > 0 else []
    if answers:
        pos = {}
        for c in checks.cells:
            pos[c.id] = (candidates.task_index[c.task] if hasattr(candidates, "task_index")
                         else list(candidates.tasks).index(c.task), c.position)
        X = np.array([[1.0, lq[a.item_index] - lq.mean(), rel_c[pos[a.cell]]] for a in answers])
        y = np.array([a.result for a in answers])
        for _ in range(25):
            eta = X @ beta
            mu = 1.0 / (1.0 + np.exp(-eta))
            W = mu * (1 - mu)
            g = X.T @ (y - mu) - LAM * (beta - beta0)
            H = (X * W[:, None]).T @ X + LAM * np.eye(3)
            beta = beta + np.linalg.solve(H, g)
    old_c = np.where(idx >= 0, lq[np.maximum(idx, 0)] - lq.mean(), 0.0)
    eta = beta[0] + beta[1] * old_c + beta[2] * rel_c
    P = 1.0 / (1.0 + np.exp(-eta))
    U = np.where(idx >= 0, q[np.maximum(idx, 0)], 0.5)
    P = np.where(idx >= 0, P, 0.5)
    return {"u_cand": U, "p_cand": P}
