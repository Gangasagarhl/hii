"""R9 honest entry (b): a score type. Paired lift over the no-tip baseline, shrunk per item
toward the bank's mean lift (James-Stein / empirical Bayes).

For each showing with a logged no-tip result: d = result - no_memory (in {-1, 0, 1}). Per item,
mean lift dbar_i over n_i such showings. Between-item variance tau2 = max(var(dbar) - mean noise
variance / n, small); each item is pulled toward the overall mean lift by n_i / (n_i + s2 / tau2).
Items never shown sit at the overall mean. Ties broken by the plain success rate (tiny weight).
"""
import numpy as np

KIND = "score_type"
NAME = "lift_js_score"
DESCRIPTION = "Paired lift over the no-tip result, shrunk toward the bank mean (empirical Bayes)."


def score(log):
    n_items = len(log.items)
    idx = np.asarray(log.item_index, dtype=int)
    res = np.asarray(log.result, dtype=float)
    nm = np.asarray(log.no_memory, dtype=float)
    ok = np.isfinite(nm)
    d = res[ok] - nm[ok]
    di = idx[ok]
    s = np.zeros(n_items)
    c = np.zeros(n_items)
    np.add.at(s, di, d)
    np.add.at(c, di, 1.0)
    seen = c > 0
    mu = float(d.mean()) if d.size else 0.0
    s2 = float(d.var()) if d.size > 1 else 0.25
    dbar = np.where(seen, s / np.maximum(c, 1.0), mu)
    if seen.sum() > 1:
        tau2 = max(float(np.var(dbar[seen])) - s2 * float(np.mean(1.0 / c[seen])), 1e-3)
    else:
        tau2 = 1e-3
    w = c / (c + s2 / tau2)
    lift = mu + w * (dbar - mu)
    wins = np.zeros(n_items)
    shows = np.zeros(n_items)
    np.add.at(wins, idx, res)
    np.add.at(shows, idx, 1.0)
    rate = (wins + 1.0) / (shows + 2.0)
    return lift + 1e-3 * rate
