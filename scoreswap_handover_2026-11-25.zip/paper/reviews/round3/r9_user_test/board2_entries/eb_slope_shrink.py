"""R9 honest entry (a): estimate how well the old scores still point the right way for the new
model, from the random checks, and shrink them by that much (empirical Bayes on the slope).

Idea: the reader's success on a checked cell ~ a + b * (old score - bank mean). b = 1 means the
old order transfers fully, b = 0 means it carries nothing. b is estimated by least squares on the
k checked cells and shrunk toward a prior b0 = 0.5 with the weight of n0 = 8 pseudo-checks; a is
the reader's checked success rate shrunk toward the owner's mean. Checked items then take in
their own fresh results (Beta update, the old value worth 2 checks). No checks: b = b0.
"""
import numpy as np

KIND = "swap_day_rule"
NAME = "eb_slope_shrink"
DESCRIPTION = "Shrink the old ema scores by a slope estimated from k random checks (prior 0.5, weight 8)."
B0 = 0.5
N0 = 8.0


def rule(bank, candidates, swap, checks):
    old = np.asarray(bank.mix_score["ema_grade"], dtype=float)
    m_old = float(old.mean())
    answers = checks.request(random=checks.budget) if checks.budget > 0 else []
    n = len(answers)
    if n:
        x = np.array([old[a.item_index] for a in answers]) - m_old
        y = np.array([a.result for a in answers])
        vx = float((x * x).sum())
        b_hat = float((x * (y - y.mean())).sum() / vx) if vx > 1e-9 else B0
        b = (N0 * B0 + n * b_hat) / (N0 + n)
        a = (N0 * m_old + y.sum()) / (N0 + n)
    else:
        b, a = B0, m_old
    b = float(np.clip(b, 0.0, 1.5))
    u = np.clip(a + b * (old - m_old), 0.0, 1.0)
    hits = np.zeros(bank.n)
    tries = np.zeros(bank.n)
    for ans in answers:
        hits[ans.item_index] += ans.result
        tries[ans.item_index] += 1.0
    u = (2.0 * u + hits) / (2.0 + tries)
    return {"u": u, "p": u}
