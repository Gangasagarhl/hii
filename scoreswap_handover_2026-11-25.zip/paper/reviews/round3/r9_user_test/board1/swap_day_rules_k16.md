# Board of swap-day rules, budget k = 16

Study `sim`. Every entry was re-run by the harness from the released tables, sealed (one fresh process per call).

**Ranked on the public DEV half: provisional.** The dev half is public, so an entry may have been tuned on it or may even have memorised it. The real ranking is on the held-out test half, which the maintainers score from submitted entry files.

Brackets: 95 % intervals. Two-way = tasks and tips both treated as sampled: msr.metrics.robust_variance, the delete-one-cluster jackknife over task ids and tips (a tip that recurs in several stream orders is one cluster; the primary interval). Theta's bracket is the union of its two-way and task-only Fieller sets (msr.metrics.theta_tests). Task-only = the task-id cluster bootstrap, 10,000 draws, seed 0 (secondary; the paper's tables of rule values use this one, so on all evaluation tasks they match it digit for digit).

Ranked by first-shown success per kind of swap (higher is better), with the difference from keep on the same tasks and draws and its two-way 95 % interval; 'vs keep' groups the ranks: above keep, below keep, or not distinguishable (the interval holds 0, so the order between such rows means little). Then regret, the level-corrected log score (when the rule returns p) and the checks used. To relate a row to the paper's table, use the task-only interval with --split all (maintainers): it is the paper's.

## same-maker upgrades (ddxplus)

| rank | rule | source | first-shown success (dev) | minus keep (dev) | vs keep | regret | theta (order kept) | order | log score (lc) | checks used |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | keep | paper (ema_grade) | 0.688 [0.587, 0.788] (task-only [0.612, 0.759]) | - | (keep) | 0.174 | no home signal | not identifiable | -0.742 | 0.0 |
| 2 | rank_focus_shrink | outside entry | 0.687 [0.591, 0.783] (task-only [0.610, 0.762]) | -0.001 [-0.041, 0.040] | not distinguishable | 0.175 | 0.623 [0.378, 0.983] | 0.92 [0.52, 2.60] | -0.703 | 16.0 |
| 3 | fixed_0.5 | paper (ema_grade) | 0.683 [0.576, 0.790] (task-only [0.605, 0.759]) | -0.004 [-0.022, 0.013] | not distinguishable | 0.179 | no home signal | not identifiable | -0.688 | 0.0 |
| 4 | powerprior_16 | paper (ema_grade) | 0.679 [0.575, 0.783] (task-only [0.605, 0.749]) | -0.009 [-0.046, 0.029] | not distinguishable | 0.183 | no home signal | not identifiable | -0.700 | 16.0 |
| 5 | retest_16 | paper (ema_grade) | 0.675 [0.560, 0.790] (task-only [0.605, 0.741]) | -0.013 [-0.073, 0.048] | not distinguishable | 0.187 | no home signal | not identifiable | -0.710 | 16.0 |
| 6 | audit_16 | paper (ema_grade) | 0.673 [0.574, 0.772] (task-only [0.599, 0.743]) | -0.015 [-0.033, 0.003] | not distinguishable | 0.189 | no home signal | not identifiable | -0.733 | 16.0 |
| 7 | recal_16 | paper (ema_grade) | 0.667 [0.566, 0.768] (task-only [0.593, 0.738]) | -0.020 [-0.038, -0.002] | below keep | 0.195 | no home signal | not identifiable | -0.708 | 16.0 |
| 8 | relevance_gate | outside entry | 0.656 [0.550, 0.762] (task-only [0.576, 0.732]) | -0.031 [-0.056, -0.006] | below keep | 0.205 | 0.625 [0.352, 1.027] | 0.92 [0.48, 2.73] | -0.726 | 0.0 |
| 9 | wipe | paper (ema_grade) | 0.647 [0.557, 0.738] (task-only [0.568, 0.723]) | -0.040 [-0.104, 0.023] | not distinguishable | 0.214 | no home signal | not identifiable | -0.712 | 0.0 |

## same-maker downgrades (ddxplus)

| rank | rule | source | first-shown success (dev) | minus keep (dev) | vs keep | regret | theta (order kept) | order | log score (lc) | checks used |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | relevance_gate | outside entry | 0.585 [0.471, 0.699] (task-only [0.513, 0.658]) | 0.031 [-0.002, 0.064] | not distinguishable | 0.237 | 0.801 [0.427, 1.632] | 0.94 [0.51, 2.45] | -0.706 | 0.0 |
| 2 | fixed_0.5 | paper (ema_grade) | 0.576 [0.461, 0.691] (task-only [0.500, 0.650]) | 0.022 [-0.005, 0.049] | not distinguishable | 0.246 | no home signal | not identifiable | -0.677 | 0.0 |
| 3 | rank_focus_shrink | outside entry | 0.555 [0.464, 0.646] (task-only [0.482, 0.628]) | 0.002 [-0.104, 0.107] | not distinguishable | 0.266 | 0.489 [0.243, 1.188] | 0.57 [0.28, 1.86] | -0.685 | 16.0 |
| 4 | keep | paper (ema_grade) | 0.554 [0.455, 0.652] (task-only [0.477, 0.632]) | - | (keep) | 0.268 | no home signal | not identifiable | -0.758 | 0.0 |
| 5 | recal_16 | paper (ema_grade) | 0.545 [0.448, 0.643] (task-only [0.474, 0.617]) | -0.008 [-0.034, 0.017] | not distinguishable | 0.276 | no home signal | not identifiable | -0.696 | 16.0 |
| 6 | audit_16 | paper (ema_grade) | 0.543 [0.453, 0.633] (task-only [0.470, 0.617]) | -0.011 [-0.029, 0.008] | not distinguishable | 0.279 | no home signal | not identifiable | -0.739 | 16.0 |
| 7 | powerprior_16 | paper (ema_grade) | 0.537 [0.452, 0.623] (task-only [0.463, 0.612]) | -0.016 [-0.068, 0.035] | not distinguishable | 0.284 | no home signal | not identifiable | -0.688 | 16.0 |
| 8 | wipe | paper (ema_grade) | 0.522 [0.435, 0.610] (task-only [0.438, 0.607]) | -0.031 [-0.096, 0.034] | not distinguishable | 0.299 | no home signal | not identifiable | -0.692 | 0.0 |
| 9 | retest_16 | paper (ema_grade) | 0.514 [0.420, 0.607] (task-only [0.434, 0.593]) | -0.040 [-0.125, 0.045] | not distinguishable | 0.308 | no home signal | not identifiable | -0.690 | 16.0 |

## cross-maker swaps (ddxplus)

| rank | rule | source | first-shown success (dev) | minus keep (dev) | vs keep | regret | theta (order kept) | order | log score (lc) | checks used |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | relevance_gate | outside entry | 0.573 [0.509, 0.637] (task-only [0.512, 0.632]) | 0.010 [-0.010, 0.030] | not distinguishable | 0.275 | 0.150 [-0.073, 0.342] | 0.17 [-0.10, 0.38] | -0.771 | 0.0 |
| 2 | rank_focus_shrink | outside entry | 0.568 [0.513, 0.624] (task-only [0.514, 0.622]) | 0.006 [-0.037, 0.048] | not distinguishable | 0.279 | 0.263 [0.126, 0.421] | 0.30 [0.16, 0.48] | -0.708 | 16.0 |
| 3 | keep | paper (ema_grade) | 0.562 [0.494, 0.631] (task-only [0.501, 0.623]) | - | (keep) | 0.285 | no home signal | not identifiable | -0.840 | 0.0 |
| 4 | fixed_0.5 | paper (ema_grade) | 0.561 [0.495, 0.628] (task-only [0.499, 0.622]) | -0.001 [-0.016, 0.014] | not distinguishable | 0.286 | no home signal | not identifiable | -0.718 | 0.0 |
| 5 | retest_16 | paper (ema_grade) | 0.557 [0.495, 0.618] (task-only [0.496, 0.615]) | -0.006 [-0.060, 0.048] | not distinguishable | 0.290 | no home signal | not identifiable | -0.700 | 16.0 |
| 6 | audit_16 | paper (ema_grade) | 0.553 [0.495, 0.610] (task-only [0.495, 0.609]) | -0.010 [-0.037, 0.017] | not distinguishable | 0.295 | no home signal | not identifiable | -0.782 | 16.0 |
| 7 | recal_16 | paper (ema_grade) | 0.550 [0.494, 0.607] (task-only [0.495, 0.605]) | -0.012 [-0.044, 0.020] | not distinguishable | 0.297 | no home signal | not identifiable | -0.725 | 16.0 |
| 8 | powerprior_16 | paper (ema_grade) | 0.542 [0.482, 0.601] (task-only [0.483, 0.599]) | -0.021 [-0.061, 0.020] | not distinguishable | 0.305 | no home signal | not identifiable | -0.707 | 16.0 |
| 9 | wipe | paper (ema_grade) | 0.540 [0.480, 0.600] (task-only [0.483, 0.597]) | -0.022 [-0.080, 0.035] | not distinguishable | 0.307 | no home signal | not identifiable | -0.700 | 0.0 |

## home cells (each owner reading its own bank) (ddxplus)

| rank | rule | source | first-shown success (dev) | minus keep (dev) | vs keep | regret | theta (order kept) | order | log score (lc) | checks used |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | keep | paper (ema_grade) | 0.679 [0.607, 0.751] (task-only [0.618, 0.737]) | - | (keep) | 0.185 | no home signal | not identifiable | -0.725 | 0.0 |
| 2 | relevance_gate | outside entry | 0.674 [0.610, 0.738] (task-only [0.616, 0.730]) | -0.004 [-0.039, 0.030] | not distinguishable | 0.190 | 0.985 [0.853, 1.142] | 0.93 [0.75, 1.19] | -0.698 | 0.0 |
| 3 | fixed_0.5 | paper (ema_grade) | 0.670 [0.605, 0.734] (task-only [0.611, 0.725]) | -0.009 [-0.019, 0.002] | not distinguishable | 0.194 | no home signal | not identifiable | -0.675 | 0.0 |
| 4 | powerprior_16 | paper (ema_grade) | 0.665 [0.600, 0.730] (task-only [0.608, 0.720]) | -0.014 [-0.056, 0.029] | not distinguishable | 0.199 | no home signal | not identifiable | -0.691 | 16.0 |
| 5 | audit_16 | paper (ema_grade) | 0.658 [0.590, 0.726] (task-only [0.601, 0.713]) | -0.020 [-0.037, -0.004] | below keep | 0.206 | no home signal | not identifiable | -0.719 | 16.0 |
| 6 | recal_16 | paper (ema_grade) | 0.653 [0.587, 0.718] (task-only [0.596, 0.706]) | -0.026 [-0.043, -0.009] | below keep | 0.211 | no home signal | not identifiable | -0.694 | 16.0 |
| 7 | rank_focus_shrink | outside entry | 0.641 [0.572, 0.709] (task-only [0.588, 0.692]) | -0.038 [-0.068, -0.008] | below keep | 0.223 | 0.781 [0.616, 0.924] | 0.74 [0.55, 0.94] | -0.685 | 16.0 |
| 8 | retest_16 | paper (ema_grade) | 0.638 [0.565, 0.712] (task-only [0.582, 0.694]) | -0.040 [-0.085, 0.005] | not distinguishable | 0.225 | no home signal | not identifiable | -0.698 | 16.0 |
| 9 | wipe | paper (ema_grade) | 0.585 [0.505, 0.665] (task-only [0.520, 0.649]) | -0.094 [-0.164, -0.023] | below keep | 0.279 | no home signal | not identifiable | -0.703 | 0.0 |

## Every ordered pair (first-shown success, dev)

| owner -> reader | audit_16 | fixed_0.5 | keep | powerprior_16 | rank_focus_shrink | recal_16 | relevance_gate | retest_16 | wipe |
|---|---|---|---|---|---|---|---|---|---|
| sim-a-old -> sim-a-old | 0.595 | 0.625 | 0.625 | 0.584 | 0.603 | 0.602 | 0.634 | 0.585 | 0.482 |
| sim-a-old -> sim-a-new | 0.699 | 0.714 | 0.723 | 0.707 | 0.713 | 0.701 | 0.696 | 0.695 | 0.652 |
| sim-a-old -> sim-b-old | 0.513 | 0.491 | 0.509 | 0.484 | 0.515 | 0.524 | 0.518 | 0.497 | 0.491 |
| sim-a-old -> sim-b-new | 0.608 | 0.589 | 0.598 | 0.605 | 0.612 | 0.595 | 0.589 | 0.600 | 0.643 |
| sim-a-new -> sim-a-old | 0.596 | 0.634 | 0.616 | 0.583 | 0.617 | 0.589 | 0.643 | 0.564 | 0.554 |
| sim-a-new -> sim-a-new | 0.701 | 0.688 | 0.705 | 0.760 | 0.660 | 0.684 | 0.723 | 0.713 | 0.705 |
| sim-a-new -> sim-b-old | 0.454 | 0.509 | 0.491 | 0.442 | 0.480 | 0.459 | 0.518 | 0.457 | 0.411 |
| sim-a-new -> sim-b-new | 0.612 | 0.616 | 0.607 | 0.620 | 0.614 | 0.603 | 0.652 | 0.591 | 0.616 |
| sim-b-old -> sim-a-old | 0.540 | 0.545 | 0.554 | 0.543 | 0.583 | 0.522 | 0.562 | 0.561 | 0.536 |
| sim-b-old -> sim-a-new | 0.598 | 0.607 | 0.625 | 0.548 | 0.593 | 0.594 | 0.625 | 0.569 | 0.545 |
| sim-b-old -> sim-b-old | 0.625 | 0.634 | 0.634 | 0.618 | 0.616 | 0.617 | 0.616 | 0.623 | 0.545 |
| sim-b-old -> sim-b-new | 0.646 | 0.652 | 0.652 | 0.651 | 0.660 | 0.633 | 0.616 | 0.655 | 0.643 |
| sim-b-new -> sim-a-old | 0.524 | 0.527 | 0.536 | 0.510 | 0.548 | 0.512 | 0.536 | 0.543 | 0.509 |
| sim-b-new -> sim-a-new | 0.572 | 0.607 | 0.580 | 0.584 | 0.600 | 0.595 | 0.580 | 0.635 | 0.571 |
| sim-b-new -> sim-b-old | 0.490 | 0.518 | 0.491 | 0.492 | 0.494 | 0.502 | 0.527 | 0.463 | 0.491 |
| sim-b-new -> sim-b-new | 0.712 | 0.732 | 0.750 | 0.699 | 0.683 | 0.707 | 0.723 | 0.632 | 0.607 |
