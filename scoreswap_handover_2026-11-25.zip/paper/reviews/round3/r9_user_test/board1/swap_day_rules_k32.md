# Board of swap-day rules, budget k = 32

Study `sim`. Every entry was re-run by the harness from the released tables, sealed (one fresh process per call).

**Ranked on the public DEV half: provisional.** The dev half is public, so an entry may have been tuned on it or may even have memorised it. The real ranking is on the held-out test half, which the maintainers score from submitted entry files.

Brackets: 95 % intervals. Two-way = tasks and tips both treated as sampled: msr.metrics.robust_variance, the delete-one-cluster jackknife over task ids and tips (a tip that recurs in several stream orders is one cluster; the primary interval). Theta's bracket is the union of its two-way and task-only Fieller sets (msr.metrics.theta_tests). Task-only = the task-id cluster bootstrap, 10,000 draws, seed 0 (secondary; the paper's tables of rule values use this one, so on all evaluation tasks they match it digit for digit).

Ranked by first-shown success per kind of swap (higher is better), with the difference from keep on the same tasks and draws and its two-way 95 % interval; 'vs keep' groups the ranks: above keep, below keep, or not distinguishable (the interval holds 0, so the order between such rows means little). Then regret, the level-corrected log score (when the rule returns p) and the checks used. To relate a row to the paper's table, use the task-only interval with --split all (maintainers): it is the paper's.

## same-maker upgrades (ddxplus)

| rank | rule | source | first-shown success (dev) | minus keep (dev) | vs keep | regret | theta (order kept) | order | log score (lc) | checks used |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | keep | paper (ema_grade) | 0.688 [0.587, 0.788] (task-only [0.612, 0.759]) | - | (keep) | 0.174 | no home signal | not identifiable | -0.742 | 0.0 |
| 2 | fixed_0.5 | paper (ema_grade) | 0.683 [0.576, 0.790] (task-only [0.605, 0.759]) | -0.004 [-0.022, 0.013] | not distinguishable | 0.179 | no home signal | not identifiable | -0.688 | 0.0 |
| 3 | powerprior_32 | paper (ema_grade) | 0.681 [0.574, 0.789] (task-only [0.607, 0.751]) | -0.006 [-0.045, 0.032] | not distinguishable | 0.180 | no home signal | not identifiable | -0.698 | 32.0 |
| 4 | audit_32 | paper (ema_grade) | 0.678 [0.577, 0.779] (task-only [0.604, 0.750]) | -0.009 [-0.022, 0.003] | not distinguishable | 0.184 | no home signal | not identifiable | -0.736 | 32.0 |
| 5 | recal_32 | paper (ema_grade) | 0.673 [0.567, 0.779] (task-only [0.597, 0.746]) | -0.014 [-0.033, 0.005] | not distinguishable | 0.188 | no home signal | not identifiable | -0.702 | 32.0 |
| 6 | rank_focus_shrink | outside entry | 0.668 [0.566, 0.769] (task-only [0.595, 0.739]) | -0.020 [-0.073, 0.033] | not distinguishable | 0.194 | 0.624 [0.371, 1.007] | 0.92 [0.53, 2.59] | -0.706 | 32.0 |
| 7 | relevance_gate | outside entry | 0.656 [0.550, 0.762] (task-only [0.576, 0.732]) | -0.031 [-0.056, -0.006] | below keep | 0.205 | 0.625 [0.352, 1.027] | 0.92 [0.48, 2.73] | -0.726 | 0.0 |
| 8 | retest_32 | paper (ema_grade) | 0.653 [0.537, 0.768] (task-only [0.577, 0.727]) | -0.035 [-0.102, 0.033] | not distinguishable | 0.209 | no home signal | not identifiable | -0.706 | 32.0 |
| 9 | wipe | paper (ema_grade) | 0.647 [0.557, 0.738] (task-only [0.568, 0.723]) | -0.040 [-0.104, 0.023] | not distinguishable | 0.214 | no home signal | not identifiable | -0.712 | 0.0 |

## same-maker downgrades (ddxplus)

| rank | rule | source | first-shown success (dev) | minus keep (dev) | vs keep | regret | theta (order kept) | order | log score (lc) | checks used |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | relevance_gate | outside entry | 0.585 [0.471, 0.699] (task-only [0.513, 0.658]) | 0.031 [-0.002, 0.064] | not distinguishable | 0.237 | 0.801 [0.427, 1.632] | 0.94 [0.51, 2.45] | -0.706 | 0.0 |
| 2 | fixed_0.5 | paper (ema_grade) | 0.576 [0.461, 0.691] (task-only [0.500, 0.650]) | 0.022 [-0.005, 0.049] | not distinguishable | 0.246 | no home signal | not identifiable | -0.677 | 0.0 |
| 3 | rank_focus_shrink | outside entry | 0.557 [0.481, 0.632] (task-only [0.491, 0.621]) | 0.003 [-0.089, 0.096] | not distinguishable | 0.265 | 0.651 [0.306, 1.690] | 0.76 [0.36, 2.54] | -0.683 | 32.0 |
| 4 | recal_32 | paper (ema_grade) | 0.556 [0.453, 0.658] (task-only [0.484, 0.628]) | 0.002 [-0.025, 0.029] | not distinguishable | 0.266 | no home signal | not identifiable | -0.688 | 32.0 |
| 5 | keep | paper (ema_grade) | 0.554 [0.455, 0.652] (task-only [0.477, 0.632]) | - | (keep) | 0.268 | no home signal | not identifiable | -0.758 | 0.0 |
| 6 | audit_32 | paper (ema_grade) | 0.547 [0.454, 0.640] (task-only [0.473, 0.622]) | -0.007 [-0.018, 0.004] | not distinguishable | 0.275 | no home signal | not identifiable | -0.746 | 32.0 |
| 7 | powerprior_32 | paper (ema_grade) | 0.538 [0.453, 0.624] (task-only [0.464, 0.613]) | -0.015 [-0.068, 0.037] | not distinguishable | 0.283 | no home signal | not identifiable | -0.686 | 32.0 |
| 8 | wipe | paper (ema_grade) | 0.522 [0.435, 0.610] (task-only [0.438, 0.607]) | -0.031 [-0.096, 0.034] | not distinguishable | 0.299 | no home signal | not identifiable | -0.692 | 0.0 |
| 9 | retest_32 | paper (ema_grade) | 0.521 [0.432, 0.611] (task-only [0.447, 0.596]) | -0.032 [-0.124, 0.059] | not distinguishable | 0.300 | no home signal | not identifiable | -0.691 | 32.0 |

## cross-maker swaps (ddxplus)

| rank | rule | source | first-shown success (dev) | minus keep (dev) | vs keep | regret | theta (order kept) | order | log score (lc) | checks used |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | rank_focus_shrink | outside entry | 0.586 [0.530, 0.641] (task-only [0.535, 0.637]) | 0.023 [-0.024, 0.071] | not distinguishable | 0.261 | 0.354 [0.197, 0.575] | 0.41 [0.23, 0.69] | -0.707 | 32.0 |
| 2 | retest_32 | paper (ema_grade) | 0.577 [0.518, 0.636] (task-only [0.521, 0.634]) | 0.015 [-0.041, 0.070] | not distinguishable | 0.270 | no home signal | not identifiable | -0.701 | 32.0 |
| 3 | relevance_gate | outside entry | 0.573 [0.509, 0.637] (task-only [0.512, 0.632]) | 0.010 [-0.010, 0.030] | not distinguishable | 0.275 | 0.150 [-0.073, 0.342] | 0.17 [-0.10, 0.38] | -0.771 | 0.0 |
| 4 | keep | paper (ema_grade) | 0.562 [0.494, 0.631] (task-only [0.501, 0.623]) | - | (keep) | 0.285 | no home signal | not identifiable | -0.840 | 0.0 |
| 5 | fixed_0.5 | paper (ema_grade) | 0.561 [0.495, 0.628] (task-only [0.499, 0.622]) | -0.001 [-0.016, 0.014] | not distinguishable | 0.286 | no home signal | not identifiable | -0.718 | 0.0 |
| 6 | audit_32 | paper (ema_grade) | 0.554 [0.496, 0.613] (task-only [0.496, 0.611]) | -0.008 [-0.035, 0.019] | not distinguishable | 0.293 | no home signal | not identifiable | -0.789 | 32.0 |
| 7 | recal_32 | paper (ema_grade) | 0.549 [0.491, 0.606] (task-only [0.492, 0.604]) | -0.014 [-0.049, 0.021] | not distinguishable | 0.299 | no home signal | not identifiable | -0.714 | 32.0 |
| 8 | powerprior_32 | paper (ema_grade) | 0.542 [0.482, 0.602] (task-only [0.483, 0.600]) | -0.021 [-0.062, 0.021] | not distinguishable | 0.305 | no home signal | not identifiable | -0.705 | 32.0 |
| 9 | wipe | paper (ema_grade) | 0.540 [0.480, 0.600] (task-only [0.483, 0.597]) | -0.022 [-0.080, 0.035] | not distinguishable | 0.307 | no home signal | not identifiable | -0.700 | 0.0 |

## home cells (each owner reading its own bank) (ddxplus)

| rank | rule | source | first-shown success (dev) | minus keep (dev) | vs keep | regret | theta (order kept) | order | log score (lc) | checks used |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | keep | paper (ema_grade) | 0.679 [0.607, 0.751] (task-only [0.618, 0.737]) | - | (keep) | 0.185 | no home signal | not identifiable | -0.725 | 0.0 |
| 2 | relevance_gate | outside entry | 0.674 [0.610, 0.738] (task-only [0.616, 0.730]) | -0.004 [-0.039, 0.030] | not distinguishable | 0.190 | 0.985 [0.853, 1.142] | 0.93 [0.75, 1.19] | -0.698 | 0.0 |
| 3 | powerprior_32 | paper (ema_grade) | 0.670 [0.606, 0.734] (task-only [0.612, 0.725]) | -0.008 [-0.051, 0.034] | not distinguishable | 0.194 | no home signal | not identifiable | -0.689 | 32.0 |
| 4 | fixed_0.5 | paper (ema_grade) | 0.670 [0.605, 0.734] (task-only [0.611, 0.725]) | -0.009 [-0.019, 0.002] | not distinguishable | 0.194 | no home signal | not identifiable | -0.675 | 0.0 |
| 5 | audit_32 | paper (ema_grade) | 0.667 [0.598, 0.736] (task-only [0.608, 0.723]) | -0.012 [-0.022, -0.001] | below keep | 0.197 | no home signal | not identifiable | -0.721 | 32.0 |
| 6 | recal_32 | paper (ema_grade) | 0.662 [0.595, 0.729] (task-only [0.604, 0.717]) | -0.016 [-0.028, -0.004] | below keep | 0.202 | no home signal | not identifiable | -0.687 | 32.0 |
| 7 | retest_32 | paper (ema_grade) | 0.645 [0.579, 0.711] (task-only [0.590, 0.701]) | -0.033 [-0.075, 0.008] | not distinguishable | 0.219 | no home signal | not identifiable | -0.699 | 32.0 |
| 8 | rank_focus_shrink | outside entry | 0.645 [0.581, 0.709] (task-only [0.591, 0.699]) | -0.033 [-0.070, 0.003] | not distinguishable | 0.219 | 0.784 [0.588, 1.012] | 0.74 [0.53, 1.02] | -0.692 | 32.0 |
| 9 | wipe | paper (ema_grade) | 0.585 [0.505, 0.665] (task-only [0.520, 0.649]) | -0.094 [-0.164, -0.023] | below keep | 0.279 | no home signal | not identifiable | -0.703 | 0.0 |

## Every ordered pair (first-shown success, dev)

| owner -> reader | audit_32 | fixed_0.5 | keep | powerprior_32 | rank_focus_shrink | recal_32 | relevance_gate | retest_32 | wipe |
|---|---|---|---|---|---|---|---|---|---|
| sim-a-old -> sim-a-old | 0.609 | 0.625 | 0.625 | 0.596 | 0.602 | 0.611 | 0.634 | 0.581 | 0.482 |
| sim-a-old -> sim-a-new | 0.707 | 0.714 | 0.723 | 0.715 | 0.685 | 0.704 | 0.696 | 0.647 | 0.652 |
| sim-a-old -> sim-b-old | 0.515 | 0.491 | 0.509 | 0.485 | 0.550 | 0.530 | 0.518 | 0.509 | 0.491 |
| sim-a-old -> sim-b-new | 0.605 | 0.589 | 0.598 | 0.603 | 0.600 | 0.598 | 0.589 | 0.581 | 0.643 |
| sim-a-new -> sim-a-old | 0.604 | 0.634 | 0.616 | 0.584 | 0.614 | 0.602 | 0.643 | 0.562 | 0.554 |
| sim-a-new -> sim-a-new | 0.702 | 0.688 | 0.705 | 0.762 | 0.677 | 0.692 | 0.723 | 0.687 | 0.705 |
| sim-a-new -> sim-b-old | 0.460 | 0.509 | 0.491 | 0.444 | 0.525 | 0.458 | 0.518 | 0.473 | 0.411 |
| sim-a-new -> sim-b-new | 0.612 | 0.616 | 0.607 | 0.619 | 0.618 | 0.600 | 0.652 | 0.617 | 0.616 |
| sim-b-old -> sim-a-old | 0.539 | 0.545 | 0.554 | 0.545 | 0.630 | 0.512 | 0.562 | 0.617 | 0.536 |
| sim-b-old -> sim-a-new | 0.605 | 0.607 | 0.625 | 0.552 | 0.585 | 0.588 | 0.625 | 0.585 | 0.545 |
| sim-b-old -> sim-b-old | 0.630 | 0.634 | 0.634 | 0.620 | 0.615 | 0.624 | 0.616 | 0.654 | 0.545 |
| sim-b-old -> sim-b-new | 0.649 | 0.652 | 0.652 | 0.647 | 0.651 | 0.642 | 0.616 | 0.658 | 0.643 |
| sim-b-new -> sim-a-old | 0.525 | 0.527 | 0.536 | 0.507 | 0.574 | 0.505 | 0.536 | 0.581 | 0.509 |
| sim-b-new -> sim-a-new | 0.572 | 0.607 | 0.580 | 0.581 | 0.605 | 0.597 | 0.580 | 0.655 | 0.571 |
| sim-b-new -> sim-b-old | 0.489 | 0.518 | 0.491 | 0.493 | 0.500 | 0.509 | 0.527 | 0.480 | 0.491 |
| sim-b-new -> sim-b-new | 0.727 | 0.732 | 0.750 | 0.702 | 0.685 | 0.722 | 0.723 | 0.659 | 0.607 |
