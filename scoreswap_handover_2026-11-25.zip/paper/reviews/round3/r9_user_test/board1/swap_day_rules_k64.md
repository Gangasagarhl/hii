# Board of swap-day rules, budget k = 64

Study `sim`. Every entry was re-run by the harness from the released tables, sealed (one fresh process per call).

**Ranked on the public DEV half: provisional.** The dev half is public, so an entry may have been tuned on it or may even have memorised it. The real ranking is on the held-out test half, which the maintainers score from submitted entry files.

Brackets: 95 % intervals. Two-way = tasks and tips both treated as sampled: msr.metrics.robust_variance, the delete-one-cluster jackknife over task ids and tips (a tip that recurs in several stream orders is one cluster; the primary interval). Theta's bracket is the union of its two-way and task-only Fieller sets (msr.metrics.theta_tests). Task-only = the task-id cluster bootstrap, 10,000 draws, seed 0 (secondary; the paper's tables of rule values use this one, so on all evaluation tasks they match it digit for digit).

Ranked by first-shown success per kind of swap (higher is better), with the difference from keep on the same tasks and draws and its two-way 95 % interval; 'vs keep' groups the ranks: above keep, below keep, or not distinguishable (the interval holds 0, so the order between such rows means little). Then regret, the level-corrected log score (when the rule returns p) and the checks used. To relate a row to the paper's table, use the task-only interval with --split all (maintainers): it is the paper's.

## same-maker upgrades (ddxplus)

| rank | rule | source | first-shown success (dev) | minus keep (dev) | vs keep | regret | theta (order kept) | order | log score (lc) | checks used |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | keep | paper (ema_grade) | 0.688 [0.587, 0.788] (task-only [0.612, 0.759]) | - | (keep) | 0.174 | no home signal | not identifiable | -0.742 | 0.0 |
| 2 | powerprior_64 | paper (ema_grade) | 0.685 [0.576, 0.795] (task-only [0.611, 0.755]) | -0.002 [-0.041, 0.036] | not distinguishable | 0.176 | no home signal | not identifiable | -0.697 | 64.0 |
| 3 | fixed_0.5 | paper (ema_grade) | 0.683 [0.576, 0.790] (task-only [0.605, 0.759]) | -0.004 [-0.022, 0.013] | not distinguishable | 0.179 | no home signal | not identifiable | -0.688 | 0.0 |
| 4 | audit_64 | paper (ema_grade) | 0.680 [0.578, 0.782] (task-only [0.606, 0.753]) | -0.007 [-0.021, 0.006] | not distinguishable | 0.181 | no home signal | not identifiable | -0.737 | 64.0 |
| 5 | recal_64 | paper (ema_grade) | 0.677 [0.569, 0.784] (task-only [0.600, 0.750]) | -0.011 [-0.031, 0.009] | not distinguishable | 0.185 | no home signal | not identifiable | -0.696 | 64.0 |
| 6 | relevance_gate | outside entry | 0.656 [0.550, 0.762] (task-only [0.576, 0.732]) | -0.031 [-0.056, -0.006] | below keep | 0.205 | 0.625 [0.352, 1.027] | 0.92 [0.48, 2.73] | -0.726 | 0.0 |
| 7 | rank_focus_shrink | outside entry | 0.652 [0.555, 0.749] (task-only [0.578, 0.725]) | -0.036 [-0.087, 0.016] | not distinguishable | 0.210 | 0.632 [0.387, 1.003] | 0.93 [0.55, 2.79] | -0.708 | 50.5 |
| 8 | wipe | paper (ema_grade) | 0.647 [0.557, 0.738] (task-only [0.568, 0.723]) | -0.040 [-0.104, 0.023] | not distinguishable | 0.214 | no home signal | not identifiable | -0.712 | 0.0 |
| 9 | retest_64 | paper (ema_grade) | 0.635 [0.537, 0.734] (task-only [0.564, 0.706]) | -0.052 [-0.114, 0.010] | not distinguishable | 0.227 | no home signal | not identifiable | -0.710 | 64.0 |

## same-maker downgrades (ddxplus)

| rank | rule | source | first-shown success (dev) | minus keep (dev) | vs keep | regret | theta (order kept) | order | log score (lc) | checks used |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | relevance_gate | outside entry | 0.585 [0.471, 0.699] (task-only [0.513, 0.658]) | 0.031 [-0.002, 0.064] | not distinguishable | 0.237 | 0.801 [0.427, 1.632] | 0.94 [0.51, 2.45] | -0.706 | 0.0 |
| 2 | fixed_0.5 | paper (ema_grade) | 0.576 [0.461, 0.691] (task-only [0.500, 0.650]) | 0.022 [-0.005, 0.049] | not distinguishable | 0.246 | no home signal | not identifiable | -0.677 | 0.0 |
| 3 | recal_64 | paper (ema_grade) | 0.566 [0.456, 0.676] (task-only [0.493, 0.639]) | 0.012 [-0.019, 0.044] | not distinguishable | 0.255 | no home signal | not identifiable | -0.679 | 64.0 |
| 4 | rank_focus_shrink | outside entry | 0.558 [0.486, 0.630] (task-only [0.493, 0.621]) | 0.005 [-0.080, 0.089] | not distinguishable | 0.263 | 0.657 [0.313, 1.620] | 0.77 [0.40, 2.29] | -0.691 | 50.5 |
| 5 | keep | paper (ema_grade) | 0.554 [0.455, 0.652] (task-only [0.477, 0.632]) | - | (keep) | 0.268 | no home signal | not identifiable | -0.758 | 0.0 |
| 6 | audit_64 | paper (ema_grade) | 0.551 [0.454, 0.647] (task-only [0.475, 0.626]) | -0.003 [-0.008, 0.001] | not distinguishable | 0.271 | no home signal | not identifiable | -0.754 | 64.0 |
| 7 | powerprior_64 | paper (ema_grade) | 0.536 [0.450, 0.623] (task-only [0.461, 0.612]) | -0.017 [-0.073, 0.038] | not distinguishable | 0.285 | no home signal | not identifiable | -0.684 | 64.0 |
| 8 | retest_64 | paper (ema_grade) | 0.532 [0.457, 0.607] (task-only [0.465, 0.599]) | -0.022 [-0.119, 0.076] | not distinguishable | 0.289 | no home signal | not identifiable | -0.693 | 64.0 |
| 9 | wipe | paper (ema_grade) | 0.522 [0.435, 0.610] (task-only [0.438, 0.607]) | -0.031 [-0.096, 0.034] | not distinguishable | 0.299 | no home signal | not identifiable | -0.692 | 0.0 |

## cross-maker swaps (ddxplus)

| rank | rule | source | first-shown success (dev) | minus keep (dev) | vs keep | regret | theta (order kept) | order | log score (lc) | checks used |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | rank_focus_shrink | outside entry | 0.584 [0.527, 0.642] (task-only [0.532, 0.638]) | 0.022 [-0.030, 0.074] | not distinguishable | 0.263 | 0.426 [0.227, 0.703] | 0.49 [0.27, 0.83] | -0.708 | 50.5 |
| 2 | retest_64 | paper (ema_grade) | 0.578 [0.517, 0.638] (task-only [0.524, 0.632]) | 0.015 [-0.041, 0.071] | not distinguishable | 0.270 | no home signal | not identifiable | -0.704 | 64.0 |
| 3 | relevance_gate | outside entry | 0.573 [0.509, 0.637] (task-only [0.512, 0.632]) | 0.010 [-0.010, 0.030] | not distinguishable | 0.275 | 0.150 [-0.073, 0.342] | 0.17 [-0.10, 0.38] | -0.771 | 0.0 |
| 4 | keep | paper (ema_grade) | 0.562 [0.494, 0.631] (task-only [0.501, 0.623]) | - | (keep) | 0.285 | no home signal | not identifiable | -0.840 | 0.0 |
| 5 | fixed_0.5 | paper (ema_grade) | 0.561 [0.495, 0.628] (task-only [0.499, 0.622]) | -0.001 [-0.016, 0.014] | not distinguishable | 0.286 | no home signal | not identifiable | -0.718 | 0.0 |
| 6 | audit_64 | paper (ema_grade) | 0.554 [0.495, 0.613] (task-only [0.496, 0.612]) | -0.008 [-0.034, 0.017] | not distinguishable | 0.293 | no home signal | not identifiable | -0.798 | 64.0 |
| 7 | recal_64 | paper (ema_grade) | 0.550 [0.492, 0.608] (task-only [0.492, 0.607]) | -0.013 [-0.051, 0.026] | not distinguishable | 0.297 | no home signal | not identifiable | -0.706 | 64.0 |
| 8 | powerprior_64 | paper (ema_grade) | 0.542 [0.481, 0.603] (task-only [0.482, 0.601]) | -0.020 [-0.063, 0.022] | not distinguishable | 0.305 | no home signal | not identifiable | -0.703 | 64.0 |
| 9 | wipe | paper (ema_grade) | 0.540 [0.480, 0.600] (task-only [0.483, 0.597]) | -0.022 [-0.080, 0.035] | not distinguishable | 0.307 | no home signal | not identifiable | -0.700 | 0.0 |

## home cells (each owner reading its own bank) (ddxplus)

| rank | rule | source | first-shown success (dev) | minus keep (dev) | vs keep | regret | theta (order kept) | order | log score (lc) | checks used |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | keep | paper (ema_grade) | 0.679 [0.607, 0.751] (task-only [0.618, 0.737]) | - | (keep) | 0.185 | no home signal | not identifiable | -0.725 | 0.0 |
| 2 | powerprior_64 | paper (ema_grade) | 0.678 [0.614, 0.742] (task-only [0.620, 0.734]) | -0.001 [-0.042, 0.041] | not distinguishable | 0.186 | no home signal | not identifiable | -0.688 | 64.0 |
| 3 | relevance_gate | outside entry | 0.674 [0.610, 0.738] (task-only [0.616, 0.730]) | -0.004 [-0.039, 0.030] | not distinguishable | 0.190 | 0.985 [0.853, 1.142] | 0.93 [0.75, 1.19] | -0.698 | 0.0 |
| 4 | audit_64 | paper (ema_grade) | 0.673 [0.603, 0.744] (task-only [0.613, 0.731]) | -0.005 [-0.010, 0.000] | not distinguishable | 0.190 | no home signal | not identifiable | -0.724 | 64.0 |
| 5 | fixed_0.5 | paper (ema_grade) | 0.670 [0.605, 0.734] (task-only [0.611, 0.725]) | -0.009 [-0.019, 0.002] | not distinguishable | 0.194 | no home signal | not identifiable | -0.675 | 0.0 |
| 6 | recal_64 | paper (ema_grade) | 0.666 [0.600, 0.733] (task-only [0.608, 0.721]) | -0.012 [-0.023, -0.001] | below keep | 0.198 | no home signal | not identifiable | -0.681 | 64.0 |
| 7 | rank_focus_shrink | outside entry | 0.637 [0.573, 0.701] (task-only [0.582, 0.690]) | -0.042 [-0.081, -0.003] | below keep | 0.227 | 0.858 [0.663, 1.106] | 0.81 [0.60, 1.13] | -0.692 | 50.5 |
| 8 | retest_64 | paper (ema_grade) | 0.610 [0.543, 0.678] (task-only [0.559, 0.664]) | -0.068 [-0.120, -0.016] | below keep | 0.253 | no home signal | not identifiable | -0.697 | 64.0 |
| 9 | wipe | paper (ema_grade) | 0.585 [0.505, 0.665] (task-only [0.520, 0.649]) | -0.094 [-0.164, -0.023] | below keep | 0.279 | no home signal | not identifiable | -0.703 | 0.0 |

## Every ordered pair (first-shown success, dev)

| owner -> reader | audit_64 | fixed_0.5 | keep | powerprior_64 | rank_focus_shrink | recal_64 | relevance_gate | retest_64 | wipe |
|---|---|---|---|---|---|---|---|---|---|
| sim-a-old -> sim-a-old | 0.617 | 0.625 | 0.625 | 0.605 | 0.597 | 0.616 | 0.634 | 0.560 | 0.482 |
| sim-a-old -> sim-a-new | 0.709 | 0.714 | 0.723 | 0.717 | 0.656 | 0.707 | 0.696 | 0.631 | 0.652 |
| sim-a-old -> sim-b-old | 0.517 | 0.491 | 0.509 | 0.493 | 0.529 | 0.530 | 0.518 | 0.522 | 0.491 |
| sim-a-old -> sim-b-new | 0.601 | 0.589 | 0.598 | 0.591 | 0.582 | 0.595 | 0.589 | 0.584 | 0.643 |
| sim-a-new -> sim-a-old | 0.610 | 0.634 | 0.616 | 0.582 | 0.608 | 0.615 | 0.643 | 0.568 | 0.554 |
| sim-a-new -> sim-a-new | 0.704 | 0.688 | 0.705 | 0.766 | 0.672 | 0.689 | 0.723 | 0.644 | 0.705 |
| sim-a-new -> sim-b-old | 0.460 | 0.509 | 0.491 | 0.444 | 0.532 | 0.462 | 0.518 | 0.493 | 0.411 |
| sim-a-new -> sim-b-new | 0.613 | 0.616 | 0.607 | 0.623 | 0.625 | 0.607 | 0.652 | 0.622 | 0.616 |
| sim-b-old -> sim-a-old | 0.537 | 0.545 | 0.554 | 0.547 | 0.634 | 0.507 | 0.562 | 0.638 | 0.536 |
| sim-b-old -> sim-a-new | 0.615 | 0.607 | 0.625 | 0.556 | 0.602 | 0.593 | 0.625 | 0.597 | 0.545 |
| sim-b-old -> sim-b-old | 0.634 | 0.634 | 0.634 | 0.631 | 0.614 | 0.632 | 0.616 | 0.614 | 0.545 |
| sim-b-old -> sim-b-new | 0.652 | 0.652 | 0.652 | 0.653 | 0.648 | 0.646 | 0.616 | 0.639 | 0.643 |
| sim-b-new -> sim-a-old | 0.525 | 0.527 | 0.536 | 0.507 | 0.542 | 0.507 | 0.536 | 0.535 | 0.509 |
| sim-b-new -> sim-a-new | 0.565 | 0.607 | 0.580 | 0.576 | 0.631 | 0.598 | 0.580 | 0.629 | 0.571 |
| sim-b-new -> sim-b-old | 0.491 | 0.518 | 0.491 | 0.491 | 0.508 | 0.517 | 0.527 | 0.497 | 0.491 |
| sim-b-new -> sim-b-new | 0.739 | 0.732 | 0.750 | 0.710 | 0.664 | 0.728 | 0.723 | 0.625 | 0.607 |
