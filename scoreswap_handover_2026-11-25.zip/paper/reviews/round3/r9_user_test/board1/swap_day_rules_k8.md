# Board of swap-day rules, budget k = 8

Study `sim`. Every entry was re-run by the harness from the released tables, sealed (one fresh process per call).

**Ranked on the public DEV half: provisional.** The dev half is public, so an entry may have been tuned on it or may even have memorised it. The real ranking is on the held-out test half, which the maintainers score from submitted entry files.

Brackets: 95 % intervals. Two-way = tasks and tips both treated as sampled: msr.metrics.robust_variance, the delete-one-cluster jackknife over task ids and tips (a tip that recurs in several stream orders is one cluster; the primary interval). Theta's bracket is the union of its two-way and task-only Fieller sets (msr.metrics.theta_tests). Task-only = the task-id cluster bootstrap, 10,000 draws, seed 0 (secondary; the paper's tables of rule values use this one, so on all evaluation tasks they match it digit for digit).

Ranked by first-shown success per kind of swap (higher is better), with the difference from keep on the same tasks and draws and its two-way 95 % interval; 'vs keep' groups the ranks: above keep, below keep, or not distinguishable (the interval holds 0, so the order between such rows means little). Then regret, the level-corrected log score (when the rule returns p) and the checks used. To relate a row to the paper's table, use the task-only interval with --split all (maintainers): it is the paper's.

## same-maker upgrades (ddxplus)

| rank | rule | source | first-shown success (dev) | minus keep (dev) | vs keep | regret | theta (order kept) | order | log score (lc) | checks used |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | rank_focus_shrink | outside entry | 0.689 [0.596, 0.783] (task-only [0.614, 0.761]) | 0.002 [-0.047, 0.051] | not distinguishable | 0.172 | 0.530 [0.289, 0.859] | 0.78 [0.39, 2.43] | -0.717 | 8.0 |
| 2 | keep | paper (ema_grade) | 0.688 [0.587, 0.788] (task-only [0.612, 0.759]) | - | (keep) | 0.174 | no home signal | not identifiable | -0.742 | 0.0 |
| 3 | retest_8 | paper (ema_grade) | 0.685 [0.588, 0.782] (task-only [0.612, 0.755]) | -0.003 [-0.058, 0.053] | not distinguishable | 0.177 | no home signal | not identifiable | -0.710 | 8.0 |
| 4 | fixed_0.5 | paper (ema_grade) | 0.683 [0.576, 0.790] (task-only [0.605, 0.759]) | -0.004 [-0.022, 0.013] | not distinguishable | 0.179 | no home signal | not identifiable | -0.688 | 0.0 |
| 5 | powerprior_8 | paper (ema_grade) | 0.676 [0.575, 0.777] (task-only [0.602, 0.745]) | -0.012 [-0.050, 0.027] | not distinguishable | 0.186 | no home signal | not identifiable | -0.702 | 8.0 |
| 6 | audit_8 | paper (ema_grade) | 0.672 [0.575, 0.769] (task-only [0.600, 0.741]) | -0.015 [-0.036, 0.005] | not distinguishable | 0.189 | no home signal | not identifiable | -0.730 | 8.0 |
| 7 | recal_8 | paper (ema_grade) | 0.664 [0.565, 0.762] (task-only [0.591, 0.734]) | -0.024 [-0.043, -0.005] | below keep | 0.198 | no home signal | not identifiable | -0.715 | 8.0 |
| 8 | relevance_gate | outside entry | 0.656 [0.550, 0.762] (task-only [0.576, 0.732]) | -0.031 [-0.056, -0.006] | below keep | 0.205 | 0.625 [0.352, 1.027] | 0.92 [0.48, 2.73] | -0.726 | 0.0 |
| 9 | wipe | paper (ema_grade) | 0.647 [0.557, 0.738] (task-only [0.568, 0.723]) | -0.040 [-0.104, 0.023] | not distinguishable | 0.214 | no home signal | not identifiable | -0.712 | 0.0 |

## same-maker downgrades (ddxplus)

| rank | rule | source | first-shown success (dev) | minus keep (dev) | vs keep | regret | theta (order kept) | order | log score (lc) | checks used |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | relevance_gate | outside entry | 0.585 [0.471, 0.699] (task-only [0.513, 0.658]) | 0.031 [-0.002, 0.064] | not distinguishable | 0.237 | 0.801 [0.427, 1.632] | 0.94 [0.51, 2.45] | -0.706 | 0.0 |
| 2 | fixed_0.5 | paper (ema_grade) | 0.576 [0.461, 0.691] (task-only [0.500, 0.650]) | 0.022 [-0.005, 0.049] | not distinguishable | 0.246 | no home signal | not identifiable | -0.677 | 0.0 |
| 3 | keep | paper (ema_grade) | 0.554 [0.455, 0.652] (task-only [0.477, 0.632]) | - | (keep) | 0.268 | no home signal | not identifiable | -0.758 | 0.0 |
| 4 | rank_focus_shrink | outside entry | 0.547 [0.454, 0.641] (task-only [0.473, 0.623]) | -0.006 [-0.086, 0.074] | not distinguishable | 0.274 | 0.443 [0.221, 1.071] | 0.52 [0.25, 1.67] | -0.686 | 8.0 |
| 5 | audit_8 | paper (ema_grade) | 0.541 [0.452, 0.630] (task-only [0.468, 0.615]) | -0.012 [-0.033, 0.009] | not distinguishable | 0.280 | no home signal | not identifiable | -0.735 | 8.0 |
| 6 | recal_8 | paper (ema_grade) | 0.540 [0.445, 0.635] (task-only [0.470, 0.611]) | -0.013 [-0.039, 0.012] | not distinguishable | 0.281 | no home signal | not identifiable | -0.702 | 8.0 |
| 7 | powerprior_8 | paper (ema_grade) | 0.539 [0.454, 0.624] (task-only [0.465, 0.613]) | -0.015 [-0.063, 0.034] | not distinguishable | 0.282 | no home signal | not identifiable | -0.688 | 8.0 |
| 8 | wipe | paper (ema_grade) | 0.522 [0.435, 0.610] (task-only [0.438, 0.607]) | -0.031 [-0.096, 0.034] | not distinguishable | 0.299 | no home signal | not identifiable | -0.692 | 0.0 |
| 9 | retest_8 | paper (ema_grade) | 0.511 [0.426, 0.596] (task-only [0.429, 0.595]) | -0.042 [-0.123, 0.039] | not distinguishable | 0.310 | no home signal | not identifiable | -0.690 | 8.0 |

## cross-maker swaps (ddxplus)

| rank | rule | source | first-shown success (dev) | minus keep (dev) | vs keep | regret | theta (order kept) | order | log score (lc) | checks used |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | relevance_gate | outside entry | 0.573 [0.509, 0.637] (task-only [0.512, 0.632]) | 0.010 [-0.010, 0.030] | not distinguishable | 0.275 | 0.150 [-0.073, 0.342] | 0.17 [-0.10, 0.38] | -0.771 | 0.0 |
| 2 | rank_focus_shrink | outside entry | 0.564 [0.507, 0.620] (task-only [0.509, 0.618]) | 0.001 [-0.039, 0.042] | not distinguishable | 0.283 | 0.163 [0.025, 0.317] | 0.19 [0.03, 0.35] | -0.708 | 8.0 |
| 3 | keep | paper (ema_grade) | 0.562 [0.494, 0.631] (task-only [0.501, 0.623]) | - | (keep) | 0.285 | no home signal | not identifiable | -0.840 | 0.0 |
| 4 | fixed_0.5 | paper (ema_grade) | 0.561 [0.495, 0.628] (task-only [0.499, 0.622]) | -0.001 [-0.016, 0.014] | not distinguishable | 0.286 | no home signal | not identifiable | -0.718 | 0.0 |
| 5 | audit_8 | paper (ema_grade) | 0.553 [0.496, 0.610] (task-only [0.496, 0.608]) | -0.010 [-0.037, 0.017] | not distinguishable | 0.295 | no home signal | not identifiable | -0.779 | 8.0 |
| 6 | recal_8 | paper (ema_grade) | 0.551 [0.494, 0.608] (task-only [0.496, 0.606]) | -0.011 [-0.039, 0.017] | not distinguishable | 0.296 | no home signal | not identifiable | -0.733 | 8.0 |
| 7 | retest_8 | paper (ema_grade) | 0.550 [0.489, 0.610] (task-only [0.491, 0.608]) | -0.013 [-0.069, 0.043] | not distinguishable | 0.297 | no home signal | not identifiable | -0.700 | 8.0 |
| 8 | powerprior_8 | paper (ema_grade) | 0.542 [0.482, 0.601] (task-only [0.483, 0.599]) | -0.021 [-0.060, 0.018] | not distinguishable | 0.305 | no home signal | not identifiable | -0.708 | 8.0 |
| 9 | wipe | paper (ema_grade) | 0.540 [0.480, 0.600] (task-only [0.483, 0.597]) | -0.022 [-0.080, 0.035] | not distinguishable | 0.307 | no home signal | not identifiable | -0.700 | 0.0 |

## home cells (each owner reading its own bank) (ddxplus)

| rank | rule | source | first-shown success (dev) | minus keep (dev) | vs keep | regret | theta (order kept) | order | log score (lc) | checks used |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | keep | paper (ema_grade) | 0.679 [0.607, 0.751] (task-only [0.618, 0.737]) | - | (keep) | 0.185 | no home signal | not identifiable | -0.725 | 0.0 |
| 2 | relevance_gate | outside entry | 0.674 [0.610, 0.738] (task-only [0.616, 0.730]) | -0.004 [-0.039, 0.030] | not distinguishable | 0.190 | 0.985 [0.853, 1.142] | 0.93 [0.75, 1.19] | -0.698 | 0.0 |
| 3 | fixed_0.5 | paper (ema_grade) | 0.670 [0.605, 0.734] (task-only [0.611, 0.725]) | -0.009 [-0.019, 0.002] | not distinguishable | 0.194 | no home signal | not identifiable | -0.675 | 0.0 |
| 4 | powerprior_8 | paper (ema_grade) | 0.659 [0.594, 0.724] (task-only [0.601, 0.714]) | -0.020 [-0.064, 0.024] | not distinguishable | 0.205 | no home signal | not identifiable | -0.692 | 8.0 |
| 5 | audit_8 | paper (ema_grade) | 0.650 [0.584, 0.717] (task-only [0.594, 0.704]) | -0.028 [-0.051, -0.006] | below keep | 0.214 | no home signal | not identifiable | -0.716 | 8.0 |
| 6 | rank_focus_shrink | outside entry | 0.645 [0.579, 0.712] (task-only [0.592, 0.697]) | -0.033 [-0.063, -0.004] | below keep | 0.219 | 0.730 [0.554, 0.911] | 0.69 [0.52, 0.89] | -0.688 | 8.0 |
| 7 | recal_8 | paper (ema_grade) | 0.645 [0.581, 0.709] (task-only [0.589, 0.697]) | -0.034 [-0.053, -0.015] | below keep | 0.219 | no home signal | not identifiable | -0.701 | 8.0 |
| 8 | retest_8 | paper (ema_grade) | 0.624 [0.547, 0.702] (task-only [0.566, 0.684]) | -0.054 [-0.112, 0.004] | not distinguishable | 0.239 | no home signal | not identifiable | -0.698 | 8.0 |
| 9 | wipe | paper (ema_grade) | 0.585 [0.505, 0.665] (task-only [0.520, 0.649]) | -0.094 [-0.164, -0.023] | below keep | 0.279 | no home signal | not identifiable | -0.703 | 0.0 |

## Every ordered pair (first-shown success, dev)

| owner -> reader | audit_8 | fixed_0.5 | keep | powerprior_8 | rank_focus_shrink | recal_8 | relevance_gate | retest_8 | wipe |
|---|---|---|---|---|---|---|---|---|---|
| sim-a-old -> sim-a-old | 0.584 | 0.625 | 0.625 | 0.578 | 0.610 | 0.592 | 0.634 | 0.552 | 0.482 |
| sim-a-old -> sim-a-new | 0.696 | 0.714 | 0.723 | 0.705 | 0.717 | 0.697 | 0.696 | 0.685 | 0.652 |
| sim-a-old -> sim-b-old | 0.507 | 0.491 | 0.509 | 0.484 | 0.516 | 0.517 | 0.518 | 0.494 | 0.491 |
| sim-a-old -> sim-b-new | 0.616 | 0.589 | 0.598 | 0.605 | 0.607 | 0.596 | 0.589 | 0.607 | 0.643 |
| sim-a-new -> sim-a-old | 0.594 | 0.634 | 0.616 | 0.586 | 0.620 | 0.584 | 0.643 | 0.569 | 0.554 |
| sim-a-new -> sim-a-new | 0.701 | 0.688 | 0.705 | 0.754 | 0.670 | 0.687 | 0.723 | 0.719 | 0.705 |
| sim-a-new -> sim-b-old | 0.456 | 0.509 | 0.491 | 0.442 | 0.488 | 0.461 | 0.518 | 0.455 | 0.411 |
| sim-a-new -> sim-b-new | 0.611 | 0.616 | 0.607 | 0.617 | 0.609 | 0.605 | 0.652 | 0.616 | 0.616 |
| sim-b-old -> sim-a-old | 0.542 | 0.545 | 0.554 | 0.541 | 0.571 | 0.527 | 0.562 | 0.574 | 0.536 |
| sim-b-old -> sim-a-new | 0.594 | 0.607 | 0.625 | 0.547 | 0.581 | 0.594 | 0.625 | 0.547 | 0.545 |
| sim-b-old -> sim-b-old | 0.615 | 0.634 | 0.634 | 0.612 | 0.604 | 0.604 | 0.616 | 0.597 | 0.545 |
| sim-b-old -> sim-b-new | 0.649 | 0.652 | 0.652 | 0.646 | 0.662 | 0.631 | 0.616 | 0.685 | 0.643 |
| sim-b-new -> sim-a-old | 0.525 | 0.527 | 0.536 | 0.511 | 0.543 | 0.517 | 0.536 | 0.503 | 0.509 |
| sim-b-new -> sim-a-new | 0.570 | 0.607 | 0.580 | 0.587 | 0.595 | 0.596 | 0.580 | 0.601 | 0.571 |
| sim-b-new -> sim-b-old | 0.489 | 0.518 | 0.491 | 0.492 | 0.475 | 0.496 | 0.527 | 0.453 | 0.491 |
| sim-b-new -> sim-b-new | 0.700 | 0.732 | 0.750 | 0.691 | 0.696 | 0.696 | 0.723 | 0.631 | 0.607 |
