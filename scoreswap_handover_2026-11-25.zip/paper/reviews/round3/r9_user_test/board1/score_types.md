# Board of score types

Study `sim`. Every entry was re-run by the harness from the released tables, sealed (one fresh process per call).

**Ranked on the public DEV half: provisional.** The dev half is public, so an entry may have been tuned on it or may even have memorised it. The real ranking is on the held-out test half, which the maintainers score from submitted entry files.

Brackets: 95 % intervals. Two-way = tasks and tips both treated as sampled: msr.metrics.robust_variance, the delete-one-cluster jackknife over task ids and tips (a tip that recurs in several stream orders is one cluster; the primary interval). Theta's bracket is the union of its two-way and task-only Fieller sets (msr.metrics.theta_tests). Task-only = the task-id cluster bootstrap, 10,000 draws, seed 0 (secondary; the paper's tables of rule values use this one, so on all evaluation tasks they match it digit for digit).

Ranked by theta (value kept) after the swap, per kind of swap, with order and stakes beside it (theta = order x stakes). A score type whose home signal is too weak (the owner's score less than 2 standard errors above zero on its calibration tasks: msr.metrics.home_signal_flag, the paper's one rule) has nothing to retain, so it is listed apart under 'no home signal', never ranked by its retained share. Order reads 'not identifiable' where the reader's spread cannot be told from zero. Cw at home is shown beside every retained number.

## same-maker upgrades (ddxplus)

| rank | score type | source | theta (dev) | order (dev) | stakes (dev) | Cw at home (dev) | Cw after (dev) |
|---|---|---|---|---|---|---|---|
| 1 | visits | paper | 0.94 [0.28, 2.00] | 1.38 [0.40, 66.74] | 0.68 [0.00, 1.08] | 0.622 | 0.622 |
| 2 | credit | paper | 0.90 [0.53, 1.38] | 1.33 [0.77, 3.48] | 0.68 [0.00, 1.08] | 0.687 | 0.680 |
| 3 | tags_self | paper | 0.82 [0.54, 1.18] | 1.20 [0.69, 3.50] | 0.68 [0.00, 1.08] | 0.757 | 0.720 |
| 4 | beta_grade | paper | 0.76 [0.48, 1.21] | 1.13 [0.64, 3.89] | 0.68 [0.00, 1.08] | 0.722 | 0.679 |
| 5 | ema_grade | paper | 0.75 [0.46, 1.19] | 1.10 [0.64, 3.29] | 0.68 [0.00, 1.08] | 0.717 | 0.673 |
| 6 | ips_score | outside entry | 0.59 [0.24, 1.06] | 0.87 [0.26, 3.66] | 0.68 [0.00, 1.08] | 0.686 | 0.618 |

## same-maker downgrades (ddxplus)

| rank | score type | source | theta (dev) | order (dev) | stakes (dev) | Cw at home (dev) | Cw after (dev) |
|---|---|---|---|---|---|---|---|
| 1 | visits | paper | 1.68  | 1.97  | 0.85 [0.56, 1.15] | 0.562 | 0.613 |
| 2 | credit | paper | 0.85 [0.48, 2.09] | 1.00 [0.59, 2.70] | 0.85 [0.56, 1.15] | 0.665 | 0.650 |
| 3 | ips_score | outside entry | 0.73 [0.38, 1.43] | 0.86 [0.44, 1.91] | 0.85 [0.56, 1.15] | 0.674 | 0.636 |
| 4 | ema_grade | paper | 0.72 [0.36, 1.44] | 0.85 [0.44, 2.10] | 0.85 [0.56, 1.15] | 0.670 | 0.631 |
| 5 | beta_grade | paper | 0.66 [0.39, 1.04] | 0.78 [0.45, 1.50] | 0.85 [0.56, 1.15] | 0.711 | 0.651 |
| 6 | tags_self | paper | 0.58 [0.22, 0.87] | 0.68 [0.27, 1.15] | 0.85 [0.56, 1.15] | 0.751 | 0.659 |

## cross-maker swaps (ddxplus)

| rank | score type | source | theta (dev) | order (dev) | stakes (dev) | Cw at home (dev) | Cw after (dev) |
|---|---|---|---|---|---|---|---|
| 1 | visits | paper | 0.37 [-0.13, 0.94] | 0.43 [-0.17, 1.42] | 0.87 [0.69, 1.04] | 0.592 | 0.535 |
| 2 | credit | paper | 0.36 [0.09, 0.70] | 0.42 [0.11, 0.81] | 0.87 [0.69, 1.04] | 0.676 | 0.565 |
| 3 | tags_self | paper | 0.26 [0.08, 0.41] | 0.30 [0.11, 0.46] | 0.87 [0.69, 1.04] | 0.754 | 0.568 |
| 4 | ema_grade | paper | 0.20 [-0.04, 0.44] | 0.23 [-0.05, 0.49] | 0.87 [0.69, 1.04] | 0.694 | 0.540 |
| 5 | beta_grade | paper | 0.16 [-0.01, 0.32] | 0.19 [-0.02, 0.38] | 0.87 [0.69, 1.04] | 0.716 | 0.537 |
| 6 | ips_score | outside entry | 0.09 [-0.22, 0.35] | 0.11 [-0.26, 0.42] | 0.87 [0.69, 1.04] | 0.680 | 0.518 |

## Every ordered pair (theta, dev)

| owner -> reader | beta_grade | credit | ema_grade | ips_score | tags_self | visits |
|---|---|---|---|---|---|---|
| sim-a-old -> sim-a-new | 0.59 | 0.85 | 0.64 | 0.60 | 0.57 | 0.95 |
| sim-a-old -> sim-b-old | -0.24 | 0.08 | 0.03 | -0.41 | -0.08 | -0.37 |
| sim-a-old -> sim-b-new | -0.17 | -0.20 | -0.15 | -0.33 | -0.08 | -0.70 |
| sim-a-new -> sim-a-old | 0.98 | 1.05 | 1.27 | 1.11 | 0.77 | 2.10 |
| sim-a-new -> sim-b-old | 0.84 | 1.38 | 0.56 | 0.66 | 0.51 | 2.79 |
| sim-a-new -> sim-b-new | 0.26 | 0.74 | 0.39 | 0.68 | 0.64 | 0.69 |
| sim-b-old -> sim-a-old | 0.32 | 0.09 | 0.37 | 0.15 | 0.39 | 0.24 |
| sim-b-old -> sim-a-new | -0.06 | -0.23 | 0.12 | -0.19 | 0.13 | 0.36 |
| sim-b-old -> sim-b-new | 0.91 | 0.95 | 0.84 | 0.58 | 1.05 | 0.93 |
| sim-b-new -> sim-a-old | 0.30 | 0.76 | 0.17 | 0.36 | 0.35 | 1.08 |
| sim-b-new -> sim-a-new | 0.14 | 0.35 | 0.21 | -0.14 | 0.23 | 0.64 |
| sim-b-new -> sim-b-old | 0.48 | 0.69 | 0.38 | 0.46 | 0.46 | 1.36 |

\* no home signal in that pair: the retained share means nothing there.
