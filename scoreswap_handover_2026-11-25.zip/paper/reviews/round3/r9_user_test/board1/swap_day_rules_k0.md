# Board of swap-day rules, budget k = 0

Study `sim`. Every entry was re-run by the harness from the released tables, sealed (one fresh process per call).

**Ranked on the public DEV half: provisional.** The dev half is public, so an entry may have been tuned on it or may even have memorised it. The real ranking is on the held-out test half, which the maintainers score from submitted entry files.

Brackets: 95 % intervals. Two-way = tasks and tips both treated as sampled: msr.metrics.robust_variance, the delete-one-cluster jackknife over task ids and tips (a tip that recurs in several stream orders is one cluster; the primary interval). Theta's bracket is the union of its two-way and task-only Fieller sets (msr.metrics.theta_tests). Task-only = the task-id cluster bootstrap, 10,000 draws, seed 0 (secondary; the paper's tables of rule values use this one, so on all evaluation tasks they match it digit for digit).

Ranked by first-shown success per kind of swap (higher is better), with the difference from keep on the same tasks and draws and its two-way 95 % interval; 'vs keep' groups the ranks: above keep, below keep, or not distinguishable (the interval holds 0, so the order between such rows means little). Then regret, the level-corrected log score (when the rule returns p) and the checks used. To relate a row to the paper's table, use the task-only interval with --split all (maintainers): it is the paper's.

## same-maker upgrades (ddxplus)

| rank | rule | source | first-shown success (dev) | minus keep (dev) | vs keep | regret | theta (order kept) | order | log score (lc) | checks used |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | keep | paper (ema_grade) | 0.688 [0.587, 0.788] (task-only [0.612, 0.759]) | - | (keep) | 0.174 | no home signal | not identifiable | -0.742 | 0.0 |
| 2 | fixed_0.5 | paper (ema_grade) | 0.683 [0.576, 0.790] (task-only [0.605, 0.759]) | -0.004 [-0.022, 0.013] | not distinguishable | 0.179 | no home signal | not identifiable | -0.688 | 0.0 |
| 3 | rank_focus_shrink | outside entry | 0.683 [0.576, 0.790] (task-only [0.605, 0.759]) | -0.004 [-0.022, 0.013] | not distinguishable | 0.179 | 0.750 [0.456, 1.195] | 1.10 [0.64, 3.29] | -0.688 | 0.0 |
| 4 | relevance_gate | outside entry | 0.656 [0.550, 0.762] (task-only [0.576, 0.732]) | -0.031 [-0.056, -0.006] | below keep | 0.205 | 0.625 [0.352, 1.027] | 0.92 [0.48, 2.73] | -0.726 | 0.0 |
| 5 | wipe | paper (ema_grade) | 0.647 [0.557, 0.738] (task-only [0.568, 0.723]) | -0.040 [-0.104, 0.023] | not distinguishable | 0.214 | no home signal | not identifiable | -0.712 | 0.0 |

## same-maker downgrades (ddxplus)

| rank | rule | source | first-shown success (dev) | minus keep (dev) | vs keep | regret | theta (order kept) | order | log score (lc) | checks used |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | relevance_gate | outside entry | 0.585 [0.471, 0.699] (task-only [0.513, 0.658]) | 0.031 [-0.002, 0.064] | not distinguishable | 0.237 | 0.801 [0.427, 1.632] | 0.94 [0.51, 2.45] | -0.706 | 0.0 |
| 2 | fixed_0.5 | paper (ema_grade) | 0.576 [0.461, 0.691] (task-only [0.500, 0.650]) | 0.022 [-0.005, 0.049] | not distinguishable | 0.246 | no home signal | not identifiable | -0.677 | 0.0 |
| 3 | rank_focus_shrink | outside entry | 0.576 [0.461, 0.691] (task-only [0.500, 0.650]) | 0.022 [-0.005, 0.049] | not distinguishable | 0.246 | 0.720 [0.356, 1.440] | 0.85 [0.44, 2.10] | -0.677 | 0.0 |
| 4 | keep | paper (ema_grade) | 0.554 [0.455, 0.652] (task-only [0.477, 0.632]) | - | (keep) | 0.268 | no home signal | not identifiable | -0.758 | 0.0 |
| 5 | wipe | paper (ema_grade) | 0.522 [0.435, 0.610] (task-only [0.438, 0.607]) | -0.031 [-0.096, 0.034] | not distinguishable | 0.299 | no home signal | not identifiable | -0.692 | 0.0 |

## cross-maker swaps (ddxplus)

| rank | rule | source | first-shown success (dev) | minus keep (dev) | vs keep | regret | theta (order kept) | order | log score (lc) | checks used |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | relevance_gate | outside entry | 0.573 [0.509, 0.637] (task-only [0.512, 0.632]) | 0.010 [-0.010, 0.030] | not distinguishable | 0.275 | 0.150 [-0.073, 0.342] | 0.17 [-0.10, 0.38] | -0.771 | 0.0 |
| 2 | keep | paper (ema_grade) | 0.562 [0.494, 0.631] (task-only [0.501, 0.623]) | - | (keep) | 0.285 | no home signal | not identifiable | -0.840 | 0.0 |
| 3 | fixed_0.5 | paper (ema_grade) | 0.561 [0.495, 0.628] (task-only [0.499, 0.622]) | -0.001 [-0.016, 0.014] | not distinguishable | 0.286 | no home signal | not identifiable | -0.718 | 0.0 |
| 4 | rank_focus_shrink | outside entry | 0.561 [0.495, 0.628] (task-only [0.499, 0.622]) | -0.001 [-0.016, 0.014] | not distinguishable | 0.286 | 0.198 [-0.043, 0.437] | 0.23 [-0.05, 0.49] | -0.718 | 0.0 |
| 5 | wipe | paper (ema_grade) | 0.540 [0.480, 0.600] (task-only [0.483, 0.597]) | -0.022 [-0.080, 0.035] | not distinguishable | 0.307 | no home signal | not identifiable | -0.700 | 0.0 |

## home cells (each owner reading its own bank) (ddxplus)

| rank | rule | source | first-shown success (dev) | minus keep (dev) | vs keep | regret | theta (order kept) | order | log score (lc) | checks used |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | keep | paper (ema_grade) | 0.679 [0.607, 0.751] (task-only [0.618, 0.737]) | - | (keep) | 0.185 | no home signal | not identifiable | -0.725 | 0.0 |
| 2 | relevance_gate | outside entry | 0.674 [0.610, 0.738] (task-only [0.616, 0.730]) | -0.004 [-0.039, 0.030] | not distinguishable | 0.190 | 0.985 [0.853, 1.142] | 0.93 [0.75, 1.19] | -0.698 | 0.0 |
| 3 | fixed_0.5 | paper (ema_grade) | 0.670 [0.605, 0.734] (task-only [0.611, 0.725]) | -0.009 [-0.019, 0.002] | not distinguishable | 0.194 | no home signal | not identifiable | -0.675 | 0.0 |
| 4 | rank_focus_shrink | outside entry | 0.670 [0.605, 0.734] (task-only [0.611, 0.725]) | -0.009 [-0.019, 0.002] | not distinguishable | 0.194 | 1.000 [1.000, 1.000] | 0.95 [0.80, 1.15] | -0.675 | 0.0 |
| 5 | wipe | paper (ema_grade) | 0.585 [0.505, 0.665] (task-only [0.520, 0.649]) | -0.094 [-0.164, -0.023] | below keep | 0.279 | no home signal | not identifiable | -0.703 | 0.0 |

## Every ordered pair (first-shown success, dev)

| owner -> reader | fixed_0.5 | keep | rank_focus_shrink | relevance_gate | wipe |
|---|---|---|---|---|---|
| sim-a-old -> sim-a-old | 0.625 | 0.625 | 0.625 | 0.634 | 0.482 |
| sim-a-old -> sim-a-new | 0.714 | 0.723 | 0.714 | 0.696 | 0.652 |
| sim-a-old -> sim-b-old | 0.491 | 0.509 | 0.491 | 0.518 | 0.491 |
| sim-a-old -> sim-b-new | 0.589 | 0.598 | 0.589 | 0.589 | 0.643 |
| sim-a-new -> sim-a-old | 0.634 | 0.616 | 0.634 | 0.643 | 0.554 |
| sim-a-new -> sim-a-new | 0.688 | 0.705 | 0.688 | 0.723 | 0.705 |
| sim-a-new -> sim-b-old | 0.509 | 0.491 | 0.509 | 0.518 | 0.411 |
| sim-a-new -> sim-b-new | 0.616 | 0.607 | 0.616 | 0.652 | 0.616 |
| sim-b-old -> sim-a-old | 0.545 | 0.554 | 0.545 | 0.562 | 0.536 |
| sim-b-old -> sim-a-new | 0.607 | 0.625 | 0.607 | 0.625 | 0.545 |
| sim-b-old -> sim-b-old | 0.634 | 0.634 | 0.634 | 0.616 | 0.545 |
| sim-b-old -> sim-b-new | 0.652 | 0.652 | 0.652 | 0.616 | 0.643 |
| sim-b-new -> sim-a-old | 0.527 | 0.536 | 0.527 | 0.536 | 0.509 |
| sim-b-new -> sim-a-new | 0.607 | 0.580 | 0.607 | 0.580 | 0.571 |
| sim-b-new -> sim-b-old | 0.518 | 0.491 | 0.518 | 0.527 | 0.491 |
| sim-b-new -> sim-b-new | 0.732 | 0.750 | 0.732 | 0.723 | 0.607 |
