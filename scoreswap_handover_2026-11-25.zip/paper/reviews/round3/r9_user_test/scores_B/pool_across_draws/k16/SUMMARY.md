# pool_across_draws: swap-day rule at budget k = 16

**Tasks scored: the DEV half of the evaluation tasks, which is public. You may have tuned on it, and a rule can memorise it, so this is a development number, not a ranking. The board ranks on the held-out TEST half, scored by the maintainers from your entry file.**

Scored from the frozen tables of study `sim` with no model call (pack fingerprint `c209acb9e99a07ef`). Each value is a mean over the evaluation tasks; 200 seeded draw(s), each task's value the mean over the draws. Differences use the same tasks and the same draws.

Brackets: 95 % intervals. Two-way = tasks and tips both treated as sampled: msr.metrics.robust_variance, the delete-one-cluster jackknife over task ids and tips (a tip that recurs in several stream orders is one cluster; the primary interval). Theta's bracket is the union of its two-way and task-only Fieller sets (msr.metrics.theta_tests). Task-only = the task-id cluster bootstrap, 10,000 draws, seed 0 (secondary; the paper's tables of rule values use this one, so on all evaluation tasks they match it digit for digit).

First-shown success: the reader's success with the candidate the rule shows first (higher is better). Regret: the gap to the task's best candidate (lower is better). Theta: the share of the owner's home ranking signal (its `ema_grade` score with its own results) that the rule's order keeps for the reader; at a home cell the reader is the owner itself with the same results, so keep's theta there is exactly 1. Theta = order x stakes; order is 'not identifiable' where the reader's spread cannot be told from zero, and theta reads 'no home signal' where the owner's score has no ranking signal on its calibration tasks (msr.metrics.home_signal_flag).

- Run sealed: one fresh process per call, forked from a launcher that never runs the entry.
- landlock: ABI 7: read-only access to 7 folder(s) and file(s); no writes, no execution; no TCP; signals and abstract sockets scoped
- seccomp: no threads; no pipes, sockets, IPC, shared memory, key rings, ptrace, exec, xattrs or file metadata changes

## By kind of swap, dev half (public) (ddxplus)

| kind | first-shown success | minus keep | minus wipe | minus fixed_0.5 | minus powerprior_16 | minus recal_16 | minus retest_16 | minus audit_16 | regret | log score (level-corrected) | theta | order | checks used |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| same-maker upgrades | 0.701 [0.601, 0.801] (task-only [0.623, 0.777]) | 0.014 [-0.016, 0.043] | 0.054 [-0.006, 0.114] | 0.018 [-0.011, 0.047] | 0.022 [-0.015, 0.059] | 0.034 [0.011, 0.058] | 0.026 [-0.035, 0.088] | 0.029 [0.002, 0.055] | 0.160 | -0.754 [-0.834, -0.675] | 0.854 [0.540, 1.347] | 1.26 [0.76, 3.73] | 16.0 |
| same-maker downgrades | 0.580 [0.489, 0.672] (task-only [0.501, 0.655]) | 0.027 [-0.030, 0.083] | 0.058 [-0.023, 0.139] | 0.005 [-0.048, 0.057] | 0.043 [-0.020, 0.106] | 0.035 [-0.016, 0.087] | 0.067 [-0.032, 0.166] | 0.037 [-0.016, 0.091] | 0.241 | -0.728 [-0.806, -0.649] | 0.822 [0.438, 1.739] | 0.97 [0.56, 2.44] | 16.0 |
| cross-maker swaps | 0.611 [0.555, 0.668] (task-only [0.556, 0.666]) | 0.049 [0.013, 0.084] | 0.071 [0.018, 0.124] | 0.050 [0.018, 0.081] | 0.069 [0.030, 0.108] | 0.061 [0.029, 0.093] | 0.055 [0.014, 0.095] | 0.059 [0.027, 0.090] | 0.236 | -0.791 [-0.844, -0.738] | 0.489 [0.210, 0.856] | 0.56 [0.27, 0.96] | 16.0 |
| home cells (each owner reading its own bank) | 0.668 [0.605, 0.731] (task-only [0.610, 0.724]) | -0.011 [-0.056, 0.035] | 0.083 [0.020, 0.145] | -0.002 [-0.042, 0.038] | 0.003 [-0.038, 0.044] | 0.015 [-0.026, 0.056] | 0.029 [-0.013, 0.072] | 0.010 [-0.028, 0.048] | 0.196 | -0.727 [-0.775, -0.679] | 1.030 [0.905, 1.207] | 0.98 [0.83, 1.23] | 16.0 |

### Every ordered pair, dev half (public)

| owner -> reader | kind | first-shown success | minus keep | minus wipe | regret | theta |
|---|---|---|---|---|---|---|
| sim-a-old -> sim-a-old | home | 0.635 [0.531, 0.739] | 0.010 | 0.153 | 0.159 | 1.01 |
| sim-a-old -> sim-a-new | same_maker_upgrade | 0.724 [0.586, 0.862] | 0.001 | 0.072 | 0.160 | 0.61 |
| sim-a-old -> sim-b-old | cross_maker | 0.526 [0.407, 0.644] | 0.017 | 0.035 | 0.314 | 0.31 |
| sim-a-old -> sim-b-new | cross_maker | 0.612 [0.495, 0.729] | 0.014 | -0.031 | 0.272 | 0.13 |
| sim-a-new -> sim-a-old | same_maker_downgrade | 0.659 [0.531, 0.787] | 0.043 | 0.106 | 0.216 | 1.39 |
| sim-a-new -> sim-a-new | home | 0.697 [0.575, 0.818] | -0.009 | -0.009 | 0.205 | 1.20 |
| sim-a-new -> sim-b-old | cross_maker | 0.613 [0.506, 0.720] | 0.121 | 0.202 | 0.137 | 1.41 |
| sim-a-new -> sim-b-new | cross_maker | 0.662 [0.564, 0.760] | 0.055 | 0.046 | 0.186 | 1.04 |
| sim-b-old -> sim-a-old | cross_maker | 0.659 [0.568, 0.751] | 0.106 | 0.124 | 0.207 | 0.69 |
| sim-b-old -> sim-a-new | cross_maker | 0.634 [0.470, 0.799] | 0.009 | 0.090 | 0.232 | 0.20 |
| sim-b-old -> sim-b-old | home | 0.642 [0.525, 0.759] | 0.008 | 0.097 | 0.206 | 1.12 |
| sim-b-old -> sim-b-new | same_maker_upgrade | 0.679 [0.557, 0.800] | 0.027 | 0.036 | 0.161 | 1.06 |
| sim-b-new -> sim-a-old | cross_maker | 0.577 [0.443, 0.711] | 0.041 | 0.068 | 0.271 | 0.45 |
| sim-b-new -> sim-a-new | cross_maker | 0.607 [0.499, 0.715] | 0.026 | 0.035 | 0.268 | 0.16 |
| sim-b-new -> sim-b-old | same_maker_downgrade | 0.502 [0.389, 0.614] | 0.010 | 0.010 | 0.266 | 0.47 |
| sim-b-new -> sim-b-new | home | 0.697 [0.580, 0.815] | -0.053 | 0.090 | 0.213 | 0.85 |

Per-stream values, the Brier scores, the uncorrected log score, Cw, both intervals of every number and the paper's rules' own values are in summary.csv and compare.csv; one row per cell is in cells.csv.
