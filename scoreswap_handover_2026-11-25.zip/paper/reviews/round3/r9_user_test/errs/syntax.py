KIND = "swap_day_rule"
NAME = "bad"
def rule(bank, candidates, swap, checks)
    return {}
