import numpy as np
KIND = "swap_day_rule"
NAME = "wrongshape"
def rule(bank, candidates, swap, checks):
    return {"u": np.full(bank.n + 1, 0.5)}
