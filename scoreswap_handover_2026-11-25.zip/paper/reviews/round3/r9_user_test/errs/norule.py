KIND = "swap_day_rule"
NAME = "norule"
def rules(bank, candidates, swap, checks):
    return {}
