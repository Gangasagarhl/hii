KIND = "swap_rule"
NAME = "kindtypo"
def rule(bank, candidates, swap, checks):
    return {}
