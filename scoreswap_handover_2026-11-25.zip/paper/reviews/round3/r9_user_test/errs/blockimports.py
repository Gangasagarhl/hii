import sys, runpy, os
sys.path.insert(0, os.getcwd())
BLOCK = {"matplotlib", "fastembed", "anthropic", "openai", "pyarrow", "datasets", "sentence_transformers",
         "huggingface_hub", "onnxruntime", "pandas", "sklearn", "torch"}
class B:
    def find_spec(self, name, path=None, target=None):
        if name.split(".")[0] in BLOCK:
            raise ImportError(f"BLOCKED third-party import: {name}")
        return None
sys.meta_path.insert(0, B())
sys.argv = ["scoreswap"] + sys.argv[1:]
runpy.run_module("scoreswap", run_name="__main__")
