# eb_slope_shrink: swap-day rule at budget k = 0

**Tasks scored: the DEV half of the evaluation tasks, which is public. You may have tuned on it, and a rule can memorise it, so this is a development number, not a ranking. The board ranks on the held-out TEST half, scored by the maintainers from your entry file.**

Scored from the frozen tables of study `sim` with no model call (pack fingerprint `c209acb9e99a07ef`). Each value is a mean over the evaluation tasks; 1 seeded draw(s), each task's value the mean over the draws. Differences use the same tasks and the same draws.

Brackets: 95 % intervals. Two-way = tasks and tips both treated as sampled: msr.metrics.robust_variance, the delete-one-cluster jackknife over task ids and tips (a tip that recurs in several stream orders is one cluster; the primary interval). Theta's bracket is the union of its two-way and task-only Fieller sets (msr.metrics.theta_tests). Task-only = the task-id cluster bootstrap, 10,000 draws, seed 0 (secondary; the paper's tables of rule values use this one, so on all evaluation tasks they match it digit for digit).

First-shown success: the reader's success with the candidate the rule shows first (higher is better). Regret: the gap to the task's best candidate (lower is better). Theta: the share of the owner's home ranking signal (its `ema_grade` score with its own results) that the rule's order keeps for the reader; at a home cell the reader is the owner itself with the same results, so keep's theta there is exactly 1. Theta = order x stakes; order is 'not identifiable' where the reader's spread cannot be told from zero, and theta reads 'no home signal' where the owner's score has no ranking signal on its calibration tasks (msr.metrics.home_signal_flag).

- Run sealed: one fresh process per call, forked from a launcher that never runs the entry.
- landlock: ABI 7: read-only access to 7 folder(s) and file(s); no writes, no execution; no TCP; signals and abstract sockets scoped
- seccomp: no threads; no pipes, sockets, IPC, shared memory, key rings, ptrace, exec, xattrs or file metadata changes

## By kind of swap, dev half (public) (ddxplus)

| kind | first-shown success | minus keep | minus wipe | minus fixed_0.5 | regret | log score (level-corrected) | theta | order | checks used |
|---|---|---|---|---|---|---|---|---|---|
| same-maker upgrades | 0.683 [0.576, 0.790] (task-only [0.605, 0.759]) | -0.004 [-0.022, 0.013] | 0.036 [-0.026, 0.098] | 0.000  | 0.179 | -0.688 [-0.739, -0.637] | 0.750 [0.456, 1.195] | 1.10 [0.64, 3.29] | 0.0 |
| same-maker downgrades | 0.576 [0.461, 0.691] (task-only [0.500, 0.650]) | 0.022 [-0.005, 0.049] | 0.054 [-0.020, 0.127] | 0.000  | 0.246 | -0.677 [-0.714, -0.640] | 0.720 [0.356, 1.440] | 0.85 [0.44, 2.10] | 0.0 |
| cross-maker swaps | 0.561 [0.495, 0.628] (task-only [0.499, 0.622]) | -0.001 [-0.016, 0.014] | 0.021 [-0.031, 0.073] | 0.000  | 0.286 | -0.718 [-0.738, -0.699] | 0.198 [-0.043, 0.437] | 0.23 [-0.05, 0.49] | 0.0 |
| home cells (each owner reading its own bank) | 0.670 [0.605, 0.734] (task-only [0.611, 0.725]) | -0.009 [-0.019, 0.002] | 0.085 [0.018, 0.152] | 0.000  | 0.194 | -0.675 [-0.697, -0.652] | 1.000 [1.000, 1.000] | 0.95 [0.80, 1.15] | 0.0 |

### Every ordered pair, dev half (public)

| owner -> reader | kind | first-shown success | minus keep | minus wipe | regret | theta |
|---|---|---|---|---|---|---|
| sim-a-old -> sim-a-old | home | 0.625 [0.521, 0.729] | 0.000 | 0.143 | 0.170 | 1.00 |
| sim-a-old -> sim-a-new | same_maker_upgrade | 0.714 [0.564, 0.864] | -0.009 | 0.062 | 0.170 | 0.64 |
| sim-a-old -> sim-b-old | cross_maker | 0.491 [0.384, 0.598] | -0.018 | 0.000 | 0.348 | 0.03 |
| sim-a-old -> sim-b-new | cross_maker | 0.589 [0.438, 0.740] | -0.009 | -0.054 | 0.295 | -0.15 |
| sim-a-new -> sim-a-old | same_maker_downgrade | 0.634 [0.501, 0.767] | 0.018 | 0.080 | 0.241 | 1.27 |
| sim-a-new -> sim-a-new | home | 0.688 [0.570, 0.805] | -0.018 | -0.018 | 0.214 | 1.00 |
| sim-a-new -> sim-b-old | cross_maker | 0.509 [0.399, 0.619] | 0.018 | 0.098 | 0.241 | 0.56 |
| sim-a-new -> sim-b-new | cross_maker | 0.616 [0.517, 0.715] | 0.009 | 0.000 | 0.232 | 0.39 |
| sim-b-old -> sim-a-old | cross_maker | 0.545 [0.389, 0.701] | -0.009 | 0.009 | 0.321 | 0.37 |
| sim-b-old -> sim-a-new | cross_maker | 0.607 [0.439, 0.775] | -0.018 | 0.062 | 0.259 | 0.12 |
| sim-b-old -> sim-b-old | home | 0.634 [0.487, 0.781] | 0.000 | 0.089 | 0.214 | 1.00 |
| sim-b-old -> sim-b-new | same_maker_upgrade | 0.652 [0.514, 0.790] | 0.000 | 0.009 | 0.188 | 0.84 |
| sim-b-new -> sim-a-old | cross_maker | 0.527 [0.395, 0.658] | -0.009 | 0.018 | 0.321 | 0.17 |
| sim-b-new -> sim-a-new | cross_maker | 0.607 [0.503, 0.712] | 0.027 | 0.036 | 0.268 | 0.21 |
| sim-b-new -> sim-b-old | same_maker_downgrade | 0.518 [0.335, 0.701] | 0.027 | 0.027 | 0.250 | 0.38 |
| sim-b-new -> sim-b-new | home | 0.732 [0.627, 0.837] | -0.018 | 0.125 | 0.179 | 1.00 |

Per-stream values, the Brier scores, the uncorrected log score, Cw, both intervals of every number and the paper's rules' own values are in summary.csv and compare.csv; one row per cell is in cells.csv.
