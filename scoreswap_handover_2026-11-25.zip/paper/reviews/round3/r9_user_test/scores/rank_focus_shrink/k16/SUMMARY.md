# rank_focus_shrink: swap-day rule at budget k = 16

**Tasks scored: the DEV half of the evaluation tasks, which is public. You may have tuned on it, and a rule can memorise it, so this is a development number, not a ranking. The board ranks on the held-out TEST half, scored by the maintainers from your entry file.**

Scored from the frozen tables of study `sim` with no model call (pack fingerprint `c209acb9e99a07ef`). Each value is a mean over the evaluation tasks; 200 seeded draw(s), each task's value the mean over the draws. Differences use the same tasks and the same draws.

Brackets: 95 % intervals. Two-way = tasks and tips both treated as sampled: msr.metrics.robust_variance, the delete-one-cluster jackknife over task ids and tips (a tip that recurs in several stream orders is one cluster; the primary interval). Theta's bracket is the union of its two-way and task-only Fieller sets (msr.metrics.theta_tests). Task-only = the task-id cluster bootstrap, 10,000 draws, seed 0 (secondary; the paper's tables of rule values use this one, so on all evaluation tasks they match it digit for digit).

First-shown success: the reader's success with the candidate the rule shows first (higher is better). Regret: the gap to the task's best candidate (lower is better). Theta: the share of the owner's home ranking signal (its `ema_grade` score with its own results) that the rule's order keeps for the reader; at a home cell the reader is the owner itself with the same results, so keep's theta there is exactly 1. Theta = order x stakes; order is 'not identifiable' where the reader's spread cannot be told from zero, and theta reads 'no home signal' where the owner's score has no ranking signal on its calibration tasks (msr.metrics.home_signal_flag).

- Run sealed: one fresh process per call, forked from a launcher that never runs the entry.
- landlock: ABI 7: read-only access to 7 folder(s) and file(s); no writes, no execution; no TCP; signals and abstract sockets scoped
- seccomp: no threads; no pipes, sockets, IPC, shared memory, key rings, ptrace, exec, xattrs or file metadata changes

## By kind of swap, dev half (public) (ddxplus)

| kind | first-shown success | minus keep | minus wipe | minus fixed_0.5 | minus powerprior_16 | minus recal_16 | minus retest_16 | minus audit_16 | regret | log score (level-corrected) | theta | order | checks used |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| same-maker upgrades | 0.687 [0.591, 0.783] (task-only [0.610, 0.762]) | -0.001 [-0.041, 0.040] | 0.039 [-0.018, 0.097] | 0.004 [-0.041, 0.049] | 0.008 [-0.043, 0.058] | 0.020 [-0.016, 0.056] | 0.012 [-0.045, 0.069] | 0.014 [-0.023, 0.051] | 0.175 | -0.703 [-0.746, -0.661] | 0.623 [0.378, 0.983] | 0.92 [0.52, 2.60] | 16.0 |
| same-maker downgrades | 0.555 [0.464, 0.646] (task-only [0.482, 0.628]) | 0.002 [-0.104, 0.107] | 0.033 [-0.045, 0.110] | -0.021 [-0.125, 0.084] | 0.018 [-0.069, 0.105] | 0.010 [-0.076, 0.096] | 0.042 [-0.025, 0.109] | 0.012 [-0.082, 0.106] | 0.266 | -0.685 [-0.705, -0.664] | 0.489 [0.243, 1.188] | 0.57 [0.28, 1.86] | 16.0 |
| cross-maker swaps | 0.568 [0.513, 0.624] (task-only [0.514, 0.622]) | 0.006 [-0.037, 0.048] | 0.028 [-0.013, 0.069] | 0.007 [-0.028, 0.042] | 0.026 [-0.005, 0.058] | 0.018 [-0.010, 0.045] | 0.012 [-0.015, 0.038] | 0.016 [-0.013, 0.044] | 0.279 | -0.708 [-0.722, -0.694] | 0.263 [0.126, 0.421] | 0.30 [0.16, 0.48] | 16.0 |
| home cells (each owner reading its own bank) | 0.641 [0.572, 0.709] (task-only [0.588, 0.692]) | -0.038 [-0.068, -0.008] | 0.056 [-0.002, 0.114] | -0.029 [-0.058, -0.000] | -0.024 [-0.060, 0.012] | -0.012 [-0.036, 0.012] | 0.002 [-0.030, 0.035] | -0.017 [-0.043, 0.008] | 0.223 | -0.685 [-0.704, -0.666] | 0.781 [0.616, 0.924] | 0.74 [0.55, 0.94] | 16.0 |

### Every ordered pair, dev half (public)

| owner -> reader | kind | first-shown success | minus keep | minus wipe | regret | theta |
|---|---|---|---|---|---|---|
| sim-a-old -> sim-a-old | home | 0.603 [0.470, 0.737] | -0.022 | 0.121 | 0.192 | 0.78 |
| sim-a-old -> sim-a-new | same_maker_upgrade | 0.713 [0.574, 0.853] | -0.010 | 0.062 | 0.171 | 0.64 |
| sim-a-old -> sim-b-old | cross_maker | 0.515 [0.387, 0.642] | 0.006 | 0.024 | 0.325 | 0.03 |
| sim-a-old -> sim-b-new | cross_maker | 0.612 [0.514, 0.710] | 0.014 | -0.030 | 0.272 | 0.10 |
| sim-a-new -> sim-a-old | same_maker_downgrade | 0.617 [0.513, 0.720] | 0.000 | 0.063 | 0.258 | 0.88 |
| sim-a-new -> sim-a-new | home | 0.660 [0.541, 0.780] | -0.045 | -0.045 | 0.241 | 0.94 |
| sim-a-new -> sim-b-old | cross_maker | 0.480 [0.369, 0.591] | -0.011 | 0.070 | 0.270 | 0.51 |
| sim-a-new -> sim-b-new | cross_maker | 0.614 [0.526, 0.702] | 0.007 | -0.002 | 0.234 | 0.58 |
| sim-b-old -> sim-a-old | cross_maker | 0.583 [0.472, 0.694] | 0.030 | 0.048 | 0.283 | 0.28 |
| sim-b-old -> sim-a-new | cross_maker | 0.593 [0.445, 0.742] | -0.032 | 0.048 | 0.273 | 0.25 |
| sim-b-old -> sim-b-old | home | 0.616 [0.475, 0.757] | -0.018 | 0.071 | 0.232 | 0.81 |
| sim-b-old -> sim-b-new | same_maker_upgrade | 0.660 [0.554, 0.767] | 0.008 | 0.017 | 0.179 | 0.61 |
| sim-b-new -> sim-a-old | cross_maker | 0.548 [0.435, 0.661] | 0.012 | 0.039 | 0.300 | 0.31 |
| sim-b-new -> sim-a-new | cross_maker | 0.600 [0.475, 0.724] | 0.019 | 0.028 | 0.275 | 0.20 |
| sim-b-new -> sim-b-old | same_maker_downgrade | 0.494 [0.366, 0.621] | 0.003 | 0.003 | 0.274 | 0.24 |
| sim-b-new -> sim-b-new | home | 0.683 [0.580, 0.786] | -0.067 | 0.076 | 0.228 | 0.66 |

Per-stream values, the Brier scores, the uncorrected log score, Cw, both intervals of every number and the paper's rules' own values are in summary.csv and compare.csv; one row per cell is in cells.csv.
