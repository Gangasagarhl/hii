# lift_js_score: score type

**Tasks scored: the DEV half of the evaluation tasks, which is public. You may have tuned on it, and a rule can memorise it, so this is a development number, not a ranking. The board ranks on the held-out TEST half, scored by the maintainers from your entry file.**

Scored from the frozen tables of study `sim` with no model call (pack fingerprint `c209acb9e99a07ef`).

Theta (value kept) is the share of the score's ranking signal at home (the owner's results) left with the reader's results after the swap (1 = all, 0 = none); theta = order x stakes, where order is how well the old order still fits the new model and stakes how much the new model cares which tip it gets. Theta means something only where there is a home signal to keep: 'no home signal' marks a group whose owner's score is less than 2 standard errors above zero on its calibration tasks (msr.metrics.home_signal_flag, the paper's one rule), and Cw at home is always shown beside it. Order reads 'not identifiable' where the reader's spread on the calibration tasks cannot be told from zero. Brackets: theta's 95 % set is the union of its two-way and task-only Fieller sets (msr.metrics.theta_tests); order and stakes: Fieller intervals from the same variance. Cw is the weighted concordance (0.5 = chance). In the home row the 'swap' is the self-swap: the owner's later repeats 3-4 against its repeats 1-2.

## By kind of swap, dev half (public) (ddxplus)

| kind | theta | order | stakes | home signal | Cw at home | Cw after the swap | theta of ema_grade | theta of beta_grade | theta of tags_self | theta of credit | theta of visits |
|---|---|---|---|---|---|---|---|---|---|---|---|
| same-maker upgrades | 0.72 [0.32, 1.20] | 1.06 [0.43, 2.96] | 0.68 [0.00, 1.08] | yes | 0.694 | 0.647 | 0.75 | 0.76 | 0.82 | 0.90 | 0.94 |
| same-maker downgrades | 0.88 [0.45, 2.28] | 1.04 [0.55, 2.94] | 0.85 [0.56, 1.15] | yes | 0.655 | 0.649 | 0.72 | 0.66 | 0.58 | 0.85 | 1.68 |
| cross-maker swaps | 0.27 [0.01, 0.59] | 0.31 [0.01, 0.67] | 0.87 [0.69, 1.04] | yes | 0.675 | 0.550 | 0.20 | 0.16 | 0.26 | 0.36 | 0.37 |
| home cells (each owner reading its own bank) | 1.19 [0.92, 1.59] | 1.12 [0.88, 1.47] | 1.06 [0.86, 1.24] | yes | 0.675 | 0.707 | 1.11 | 1.02 | 1.01 | 1.24 | 1.62 |

### Every ordered pair, dev half (public)

| owner -> reader | kind | theta | home signal | Cw at home | Cw after |
|---|---|---|---|---|---|
| sim-a-old -> sim-a-old | home | 1.05 [0.60, 2.03] | yes | 0.714 | 0.696 |
| sim-a-old -> sim-a-new | same_maker_upgrade | 0.55 [-0.18, 1.33] | yes | 0.714 | 0.623 |
| sim-a-old -> sim-b-old | cross_maker | -0.10 [-1.44, 0.55] | yes | 0.714 | 0.483 |
| sim-a-old -> sim-b-new | cross_maker | -0.12 [-0.73, 0.43] | yes | 0.714 | 0.477 |
| sim-a-new -> sim-a-old | same_maker_downgrade | 1.15 [0.41, 6.47] | yes | 0.629 | 0.644 |
| sim-a-new -> sim-a-new | home | 1.76 [0.89, 8.36] | yes | 0.629 | 0.728 |
| sim-a-new -> sim-b-old | cross_maker | 1.64 [0.54, 8.86] | yes | 0.629 | 0.717 |
| sim-a-new -> sim-b-new | cross_maker | 0.94 [-0.81, 4.83] | yes | 0.629 | 0.627 |
| sim-b-old -> sim-a-old | cross_maker | -0.29 [-0.88, 0.15] | yes | 0.674 | 0.449 |
| sim-b-old -> sim-a-new | cross_maker | -0.45 [-1.13, 0.21] | yes | 0.674 | 0.415 |
| sim-b-old -> sim-b-old | home | 1.11 [0.49, 1.98] | yes | 0.674 | 0.710 |
| sim-b-old -> sim-b-new | same_maker_upgrade | 0.90 [0.42, 1.66] | yes | 0.674 | 0.672 |
| sim-b-new -> sim-a-old | cross_maker | 0.72 [0.23, 4.24] | yes | 0.682 | 0.654 |
| sim-b-new -> sim-a-new | cross_maker | 0.34 [-0.40, 4.57] | yes | 0.682 | 0.575 |
| sim-b-new -> sim-b-old | same_maker_downgrade | 0.71 [0.22, 4.40] | yes | 0.682 | 0.654 |
| sim-b-new -> sim-b-new | home | 1.01 [0.59, 2.40] | yes | 0.682 | 0.695 |

Per-stream values and the task-only bootstrap intervals are in summary.csv; differences in theta against the paper's five score types (bootstrap) are in compare.csv.
