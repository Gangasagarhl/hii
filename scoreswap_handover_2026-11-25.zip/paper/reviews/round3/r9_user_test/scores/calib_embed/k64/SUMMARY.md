# calib_embed: swap-day rule at budget k = 64

**Tasks scored: the DEV half of the evaluation tasks, which is public. You may have tuned on it, and a rule can memorise it, so this is a development number, not a ranking. The board ranks on the held-out TEST half, scored by the maintainers from your entry file.**

Scored from the frozen tables of study `sim` with no model call (pack fingerprint `c209acb9e99a07ef`). Each value is a mean over the evaluation tasks; 200 seeded draw(s), each task's value the mean over the draws. Differences use the same tasks and the same draws.

Brackets: 95 % intervals. Two-way = tasks and tips both treated as sampled: msr.metrics.robust_variance, the delete-one-cluster jackknife over task ids and tips (a tip that recurs in several stream orders is one cluster; the primary interval). Theta's bracket is the union of its two-way and task-only Fieller sets (msr.metrics.theta_tests). Task-only = the task-id cluster bootstrap, 10,000 draws, seed 0 (secondary; the paper's tables of rule values use this one, so on all evaluation tasks they match it digit for digit).

First-shown success: the reader's success with the candidate the rule shows first (higher is better). Regret: the gap to the task's best candidate (lower is better). Theta: the share of the owner's home ranking signal (its `ema_grade` score with its own results) that the rule's order keeps for the reader; at a home cell the reader is the owner itself with the same results, so keep's theta there is exactly 1. Theta = order x stakes; order is 'not identifiable' where the reader's spread cannot be told from zero, and theta reads 'no home signal' where the owner's score has no ranking signal on its calibration tasks (msr.metrics.home_signal_flag).

- Run sealed: one fresh process per call, forked from a launcher that never runs the entry.
- landlock: ABI 7: read-only access to 7 folder(s) and file(s); no writes, no execution; no TCP; signals and abstract sockets scoped
- seccomp: no threads; no pipes, sockets, IPC, shared memory, key rings, ptrace, exec, xattrs or file metadata changes

## By kind of swap, dev half (public) (ddxplus)

| kind | first-shown success | minus keep | minus wipe | minus fixed_0.5 | minus powerprior_64 | minus recal_64 | minus retest_64 | minus audit_64 | regret | log score (level-corrected) | theta | order | checks used |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| same-maker upgrades | 0.688 [0.588, 0.787] (task-only [0.605, 0.768]) | 0.000 [-0.037, 0.037] | 0.040 [-0.027, 0.107] | 0.004 [-0.035, 0.044] | 0.002 [-0.053, 0.057] | 0.011 [-0.029, 0.051] | 0.052 [-0.021, 0.126] | 0.007 [-0.032, 0.046] | 0.174 | -0.773 [-0.853, -0.694] | 0.913 [0.599, 1.421] | 1.35 [0.86, 3.89] | 0.0 |
| same-maker downgrades | 0.571 [0.486, 0.657] (task-only [0.495, 0.645]) | 0.018 [-0.041, 0.077] | 0.049 [-0.032, 0.130] | -0.004 [-0.067, 0.058] | 0.035 [-0.026, 0.096] | 0.005 [-0.052, 0.063] | 0.039 [-0.030, 0.108] | 0.021 [-0.036, 0.078] | 0.250 | -0.695 [-0.750, -0.641] | 0.839 [0.454, 1.871] | 0.99 [0.56, 2.70] | 0.0 |
| cross-maker swaps | 0.613 [0.555, 0.671] (task-only [0.555, 0.669]) | 0.050 [0.013, 0.088] | 0.073 [0.024, 0.121] | 0.051 [0.019, 0.084] | 0.071 [0.033, 0.109] | 0.063 [0.031, 0.095] | 0.035 [0.003, 0.068] | 0.059 [0.028, 0.089] | 0.234 | -0.776 [-0.835, -0.718] | 0.547 [0.253, 0.915] | 0.63 [0.32, 1.05] | 0.0 |
| home cells (each owner reading its own bank) | 0.667 [0.603, 0.731] (task-only [0.614, 0.719]) | -0.011 [-0.073, 0.051] | 0.083 [0.006, 0.159] | -0.002 [-0.058, 0.054] | -0.010 [-0.065, 0.044] | 0.001 [-0.057, 0.060] | 0.057 [0.002, 0.112] | -0.006 [-0.066, 0.054] | 0.196 | -0.720 [-0.767, -0.672] | 1.129 [0.896, 1.469] | 1.07 [0.80, 1.50] | 0.0 |

### Every ordered pair, dev half (public)

| owner -> reader | kind | first-shown success | minus keep | minus wipe | regret | theta |
|---|---|---|---|---|---|---|
| sim-a-old -> sim-a-old | home | 0.616 [0.510, 0.722] | -0.009 | 0.134 | 0.179 | 1.09 |
| sim-a-old -> sim-a-new | same_maker_upgrade | 0.705 [0.561, 0.850] | -0.018 | 0.054 | 0.179 | 0.69 |
| sim-a-old -> sim-b-old | cross_maker | 0.562 [0.448, 0.677] | 0.054 | 0.071 | 0.277 | 0.39 |
| sim-a-old -> sim-b-new | cross_maker | 0.607 [0.500, 0.715] | 0.009 | -0.036 | 0.277 | 0.33 |
| sim-a-new -> sim-a-old | same_maker_downgrade | 0.652 [0.559, 0.744] | 0.036 | 0.098 | 0.223 | 1.30 |
| sim-a-new -> sim-a-new | home | 0.661 [0.521, 0.801] | -0.045 | -0.045 | 0.241 | 1.20 |
| sim-a-new -> sim-b-old | cross_maker | 0.571 [0.459, 0.684] | 0.080 | 0.161 | 0.179 | 1.18 |
| sim-a-new -> sim-b-new | cross_maker | 0.616 [0.511, 0.721] | 0.009 | 0.000 | 0.232 | 1.13 |
| sim-b-old -> sim-a-old | cross_maker | 0.688 [0.583, 0.792] | 0.134 | 0.152 | 0.179 | 0.70 |
| sim-b-old -> sim-a-new | cross_maker | 0.616 [0.448, 0.784] | -0.009 | 0.071 | 0.250 | 0.16 |
| sim-b-old -> sim-b-old | home | 0.652 [0.535, 0.769] | 0.018 | 0.107 | 0.196 | 1.19 |
| sim-b-old -> sim-b-new | same_maker_upgrade | 0.670 [0.564, 0.775] | 0.018 | 0.027 | 0.170 | 1.10 |
| sim-b-new -> sim-a-old | cross_maker | 0.589 [0.476, 0.703] | 0.054 | 0.080 | 0.259 | 0.65 |
| sim-b-new -> sim-a-new | cross_maker | 0.652 [0.519, 0.784] | 0.071 | 0.080 | 0.223 | 0.23 |
| sim-b-new -> sim-b-old | same_maker_downgrade | 0.491 [0.350, 0.632] | 0.000 | 0.000 | 0.277 | 0.56 |
| sim-b-new -> sim-b-new | home | 0.741 [0.624, 0.858] | -0.009 | 0.134 | 0.170 | 1.05 |

Per-stream values, the Brier scores, the uncorrected log score, Cw, both intervals of every number and the paper's rules' own values are in summary.csv and compare.csv; one row per cell is in cells.csv.
