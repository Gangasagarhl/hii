# dev_memo: swap-day rule at budget k = 0

**Tasks scored: the DEV half of the evaluation tasks, which is public. You may have tuned on it, and a rule can memorise it, so this is a development number, not a ranking. The board ranks on the held-out TEST half, scored by the maintainers from your entry file.**

Scored from the frozen tables of study `sim` with no model call (pack fingerprint `c209acb9e99a07ef`). Each value is a mean over the evaluation tasks; 1 seeded draw(s), each task's value the mean over the draws. Differences use the same tasks and the same draws.

Brackets: 95 % intervals. Two-way = tasks and tips both treated as sampled: msr.metrics.robust_variance, the delete-one-cluster jackknife over task ids and tips (a tip that recurs in several stream orders is one cluster; the primary interval). Theta's bracket is the union of its two-way and task-only Fieller sets (msr.metrics.theta_tests). Task-only = the task-id cluster bootstrap, 10,000 draws, seed 0 (secondary; the paper's tables of rule values use this one, so on all evaluation tasks they match it digit for digit).

First-shown success: the reader's success with the candidate the rule shows first (higher is better). Regret: the gap to the task's best candidate (lower is better). Theta: the share of the owner's home ranking signal (its `ema_grade` score with its own results) that the rule's order keeps for the reader; at a home cell the reader is the owner itself with the same results, so keep's theta there is exactly 1. Theta = order x stakes; order is 'not identifiable' where the reader's spread cannot be told from zero, and theta reads 'no home signal' where the owner's score has no ranking signal on its calibration tasks (msr.metrics.home_signal_flag).

- Run sealed: one fresh process per call, forked from a launcher that never runs the entry.
- landlock: ABI 7: read-only access to 7 folder(s) and file(s); no writes, no execution; no TCP; signals and abstract sockets scoped
- seccomp: no threads; no pipes, sockets, IPC, shared memory, key rings, ptrace, exec, xattrs or file metadata changes

## By kind of swap, dev half (public) (ddxplus)

| kind | first-shown success | minus keep | minus wipe | minus fixed_0.5 | regret | theta | order | checks used |
|---|---|---|---|---|---|---|---|---|
| same-maker upgrades | 0.862 [0.800, 0.923] (task-only [0.807, 0.912]) | 0.174 [0.109, 0.239] | 0.214 [0.134, 0.295] | 0.179 [0.108, 0.249] | 0.000 | 1.212 [0.830, 1.942] | 1.78 [1.14, 5.42] | 0.0 |
| same-maker downgrades | 0.821 [0.759, 0.884] (task-only [0.759, 0.877]) | 0.268 [0.194, 0.342] | 0.299 [0.225, 0.373] | 0.246 [0.163, 0.328] | 0.000 | 1.656 [1.004, 4.160] | 1.94 [1.14, 6.57] | 0.0 |
| cross-maker swaps | 0.847 [0.804, 0.890] (task-only [0.804, 0.887]) | 0.285 [0.240, 0.329] | 0.307 [0.269, 0.345] | 0.286 [0.246, 0.326] | 0.000 | 1.442 [1.072, 2.172] | 1.66 [1.18, 2.81] | 0.0 |
| home cells (each owner reading its own bank) | 0.864 [0.819, 0.909] (task-only [0.827, 0.899]) | 0.185 [0.127, 0.243] | 0.279 [0.219, 0.339] | 0.194 [0.143, 0.245] | 0.000 | 1.525 [1.110, 2.336] | 1.45 [1.03, 2.31] | 0.0 |

### Every ordered pair, dev half (public)

| owner -> reader | kind | first-shown success | minus keep | minus wipe | regret | theta |
|---|---|---|---|---|---|---|
| sim-a-old -> sim-a-old | home | 0.795 [0.700, 0.889] | 0.170 | 0.312 | 0.000 | 1.40 |
| sim-a-old -> sim-a-new | same_maker_upgrade | 0.884 [0.810, 0.958] | 0.161 | 0.232 | 0.000 | 1.23 |
| sim-a-old -> sim-b-old | cross_maker | 0.839 [0.721, 0.957] | 0.330 | 0.348 | 0.000 | 1.66 |
| sim-a-old -> sim-b-new | cross_maker | 0.884 [0.814, 0.954] | 0.286 | 0.241 | 0.000 | 1.37 |
| sim-a-new -> sim-a-old | same_maker_downgrade | 0.875 [0.800, 0.950] | 0.259 | 0.321 | 0.000 | 2.23 |
| sim-a-new -> sim-a-new | home | 0.902 [0.825, 0.978] | 0.196 | 0.196 | 0.000 | 2.06 |
| sim-a-new -> sim-b-old | cross_maker | 0.750 [0.663, 0.837] | 0.259 | 0.339 | 0.000 | 2.13 |
| sim-a-new -> sim-b-new | cross_maker | 0.848 [0.778, 0.919] | 0.241 | 0.232 | 0.000 | 1.97 |
| sim-b-old -> sim-a-old | cross_maker | 0.866 [0.788, 0.945] | 0.312 | 0.330 | 0.000 | 1.25 |
| sim-b-old -> sim-a-new | cross_maker | 0.866 [0.769, 0.963] | 0.241 | 0.321 | 0.000 | 1.20 |
| sim-b-old -> sim-b-old | home | 0.848 [0.750, 0.946] | 0.214 | 0.304 | 0.000 | 1.40 |
| sim-b-old -> sim-b-new | same_maker_upgrade | 0.839 [0.758, 0.920] | 0.188 | 0.196 | 0.000 | 1.19 |
| sim-b-new -> sim-a-old | cross_maker | 0.848 [0.778, 0.919] | 0.312 | 0.339 | 0.000 | 1.30 |
| sim-b-new -> sim-a-new | cross_maker | 0.875 [0.795, 0.955] | 0.295 | 0.304 | 0.000 | 1.14 |
| sim-b-new -> sim-b-old | same_maker_downgrade | 0.768 [0.686, 0.850] | 0.277 | 0.277 | 0.000 | 1.30 |
| sim-b-new -> sim-b-new | home | 0.911 [0.861, 0.961] | 0.161 | 0.304 | 0.000 | 1.43 |

Per-stream values, the Brier scores, the uncorrected log score, Cw, both intervals of every number and the paper's rules' own values are in summary.csv and compare.csv; one row per cell is in cells.csv.
