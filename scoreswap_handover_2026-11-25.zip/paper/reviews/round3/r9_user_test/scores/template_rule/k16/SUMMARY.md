# template_rule: swap-day rule at budget k = 16

**Tasks scored: the DEV half of the evaluation tasks, which is public. You may have tuned on it, and a rule can memorise it, so this is a development number, not a ranking. The board ranks on the held-out TEST half, scored by the maintainers from your entry file.**

Scored from the frozen tables of study `sim` with no model call (pack fingerprint `c209acb9e99a07ef`). Each value is a mean over the evaluation tasks; 200 seeded draw(s), each task's value the mean over the draws. Differences use the same tasks and the same draws.

Brackets: 95 % intervals. Two-way = tasks and tips both treated as sampled: msr.metrics.robust_variance, the delete-one-cluster jackknife over task ids and tips (a tip that recurs in several stream orders is one cluster; the primary interval). Theta's bracket is the union of its two-way and task-only Fieller sets (msr.metrics.theta_tests). Task-only = the task-id cluster bootstrap, 10,000 draws, seed 0 (secondary; the paper's tables of rule values use this one, so on all evaluation tasks they match it digit for digit).

First-shown success: the reader's success with the candidate the rule shows first (higher is better). Regret: the gap to the task's best candidate (lower is better). Theta: the share of the owner's home ranking signal (its `ema_grade` score with its own results) that the rule's order keeps for the reader; at a home cell the reader is the owner itself with the same results, so keep's theta there is exactly 1. Theta = order x stakes; order is 'not identifiable' where the reader's spread cannot be told from zero, and theta reads 'no home signal' where the owner's score has no ranking signal on its calibration tasks (msr.metrics.home_signal_flag).

- Run sealed: one fresh process per call, forked from a launcher that never runs the entry.
- landlock: ABI 7: read-only access to 7 folder(s) and file(s); no writes, no execution; no TCP; signals and abstract sockets scoped
- seccomp: no threads; no pipes, sockets, IPC, shared memory, key rings, ptrace, exec, xattrs or file metadata changes

## By kind of swap, dev half (public) (ddxplus)

| kind | first-shown success | minus keep | minus wipe | minus fixed_0.5 | minus powerprior_16 | minus recal_16 | minus retest_16 | minus audit_16 | regret | log score (level-corrected) | theta | order | checks used |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| same-maker upgrades | 0.690 [0.593, 0.786] (task-only [0.614, 0.762]) | 0.002 [-0.009, 0.013] | 0.042 [-0.019, 0.103] | 0.007 [-0.017, 0.030] | 0.011 [-0.026, 0.047] | 0.022 [0.003, 0.042] | 0.015 [-0.047, 0.076] | 0.017 [-0.002, 0.036] | 0.172 | -0.749 [-0.840, -0.658] | 0.790 [0.504, 1.240] | 1.16 [0.70, 3.44] | 16.0 |
| same-maker downgrades | 0.566 [0.481, 0.650] (task-only [0.497, 0.636]) | 0.012 [-0.011, 0.036] | 0.044 [-0.024, 0.111] | -0.010 [-0.044, 0.024] | 0.028 [-0.017, 0.074] | 0.021 [-0.005, 0.047] | 0.052 [-0.029, 0.134] | 0.023 [-0.005, 0.051] | 0.256 | -0.752 [-0.846, -0.659] | 0.758 [0.411, 1.579] | 0.89 [0.49, 2.37] | 16.0 |
| cross-maker swaps | 0.573 [0.509, 0.636] (task-only [0.514, 0.630]) | 0.010 [-0.002, 0.022] | 0.032 [-0.020, 0.085] | 0.011 [0.000, 0.022] | 0.031 [-0.004, 0.066] | 0.022 [-0.005, 0.050] | 0.016 [-0.030, 0.062] | 0.020 [-0.003, 0.043] | 0.275 | -0.832 [-0.880, -0.784] | 0.256 [0.028, 0.492] | 0.29 [0.04, 0.55] | 16.0 |
| home cells (each owner reading its own bank) | 0.671 [0.605, 0.738] (task-only [0.613, 0.726]) | -0.007 [-0.020, 0.006] | 0.086 [0.025, 0.148] | 0.002 [-0.009, 0.013] | 0.006 [-0.029, 0.041] | 0.019 [0.005, 0.032] | 0.033 [-0.005, 0.070] | 0.013 [0.002, 0.024] | 0.193 | -0.727 [-0.780, -0.674] | 1.021 [0.986, 1.066] | 0.97 [0.83, 1.18] | 16.0 |

### Every ordered pair, dev half (public)

| owner -> reader | kind | first-shown success | minus keep | minus wipe | regret | theta |
|---|---|---|---|---|---|---|
| sim-a-old -> sim-a-old | home | 0.630 [0.530, 0.730] | 0.005 | 0.148 | 0.165 | 1.01 |
| sim-a-old -> sim-a-new | same_maker_upgrade | 0.720 [0.581, 0.859] | -0.003 | 0.068 | 0.164 | 0.67 |
| sim-a-old -> sim-b-old | cross_maker | 0.511 [0.410, 0.612] | 0.002 | 0.020 | 0.328 | 0.12 |
| sim-a-old -> sim-b-new | cross_maker | 0.591 [0.442, 0.740] | -0.007 | -0.052 | 0.293 | -0.05 |
| sim-a-new -> sim-a-old | same_maker_downgrade | 0.629 [0.532, 0.726] | 0.013 | 0.075 | 0.246 | 1.30 |
| sim-a-new -> sim-a-new | home | 0.697 [0.571, 0.823] | -0.008 | -0.008 | 0.205 | 1.08 |
| sim-a-new -> sim-b-old | cross_maker | 0.519 [0.414, 0.624] | 0.028 | 0.108 | 0.231 | 0.74 |
| sim-a-new -> sim-b-new | cross_maker | 0.626 [0.532, 0.720] | 0.019 | 0.010 | 0.222 | 0.56 |
| sim-b-old -> sim-a-old | cross_maker | 0.570 [0.431, 0.709] | 0.016 | 0.034 | 0.296 | 0.39 |
| sim-b-old -> sim-a-new | cross_maker | 0.626 [0.476, 0.777] | 0.001 | 0.082 | 0.240 | 0.12 |
| sim-b-old -> sim-b-old | home | 0.622 [0.482, 0.761] | -0.012 | 0.077 | 0.227 | 1.01 |
| sim-b-old -> sim-b-new | same_maker_upgrade | 0.659 [0.541, 0.777] | 0.007 | 0.016 | 0.180 | 0.89 |
| sim-b-new -> sim-a-old | cross_maker | 0.540 [0.401, 0.679] | 0.004 | 0.031 | 0.308 | 0.20 |
| sim-b-new -> sim-a-new | cross_maker | 0.598 [0.493, 0.702] | 0.017 | 0.026 | 0.277 | 0.20 |
| sim-b-new -> sim-b-old | same_maker_downgrade | 0.503 [0.372, 0.634] | 0.012 | 0.012 | 0.265 | 0.42 |
| sim-b-new -> sim-b-new | home | 0.737 [0.626, 0.847] | -0.013 | 0.129 | 0.174 | 1.00 |

Per-stream values, the Brier scores, the uncorrected log score, Cw, both intervals of every number and the paper's rules' own values are in summary.csv and compare.csv; one row per cell is in cells.csv.
