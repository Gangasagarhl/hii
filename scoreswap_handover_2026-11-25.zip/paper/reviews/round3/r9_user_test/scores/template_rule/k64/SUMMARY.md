# template_rule: swap-day rule at budget k = 64

**Tasks scored: the DEV half of the evaluation tasks, which is public. You may have tuned on it, and a rule can memorise it, so this is a development number, not a ranking. The board ranks on the held-out TEST half, scored by the maintainers from your entry file.**

Scored from the frozen tables of study `sim` with no model call (pack fingerprint `c209acb9e99a07ef`). Each value is a mean over the evaluation tasks; 200 seeded draw(s), each task's value the mean over the draws. Differences use the same tasks and the same draws.

Brackets: 95 % intervals. Two-way = tasks and tips both treated as sampled: msr.metrics.robust_variance, the delete-one-cluster jackknife over task ids and tips (a tip that recurs in several stream orders is one cluster; the primary interval). Theta's bracket is the union of its two-way and task-only Fieller sets (msr.metrics.theta_tests). Task-only = the task-id cluster bootstrap, 10,000 draws, seed 0 (secondary; the paper's tables of rule values use this one, so on all evaluation tasks they match it digit for digit).

First-shown success: the reader's success with the candidate the rule shows first (higher is better). Regret: the gap to the task's best candidate (lower is better). Theta: the share of the owner's home ranking signal (its `ema_grade` score with its own results) that the rule's order keeps for the reader; at a home cell the reader is the owner itself with the same results, so keep's theta there is exactly 1. Theta = order x stakes; order is 'not identifiable' where the reader's spread cannot be told from zero, and theta reads 'no home signal' where the owner's score has no ranking signal on its calibration tasks (msr.metrics.home_signal_flag).

- Run sealed: one fresh process per call, forked from a launcher that never runs the entry.
- landlock: ABI 7: read-only access to 7 folder(s) and file(s); no writes, no execution; no TCP; signals and abstract sockets scoped
- seccomp: no threads; no pipes, sockets, IPC, shared memory, key rings, ptrace, exec, xattrs or file metadata changes

## By kind of swap, dev half (public) (ddxplus)

| kind | first-shown success | minus keep | minus wipe | minus fixed_0.5 | minus powerprior_64 | minus recal_64 | minus retest_64 | minus audit_64 | regret | log score (level-corrected) | theta | order | checks used |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| same-maker upgrades | 0.696 [0.600, 0.791] (task-only [0.620, 0.768]) | 0.008 [-0.018, 0.034] | 0.048 [-0.010, 0.107] | 0.012 [-0.019, 0.044] | 0.010 [-0.033, 0.054] | 0.019 [-0.012, 0.050] | 0.060 [-0.001, 0.122] | 0.015 [-0.012, 0.042] | 0.166 | -0.759 [-0.843, -0.674] | 0.847 [0.562, 1.308] | 1.25 [0.76, 3.77] | 64.0 |
| same-maker downgrades | 0.588 [0.510, 0.666] (task-only [0.518, 0.656]) | 0.034 [-0.012, 0.081] | 0.066 [-0.009, 0.140] | 0.012 [-0.040, 0.064] | 0.052 [-0.002, 0.105] | 0.022 [-0.027, 0.071] | 0.056 [-0.013, 0.125] | 0.037 [-0.007, 0.081] | 0.233 | -0.731 [-0.801, -0.661] | 0.846 [0.500, 1.817] | 0.99 [0.59, 2.75] | 64.0 |
| cross-maker swaps | 0.596 [0.539, 0.653] (task-only [0.539, 0.651]) | 0.034 [0.008, 0.060] | 0.056 [0.008, 0.104] | 0.035 [0.014, 0.056] | 0.054 [0.019, 0.089] | 0.046 [0.019, 0.074] | 0.019 [-0.021, 0.058] | 0.042 [0.021, 0.063] | 0.251 | -0.810 [-0.860, -0.760] | 0.388 [0.161, 0.660] | 0.45 [0.20, 0.74] | 64.0 |
| home cells (each owner reading its own bank) | 0.666 [0.604, 0.728] (task-only [0.612, 0.719]) | -0.013 [-0.040, 0.015] | 0.081 [0.026, 0.137] | -0.004 [-0.025, 0.018] | -0.012 [-0.043, 0.019] | -0.000 [-0.024, 0.024] | 0.056 [0.012, 0.099] | -0.007 [-0.032, 0.017] | 0.198 | -0.727 [-0.775, -0.678] | 1.075 [0.952, 1.275] | 1.02 [0.85, 1.30] | 64.0 |

### Every ordered pair, dev half (public)

| owner -> reader | kind | first-shown success | minus keep | minus wipe | regret | theta |
|---|---|---|---|---|---|---|
| sim-a-old -> sim-a-old | home | 0.623 [0.523, 0.723] | -0.002 | 0.141 | 0.172 | 1.02 |
| sim-a-old -> sim-a-new | same_maker_upgrade | 0.717 [0.579, 0.855] | -0.007 | 0.065 | 0.167 | 0.65 |
| sim-a-old -> sim-b-old | cross_maker | 0.540 [0.440, 0.640] | 0.031 | 0.049 | 0.300 | 0.37 |
| sim-a-old -> sim-b-new | cross_maker | 0.610 [0.501, 0.720] | 0.012 | -0.032 | 0.273 | 0.12 |
| sim-a-new -> sim-a-old | same_maker_downgrade | 0.656 [0.571, 0.741] | 0.040 | 0.102 | 0.219 | 1.43 |
| sim-a-new -> sim-a-new | home | 0.692 [0.570, 0.814] | -0.013 | -0.013 | 0.210 | 1.23 |
| sim-a-new -> sim-b-old | cross_maker | 0.575 [0.469, 0.680] | 0.084 | 0.164 | 0.175 | 1.08 |
| sim-a-new -> sim-b-new | cross_maker | 0.645 [0.551, 0.738] | 0.037 | 0.028 | 0.204 | 0.82 |
| sim-b-old -> sim-a-old | cross_maker | 0.618 [0.530, 0.706] | 0.065 | 0.083 | 0.248 | 0.49 |
| sim-b-old -> sim-a-new | cross_maker | 0.622 [0.472, 0.772] | -0.003 | 0.078 | 0.244 | 0.12 |
| sim-b-old -> sim-b-old | home | 0.620 [0.489, 0.750] | -0.014 | 0.075 | 0.229 | 1.04 |
| sim-b-old -> sim-b-new | same_maker_upgrade | 0.674 [0.565, 0.784] | 0.023 | 0.032 | 0.165 | 1.01 |
| sim-b-new -> sim-a-old | cross_maker | 0.552 [0.413, 0.691] | 0.016 | 0.043 | 0.296 | 0.29 |
| sim-b-new -> sim-a-new | cross_maker | 0.606 [0.489, 0.723] | 0.026 | 0.035 | 0.269 | 0.19 |
| sim-b-new -> sim-b-old | same_maker_downgrade | 0.520 [0.400, 0.640] | 0.029 | 0.029 | 0.248 | 0.49 |
| sim-b-new -> sim-b-new | home | 0.730 [0.640, 0.819] | -0.020 | 0.122 | 0.181 | 1.06 |

Per-stream values, the Brier scores, the uncorrected log score, Cw, both intervals of every number and the paper's rules' own values are in summary.csv and compare.csv; one row per cell is in cells.csv.
