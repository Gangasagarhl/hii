# template_rule: swap-day rule at budget k = 8

**Tasks scored: the DEV half of the evaluation tasks, which is public. You may have tuned on it, and a rule can memorise it, so this is a development number, not a ranking. The board ranks on the held-out TEST half, scored by the maintainers from your entry file.**

Scored from the frozen tables of study `sim` with no model call (pack fingerprint `c209acb9e99a07ef`). Each value is a mean over the evaluation tasks; 200 seeded draw(s), each task's value the mean over the draws. Differences use the same tasks and the same draws.

Brackets: 95 % intervals. Two-way = tasks and tips both treated as sampled: msr.metrics.robust_variance, the delete-one-cluster jackknife over task ids and tips (a tip that recurs in several stream orders is one cluster; the primary interval). Theta's bracket is the union of its two-way and task-only Fieller sets (msr.metrics.theta_tests). Task-only = the task-id cluster bootstrap, 10,000 draws, seed 0 (secondary; the paper's tables of rule values use this one, so on all evaluation tasks they match it digit for digit).

First-shown success: the reader's success with the candidate the rule shows first (higher is better). Regret: the gap to the task's best candidate (lower is better). Theta: the share of the owner's home ranking signal (its `ema_grade` score with its own results) that the rule's order keeps for the reader; at a home cell the reader is the owner itself with the same results, so keep's theta there is exactly 1. Theta = order x stakes; order is 'not identifiable' where the reader's spread cannot be told from zero, and theta reads 'no home signal' where the owner's score has no ranking signal on its calibration tasks (msr.metrics.home_signal_flag).

- Run sealed: one fresh process per call, forked from a launcher that never runs the entry.
- landlock: ABI 7: read-only access to 7 folder(s) and file(s); no writes, no execution; no TCP; signals and abstract sockets scoped
- seccomp: no threads; no pipes, sockets, IPC, shared memory, key rings, ptrace, exec, xattrs or file metadata changes

## By kind of swap, dev half (public) (ddxplus)

| kind | first-shown success | minus keep | minus wipe | minus fixed_0.5 | minus powerprior_8 | minus recal_8 | minus retest_8 | minus audit_8 | regret | log score (level-corrected) | theta | order | checks used |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| same-maker upgrades | 0.688 [0.590, 0.786] (task-only [0.613, 0.761]) | 0.001 [-0.005, 0.007] | 0.041 [-0.021, 0.103] | 0.005 [-0.014, 0.025] | 0.013 [-0.025, 0.050] | 0.025 [0.007, 0.042] | 0.004 [-0.050, 0.058] | 0.016 [-0.004, 0.036] | 0.173 | -0.746 [-0.839, -0.652] | 0.772 [0.483, 1.218] | 1.14 [0.67, 3.40] | 8.0 |
| same-maker downgrades | 0.560 [0.471, 0.650] (task-only [0.490, 0.633]) | 0.007 [-0.007, 0.021] | 0.038 [-0.027, 0.104] | -0.015 [-0.044, 0.014] | 0.021 [-0.023, 0.065] | 0.020 [-0.004, 0.044] | 0.049 [-0.027, 0.125] | 0.019 [-0.005, 0.043] | 0.261 | -0.755 [-0.853, -0.657] | 0.737 [0.386, 1.506] | 0.87 [0.47, 2.24] | 8.0 |
| cross-maker swaps | 0.568 [0.502, 0.633] (task-only [0.508, 0.626]) | 0.005 [-0.003, 0.013] | 0.027 [-0.027, 0.082] | 0.006 [-0.005, 0.018] | 0.026 [-0.010, 0.062] | 0.016 [-0.008, 0.041] | 0.018 [-0.035, 0.071] | 0.015 [-0.009, 0.039] | 0.279 | -0.836 [-0.884, -0.788] | 0.226 [-0.005, 0.459] | 0.26 [-0.01, 0.51] | 8.0 |
| home cells (each owner reading its own bank) | 0.675 [0.606, 0.743] (task-only [0.616, 0.731]) | -0.004 [-0.012, 0.004] | 0.090 [0.024, 0.156] | 0.005 [-0.005, 0.015] | 0.016 [-0.024, 0.056] | 0.030 [0.014, 0.046] | 0.050 [-0.002, 0.103] | 0.025 [0.007, 0.043] | 0.189 | -0.727 [-0.780, -0.673] | 1.010 [0.988, 1.038] | 0.96 [0.81, 1.16] | 8.0 |

### Every ordered pair, dev half (public)

| owner -> reader | kind | first-shown success | minus keep | minus wipe | regret | theta |
|---|---|---|---|---|---|---|
| sim-a-old -> sim-a-old | home | 0.632 [0.531, 0.733] | 0.007 | 0.150 | 0.163 | 1.00 |
| sim-a-old -> sim-a-new | same_maker_upgrade | 0.720 [0.578, 0.862] | -0.003 | 0.068 | 0.164 | 0.65 |
| sim-a-old -> sim-b-old | cross_maker | 0.507 [0.403, 0.611] | -0.002 | 0.016 | 0.332 | 0.06 |
| sim-a-old -> sim-b-new | cross_maker | 0.592 [0.439, 0.744] | -0.007 | -0.051 | 0.292 | -0.09 |
| sim-a-new -> sim-a-old | same_maker_downgrade | 0.621 [0.516, 0.725] | 0.005 | 0.067 | 0.254 | 1.28 |
| sim-a-new -> sim-a-new | home | 0.698 [0.566, 0.831] | -0.007 | -0.007 | 0.203 | 1.04 |
| sim-a-new -> sim-b-old | cross_maker | 0.508 [0.402, 0.614] | 0.017 | 0.098 | 0.242 | 0.67 |
| sim-a-new -> sim-b-new | cross_maker | 0.617 [0.522, 0.713] | 0.010 | 0.001 | 0.231 | 0.48 |
| sim-b-old -> sim-a-old | cross_maker | 0.564 [0.411, 0.716] | 0.010 | 0.028 | 0.303 | 0.38 |
| sim-b-old -> sim-a-new | cross_maker | 0.625 [0.468, 0.782] | 0.000 | 0.080 | 0.241 | 0.12 |
| sim-b-old -> sim-b-old | home | 0.626 [0.483, 0.768] | -0.008 | 0.081 | 0.223 | 1.00 |
| sim-b-old -> sim-b-new | same_maker_upgrade | 0.657 [0.536, 0.778] | 0.005 | 0.014 | 0.182 | 0.87 |
| sim-b-new -> sim-a-old | cross_maker | 0.540 [0.398, 0.682] | 0.004 | 0.031 | 0.308 | 0.18 |
| sim-b-new -> sim-a-new | cross_maker | 0.588 [0.484, 0.693] | 0.008 | 0.017 | 0.287 | 0.20 |
| sim-b-new -> sim-b-old | same_maker_downgrade | 0.500 [0.360, 0.640] | 0.009 | 0.009 | 0.268 | 0.40 |
| sim-b-new -> sim-b-new | home | 0.743 [0.626, 0.860] | -0.007 | 0.136 | 0.167 | 1.01 |

Per-stream values, the Brier scores, the uncorrected log score, Cw, both intervals of every number and the paper's rules' own values are in summary.csv and compare.csv; one row per cell is in cells.csv.
