# Review R7: statistics, sequential testing and evaluation methodology

Reviewer focus: estimands and identification, validity of the primary tests and intervals, the swap-day tests and
the lower bound, agreement of pre-registration, code and paper. Everything below was checked on simulated data with
my own data-generating processes calling the authors' functions (`msr.metrics.theta_tests`, `robust_variance`,
`msr.sequential.decide_margin0`, `decide_keep_or_drop`, `home_signal_flag`, `least_favourable`,
`adaptive_constants`, `plugin_bound_interval`). No model was called. Scripts and raw outputs are in
`paper/reviews/round3/r7_checks/` (list at the end).

## 1. Summary of the submission

The paper asks whether learned per-item usefulness scores in an "exemplar memory" (a past task and the model's
answer, no label; one of the four most relevant items is shown, chosen by 0.5 x score + 0.5 x relevance) keep their
value when the model that reads the memory is replaced. Its headline estimand is theta = sum V_swap / sum V_home,
where V is a per-task sum over candidate pairs of the score-order sign times the reader's success difference; V is
linear in the outcomes, so theta is a ratio of two unbiasedly estimated means. Theta is split, by definition, into
"retained order" times "stakes" using cross-session second moments of item effects. Twelve primary tests (theta < 1,
theta < 0.75, theta > 0.75, each an intersection-union test with a positive-home-signal member, and keep minus wipe
in first-shown success, in each of three kinds of swap) form one Holm family, with a two-way (task id x item)
delete-one-cluster jackknife variance and Fieller sets. For the swap day the paper offers betting-martingale tests
(keep beats wipe; at most a quarter of the value lost, paired with the old model's results on the same tasks) and a
Kullback-Leibler lower bound on the number of checks. No real-model data exist: every result in `main.pdf` is a
placeholder; `dryrun.pdf` fills them from a four-model simulated practice study.

## 2. Strengths

1. **The headline is a well-chosen estimand.** V is linear in the outcomes, so theta does not move with outcome
   noise, unlike the concordance ratio R (the identity R = theta W_home / W_swap in Appendix "Transfer decomposition"
   is correct; I re-derived it). No ratio is ever tested directly; the contrasts are linear.
2. **The sign problem is solved correctly.** Putting "V_home > 0" inside every PC1 member as an intersection-union
   component (Berger 1982) makes each member valid on the whole null, including a reversed home order; labels are
   functions of rejections only, and "material drop"/"no material drop" are opposite tails of one z, so they can
   never both be shown (checked in `msr/metrics.py:2119-2186`).
3. **The swap-day tests are valid as stated, with one wording slip (W6).** In my own worlds (heterogeneous,
   sparse-signal, positively dependent checks; 4,000 streams to 2,000 tasks each) the break-even test and the paired
   0.75 test never exceeded their level (table in Section 5). The sign gate and the store stop are enforced in code
   (`msr/sequential.py:609-641`, `replay_cell` passes `n_home` and the flag).
4. **The lower bound is correct.** I checked the proof line by line (Wald identity per cell, data processing on the
   KEEP event, monotonicity of d(.||.), the KKT condition (q - p)/(q(1-q)) = -nu c, the second-order and adaptive
   closed forms by Cauchy-Schwarz). An independent SLSQP solution of the least-favourable problem agrees with
   `least_favourable` to a relative 3e-4 in all eight test cases.
5. **When items are not shared between owners, the registered jackknife does what the paper says.** In my benign
   and hub-dominated, heavy-tailed worlds the boundary sizes, theta coverage and stakes/order coverage match the
   authors' claims (Section 5).
6. **Honesty and auditability.** One function per rule, flags that never gate a test, a long list of open points, a
   pre-registration that states what each test assumes, and code that I could call directly.
7. Other proofs I checked and found correct: the Gini-correlation form of Cw, the rank form of V, the Jensen
   inequality behind the "why weighted" remark, the invariance proposition (including the lambda* = 0.25 example and
   the mixing-weight identity), the Buhlmann credibility condition, the replicate-measurement estimator of gamma and
   the centring argument for Q (up to an O(1/n) covariance term).

## 3. Weaknesses (most serious first)

**W1. [FATAL as submitted] There is no result to review, and the registration it rests on is not frozen.**
Every finding of the abstract, introduction and Sections 5-8 is a red placeholder (README Section 5 lists 9 groups of
TODO claims). The only numbers are simulation checks of the method and a four-model practice study whose own
caption says its values "say nothing about real models". The confirmatory framing depends on a pre-registration
that is still a draft (`prediction/PREREGISTRATION.md`, "Status: DRAFT, not frozen") with 30 open points, including
code that differs from three registered rulings (open point 24: the z-scored mix, recal_k's standardising SD, the
starting counts after the swap) and registered secondary analyses with no analysis code (open point 30). ICML reviews
findings, not protocols; as it stands I cannot judge any empirical claim. Fix: run the study after freezing and
depositing the registration with the code hash, or submit the protocol to a venue with a registered-report track.

**W2. [MAJOR] The item clusters are coded per owner, although every owner's candidates for a probe task are the
same four write tasks. Pooled tests then understate their variance when usefulness has a write-task component.**
- *Where.* `msr/analysis.py:3252` codes an item as `f"{o}|{b}|{v}"` (owner | stream | item id), and the item id is
  `"<write task id>@<owner>"` (`msr/build.py:63-66`); `msr/theory.py:672-673` does the same for Family T. The paper says so
  (`paper/sections/A9_statistics.tex:9`, "coded by identity within owner and stream"), as does the pre-registration
  (Part 4.1, lines 838-839; Part 11.1, line 1687).
- *Why it is wrong.* Every model writes its bank from the same 250 write tasks of an order (pre-registration 1.2),
  and retrieval uses the write task's text only (`msr/probe.py:47`, paper `A12_setup_details.tex`, "Retrieval"), so
  for a probe task all owners show the same four write tasks. The sampled unit on the item side is the write task.
  Anything about a write task that helps or hurts every version of it (its case description; whether most models
  answer it correctly; the paper's own near-duplicate and same-diagnosis effects in Appendix "Construct checks") is
  shared by all owners' items, and a reader's reaction to that write task is shared by every bank the reader reads.
  The jackknife then treats eight correlated clusters as eight independent ones. The cross-maker group pools 48
  swaps over 8 owners, each reader reading 6 banks, so it is hit hardest; P3 (pooled over all 60 swaps), Family T and
  PC2 pool the same way.
- *Evidence (my simulator, `r7_checks/r7_dgp.py`, world `shared_b75`; true theta = 0.75 exactly by construction;
  253 replications).* Cross-maker group, items coded as the analysis codes them: null z of the no-material-drop
  contrast has SD 1.67 (MC SE 0.07); PC1-NI rejects at one-sided 0.05 in 0.158 (0.023), PC1-MD in 0.213 (0.026);
  theta's 95% union Fieller set covers in 0.727 (0.028). Same data, items coded by write task within stream:
  z SD 1.03 (0.05), sizes 0.040 (0.012) and 0.055 (0.014), coverage 0.949 (0.014). The disjoint same-maker group is
  unaffected in this world (z SD 1.00, coverage 0.949), as expected, because its six readers differ. An approximate
  12-member Holm family error (Section 5) is 0.147 (0.022) with the analysis's coding and 0.052 (0.014) with
  write-task coding, against the paper's "worst simulated familywise error 0.046" (`A9_statistics.tex:25`).
  When half of each reader's reaction to a write task is common to all readers (world `common_b75`, 200
  replications), the disjoint same-maker group is hit too: PC1-NI size 0.120 (0.023), coverage 0.875 (0.023), z SD 1.28;
  cross group 0.175 (0.027), 0.755 (0.030), z SD 1.61; with write-task coding 0.045 / 0.955 and 0.025 / 0.980. PC2 is hit the same way: in a world where keep and wipe are equal in truth (world `pc2null_shared`, 200
  replications, half of the reader's reaction common to all readers), PC2 rejected at two-sided 0.05 in 0.225 (0.030)
  of replications in the cross group (null z SD 1.64) and 0.105 (0.022) in the disjoint same-maker group (z SD 1.27);
  with write-task coding 0.065 (0.017) and 0.045 (0.015). At the drop boundary (true theta = 1, world `shared_b100`,
  cross group, 150 replications) the full drop member, self-swap part included, rejected in 0.127 (0.027) at 0.05 and
  0.027 (0.013) at 0.05/12 (nominal 0.0042), coverage 0.833 (0.030); write-task coding 0.047 (0.017), 0.000, 0.947. The size of the problem depends on how much of the contrast's variance items carry: in a milder world
  (`mild_b75`, median item share 0.14, 159 replications) I saw no inflation (cross group NI 0.031, MD 0.057, coverage
  0.956, z SD 0.97). The inflation appears at item shares of 0.5-0.6 (`shared_b75`, `common_b75`); the authors' own
  full-size simulated rehearsal reached item shares of 0.61-0.86 (`docs/power/coverage_items_t.md`, note under the
  reviewer's table), so the harmful regime is the one their own rehearsal is in.
- *Why the authors' checks could not see it.* Their size and coverage simulators give each owner its own bank
  ("per (owner, stream, order) a bank of 250 items", `docs/power/power_theta.py:9-13`), and the simulated models key
  item quality on the full item id "task@writer" (`msr/sim.py:182-187`), so no item effect is shared across owners.
- *Fix.* Code item clusters by write-task id within stream for every statistic that pools owners (drop the
  "@owner" suffix in `TwoWay.__init__` and in `msr/theory.py`), keep the owner coding as a sensitivity column, and
  repeat the size and coverage simulations with a write-task component and a reader-by-write-task component. The
  change costs some power (the home member's z fell from 30 to 24 in my world) and should be in the frozen plan.

**W3. [MAJOR] The group estimands are statements about a handful of heterogeneous, model-sharing pairs, and the
reporting invites reading them as statements about "same-maker upgrades" and "cross-maker swaps".**
- All inference is conditional on the twelve models (`A9_statistics.tex:5`); dependence through a shared model is in
  no interval (pre-registration 4.1, last bullet). The same-maker groups hold six pairs that differ in kind (a
  generation step, a 27B->31B size change, "a minor update, five weeks apart", `04_setup.tex`, Table 1); the two
  extension pairs, added in revision 2 (one of them "a minor update, five weeks apart"), enter the upgrade and
  downgrade groups but not P4, so the body's group contrast and P4 compare different sets of pairs.
- The group statistic is a ratio of sums, so pairs with a large home signal dominate theta; a mean of per-pair theta
  is excluded by design ("never a mean of per-swap ratios", pre-registration 2.12), so a group value can hide one pair
  that lost everything (the range is printed, but no test reads it).
- The between-pair SD is DerSimonian-Laird with a t(k - 2) prediction interval (`msr/analysis.py:3829-3876`). With
  k = 6, the Higgins-Thompson-Spiegelhalter interval with a DerSimonian-Laird tau is known to under-cover when there
  are few studies (Partlett and Riley, Stat. Med. 2017), and in the cross group the 48 pairs are crossed in 8 owners and 8 readers, so "k = 48" is not
  48 independent pairs.
- Fix: report the core-only same-maker groups beside the 6-pair groups; report equal-weight per-pair means and a
  leave-one-pair-out range in the primary table; fit a crossed owner + reader random-effects model for the cross
  group (with model-level variance components) for any sentence about "a new pair"; write every group sentence as
  "these six pairs".

**W4. [MAJOR] The link from theta to what an operator gains is not established, and two derived quantities are
named for more than they measure.**
- Theta is a pairwise quantity over all six candidate pairs; the operator's decision is a top-1 pick under a 0.5
  relevance mix (PC2). Nothing in the paper relates theta = 0.75 to keeping 75% of the first-shown gain, yet
  `05b_q2_stakes.tex:5` translates the margin as "giving up 0.25 x (keep - shuffled)" in success points (macro
  `MarginPointsAllSwaps`, MACROS.md line 1731). That translation assumes first-shown gain is linear in theta.
- "Retained order" (theta / stakes) is described as scale-free and "1 when the reader's item effects follow the old
  order as closely as the owner's did" (`03_benchmark.tex:52`). It is a Pearson-type association, not an order
  measure. With every within-task pair in the same order for owner and reader (reader = a strictly increasing map of
  the owner's chances; noise-free, 200,000 tasks; `r7_checks/r7_order_meaning.py`), it is 0.896 for a threshold-like
  reader and 0.898 for a convex one, while theta is 2.17 and 0.83. So a "retained order" below 1 does not mean a
  "scrambled order" (`05_q1_order.tex`, "a low theta can come from a scrambled order or from a reader whose success
  depends less on which item it sees").
- "Not identifiable" is used for a z < 2 pre-test on calibration tasks (`03_benchmark.tex:57`). Identification is a
  population property (the order is not identified only when E S_reader = 0); a failed z test is "not estimated
  precisely".
- Fix: drop or justify the margin translation (report the first-shown gain at home and after the swap directly);
  rename "retained order" (for example "retained correlation") and state the monotone counter-example; say
  "estimated with too little precision" instead of "not identifiable".

**W5. [MAJOR] The operator-facing recommendations draw on unadjusted, selected and data-dependent comparisons.**
- "The best rule with checks" (`05c_q3_operator.tex:17`, macro `ArmBestCheckMinusKeepCross`) is the largest of the
  rule-by-k contrasts on the same evaluation data (MACROS.md line 1210: "pooled_32 ... (largest)"): a winner's-curse
  estimate with no selection adjustment.
- The decision table "by kind of swap and check budget" (Appendix "Secondary results") is built from secondary
  comparisons with unadjusted intervals; PC3 and PC4 rest on an additivity assumption that the pre-registration
  itself shows can fail by the size of the minimum detectable effect (Part 3, PC3, "-0.013 to +0.012 nats").
- Data-dependent design choices before the confirmatory run: the headline score type, the second stream, the number
  of passes and the exploration rate are set by the pilot (Part 9.2); P1 is computed only over swaps whose flag
  passes; the extension pairs were added in revision 2. Each is defensible and pre-stated, but together they are
  degrees of freedom that the paper should list in one place beside the results.
- Fix: choose the "best rule" on the development half (the benchmark already has one) and evaluate it on the other;
  label the decision table exploratory or give it simultaneous intervals; list the pilot-set choices in the results
  section.

**W6. [MINOR] Proposition "Error control for the 0.75 question": statement, proof and code disagree about DROP.**
The statement (`A15_keep_or_drop.tex:18`) says the rule "drops with probability at most alpha whenever theta >= 0.25";
the proof says "A drop needs no sign" (`A8_proofs.tex`, paragraph on the proposition); the pre-registration says the
flag only blocks KEEP (11.4.5, "never KEEP"). For an ungated drop test the statement is false when A_home < 0: in my
world with A_home = -0.12 and theta = 1, the ungated rule dropped in 1.000 of 1,000 streams. The code gates DROP too
(`msr/sequential.py:636`, every decision becomes NOT_TESTABLE without the flag), so for the code the statement holds
(keep 0.000, drop 0.000, not testable 1.000). Fix: state "drops with probability at most max(alpha, alpha_flag)
whenever theta >= 0.25", prove it with the gate, and say what the operator does when the decision is "not testable".

**W7. [MINOR] The reported lower bound is the second-order plug-in, its interval is for that approximation, and it
bounds an expectation.** The theorem bounds E[N]; the text compares it with medians and says no rule "can reach
power 0.8 in fewer than B tasks" (`05c_q3_operator.tex:12`). The study's B is `bound_tasks_chi2` (MACROS.md, macro
`CheckBoundKeepTasks`), not the bound. In smooth worlds the two agree within 2%, but in a world with near-deterministic
cells (most LLM tasks) the exact least-favourable bound is 1.70 times the second-order value at margin 0.75 and 3.6
times at margin 0, and the task-bootstrap interval covers the second-order value in 0.94-0.95 of replications and
the exact bound in 0.00-0.22. The reported number is therefore conservative (a valid, looser bound), but the stated
"ratio of median stopping time to the bound" overstates how far the tests are from optimal. Fix: compute
`least_favourable` on the plug-in table (the code exists) and say "in expectation".

**W8. [MINOR] The random-order condition of both swap-day tests is load-bearing and should be an operating rule.**
With the same reader at the break-even boundary but tasks checked in topic blocks (200 tasks of one sign, then 200 of
the other), the break-even test kept falsely in 0.749 of 1,000 streams. The paper states the condition; the abstract's
"a few hundred fresh checks of the new model" invites using live traffic in arrival order. Fix: say in the body that
check tasks must be drawn at random from a fixed held-out pool, and have the scorer refuse unshuffled input.

**W9. [MINOR] The home-signal gate of the 0.75 test is not free, and the flag's standard error ignores clustering.**
In my sparse-signal world (A_home = 0.089) the 100-task calibration flag failed in 0.475-0.488 of streams (4,000
each), so about half of all swap days end "not testable" whatever the reader does. `calibration_z` (`msr/metrics.py:1438-1464`) uses an i.i.d.
standard error, ignoring items shared across tasks and task ids shared across orders; for the per-bank swap-day use
this is right (the bank is fixed), but for the theta label pooled over three orders it is not. Fix: report the flag's
pass rate beside every swap-day number; use the two-way variance for the pooled label.

**W10. [MINOR] Stakes and order depend on the later-session condition, and the analysis does not check it before
printing them.** With 30% within-session copying of the earlier repeat (world `copy30_b75`, 400 replications, 6
disjoint pairs), the estimated stakes averaged 2.41 against a true 0.95 and the order 0.31 against a true 0.79, and
neither 95% set covered the truth in any replication (0/400), while theta stayed unbiased (mean 0.751, coverage 0.935
(0.012)). The paper's "x 1.80 at a copy rate of 0.3" is world-specific: the inflation grows as item effects shrink
relative to Bernoulli noise. Theta is unaffected. Fix: print stakes and order only after the within- versus
across-session check passes (Part 0.3 describes it), or flag them.

**W11. [MINOR] The forecast's single test and P1 are fragile.** The authors' own simulations show a level of 0.12
when a capability effect is curved in both arrays (`A8_proofs.tex`, "The forecast before the swap"), with 8 models
and 384 relabellings. An owner-level property that raises both theta and error consistency passes the relabelling
test as "incremental value". P1 is computed only on swaps whose flag passes, which selects pairs by home signal.
Fix: add owner and reader fixed effects to the controls, or say that F1 and P1 detect pair-level and model-level
association alike.

**W12. [MINOR] Small statistical slips.** (a) With a weak home signal (home Cw 0.514, median home z 4.8; 800 replications) the material-drop member rejected
in 0.068 (0.009) at 0.05, 2 SE above nominal (0.006 (0.003) at 0.05/12; no-material-drop 0.043; coverage 0.951):
a small anti-conservative skew worth a larger check at the signal the pilot will show. (b) The self-swap member's df is not in the
"df < 100" concern-mark check (`msr/analysis.py:3777`, only the contrast and home df). (c) The Q-statistic of the
measurement check is centred only to O(1/n) because V_swap, C_oo and C_on share tasks (A8, item (v), "however weak
the denominator" is too strong). (d) The pooled theta flag combines owners as if they were independent (`calibration_z`
docstring, `msr/metrics.py:1447`, "owners independent"), which fails for the reason of W2: owners share write tasks.

## 4. Questions for the authors

1. Why are item clusters coded within owner when all owners' candidates are the same write tasks? Will you recode
   them by write task within stream for PC1, PC2, P3 and Family T, and revalidate with a shared write-task component?
2. What exactly is the item population: write tasks of the stream pool (shared by owners), or (owner, write task)
   combinations? Your sentence "an operator's own bank is one draw of items" fits the first.
3. How is "0.25 x (keep - shuffled)" derived as the success-point meaning of theta = 0.75?
4. Will the paper report the exact least-favourable bound at the study's plug-in table, and state the theorem in
   terms of E[N]?
5. What does an operator do when the 0.75 decision is "not testable"? Is DROP also blocked by design?
6. Will the "best rule with checks" be selected on the development half?
7. Would you add the equal-weight per-pair mean and a core-only same-maker group to the primary table?
8. Can the F1/P1 relabelling test separate a pair-level association from owner- or reader-level confounding?
9. The Holm family has, in every group, at least one true null among MD and NI (theta >= 0.75 or theta <= 0.75 always
   holds). Did you consider Shaffer's refinement, which uses this logical constraint for a little more power?
10. When will the registration be frozen, and will the frozen file and the code hash be deposited before the pilot or
    before the main run?

## 5. My measured numbers beside the authors' claims

Monte-Carlo standard errors in brackets; "analysis coding" = items coded owner | stream | item as in
`msr/analysis.py`; "write coding" = items coded by write task within stream. Theta tests: one-sided level 0.05 at the
exact boundary (true theta = 0.75 for MD/NI, 1 for drop); every theta world has 2 streams x 3 orders x 400 evaluation
tasks from a 1,500-task pool, 250-item banks, 4 candidates, 2 repeats (home 4).

| Quantity | Authors' claim (where) | My measurement |
|---|---|---|
| Boundary size of PC1 contrasts, owner-specific items | 0.043-0.052 (`A9_statistics.tex`, macros MethodSizeOurs) | benign, 6 disjoint pairs, 610 reps: NI 0.044 (0.008), MD 0.041 (0.008); hubs + few dominant items, 800 reps: NI 0.049 (0.008), MD 0.041 (0.007) |
| Theta coverage, owner-specific items | 0.940-0.978 | benign 0.956 (0.008); hubs 0.956 (0.007) |
| Stakes / order coverage | 0.943-0.971 / 0.941-0.972 | benign 0.966 (0.007) / 0.964 (0.008) |
| Null z SD of the NI contrast | 0.93-1.01 (pre-reg 4.1) | benign 0.98 (0.03); **shared write tasks, cross group: 1.67 (0.07)**, write coding 1.03 (0.05) |
| Boundary size, cross group, shared write tasks | not studied | **NI 0.158 (0.023), MD 0.213 (0.026)**; write coding 0.040 (0.012), 0.055 (0.014) |
| Theta coverage, cross group, shared write tasks | not studied | **0.727 (0.028)**; write coding 0.949 (0.014) |
| 12-member Holm familywise error | worst 0.046 (`A9_statistics.tex:25`) | approx. **0.147 (0.022)** in the shared world (analysis coding); 0.052 (0.014) write coding |
| Drop member at theta = 1, owner-specific items (600 reps) | 0.043-0.052 for the contrasts | contrast alone 0.062 (0.010); full member (home and self-swap parts) 0.010 (0.004); coverage 0.943 (0.009) |
| Drop member at theta = 1, shared write tasks, cross group (150 reps) | not studied | **0.127 (0.027)** at 0.05, 0.027 (0.013) at 0.05/12; coverage 0.833 (0.030); write coding 0.047 (0.017), 0.000, 0.947 |
| Reader reaction half common to all readers (200 reps) | not studied | disjoint same-maker group: **NI 0.120 (0.023), coverage 0.875 (0.023)**; cross 0.175 (0.027), 0.755 (0.030); write coding 0.045 / 0.955, 0.025 / 0.980 |
| Mild sharing, item share 0.14 (159 reps) | not studied | cross NI 0.031 (0.014), MD 0.057 (0.018), coverage 0.956 (0.016): no inflation |
| PC2 size when keep = wipe in truth | not reported | owner-specific items 0.040 (0.008), 600 reps; shared world (200 reps): **cross 0.225 (0.030), same-maker 0.105 (0.022)**; write coding 0.065 (0.017), 0.045 (0.015) |
| Weak home signal (home Cw 0.514, median home z 4.8; 800 reps) | "weak" row of power tables | NI 0.043 (0.007), MD 0.068 (0.009), coverage 0.951 (0.008) |
| Reversed home order, reader at 0.25 of it (300 reps) | contrasts alone up to 0.725, members <= 0.043 (pre-reg Part 3) | NI contrast alone 1.000; NI, MD and drop members 0.000 |
| 30% within-session copying (400 reps) | stakes x 1.80, order x 0.56 at 0.3 (pre-reg 2.4) | stakes 2.41 vs true 0.95, order 0.31 vs true 0.79, coverage 0/400 for both; theta coverage 0.935 (0.012) |
| Break-even test (ranking and decision forms), false keep / false wipe by 2,000 tasks | 0.024-0.039 (A8) | 3 worlds, 4,000 streams each: keep 0.016-0.029, wipe 0.015-0.037 (SE <= 0.003) |
| Paired 0.75 test with fresh home results and the flag | false keep 0.015-0.030; false drop 0.014-0.039 (A8) | false keep 0.0095-0.0135; false drop 0.0098-0.022 (4,000 streams) |
| Reversed home order (A_home = -0.12), theta = 1 | "never KEEP" | gated rule: keep 0, drop 0, not testable 1.000; ungated drop test drops in 1.000 |
| Non-random check order (topic blocks), break-even | condition stated | false keep 0.749 (0.014) |
| Flag pass rate, sparse signal (A_home = 0.089, 100 calibration tasks) | not reported | 0.51-0.53 (0.008) |
| Least-favourable solver | KKT bisection | agrees with independent SLSQP within 3e-4 (8 tables) |
| Second-order vs exact bound | "to second order" | ratio 0.99-1.02 in 3 smooth worlds; **0.59 (keep) and 0.28 (margin 0) with near-deterministic cells** |
| Adaptive factor | 1.24-1.56 | 1.25-1.93 (4 worlds) |
| 95% interval of the plug-in bound (400 tasks, 1 or 6 cells, 300 reps) | task bootstrap | covers the second-order truth 0.93-0.96; covers the exact bound 0.00-0.22 in the near-deterministic world |
| "Retained order" when every pair keeps its order | "1" (`03_benchmark.tex:52`) | 0.896-0.995; theta 0.55-2.17 |

## 6. Pre-registration / code / paper mismatches

1. **DROP and the flag.** Paper `A15_keep_or_drop.tex:18` and `A8_proofs.tex:59` ("A drop needs no sign"); pre-reg
   11.4.4-11.4.5 (lines 1917-1920, 1936: the flag blocks KEEP only) vs code `msr/sequential.py:636` (the flag blocks
   every decision).
2. **Replay budget.** Pre-reg 11.4.6 line 1950 "300 per order" vs line 1946 and Part 11.5 line 2063 "200 tasks";
   code `STORE_TASKS_REAL = 200`, `CAP_TASKS = 300` kept as a reference (`msr/sequential.py:196-200`).
3. **Old-model calls for the 0.75 store.** Pre-reg 6.4 line 1128 "about 6,644"; code docstring
   `msr/sequential.py:225` "about 5,850" (it omits the 800 flag calls).
4. **Stale cross-reference.** Pre-reg 2.4 lines 474-475 say Part 11.1 "still names the same-task 4-SE rule"; Part
   11.1 (lines 1683-1685) already uses the calibration flag; open point 27(a) and 27(d) are stale too.
5. **Code differs from registered rulings** (listed by the authors, open point 24): `msr.engine.first_shown_z`,
   `msr.scores._zscore`, `msr.arms` starting counts.
6. **Registered secondary rules without analysis code** (open point 30): judge, owner's rating, relearn, re-answer's
   home value; the paper prints their cells as TODO (`A1_full_definitions.tex`, last paragraph).
7. **Familywise error.** Paper `A9_statistics.tex:25` gives "0.046"; pre-reg 5.1 line 987 also gives 0.0696 when
   SEs are 6% too small. The paper omits the stress value.
8. **Order identifiability.** Paper `03_benchmark.tex:57` states one condition; pre-reg 2.4 and the code
   (`msr/metrics.py:2063-2064`) also require both spreads positive on the evaluation tasks.
9. **Concern marks.** Paper `A9_statistics.tex` and pre-reg 4.1 apply the df < 100 mark to "every primary test"; the
   code checks only the contrast and home df, not the self-swap part of the drop member (`msr/analysis.py:3772-3777`).
10. **Item clustering** is consistent across the three (pre-reg 4.1 line 838, paper A9 line 9, code
    `analysis.py:3252`, `theory.py:673`) but wrong for pooled tests (W2). The paper's body sentence
    (`03_benchmark.tex:78`, "items (coded by identity across orders)") hides that the identity is per owner.

## 7. What a sceptical statistician would still object to

- **Multiplicity outside the primary family.** Besides the 12 primary tests there are 180 per-pair PC1 members, 3 x
  60 per-pair PC2-PC4 flags, Family T (9), P1-P4 (4), F1 (1), the agent-leg families, PC3/PC4 unadjusted, construct
  strata, visit thirds, the k-curve and seven sensitivity settings of the swap-day rule. Each family is controlled on
  its own; the narrative is not. The abstract's swap-day sentence rests on simulation medians, not tests.
- **Selection through gates and flags.** The pilot gate selects whether the study runs and which score type is the
  headline (on Haiku only); the flag selects the swaps entering P1 and the cells entering the replay's headline
  rates. None of these touches a primary test, which is good; but readers of the decision table see only the cells
  that passed.
- **Pooling over streams and orders.** Equal weight per swap-stream is fine; the three orders reshuffle one pool and
  are clustered by task id, which is right. The ratio-of-sums pooling (W3) is the larger issue.
- **The non-square grid.** The extension pairs enter only the same-maker groups, so "same-maker vs cross-maker" in the
  body compares groups that differ in which models they contain (W3).
- **Dependence between cells that share a model** is outside every interval by design (inference conditional on the
  models). That is a legitimate choice, but then no sentence should be about swaps in general.

## 8. Scores

- Soundness: 2 (fair). The swap-day tests and the bound are sound; the primary variance is wrong for pooled groups
  in a realistic world (W2); nothing has been measured yet.
- Presentation: 3 (good). Dense but careful; every claim has a pointer. The placeholders make the body hard to read.
- Significance: 2 (fair). A narrow setting (one stored example among four, two streams); importance depends on
  results that do not exist.
- Originality: 2 (fair). The tools are classical by the authors' own account; the new parts are the benchmark design,
  the paired swap-day test and its evaluation.
- Overall:
  - (a) as it stands (placeholders, no real data): **2 (reject)**.
  - (b) if the real results show the pattern of the dry run (and W2 is fixed): **4 (weak accept)**.
  - (c) if the real results show no usable signal even at home: **2 (reject)**; the measurements would be valid but
    the question would be empty for this setting.
- Confidence: 4.

## 9. What would move my score up by one

1. Real results under a frozen, deposited registration with the code hash (moves (a) to a real score).
2. Item clusters coded by write task for every pooled test, with size and coverage re-simulated in a world with a
   shared write-task component (my `r7_dgp.py` worlds `shared_*` and `common_*` can be reused).
3. Core-only same-maker groups and equal-weight per-pair means in the primary table; a crossed owner + reader
   random-effects summary for "a new pair".
4. The "best rule" chosen on the development half; the decision table marked exploratory.
5. Proposition 2 restated with the gate; the exact least-favourable bound reported, "in expectation".
6. "Retained order" renamed or its monotone counter-example stated; the 0.25 x (keep - shuffled) translation removed.

## 10. Reproduction

All in `paper/reviews/round3/r7_checks/` (run from the repository root with `.venv/bin/python`):

- `r7_dgp.py`: the theta-test world (exact true theta; write tasks shared by owners; reader-by-write-task effects).
- `r7_run_theta.py WORLD REPS OUT.jsonl [--groups ...] [--codings owner,write]`: calls `msr.metrics.theta_tests` and
  `robust_variance` on data assembled as `msr.analysis.TwoWay.theta` assembles them; raw rows in `out/*.jsonl`.
- `r7_summarize.py`: sizes, null-z SDs, coverage (`out/theta_summary.json`); `r7_fwer.py`: the approximate Holm family
  error (`out/fwer_approx.json`).
- `r7_seq.py`: the swap-day tests (`out/seq_checks.json`); `r7_bound.py`: the bound checks (`out/bound_checks.json`);
  `r7_order_meaning.py`: the monotone-transfer example (`out/order_meaning.json`).
- `batch*.sh`: the exact runs (systemd units `r7-*`, 2 cores each). `batch1.sh` and `batch2.sh` were stopped early
  (the machine was busy) and continued with trimmed counts in `batch1b.sh` and `batch2b.sh`; every number above is
  computed from the replications actually stored in `out/*.jsonl`, with the replication count stated beside it.
- The Holm family error is an approximation: the downgrade group is stood in for by the upgrade group of the next
  replication and the three PC2 members are counted as clear rejections (`r7_fwer.py` docstring).
