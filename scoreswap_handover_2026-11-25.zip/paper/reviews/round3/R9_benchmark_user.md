# R9: review as a benchmark user (ICML 2027, datasets, evaluations and benchmarks)

Reviewer R9. I used the tool as an outsider: I followed only `paper/reviews/round3/README.md` and
`docs/BENCHMARK_GUIDE.md`, wrote my own entries, and then tried to break the tool. Everything I ran, every entry and
every log is in `paper/reviews/round3/r9_user_test/`. I used only the public practice pack `release/sim`. I did not
read `release/sim_private` and did not run any `--private` command. My entries only tested whether they could reach
the private pack, and the kernel stopped them. No model was called and no network was used.

## Summary

ScoreSwap freezes the graded results of every "new model reads old model's memory" cell, so that rules for keeping,
wiping or re-checking learned memory scores can be scored offline at a given budget of fresh checks, with a held-out
test half kept by the maintainers. As a tool it is unusually pleasant to start with: in about ten minutes I described
the pack, checked and scored a shipped example and built a board, and the error messages told me exactly what to fix.
The file sandbox is real. With the Python guard disabled, the kernel still refused every read outside the allowed
folders, including the private test file and `.env`. Two central promises do not hold, though. First, the per-budget
swap-day boards cannot enforce the budget: the calibration results that checks are drawn from are public, so a
20-line entry that carries them beats every paper rule of the k = 64 board on cross-maker swaps (all seven paired
intervals exclude zero) while asking for 0 checks, and passes `check`. The
guide says ranking on test handles this, but it does not. Second, "nothing your entry does in one call reaches the
next" is false: a call can write into the launcher's resource limits, or into the access time of a readable file, and
later calls read it back. I used this to pool checks across the 200 draws of a cell. That entry reports "16 checks
used", beats keep by +0.054 on cross-maker swaps where its honest twin gets +0.010, and passes `check`, because it
detects check mode from `swap.draws`. The same hole lets a sealed call change resource limits of any process the
maintainer owns. The paper has no real-model results yet, so its significance is still open; as it stands, I would
not trust third-party board entries.

### First-contact log (Linux 6.17, Landlock ABI 7, 8 threads, shared machine at load average 5 to 19)

| # | step, following the guide only | command | wall time | what went wrong or was unclear |
|---|---|---|---|---|
| 0 | read README + guide | - | about 15 min | The guide's "Get the frozen tables" says "Download the pack" (BENCHMARK_GUIDE.md:61) but gives no place to download it from, and does not say that the practice pack already ships as `release/sim`. The alternative it offers, `export --study sim`, needs `runs/sim` and would write the private half onto the user's own disk. |
| 1 | describe the pack | `python -m scoreswap describe --pack release/sim` | 0.45 s | Very useful. But the guide (line 24) says `describe` lists the budgets a pack can hold, and it does not: it prints one example call at k = 16. The pack holds 0 to 64; 128 and 256 are refused later. |
| 2 | check a shipped example | `python -m scoreswap check examples/rank_focus_shrink.py --pack release/sim` | 9.5 s | None; clear PASS lines. |
| 3 | score it | `python -m scoreswap score examples/rank_focus_shrink.py --pack release/sim --budget 16 --out .../scores` | 25 s | The guide (line 224) says SUMMARY.md's "first line says which half was scored"; it is the third line (the first is the title). Minor. |
| 4 | build a board | `python -m scoreswap leaderboard board1_entries/ --pack release/sim --out .../board1` (3 examples, default budgets 0, 8, 16, 32, 64) | 530 s | No progress output for nine minutes (`score` shows a % bar; `leaderboard` prints one line per entry and then nothing). The guide's timing table covers only the full-size pack, nothing for the practice pack. The board's rows for the paper's rules are wrong (W6). |
| 5 | check my 3 entries | `check entries/{eb_slope_shrink,lift_js_score,logit_p_cand}.py` | 29 s, 6 s, 31 s | All PASS. Mapping a check cell's task to a row of `candidates` needs `candidates.task_index`, which exists but is not in the guide's field table. |
| 6 | score them | `score ... --budget 0/16` | 6 s (score type) to 120 s (k = 16) with 2 workers | None. |

Error messages (syntax error, missing `rule`, misspelled KIND, wrong output shape, file over 256 KB, unregistered
budget 10, budget 128 too big for the pack, wrong pack folder) all named the problem and the fix
(`logs/` and `errs/`). Without the heavy third-party packages (matplotlib, fastembed, anthropic, openai, pyarrow,
datasets and others blocked at import), `score` and `leaderboard` still ran, so the install line is plausible for the
scorer's main process (`errs/blockimports.py`).

### My three honest entries (step 2), written from the guide alone

All three passed `check` on the first try. The numbers below are on dev, from `scores/`, `scores_A/` and `board2/`.

- **(a) `entries/eb_slope_shrink.py`**: empirical-Bayes shrinkage of the old scores by a slope estimated from the
  k random checks, with prior 0.5 and weight 8.
  - At k = 16 it is not distinguishable from keep in any kind of swap: upgrades -0.012 [-0.033, 0.010], cross-maker
    +0.007 [-0.023, 0.038], home -0.023 [-0.047, 0.000].
  - On the board it sits between the guide's template and the paper's rules. Plausible.
- **(b) `entries/lift_js_score.py`**: a score type. Paired lift over the no-tip result, shrunk toward the bank mean.
  - Cw at home 0.675, against 0.676 to 0.722 for the paper's types; theta 0.72, 0.88 and 0.27 by kind.
  - Board rank 6, 2 and 3 of 6. Plausible, and the per-pair intervals are very wide on this pack.
- **(c) `entries/logit_p_cand.py`**: returns `p_cand` from a ridge logistic fit on the checks, to exercise the log
  score.
  - First-shown success equals keep's, by construction.
  - The level-corrected log score improves with checks (cross-maker -0.838 at k = 0, -0.745 at k = 16), in the range
    of the paper's rules (-0.700 to -0.782 at k = 16).

Uncertainty: two runs of (a) gave byte-identical summaries. The tool does not let a user score a split half of dev,
so I could not test the intervals' coverage myself.

## Strengths

1. **Easy first contact.** About 10 minutes from zero to a board on the practice pack; no key, no network, no GPU.
   `describe` shows exactly what a call receives, with sample values, which is better than most benchmark docs.
2. **The file sandbox works where it matters.** With the Python audit hook disabled from inside the entry,
   Landlock still returned errno 13 for `release/sim_private/test_results.csv`, `.env`, `release/sim/dev_results.csv`,
   `/etc/hostname` and `/proc/self/status`, and refused a write to `/dev/shm` (`attacks/probe_sandbox.py`,
   `logs/10_probe_sandbox.txt`). Starting a thread failed ("can't start new thread"). I did not test `fork`, pipes or
   sockets myself; the seccomp list (sandbox.py:135) and the authors' tests cover them. Hanging and killing the
   launcher both fail closed (`logs/50_*.txt`).
3. **Honest about the weak spots it knows.** The guide says plainly that dev numbers are not rankings, that a rule can
   memorise dev outcomes, that model names are inputs, and that home rows of the test half are not fully held out (with
   a count in the manifest). Every dev output carries a bold banner saying it is not a ranking.
4. **Reproducible for honest entries.** Two runs of the same rule gave byte-identical `SUMMARY.md`, `summary.csv`
   and `compare.csv` (`scores_A` and `scores_B`; only the row order of `cells.csv` differs). Comparisons with the
   paper's rules use the same tasks and draws, with paired intervals.
5. **Good error messages and contract checks** (see the log above), and a size limit on entries.
6. **Well-designed reporting**: per ordered pair, per kind of swap, two interval types, checks used and the reader
   calls they would cost. The log-score path works and responds to checks as it should (`logit_p_cand`: cross-maker
   level-corrected log score -0.838 at k = 0, -0.745 at k = 16).
7. **Data usable without the code.** The CSVs and `SCHEMA.md` describe every column; the canary string and per-file
   sha256 are in place.

## Weaknesses

**W1 (FATAL as it stands, fixable). The budget k of the swap-day boards cannot be enforced, because the results that
checks are drawn from are public.** `release/sim/calibration_results.csv` holds both repeats of every calibration
cell of every reader. `attacks/make_calib_embed.py` writes `attacks/calib_embed.py` (169 KB, under the 256 KB limit;
about 9 KB would suffice packed as bits even for the full 8-model design). The entry maps each `checks.cells` entry
to its public task id by position and uses all 192 stored results of the cell, without asking for a single check.
- `check` passes on all four lines; it reports "most used per call: k=0: 0, k=16: 0" (`logs/30_check_calib_embed.txt`).
- At k = 0, cross-maker swaps (dev): +0.050 [0.013, 0.088] over keep, "checks used 0.0" (`scores/calib_embed/k0/SUMMARY.md`).
- At k = 64, on cross-maker swaps, it beats every paper rule with intervals that exclude zero
  (`scores/calib_embed/k64`): keep +0.050, wipe +0.073, fixed_0.5 +0.051, powerprior_64 +0.071,
  recal_64 +0.063 [0.031, 0.095], retest_64 +0.035, audit_64 +0.059. It also beats the guide's own template rule at a
  real k = 64 (+0.034 over keep, `scores/template_rule/k64`). On the other kinds of swap it is not distinguishable
  from them.
- On a board built with `leaderboard` (`board2/swap_day_rules_k0.md` and `board2/swap_day_rules_k16.md`), it ranks
  first among cross-maker swaps at both k = 0 and k = 16, with "checks used 0.0". At k = 0 it is the only rule
  marked "above keep".
- The held-out alarm cannot catch it: the gain is information about the reader, not about dev tasks, so it should be
  the same on dev and test. This is my reading of `check.py:held_out_gap`; I did not run `--private`.
- The guide (BENCHMARK_GUIDE.md:315-317) says carrying public data "is why the board ranks on test". For calibration
  data that is false.
- Fix: score the board's swap-day rules with a private calibration pool. Have the maintainers hold the readers'
  results on calibration tasks that are not public, or move the calibration results of the board's cells into the
  private folder and give users a separate, public practice calibration pool. If not fixed, say plainly that the
  budget is honour-based for outside entries.

**W2 (MAJOR). Calls can pass notes to later calls; the guarantee in the paper and the guide is false.** The guide
says "nothing your entry does in one call reaches the next" (line 309), "Nothing you store survives to the next call"
(line 108), and the paper says "so nothing it saw in one call reaches another" (A14_rule_interface.tex:14). Two
working channels:
1. **Resource limits of the launcher.** `resource.prlimit(os.getppid(), ...)` is allowed: `prlimit64` is not in
   `_DENY_X86_64` (sandbox.py:135), and Landlock does not cover it. The next worker is forked from the launcher and
   inherits the limits. `attacks/carry_counter.py`: the fifth call reported "this call is number 5 in this launcher"
   (`logs/32_check_carry_counter.txt`). Five limits the launcher does not depend on (core size, locks, RSS, a
   very large file size, message queues) hold about 200 bits per launcher. `sched_getaffinity` and `getpriority` on
   the launcher also work (`logs/10_probe_sandbox.txt`); I did not write those two.
2. **File access times.** Reading a readable file whose atime is over a day old (`relatime`) updates the atime, and a
   later call sees it with `os.stat` (`attacks/atime_channel.py`, `logs/52_atime.txt`: "the file was read 0.3 s
   ago"). There are thousands of such one-shot bits under `anaconda3/` and `.venv/`, and they survive across runs and
   across entries.

The exploit is `attacks/pool_across_draws.py`. Each call asks its k random checks honestly, merges them with the
answers that earlier draws of the same cell stored in the launcher's limits, writes the union back, and scores with
everything known. Under `check` (`swap.draws` = 3) it behaves exactly like the guide's template, so `check` passes
all lines (`logs/33_check_pool.txt`). Under `score` (200 draws):

| rule (dev, cross-maker swaps) | checks the scorer reports | minus keep | minus recal_k at the same k |
|---|---|---|---|
| template rule from the guide, k = 8 | 8 | +0.005 [-0.003, 0.013] | +0.016 [-0.008, 0.041] |
| pool_across_draws, k = 8 | 8 | +0.044 [0.009, 0.078] | +0.055 [0.029, 0.081] |
| template rule, k = 16 | 16 | +0.010 [-0.002, 0.022] | +0.022 [-0.005, 0.050] |
| pool_across_draws, k = 16 | 16 | +0.054 [0.022, 0.086] | +0.066 [0.038, 0.095] |
| template rule, k = 64 | 64 | +0.034 [0.008, 0.060] | +0.046 [0.019, 0.074] |
| calib_embed (W1), any k | 0 | +0.050 [0.013, 0.088] | +0.063 [0.031, 0.095] (vs recal_64) |

At a reported k = 8, the pooled rule is better than the honest rule at a real k = 64.

Three score runs of the pooled rule at k = 16 give cross-maker leads of +0.054, +0.051 and +0.049, each with an
interval clear of zero (`scores_tmp`, `scores_A`, `scores_B`). The downgrade lead moves from +0.027 to +0.048
between runs; the tool's intervals assume a deterministic entry and do not show this run-to-run spread.

A fourth run, inside `leaderboard`, gives +0.044 [0.011, 0.076]. That ranks the pooled rule second among cross-maker
swaps on the k = 16 board, marked "above keep", with "checks used 16.0". Only W1's entry is above it; every honest
entry and every paper rule is below it (`board2/swap_day_rules_k16.md`).

The authors' own test claims "Every channel an entry could use to leave a note for its next call is closed"
(tests/test_scoreswap_cheats.py:284), but it covers only module state, pipes, threads, files, the environment, mmap
and fork.

Fix:
- seccomp-refuse `prlimit64` and `setrlimit`, or allow them only with pid 0 and lowering only; also refuse
  `sched_setaffinity`, `sched_setscheduler`, `setpriority`, `ioprio_set` and `setpgid` on any pid but 0.
- Run the launcher in a mount namespace that contains only the allowed folders, bind-mounted read-only (or
  `noatime`). A read-only mount does not update atime, and a namespace holding nothing else also hides `stat` of
  other paths (W9).
- Fork each worker from a pristine copy, or reset the launcher's limits after each call.
- Make `check` indistinguishable from `score` (W4).

**W3 (MAJOR). A submitted entry can disturb the maintainer's machine.**
- A sealed call changed the core-file limit of a process in a different systemd unit (my dummy `sleep`: 0 -> 424242,
  confirmed from outside with `prlimit`), and counted 940 processes of the same user by probing `prlimit`
  read-only (`attacks/reach_other_process.py`). With `RLIMIT_CPU` or `RLIMIT_AS` instead, an entry could kill or
  starve any other job of the maintainer's user (I did not try this).
- On kernels before 6.12 (Landlock ABI below 6, sandbox.py:83), signals are not scoped either. Only the Python hook
  then stands between an entry and `kill` of any process of that user, and the hook can be switched off (W8).
- There is no per-worker memory limit (`apply_worker` sets only `RLIMIT_NPROC`, sandbox.py:249-255). A 3 GB
  allocation inside a 1 GB unit killed the whole scorer with no message at all; the log file is empty
  (`attacks/mem_bomb.py`).
- There is no total time budget per entry. Calls of 299 s stay under the 300 s timeout (harness.py:39), which is
  6,400 x 299 s on this small pack.
- The guide gives maintainers no advice to run submissions under a throwaway user, a container or a memory cgroup.
- Fix: run untrusted entries under a dedicated uid or user namespace with a cgroup `memory.max`, refuse cross-pid
  syscalls (as in W2), set `RLIMIT_AS` in each worker, add a wall-time budget per entry, and write this down as the
  maintainers' procedure.

**W4 (MAJOR). `check` can be told apart from `score`, so a PASS certifies nothing about behaviour during scoring.**
- `check` runs 3 draws and budgets {0, 16} (check.py:130), and the rule sees `swap.draws` = 3 against
  `swap.settings["draws_per_budget"]` = 200.
- The maintainers' held-out alarm is computed from that same 3-draw run, so it sees the honest branch.
  `pool_across_draws.py` uses exactly this switch.
- Fix: run `check` with the full draws, or have `score` itself re-run a random sample of calls in another order and
  compare them byte for byte; do not expose `draws` (or expose the pack's value in both).

**W5 (MAJOR). The held-out half is not yet run in a way the community can trust.**
- The maintainers are the authors.
- "Send your entry file" (guide line 41) names no channel, no rate limit ("the maintainers limit submissions": how
  many?), no public log of submissions, and no turnaround.
- Contact and an issue tracker come only at camera-ready (A6 item 11).
- The sha256 commitment is never opened: nothing says when, or whether, a retired test half is published so that
  outsiders can check old board numbers.
- The alarm allows a dev lead of max(3 SE, 3 points) above the test lead. On the practice pack that is several
  points, because the test half holds only 28 tasks per order (`manifest.json`, "splits").
- Fix: publish a submission protocol (channel, limit per team per month, a public append-only log of entry sha256,
  date and test score, including failed and withdrawn entries); publish each retired test half; name a co-maintainer
  outside the author team.

**W6 (MAJOR, presentation bug). The board labels every paper rule "no home signal" and "not identifiable" in cells
where the home signal is present.**
- On `board1/swap_day_rules_k16.md`, keep, wipe and all paper rules read "no home signal / not identifiable" (CSV:
  `status = undefined: home signal too weak`) in all four kinds of swap. The outside entry `rank_focus_shrink` gets
  theta 0.623 [0.378, 0.983] in the same cells.
- Scored as an outside entry (`entries/keep_as_entry.py`), keep shows theta 0.750 [0.456, 1.195] for upgrades and
  exactly 1.000 at home, as the guide says it should (`scores/keep_as_entry/k0/SUMMARY.md`).
- The cause appears to be that the reference rows lack the calibration arrays, and the flag then defaults to "no".
- A reader of the board would conclude the paper's baselines have nothing to keep. Fix: compute the flags for the
  reference rows from the same arrays, or print "not computed" instead of a false label.

**W7 (MAJOR). The score-type board ranks by a ratio, which rewards weak home skill.**
- `visits`, registered as "the score with no usefulness signal of its own", ranks first in all three kinds of swap.
  Downgrades: theta 1.68, printed with no interval at all (an unbounded Fieller set shown as blank).
- Its Cw at home (0.562 to 0.622) is the lowest of all types (`board1/score_types.md`, `board2/score_types.md`).
- A type that just clears the 2-SE home gate can post a large, noisy theta.
- Unlike the swap-day boards, this board ranks with no paired difference and no "not distinguishable" grouping, even
  though every theta interval overlaps every other in each kind of swap.
- Fix: rank by the absolute after-swap quantity (Cw or V after the swap) or by a lower confidence bound on theta,
  group the ranks by paired intervals as the rule boards do, and print unbounded sets as "unbounded".

**W8 (MINOR). The Python audit hook can be switched off, and an entry can wipe its own violation record.**
- Rewriting the hook's closure (`cell_contents` of `block`, `ok_path`) disables it. Clearing
  `sys._getframe().f_back.f_locals["denied"]` erases what it recorded (`logs/10_probe_sandbox.txt`: "denied list had
  6 entries ... clearing it").
- On Linux the kernel still blocks the files, but `check.py:15` ("Any refused attempt the entry makes fails the check,
  named") is then false: kernel refusals are silent.
- Off Linux the hook is the only guard. An entry that switches off the hook, clears `denied` and detects check mode
  (W4) could then read a maintainer's private file during `score` and stay invisible to the canary. This is inferred
  from the code; I did not test off Linux.
- seccomp is built for x86_64 only (sandbox.py:219), so on arm64 Linux, threads, pipes and IPC are not limited.
- The guide says "Sealing needs Linux" but should say: maintainers must score on Linux x86_64 with kernel 6.12 or
  newer.

**W9 (MINOR). `stat` works on any path.** From inside a call: `.env` exists with 125 bytes; the private test file
exists with 824,389 bytes and an mtime (`logs/10_probe_sandbox.txt`). No contents leak, but "cannot read any file"
(line 305) should say "contents".

**W10 (MINOR). Some test-task outcomes are public.** 16 of 220 (model, test task) pairs (7%) have that model's own
graded results on that test task, with no tip and with its own tips, in another order's public score-phase log
(`banks/*/showings.csv`). 12 items were written from test task ids. This does not help first-shown success (the
level is common to all candidates), but a rule returning `p` can use a reader's known no-tip result on a test task in
the log and Brier scores. The manifest's "exposure" counts only home cells with the same task and item. Count this
exposure too, and say whether it grows in the full design (orders reshuffle one pool).

**W11 (MINOR). The "random" checks are predictable.** The seed is built from public values
(`msr.evaluate.draw_hash`), so a rule can predict which cells `request(random=k)` returns before asking: 16 of 16
(`attacks/predict_random.py`). "Cannot steer" is true; "random" should be read as "fixed and public".

**W12 (MINOR). The guide and output have small errors.**
- No download location for the pack (line 61).
- `describe` does not list budgets (line 24).
- The "first line" of SUMMARY.md (line 224).
- `candidates.task_index` is undocumented.
- The README omits `describe`.
- `leaderboard` shows no progress for minutes.
- `cells.csv` row order changes between identical runs.
- `check` says "random draws like recal_k" for a rule that draws nothing.
- No timings for the practice pack.
- No pinned versions of numpy and scipy for the maintainers' environment, so "other installed packages" means
  different things on different machines.

**W13 (MINOR). Licences and versioning are not settled.**
- The pack's `licences/ddxplus.txt` says the CC BY 4.0 licence is "NOT yet verified at the dataset record". The
  paper's A3 says it was "read at its source on 24 Nov 2026".
- The code has no licence yet ("chosen for the public release"); the model-output terms are TODO.
- The board's `entries.json` records the pack fingerprint (good), but there is no board version and no rule for
  re-scoring old entries when the test half is replaced yearly, so board numbers from different years are not
  comparable.

**W14 (MINOR, practice data only). The paper's check rules look weak against the guide's own two-line template.**
- At k = 8 the template beats `recal_8` at home (+0.030 [0.014, 0.046]) and on upgrades (+0.025 [0.007, 0.042]).
- At k = 64 it beats `recal_64` on cross-maker swaps (+0.046 [0.019, 0.074]) (`scores/template_rule/`).
- If this holds on real data, the registered baselines understate what a budget of checks can buy.

**W15 (MINOR). A dev-memorising entry passes every public check with "All checks passed".** It gains +0.17 to +0.29
over keep on dev (`attacks/dev_memo.py`, `scores/dev_memo/k0`). The guide admits memorisation, but `check` could say
"public checks cannot detect memorised dev outcomes" next to "All checks passed".

Count: 1 FATAL, 6 MAJOR, 8 MINOR.

## Questions for the authors

1. How will the board stop an entry from carrying the public calibration results (W1)? Will the calibration pool of
   the ranked board be private?
2. Who will run the held-out half, by what channel, with what limit per team, and will every submission (including
   failed ones) be logged publicly?
3. Will retired test halves be published so that the sha256 commitments can be checked? When?
4. Which kernel, architecture and isolation (uid, container, cgroup) will the maintainers use to run untrusted
   entries?
5. In the full design, what share of (reader, test task) pairs have the reader's own no-tip result in a public score
   phase (W10)?
6. Why is the score-type board ranked by theta rather than by an absolute after-swap measure, given that the no-signal
   control `visits` tops it on the practice data?
7. Will the pack and the boards carry version numbers and a changelog, and will old entries be re-scored on each new
   test half?

## Attack table

| # | attack | result | evidence | does the documentation tell the truth? |
|---|---|---|---|---|
| A1 | carry the public calibration results in the code; use all of them at any k | **succeeded** | `attacks/calib_embed.py`; check PASS, 0 checks used; +0.050 over keep (k = 0), +0.063 over recal_64 (cross-maker, dev); rank 1 for cross-maker swaps on the k = 0 and k = 16 boards (`board2/`) | No: the guide says ranking on test handles carried public data (lines 315-317) |
| A2 | carry state between calls through the launcher's resource limits | **succeeded** | `attacks/carry_counter.py`: call 5 knew it was call 5 | No: guide lines 108 and 309, paper A14 line 14 |
| A3 | pool the checks of all 200 draws through A2, honest under check | **succeeded** | `attacks/pool_across_draws.py`: check PASS; +0.049 to +0.054 over keep at a reported k = 16 in three score runs (honest twin +0.010); +0.044 at a reported k = 8; rank 2 for cross-maker swaps on the k = 16 board | No |
| A4 | carry state through file access times | **succeeded** (one-shot bits, also across runs) | `attacks/atime_channel.py`, `logs/52_atime.txt` | No |
| A5 | make check pass and score behave differently | **succeeded** | `swap.draws` is 3 under check and 200 under score; used in A3 | Not mentioned |
| A6 | reach processes outside the sandbox | **succeeded** (limits of any same-user process; enumerate 940 processes) | `attacks/reach_other_process.py` | No: "reach another process" is said to be refused (sandbox.py docstring) |
| A7 | read the private pack, `.env`, the dev file, `/proc`, `/etc` from a call (Python hook disabled) | **blocked** by the kernel (errno 13) | `logs/10_probe_sandbox.txt` | Yes |
| A8 | learn file existence, size, mtime outside the allowed folders | **partly** (metadata only) | `stat` of `.env`, private test file | Mostly; "cannot read any file" should say contents |
| A9 | switch off the audit hook and erase the violation record | **succeeded** (consequence only off Linux, or for reporting) | `attacks/probe_sandbox.py` | Partly: "Any refused attempt ... fails the check" is false |
| A10 | memorise dev outcomes; behave like keep on test tasks | **partly** (+0.17 to +0.29 on dev, all public checks PASS; the maintainers' alarm should catch large gaps, not run by me) | `attacks/dev_memo.py` | Yes, documented |
| A11 | detect model and cell, special-case it | **succeeded** (trivial: `swap.reader`, positions match public files) | A1 and A10 rely on it | Yes, documented |
| A12 | predict the "random" checks | **partly** (16 of 16 predicted; no outcome learnt) | `attacks/predict_random.py` | Yes ("cannot steer") |
| A13 | ask for more checks than the budget, or a cell a third time | **blocked** | harness refuses; the authors' tests cover it | Yes |
| A14 | hang a call | **blocked** per call (timeout); no per-entry wall budget | `attacks/hang.py` with `--timeout 5` | Partly |
| A15 | kill the launcher | **blocked** (fails closed: "the entry's process stopped") | `attacks/kill_launcher.py` | Yes |
| A16 | forge messages on the harness pipe | **partly** (a forged result and "reaped" were accepted for one call; the run then stopped one call later) | `attacks/forge_messages.py` | Not mentioned |
| A17 | exhaust memory | **partly** (no per-worker limit; in a 1 GB unit the whole scorer died silently) | `attacks/mem_bomb.py` | Not mentioned |
| A18 | entry inside the pack, oversize entry, bad outputs | **blocked** with clear messages | `errs/` | Yes |

## Paper claims about the tool

**True as written** (checked):
- Entries are scored offline from frozen tables with no model call.
- The public pack reproduces boards on the development half.
- Every call runs in a fresh process forked from a launcher that never runs entry code.
- On Linux the kernel limits file reads to the Python installation and the scorer's code (A7). Note that "the
  Python installation" here means all of `~/anaconda3`, the base prefix of the venv.
- No writes or threads (tested). Pipes, sockets, shared memory and new processes are on the seccomp list (code read,
  not attacked by me).
- The scorer counts the checks.
- The two-answers limit is enforced (code read; the authors' tests cover it).
- `check` repeats the run in another order and with permuted outcomes.
- The commands exist and work as described.
- Results are per ordered pair, per kind of swap, with two intervals.
- The test half's sha256 is in the public manifest.
- No reader's result on a test task with another model's item is public (verified on `release/sim`).

**Over-claims:**
- "so nothing it saw in one call reaches another" (A14_rule_interface.tex:14) and the guide's "Guaranteed" list
  (lines 304-312): false (W2, A2 to A4).
- "the check ... requires byte-identical output" as a safeguard: true, but the check is detectable (W4), so it
  safeguards nothing against a deliberate cheat.
- "That is why the board ranks on test" for carried public data (guide lines 315-317): does not cover calibration
  data (W1).
- "elsewhere the sealing is a Python audit hook backed by the permutation canary" (A14): the hook can be switched off
  from inside (W8).
- "a new entry is listed only after the maintainers have re-run it on both packs": the re-run itself can be gamed
  (W1 to W4).
- Licence of DDXPlus "read at its source": the pack's own licence file says it is not verified (W13).

**Missing:**
- The submission procedure, its limits and a public log (W5).
- Who runs the private half, on what machine and isolation (W3, W8).
- When committed test halves are opened.
- The code licence.
- Board and pack versioning and the re-scoring policy.
- The model-output terms.
- The cost and hardware to take part: CPU only, minutes on the practice pack, about 20 minutes per entry per budget
  at full size by the guide's figure. I would add a statement that a laptop suffices.
- What happens off Linux. On Windows every call starts a new Python interpreter (`ChildRunner._fresh_for_call`),
  which at full size means 76,800 interpreter starts per entry and budget, with no time estimate.
- A plain reference implementation of the scoring arithmetic for users who do not want to run the package. The
  appendix defines it in words; the data are accessible as CSV.

## Adoption: would I use it in my own paper?

Not yet. The question is real (memory scores outliving a model), the format is light, and I could score a new rule
in minutes. Two things would stop me:

1. **I could not trust anyone else's board entry, or prove that mine is clean.** The budget is not binding (W1), calls
   can share state (W2), and `check` can be fooled (W4). A reviewer of my paper could rightly ask whether my k = 16
   result is a k = 16 result.
2. **The held-out half is a promise, not yet a procedure** (W5). It is run by the authors, with no published
   protocol, rate limit, public log or opening of past commitments. The community trusts held-out halves run by a
   neutral party with a public log, or halves that are released on a schedule. Neither is in place.

A third, scientific concern is effect size. On the practice data, honest rules differ from keep by 0 to 3 points,
with paired intervals of about ±1 to ±3 points. So a new rule would need either the full-size pack or many cells to
show anything. Whether real data are more decisive is still open.

## Scores

- Soundness: 2. The statistics are careful, but the tool's two central guarantees (budget, call isolation) fail,
  and the board mislabels the baselines.
- Presentation: 3. The guide is clear and honest and the error messages are excellent; there are several small
  errors in the guide and the boards.
- Significance: 2 today; 3 with real data. The construct is narrow (exemplar memory, one item of four, single-call
  tasks), and the differences between rules are a few points with intervals of about ±3 points.
- Originality: 3. An offline, budgeted swap-day benchmark with a held-out half is new.
- Confidence: 4. I ran everything I report; I did not run the private half.

Overall:
- (a) As it stands (placeholders, no real data, W1 to W4 open): **2 (reject)**.
- (b) If the real results show the pattern of the dry run: **4 (weak accept)**, provided W1 to W4 are fixed and
  re-tested. With the tool as it is now, 3.
- (c) If the real results show no usable signal even at home: **2 (reject)**. The theta boards would be all "no home
  signal", and the swap-day boards alone are too thin a contribution.

## What would move my score up by one

- A private calibration pool for the ranked board, or a stated honour-based budget plus a k-free board (W1).
- Close the cross-call channels: seccomp on cross-pid and limit-changing syscalls, read-only or noatime mounts, a
  pristine fork per call; plus an attack test for each channel in `tests/test_scoreswap_cheats.py` (W2, W3).
- Make `check` and `score` indistinguishable to the entry (W4).
- A written submission and maintenance protocol: channel, limits, a public log, an outside co-maintainer, and when
  test halves are opened (W5).
- Fix the board's reference-rule flags and rank score types by an absolute measure (W6, W7).
