# Review round 3: what a reviewer needs

All paths are relative to the repository root. Nothing here needs a model call or a key.

## 1. The paper

| File | What it is |
|---|---|
| `paper/main.pdf` | The submission layout. Every result is a red placeholder ("Results pending"); figures and tables are boxes naming their source file. The only numbers that are not design facts are method-validation numbers from simulation (`\Method...` macros, Appendix "Statistics in Full"). |
| `paper/dryrun.pdf` | The same paper filled with the small simulated practice study (`config/sim.yaml`: 4 simulated models, one stream), watermarked "DRY RUN - SIMULATED DATA - NOT RESULTS" on every page. It shows that the pipeline produces every number, table and figure; its values say nothing about real models. |
| `paper/main.tex`, `paper/sections/*.tex` | Sources. `bash paper/build.sh` rebuilds both PDFs (Tectonic). |
| `paper/assets/MACROS.md` | Every number macro with its value in the practice study, its meaning and its source file and column. |
| `paper/reference_ledger.md` | Every cited work, the page opened, a quoted sentence and a status (VERIFIED, ABSTRACT-ONLY, NOT-CITED). |
| `paper/STYLE_CHECKS.md` | The paper against the ICML 2027 rules, rule by rule. |

## 2. The pre-registration

`prediction/PREREGISTRATION.md` (status: draft, not frozen). Parts 0-10 fix the design, the measures, the primary
tests and their family, the variance, the secondary and exploratory analyses, the agent leg (Part 8.4), the pilot rules
and the costs; Part 11 holds the transfer decomposition, the forecast and the keep-or-drop decision. The list of open
points is at the end of the file.

## 3. The benchmark guide and the scorer

- `docs/BENCHMARK_GUIDE.md`: how to write and score a swap-day rule or a score type, the public and private packs, the
  boards, and what the sealing does and does not guarantee.
- `scoreswap/` (`python -m scoreswap check | score | leaderboard | export`): the scorer. `scoreswap/export.py` writes
  the packs and holds the development/test split rule.

## 4. Code entry points

| Command or module | What it does |
|---|---|
| `python run.py --study config/sim.yaml` | Runs the whole study end to end on simulated models (free, minutes); stages build, probe, probe_extra, judge, relearn, evaluate, online. With a real study file it prints the cost estimate and calls nothing unless `--yes` is given. |
| `python -m msr.analysis --study <name>` | All registered estimands, tests, intervals and tables (`runs/<name>/analysis/`). |
| `msr/metrics.py` | V, theta, order and stakes, the two-way jackknife, the tests (`theta_tests`), the label function (`pc1_label`), the home-signal flag. |
| `msr/sequential.py`, `msr/theory.py`, `msr/forecast.py` | The keep-or-drop decision and its bound, the transfer decomposition, the pre-swap forecast. |
| `msr/construct.py`, `scripts/make_construct_assets.py` | The construct checks and free baselines. |
| `scripts/make_paper_assets.py` | Writes `paper/assets/` (numbers, tables, figures) from an analysis folder. |
| `legs/memrl/README.md` | The agent leg on MemRL's released code: design, patches, power, cost, how to run. |
| `python -m pytest -q` | The test suite (no keys, no cost). |

## 5. Claims that are TODO until real data

No confirmatory result exists: no paid run has been made. In `main.pdf` the following are placeholders and will be
filled only from the confirmatory analysis of the frozen pre-registration.

1. Abstract: the headline (share of home value kept after same-maker upgrades and across makers; whether keeping beats
   wiping) and the sizes of the two swap-day checks (checks for "keep beats wipe", tasks for "at most a quarter lost").
2. Introduction, "Findings": theta per kind of swap with intervals; keep minus wipe at home and after the swap; the
   median checks of the break-even test; the bound and its interval for the 0.75 question.
3. Section 5 (Q1): theta, its interval and its registered reading in each kind of swap; the self-swap references; the
   prediction intervals for a new pair; retained order and stakes; P4 and the maker coefficient with and without the
   capability controls; the stored-answer-correct reference, the grade's share of the home signal and the residualised
   theta; the answer-match and near-duplicate shares; the shuffled control; Figure 1 (theta for every pair), the per-pair forest plot and the primary-test table.
4. Section 6 (Q2): the stakes table (keep minus wipe and keep minus shuffled, at home and after the swap) and the
   margin in success points.
5. Section 7 (Q3): the PC2 estimates and readings; the break-even test's median checks and its bound; the paired
   test's median tasks, the bound and its interval; the fixed audit's false-keep rate; the registered secondary
   baselines against keep (re-answer, the new model as judge, relearn) and the best check rule.
6. Section 8 (agent leg): every reading of the 12 directed swaps (results sentence and Table "Agent leg").
7. Appendices: the decision table by kind of swap and budget; every secondary table and figure (stakes in full, per-pair
   table, arms, PC3/PC4 with the base-rate gap and the with-item target, the measurement check's nine tests and its
   figure, the k-curve, the stopping-time and null figures, the forecast's F1 and its figure, P1-P3, the run after the
   swap, the realism check); the construct tables (correctness, strata and visit thirds, free baselines); the cost
   table's measured counts; the total calls and dollars; the datasheet's row counts and collection window; the pilot
   gate values and the pilot-set constants (score passes, exploration, headline score type, second stream).
8. Registered secondary rules whose analysis code is not written yet (pre-registration open point 30): the judge, the
   owner's write-time rating, relearn, and re-answer's home value. Their result cells stay empty until that code exists.
9. Items for the human authors, not data: the anonymous view-only link to the frozen pre-registration with its sha256;
   the anonymous code link; the AI tools and versions in the AI Disclosure Statement; the licence of the model outputs.
