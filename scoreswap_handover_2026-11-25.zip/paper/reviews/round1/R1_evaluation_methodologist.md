# Review R1: evaluation methodology and statistics

**Submission:** "Do Memory Scores Survive a Model Swap? A Benchmark of Keep, Wipe and Recalibrate Rules for Agent Memory" (ScoreSwap)
**Track / contribution type:** ICML 2027, Datasets, Evaluations and Benchmarks
**Reviewer expertise:** evaluation methodology and statistics for LLM benchmarks (error bars, clustered and paired inference, multiple testing, pre-registration, construct validity)
**Material read:** `main.tex`, `macros.tex`, every file in `sections/`, `assets/numbers.tex` and the four `assets/table_*.tex`, every figure in `assets/*.png`, and the supplementary `prediction/PREREGISTRATION.md`. Nothing else.

**Note on the version reviewed.** Every number, table and figure is from a simulation with made-up models ("DRY RUN - SIMULATED DATA"). I judge the question, design, statistics, definitions, claims and writing as they stand. I then judge the paper as if the real study (a) showed the same qualitative pattern as the dry run, (b) showed weak effects, or (c) showed null effects. Dry-run numbers are quoted only where they expose a design property that does not depend on the simulator: units, degenerate baselines, notation clashes, or numbers that do not add up.

---

## 1. Summary

The paper asks whether per-item usefulness scores in an agent's memory, earned while one LLM did the work (for example MemRL-style moving averages of rewards, or ACE-style helpful/harmful counters), still rank the items correctly after the agent is switched to a different LLM. The memory content is held fixed.

**Design.** Eight models (four makers, one old to new pair per maker) each build a 250-item bank on two program-graded single-call streams: DDXPlus diagnosis and BIRD text-to-SQL. Each stream is shuffled into three orders. An item is a past task plus the model's unlabelled answer. Each item carries five score families, updated over a 500-task score phase in which one item is shown at a time. A probe table then records, for every ordered owner-reader pair, the reader's graded result with each of the 4 most similar items shown alone (two repeats) and with no item.

**Measures.** The headline measure is a within-task, outcome-difference-weighted concordance C_w between the owner's scores and the reader's results. The paper reports the drop D = C_home - C_swap and the "retained validity" R = (C_swap - 0.5)/(C_home - 0.5). A self-swap (two extra owner repeats) gives a noise floor.

**Swap-day rules.** Keep, wipe, fixed discount, power prior, logistic recalibration, re-test, audit, pooled and fresh-only rules are compared offline on first-shown success and held-out log score.

**Confirmatory tests.** Twelve primary tests (PC1 to PC4 times three swap strata: 4 upgrades, 4 downgrades, 48 cross-maker swaps) are run under Holm. Each uses a stratified, paired task bootstrap.

**Three further pieces.**
- A "law of score transfer": C_swap - 1/2 is predicted from gamma (the slope of the reader's on the owner's true usefulness differences), the home signal and the outcome spreads, under a no-leakage assumption. The prediction has no fitted parameter.
- An anytime-valid betting test that keeps or drops old scores once it is sure.
- A pre-registered forecast of retained validity from no-memory error consistency, validated leave-one-model-out.

The supplement is a long, detailed draft pre-registration. An appendix also applies the question to released skill scores from another paper (Beyond Gain), with real numbers: Spearman 0.40 to 0.62 across model pairs.

**Dry-run pattern.**
- PC1 is inconclusive within a maker (R about 0.77, interval about 0.5 to 1.1) and finds a material drop across makers (R about 0.21).
- Keep beats wipe on first-shown success only for upgrades.
- The fixed discount beats keep on log score everywhere. Recalibration never beats both keep and wipe.
- The law fits with mean absolute error 0.03, against 0.11 for "no change".
- The forecast loses to a same-maker flag.
- The stop-when-sure check needs a median of about 560 to 630 tasks, more than the table holds.

---

## 2. Strengths

1. **A real, well-posed question with a clean main contrast.** Holding content fixed and changing only the reader isolates "do the scores transfer" from "does the memory content help". The authors correctly note that prior transfer results confound the two (the CHIME arithmetic in the introduction makes this concrete). The question is timely given forced deprecations.
2. **The probe-table design is the right benchmark design.** A full factorial of candidate by reader by repeat, graded by program, lets any rule that picks among the stored candidates be scored offline and paired on identical tasks. A future model can be added as a *reader* of the frozen banks without calling any retired model. Of everything here, this is most likely to be reused.
3. **Paired inference across all cells.** One resampled task list is applied to every owner, reader, rule and family, so all contrasts are paired. This is better practice than most LLM-evaluation papers.
4. **Good guardrails.**
   - A self-swap noise floor, a content-only shuffled control and a no-signal score family (`visits`).
   - The rule "a failed drop test is never reported as 'no drop'".
   - A non-inferiority test rather than a failure to reject.
   - The intersection-union construction for PC4 is correct.
5. **The theory is correct and partly illuminating.** I checked the proofs.
   - Proposition 3.1 (linearity) holds as stated.
   - The decomposition in Proposition 3.2 is exact.
   - The non-identifiability of gamma from one owner repeat (A8 (iii)) is a nice and useful result.
   - The invariance proposition explains cleanly why discount rules cannot change concordance, which justifies judging them by log score and decisions.
   - The Gaussian corollary and the Buhlmann break-even formula are both correct.
   - Most importantly, the paper itself shows that R mixes rank transfer with outcome noise. This is a genuine contribution to how such ratios should be read, and also the basis of my main criticism.
6. **Unusually honest scoping.** "What we do not claim", the limitations, the low-power warning on the forecast, the testability rule for permutation tests (1/n!), and reporting the undecided share of the sequential check are all commendable.
7. **The outside check on released data (Appendix A11)** is a real-data motivation, done carefully: it reproduces the original paper's 14 to 23% flip rate, splits noise from transfer with split halves, and lists its limits.

---

## 3. Weaknesses (most serious first)

### W1. The headline measure R does not measure the stated construct, by the paper's own Proposition 3.2.

The question is whether the old scores "still rank the items correctly" for the new model. The headline is R = (C_swap - 0.5)/(C_home - 0.5) (Eq. 2). It is used in the abstract, Fig. 1, the PC1 non-inferiority margin and P1 to P4.

Section 3 itself shows what R measures: "So a noisier reader lowers R with no change in transfer, while R_V = V_swap/V_home -> gamma is free of outcome noise". The supplement says the same thing more bluntly (Part 11.1): "the plain ratio R moves with the two models' outcome noise, and theta does not." Two separate problems follow.

1. **Noise confound.** R falls when the reader's repeats are noisier, even if the ranking is perfectly preserved.
   - The design makes noise differ systematically between readers: "no temperature is sent to closed models and every sampling value is explicit on open hosts" (Sec. 4).
   - So R across makers partly measures the closed/open sampling settings.
   - The noise floor cannot fix this: it uses the *owner's* self-swap, which says nothing about a noisier *reader*.
2. **Scale confound, even in the noise-free version.**
   - R_V converges to gamma = rho * sd(delta^t)/sd(delta^s).
   - Suppose a stronger reader barely depends on which exemplar it sees (small sd(delta^t)). Then R_V is small even when rho = 1, that is, when the old scores order the items *exactly* as the reader's true usefulness does.
   - So neither R nor R_V answers "do the scores still rank the items correctly". They answer "how much of the owner's usefulness spread, in the reader's units, the old order still picks up". That is a legitimate quantity, but a different one.

The Appendix A11 numbers show how much this matters: the plain ratio moved "between 0.48 and 0.97" while the noise-allowing ratio ranged "from 0.65 to 0.91".

*Fix.*
- Decide which construct is the headline and name it accordingly. For "ranking correctness", use the attenuation-corrected rho-hat, or R_std (which the supplement already defines and predicts to equal rho). Alternatively, normalise C_swap by the *reader's* own ceiling, which A8 already derives ("Ceiling").
- For "usefulness picked up", use theta = R_V.
- Report R only as a secondary, noise-confounded quantity.
- Put the NI margin on the chosen noise-free quantity.
- The pre-registration is still marked "DRAFT. Not frozen", so this can be done now without a deviation.
- Equalise sampling settings wherever the API allows it. Claude accepts a temperature; send the same one as on the open hosts. Report repeat disagreement per model in the main text.

### W2. The Holm procedure with min(p_drop, p_NI) does not control the familywise error rate as claimed. The same flaw affects the law's family T.

A9: "PC1 enters Holm with min(p_drop, p_NI)". The supplement (Part 3) justifies this: "this keeps the familywise error at 0.05 because only one of the two nulls can be true". That argument is valid for single-step Bonferroni. It is not valid for Holm's step-down.

Why: a PC1 member can be rejected *correctly* through its false component, and that rejection loosens the thresholds of later steps. Meanwhile the member still carries a true null component that may be claimed at the loosened threshold. Holm's proof needs the first false rejection to occur after at most m - m0 rejections. Here, members that carry a true component can be rejected without error, so that bound fails.

*Counterexample.*
- All nine PC2 to PC4 nulls are false, with p-values smaller than those of the PC1 members.
- In each of the three strata the drop sits exactly at the NI margin (D = 0.25 times the home signal) and is estimated precisely. So p_drop is tiny (a correct "drop" claim), and p_NI is roughly uniform under its boundary null.
- The PC1 members then reach Holm steps 10 to 12, with thresholds alpha/3, alpha/2 and alpha.
- The supplement allows "every claim of that PC1 test whose own p-value is at or below its Holm threshold" ("this can sit beside 'small drop'").
- P(at least one false "no material drop" claim) = 1 - (1 - 0.05/3)(1 - 0.05/2)(1 - 0.05), which is about 0.089. That exceeds 0.05.

Family T uses the same device, "T1(g) enters Holm with p = min(p_eq, p_diff)".

*Fix.* Any one of these works:
- Enter p_drop and p_NI as separate members (15 tests; Holm is valid under any logical relation).
- Use an explicit closed test under the partitioning principle, which in effect orders PC1 members by the component not yet rejected.
- Use the Bonferroni form 2 * min already adopted for the per-pair flags.

The cost in power is small.

### W3. Primary intervals ignore two known sources of dependence: tasks reused across orders, and items reused across tasks.

1. **Tasks recur across orders.**
   - Each stream "is shuffled with seeds 0, 1 and 2 and cut into parts that share no task: 250 write, 500 score, 500 probe ... and 250 test", which is 1,500 tasks per order.
   - The supplement says DS-1000 "has 1,000 tasks and cannot hold 1,500". So each order reshuffles roughly the same pool.
   - The "1,200 evaluation tasks per stream" are therefore not 1,200 distinct tasks. The same task can be an evaluation task in two or three orders, with different banks.
   - The bootstrap "resample[s] evaluation tasks within each (stream, order) stratum" independently and treats "the three orders [as] fixed strata, not clusters". That treats repeated appearances of one task as independent draws, so it understates the variance of everything pooled over orders.
   - *Fix:* resample unique task IDs across orders (each draw carries all appearances of a task), and report the overlap.
2. **Items recur across tasks.**
   - One item is a candidate on many tasks, and its score error and its reader usefulness are fixed across them.
   - The paper's own A8 reports that for the law's gap a task-only bootstrap covers 91 to 92% against 94 to 97% for the two-way variance. Accordingly the law uses a task-and-item variance "because a finite bank leaks by chance".
   - PC1 to PC4, the confirmatory claims, use the task-only bootstrap. The two-way pigeonhole bootstrap is only a "cross-check".
   - So the paper adopts the items-as-sampled estimand for its secondary law and the items-as-fixed estimand for its primary claims, and never says so.
   - *Fix:* either make the two-way (task by item, task IDs clustered across orders) bootstrap primary for PC1 to PC4, or state that the primary estimand is conditional on these specific banks. If you take the second route, remove the general phrasing ("old scores keep ...") everywhere.
3. **Bank construction is a single realisation.** Exploration randomness in the score phase is not in any interval. The "second independent bank" (supplement 8.3.4) should be used to report this variance component in the main text.

### W4. The swap strata are inference about 4, 4 and 48 fixed pairs, but the abstract states them as facts about kinds of swaps. The cross-maker stratum hides structured heterogeneity.

- "Old scores keep X of their above-chance validity after same-maker upgrades" summarises four specific pairs, one per maker, with a task-only interval. Between-pair variance is not in the interval. With n = 4 pairs, a statement about "upgrades" in general would have an interval with 3 degrees of freedom.
- The limitations section says so ("every confirmatory statement is conditional on eight models"). The abstract and Results do not.
- Strata (a) and (b) are the same four unordered pairs in two directions, so the upgrade/downgrade contrast rests on four within-pair comparisons, not two independent samples.
- Stratum (c) has equal-weight members of four different kinds: 12 old to new, 12 new to old, 12 old to old and 12 new to new cross-maker swaps. It also mixes closed to open and open to closed. Only old to new is the realistic retirement scenario.
- The supplement pre-registers a heterogeneity summary (range, share of opposite-sign pairs, source/target SDs). None of it appears in the Results section.

*Fix:*
- Report the pre-registered heterogeneity summary beside every stratum estimate.
- Add the cross-maker old to new subset (12 pairs) as a named secondary stratum.
- Show the source/target decomposition in the main text.
- Phrase stratum results as "for these four upgrade pairs".

### W5. PC3 and PC4 mainly test calibration-in-the-large and the noisiness of the moving average, not transfer. They need a home reference.

- The predicted success p is an *item-level* number (q for `ema_grade`), scored against task-level outcomes. It cannot follow task difficulty.
- In the dry-run table the constant prediction p = 0.5 (`wipe`, log score -0.693, with a degenerate interval) beats `keep` in every stratum (-0.743, -0.755, -0.828). It also beats the reader's `own` bank (-0.700 to -0.713).
- When even a model's own scores lose to a coin on log score, shrinking toward 0.5 (`fixed_0.5`, PC3) will win whether or not a swap happened. And fitting a level (`recal_k`, PC4) rewards base-rate correction, not ranking.
- None of the arm tables reports the home cell for these rules.

*Fix:*
- Report LS and Brier for each rule at home and test the swap contrasts as difference-in-differences: (rule - keep)_swap - (rule - keep)_home.
- Or demote PC3 and PC4 to secondary and promote a decision-level contrast, such as first-shown success or regret of `recal_64` against `keep`.
- Consider a task-adjusted calibration target, for example the reader's success minus its no-item success on the task.

### W6. The stop-when-sure check is mis-summarised in the abstract, compared against strawmen, and its error guarantee assumes a known estimand.

1. **Units and omitted information.**
   - Abstract: "A keep-or-drop decision with controlled error needs a median of [563] fresh-check tasks, against 8 to 64 checks for fixed rules".
   - 563 tasks are 2,252 checks, so the comparison mixes units and understates the cost ratio, which is 35 to 280 times.
   - The sentence omits that in the replay the check left essentially every pair undecided: 0.2% decided within 100 tasks, and `CheckSequentialUndecided = 1.000`.
   - The supplement's own wording rule (11.4.11) requires the median "always given with the share undecided". The abstract breaks that rule.
2. **Strawman comparators.**
   - `audit_k` keeps if C_w > 0.5, so it tests theta > 0, not theta >= 0.75. Its "false keep" rate against a 0.75 threshold (58% in the dry run) is a feature of its definition.
   - The fair comparator is a fixed-sample one-sided test of the same hypothesis at the same alpha. It needs fewer tasks than the anytime-valid version; optional stopping is what you pay for.
   - Report that, and say plainly that the sample size the check "needs" is a property of this particular betting design, not of the problem.
3. **Plug-in threshold.** "If tasks are drawn independently and A-bar_home is treated as known, each error is at most alpha". A-bar_home is estimated, so the stated guarantee is not the operating guarantee.
   - *Fix:* use a lower confidence bound for A-bar_home, splitting alpha, or test the paired difference A_swap - 0.75 A_home directly.
4. **Measure proliferation.** The check uses theta, the law uses R_V, the forecast figure uses "T = N_swap/N_home", and PC1 uses R. The supplement says theta = R_V = T, but the paper never states it. "N" also collides with N(tau) in Eq. 1 and with N-bar in the NI test.

### W7. The "law" is an exact decomposition plus a mediation assumption, tested in-sample. "Prediction with no fitted parameter" overstates it.

- gamma-hat = sum(Delta y^s Delta y^t) / sum(d-hat_s^2) is computed from the reader's outcomes on the *same* evaluation pairs that define C_swap, and it is divided by the same W_swap.
- The "prediction" therefore needs the full reader-side probe table: the expensive measurement itself. It cannot be made before a swap.
- The gap test checks an orthogonality condition, that sgn(Delta x) is uncorrelated with the residual of delta^t on delta^s. That is useful (it is a test of leakage), but it is not out-of-sample prediction.
- The comparison baseline "no change" (C_swap = C_home) is weak. The supplement registers stronger ones (R = gamma-hat with spreads ignored; R = rho-hat) that the Results do not report.
- The pre-registered confirmatory tests of the law (family T: T1 equivalence within +/-0.02 per stratum, T2 family differences) are not reported at all. Results gives a mean gap, a mean absolute error and a coverage share. Mean gap close to 0 across pairs can hide large gaps of both signs, and coverage of zero is non-rejection, not support.
- In Fig. 2 the x-axis error bars are as wide as 0.46 to 0.76, so a low-power law "fits" by default. This is exactly what the equivalence test is for.

*Fix:*
- Call it a decomposition with a testable no-leakage condition.
- Report the registered T1 and T2 decisions and the stronger baselines.
- Show that the law outperforms R = rho-hat, the only competitor that is equally cheap to compute.

### W8. Construct validity of the single-item, 1-of-4 probe and of the score-earning process.

- The benchmark measures re-ranking among the 4 nearest neighbours, with one shown. The scores are also *earned* with one item shown.
- The systems cited in motivation retrieve candidates by similarity and then select several items by a score mix. MemRL also updates all retrieved items. So both the score-generation process and the use of the score differ from deployment.
- If a deployed system shows all four candidates, within-candidate ranking is irrelevant. If it re-ranks a larger pool, the probe's 4-candidate restriction understates the score's role.
- The realism check covers only the upgrade pairs and home cells on 100 tasks.
- In these streams an item is a few-shot exemplar (task plus unlabelled answer). The construct is closer to "transfer of exemplar-utility estimates" than to "agent memory". The agent leg (LifelongAgentBench) is the only test of the broader claim, and Sec. 4 still says "state which legs ran".

*Fix:*
- Justify the 4/1 design against how the cited systems use scores.
- Add a k-shown sensitivity (the Shapley subsets already contain the 2-, 3- and 4-item results; use them for swap pairs too).
- Run the score phase with multi-item retrieval for at least one owner.
- Narrow the framing in the title and abstract to what is measured.

A cheap construct check: the write phase is graded by program, so each item's stored answer is known to be right or wrong. Report how much of home and swap concordance a model-independent "stored answer is correct" score achieves. If scores mostly track answer correctness, high within-maker transfer is expected and the interesting part is the residual.

### W9. "Oracle" is not an oracle, and some baselines are degenerate.

- The cross-fitted `oracle` picks on one noisy repeat and scores on the other. In the dry run it is *below* `keep` for upgrades (0.658 vs 0.703) and below `own` everywhere.
- The supplement says "a reference, not an upper bound". The paper calls it "the cross-fitted oracle" with no caveat.
- *Fix:* rename it ("one-repeat pick"), and give a real ceiling: the model-based ceiling the supplement registers (8.2.8), or a home-cell version that picks on 3 repeats and scores on 1.
- The content-only control (`shuffled`) has C_w = 0.5 by construction. It verifies the code, not the content. The informative content control is FS_shuffled vs FS_wipe.

### W10. The self-swap rule is ad hoc, and the 4-SE gate introduces selection.

- "A drop counts only if its test rejects and the point estimate exceeds U_self". This compares a point estimate with the upper endpoint of a *different* statistic's interval, and double-counts sampling noise that is already in D's own interval.
- The supplement already defines the coherent contrast, C_fresh - C_swap ("same variance as D"), and relegates it to secondary. Make it the drop statistic, or drop the U_self rule.
- R is "reported only when C_home - 0.5 is at least four standard errors". Conditioning on a large observed denominator biases R downward near the threshold.
- In the weak-effect scenario this gate leaves most owners undefined, so the headline set becomes selected by home strength. Report how many owner-stream cells pass, and give D for all.

### W11. Pre-registration credibility and consistency.

- The supplement is "Status: DRAFT. Not frozen". It has open points where "the code differs from three rulings written into this file", and it refers to internal roles and documents ("the research manager", `docs/MASTER_PLAN.md`) that reviewers cannot see.
- The paper states "All tests are fixed in a pre-registration". Its Appendix on identity and deviations is entirely TODO.
- A self-hashed file in the authors' own repository is weak evidence of timing.
- *Fix:* freeze on a third-party registry with a timestamp (for example OSF, embargoed until review) before the first paid main-run call, and cite the registration ID. Reconcile the paper with the registration:
  - A1 says "each of 1,000 draws d" and "1,000 permutations"; the registration was amended to 200.
  - PC4 is "k = 64" in Sec. 3 but "k = 32 in PC4" in the dry-run box and in Table A13 ("recal_32").
  - The decision categories ("material drop" requires D >= 0.05) are in the registration only.
- P3 ("tags lose more") and the law's T2 ("no family difference") are acknowledged in the registration to "predict opposite things ... at most one of them can come out as predicted". Registering contradictory predictions weakens the "pre-registered predictions" framing. Say which one the authors actually believe, or present P3 as a test of the law.
- P1 (agreement predicts R) and F1 (error consistency predicts theta) are close variants of one hypothesis, tested in two families without joint control.

### W12. Reproducibility and reuse claims overreach with closed models.

- "so that the core can be re-run after closed models retire" (Sec. 4), "its open-weight core stays runnable" (Impact): after the closed models retire, only the 12 open-to-open ordered pairs (4 of the 8 same-maker swaps) can be re-run.
- Even these run through "one pinned host at fp8", a commercial third-party host whose kernels and availability are not under the authors' control.
- *Fix:* give weight commit hashes, run (or at least validate) the open models locally with a stated serving stack, and report how close the hosted fp8 results are to local ones.
- "Score any new rule offline with no model calls" holds only for rules that map the frozen bank statistics, plus at most two checks per calibration cell (calibration tasks only), to an order over the 4 fixed candidates, with one item shown. It does not hold for:
  - new score families whose own retrieval loop would have changed what was shown in the score phase (off-policy; propensities are logged but not used);
  - rules that need more checks per item (the paper's own break-even, "about two checks per item ... beyond the budgets", is out of reach of the table for most items);
  - rules that show several items or retrieve beyond 4 candidates.
- State the marginal cost of adding one reader model. By my count from Sec. 3 to 4 this is about 8 owners x 500 tasks x 4 candidates x 2 repeats x 6 stream-orders, roughly 190k calls plus no-item runs. Note that new *owners* can never be read by retired models.
- The cost table is a placeholder (sim cost is $0.00). The real total, by my rough count over 1.7M probe calls, should be in the main text.

### W13. Presentation.

- Too many contributions compete for eight pages: benchmark, law, rule comparison, sequential check, forecast, four predictions and an online run. Essential definitions (decision categories, gates, which repeats enter gamma-hat, pooling rules) live only in the supplement.
- "Family" means a score family, a Holm family and a model maker ("Cross-family" in Tables 2 to 4 and Figs. 1 to 6 vs "cross-maker" in the text).
- Sec. 2 says the law "under normality ... reduces to the classical arcsin form". A8 shows the arcsin form is for the *unweighted* C, and that for C_w the Gaussian limit is (1 + r)/2.
- The abstract gives point estimates without intervals or decisions.
- Fig. 2's caption says "95% intervals", but the plotted bars are "95% task bootstrap", which A8 shows under-covers for this statistic.
- Fig. 1's caption explains hatched cells, but none is hatched, while the law reports only 9 of 12 pairs "defined". Two different gates exist and neither is stated in the main text.
- The datasheet, licences, prompts, release checklist and AI-use statement are stubs. For a datasets and benchmarks paper these must be complete and the data accessible to reviewers at submission.
- Missing related work on cross-model transfer of exemplar utility, the closest prior art for the single-call streams:
  - Rubin et al. (2022), EPR: a retriever trained with one LM's scores, used with other LMs.
  - Wang et al. (NeurIPS 2023): demonstrations selected with a small LM, transferred to larger LMs.
- Missing related work on backward compatibility and regression-free model updates (for example Bansal et al. 2019; Echterhoff et al. 2024, MUSCLE).
- Missing related work on item-level statistics transferred across models in IRT-based benchmark compression (tinyBenchmarks, anchor points).

---

## 4. Questions for the authors

1. Which construct is the headline: rank correctness (rho), usefulness picked up (theta = gamma), or noise-confounded R? Why should a practitioner care about R rather than about first-shown success?
2. What sampling settings will each model actually run with? What is repeat disagreement per model? Will you send the same temperature to every model that accepts one?
3. How many distinct tasks does each stream pool contain, and what fraction of evaluation tasks recur across the three orders? Does the bootstrap cluster on task ID across orders?
4. How do you reconcile Holm with min(p_drop, p_NI) given the step-down counterexample in W2? Would you accept entering both components as separate members?
5. Why are PC1 to PC4 inferred with items fixed while the law treats items as sampled? Which estimand do the abstract's sentences refer to?
6. What are LS(keep), LS(fixed_0.5) and LS(recal_64) in the *home* cells? If fixed_0.5 also beats keep at home, what does PC3 tell us about swaps?
7. Which owner repeats enter gamma-hat: the same repeats 1 and 2 that define V_home? If so, how does the correlated error between gamma-hat and V_home affect the gap test?
8. Table 2 reports the same C_home (0.683) for upgrades, downgrades and cross-maker swaps. The supplement (Part 2.3) says the upgrade stratum's owners are the old models, the downgrade stratum's the new models, and the cross stratum's all eight. Is the stratum denominator pooled over all owners, or is this a coincidence or a bug?
9. The law's coverage is 0.833 of pairs, but only 9 of 12 pairs are "defined". What is the denominator, and which pairs enter the mean absolute error?
10. How much of home and swap concordance does a model-independent "stored answer is correct" score achieve?
11. For the sequential check, what is the sample size of a fixed-n one-sided test of theta > 0.75 at the same alpha and power? How do the conclusions change if A-bar_home is replaced by a lower confidence bound?
12. Which 12 swaps enter the run after the swap? Why does the forest plot's group estimate use equal weights per pair rather than per task?
13. Where and when will the pre-registration be frozen? Will the paper report the registration ID and every deviation, including the 1,000 vs 200 draws and k = 32 vs 64?

---

## 5. Scores (for the case where the real study shows the same qualitative pattern as the dry run)

| Criterion | Score | One-line reason |
|---|---|---|
| Soundness | **2** (fair) | Careful design and correct theory, but the headline R is confounded (by the paper's own Prop. 3.2), the Holm composite does not control FWER, the primary intervals ignore task and item reuse, and PC3/PC4 lack a home reference. All fixable. |
| Presentation | **2** (fair) | Honest and well organised at the top level, but overloaded: four overlapping retained-signal measures, "family" with three meanings, key definitions only in the supplement, an abstract without intervals and with a units error. |
| Significance | **3** (good) | Timely, practical question and a reusable factorial probe table. The measured setting (single-call, unlabelled exemplars, 1 of 4 shown) is narrower than "agent memory". |
| Originality | **3** (good) | First controlled item-level measurement with content held fixed. Close prior art on exemplar-utility transfer is missing. The statistical machinery is classical, as the authors say. |
| **Overall** | **3** (weak reject) | Worth publishing once the measure and inference are fixed. As written, the headline numbers would not mean what the abstract says they mean. |
| Confidence | **4** | I checked the proofs and the statistical procedures in detail. I am less certain about the 2026 related work I could not open. |

**How the Overall score moves.**
- **Same pattern, with W1 to W3 and W5 fixed and the claims rewritten:** 4 to 5. A clear "transfers within maker, largely lost across makers, keep beats wipe only for upgrades, cheap fixes do not help, controlled decisions are expensive" result is useful, and the probe table is a lasting asset.
- **Weak effects (home C_w barely above 0.5):** 2.
  - The 4-SE gate leaves R undefined for most owners, and PC1's NI test is not run.
  - The law's prediction collapses to about 0.5 for every pair, and the sequential check never decides.
  - The benchmark then cannot distinguish rules. Its main finding becomes "MemRL-style scores barely rank items even at home". That is an important negative result, but a different paper, and it would need a different framing and analysis (home validity by family, visits and stream).
  - It would climb back to 3 if reframed honestly around that finding, with home validity measured against the stored-answer-correctness baseline.
- **Null effects, informative case (NI rejects in every stratum, R or theta about 1):** 3 to 4. "Scores survive swaps; keep them" is a useful, well-powered null, but the law and rules sections lose most of their interest.
- **Null effects, uninformative case (everything inconclusive):** 2. The paper would amount to a measurement framework with no measured conclusion.

---

## 6. Most likely reason for rejection, and the three changes that would raise my score most

**Most likely rejection reason.** The headline quantity does not measure the question asked. "Retained validity" R is, by the authors' own Proposition 3.2, driven by the reader's outcome noise and usefulness spread as much as by whether the old scores still rank items correctly. Closed and open models run under different sampling settings, so cross-maker R partly measures the API configuration. A reviewer who sees this will not trust the abstract's percentages. The thinly specified primary inference (W2, W3) and the narrow single-item setting will then decide against the paper.

**Three changes, ranked by impact per unit of effort.**
1. **Change the headline measure before freezing.** Low effort, highest impact: everything is already computed.
   - Make a noise-free quantity primary: theta = R_V for usefulness picked up, and rho-hat / R_std or a reader-ceiling-normalised C_w for ranking correctness.
   - Put the NI margin on it, keep R as a secondary column, and equalise sampling temperature wherever the API allows it.
   - Report repeat disagreement per model in the main text.
2. **Repair the confirmatory inference.** Low to moderate effort.
   - Enter p_drop and p_NI as separate Holm members, or use a closed test; do the same for T1.
   - Bootstrap clusters on task ID across orders, with items crossed (two-way), as the primary analysis.
   - Report the registered heterogeneity summary and the cross-maker old-to-new subset beside every stratum.
   - Freeze the registration on a timestamped third-party registry.
3. **Rewrite the claims and reference PC3/PC4 to home.** Low effort.
   - Abstract with intervals and the confirmatory decisions.
   - The sequential-check sentence in consistent units, with the undecided share and against a fixed-n test at equal alpha.
   - "Law" becomes "decomposition with a testable no-leakage condition", with T1 and T2 reported.
   - "Oracle" renamed; "any new rule" scoped.
   - PC3 and PC4 as swap-minus-home contrasts, or demoted.

---

## 7. Overclaims, ambiguous definitions, and statistics that cannot be reproduced from the text

### 7a. Sentences I consider overclaims

1. Abstract: "yet no study has tested this item by item." Unhedged. Sec. 2 correctly says "In the work we found". The authors' own Appendix A11 and the judge-replacement and exemplar-transfer literature test closely related item-level questions.
2. Abstract: "we explain the result with a law of score transfer whose prediction has no fitted parameter". gamma-hat is estimated from the reader's outcomes on the same pairs (W7). "Explain" is stronger than an in-sample decomposition supports.
3. Abstract: "the law predicts the swap validity of each pair with a mean gap of ...". A mean gap across pairs says nothing about *each* pair; the per-pair coverage is lower than nominal.
4. Abstract: "Old scores keep [0.768] of their above-chance validity after same-maker upgrades". The confirmatory decision was "inconclusive" (interval 0.49 to 1.13); the statement concerns four specific pairs; and R is noise-confounded (W1).
5. Abstract: "A keep-or-drop decision with controlled error needs a median of [563] fresh-check tasks, against 8 to 64 checks for fixed rules". Mixed units (tasks vs checks); the fixed rules do not control error; the undecided share is omitted; "needs" is a property of this betting design, not of the problem.
6. Abstract and Sec. 1: "we release frozen probe tables that score any new rule offline with no model calls" / "any score rule, including rules proposed later, is scored offline". It holds only for rules over the 4 fixed candidates, one shown, using at most the stored checks (W12).
7. Sec. 1: "validity after the swap is validity at home times a transfer slope that is measured *without the scores*, so each pair's swap validity is predicted with no fitted parameter". The slope is measured with the full reader probe table on the same items.
8. Sec. 1: "the check measures how many fresh checks such a decision needs". It measures how many *this* anytime-valid test needs.
9. Sec. 2: "Our law is distribution-free ...; under normality it reduces to the classical arcsin form". This contradicts A8: for C_w the Gaussian limit is (1 + r)/2; arcsin applies to the unweighted C.
10. Sec. 2: "\bench{} supplies the measured answer." It supplies a measured answer for 8 models, 2 streams and one display protocol.
11. Sec. 4: "each through one pinned host at fp8 with fallbacks off, so that the core can be re-run after closed models retire". Only 12 of 56 pairs, through a third-party host.
12. Impact: "This work gives practitioners a way to check, before and after such a swap, whether the stored usefulness scores still point to the right items, and what that check costs." In the dry-run pattern the "before" forecast loses to a same-maker flag, and the "after" check does not decide within the table.
13. Impact: "its open-weight core stays runnable after closed models retire". Same issue as item 11.
14. Impact: "A likely benefit is fewer silent failures after a model swap". Speculative; not supported by any measured deployment outcome.
15. Sec. 3.3 (Law): "Since gamma and W involve no score, a score's reliability cancels from R and R_V". This holds only under L = 0 for every family. The sentence reads as unconditional; say "under the law".
16. Results: "for the cross-fitted \arm{oracle}". It is labelled as a ceiling but is below `keep` (W9).
17. Sec. 3: "with unit weights C_w is the within-task Harrell's C, a stratified Somers' D". C is not D: D = 2C - 1.

### 7b. Ambiguous definitions

1. **The 4-SE gate for R.** At which pooling level (pair-stream, pair, owner, stratum)? Which SE (bootstrap SD of C_home)? The main text does not say. The supplement does (Part 2.4), but the figure caption implies a per-cell gate that never fires.
2. **"Pooled within strata" for R.** Ratio of stratum means, or mean of per-pair ratios? Equal weight per pair, per stream or per task?
3. **Which repeats enter gamma-hat and V_home.** The paper says only "with its two repeats".
4. **theta, R_V, T and A-bar.** The paper never states theta = R_V. Fig. "forecast_readiness" uses T = N_swap/N_home, which collides with N(tau) in Eq. 1 and with N-bar in the NI test.
5. **"Family".** Score family vs Holm family vs model family; "cross-family" in tables and figures, "cross-maker" in text.
6. **Decision labels.** "material drop", "small drop", "keep beats wipe (practical size, >= 5 points)", "not shown". The 5-point thresholds and category rules are not in the paper.
7. **U_self.** "the upper end of the matching self-swap interval": which interval level, and at what pooling?
8. **"Informative pair" and the law's definedness.** The definedness criterion (sum d-hat_s^2 >= 4 SE) differs from the R gate and is not stated in the paper.
9. **The run after the swap.** Which swaps, arms and k (the figure shows "recalibrate (16 checks)"; the registration says recal_64; numbers.tex has `OnlineRecalOneSixAll`)?
10. **A_tau.** Defined for "candidates ... each checked once", but A-bar_home is computed from the owner's two-repeat means. Linear, so unbiased, but the variance and the betting bounds differ. State which.
11. **The forecast target.** theta or R? The text says theta; the figure axis says "T".
12. **"Same-maker upgrade".** Version, size and possibly architecture change together (gemma-3-27b to gemma-4-31b). State what "upgrade" fixes.

### 7c. Statistics I could not reproduce from the text and assets

1. **Identical home concordance across strata.** `PCOneUpgradeCHome` = `PCOneDowngradeCHome` = `PCOneCrossCHome` = 0.683, although the strata have different owner sets (see Q8).
2. **Law coverage denominator.** `LawCoverageTwoWayAllSwapsValue` = 0.833 (10/12), but `LawNPairsDefinedAllSwapsValue` = 9. Likewise same-maker coverage 0.750 with 3 defined, and cross-maker 0.875 with 6 defined.
3. **Fig. 1 vs the law's definedness.** Fig. 1 shows R for all 12 swaps with no hatched (undefined) cell, while the law reports only 9 defined pairs. Two different gates are applied and neither is stated.
4. **PC4 k.** Sec. 3 and A9 say k = 64; the dry-run box and `table_main` use k = 32; the online-run figure uses 16.
5. **Draw counts.** A1 says "1,000 draws d" and "1,000 permutations"; the supplement says 200.
6. **The sequential headline.** "against at most 16 tasks (64 checks)" vs the abstract's "8 to 64 checks". The 100-task cap in the Results vs the 300-task replay cap in Fig. "sequential_stopping" and supplement 11.4.6.
7. **PC1 p-values.** `PCOneUpgradeP` = 0.0915 is labelled `p_holm_input`. Whether this is p_drop or min(p_drop, p_NI) cannot be told from the table, which shows only "Estimate" for D-bar and no NI statistic. The NI estimate N-bar and its p should be columns of Table 2.
8. **Equal pooling over streams.** The dry run uses one stream; the formulas for pooling two streams (Part 2.12 of the supplement) are not in the paper, so the eventual numbers cannot be rebuilt from the text alone.
9. **Fig. 2 intervals.** The intervals are task-bootstrap, while the text says the law's test uses the two-way variance. The plotted intervals are not the ones tested.
10. **Cost.** The total number of calls and the USD for the real study cannot be derived from the text. Table A5 is a placeholder; give the formula and the price snapshot.

---

*Reviewer's closing note.* This is one of the more careful evaluation designs I have reviewed in this area. Most problems above are of the kind that a strong team can fix before freezing the registration: choosing the right estimand, using the multiple-testing procedure correctly, and clustering correctly. The biggest risk is in the framing, not the engineering. The paper's own theory tells the authors their headline ratio is confounded, and the paper does not yet act on it.
