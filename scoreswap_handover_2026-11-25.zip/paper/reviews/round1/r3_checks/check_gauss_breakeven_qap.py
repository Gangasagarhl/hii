"""Checks 8-10: Gaussian corollary on discrete outcomes; break-even formula; model-label permutation (QAP) test."""
import itertools
import numpy as np
from scipy import stats

rng = np.random.default_rng(11)
PAIRS = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]


def diffs(a):
    return np.stack([a[:, i] - a[:, j] for i, j in PAIRS], 1).ravel()


# ---- Check 8: Gaussian corollary when outcomes are means of 2 Bernoulli repeats
print("[8] Gaussian corollary vs discrete outcomes (2 repeats):")
for sd_b, sd_e, sd_xn in [(0.6, 0.6, 0.3), (1.0, 0.5, 0.2), (0.4, 0.8, 0.6)]:
    T, B = 300000, 5000
    items = rng.integers(0, B, (T, 4))
    b = rng.normal(0, sd_b, B)
    mu = 1 / (1 + np.exp(-(rng.normal(0.3, 1.0, (T, 1)) + b[items] + rng.normal(0, sd_e, (T, 4)))))
    x = (b + rng.normal(0, sd_xn, B))[items]
    y = (rng.random((T, 4, 2)) < mu[..., None]).mean(-1)
    dx, dy, dmu = diffs(x), diffs(y), diffs(mu)
    inf = dy != 0
    C_unw = np.mean(np.sign(dx[inf]) == np.sign(dy[inf]))
    r = np.corrcoef(dx, dy)[0, 1]
    Cw = 0.5 + np.sum(np.sign(dx) * dy) / (2 * np.sum(np.abs(dy)))
    r_xd = np.corrcoef(dx, dmu)[0, 1]
    pred_meas = 0.5 + 0.5 * np.sqrt(2 / np.pi) * r_xd * dmu.std() / np.abs(dy).mean()
    print(f"    sd_b={sd_b} sd_e={sd_e}: unweighted C={C_unw:.3f} arcsin form={0.5+np.arcsin(r)/np.pi:.3f} "
          f"(miss {C_unw-0.5-np.arcsin(r)/np.pi:+.3f}); Cw={Cw:.3f} (1+r)/2={(1+r)/2:.3f} (miss {Cw-(1+r)/2:+.3f}); "
          f"measured-E|dy| form={pred_meas:.3f} (miss {Cw-pred_meas:+.3f})")

# ---- Check 9: break-even formula
print("[9] break-even: corr(p_hat_s, p_t) vs rho*sqrt(n/(n+eta_s)); k* formula")
a_s, b_s, a_t, b_t = 2.0, 3.0, 3.0, 2.0
eta_s, eta_t = a_s + b_s, a_t + b_t
N = 400000
z = rng.multivariate_normal([0, 0], [[1, 0.75], [0.75, 1]], N)
ps = stats.beta.ppf(stats.norm.cdf(z[:, 0]), a_s, b_s)
pt = stats.beta.ppf(stats.norm.cdf(z[:, 1]), a_t, b_t)
rho = np.corrcoef(ps, pt)[0, 1]
for n in [3, 6, 20]:
    s = rng.binomial(n, ps)
    c_old = np.corrcoef(s, pt)[0, 1]
    kstar = eta_t * rho ** 2 * n / (eta_s + (1 - rho ** 2) * n)
    cs = []
    for k in range(1, 12):
        cs.append(np.corrcoef(rng.binomial(k, pt), pt)[0, 1])
    first_win = next((k for k, c in zip(range(1, 12), cs) if c > c_old), None)
    print(f"    rho={rho:.3f} n={n}: corr old={c_old:.3f} formula={rho*np.sqrt(n/(n+eta_s)):.3f}; "
          f"k*={kstar:.2f}; first winning integer k={first_win}")

# ---- Check 10: model-label permutation (QAP/Mantel) test when both arrays carry the maker structure
print("[10] F1-type permutation test of Spearman(ec, theta) when theta depends ONLY on same-maker, "
      "and ec = same-maker effect + independent noise (ec adds nothing beyond the maker flag):")
models = list(range(8)); maker = np.array([0, 0, 1, 1, 2, 2, 3, 3])
swaps = [(a, b) for a in models for b in models if a != b]
same = np.array([maker[a] == maker[b] for a, b in swaps], float)
perms = list(itertools.permutations(models))
idx = rng.choice(len(perms), 3000, replace=False)
perm_sub = [perms[i] for i in idx]
rej = 0; nsim = 200
for _ in range(nsim):
    noise_pair = rng.normal(0, 0.05, (8, 8)); noise_pair = (noise_pair + noise_pair.T) / 2
    ec = np.array([0.10 + 0.08 * (maker[a] == maker[b]) + noise_pair[a, b] for a, b in swaps])
    theta = np.array([0.30 + 0.45 * (maker[a] == maker[b]) + rng.normal(0, 0.2) for a, b in swaps])
    obs = stats.spearmanr(ec, theta)[0]
    ecm = np.zeros((8, 8))
    for (a, b), v in zip(swaps, ec):
        ecm[a, b] = v
    cnt = 1
    for p in perm_sub:
        ecp = np.array([ecm[p[a], p[b]] for a, b in swaps])
        cnt += stats.spearmanr(ecp, theta)[0] >= obs
    rej += (cnt / (len(perm_sub) + 1)) <= 0.025
print(f"    rejection rate at 0.025 = {rej/nsim:.2f} (the test rejects the sharp null of independence, "
      f"not 'ec predicts beyond same-maker')")
