"""Checks 5-7, 11: count discount counterexample; the stop-when-sure check with the home value estimated;
a lower bound on the tasks any level-alpha sequential test needs; sampling without replacement."""
import numpy as np

rng = np.random.default_rng(3)

# ---- Check 5: discount on counts at a fixed lambda
def bmean(s, n, lam):
    return (1 + lam * s) / (2 + lam * n)
si, ni, sj, nj = 1, 1, 6, 10
for lam in [1e-6, 0.1, 0.25, 0.5, 1.0]:
    print(f"[5] lambda={lam:<6}: item i (1/1)={bmean(si,ni,lam):.4f}  item j (6/10)={bmean(sj,nj,lam):.4f}")
print("[5] net count: i=0 net... m_i=s-n/2=", si - ni / 2, " m_j=", sj - nj / 2,
      "-> orders disagree (net: j>i; Beta(1,1): i>j), yet lambda=0.5 keeps keep's order (crossing at 0.25)")

# ---- Check 6: sequential check; home value estimated vs known
BETS = np.arange(1, 21) / 40.0
ALPHA = 0.05
D_HOME = 0.12  # candidate offsets so that E A_home = 5d/3 = 0.2
MU0 = 0.6


def task_A(n_rep, T, d):
    """A = (3y1 + y2 - y3 - 3y4)/4 with mu = 0.6 + (d, d/3, -d/3, -d); E A = 5d/3."""
    mu = MU0 + np.array([d, d / 3, -d / 3, -d])
    y = rng.random((n_rep, T, 4)) < mu
    return (3 * y[..., 0] + y[..., 1] - y[..., 2] - 3 * y[..., 3]) / 4.0


def run_keep_test(xi, omega):
    """xi: (R,T) in [0,1]; omega: (R,) thresholds; returns first rejection time (or -1)."""
    R, T = xi.shape
    wealth = np.zeros((R, T))
    for eta in BETS:
        wealth += np.exp(np.cumsum(np.log1p(eta * (xi - omega[:, None])), axis=1))
    wealth /= len(BETS)
    hit = wealth >= 1 / ALPHA
    first = np.where(hit.any(1), hit.argmax(1) + 1, -1)
    return first


A_home_true = 5 * D_HOME / 3
sdA = task_A(1, 200000, D_HOME).std()
print(f"[6] per-task statistic: E A_home={A_home_true:.3f}, sd(A) one check={sdA:.3f}")
T = 6000
R = 1000
for theta in [0.60, 0.70, 0.74]:
    d = theta * D_HOME
    for se_frac in [0.0, 1 / 10, 1 / 4]:
        A = task_A(R, T, d)
        xi = (A + 1) / 2
        Ahat = A_home_true + rng.normal(0, se_frac * A_home_true, R) if se_frac > 0 else np.full(R, A_home_true)
        omega = (0.75 * Ahat + 1) / 2
        first = run_keep_test(xi, omega)
        rates = {cap: np.mean((first > 0) & (first <= cap)) for cap in [100, 300, 1000, 6000]}
        lab = "known" if se_frac == 0 else f"SE=A_home/{int(1/se_frac)}"
        print(f"[6] theta={theta:.2f} home {lab:14s}: P(false KEEP by 100/300/1000/6000 tasks) = "
              + " / ".join(f"{rates[c]:.3f}" for c in [100, 300, 1000, 6000]))

# stopping time at theta = 1 (home known)
A = task_A(1000, 3000, D_HOME)
first = run_keep_test((A + 1) / 2, np.full(1000, (0.75 * A_home_true + 1) / 2))
ok = first[first > 0]
print(f"[6] theta=1: P(KEEP by 100/300/3000 tasks) = {np.mean((first>0)&(first<=100)):.3f} / "
      f"{np.mean((first>0)&(first<=300)):.3f} / {np.mean(first>0):.3f}; median time | decided = {np.median(ok):.0f}")

# ---- Check 7: information lower bound for ANY sequential test (Wald's inequality)
mu1 = MU0 + np.array([1, 1 / 3, -1 / 3, -1]) * D_HOME
mu0 = MU0 + np.array([1, 1 / 3, -1 / 3, -1]) * D_HOME * 0.75
KL = np.sum(mu1 * np.log(mu1 / mu0) + (1 - mu1) * np.log((1 - mu1) / (1 - mu0)))
for beta in [0.5, 0.2]:
    a = ALPHA
    lb = ((1 - beta) * np.log((1 - beta) / a) + beta * np.log(beta / (1 - a))) / KL
    print(f"[7] Wald bound: any test with false-keep <= {a} at theta=0.75 and KEEP prob {1-beta} at theta=1 "
          f"needs E[N | theta=1] >= {lb:.0f} tasks (KL per task {KL:.5f}; uses all 4 outcomes, not just A)")
# fixed-n normal approximation on A itself
z = 1.645; zb = 0.842
print(f"[7] fixed-sample one-sided test on mean A, 80% power, theta 1 vs 0.75: n = {((z+zb)*sdA/(0.25*A_home_true))**2:.0f} tasks")

# ---- Check 11: sampling WITHOUT replacement from a 300-task pool whose mean is exactly at the threshold
Npool = 300
reps = 4000
rej = 0
for r in range(reps):
    pool = task_A(1, Npool, D_HOME * 0.75)[0]
    omega = (pool.mean() + 1) / 2   # null exactly true for the pool mean
    xi = (rng.permutation(pool) + 1) / 2
    first = run_keep_test(xi[None, :], np.array([omega]))
    rej += first[0] > 0
print(f"[11] WoR from a 300-task pool with pool mean exactly at the KEEP threshold: type-I = {rej/reps:.4f} (alpha 0.05)")
