import numpy as np
src = open("check_mediation_nonlinear.py").read().split('print("Reader = ')[0]
exec(src)
lg = lambda p: np.log(p/(1-p)); ex = lambda z: 1/(1+np.exp(-z))
print("Same nonlinear reader (logit-2.5), scores of different reliability (families differ only in noise):")
for sdx in [0.1, 0.5, 1.5]:
    run(lambda p: ex(lg(p)-2.5), f"score noise sd={sdx}", sd_b=1.2, sd_e=0.5, sd_xn=sdx)
