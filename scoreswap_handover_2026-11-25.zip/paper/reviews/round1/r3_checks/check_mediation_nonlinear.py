"""Check 3: 'mediation' (scores carry nothing about the reader beyond the owner's usefulness) does NOT imply L = 0.
The reader's success chance is a deterministic monotone function of the owner's success chance, cell by cell
(mu_t = g(mu_s)), and the score is a noisy function of the owner's item effect only.  So x is independent of mu_t
given mu_s.  We compute the population leakage L and the implied law gap in Cw units."""
import numpy as np

rng = np.random.default_rng(7)
PAIRS = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]


def diffs(a):
    return np.stack([a[:, i] - a[:, j] for i, j in PAIRS], 1)


def sgn(d):
    return np.sign(d)


def e_abs_diff_2rep(mi, mj):
    """E|ybar_i - ybar_j| for two repeat means, exact."""
    vals = np.array([0, .5, 1.])
    pi = np.stack([(1 - mi) ** 2, 2 * mi * (1 - mi), mi ** 2], -1)
    pj = np.stack([(1 - mj) ** 2, 2 * mj * (1 - mj), mj ** 2], -1)
    out = 0
    for a in range(3):
        for b in range(3):
            out = out + pi[..., a] * pj[..., b] * abs(vals[a] - vals[b])
    return out


def run(g, name, T=400000, B=5000, sd_b=0.8, sd_e=0.8, sd_xn=0.4, lvl_sd=1.0, lvl_mean=0.3):
    items = rng.integers(0, B, size=(T, 4))
    b = rng.normal(0, sd_b, B)
    e = rng.normal(0, sd_e, (T, 4))
    lvl = rng.normal(lvl_mean, lvl_sd, (T, 1))
    mu_s = 1 / (1 + np.exp(-(lvl + b[items] + e)))
    mu_t = g(mu_s)
    x = (b + rng.normal(0, sd_xn, B))[items]
    ds, dt = diffs(mu_s), diffs(mu_t)
    a = sgn(diffs(x))
    gam = (ds * dt).mean() / (ds ** 2).mean()
    Vh, Vs = (a * ds).mean(), (a * dt).mean()
    L = Vs - gam * Vh
    Wt = np.mean([e_abs_diff_2rep(mu_t[:, i], mu_t[:, j]) for i, j in PAIRS])
    Ws = np.mean([e_abs_diff_2rep(mu_s[:, i], mu_s[:, j]) for i, j in PAIRS])
    C_home = 0.5 + Vh / (2 * Ws)
    C_swap = 0.5 + Vs / (2 * Wt)
    pred = 0.5 + gam * Vh / (2 * Wt)
    print(f"{name:38s} gamma={gam:.3f}  R_V={Vs/Vh:.3f}  L={L:+.5f}  C_home={C_home:.3f}  "
          f"C_swap={C_swap:.3f}  law={pred:.3f}  gap(Cw)={C_swap-pred:+.4f}  mean mu_s={mu_s.mean():.2f} mu_t={mu_t.mean():.2f}")


print("Reader = deterministic monotone function of owner, cellwise (perfect 'mediation'):")
run(lambda p: p, "identity (control, law exact)")
run(lambda p: p ** 0.25, "stronger reader, saturating p^0.25")
run(lambda p: p ** 0.5, "stronger reader p^0.5")
run(lambda p: p ** 2, "weaker reader p^2")
run(lambda p: p ** 4, "much weaker reader p^4")
run(lambda p: 1 / (1 + np.exp(-3 * np.log(p / (1 - p)))), "sharper reader logit*3")
run(lambda p: 1 / (1 + np.exp(-0.4 * np.log(p / (1 - p)))), "flatter reader logit*0.4")
run(lambda p: 1 / (1 + np.exp(-(np.log(p / (1 - p)) + 2))), "uniformly stronger: logit+2")
run(lambda p: 1 / (1 + np.exp(-(np.log(p / (1 - p)) - 2))), "uniformly weaker: logit-2")
