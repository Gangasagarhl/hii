import numpy as np, importlib.util, sys
spec = importlib.util.spec_from_file_location("m", "check_mediation_nonlinear.py")
src = open("check_mediation_nonlinear.py").read().split('print("Reader = ')[0]
exec(src)
lg = lambda p: np.log(p/(1-p)); ex = lambda z: 1/(1+np.exp(-z))
print("More reliable score (sd_xn=0.1), item effects dominant (sd_b=1.2, sd_e=0.5):")
kw = dict(sd_b=1.2, sd_e=0.5, sd_xn=0.1)
run(lambda p: p, "identity", **kw)
run(lambda p: ex(lg(p)-2.5), "weaker: logit-2.5", **kw)
run(lambda p: ex(lg(p)+2.5), "stronger: logit+2.5", **kw)
run(lambda p: ex(3*lg(p)), "sharper logit*3", **kw)
run(lambda p: ex(5*lg(p)-1), "threshold-like 5*logit-1", **kw)
run(lambda p: p**4, "p^4", **kw)
