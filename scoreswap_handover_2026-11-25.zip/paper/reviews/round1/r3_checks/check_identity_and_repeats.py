"""Checks 1-2 and 4: linearity identity; unbiasedness of V under dependent repeats;
bias of d^2 and gamma-hat under repeat dependence (caching) and weak owner signal."""
import numpy as np

rng = np.random.default_rng(1)
PAIRS = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]


def cw_direct(x, yb):
    """x: (T,4) scores; yb: (T,4) repeat means. Eq. (1) of the paper."""
    num = den = 0.0
    for i, j in PAIRS:
        dx = x[:, i] - x[:, j]
        dy = yb[:, i] - yb[:, j]
        w = np.abs(dy)
        kap = np.where(np.abs(dx) <= 1e-12, 0.5, np.where(dx * dy > 0, 1.0, 0.0))
        num += (w * kap).sum()
        den += w.sum()
    return num / den


def sgn_tol(d):
    return np.where(np.abs(d) <= 1e-12, 0.0, np.sign(d))


def V_W(x, yb):
    V = np.zeros(x.shape[0]); W = np.zeros(x.shape[0])
    for i, j in PAIRS:
        V += sgn_tol(x[:, i] - x[:, j]) * (yb[:, i] - yb[:, j])
        W += np.abs(yb[:, i] - yb[:, j])
    return V, W


# ---- Check 1: identity, with many score ties and outcome ties
worst = 0
for _ in range(2000):
    T = 30
    x = rng.integers(0, 3, size=(T, 4)).astype(float)  # heavy ties
    yb = rng.integers(0, 3, size=(T, 4)) / 2.0
    V, W = V_W(x, yb)
    if W.sum() == 0:
        continue
    worst = max(worst, abs(cw_direct(x, yb) - (0.5 + V.sum() / (2 * W.sum()))))
print(f"[1] identity Cw = 1/2 + sumV/(2 sumW): max abs error over 2000 random tables with ties = {worst:.2e}")


# ---- World generator: linear-probability world where the law holds exactly
def world(T, sd_u=0.12, sd_item_frac=0.5, gamma=0.6, sd_v=0.06, sd_xnoise=0.05, B=300):
    items = rng.integers(0, B, size=(T, 4))
    for t in range(T):  # distinct candidates
        while len(set(items[t])) < 4:
            items[t] = rng.integers(0, B, size=4)
    b = rng.normal(0, sd_u * np.sqrt(sd_item_frac), B)          # item-level usefulness (owner)
    e = rng.normal(0, sd_u * np.sqrt(1 - sd_item_frac), (T, 4))  # task-specific usefulness
    lvl_s = rng.uniform(0.35, 0.75, T)[:, None]
    lvl_t = rng.uniform(0.35, 0.75, T)[:, None]
    u = b[items] + e
    v = rng.normal(0, sd_v, (T, 4))
    mu_s = np.clip(lvl_s + u, 0.01, 0.99)
    mu_t = np.clip(lvl_t + gamma * u + v, 0.01, 0.99)
    x = (b + rng.normal(0, sd_xnoise, B))[items]                 # score tracks item effect only
    return mu_s, mu_t, x


def draw(mu, nrep=2, cache=0.0):
    y = (rng.random(mu.shape + (nrep,)) < mu[..., None]).astype(float)
    if cache > 0:  # repeat r>1 is a copy of repeat 1 with prob cache (provider-side caching)
        c = rng.random(mu.shape + (nrep - 1,)) < cache
        y[..., 1:] = np.where(c, y[..., :1], y[..., 1:])
    return y


def dhat2(y):
    """unbiased square of pair differences from n=2 repeats (U = y1*y2)."""
    yb = y.mean(-1)
    n = y.shape[-1]
    U = yb ** 2 - y.var(-1, ddof=1) / n
    out = []
    for i, j in PAIRS:
        out.append(U[:, i] + U[:, j] - 2 * yb[:, i] * yb[:, j])
    return np.stack(out, 1)


def diffs(a):
    return np.stack([a[:, i] - a[:, j] for i, j in PAIRS], 1)


def law_pieces(mu_s, mu_t, x, cache_s=0.0):
    ys = draw(mu_s, 2, cache_s); yt = draw(mu_t, 2)
    ybs, ybt = ys.mean(-1), yt.mean(-1)
    S, Tt = diffs(ybs), diffs(ybt)
    a = sgn_tol(diffs(x))
    g_hat = (S * Tt).sum() / dhat2(ys).sum()
    Vh, Vs = (a * S).sum(), (a * Tt).sum()
    Wh, Ws = np.abs(S).sum(), np.abs(Tt).sum()
    C_swap = 0.5 + Vs / (2 * Ws)
    pred = 0.5 + g_hat * Vh / (2 * Ws)
    return dict(g_hat=g_hat, RV=Vs / Vh, gap=C_swap - pred, C_swap=C_swap, C_home=0.5 + Vh / (2 * Wh))


# population gamma for the linear world
mu_s, mu_t, x = world(200000)
ds, dt = diffs(mu_s), diffs(mu_t)
g_pop = (ds * dt).sum() / (ds ** 2).sum()
a = sgn_tol(diffs(x))
L = (a * dt).mean() - g_pop * (a * ds).mean()
print(f"[2] linear world: population gamma={g_pop:.3f}, population L={L:.2e} (law holds), "
      f"E delta_s^2={np.mean(ds**2):.4f}, mean noise var of 2-rep diff={np.mean(diffs(mu_s*(1-mu_s))*0+ (mu_s*(1-mu_s))[:, [0,0,0,1,1,2]].mean() ):.3f}")

# ---- Check 2: V unbiased under caching; gamma-hat and the law gap biased
for cache in [0.0, 0.3, 0.6]:
    res = [law_pieces(*world(2400), cache_s=cache) for _ in range(150)]
    g = np.array([r['g_hat'] for r in res]); gap = np.array([r['gap'] for r in res]); RV = np.array([r['RV'] for r in res])
    print(f"[2] owner repeat caching={cache:.1f}: mean gamma_hat={g.mean():.3f} (true {g_pop:.3f}); "
          f"mean R_V={RV.mean():.3f}; mean law gap in Cw={gap.mean():+.4f} (sd {gap.std():.4f})")

# unbiasedness of V under caching: compare E V_home with V* computed from mu
mu_s, mu_t, x = world(2400)
a = sgn_tol(diffs(x)); Vstar = (a * diffs(mu_s)).sum()
Vs = [(a * diffs(draw(mu_s, 2, 0.6).mean(-1))).sum() for _ in range(400)]
print(f"[2] E V_home under caching 0.6: {np.mean(Vs):.2f} +- {np.std(Vs)/20:.2f}  vs V* = {Vstar:.2f} (unbiased, as claimed)")

# ---- Check 4: weak owner signal: distribution of gamma-hat at dry-run and main sizes
print("[4] weak signal: sd_u = total sd of usefulness per item (owner); reliability of a 2-repeat pair difference")
for sd_u in [0.05, 0.08, 0.12]:
    for T in [112, 400, 2400]:
        mu_s, mu_t, x = world(100000, sd_u=sd_u)
        ds, dt = diffs(mu_s), diffs(mu_t)
        gp = (ds * dt).sum() / (ds ** 2).sum()
        nv = (mu_s * (1 - mu_s))
        noise = np.mean(np.stack([(nv[:, i] + nv[:, j]) / 2 for i, j in PAIRS], 1))
        rel = np.mean(ds ** 2) / (np.mean(ds ** 2) + noise)
        gs, den_neg, keep4 = [], 0, []
        for _ in range(400):
            ms, mt, xx = world(T, sd_u=sd_u)
            ys = draw(ms, 2); yt = draw(mt, 2)
            S, Tt = diffs(ys.mean(-1)), diffs(yt.mean(-1))
            D = dhat2(ys)
            den = D.sum(); num = (S * Tt).sum()
            # task-bootstrap SE of the denominator (the paper's definedness rule)
            Dt = D.sum(1)
            se = Dt.std(ddof=1) * np.sqrt(T)
            if den <= 0:
                den_neg += 1
                continue
            gs.append(num / den)
            if den >= 4 * se:
                keep4.append(num / den)
        gs = np.array(gs); keep4 = np.array(keep4)
        print(f"    sd_u={sd_u:.2f} rel={rel:.3f} T={T:5d}: gamma={gp:.3f}; P(den<=0)={den_neg/400:.3f}; "
              f"median g_hat={np.median(gs):.3f}; IQR=({np.percentile(gs,25):.2f},{np.percentile(gs,75):.2f}); "
              f"defined by 4-SE rule {len(keep4)/400:.2f}, mean|defined={keep4.mean() if len(keep4) else float('nan'):.3f}")
