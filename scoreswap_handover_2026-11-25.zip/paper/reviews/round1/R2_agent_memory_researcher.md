# Review R2: agent memory and skill libraries

**Submission:** "Do Memory Scores Survive a Model Swap? A Benchmark of Keep, Wipe and Recalibrate Rules for Agent Memory" (ScoreSwap)
**Track:** Datasets, Evaluations and Benchmarks
**Reviewer expertise:** LLM agents with memory and skill libraries (MemRL, RoMeRL, ACE, ExpeL, ReasoningBank, Dynamic Cheatsheet, CHIME, EvoKernel, HEIRS, StreamBench, LifelongAgentBench, MemoryAgentBench, LongMemEval, and the 2026 work on moving memory between models).
**What I read:** main.tex, every file in sections/, the tables and macros in assets/, and all figures in assets/*.png. I also read prediction/PREREGISTRATION.md as supplementary material. Every number in the draft comes from a watermarked simulation, so I judge the question, design, claims and writing as they stand, and say separately how the paper would fare under three outcomes for the real data: the dry-run pattern, weak effects, and null effects.

---

## 1. Summary

The paper asks a narrow, well-posed question. An agent memory keeps a learned usefulness score per item (a MemRL-style moving average of rewards, ACE-style helpful/harmful counters, EvolveR-style success counts, MemCredit-style with-minus-without credit). If the memory content is frozen and the scores are carried to a new language model, do the scores still rank the items correctly for that model?

To answer it, each of eight models (four old→new pairs from Anthropic, OpenAI, Qwen and Google) builds a bank in two phases on DDXPlus and BIRD (from StreamBench):
- a write phase, in which 250 unlabelled (task, own answer) items are stored;
- a score phase, in which 500 tasks are run three times, one retrieved item is shown each time, and five score families are updated.

A full-information "probe table" then records, for every owner→reader cell (56 swaps plus 8 home cells), the program-graded result of the reader on 500 probe tasks with each of the 4 most relevant candidates shown alone (two repeats), plus a no-memory baseline.

The headline measure is a within-task, outcome-weighted concordance C_w (a stratified Harrell's C). Retained validity is R = (C_swap − ½)/(C_home − ½), and the self-swap gives a noise floor. On top of this the paper adds:
1. a "law of score transfer", a decomposition C_swap − ½ ≈ γ (W_home/W_swap)(C_home − ½) whose slope γ is estimated without the scores;
2. a comparison of about 18 swap-day rules (keep, wipe, fixed discount, power prior, recalibration, re-test, audit, pooled, fresh) on first-shown success and log score;
3. an anytime-valid "stop-when-sure" keep/drop check;
4. a pre-registered, memory-free forecast from error consistency;
5. four pre-registered predictions;
6. a post-swap online run;
7. a Shapley realism check on item subsets;
8. an "outside check" on the released per-skill gains of Beyond Gain.

All confirmatory tests are pre-registered with Holm control over 12 primary tests.

---

## 2. Strengths

- **S1. A cleanly isolated quantity.** Prior cross-model memory work (MemRL App. C.1, CHIME Table 6, EvoKernel, RoMeRL, MemCollab, Memory Transfer Learning, Goyal & Ray) reports end-task success. End-task success mixes what the content is worth with the order the scores impose. Holding content and candidates fixed and asking only about rank validity is a real conceptual contribution. The `shuffled` arm (content-only control) and `wipe` (relevance-only) make the split explicit. I searched arXiv through November 2026 and found no paper that measures item-level rank validity of carried memory scores with content frozen (see §7 for near misses).
- **S2. A full-information probe table is a good benchmark primitive.** Every candidate is graded alone with repeats, so any rule that re-ranks the logged candidates can be scored offline with no model calls. This is the right design for comparing swap-day rules cheaply and reproducibly, and the open-weight half keeps the core re-runnable after the closed models retire.
- **S3. Statistical care well above the norm for this subfield.** The paper has:
  - a frozen pre-registration with a deviations log;
  - a self-swap noise floor;
  - a non-inferiority margin tied to the home signal;
  - a paired task bootstrap with orders as strata;
  - two-way (task × item) variance for the law's gap;
  - exact permutation tests for model-level predictions;
  - honest statements that the forecast is likely underpowered.

  The "a failed drop test is never reported as no drop" rule is welcome.
- **S4. The decomposition is useful as an explanation.** Proposition 2 and the "direction of failure" result separate three things that are usually conflated: transfer of usefulness (γ), reader noise (the W ratio), and owner-specific leakage (L). The observation that R is confounded by reader noise while R_V is not is a genuinely useful methodological point for anyone who reports transfer ratios.
- **S5. The outside check on Beyond Gain is a real, cheap, informative pilot.** It is honest about its limits: one judge, one task per skill, mostly one maker.
- **S6. Transparent, honest scoping.** This shows in the "What we do not claim" paragraph, in tracing each rule to its classical origin (power prior, discounted UCB, Steyerberg recalibration), and in a limitations section that names the right threats.

---

## 3. Weaknesses (most serious first)

### W1. The confirmatory setting is in-context exemplar selection, not the agent memory the paper motivates

**What the setting is.** The memory item is an unlabelled (task, model answer) pair. The tasks are single-call (diagnosis label, SQL query). The reader sees exactly one item, chosen from the top 4 by embedding similarity. Scores come from an artificial build: 1,500 shows over 250 items, about 6 shows per item on average, selection-biased, with ε = 0.3 exploration and the 0.5/0.5 mix. This is the StreamBench "shot" baseline, essentially retrieval-based few-shot exemplar selection.

**What the cited systems do.** The systems the paper cites store something different and use it differently:
- ExpeL, ReasoningBank and Dynamic Cheatsheet store distilled insights or strategies.
- ACE keeps a whole playbook of bullets in context.
- MemRL retrieves top-k2 experiences after a z-normalised similarity/Q mix, in multi-step agent tasks (ALFWorld, LifelongAgentBench, BigCodeBench, HLE).
- Skill libraries (HEIRS, Beyond Gain, SkillsBench) store procedures.

**Why it matters.** Usefulness of a raw exemplar is dominated by two model-agnostic facts: whether the owner's stored answer is right, and whether the probe is a near-duplicate. The limitations section concedes that neighbouring DDXPlus/BIRD tasks share answers. These facts plausibly drive both R and the keep-vs-wipe gaps, so the results may not carry to insight- or skill-style memories. The study's own most realistic setting, LifelongAgentBench on MemRL's released code, sits outside the pre-registration (Part 8.3.8, "legs outside this registration") and appears in Setup only as `\TODO{state which legs ran}`. Thinking is off on every model, and every model is a small or cheap tier, while deployed agent stacks increasingly run reasoning modes.

**Action.**
- Make one agentic leg with a real scored-memory system confirmatory, at least for the four upgrade pairs and a handful of cross-maker pairs: MemRL on LifelongAgentBench or ALFWorld with its own top-k2 and z-normalised mix, or ACE on AppWorld with counters visible.
- Promote the labelled ("memprompt") item style from exploratory to at least secondary.
- Use the subset (Shapley) runs to report how C_w changes when 2–4 items are shown together, not only single-item vs Shapley agreement on upgrades.

### W2. The practical stakes are never shown, and the scope of "scored memory" is overstated

**Stakes.** R is a ratio of concordances; a practitioner needs success points. In the dry run, by construction:
- keep − wipe on first-shown success is 1.5 points (not significant) for cross-maker swaps, the stratum where R collapses to about 0.2;
- in the online run, wipe matches or beats keep (0.676 vs 0.660).

If real data look like this, the paper's own numbers would say that score order barely matters next to relevance, so the swap-day question is second-order. That would undercut the motivation. The paper needs, in the main text, a stakes table per stratum: keep − shuffled, keep − wipe, keep − relevance, own − keep and oracle − keep, in success points. It should also make recovery time in the online run (τ95, S_100) a headline practitioner metric. Scores that re-converge in 30 tasks make swap-day rules nearly moot.

**Scope.** The abstract opens with "Agent memories keep a usefulness score for every stored item". That is not true of most deployed or widely used memory systems: Mem0, Letta/MemGPT, ChatGPT and Claude memory, ExpeL, ReasoningBank, Dynamic Cheatsheet and LangMem keep no learned per-item utility. Scored memory is a growing research niche (MemRL, RoMeRL, EvoKernel, CHIME, MemCredit, EvolveR, MemQ, BEAM). Say so, and size the population the result applies to.

### W3. The "law of score transfer" is a decomposition, presented as a parameter-free prediction

The estimate γ̂ = ΣΔȳ^sΔȳ^t / Σd̂²_s uses the reader's probe outcomes on the owner's candidates on the same evaluation tasks. Those are the same data from which C_swap is computed. Consequences:
- The "prediction" cannot be made before the swap, and it saves nothing on swap day. Estimating γ costs at least as much as measuring C_swap directly.
- "No fitted parameter" is technically true but rhetorically misleading. γ̂ is a moment estimator on the reader data, not an out-of-sample forecast. Under L = 0 the identity is close to tautological.
- The scientifically interesting content is the leakage test (L ≠ 0: the scores encode owner-specific quirks beyond the owner's usefulness). That deserves to be the claim.
- Calling it a "law" invites scrutiny it cannot carry with eight models.

There is also an internal inconsistency. Proposition 2 shows that R moves with the reader's noise even when transfer is unchanged. Yet R, not R_V or the noise-adjusted R, is the headline in the abstract, Figure 1, PC1 and P1–P4. Figure 1's own diagonal (self-swap R of 0.80, 1.11, 1.21, 1.14) shows how noisy R is.

**Action.**
- Rename the result (for example "transfer decomposition").
- Make R_V or a noise-adjusted R the headline.
- State that estimating γ needs the reader's probe.
- Add a genuinely out-of-sample version: estimate γ̂ on the 100 calibration tasks only, predict C_swap on the 400 evaluation tasks, and report the error as a function of the number of calibration tasks. That would turn the law into a swap-day tool and connect it to the check.

### W4. The calibration comparisons (PC3, PC4) mostly test home miscalibration, not the swap

In the dry run, keep's log score (−0.743 on upgrades) is worse than the constant 0.5 that wipe produces (−0.693). An EMA with α = 0.3 started at 0.5, after a handful of selection-biased shows, is not a calibrated probability, and MemRL never uses Q as one. Shrinking toward 0.5 (fixed_0.5) or refitting a level (recal_k) would therefore "win" at home as well. As designed, PC3 and PC4 cannot separate "the swap broke calibration" from "EMA scores were never probabilities".

**Action.** Report every arm's metric on the home self-swap cells (the C_fresh repeats) and test the swap-minus-home difference. Alternatively, drop log score as a primary endpoint for `ema_grade` and keep it for `beta_grade`, whose output is a posterior mean.

### W5. Faithfulness of the score families is mixed

The `ema_grade` and `beta_grade` families are faithful; `tags_self` and `credit` are adequate only with stronger caveats, and the retrieval mix needs a sensitivity analysis:

- **`ema_grade` vs MemRL: faithful.** MemRL's Table 8 gives α = 0.3 and Q_init = 0 with r ∈ [−1, 1]. The affine-map argument (Proposition 3) correctly shows rank equivalence with the [0, 1] version.
- **`beta_grade` vs EvolveR: faithful.**
- **`tags_self` vs ACE: acceptable only with a caveat in the abstract.** In ACE the Generator marks bullets helpful or misleading. The counters live in a playbook the model reads largely whole, and ACE does not rank and show one bullet by counter. Ranking top-1 by the smoothed tag share is therefore the authors' operationalisation, as stated. It is acceptable as a measurement of "does a self-tag signal transfer", but P3 then tests a use ACE does not make. Say so in the abstract or introduction, not only in Limitations. A probe that shows the playbook with counters to the reader would test what ACE actually does.
- **`credit` vs MemCredit: acceptable if labelled.** MemCredit estimates a "state-, reference-context- and policy-conditional marginal contribution" by controlled interventions and distils it into a utility estimator. A raw mean of (with − without) over a single no-memory run is a simplified analogue; call it "MemCredit-style". Note that MemCredit's credit is explicitly policy-conditional, so a drop under a swap is expected by its own definition.
- **The mix: needs sensitivity analysis.** MemRL z-normalises both similarity and Q before mixing. Here raw cosine (bge values are compressed into a narrow band) is mixed with a [0, 1] score. The effective weight on the score therefore depends on scale, and every first-shown-success comparison depends on it. The z-normalised mix is only exploratory (Prereg 8.3.1); it should be a secondary analysis reported beside the headline.

### W6. The swap-day check's headline comparison is mis-stated

In the dry run:
- keeping needs a median of 563 tasks (about 2,250 reader calls), and dropping needs 629;
- only 0.2% of streams decide within the 100-task calibration pool;
- the fixed `audit_64` rule keeps scores whose true retained share is below 0.75 in 58% of replays.

The abstract turns this into "a median of N fresh-check tasks, against 8 to 64 checks for fixed rules". That compares tasks with checks (one task is 4 checks) and implies the fixed rules make the same decision more cheaply, when in fact their error is uncontrolled. The honest finding is more interesting: a keep/drop decision with controlled error is out of reach at any budget a practitioner would spend, and cheap audits are close to coin flips. Treating the home signal Ā_home as known also ignores its estimation error; propagate it or bound its effect.

### W7. Too many contributions for eight pages

The main text carries:
- the benchmark, about 18 rules, and 12 primary tests;
- the law with three propositions;
- the anytime-valid check and the forecast;
- the predictions P1–P4, the online run and the Shapley realism check;
- the outside check.

Several of these are pre-declared as likely null. With eight models the forecast has 28 unordered pairs, and P1, P2 and P4 rest on eight model labels; in the dry run they were "not testable". The result is that the main text has no room for the things a D&B reader needs: per-pair heterogeneity (the forest plot is in the appendix), the stakes in W2, the data format and interface in W9, and the share of informative pairs and score ties. Move the forecast and P1–P4 to the appendix and spend the space on W2 and W9.

### W8. The scope of inference does not match the headline phrasing

Each same-maker stratum has 4 pairs, one per maker, and they are heterogeneous:
- Haiku 4.5 → 5.5 is a generation jump;
- Gemma 3 27B → Gemma 4 31B changes architecture and size;
- Qwen 3.5 → 3.8 keeps the same size.

Intervals resample tasks only, so "after same-maker upgrades, old scores keep R = …" describes these four pairs, not upgrades in general. The Limitations section says this; the abstract does not.

Statistical details to justify:
- PC1 enters Holm with min(p_drop, p_NI). That puts two one-sided hypotheses in one slot, so state why familywise error is still controlled.
- The extra rule that a drop also needs a point estimate above U_self is an ad hoc second criterion with unclear operating characteristics.

### W9. The benchmark lacks an adoption path

**Missing pieces.** For a D&B paper, the benchmark is under-specified:
- **No defined interface for a rule.** What are the inputs: the owner's full score histories, visit logs, selection propensities, the item text, k fresh checks? What is the output: one score per item?
- **No canonical metric or leaderboard.** There is no hidden test split, and nothing says how a new rule's entry would be validated.
- **"An adapter for outside memory systems" is not described.**
- **The release is still TODO.** The datasheet, licences (BIRD is listed as CC BY-SA vs CC BY-NC, unresolved), Croissant metadata and the checklist are all marked TODO.

**Overstated reach.** The offline tables cover only rules that re-rank the same 4 logged candidates and show one item. Different content, different retrieval, multi-item context, or rules that need fresh calls on new items cannot be scored offline, so "any new rule" (abstract, contributions) overclaims.

**Adoption.** The likely users are authors of scored-memory systems who want to justify a swap-day default. Give them a 20-line "evaluate your rule" example and a fixed results table they can append to.

### W10. Positioning against the closest work rests partly on abstracts, and the introduction's evidence does not match its argument

**Abstracts only.** Table 6 (App. C) says its OpenReview rows "rest on their abstracts and author responses". Those rows (Beyond Semantic Relevance, HEIRS, judge replacement) are exactly the works that decide the novelty margin. Beyond Semantic Relevance reportedly compares own, pooled and donor execution credit under a calibration budget, which is very close to keep/pooled/fresh with k checks, judged on end-task F1. They must be read in full. Two appendix rows (Policy-Response Drift; Harmless Here, Harmful There) appear only in the table, not in Related Work, and I could not locate them publicly.

**Introduction evidence.** The introduction argues that end-task success mixes content and order, then uses CHIME's cross-model cell (moved memory +0.78 vs own memory +6.24) as evidence that "the order does not always carry over". The two memories in that comparison differ in content as well as scores, so the cell says nothing about order. (I verified the numbers: 30.04 / 30.82 / 36.28 in CHIME Table 6.)

The Beyond Gain figure ("Spearman only 0.40") is quoted without the noise ceiling the authors themselves compute in App. D. There, split-half Spearman is 0.30–0.64 and the noise-matched ratio for some pairs cannot be told apart from 1. Quote the noise-matched ratio, or both.

### W11. Presentation

- "Family" means two things: score families and model makers. Tables and figures say "Same-family upgrades" and "Cross-family", while the text says "same-maker" and "cross-maker".
- The forecast figure labels its target T = N_swap/N_home; the text calls it θ = Ā_swap/Ā_home.
- Figure 1's legend explains hatched cells, but none are hatched. The "noise floor" diagonal shows R values above 1 without comment.
- The `oracle` arm is cross-fitted on two repeats and falls below `keep` (0.658 vs 0.703 on upgrades). It is not a ceiling and should be relabelled (the prereg already says "not an upper bound") or rebuilt from the four home repeats.
- `\TODO` markers remain in the main text: Setup, figure captions and the AI statement.
- The plain-language register ("maker", "keep/wipe", the garage) reads well, but it sometimes costs precision. "Validity" is used for a concordance, and the abstract's numbers mix units.

---

## 4. Questions for the authors

1. What share of within-task candidate pairs is informative (|Δȳ| > 0) at home, and what share is tied in score (q still at 0.5, or equal counts)? How many owners clear the 4-SE rule for R, per stream?
2. What fraction of probe tasks has a candidate whose stored answer is exactly the gold answer, or a near-duplicate? Does R change when those tasks are excluded?
3. Can γ be estimated from calibration tasks only, and how well does the law then predict C_swap on evaluation tasks, as a function of the number of calibration tasks?
4. What are keep's and fixed_0.5's log scores at home (self-swap)? Is the PC3 effect present without any swap?
5. How large is keep − shuffled in success points per stratum? It is the cleanest estimate of what score order is worth.
6. How do results change with MemRL's z-normalised mix and with top-2 or top-3 items shown (from the subset runs)?
7. Which legs ran (LifelongAgentBench on MemRL code, AppWorld)? Will any of them be confirmatory?
8. Why is the stop-when-sure check calibrated on tasks with all 4 candidates checked, rather than adaptively choosing which (task, candidate) cell to check? Would an active design cut the 500+ task requirement?
9. PC1 takes min(p_drop, p_NI) into one Holm slot. Under which null is the familywise error controlled?
10. What exactly is the "adapter for outside memory systems", and what is the rule interface for offline submission?
11. Is there a reason to expect results under thinking-off to carry to reasoning modes, which most deployed agents now use?

---

## 5. Scores (if the real study shows the same qualitative pattern as the dry run)

| Criterion | Score | One-line reason |
|---|---|---|
| Soundness | 3 / 4 | Pre-registered, paired, noise-floored and carefully powered. But PC3/PC4 lack home references, the headline R is noise-confounded by the authors' own proposition, and the "law" is mis-framed as a prediction. |
| Presentation | 2 / 4 | Readable sentence by sentence, but overloaded with contributions. Terminology clashes (family/maker), units are mixed (tasks vs checks), TODOs remain, and the stakes and interface are missing from the main text. |
| Significance | 2 / 4 | The setting is exemplar selection on single-call tasks with one item shown, and there is no evidence yet that score order moves success by more than a few points. Few deployed memories keep per-item scores. |
| Originality | 3 / 4 | Item-level rank validity with content frozen is a new target, and the probe table is a new resource. Every method is borrowed, and near neighbours (Beyond Semantic Relevance, judge replacement, HEIRS, Beyond Gain) narrow the margin. |
| **Overall** | **3 / 6 (weak reject)** | A careful measurement of a real but narrow quantity in a setting that is not yet the one the paper motivates. It could reach 4–5 with W1–W3 fixed. |
| Confidence | 4 / 5 | I know the memory/skill literature well and checked the key cited works. I could not open the OpenReview submissions. |

**How Overall moves with the real results:**
- **Same pattern as the dry run** (cross-maker R ≈ 0.2 with a material drop; upgrades inconclusive; keep − wipe small across makers; law MAE well below "no change"; check needs about 500+ tasks; forecast null): **3**, or **4** if W1–W4 are fixed. The pattern is interesting ("cross-maker swaps erase most score signal, but relevance carries the decision, and no cheap check can tell you which case you are in"), but the stakes must be shown.
- **Weak effects** (R between 0.6 and 1 everywhere with wide intervals; keep ≈ wipe on success; PC1 inconclusive in most strata): **2–3**. The message becomes "carried scores lose a little and it hardly matters", which is a useful sanity result but thin for a main-track D&B paper unless the agentic leg shows larger stakes.
- **Null effects**, two distinct cases:
  - **(a) A strong home signal and non-inferiority shown in every stratum** ("keeping scores is safe"): **3**. It is a clean, actionable negative result, still narrow.
  - **(b) A home signal too weak to define R for many owners** (scores barely rank items even under their own model): **1–2**. The benchmark would then measure nothing, and the paper would have to become "per-item scores in this setting carry little signal at all", which is a different paper.

---

## 6. The single most likely reason for rejection, and the three changes that would raise my score most

**Most likely reason for rejection.** Reviewers will see a statistically careful study of in-context exemplar selection: unlabelled (task, answer) items, single-call tasks, one item shown, scores from an artificial two-phase build, thinking off. They will see it presented as a benchmark for agent memory, with no evidence that score order changes outcomes by more than a few points and no adoption path. Significance and realism, not rigour, will sink it.

**Three changes, ranked by impact per effort:**

1. **Reframe and cut (low effort, high impact).**
   - Make the paper about one thing: item-level score validity, the content-vs-order split, and what a controlled swap-day decision costs.
   - Rename the "law" as a decomposition, make R_V or noise-adjusted R the headline, and add the calibration-tasks-only out-of-sample version of the law.
   - Fix the tasks-vs-checks comparison in the abstract and state plainly that controlled decisions need hundreds of tasks.
   - Move the forecast and P1–P4 to the appendix.
   - Fix the family/maker terminology.
2. **Show the stakes and add home references (low-to-medium effort, high impact).**
   - Add a main-text table, per stratum, of keep − shuffled, keep − wipe, own − keep and oracle − keep in success points, plus online recovery time.
   - Apply every arm to the home self-swap so that PC3/PC4 test the swap, not EMA miscalibration.
   - Fix or relabel the oracle.
   - Specify the rule interface, file schema and a results table that outsiders can submit to.
3. **One confirmatory agentic leg with a real scored-memory system (high effort, highest realism gain).**
   - Run MemRL on LifelongAgentBench or ALFWorld with its native top-k2 and z-normalised mix, or ACE on AppWorld with counters, for the four upgrades and a subset of cross-maker pairs.
   - Promote the labelled item style to secondary.

---

## 7. Missing or mis-described related work

**Missing (the same question in neighbouring literatures: per-item value under model A used for model B):**
- **Rubin, Herzig & Berant, "Learning To Retrieve Prompts for In-Context Learning" (EPR), NAACL 2022.** https://arxiv.org/abs/2112.08633. Scores each candidate exemplar by an LM's likelihood of the gold output with that exemplar shown alone, which is the same probe design. It then uses the trained retriever with other inference LMs (GPT-J, GPT-3, Codex). It is in the authors' .bib but not cited.
- **Wang, Yang & Wei, "Learning to Retrieve In-Context Examples for LLMs" (LLM-R).** https://arxiv.org/abs/2307.07164. Trains an exemplar retriever from one LLM's feedback and evaluates it on LLMs of other sizes. In the .bib, not cited.
- **Nguyen & Wong, "In-context Example Selection with Influences".** https://arxiv.org/abs/2302.11042. Per-exemplar influence scores for ICL. In the .bib, not cited.
- **Chang & Jia, "Data Curation Alone Can Stabilize In-context Learning", ACL 2023.** https://aclanthology.org/2023.acl-long.452. Per-example usefulness scores for ICL demonstrations. In the .bib, not cited.
- **Khaddaj, Engstrom & Madry, "Small-to-Large Generalization: Training Data Influences Models Consistently Across Scale", ICLR 2025.** https://arxiv.org/abs/2505.16260. Measures whether per-datum influence and data selection under a small proxy transfer to a larger model. It is the data-attribution analogue of "do item scores survive a model change".
- **Coleman et al., "Selection via Proxy", ICLR 2020.** https://arxiv.org/abs/1906.11829. Rank agreement of per-example selection scores between proxy and target models.
- **Khraishi et al., "Evaluating Performance Drift from Model Switching in Multi-Turn LLM Systems", 2026.** https://arxiv.org/abs/2603.03111. A switch-matrix benchmark over ordered (prefix model → suffix model) pairs, with a per-model prefix/suffix decomposition that explains about 70% of drift variance. It is a direct precedent for the ordered-pair grid and the source-and-target summary.
- **Choi et al., "New Model, Old Habits: Behavior Transfer under Model Swapping in Multi-Session LLM Agents", 2026.** https://arxiv.org/abs/2610.19712. Recipient models adopt the source model's habits from inherited history; summarisation (DASH) reduces this. It is the closest "model swap in agents" study and is in the .bib, not cited.
- **Yu et al., "Skill is Not One-Size-Fits-All: Model-Aware Skill Alignment for LLM Agents" (MASA), 2026.** https://arxiv.org/abs/2605.30723. Shows that a skill helping one backbone can harm another, and adapts skills per backbone.
- **Belikova et al., "Managing Procedural Memory in LLM Agents" (AFTER), 2026.** https://arxiv.org/abs/2606.23127. Cross-backbone skill transfer: some skills generalise and others specialise and lose effect.
- **Zhang & Yang, "LLM-as-a-Judge Version Shift: The Instrument Changed, Not the Standard", 2026.** https://arxiv.org/abs/2610.32986. A pre-registered study of same-family judge transitions with a frozen-anchor audit; global recalibration fixes the mean but not object-level dispersion. It is the public analogue of the judge-replacement row and of the "recalibration fixes calibration, not discrimination" point.
- **"When the Judge Changes, So Does the Measurement", 2026.** https://arxiv.org/abs/2607.08535. Treats judge swaps as a measurement-validity problem.
- **Asadolahi et al., "Memory Reward Inflation in Self-Improving LLM Agents", 2026.** https://arxiv.org/abs/2608.00017. Self-graded memory scores overvalue wrong episodes (the "Echo Gap"). It is directly relevant to `tags_self` and prediction P3.
- **Wu, Ding & Huang, "ERRAND: Budgeted Maintenance of Agent Memory", NeurIPS 2026.** https://arxiv.org/abs/2609.29545. Prices memory revalidation against task actions under drift, with pre-registered calibers. It is relevant to framing swap-day checks as a budget decision (drift of the world, not of the model).
- **Akgül et al., "When Agent Skills Go Stale", 2026.** https://arxiv.org/abs/2611.22525. Selective maintenance of skill state after environment change. In the .bib, not cited.
- **Echterhoff et al., "MUSCLE: A Model Update Strategy for Compatible LLM Evolution", 2024.** https://arxiv.org/abs/2407.09435. Negative flips under LLM upgrades. Yan et al. (PCT, https://arxiv.org/abs/2011.09161) and Shen et al. (BCT, https://arxiv.org/abs/2003.11942) cover regression-free and backward-compatible model updates. This is the established "model update compatibility" literature the upgrade/downgrade framing should connect to. MUSCLE and PCT are in the .bib, not cited.
- **Cross-backbone skill transfer at end-task level**, which strengthens the claim that end-task transfer is well covered:
  - SkillsBench: https://arxiv.org/abs/2602.12670
  - SKILL-DISCO: https://arxiv.org/abs/2606.26669
  - SkillAdam: https://arxiv.org/abs/2609.08944
  - Learner2Skill, "lightweight executor calibration" when moving skills to a new LLM: https://arxiv.org/abs/2609.37157

**Mis-described or under-described:**
- **CHIME (https://arxiv.org/abs/2609.02074).** The numbers are correct. But CHIME keeps a per-item value v_i ∈ [−1, 1] plus a reuse count, and its authors conclude that "attributed memory encodes reusable guidance rather than backbone-specific patterns". Using one cell as evidence about order is not supported, because content differs between moved and own memory. Table 6 marks CHIME's "moves per-item scores" as "?". CHIME does move value-annotated items, so the cell should be ✓ or ◦.
- **MemRL (https://arxiv.org/abs/2601.03192).** The quote is from App. E.4 and the transfer is App. C.1, from Gemini-3-pro to three weaker models on HLE. The gains (+0.22 to +0.38) mainly show a strong teacher's content helping weaker readers. The paper says end-task mixes content and order, which is fair. MemRL's α = 0.3 and Q_init = 0 (Table 8) match the paper's description.
- **MemCredit (https://arxiv.org/abs/2611.15600).** The credit is a distilled, "policy-conditional" counterfactual estimate, not a raw with-minus-without mean. Label the family "MemCredit-style" and note that policy-conditioning predicts a drop by design.
- **ACE (https://arxiv.org/abs/2510.04618).** The counters are marked by the Generator during use, and the paper does not specify them as a retrieval ranking signal. The "our operationalisation" disclaimer is honest but belongs in the abstract or introduction.
- **Beyond Gain (https://arxiv.org/abs/2610.32322).** It already states that verdicts "vary by model, so hubs should interpret them per model", and it uses one model's gain to validate another model's unaided score. Item-level cross-model use of skill scores is therefore not untouched. Scope "no study has tested this item by item" to learned memory scores.
- **Goyal & Ray (https://arxiv.org/abs/2609.05339).** Described fairly: memory fixed during the reader swap, per-history (not per-item) analysis, and a 20-probe screening check (App. C) validated against 140 held-out probes.
- **ZenML SwapBench (https://www.zenml.io/benchmarks/swapbench).** Fair. It covers 13 swaps behind two customer-service agents with no memory, compares cheaper checks against hidden-scenario truth, and has not released its scenario sets yet.
- **Unverifiable rows.** "Beyond Semantic Relevance", "HEIRS", "When Can Historical Scores Be Reused After Judge Replacement?", "Refreshing Agent Memory with Policy-Response Drift" and "Harmless Here, Harmful There" could not be opened: OpenReview blocks automated access, and I found no public copy of the last two. Since these decide the novelty margin, the authors must characterise them from full text.

---

## 8. Sentences I consider overclaims

1. Abstract: "Agent memories keep a usefulness score for every stored item." Most deployed and widely used memories keep none; only a subset of research systems do.
2. Abstract: "yet no study has tested this item by item." Beyond Gain (per-skill, per-model scores and cross-model use), EPR/LLM-R (per-exemplar LM scores used across inference LMs) and small-to-large data attribution all test item-level value across models. Scope it to learned agent-memory scores with content frozen.
3. Abstract: "we explain the result with a law of score transfer whose prediction has no fitted parameter". This is a decomposition whose slope is estimated from the reader's outcomes on the same tasks. "Explain" and "law" are too strong.
4. Abstract: "the law predicts the swap validity of each pair with a mean gap of …". It is not a prediction available before measuring the reader on the same probes.
5. Abstract: "A keep-or-drop decision with controlled error needs a median of N fresh-check tasks, against 8 to 64 checks for fixed rules". The units differ (tasks vs checks), and the fixed rules do not control error. The comparison implies a cost trade-off that does not exist.
6. Abstract: "we release frozen probe tables that score any new rule offline with no model calls". Only rules that re-rank the logged 4 candidates and show one item can be scored.
7. Introduction contributions: "Because the table holds the result of every choice, any score rule, including rules proposed later, is scored offline". Same issue: "every single-item choice among the logged candidates".
8. Introduction: "Published numbers suggest the order does not always carry over. In CHIME's cross-model table …". The CHIME comparison changes content too, so it cannot speak to order.
9. Introduction: "… rank 1,165 skills for its same-size successor with a Spearman correlation of only 0.40". "Only" implies a transfer loss, but App. D shows split-half reliabilities of 0.30–0.64, and some noise-matched ratios cannot be told apart from 1.
10. Introduction contributions: "Under one stated, testable assumption, validity after the swap is validity at home times a transfer slope …". The equation also carries the reader/owner noise ratio W_home/W_swap, so it is not "times a transfer slope" alone.
11. Introduction contributions: "the check measures how many fresh checks such a decision needs". It does so only under independent tasks and a known home signal, and in practice it shows the decision is out of reach.
12. Section 2: "In the work we found, none holds content fixed and asks whether carried per-item scores still rank items." This is acceptable only once the OpenReview neighbours have been read in full; the appendix says they were judged from abstracts.
13. Section 2 (origins): "… \bench{} supplies the measured answer." It is a measured answer for eight models, two single-call streams and one-item display, not "the" answer to how much old evidence is worth.
14. Section 3.2: "Since γ and W involve no score, a score's reliability cancels from R and R_V: under the law all families keep the same share". This is true only under L = 0 in the population. Finite-bank leakage (SD 0.10–0.12 in R_V for 80-item banks, App. E) makes the cancellation approximate.
15. Impact statement: "This work gives practitioners a way to check, before and after such a swap, whether the stored usefulness scores still point to the right items". The before-swap forecast is pre-declared as likely null, and the after-swap check needs hundreds of tasks.
16. Impact statement: "A likely benefit is fewer silent failures after a model swap, and less waste from rebuilding memories that would have survived." This is speculative, since the paper does not show that score order affects success materially.
17. Title and abstract framing: "A Benchmark of Keep, Wipe and Recalibrate Rules for Agent Memory". The confirmatory core measures exemplar-style items on single-call tasks. Either qualify it ("for scored exemplar memories") or add the agentic leg.
