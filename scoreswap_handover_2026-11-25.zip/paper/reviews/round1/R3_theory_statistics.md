# Review R3: theory and statistics

**Submission:** "Do Memory Scores Survive a Model Swap? A Benchmark of Keep, Wipe and Recalibrate Rules for Agent Memory" (ICML 2027, anonymous)
**Reviewer focus:** statistical learning theory and mathematical statistics: rank statistics, measurement error, transfer under shift, sequential and anytime-valid inference, and Bayesian borrowing.
**What I read:** `main.tex`, every file in `sections/`, `assets/numbers.tex`, the four `assets/table_*.tex` files, the figures in `assets/*.png`, and the pre-registration supplement (`prediction/PREREGISTRATION.md`, mainly Parts 2–5 and 11). I read no code and no other project file.
**About the numbers:** this version is a dry run. Every number comes from a simulation with made-up models, and is marked as such. I judge the theory, its assumptions, the estimators, the tests and the claims as written. I do not judge the simulated values, except where they show what the method does.

All my numerical checks are in `<scratch folder>`:
- `check_identity_and_repeats.py`
- `check_mediation_nonlinear.py` and `check_mediation_nonlinear2.py`
- `check_reliability_cancel.py`
- `check_sequential.py`
- `check_gauss_breakeven_qap.py`

They use numpy and scipy only.

---

## 1. Summary

The paper asks whether per-item usefulness scores that an agent memory earned under one LLM still rank the same items correctly for a different LLM. Its main measure is a weighted within-task concordance $C_w$: each candidate pair is weighted by $|\Delta\bar y|$, the gap between the reader's mean outcomes. The paper compares $C_w$ at home with $C_w$ after a swap, through the drop $D$ and the ratio $R=(C_{swap}-\tfrac12)/(C_{home}-\tfrac12)$.

The theory section (Sec. 3b, App. A8) makes five claims:
1. **Linearity identity (Prop. 1).** $C_w=\tfrac12+\sum V/(2\sum W)$, where the numerator $V$ is linear in the outcomes, so outcome noise affects $C_w$ only through the weights $W$.
2. **Transfer law (Prop. 2).** $E[\mathrm{sgn}(\Delta x)\delta^t]=\gamma\,E[\mathrm{sgn}(\Delta x)\delta^s]+L$. Under $L=0$, $C_{swap}-\tfrac12 \to \gamma\,(\bar W_{home}/\bar W_{swap})(C_{home}-\tfrac12)$. Here $\gamma$ is a score-free slope, estimated by a replicate-corrected errors-in-variables estimator.
3. **Invariance (Prop. 3).** Statements about monotone maps and about discounting counts.
4. **Two remarks.** A Gaussian corollary, and a Bühlmann-type break-even number of fresh checks.
5. **Two statistical additions (Sec. 3c).**
   - A pre-swap forecast of $\theta=\bar A_{swap}/\bar A_{home}$ from no-memory error consistency, validated by leaving one model out and tested by model-label permutation.
   - A "stop-when-sure" swap-day check. It applies two one-sided betting test martingales to the per-task statistic $A_\tau\in[-1,1]$, with thresholds $0.75\,\bar A_{home}$ and $0.25\,\bar A_{home}$.

The confirmatory analysis is four primary comparisons in three swap strata, under Holm's procedure.

**My overall reading.**
- The formal statements are almost all correct.
- Nearly all of them are classical results, relabelled as Propositions and as a "law".
- The verbal reading of the key assumption is wrong. I give a counter-example.
- The estimator of the transfer slope is fragile in exactly the conditions the paper warns about: dependent repeats and a weak owner signal.
- The swap-day check's error guarantee is stated under an assumption that never holds: a known home value. The headline comparison of its cost is misleading.
- The paper's own identity shows that its headline estimand, $R$ on $C_w$, is confounded by the reader's outcome noise. Yet $R$ stays the headline.

---

## 2. Statement-by-statement audit

**Classification codes:**
- **(a)** correct and non-trivial
- **(b)** correct, but classical or elementary, and should be presented as such
- **(c)** correct only under an assumption the paper does not state (I state it)
- **(d)** wrong (counter-example given)

### 2.1 The measure (Eq. 1) and its classical identity

**S1. Eq. (1); "with unit weights $C_w$ is the within-task Harrell's C, a stratified Somers' D".**
- The definition is fine.
- Two precision issues:
  1. "Unit weights" must mean unit weights on *informative* pairs ($\Delta\bar y\neq0$). With unit weights on all pairs, outcome-tied pairs would enter with $\kappa\in\{0,\tfrac12\}$. The pre-registration says this correctly; the paper does not.
  2. $C=(1+D)/2$, so $C$ is not "a Somers' D".
- The definition of $\kappa$ also leaves the order of precedence unclear when $0<|\Delta x|\le 10^{-12}$ and $\Delta x\,\Delta\bar y>0$. The sign convention in $V$ must use the same tolerance.
- **(b)**, plus wording fixes.

**S2. Prop. 1, part 1: $C_w=\tfrac12+\sum_\tau V(\tau)/(2\sum_\tau W(\tau))$ exactly.**
- The proof (three cases per pair) is correct.
- Numerical check: the maximum absolute error over 2,000 random tables with heavy ties in both $x$ and $\bar y$ is $1.1\times10^{-16}$.
- The identity is the pairwise form of $|b|\,\mathbf 1[\mathrm{sgn}\,a=\mathrm{sgn}\,b]=\tfrac12(|b|+\mathrm{sgn}(a)\,b)$.
- The rank form in A8 is exact: $V=\sum_i a_i\bar y_i$, and $W$ equals $V$ evaluated at $x=\bar y$.
- It follows that $2C_w-1=\sum_\tau \mathrm{cov}(\bar y,\mathrm{rank}\,x)/\sum_\tau\mathrm{cov}(\bar y,\mathrm{rank}\,\bar y)$. This is exactly the pooled within-task **Gini correlation** $\Gamma(\bar y,x)$ of Schechtman and Yitzhaki (1987), so $C_w=(1+\Gamma)/2$.
- That the Gini covariance is linear in $Y$ is a textbook property. So is the fact that it equals Pearson's $r$ under bivariate normality, which is the paper's "$C_w=(1+r)/2$" remark.
- A8 cites Schechtman–Yitzhaki only for "Gini-type". The main text should say plainly that $C_w$ is a re-expression of the Gini correlation.
- **(b).**

**S3. Prop. 1, part 2: $E[V(\tau)\mid\tau]=\sum_{i<j}\mathrm{sgn}(\Delta x_{ij})\,\delta^t_{ij}$ "for any number of repeats".**

I checked this against the three features of the sampling scheme the brief asked about.
- *Candidates chosen by relevance.* $K(\tau)$ is a fixed function of $\tau$ and the bank's embeddings. Conditioning on $(\tau,\text{bank})$ handles it.
- *Scores earned on-policy, with exploration.* $x$ is a function of the owner's score-phase outcomes on other tasks. Unbiasedness needs only that probe-call noise is mean-zero given $(\tau,\text{bank},x,\mu)$. That follows from (A1) plus independence between score-phase calls and probe calls (part of A2). Adaptivity changes what $x$ measures, not whether $V$ is unbiased.
- *Dependent repeats.* Because $V$ is linear, only first moments matter, so dependent repeats do **not** bias $V$. Numerical check: with 60% provider-side caching (repeat 2 copies repeat 1), $E V_{home}=1259.5\pm4.8$ against $V^*=1253.7$.

So the claim is right.

The gloss "outcome noise enters $C_w$ only through $W$" needs a qualifier: it holds for the first moment of the numerator only. Noise still drives the variance of $V$ and the finite-sample ratio bias.

The limit $C_w\to\tfrac12+EV^*/(2EW)$ also needs tasks i.i.d. *given the bank* and $EW>0$.

**(b)**, correct, with the qualifiers above.

**S4. Remarks in A8: "Ceiling" ($C_w\le \tfrac12+E|\delta|/(2E|\Delta\bar y|)$) and "Why weighted" (the unweighted numerator is not linear; the two versions coincide with one repeat).**
- Both are correct.
- $\sqrt{\text{mean }\hat d^2}$ is a biased (Jensen) and possibly undefined estimate of the second bound; this should be said.
- **(b).**

### 2.2 The transfer law

**S5. $\gamma=E[\delta^s\delta^t]/E[(\delta^s)^2]=\rho\,\mathrm{sd}(\delta^t)/\mathrm{sd}(\delta^s)$.**
- Correct, because the random orientation of pairs makes $E\delta=0$.
- $\gamma$ is a regression slope through the origin, is not symmetric in $s$ and $t$, and can exceed 1.
- **(b).**

**S6. Prop. 2, the "exact" decomposition $E[\mathrm{sgn}(\Delta x)\delta^t]=\gamma E[\mathrm{sgn}(\Delta x)\delta^s]+L$.**
- This is a tautology: $L$ is defined as the residual.
- The content lies entirely in the restriction $L=0$.
- **(b).**

**S7. What $L=0$ means, and the claim that it is "one stated, testable assumption".**

This is the most important theoretical point in my review. Write $a=\mathrm{sgn}(\Delta x)$ and $c=E[a\delta^s]/E[(\delta^s)^2]$. Then
$$L=E\big[\delta^t\,(a-c\,\delta^s)\big],$$
the covariance between the reader's usefulness differences and the part of the score sign that is linearly orthogonal to the owner's differences. Equivalently, $R_V=\sum aT/\sum aS$ is the instrumental-variable estimate of the slope of reader contrasts on owner contrasts, with the score sign as instrument. $\hat\gamma$ is the reliability-corrected least-squares estimate of the same slope. **$L=0$ says these two estimands coincide.** That makes the "law" a Durbin–Wu–Hausman-type specification test.

The "direction of failure" identity $R_V-\gamma=\sum_k(\gamma_k-\bar\gamma)(w_k-v_k)$ is the classical result that, under heterogeneous slopes, IV and OLS estimate differently weighted averages of the component slopes (Angrist and Imbens 1995; Angrist, Graddy and Imbens 2000). It should be cited as such. Its algebra is correct: $\sum w_k=\sum v_k=1$.

The paper glosses $L=0$ in three places:
- Sec. 3b: "the old scores carry no information about the reader beyond the owner's usefulness".
- Limitations: "The law rests on one assumption, that the scores carry nothing about the new model beyond the old model's usefulness".
- Pre-registration 11.2.1: "mediation".

That gloss is a conditional-independence statement, $x\perp\mu_t\mid\mu_s$. **It does not imply $L=0$.** The formal sufficient condition in Prop. 2, $E[\delta^t\mid\delta^s,x]=\gamma\delta^s$, adds two further requirements:
1. $\delta^t$ depends on the pair of owner levels $(\mu_s(\tau,i),\mu_s(\tau,j))$ only through their difference.
2. That dependence is linear.

Success probabilities live in $[0,1]$, and a stronger, weaker or sharper reader is naturally a non-linear function of the owner. So both requirements fail generically.

**Counter-example** (`check_mediation_nonlinear*.py`):
- Setup: owner $\mu_s=\mathrm{logit}^{-1}(\text{task}+b_i+e_{\tau i})$. Score $x_i=b_i+\text{noise}$, depending on the owner's item effect only. Reader $\mu_t=g(\mu_s)$, a deterministic monotone function, cell by cell. Mediation therefore holds in the strongest possible sense.
- Population values (400,000 tasks; reliable score, item effects dominant):

| Reader | $\gamma$ | $R_V$ | Law gap in $C_w$ | Equivalence margin |
|---|---|---|---|---|
| $g=\mathrm{logit}^{-1}(\mathrm{logit}\,p-2.5)$, a uniformly weaker reader (a downgrade) | 0.558 | 0.621 | **+0.031** | ±0.02 |
| Sharper reader ($3\times$logit) | — | — | **−0.023** | ±0.02 |
| Threshold-like reader | — | — | **−0.026** | ±0.02 |
| $g(p)=p^4$ | — | — | +0.024 | ±0.02 |
| Identity (control) | — | — | 0.000 | ±0.02 |

- With a noisier score or mixed item and task effects, the gaps are smaller, $|{\rm gap}|=0.002$–$0.019$.

Under the reading fixed in advance (pre-registration 11.2.4), a positive gap is read as "the old scores carry information about the new model beyond the owner's own results", and a negative one as "the owner's quirks". **Neither is true in these worlds.** There are no quirks and no extra information; there is only a non-linear map between two probability scales.

Classification:
- Prop. 2's formal statement: **(b)**.
- The claim that $L=0$ is the mediation assumption, and its use to interpret rejections: **(d)**.
- "One assumption": **(c)**. The prediction also needs (A1) and (A2), tasks i.i.d. given the bank, $E(\delta^s)^2>0$, and, for the estimated version, conditionally independent owner repeats (S12).

**S8. Eq. (3), $C_{swap}-\tfrac12\to\gamma(\bar W_{home}/\bar W_{swap})(C_{home}-\tfrac12)$.**
- Given $L=0$ and the conditions in S7, it follows from Prop. 1 applied to both cells, on the same pairs.
- The A8 sentence "equivalently $(V^*_{swap}/\mathrm{sd}\,\delta^t)/(V^*_{home}/\mathrm{sd}\,\delta^s)=\rho$" also holds only under $L=0$, not in general.
- **(c)**, as listed in S7.

**S9. "$R_V\to\gamma$ is free of outcome noise"; "a score's reliability cancels from $R$ and $R_V$: under the law all families keep the same share, and a family effect (P3) measures leakage".**
- Correct, given $L=0$ for every family.
- In my non-linear world (`check_reliability_cancel.py`), $R_V$ barely moved across score-noise levels (0.615, 0.625, 0.626). So the "reliability cancels" heuristic is fairly robust even when $L\neq0$, which is to the authors' credit.
- But "a family effect measures leakage" inherits the problem in S7: what leakage *means* is not identified.
- $R_V$ is a ratio with first stage $V_{home}$. Its finite-sample bias is of order $\mathrm{CV}(V_{home})^2$, about 6% at the 4-SE reportability floor, plus selection from the screen itself.
- **(c).**

**S10. "Finite banks" remark: with one bank, $L\neq0$ by chance, with sd 0.10–0.12 in $R_V$ at 80 items.**
- Plausible, and it is the right concern.
- It rests on the authors' simulations only. It also changes the estimand to a superpopulation of items, which clashes with how the rest of the paper does inference (W7).
- **(c).**

### 2.3 Estimators, identification and the test of the law

**S11. (ii) $U=\bar y^2-S^2/n$ is unbiased for $\mu^2$, and $\hat d^2=U_i+U_j-2\bar y_i\bar y_j$ for $\delta^2$.**
- Correct. For $n=2$ the estimator reduces to $U=y_1y_2$.
- This is classical unbiased estimation of a squared mean (a U-statistic).
- **(b).**

**S12. $\hat\gamma=\sum\Delta\bar y^s\Delta\bar y^t/\sum\hat d^2_s$ and $\hat\rho$ (Spearman's correction) are consistent.**
- This is the method-of-moments errors-in-variables estimator with replicate measurements (Fuller 1987, Ch. 1; Carroll et al. 2006, replication data). Consistency holds as the number of tasks grows, under (A2), when $E(\delta^s)^2>0$.
- **(b)** as stated.
- Three issues the paper does not discuss:
  1. **Repeat dependence biases $\hat\gamma$ badly, and the law test with it.** Unbiasedness of $\hat d^2$ needs the two owner repeats to be *conditionally independent within the cell*. That is exactly what provider-side caching or near-deterministic decoding breaks, and the paper names both risks under (A2). Within-task item differences have low reliability (in my calibrated world, $E\delta^2=0.029$ against a two-repeat noise variance of 0.22, so reliability is about 0.12). The bias term ${\rm cache}\times[\mu_i(1-\mu_i)+\mu_j(1-\mu_j)]$ in $\hat d^2$ therefore swamps the signal.
     - Numerical check (`check_identity_and_repeats.py`, 2,400 tasks, law exactly true, $L=-1\times10^{-4}$):

       | Caching rate | Mean $\hat\gamma$ (true 0.600) | Law gap in $C_w$ |
       |---|---|---|
       | 0 | 0.603 | +0.0006 |
       | 0.3 | **0.108** | **+0.055** (sd 0.008) |
       | 0.6 | 0.059 | +0.062 |

     - $R_V$ is unaffected (0.61). So caching alone makes the law "fail" with near-certainty, and the pre-registered reading would be "the old scores carry information about the new model".
     - Repeat disagreement, which the paper reports, cannot separate caching from extreme $\mu$. So (A2) is not checkable from repeats 1–2.
     - **The fix is already in the design.** Home cells have repeats 3–4, collected later. The denominator $\sum\Delta\bar y^{s,(12)}\Delta\bar y^{s,(34)}$ is unbiased for $\sum(\delta^s)^2$ whenever the two *sessions* are independent, even if repeats within a session are not. This should be the primary denominator, or at least a pre-registered sensitivity analysis. The existing sensitivity analysis ("all four home repeats") still uses within-session products.
  2. **Weak owner signal.** $\hat\gamma$ is a ratio whose denominator can be near zero or negative. In the same world:
     - At the dry run's 112 tasks per pair, $P(\sum\hat d^2\le0)=0.11$–$0.45$ as reliability falls from 0.12 to 0.02, the median of $\hat\gamma$ is 0.21–0.53 against 0.60, and the IQR is roughly $(0.15,0.96)$ even at reliability 0.12.
     - At 2,400 tasks and reliability 0.12, the estimator behaves well: median 0.600, IQR $(0.53,0.73)$.
     - The definedness rule in the pre-registration ($\sum\hat d^2\ge4$ SE; it is not stated in the paper) selects strongly when it binds. In the cases above where it admitted only 2–5% of draws, the mean of $\hat\gamma$ given definedness was **0.33–0.35 against 0.60**.
     - A first-order (delta-method) variance for the gap $G$ is unreliable in this regime.
     - The paper should state the regime in which $\hat\gamma$ is usable, in terms of $\sum(\delta^s)^2/\mathrm{SE}$, and use Fieller-type or bootstrap-t intervals for $\hat\gamma$, $R$ and $\theta$.
  3. $|\hat\rho|$ can exceed 1, a classical feature of disattenuated correlations.
- **Overall for S12: (b)** asymptotically; **(c)** in practice. It needs within-cell repeat independence, which should be replaced by cross-session independence, and a strong enough owner signal.

**S13. (iii) With one owner repeat, $\gamma$ is not identified.**
- The argument (add an independent mean-zero $\xi$ to $\mu_s$) is correct, and so is the remark that no unbiased estimator exists, since expectations are multi-affine in the $\mu$'s.
- The argument needs $\mu_s$ bounded away from $\{0,1\}$ on a set of positive mass, so that $\mu_s+\xi\in[0,1]$. If the owner is deterministic, single draws do identify $\delta^2$.
- The same construction with $\xi$ *shared* by repeats 1 and 2 shows that, with two repeats, identification rests entirely on (A2). That should be said next to (iii).
- **(b)/(c).**

**S14. (iv) $G$ estimates $L/(2EW_{swap})$, with variance $V_{task}+V_{item}-V_{both}$ in which items enter as dyads.**
- Correct as inclusion–exclusion over the *set of dependent pairs of observations*: share a task, or share at least one item.
- Implementation details decide whether it is right:
  - The item term must use the dyadic correction. A candidate pair $(i,j)$ that appears in several tasks shares *both* items with itself, and a naive sum of $\sum_c(\sum_{p\ni c}\psi_p)^2$ over items counts it twice.
  - The two-way estimate can be negative (Cameron, Gelbach and Miller 2011 discuss an eigenvalue fix).
- The scheme ignores two sources of dependence:
  - between items whose scores were co-determined by the adaptive score phase (items that competed for the same score tasks);
  - between swaps that share an owner or a reader, which matters for the stratum means. The pre-registration admits this.
- The simulated coverage (94–97%) is reassuring, but it comes from worlds that satisfy (A2) and have adequate signal.
- **(c).**

**S15. "A prediction with no fitted parameter".**
- No parameter is tuned to $C_{swap}$, which is fair.
- But $\hat\gamma$ and $W_{swap}$ are estimated from the *reader's outcomes on the very tasks being predicted*. Algebraically, $G\cdot 2W_{swap}=\sum_p(a_p-\hat c S_p)T_p$: measured and predicted share the factor $1/(2W_{swap})$.
- Two consequences:
  1. The headline comparison of the law's MAE (0.030) with that of "no change" (0.111) is unbalanced, because only the law uses reader data. The fair baselines are "$R=\hat\gamma$" and "$R=\hat\rho$". Both are in the pre-registration (11.2.5) but missing from the paper. So is a cross-fitted version (estimate $\hat\gamma$ on half the tasks, test on the other half).
  2. Figure 2 plots two quantities with a common denominator (Pearson's 1897 spurious correlation of ratios). The honest plot is $R_V$ against $\hat\gamma$.
- The abstract's "mean gap" is also the wrong summary: gaps of opposite sign cancel. Use MAE or RMS gap.
- **(c), rhetorical overstatement.**

### 2.4 Invariance and discounts

**S16. Prop. 3, first sentence: a strictly increasing map leaves every concordance unchanged; a decreasing map sends $C_w\to1-C_w$.**
- Correct, and covered by the tolerance caveat in A8.
- **(b)**, a standard property of rank statistics.

**S17. "This covers fixed\_λ on ema\_grade, credit and visits."**
- Correct: $q'=0.5+\lambda(q-0.5)$, $c'=\lambda c$ and $n'=\lambda n$ are all strictly increasing for $\lambda>0$.
- **(b).**

**S18. Discounting counts by $\lambda$ is the same as a Beta$(1/\lambda,1/\lambda)$ prior on the full counts.**
- Correct: $(1+\lambda s)/(2+\lambda n)=(1/\lambda+s)/(2/\lambda+n)$.
- This is also the power prior with fixed $a_0=\lambda$ on a Beta(1,1) initial prior, as the related-work section says.
- **(b).**

**S19. Main text: discounting counts "reorders exactly the pairs whose net-count and posterior-mean orders disagree".**
- For a *fixed* $\lambda$ this is **false**.
- The A8 algebra is right: the order is the sign of $2(m_i-m_j)+\lambda(m_in_j-m_jn_i)$, with one crossing at $\lambda^*_{ij}$. A pair is reordered at a given $\lambda$ only if $\lambda^*_{ij}\in(\lambda,1)$.
- **Counter-example** (`check_sequential.py`): item $i$ has 1 success in 1 show; item $j$ has 6 in 10.
  - Net count: $m_i=0.5<m_j=1$, so $j$ ranks first.
  - Beta(1,1) mean: $0.667>0.583$, so $i$ ranks first.
  - The two orders disagree, but the crossing is at $\lambda^*=0.25$. At the pre-registered $\lambda=0.5$ the scores are 0.600 and 0.571, which is **keep's order**.
- The A8 statement ("changes order at most once in $(0,1]$, and does so iff…") is correct. The main text should say "exactly the pairs with $\lambda^*_{ij}\in(\lambda,1)$; as $\lambda\to0$, these are the pairs whose net-count and posterior-mean orders disagree".
- **(d)** for the main-text sentence; **(b)** for the appendix version.

**S20. In the retrieval mix, fixed\_λ on ema\_grade or credit equals keep with score weight $w\lambda/(w\lambda+1-w)$; the moving-average update does not commute with the discount.**
- Both correct.
- **(b).**

**S21. The converse: if $C_w$ is equal for all outcome tables, then the within-task weak orders are equal.**
- Correct. The single-success table gives $a_i$, and $x_i>x_j$ strictly implies $a_i\ge a_j+2$.
- Note what it gives: preservation of every *co-candidate* order, **not** the existence of one global strictly increasing map. Pairs that never share a task can be reordered freely.
- **(b)**, with that scope stated.

**S22. Sec. 3, the MemRL equivalence: with rewards in $[-1,1]$ and $q_0=0$, the map $q'=(q+1)/2$ commutes with the update.**
- Correct for the affine map and any rewards in $[-1,1]$, provided the step size is the same and the same normalised score enters the retrieval mix.
- **(b).**

### 2.5 Gaussian corollary, the arcsin claim and break-even

**S23. Gaussian corollary.**
- Statements:
  - unweighted $C=\tfrac12+\arcsin(r)/\pi$ (Sheppard);
  - $E[Y\,\mathrm{sgn}X]=r\,\mathrm{sd}(Y)E|X|/\mathrm{sd}(X)$, so $C_w=(1+r)/2$;
  - Gaussian Markov chain, giving $\mathrm{corr}(\Delta x,\delta^t)=\mathrm{corr}(\Delta x,\delta^s)\rho$;
  - attenuation by $\mathrm{Rel}^{1/2}$.
- All correct and all classical. $C_w=(1+r)/2$ is the fact that Gini correlation equals Pearson under normality.
- **(b).**

**S24. "For outcomes in $\{0,\tfrac12,1\}$ … the arcsin form under-predicts the unweighted concordance by 0.04–0.07 and $(1+r)/2$ under-predicts $C_w$ by about 0.01, while the measured-$E|\Delta\bar y|$ version is within 0.003."**
- The direction is right. In my three logistic worlds the errors were:

| Prediction | Error in my worlds | Paper's stated error |
|---|---|---|
| arcsin form, unweighted $C$ | +0.023 to +0.086 | 0.04–0.07 |
| $(1+r)/2$ for $C_w$ | +0.007 to +0.027 | about 0.01 |
| measured-$E\lvert\Delta\bar y\rvert$ form | +0.001 to +0.005 | within 0.003 |

- So the sizes depend on the data-generating process. The paper should state its own, or give ranges.
- **(c).**

**S25. Related work: "Our law … under normality reduces to the classical arcsin form."**
- **Wrong.** The law concerns $C_w$, and under joint normality $C_w=(1+r)/2$ is *linear* in $r$. Under normality the law reduces to "Spearman-attenuated $r$, times $\rho$". The arcsin form belongs to the unweighted $C$, which the law does not describe.
- **(d)**, minor.

**S26. Break-even: fresh checks beat kept visits iff $k>\eta_t\rho^2n/(\eta_s+(1-\rho^2)n)$.**
- The derivation via the law of total covariance is correct.
- Monte Carlo check (`check_gauss_breakeven_qap.py`): the correlations match the formula to the third decimal (0.451, 0.544 and 0.659 for $n=3,6,20$), and the first winning integer is $\lfloor k^*\rfloor+1$ in every case.
- Three caveats:
  - The main text writes a single $\eta$, which assumes $\eta_s=\eta_t$.
  - "Fresh-only wins for every $n$ iff $\rho^2<K/(K+\eta_t)$" should read "$\le$", a boundary triviality.
  - The model, "one success chance per item", ignores the within-task usefulness heterogeneity that the whole law is built on. It also compares two dominated estimators: the credibility-weighted combination beats both.
- This is Bühlmann credibility.
- **(b)/(c).**

### 2.6 The swap-day check (Sec. 3c)

**S27. $A_\tau=\sum_{i<j}\mathrm{sgn}(\Delta x)(y_i-y_j)/M$, with $M=\lfloor n/2\rfloor\lceil n/2\rceil$, lies in $[-1,1]$, is linear in the success probabilities, and "is 0 when the old order carries no information".**
- The bounds are correct. With no ties, $a=(3,1,-1,-3)$ and $\max\sum a_iy_i=4$. Ties shrink $|a_i|$.
- The mean of $A_\tau$ is linear, so single-check tasks have the same expectation as two-repeat means. This is a good use of Prop. 1.
- "Zero when there is no information" holds on average over shuffles or banks, not for a fixed bank.
- **(b).**

**S28. Validity of each one-sided test: $\Psi_t$ is a non-negative supermartingale and Ville's inequality applies.**
- Correct for tasks i.i.d. from the stream (or any filtration with $E[\xi_t\mid\mathcal F_{t-1}]\le\omega$). The bets $\eta_d=d/40\le0.5$ keep every factor at least $0.5$.
- My simulated error with a known home value was $\le0.033$ through 6,000 tasks, consistent with the paper's 0.034.
- **(b)**, the classical betting construction, which the paper cites as such.

**S29. "If tasks are drawn independently and $\bar A_{home}$ is treated as known, each error is at most $\alpha$ at any stopping time."**
- The statement is correct *as stated*, but the condition is never met. The KEEP threshold $0.75\hat A_{home}$ is a random variable estimated from the owner's evaluation tasks.
- Conditional on $\hat A_{home}$, the test controls error for the *plug-in* null $\bar A_{swap}\le0.75\hat A_{home}$, not for $\theta\le0.75$. As the horizon grows, the false-KEEP probability for $\theta\uparrow0.75$ tends to $P(\hat A_{home}<\bar A_{home})\approx\tfrac12$.
- Numerical check (`check_sequential.py`): per-task statistic of the paper's form, $\bar A_{home}=0.20$, sd of a single-check $A$ about 0.53, 1,000 streams.

| True $\theta$ | Home value | False KEEP by 300 tasks | by 1,000 | by 6,000 |
|---|---|---|---|---|
| 0.74 | known | 0.011 | 0.023 | 0.033 |
| 0.74 | SE $=\bar A_{home}/4$ (the reportability floor) | 0.041 | **0.163** | **0.316** |
| 0.70 | SE $=\bar A_{home}/4$ | 0.024 | 0.122 | 0.232 |
| 0.60 | SE $=\bar A_{home}/4$ | 0.007 | 0.041 | 0.100 |
| 0.74 | SE $=\bar A_{home}/10$ (roughly 400 tasks per order) | 0.005 | 0.036 | 0.128 |

- Within the table's 300-task cap, low power hides the inflation. On a live stream, which is how a "stop-when-sure" rule would be used, it does not stay hidden.
- A9's "controls each of its two errors at α=0.05 *by construction*" drops the qualifier and is **(d)** as written.
- Fix: split $\alpha$. Keep only if a lower confidence-sequence bound for $\bar A_{swap}$ exceeds $0.75$ times an upper $(1-\alpha/2)$ bound for $\bar A_{home}$, or use a confidence sequence for the ratio directly.
- **(c)** for the 03c statement.

**S30. The composite keep/drop/continue decision is "error-controlled".**
- Each error is $\le\alpha$, given S29's conditions, because each decision requires its own test to reject, and both guarantees hold uniformly over time.
- In the indifference zone $0.25<\theta<0.75$, the chance of *some* wrong decision is $\le2\alpha$.
- DROP and the default at the cap both lead to "recalibrate" (pre-registration 11.4.5). So the false-drop guarantee makes no difference to the action taken; only KEEP is consequential.
- **(b).**

**S31. The replay as a check of the guarantee.**
- Tasks are drawn uniformly without replacement from one pool, so they are exchangeable but not i.i.d.
- Sampling without replacement is *not* the problem. With the pool mean exactly at the KEEP threshold, the type-I error was 0.000 in 4,000 replays: the without-replacement path is pinned at the pool mean.
- The problems are elsewhere:
  - The "truth" is computed on a *different* half of the evaluation tasks. Its own standard error (about 0.14 in $\theta$ at 200 tasks with these signal levels) is not small next to the 0.75 and 0.25 thresholds.
  - The 1,000 replays per cell share one pool, so a cell's "false-keep rate" is close to a property of that pool, not a frequency.
- The replay therefore checks agreement between two finite-sample estimates, not the guarantee. The simulator check with fresh Bernoulli draws is the real check.
- **(c).**

**S32. Abstract: "A keep-or-drop decision with controlled error needs a median of [563] fresh-check tasks, against 8 to 64 checks for fixed rules."**
- This compares *tasks* (4 checks each, so 563 tasks are about 2,250 checks) with *checks*.
- 563 tasks is 5.6 times the 100-task calibration pool and nearly twice the 300-task replay pool, and the dry-run replay left **100%** of cells undecided (`CheckAllUndecidedInTable=1.000`).
- The comparison also omits the fixed rules' false-keep rates of 51–58% (audit\_8 to audit\_64).
- The cost is **not** a weakness of the betting test. It is an information limit. With the paper's per-task statistic at $\bar A_{home}=0.2$:
  - Wald's inequality gives that *any* sequential test with false KEEP $\le0.05$ at $\theta=0.75$ needs $E[N\mid\theta=1]\ge190$ tasks for 50% power and $\ge437$ for 80%. This uses the full four-outcome likelihood; KL is 0.0044 per task.
  - A fixed-sample one-sided test on $\bar A$ needs about 704 tasks for 80% power.
  - My simulated median stopping time at $\theta=1$ was 614 tasks, consistent with the paper's 563.
- The paper should state this as a result, for example $N\gtrsim 2\sigma_A^2\log(1/\alpha)/(0.25\bar A_{home})^2$. It is the only genuinely new, decision-relevant theoretical fact available here: *no rule can make a controlled keep/drop decision within the benchmark's budget unless the home signal is several times larger*.
- The current wording is misleading.

### 2.7 Forecast and permutation tests

**S33. Leaving one model out.**
- Valid for the question "predict swaps that involve one unseen model": all of model $m$'s targets are excluded from training.
- But every test swap's *other* model is seen in training, so the scheme does not reproduce "neither model seen". With 8 models, a leave-two-models-out variant is feasible.
- Out-of-fold MAE intervals that resample tasks ignore variability between models, which dominates the generalisation claim.
- **(c).**

**S34. "A model-label permutation test cannot reach $p<1/n!$, so with Holm over two tests it needs at least five models."**
- Correct, and trivial ($1/24>0.025>1/120$).
- It is necessary but far from sufficient; power is the binding constraint.
- **(b).**

**S35. Validity of the permutation test as a test that error consistency predicts $\theta$.**
- Relabelling models in the predictor array with targets fixed is a Mantel/QAP test (Mantel 1967; Krackhardt 1988). It is exact for the *sharp null* that the arrays are independent and one is jointly exchangeable.
- The maker structure makes neither array exchangeable. So the test rejects whenever both arrays carry the maker signal.
- Numerical check: 8 models in 4 makers, $\theta$ depending only on the same-maker flag, and error consistency equal to the same-maker effect plus independent noise, so it adds nothing beyond the flag. F1's one-sided test at 0.025 **rejected in 47% of 200 worlds**.
- The pre-registration's wording rule (beat same\_maker in out-of-fold $R^2$) partly guards against this, but the paper does not state it. The right tool is MRQAP with the same-maker flag partialled out (Dekker, Krackhardt and Snijders 2007, double semi-partialling or Freedman–Lane).
- **(c).**

**S36. Link between the forecast and the theory (not claimed as a proposition, but implied by Sec. 3c following Sec. 3b).**
- The predictor (no-memory error consistency) measures agreement on *task-level* difficulty.
- The target $\theta=R_V$, which equals $\gamma$ under the law, is built from *within-task* item differences, which remove task-level effects by construction. In the decomposition $\mu_m(\tau,i)=a_m(\tau)+b_m(i)+e_m(\tau,i)$, error consistency depends on $(a_s,a_t)$ and $\theta$ on $(b,e)$.
- The theory therefore gives no reason to expect error consistency to forecast $\theta$, and the dry run's out-of-fold $R^2=-1.5$ is unsurprising.
- The theory points instead to estimating $\gamma$ from a few reader cells, which is the "20 fresh checks" baseline. It also says how many cells that needs, given the low reliability (S12).
- This is a gap in the logic, not an error.

### 2.8 The confirmatory machinery

**S37. PC1 enters Holm with $\min(p_{drop},p_{NI})$; PC4 uses $\max(p_{4a},p_{4b})$; p-values come from the percentile bootstrap.**
- With $C_{home}>\tfrac12$ the two PC1 nulls are disjoint, so $\min$-$p$ testing is valid (partitioning principle; Goeman, Solari and Stijnen 2010, three-sided testing).
- The intersection–union test is valid (Berger 1982).
- Percentile-inversion p-values are asymptotically valid. Holm thresholds near 0.004 sit in the bootstrap tail (about 42 of 10,000 draws), which is acceptable.
- **(b).**

**S38. The headline estimand.**
- By the paper's own identity, $R=R_V\times(W_{home}/W_{swap})$ exactly, on the same tasks. The paper says "a noisier reader lowers $R$ with no change in transfer".
- Yet PC1, Figure 1 and the abstract's retained-validity numbers all use $R$ and $D$ on $C_w$.
- The self-swap noise floor does not repair this. It compares two sets of owner repeats with the *same* noise level, so it captures only sampling noise and drift, not the reader's different outcome variance.
- In the dry run the spread ratio for two-repeat cells ranges over roughly 0.81–1.11 (Fig. A8 left panel), so $R$ misstates $R_V$ by up to about 20%. $R_V$ is the decision-relevant ratio because first-shown success depends on $\mu_t$, not on noise.
- This is an internal inconsistency, not a mathematical error.

### 2.9 Summary of numerical checks

| Check | Finding |
|---|---|
| Identity (Prop. 1) | Exact to $10^{-16}$ with ties |
| $V$ unbiased under 60% caching | Yes ($1259.5\pm4.8$ against $1253.7$) |
| $\hat\gamma$ under 30% within-session caching | 0.108 against 0.600; law gap $+0.055$ $C_w$; $R_V$ unaffected |
| $\hat\gamma$ with weak signal (reliability 0.02–0.12, 112–2,400 tasks) | $P(\text{den}\le0)$ up to 0.45; conditional mean given the 4-SE rule 0.33 against 0.60 when the rule binds |
| Mediation without linearity (reader a monotone transform of owner) | Law gap $+0.031$ / $-0.023$ / $-0.026$ $C_w$, beyond the ±0.02 margin |
| Score reliability under non-linear transfer | $R_V$ 0.615–0.626: nearly invariant |
| Count-discount reorder claim at λ=0.5 | Counter-example (1/1 against 6/10) |
| Gaussian corollary on 2-repeat outcomes | arcsin miss +0.023 to +0.086; $(1+r)/2$ miss +0.007 to +0.027 |
| Break-even formula | Exact; first winning $k=\lfloor k^*\rfloor+1$ |
| Check, home value estimated | False KEEP 0.16–0.32 at θ=0.74 by 1,000–6,000 tasks |
| Check, without-replacement replay at a null pool | Type-I 0.000 (conservative) |
| Information lower bound for any check | ≥190 tasks (50% power), ≥437 (80%); fixed-sample n≈704 |
| Model-label permutation (QAP), error consistency adds nothing beyond maker | Rejects 47% |

---

## 3. Strengths

1. **The question is real and well posed.** The probe-table design makes rank validity measurable item by item and lets any future rule be scored offline. Showing each item alone removes the identification problems of retrieval logs.
2. **The algebra is clean and correct.** Writing $C_w=\tfrac12+\sum V/(2\sum W)$ separates noise from signal in the first moment. It is used well in two places: the noise-free $R_V$, and the single-check sequential statistic, whose mean equals that of two-repeat means.
3. **The pre-registration is unusually explicit.** It fixes margins, multiplicity families, reportability rules, decision wording and what counts against each claim. The intersection–union test for PC4 and $\min$-$p$ for PC1 are handled correctly.
4. **The paper is honest about limits.** It names dependent repeats, finite banks, the low power of an 8-model forecast and the share left undecided as threats. The theory appendix separates classical from new more than most submissions do.
5. **The anytime-valid construction is correctly implemented** (non-negativity, mixture of constant bets, Ville), and is checked against exact nulls.

---

## 4. Weaknesses (most serious first)

**W1. The headline estimand contradicts the paper's own theory.**
- Prop. 2 shows that $R$ moves with the outcome spread of the two models, $W_{home}/W_{swap}$, with no change in transfer.
- PC1, the abstract's retained-validity numbers and Figure 1 still use $R$ and $D$ on $C_w$, and the self-swap floor does not correct for the reader's noise (S38).
- Either make $\theta=R_V$ the primary estimand, or report $R=R_V\times$(spread ratio) as a decomposition in every headline.

**W2. The "law" rests on a misdescribed assumption, so its failures cannot be interpreted.**
- $L=0$ is a linear partial-covariance restriction (IV equals reliability-corrected OLS), not "mediation" (S7).
- With mediation holding exactly, non-linear probability maps produce law gaps of +0.031 and −0.026 in $C_w$, beyond the ±0.02 margin.
- Dependent owner repeats produce +0.055 (S12).
- In each case the pre-registered reading of the sign ("scores carry information about the reader beyond the owner" or "owner's quirks") is false.
- The law is a joint test of (A1), (A2), linearity and no leakage. It should be called a *specification test*, with that list of assumptions.

**W3. The transfer-slope estimator is fragile exactly where it matters (S12).**
- Within-task item differences have low reliability. So $\hat\gamma$ is heavy-tailed at per-order sizes, the definedness screen biases it, and caching collapses it.
- The design already holds the fix: a cross-session denominator from repeats 1–2 against 3–4.

**W4. The swap-day check's guarantee and its headline cost are both overstated (S29–S32).**
- The guarantee assumes a known home value. Estimating it lets false KEEP rise to 0.16–0.32 near the boundary on realistic horizons.
- "By construction" in A9 is wrong as written.
- The abstract compares 563 *tasks* with 8–64 *checks* and does not say that the replay decided nothing.
- The real, useful finding is an information lower bound: hundreds of tasks are needed at this home signal, for any procedure. The paper does not state it.

**W5. Novelty of the theory is overstated by its framing.**
- "Proposition", "Law of score transfer" and "a prediction with no fitted parameter" suggest new results. In fact:
  - Prop. 1 is the linearity of the Gini covariance (Schechtman and Yitzhaki 1987).
  - Prop. 2 is an identity plus a Hausman-type restriction. Its "direction of failure" is the IV-weights result (Angrist and Imbens 1995).
  - $\hat\gamma$ and $\hat\rho$ are method-of-moments errors-in-variables estimators with replicates (Fuller 1987) and Spearman's correction.
  - (iii) is classical unbiased estimability for Bernoulli data.
  - Prop. 3 is rank invariance plus a reparametrisation of the power prior.
  - The corollary is Sheppard/Greiner plus Gini equals Pearson. The break-even rule is Bühlmann. The check is Waudby-Smith and Ramdas. The forecast test is Mantel/QAP.
- The introduction partly concedes this ("the ingredients are classical"), but the section headings and the abstract do not.

**W6. The forecast is disconnected from the theory, and its test does not test the claim (S33–S36).**
- Error consistency measures task-level agreement. The target is built from within-task differences that cancel task effects.
- The permutation test rejects the sharp null of independence whenever both arrays carry maker structure: 47% in a world where error consistency adds nothing.
- Leaving one model out still sees the other model of every test swap.

**W7. Inference treats the same sources of randomness inconsistently.**
- Items are random for the law's test; banks are fixed for PC1–PC4 (task bootstrap only), and the sequential check conditions on the bank. Models are fixed everywhere, yet the forecast and P1–P4 are framed as generalisation.
- The paper's own simulation gives task-only coverage of 91–92% when items are random.
- Each choice can be defended, but the estimand (bank-conditional or item-superpopulation) must be stated per claim. The primary tests should then either say "for these banks" or add the item variance.
- The two-way variance has the further issues listed in S14.

**W8. Statements that are wrong or overclaimed as written:**
- the main-text count-discount reordering claim (S19);
- "under normality the law reduces to the arcsin form" (S25);
- "one stated, testable assumption" (S7, S8);
- "by construction" (S29);
- "outcome noise enters $C_w$ only through $W$" (first moment only; S3);
- "the law predicts the swap validity of each pair with a mean gap of …" (the mean gap is the wrong summary; S15).

**W9. Minor:**
- the tie-tolerance precedence in $\kappa$;
- "unit weights" should read "unit weights on informative pairs";
- the main-text break-even formula silently sets $\eta_s=\eta_t$;
- the boundary case should be "≤" in the "fresh-only wins for every $n$" condition;
- (iii) needs $\mu$ bounded away from $\{0,1\}$;
- $|\hat\rho|$ can exceed 1;
- ratios with weak denominators ($R$, $\theta$, $\hat\gamma$) deserve Fieller or bootstrap-t intervals;
- the forecast figure labels the target $T=N_{swap}/N_{home}$ while the paper uses $\theta=\bar A_{swap}/\bar A_{home}$;
- the dry-run law figure says "12 ordered swaps", but `LawNPairsDefinedAllSwapsValue=9`.

---

## 5. Questions for the authors

1. Under what exact condition do you claim $L=0$: conditional independence $x\perp\mu_t\mid\mu_s$, or the linear condition $E[\delta^t\mid\delta^s,x]=\gamma\delta^s$? If the former, how do you square it with the counter-example in S7, where $\mu_t=g(\mu_s)$ cell by cell and the gap reaches 0.031 $C_w$?
2. Will you estimate $\sum(\delta^s)^2$ from cross-session products (repeats 1–2 against 3–4), so that $\hat\gamma$ is robust to within-session dependence? What is the measured within-session repeat agreement of each closed model relative to its across-session agreement?
3. In the dry run, $\hat\gamma$ is below the simulator's truth in both groups (0.60 against 0.69; 0.27 against 0.30). Is this a systematic bias (definedness selection, ratio bias, or an (A2) violation in the simulator), or noise?
4. What is the expected reliability $E(\delta^s)^2/(E(\delta^s)^2+\text{noise})$ of within-task item differences per model? At what reliability does the definedness rule fail at 400 or 1,200 tasks?
5. For the check: how do you propagate the uncertainty of $\hat A_{home}$? Would you accept a Bonferroni split (a confidence sequence for $\bar A_{swap}$ at $\alpha/2$ against a fixed-sample bound for $\bar A_{home}$ at $\alpha/2$)?
6. Will you report, for the check, a lower bound on the tasks any level-α procedure needs at the observed $\bar A_{home}$, and restate the abstract in tasks and checks with the undecided share?
7. Why should no-memory error consistency, which reflects task-level agreement, predict a within-task quantity from which task effects cancel? Would a forecast of $\gamma$ from a small number of reader cells be more coherent with Sec. 3b?
8. How is the item term of the two-way variance computed when the same candidate pair occurs in several tasks? What do you do when the estimate is negative?
9. Is PC1 meant to be bank-conditional? If so, please say "for these banks". If not, why does PC1 use a task-only bootstrap when the law uses items as random?
10. Which baselines will the law's MAE be compared with in the paper: "$R=\hat\gamma$", "$R=\hat\rho$", a cross-fitted law? Why is only "no change" reported?

---

## 6. Scores

| Item | Score | Reason |
|---|---|---|
| **Soundness** | **2 / 4** | The formal statements are mostly correct. But the identifying assumption is misdescribed, $\hat\gamma$ is fragile under the paper's named risks, the check's guarantee is overstated, and the headline estimand contradicts the paper's own identity. |
| **Presentation** | **2 / 4** | Well organised and pre-registered, but classical results are branded as Propositions and a "law", and the abstract's check comparison and "mean gap" are misleading. |
| **Significance** | **2 / 4** | The question matters for agent memory. The theoretical contribution is modest, and the most useful theoretical fact (an information lower bound for the swap-day decision) is missing. |
| **Originality** | **2 / 4** | The target quantity is new; every statistical tool is classical. |
| **Overall** | **3 / 6** | Weak reject in its current form. The benchmark could be a solid contribution once the estimand and the claims are repaired. |
| **Confidence** | **4 / 5** | I checked every proof line by line and tested the doubtful claims numerically. I did not see the code or real data. |

---

## 7. Is the theory section an asset or a liability as written?

**As written it is a liability.**
- It invites a statistician to check eight "propositions", almost all classical, under a heading ("A Law of Score Transfer") that promises more than they deliver.
- Its central assumption is described in words that do not match the mathematics, so any failure of the law will be misread.
- Its estimator breaks under the risks the paper itself names (caching, deterministic decoding).
- Its most important practical consequence, that $R_V$ rather than $R$ is the right headline, is ignored by the confirmatory analysis.
- Its two neighbours in Sec. 3c (the forecast, and the check's guarantee) are either disconnected from it or overstated.

**How to make it an asset:**

1. **Rename and reframe.**
   - Call it "A decomposition of concordance after a swap", not a law.
   - Lemma 1: $C_w=(1+\Gamma)/2$, with $\Gamma$ the pooled within-task Gini correlation, linear in outcomes (cite Schechtman and Yitzhaki 1987).
   - Lemma 2: the identity $R=R_V\cdot W_{home}/W_{swap}$.
   - Proposition: $R_V=\gamma+L/E[\mathrm{sgn}(\Delta x)\delta^s]$, with $L=\mathrm{Cov}(\delta^t,a-\mathrm{Proj}(a\mid\delta^s))$, presented as an IV-against-OLS (Hausman) contrast.
   - State assumptions A1–A3 explicitly, A3 being linearity of $E[\delta^t\mid\mu_s\text{-pair},x]$ in $\delta^s$. Delete "one assumption" and "no fitted parameter".
2. **Make the test what it is.**
   - Call it a *specification test* of A2 + A3 + no leakage. Say that the sign of a gap is not interpretable without A3.
   - Add a non-linearity sensitivity analysis, for example fitting the law on the logit scale or with a monotone-spline $E[\delta^t\mid\cdot]$.
3. **Repair the estimator.**
   - Primary denominator from cross-session products (repeats 1–2 against 3–4).
   - State the reliability regime in which $\hat\gamma$ is usable.
   - Use Fieller or bootstrap-t intervals for $\hat\gamma$, $R_V$ and $R$.
   - Compare the law with "$R=\hat\gamma$" and with a cross-fitted law, not with "no change".
4. **Promote $\theta=R_V$ to the headline,** with $R$ reported as $R_V\times$ spread ratio.
5. **Turn the check into a theorem plus an honest number.**
   - Propagate the uncertainty of $\hat A_{home}$ so that the guarantee holds for $\theta$.
   - Add the information lower bound ($E N\gtrsim 2\sigma_A^2\log(1/\alpha)/(0.25\bar A_{home})^2$, or Wald's KL form).
   - Report the check's cost in checks and with the undecided share.
   - This makes "fixed budgets of 8–64 checks cannot support a controlled decision" a *derived* statement rather than a simulated one.
6. **Cut or demote to appendix remarks:**
   - the Gaussian corollary (explicitly classical);
   - the break-even rule (explicitly Bühlmann);
   - the invariance results, with the main-text count statement corrected.
7. **Connect the forecast to $\gamma$, or decouple it.** If error consistency stays, test it with MRQAP partialling out same-maker, not with a plain label permutation.

---

## 8. The three changes that would raise my score most

1. **Fix the estimand and the law's assumptions together.**
   - Make $\theta=R_V$ the primary PC1 estimand, or report the exact split $R=R_V\times W_{home}/W_{swap}$ in every headline.
   - Restate the law as a specification test with its full assumption list (A1, A2 with cross-session independence, linearity, no leakage).
   - Use the cross-session estimator of the owner's signal, and add the non-linearity and repeat-dependence sensitivity analyses. My counter-examples show both can move the gap past the ±0.02 margin.
2. **Repair the stop-when-sure check.**
   - Make the guarantee hold for $\theta$ by propagating the uncertainty of $\hat A_{home}$.
   - Add an information lower bound on the tasks any level-α procedure needs.
   - Rewrite the abstract's comparison in consistent units (tasks against tasks, or checks against checks), with the undecided share and the fixed rules' false-keep rates.
3. **Re-present the theory honestly and fix the incorrect statements.**
   - Label the classical results as classical (Gini correlation, Hausman and IV weights, Fuller errors-in-variables, Bühlmann, Sheppard, Ville, Mantel/QAP).
   - Correct the count-reorder sentence, the arcsin claim, "one assumption", "by construction" and "mean gap".
   - Either ground the forecast in the decomposition (forecast $\gamma$) or test it with a same-maker-partialled permutation scheme.

---

### References used in this review (classical sources the paper should cite or cite more precisely)

- Angrist and Imbens (1995), *JASA* 90; Angrist, Graddy and Imbens (2000), *RES* 67. IV weights under heterogeneous effects.
- Berger (1982), *Technometrics* 24. Intersection–union tests.
- Carroll, Ruppert, Stefanski and Crainiceanu (2006), *Measurement Error in Nonlinear Models*, 2nd ed.
- Dekker, Krackhardt and Snijders (2007), *Psychometrika* 72(4):563–581. MRQAP, double semi-partialling.
- Fieller (1954), *JRSS-B* 16. Intervals for ratios.
- Fuller (1987), *Measurement Error Models*.
- Goeman, Solari and Stijnen (2010), *Statistics in Medicine* 29. Three-sided testing.
- Hausman (1978), *Econometrica* 46.
- Krackhardt (1988), *Social Networks* 10; Mantel (1967), *Cancer Research* 27.
- Pearson (1897), *Proc. R. Soc.* 60. Spurious correlation of ratios.
- Schechtman and Yitzhaki (1987), *Communications in Statistics: Theory and Methods* 16. Gini correlation.
- Wald (1945), *Ann. Math. Statist.* 16. Sequential tests and the expected sample-size bound.
- Waudby-Smith and Ramdas (2020), NeurIPS. Confidence sequences for sampling without replacement.
