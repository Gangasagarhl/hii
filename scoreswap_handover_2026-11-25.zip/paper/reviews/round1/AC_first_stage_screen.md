# ICML 2027 first-stage AC screen (Datasets, Evaluations and Benchmarks)

Submission: "Do Memory Scores Survive a Model Swap? A Benchmark of Keep, Wipe and Recalibrate Rules for Agent Memory" (anonymous).
Read from: `paper/main.tex`, `paper/sections/*.tex`, `paper/assets/*`, and the built `dryrun.pdf` (25 pages) / `main.pdf` (22 pages).
Context: the numbers are a watermarked simulation (dry run). The judgement is on framing, story and the first two pages, assuming real numbers with the same pattern.

---

## Step 1: timed screen (written before reading past the allowed parts)

Read: title, abstract, introduction, Figure 1 and its caption, the contribution list, the section headings, the limitations, and how pages 1 and 2 look in the PDF.

**Decision:** advance to full review.
**Confidence:** moderate (about 65 %). This is a "when in doubt" advance, not a clear accept-track paper.

**Two-sentence justification (as sent to the SAC):**
The paper asks a sharp, practical question that is new to me: when an agent's memory is carried to a new model, do the per-item usefulness scores still rank the items? It answers with a reusable offline probe table over 56 ordered model pairs, a falsifiable prediction with no fitted parameter, and pre-registered comparisons. My main doubts are about scale (eight models, two single-call task streams), whether calling it a "law" is justified, and an introduction that never states what was found. Those are questions for reviewers; they are not grounds to reject at this stage.

**What I noted during the 15 minutes:**
- Good: the question is in bold and can be checked; the scale is stated in the abstract (8 models, 4 makers, every ordered pair, 2 streams); the outside evidence in the intro is concrete (CHIME's 0.78 against 6.24 points, a Spearman of 0.40 on 1,165 released skill scores); "What we do not claim" sets out the novelty boundary honestly.
- Bad: the first figure is the result grid on page 5 or later, so pages 1 and 2 have no picture of the setup. The introduction has no "we find" paragraph, so the abstract is the only place the reader learns the result. Abstract sentence 3 is about 60 words long and packs four contributions together with semicolons. The fresh-check result ("a median of 563 tasks against 8 to 64 for fixed rules") reads as if the new check costs about 10 to 70 times more, and the sentence never says whether that is good or bad. The garage-and-mechanic opening uses three lines of the most valuable space in the paper. The release (the actual benchmark product) appears only in the last half-sentence of the abstract.
- I could not find quickly: what the two task streams are, how many items and tasks there are, what "validity" means in numbers (Harrell's C? Spearman?), and what a practitioner should do on swap day.

---

## Step 2: after reading the whole paper (all sections, appendices A–M, the four tables, all 12 figures)

### Was the first impression right?
Yes, the paper should advance, and I am now somewhat more confident (about 75 %). The full paper is more careful than its first two pages suggest. It has a pre-registered family of 12 Holm-corrected tests, a self-swap noise floor, a shuffled-score control, a two-way (task × item) variance for the law test, an outside check on released data, a datasheet and a release checklist. Read in full, the story is coherent and better than the opening suggests:

> carried scores lose ranking validity mostly across makers → the loss is accounted for by how much the two models agree on *which items help* (γ), not by the score rule → γ needs the new model's per-item results, so it cannot be read off cheaply → no-memory agreement [does / does not] forecast it → a decision with error control therefore costs [hundreds of] fresh tasks, and small fixed audits are wrong about half the time.

**This chain does not appear anywhere on pages 1–2.** A first-stage AC who stops after page 2 sees four loosely related contributions, not one argument. That is the main framing risk.

Step 2 also raised concerns that full reviewers will bring up. These are not reasons to reject at the first stage:
1. **The law is only partly a "prediction".** γ̂ is computed from the *reader's* probe results on the same tasks and items that give C_swap. It has no fitted parameter, but it is not available before the swap, and on the swap day it costs as much as measuring C_swap directly. In effect it is a mediation or conditional-independence test ("the score tells the reader nothing beyond the owner's item usefulness"). That is a useful diagnostic, but calling it a "law" that "predicts each pair" oversells it.
2. **The swap-day answer is mostly negative**, and the abstract hides that. In the dry-run pattern, the anytime-valid check needs a median of 563 tasks (629 to drop). That is more than the 300-task calibration pool the table holds, and only 0.2 % of streams decide within 100 tasks. The audit rule false-keeps in 58 % of replays. This is a real, citable finding, but it has to be stated as such.
3. **Contribution 4 (forecast) is likely null.** In the dry run the forecast's MAE is 0.44, against 0.18 for the same-maker flag and 0.25 for the grand mean. Listing a probable null as one of four headline contributions weakens the list.
4. **Internal inconsistencies a reviewer will find within minutes:**
   - Units: the abstract compares "563 fresh-check **tasks**" with "8 to 64 **checks**". One task is 4 checks, so the comparison is off by a factor of 4.
   - Horizon: the Results say "within the 100-task cap", the stopping figure says "horizon 1000 tasks" and "whole stream pool: 300 tasks = 1200 checks", and §5 says it "recalibrates when the table's tasks run out".
   - The swap-day decision is called "keep or drop" in the abstract and Results but "keep-or-recalibrate" twice in §5 and in related work.
   - The abstract says "eight swap-day rules". §3.3 and Table 8 list nine (keep, wipe, fixed, power prior, recal, retest, audit, pooled, fresh) plus five references.
   - "Family" means a *score family* (ema_grade, …) in the text, but every figure and table says "Same-family upgrades / Cross-family swaps" for *maker*. The text says "cross-maker".
   - The quantity is θ in §5 but "T = N_swap/N_home" on the forecast figure's axis.
   - In Figure 1 the diagonal is called the "noise floor", but in an R grid the self-swap is the *ceiling* (R≈1). It is a floor only for the drop D.
   - The cross-fitted **oracle scores below keep** (upgrades: 0.658 against 0.703), and the reader's own bank beats the oracle. With real numbers of this pattern, readers will distrust the reference. Rename it, e.g. "one-repeat oracle", and explain, or replace it.
   - The run after the swap gives keep 0.660 < wipe 0.676, while PC2 says keep beats wipe for upgrades. Nothing reconciles the two.
   - The PC4 decision label "not shown" reads as "not displayed". Use "not supported".
   - The abstract reports the law's **signed mean gap** (−0.000), which hides per-pair error. Report the MAE against the no-change baseline (0.030 against 0.111 in the dry run).
5. **Motivation contradicts itself.** The intro says end-task success "mixes the content of the items with the order", then cites CHIME's *end-task* numbers as evidence that "the order does not always carry over". CHIME cannot separate the two. Only the Beyond Gain outside check (Spearman 0.40 on 1,165 released skill scores) is order-only evidence.
6. **"Any new rule" is too broad.** The probe table can score only rules that re-rank the 4 fixed candidates shown one at a time on single-call tasks. Rules that change content, show several items, change retrieval or write new items cannot be scored offline.
7. **An 8×8 heatmap at column width** (the current Figure 1, a 4×4 grid in the dry run) will have about 6 pt numbers in 64 cells and will not be readable in print.

### What in the first two pages helped most
- The bold, checkable question.
- Scale in the abstract (8 models, 4 makers, every ordered pair, 2 streams).
- The Beyond Gain number (ρ = 0.40, 95 % CI 0.35–0.45, on 1,165 released skill scores, same-size successor), which is concrete and order-only.
- A plainly stated limit ("every confirmatory statement is about these eight models").

### What in the first two pages hurt most
1. **No "what we found" paragraph and no figure on pages 1–4.** The abstract is the only place the result appears, and there it is crammed into two sentences. The first figure is on page 6. The main body ends partway through page 7, so there is about one page of unused space under the 8-page limit.
2. **The swap-day sentence reads as a self-own:** "needs a median of 563 … against 8 to 64 checks". It is unclear whether this is the paper's method losing or a finding about how hard the decision is.
3. **"A law of score transfer"** in the abstract and contribution 2. A busy AC reads "law" as an overclaim, especially next to "the ingredients are classical".
4. **Defensive density.** The "What we do not claim" paragraph lists seven non-claims with ten citations on page 2, and the novelty disclaimer recurs (see the slop list). The *positive* novelty sentence ("none holds content fixed and asks whether carried per-item scores still rank items") is buried in Related Work on page 2–3.
5. The garage analogy uses the first three lines of the introduction.

### What a reader could not find quickly (target: under 60 s each)
| Item | Findable on pp. 1–2? | Where it actually is |
|---|---|---|
| The question | Yes (bold, p. 1), but it bundles three questions (do they / why / what to do) | intro |
| What was measured | **No.** "Item-level rank validity" and "above-chance validity" are not defined. Weighted within-task concordance C_w and R = (C_swap − ½)/(C_home − ½) appear only in §3.2 | p. 3 |
| Scale | Partly. Models yes. **Tasks, items, repeats and total graded calls: no.** Streams are not named (DDXPlus diagnosis, BIRD text-to-SQL). The agent leg on LifelongAgentBench is not mentioned | §6, p. 5 |
| Headline result | Abstract only, with mixed units; none in the intro | §7, p. 5–7 |
| What is new | Only as a list of non-claims. The positive statement is in Related Work | p. 2–3 |
| The limits | Yes (end of intro, §9) | p. 2, p. 7 |
| The practical swap-day rule | **No.** The Discussion is reserved for "after results" | p. 7 |

### Crowdedness and title collision (web check, 23 Nov 2026)
- **Title collision: high.** Goyal & Ray, *"Does Your Agent's Memory Survive a Model Upgrade? A Controlled Study of Memory Portability"* (arXiv 2609.05339, Sept 2026). The paper itself cites it as `goyal2026survive`. "Do Memory Scores Survive a Model Swap?" differs by two words, so an AC who has seen it will file this paper as "another portability study" before reading the abstract.
- **Area: crowded.** Moving memory across LLMs had at least six 2026 papers: Goyal & Ray; CHIME; Memory Transfer Learning; MemCollab; *Rosetta Memory* (arXiv 2606.07711); *Learning on the Job* (arXiv 2607.22157, a frozen store moved between Mistral Large and Claude Sonnet 5); and ICLR-2027 submissions on executor and judge replacement.
- **The specific angle looks open.** I found no paper that freezes content and measures whether carried *per-item scores* still *rank*. The title has to signal that angle.
- **Possibly missing citations:**
  - *Memory Reward Inflation in Self-Improving LLM Agents* (arXiv 2608.00017). It is about stored scores ranking bad memories high, also on BIRD, and is directly relevant to the validity of usefulness scores.
  - *Rosetta Memory* (2606.07711).
  - *Learning on the Job* (2607.22157).
- **Name check:** "ScoreSwap" has no collision. It sits close to ZenML's "SwapBench", which is cited, so that is acceptable.

---

## Rewrites

### (a) Three alternative titles
1. **ScoreSwap: Do Agent-Memory Usefulness Scores Still Rank Items After a Model Swap?**
2. Old Scores, New Model: A Benchmark for Reusing Agent-Memory Scores After a Model Swap
3. *(results-conditional)* Memory Scores Survive Upgrades but Not Cross-Provider Swaps: A Frozen-Content Benchmark for Agent Memory

**Pick: 1.**
- It names the benchmark, which suits the Datasets, Evaluations and Benchmarks type.
- It puts the measured quantity ("rank") and the object ("usefulness scores", not "memory") in the title, which separates it from Goyal & Ray's portability study.
- It drops "survive", the word that causes the collision.
- Title 3 is stronger *if* the real results show a clean within/cross split with non-overlapping intervals; decide once the numbers are in. Title 2 is the fallback if the venue dislikes colon titles.
- Running title: "ScoreSwap: Do Memory Scores Still Rank After a Model Swap?"

### (b) Abstract (6 sentences; bracketed placeholders)
> Agent memories attach a usefulness score to every stored item, but the score is earned under one language model, and providers retire models on short notice. Published transfer results report end-task success, which mixes what the items contain with how the scores rank them, so whether old scores still rank items for the new model has not been measured. We introduce ScoreSwap, a benchmark that freezes memory content and, for all 56 ordered pairs of eight models from four providers on two automatically graded streams (diagnosis and text-to-SQL), records the new model's result with every candidate item shown alone ([N] graded calls), so that any rule that re-ranks stored items can be scored offline without model calls. Old scores keep [X]% of their above-chance ranking validity after same-provider upgrades but only [Y]% after cross-provider swaps; a parameter-free decomposition, the two models' agreement on which items help corrected for outcome noise, accounts for each pair's loss with mean absolute error [a] (no-change baseline [b]). On the swap day, keeping old scores beats wiping them only after [upgrades], fixed audits of up to 64 checks keep scores that should be dropped in [P]% of replays, and a keep-or-drop decision with 5% error control needs a median of [M] fresh tasks. We release the probe tables, score banks and a pre-registered analysis that rebuilds every number.

*Why this version advances:* sentence 2 shows the gap is a measurement gap, not a missing method. Sentence 3 gives the scale in numbers and the reuse property. Sentence 4 is the headline plus the "why". Sentence 5 turns the 563-task number into a finding, with consistent units. "Law" is gone.

### (c) First paragraph of the introduction (replaces the garage paragraph and "Scored memories and forced swaps")
> Agents that learn at test time keep past solutions in a memory and attach a usefulness score to each item: MemRL updates a reward moving average per memory \citep{zhang2026memrl}, ACE counts how often an item was marked helpful or harmful \citep{zhang2025ace}, and EvolveR tracks success counts \citep{wu2025evolver}. Retrieval ranks items by these scores, so the scores, not only the content, decide what the agent sees. The scores are earned under one model, and that model is soon replaced: one provider promises only "at least 60 days' notice" before retiring a model \citep{anthropic2026deprecations}, and behaviour can shift even under a fixed name \citep{chen2024chatgpt}. On the day of a swap, an operator must keep the old scores, wipe them, or pay for fresh checks, and nothing yet measures whether the old scores still rank the items correctly for the new model.

Second paragraph (the gap, order-only evidence first):
> Systems that carry a scored memory forward report end-task success \citep{zhang2026memrl,yang2026romerl,zheng2026evokernel}, which mixes what the items say with the order the scores impose. Released per-item scores already suggest that the order does not fully carry over. Gains earned under one open model rank 1,165 skills for its same-size successor with Spearman ρ = 0.40 (95 % CI 0.35–0.45; \cref{app:outside}) \citep{wang2026beyondgain}.

Then add a third paragraph (**"What we find"**, 3–4 sentences with \Res{} numbers, pointing to Figure 1). The contributions come after it.

### (d) Figure 1: sharper caption and design note
**Design:** add a *new* Figure 1 at the top of page 2 (`figure*` spanning both columns, about 35 % of page height) or as a single-column figure on page 1. Move the current heatmap to the appendix or make it full-width, since an 8×8 grid is unreadable at column width.
- **Left panel (schematic):** owner model → frozen bank with scores *x* → swap → reader model. Show the probe-table row ("task τ: 4 candidates, each shown alone, 2 repeats, auto-graded") and the comparison "order by old *x*" against "reader's results", giving C_swap and then R.
- **Right panel (result):** R for each of the 56 ordered pairs as dots with 95 % intervals, grouped into three columns (same-provider upgrades / downgrades / cross-provider), with a diamond per group. Add a grey band for the self-swap range, a dashed line at R = 0.75 (the pre-registered margin) and a solid line at R = 0.
- Use "provider" (or "maker") consistently, never "family".
- Use the same colour-blind-safe palette (cividis or Okabe–Ito) as the other figures.

**Caption:**
> **Figure 1. Old usefulness scores keep most of their ranking power within a provider and lose most of it across providers.** *Left:* ScoreSwap freezes a memory's content and compares the order given by the old model's scores with the new model's graded results on each candidate item shown alone. *Right:* retained validity R, the share of the old scores' above-chance ranking signal that survives the swap (1 = no loss, 0 = chance), for all 56 ordered pairs of eight models, with 95 % intervals and group means. Grey band: self-swap (same model, fresh repeats). Dashed line: pre-registered margin R = 0.75. [Upgrades keep X, downgrades Y, cross-provider swaps Z.]

**Fix for the current grid caption, if it is kept:** call the diagonal the *self-swap reference (R≈1 up to noise)*, not the "noise floor". State that colours are clipped to [0, 1] while the printed numbers are not. Replace the TODO with the takeaway sentence.

### (e) Contributions as checkable claims
1. **Benchmark.** ScoreSwap releases frozen probe tables for 8 models from 4 providers, 2 streams and 3 stream orders. For each of [N] probe tasks they record the reader's auto-graded result with each of 4 candidate items shown alone and with none, twice ([N] calls, [$] cost). All 13 rules and references in this paper are re-scored from the tables alone, without model calls (§3, App. B–C).
2. **Measurement.** For all 56 ordered pairs, retained ranking validity R with 95 % intervals against a self-swap reference: [X] after upgrades, [Y] after downgrades and [Z] after cross-provider swaps. The pre-registered drop test rejects in [k] of 3 strata (Fig. 1, Table 1).
3. **Explanation.** An exact decomposition of weighted concordance (Prop. 4.1–4.2) shows that if scores carry no reader-specific information, retained validity equals the two models' agreement slope on item usefulness times an outcome-noise ratio, and neither quantity uses the scores. On held-out tasks this accounts for each pair's swap concordance with MAE [a] (no-change baseline [b]). The leakage test rejects for [k] of 56 pairs, and score families differ by [d] (P3) (§4, Fig. 2).
4. **Swap-day rules and their cost.** Nine rules are compared on the same items with their call costs. Keep beats wipe on first-shown success in [strata]. No rule with k ≤ 64 checks beats both keep and wipe on log score in [strata]. An anytime-valid keep-or-drop test holds both error rates at or below [0.05] but needs a median of [M] tasks, while fixed audits of up to 64 checks false-keep in [P] % of replays (§5, §7).
- *Move the forecast to a secondary result,* phrased as: "A pre-registered pre-swap forecast from no-memory agreement [beats / does not beat] the same-provider flag out of model (MAE [a] vs [b]); with eight models this test has low power (App. H)."

### (f) What to cut from pages 1–2
| Cut or move | Lines saved | Why |
|---|---|---|
| Garage analogy, 3 sentences, plus the source comment `% Everyday picture first (owner's rule)` | about 4 | It uses the most-read lines and reads as a template |
| Biomedical retirement statistics (5,242 publications, 42 %, 538 days) | about 4 | Off-topic for agent memory; the 60-day notice and one drift example are enough |
| CHIME numbers paragraph | about 6 | Contradicts the content-versus-order point; move to Related Work with that caveat |
| MemCredit and the fourth system in the opening list | about 1 | Three examples are enough |
| "What we do not claim", 7 items and 10 citations, shortened to 2 lines: "The concordance measure, the discount rules and the sequential test are classical (§2); what is new is the measurement, the decomposition and the benchmark." | about 8 | Defensive density; move the citations to Related Work |
| Contribution 2's "The ingredients are classical …" and contribution 4's "may come out null; we report it either way" | about 4 | Move to Related Work and Limitations |
| Abstract sentence 3, split | n/a | About 75 words, four clauses |
| **Add instead:** "What we find" paragraph and the new Figure 1 | uses the freed space and the ~1 page of slack | |

---

## Text that reads as machine-written (risk under the AI-quality screen)
ICML 2027's Generative-AI policy requires disclosure and says that misrepresenting AI use can lead to desk rejection. I did not find the word "slop" on the CFP or Author Instructions pages. However, the two-stage process explicitly targets low-quality papers. This draft's AI statement discloses AI use for proofs, code, analyses and drafting. Combined with the tells below, that will prime a skeptical first-stage reader.
1. **A formula opening:** "A garage keeps a box of repair tips… The mechanic is replaced. Do the old scores still point the new mechanic to the best tips?"
2. **Aphoristic short declaratives:** "These scores are earned under one model, and the model does not stay." / "Published numbers suggest the order does not always carry over." / "There are risks." (Impact).
3. **The same novelty disclaimer five times:**
   - "we cite them as such" (contribution 2)
   - "which we do not claim" (§2)
   - "only the tested quantity (…) and the keep-or-drop decision are new" (§2)
   - "Both additions apply existing statistics to a new quantity and a new decision" (§5)
   - "new are only the tested quantity and the keep-or-recalibrate decision" (§5)
   Say it once, in §2.
4. **A list-everything abstract sentence** (sentence 3) that strings four contributions with semicolons and "and".
5. **Controlled-vocabulary coinages that read oddly at ICML:**
   - "makers" → "providers"
   - "graded by program" → "automatically graded (execution / exact match)"
   - "a check that stops once it is sure" / "stop-when-sure check" → "anytime-valid sequential test"
   - "the old scores still order the items" → "rank"
   Keep "owner/reader" and "swap day"; they are good.
6. **Defensive asides:** "which we call a moving average, not Q-learning"; "A failed drop test is never reported as 'no drop'" appears twice (§3 and App. B).
7. **A stat-dump motivation** (four systems, three statistics, one quote in two paragraphs), which looks like literature synthesis rather than argument.

## Sentences that overclaim
| Sentence | Problem | Fix |
|---|---|---|
| "yet no study has tested this item by item" (abstract) | Universal negative in a crowded 2026 area | "we found no study that holds content fixed and tests this item by item" |
| "a law of score transfer" (abstract, contribution 2, §4 title) | An identity plus one assumption; the authors themselves say "the ingredients are classical" | "transfer decomposition" / "a parameter-free account" |
| "the law predicts the swap validity of each pair" | γ̂ uses the reader's results on the same items, so it is not usable before the swap; and a "mean gap" is quoted for "each pair" | "accounts for each pair's validity (MAE [a] vs no-change [b])" |
| "score any new rule offline" (abstract, contribution 1) | Only rules that re-rank the 4 stored candidates shown alone | "any rule that re-ranks stored items" |
| "needs a median of [M] fresh-check tasks, against 8 to 64 checks for fixed rules" | Mixed units; implies the fixed rules achieve the same error control | Units consistent; state the fixed rules' false-keep rate |
| "Published numbers suggest the order does not always carry over" (followed by CHIME) | CHIME is end-task success, so it cannot show order | Lead with the Beyond Gain ρ; drop CHIME here |
| Impact: "a way to check, **before** and after such a swap" | "Before" rests on the forecast, which is likely null | "after a swap, and what that check costs" |
| "compare eight swap-day rules" | Nine rules plus five references are listed | Count them |

## Formatting, anonymity and completeness risks
- **TODOs: blocking.** `main.pdf` (submission mode) shows **49 red TODO markers**, 9 of them in the main body: setup legs, three figure and table captions, Discussion, Accessibility, Software and Data, and the AI statement. It also shows the red "NOTE FOR THE HUMAN AUTHORS" box. Any of these at first stage means rejection as incomplete.
  - Appendix stubs: datasheet, licences ("per team notes", BIRD licence unresolved: CC BY-SA vs CC BY-NC), prompts, pre-registration identity, release checklist, cost table.
  - The DEB type asks authors to "clearly state what scientific claims the benchmark supports" and to address licensing. Release-checklist item 1 (one-sentence construct) is still a TODO.
- **AI Disclosure Statement.** It is required (CFP 2027) and present, but it contains three TODOs and an unverified claim ("Every reference was resolved…"), and it says the human-author statements must be true at submission. Misrepresentation is a desk-rejection ground. Finalise it truthfully and name the tools and versions. The heading "AI Use Statement" follows the kit; the CFP calls it the "AI Disclosure Statement", so consider matching that wording.
- **LaTeX comments.** They contain process notes and internal paths: "owner's rule", "Theory worker, 23 Nov 2026", "paper worker", "NOTE FOR THE HUMAN AUTHORS: this draft was written by an AI assistant", `prediction/PREREGISTRATION.md`, `research_notes/Model swap benchmark ICML plan/…`, `runs/sim/…`, `msr/*.py`. They do not appear in the PDF, but they would leak if `paper/` goes into the supplementary zip or onto arXiv. Strip comments (e.g. with arxiv-latex-cleaner) before any source upload.
- **PDF metadata: clean.** Author is "Anonymous Authors". No user names or home paths appear in `main.pdf`, `dryrun.pdf` or the figure PDFs (checked with `strings`). The figure PDFs carry only Matplotlib creator tags.
- **Links.** "Released under an anonymous link at submission" is a TODO. Use an anonymised host (e.g. anonymous.4open.science), with licences and names stripped from the code, as the Author Instructions require.
- **Page limit.** The main body ends partway through page 7 of 8, so it is OK, and there is room for the new Figure 1 and the findings paragraph. Re-check after the Discussion is written; with no slack added, a filled Discussion plus Figure 1 should still fit.
- **Citations of anonymous OpenReview submissions** (Anonymous 2026a/c/d, one of them desk-rejected) are allowed. However, three of the four "closest" works are unrefereed anonymous submissions. Table 7's footnote says those cells "rest on their abstracts and author responses"; a reviewer will discount that.
- **Mandatory sections present:** Impact Statement, AI statement, Accessibility, and Software and Data are in kit order. "Preliminary work. Under review by ICML. Do not distribute." appears in the footer.
- **Notation consistency:** see the list in Step 2, item 4 (family/maker, θ/T, keep-or-drop/recalibrate, units).

## Bottom line for the SAC
Advance to full review. The question is new, sharp and practically important; the design is unusually rigorous for the area; and the reusable probe table fits the Datasets, Evaluations and Benchmarks type. The risk is in the presentation, not the science. As written, pages 1–2 do not state the finding, do not show a figure, overclaim with "law", and read in places as machine-drafted. A stricter AC could reject it at the first stage on those grounds alone, so the rewrites above should be made before submission.

## Sources checked on the web
- [Goyal & Ray, Does Your Agent's Memory Survive a Model Upgrade? (arXiv 2609.05339)](https://arxiv.org/pdf/2609.05339)
- [Memory Reward Inflation in Self-Improving LLM Agents (arXiv 2608.00017)](https://arxiv.org/abs/2608.00017)
- [Learning on the Job (arXiv 2607.22157)](https://arxiv.org/abs/2607.22157)
- [Rosetta Memory: Adaptive Memory for Cross-LLM Agents (arXiv 2606.07711)](https://arxiv.org/abs/2606.07711)
- [ICML 2027 Call for Papers](https://icml.cc/Conferences/2027/CallForPapers)
- [ICML 2027 Contribution Types](https://icml.cc/Conferences/2027/ContributionTypes)
- [ICML 2027 Author Instructions](https://icml.cc/Conferences/2027/AuthorInstructions)
- [ICML 2027 Use of Generative AI by Authors](https://icml.cc/Conferences/2027/UseOfGenerativeAIByAuthors)
