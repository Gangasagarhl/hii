# Review R6 (round 2): statistics and theory

Reviewer R6: mathematical statistics (rank statistics and concordance, cluster-robust and multi-way inference,
ratio estimators and Fieller sets, multiple testing, sequential and anytime-valid tests, information lower bounds,
probabilistic forecasts).

What I read: `paper/dryrun.pdf` and its sources (`main.tex`, `sections/*.tex`, with the theory in `03b`, `03c`, `A8`,
`A9`, `A1`), the code under test (`msr/metrics.py`, `theory.py`, `sequential.py`, `forecast.py`, `analysis.py`),
`docs/power/size_theta_boundary.md`, `prediction/PREREGISTRATION.md`, and the CSV files under `runs/sim/analysis/`.
I did not read the authors' internal notes or earlier reviews.

All my computations are in `paper/reviews/round2/r6_checks/`. I wrote my own data-generating process
(`r6_dgp.py`; it is not the authors' simulator) and called the authors' functions only as the object under test.
Each check has a script and an output file (checks 1, 2 and 2b ran before a seed-order fix in `r6_dgp.py`; they are
reproducible in distribution, not bit for bit):

| check | script | output |
|---|---|---|
| 1 theta, Cw, Fieller sets | `c1_theta_fieller.py` | `c1_theta_fieller_output.md` |
| 2 two-way variance and the factor 1.03 | `c2_twoway_size.py`, `c2b_followup.py` | `c2_twoway_size_output.md`, `c2b_followup_output.md` |
| 3 the 15-test Holm family and the decision words | `c3_holm_family.py` | `c3_holm_family_output.md` |
| 4 transfer decomposition and its test | `c4_decomposition.py` | `c4_decomposition_output.md` |
| 5 the paired betting test | `c5_betting.py` | `c5_betting_output.md` |
| 6 the information lower bound | `c6_bound.py` | `c6_bound_output.md` |
| 7 the forecast test F1 | `c7_forecast.py` | `c7_forecast_output.md` |
| 8 level-corrected log score, swap-minus-home | `c8_level_correction.py` | `c8_level_correction_output.md` |
| 9 dry-run numbers against the CSVs | `c9_numbers.py` | `c9_numbers_output.md` |

The numbers in the dry run come from simulated models. I did not mark the paper down for that. For each main
claim I say below which pattern in the real results would make it fail.

---

## 1. Summary

The paper builds a benchmark (ScoreSwap) to ask whether per-item usefulness scores that an agent memory earned
under one language model still rank the same items for another model. Eight models from four makers write and
score their own banks; probe tables record every reader's graded result with each of the owner's four candidate
items shown alone. The headline is the retained ranking signal theta = sum V_swap / sum V_home, where V(tau) is a
signed, linear-in-outcomes within-task concordance numerator. On top of this the paper offers:

1. a 15-member Holm family per swap group (a drop test theta < 1 and a no-material-drop test theta > 0.75 as
   separate one-sided members, plus three rule comparisons), with a two-way (task by item) cluster-robust variance,
   Fieller intervals and a fixed inflation factor 1.03 of every two-way standard error;
2. a "transfer decomposition" E[a delta_t] = gamma E[a delta_s] + L, with a score-free slope gamma estimated from two
   independent owner sessions, and a specification test of L = 0;
3. a paired betting test (test martingale, Ville) for a keep-or-drop decision on swap day, and a Wald/Kaufmann-type
   information lower bound on the number of tasks any such decision needs;
4. a pre-swap forecast of theta from error consistency, tested once by double semi-partialling over 384
   maker-preserving relabellings;
5. prediction-quality comparisons on a level-corrected log score, as swap-minus-home contrasts.

My overall reading. The measurement design is careful and the bookkeeping is unusually good: every one of the 1,158
number macros I could trace reproduces its CSV source at printed precision, and every hand-written constant of the
appendix that I recomputed is right. The classical identities are correct. But several formal statements are
wrong as written because a sign condition is missing; the size claim for the two-way variance is specific to the
authors' own worlds and fails in mine when the variance is driven by a few items; the factor 1.03 is presented as a
small-sample correction when the authors' own table shows it corrects Monte-Carlo noise; the "home signal too weak"
flag is implemented three different ways although the text and the pre-registration describe one; the
decomposition's "account" is an in-sample consistency check whose advantage over the same-information baseline is
nil in the dry run; and the abstract's sentence on the lower bound says more than the theorem proves. None of
these is fatal, all are fixable, and most fixes are a sentence or a condition. The bigger question for ICML is
significance: the statistics are classical by the authors' own account, so the contribution stands or falls with
the real measurement, which does not exist yet.

---

## 2. Every formal claim, with my verdict

Verdicts: **correct**; **correct, missing condition** (true once a condition is added; the counter-example shows
the condition is needed); **wrong** (false as stated); **over-stated** (true in a narrower form than written);
**unclear** (cannot be checked as written). "Cn" = my check n.

| # | Claim (place) | Verdict | Evidence |
|---|---|---|---|
| 1 | theta = sum V_swap / sum V_home; "1 keeps all of the home signal, 0 none, < 0 reverses" (Sec. 3.2, eq. theta) | correct, missing condition | Needs V_home > 0 in the population. With V_home < 0 the sign reading inverts (C1a). |
| 2 | "V is linear in the outcomes, so outcome noise does not bias it"; theta "does not move with the new model's outcome noise" (Sec. 3.2, intro) | correct (first moment only) | Verified; theta-hat is a ratio of sums with O(1/n) bias and a noise-dependent variance; the text in A8 says so, the intro does not. |
| 3 | Prop. 3.1: Cw = 1/2 + sum V/(2 sum W) = (1 + Gamma)/2 exactly, Gamma the pooled within-task Gini correlation; E[V | tau] = sum a delta_t for any repeats and dependence (03b, A8) | correct | My own midrank code: largest error 0 (to machine precision) over 200 random tables with score and outcome ties (C4i). "Pooled" means a ratio of pooled covariances, weighted by candidates per task; say so. |
| 4 | "with unit weights on the pairs whose outcomes differ" Cw is the within-task Harrell's C; 2Cw - 1 a stratified Somers' D (Sec. 3.2) | over-stated | Holds for one repeat (0/1 outcomes). With two-repeat means the weights are 0, 1/2, 1 and Cw is a weighted C, not Harrell's. |
| 5 | R = theta W_home / W_swap (Sec. 3.2, eq. law) | correct | Exact identity on the same pairs; largest error 1e-15 (C4i). |
| 6 | Prop. 3.2: E[a delta_t] = gamma E[a delta_s] + L; theta -> gamma + L / E[a delta_s] (03b, A8) | correct, missing condition | The identity is definitional. The limit needs E[a delta_s] != 0 and i.i.d. tasks; "E over a pair drawn uniformly within a task" equals the sample's pair-weighted limit only if every task has the same number of candidates. |
| 7 | "L = 0 iff the IV slope (instrument a) equals the LS slope gamma"; a specification restriction (03b, A8) | correct | Verified. |
| 8 | "if the reader's chance is an increasing function of the owner's ... abs(theta - gamma) stays below 0.035 for readers within one logit" (03b body; A8) | over-stated | Reproduces in the authors' default owner world (+0.034). In my owner worlds with hard tasks (mean logit -1.8) or easy, item-dominated tasks, a reader ONE logit away misses by 0.133-0.136 and half a logit by 0.034-0.059 (C4v). The bound is a property of one world, not of monotone readers. |
| 9 | gamma-hat = C_on / C_oo consistent with dependence inside a session (A8 i) | correct | Verified algebraically under (A2). In the dry run gamma-hat is below the simulator's truth in 10 of 12 swaps (same-maker mean 0.521 against 0.694; C9): not a proof of bias (pairs are dependent, 11 of 12 intervals cover), but my moderate-signal world shows the same direction (median 0.48 against 0.60, C4iv): a ratio with a noisy cross-session denominator. Report it; do not print it beside "truth 0.69" without comment. |
| 10 | gamma not identified with one repeat in total (A8 ii) | correct | The construction mu_s + xi works (needs mu_s away from 0 and 1, stated). |
| 11 | Fieller sets for theta and gamma "covered the true gamma in 94.5-97% of 200 simulated worlds" (A8 iv) | correct (in my worlds too) | C1c: registered Fieller set covered 0.94-0.98 at home z from 11 down to 1.8; 59% unbounded at z = 1.8. Note the code returns (-inf, inf) whenever the quadratic's leading term is <= 0, also when the true Fieller set is two rays excluding an interval: conservative, loses information. |
| 12 | Q = V_swap C_oo - C_on V_home "is centred under L = 0 however weak the denominator" (A8 v) | correct to first order | E[Q] has an O(n) term from the owner's session-1-2 noise shared by V_home and C_on, against O(n^{3/2}) SD: negligible. In my L = 0 world the two-way test has mean z +0.02, SD 0.84, rejection 0.027 (C4iii): valid, conservative. |
| 13 | "a parameter-free consistency check"; the comparison "needs ... no fitted number" (03b l.23, Sec. 5 l.26) | over-stated | gamma-hat is a fitted slope (one per pair) computed from the reader's results on the same tasks; the "prediction" also uses W_swap from the same results. It is an in-sample consistency check with no tuned constant. |
| 14 | The decomposition "accounts for each pair's swap concordance with MAE 0.030 against 0.111 for no change and 0.030 for rho alone" (abstract, intro, Sec. 5) | over-stated | Its error is the sampling noise of theta-hat - gamma-hat times V_home / 2 W_swap. In my linear worlds (L = 0 exactly) it never beats R = gamma-hat by more than 0.001, beats R = rho-hat only when rho != gamma, and loses to "no change" in 3 of 4 settings (0.030-0.035 against 0.012-0.026) whenever the reader's noise happens to offset the loss (C4iv). In the dry run it ties R = rho-hat. MAE is not evidence of an "account". |
| 15 | "If L = 0 for every family, theta is the same for all of them" (A8, score families) | correct | Verified. |
| 16 | Prop. A.1 Invariance (monotone maps; count discounting = Beta(1/lambda, 1/lambda) prior; a pair switches at most once, at lambda*; the mix weight) | correct, missing boundary case | Brute force over 20,000 random count pairs: the pairs fixed_lambda reverses are exactly those with lambda* in (lambda, 1), 0 exceptions; in 62 more pairs lambda* = lambda and the discounted scores tie, which also changes V and Cw (C4ii). The example (lambda* = 0.25; 0.600 vs 0.571) checks. |
| 17 | Gaussian forms (Sheppard arcsin, (1 + r)/2, attenuation) (A8) | correct | Classical; the 0/1-outcome misses are simulation numbers, labelled exploratory. |
| 18 | Buhlmann break-even k > eta_t rho^2 n / (eta_s + (1 - rho^2) n) (A8) | correct, missing condition | Algebra verified; it requires k fresh draws per item, whereas the paper's k is a total budget over a 250-item bank (well under one check per item). |
| 19 | Prop. 3.3 (Error control): keeps with probability <= alpha whenever theta <= 0.75 and drops with probability <= alpha whenever theta >= 0.25, at every stopping time, with the home signal estimated (03c, A8) | correct, missing conditions | (a) Needs A_home > 0: with A_home = -0.10 and theta = +0.02 the test keeps in 0.999 of streams (C5c). (b) Needs a fresh, independent home result per drawn task; when a finite stored home table (2 repeats per cell) is reused beyond its size, false keeps at theta = 0.75 exactly reach 0.13 by 3,000 tasks and 0.20 by 6,000 (C5d). With i.i.d. tasks and fresh home results it holds (0.025 by 3,000 tasks, C5a); drawing without replacement from the pool is more conservative than with replacement in every pool I tried (C5b). |
| 20 | "The rule with thresholds 0.75 A_home-hat ... is not valid when A_home-hat is estimated" (03c) | correct | Standard. |
| 21 | theta = A_swap / A_home with A = V/M (03c l.3) | correct, missing condition | Only when every task has the same number of candidates: one 4-candidate and one 3-candidate task give 0.000 from V and -0.250 from A (C1a). True under rule 1.6 with four candidates; say it. |
| 22 | Theorem 3.4 (Information limit): any decision with false keep <= alpha at theta_0 and keep >= 1 - beta at theta_1 needs E N >= d(1 - beta || alpha) / K*; K* to second order (theta_1 - theta_0)^2 A_home^2 / (2 E sigma_tau^2) (03c, A8) | correct, missing condition | Proof correct (Wald identity + data processing, KKT of the least-favourable table; my own solver matches `least_favourable` to 6 digits, C6a). "Any decision" must read "any decision that checks every candidate of uniformly drawn tasks once": rules that choose which cells to check face a bound 1.24-1.56 times lower (C6b). sigma^2 is the within-task Bernoulli variance, not the variance of A the data show, so the bound is loose by the between-task variance (the paper's own "about twice"). |
| 23 | "In a task model with A_home = 0.20, no valid decision with 16 tasks keeps a lossless swap more than 15% of the time"; 191/439/548 tasks; K* = 0.0043; fixed z test about 700 (03c, A8) | correct | All reproduce (C6a, C9). The fixed paired z test needs 899, which the text does not say. |
| 24 | "No keep-or-drop decision with 5% error control can be made with a few checks: at this signal any such rule needs at least 262 tasks" (abstract l.10, intro) | over-stated | 262 is a plug-in, second-order estimate of the bound (sequential_bound.csv, table_plugin, bound_tasks_chi2) with no uncertainty; it is design-, margin- and signal-specific (C6b, C6c); the sentence exceeds the wording registered in prereg 11.4.12 (l.1456). |
| 25 | "the paired test needs about twice the bound" (03c, A8) | correct in the reviewer model only | 896 / 439 = 2.04 there; at the dry run's signal 720 / 262 = 2.75 (C9). |
| 26 | Holm over 15 members controls FWER; "worst familywise error 0.0499" (A9) | correct but uninformative | Holm controls FWER under any dependence once each member's p is valid; the simulation re-proves Holm's theorem. The exposure is the members' own size (C3a): with the factor, FWER stays <= 0.05 only while the true SD of the null z is <= about 1.03-1.05; at 1.10 it is 0.065-0.081. |
| 27 | "The two PC1 hypotheses of a group are disjoint, so at most one is true" (prereg 5.1, A9) | correct, missing condition | Only if V_home > 0. With V_home < 0 both linear nulls "V_home - V_swap <= 0" and "V_swap - 0.75 V_home <= 0" can be false at once, and the NI test can reject with theta-hat negative: theta-hat = -0.31, p_NI < 1e-4, category "no material drop" from `msr.analysis.theta_category` (C1a). |
| 28 | Decision word "material drop" (drop test rejects and theta-hat <= 0.75) (A9, prereg PC1) | over-stated | No test of theta < 0.75 stands behind the word. With true theta = 0.80 it is printed in up to 0.24 of replications, at 0.76 in up to 0.42 (C3b). |
| 29 | Two-way variance V_task + V_item - V_both with multiple membership (A9, A8 iv) | correct as an estimator | The code (`_twoway_forms`) sums psi_i psi_j over pairs related by task or by a shared item: the right union form. Its downward bias with few effective item clusters is not addressed (item 30). |
| 30 | "Every two-way standard error is multiplied by a fixed small-sample factor of 1.03; ... the one-sided tests of theta then rejected in at most 0.049 ... (0.055 without it)" (A9 l.12) | over-stated, and the reason given is wrong | (a) In the authors' own 20 configurations the unscaled size averages 0.0499; the maximum 0.0546 is what the largest of 20 estimates with MC SE 0.0025 is expected to be (0.05 + 1.87 x 0.0025 = 0.0547). The data show no SE shortfall to correct; the factor is a conservative inflation equivalent to testing at 0.045. It is not a small-sample correction (the authors' t and CR1 corrections changed nothing). (b) In my worlds where a few items carry the variance, the null z has SD 1.09-1.29 and the one-sided size with the factor is 0.057-0.088 (C2, C2b). |
| 31 | Task-only bootstrap and the earlier coverages (A9) | not checked | Secondary. |
| 32 | F1 "held its level in five null worlds"; "a capability effect curved in both arrays inflates its level to about 0.1" (A8 forecast) | correct in my null worlds except one | My worlds: 0.052, 0.035 (heavy-tailed ratio noise), 0.050, 0.046; a null world where theta depends on whether the owner is the newer model of its maker gives 0.064 pooled over 4,000 worlds (SE 0.004) (C7). Double semi-partialling is approximate, not exact. |
| 33 | Level correction: "the shared level error this leaves cancels in the differences between rules to first order" (A1) | correct (first order) | Verified: d LS / d delta = mean(y - p*), equal across rules with equal mean p*; the second-order term differs by rule. |
| 34 | Swap-minus-home: "what a rule gains at home anyway does not count as an effect of the swap" (Sec. 3.3) | over-stated | With perfect transfer and only a base-rate difference between owner and reader, the PC3 contrast is -0.013 to +0.012 nats per check (C8), the size of the registered minimum detectable effect (0.003-0.014, prereg 6.3). It identifies a swap effect only under an additivity assumption that is not stated. |
| 35 | "flag on which no primary test and no interval depends"; "used in three places only" (Sec. 3.2, A9 l.39) | wrong as implemented | The forecast's F1 selects swaps by a same-task 4-SE rule (`msr/forecast.py` l.415), and the keep-or-drop headline set uses a 4-SE rule on the truth half (`msr/sequential.py` l.1375), not the calibration flag the text and the pre-registration describe. |
| 36 | Estimand conditioning: "everything is conditional on the owner's bank" (A8 Setting) vs "tasks and items are treated as drawn from their populations" (A9, prereg 4.1) | unclear | Two different estimands. In my world a 60-item bank alone moves theta with SD 0.08 around the item-population value (C1b). The betting test's null is the fixed-bank theta, the primary tests target the item-population theta. |
| 37 | "All tests are fixed in a (dated) pre-registration" (Sec. 3.3 l.57; A9 l.4) | wrong at the time of review | `prediction/PREREGISTRATION.md` l.3: "Status: DRAFT. Not frozen."; A7 has a TODO for the freeze date. |

---

## 3. Strengths

1. **The headline is the right statistic.** theta = sum V_swap / sum V_home is linear in the outcomes in numerator and
   denominator, so its population value does not move with the reader's outcome noise. The exact identity
   R = theta W_home / W_swap (claim 5) shows cleanly why the obvious ratio of concordances is confounded. Both tests
   are on linear contrasts (no noisy denominator inside a test), and the interval is a Fieller set that inverts the
   same test. This is textbook-correct and well argued.
2. **The classical results are stated with their sources and are right** (claims 3, 5, 7, 10, 15, 17, 23, and 16 up to a
   boundary tie): I re-derived and re-computed every one.
3. **The cross-session estimator of gamma** (owner sessions 1-2 against 3-4) is a good design choice: it is unbiased
   under within-session dependence (caching), which a within-session U-statistic is not. The non-identification
   argument with one repeat is correct and useful.
4. **The paired betting test fixes a real flaw** of plug-in thresholds: with the home value estimated, the pairing
   puts the home sampling error inside D. Under the stated conditions it is valid, and conservatively so (C5a, C5b).
5. **The withdrawn min(p, p) device** is correctly diagnosed; separating drop and no-material-drop into two members is
   the right fix.
6. **Bookkeeping.** 1,158 of 1,158 machine-traceable number macros in the dry run match their CSV rows at printed
   precision, and the 15 strings I sampled from the abstract and body appear in the PDF (C9). The hand-written
   constants of A8 (K* = 0.0043; 191 / 439 / 548 tasks; 765 / 1,758 / 2,191 checks; best keep rates 0.08 / 0.10 /
   0.12 / 0.15; forced false keeps 0.74 / 0.72 / 0.68 / 0.63; simulator truth 0.69 and 0.30) all reproduce.
7. **Honest framing in many places**: a failed drop test is never "no drop"; the self-swap hurdle only makes claims
   harder; "inconclusive" is a first-class outcome; the limits of the specification test are listed in A8.

---

## 4. Weaknesses (most serious first)

Each item is labelled **[wrong]**, **[over-stated]** (true but claimed more broadly than shown) or **[unclear]**.

### W1 [wrong as stated] Two propositions and two tests need a positive home signal, and none of them checks it
*Where:* Prop. 3.3 (03c), its proof (A8), PC1-NI (Sec. 3.3, A9, prereg PC1), the per-pair Holm flags, `msr.analysis.theta_category`.
The hypotheses "theta <= 0.75" and "V_swap - 0.75 V_home <= 0" are the same only when V_home > 0; the drop test
likewise. Neither test takes a gate (the authors' ruling of 24 Nov), so the code turns a negative home signal into a
positive claim.
*Counter-examples (mine):* (i) mean V_home = -0.24, mean V_swap = +0.08: theta-hat = -0.31, p_NI < 1e-4, decision
"no material drop" (C1a). (ii) Keep-or-drop with A_home = -0.10, A_swap ~ 0 (theta = 0.02): KEEP in 0.999 of streams
(C5c). The PC1 pair is "disjoint" (prereg 5.1) only under the same condition.
This is not academic: the per-pair tests (112 Holm members) run on single swaps, where an owner with a weak signal
can show a negative home value by chance, and nothing stops the word "no material drop" from being printed then.
*Fix:* state A_home > 0 (V_home > 0) as a condition in Prop. 3.3 and in PC1; make it operational: run both PC1 tests
and the keep-or-drop rule only when the calibration-task flag says the home signal is positive (it is computed on
separate tasks, so it does not select on the estimate's noise), and otherwise report "not testable"; in
`theta_category`, never print "no material drop" or "drop" with theta-hat <= 0.

### W2 [over-stated; the stated reason is wrong] The factor 1.03 and the size claim "at most 0.049"
*Where:* A9 l.12; prereg 4.1 (l.683-695); `msr.metrics.TWOWAY_SE_FACTOR`; `docs/power/size_theta_boundary.md`.
(a) The authors' own size table (20 configurations, MC SE 0.0022-0.0031) has an unscaled mean size of **0.0499**.
The maximum, 0.0546, is exactly what the largest of 20 unbiased estimates is expected to be. Their own z-statistics
have SD 0.98-1.02. There is no measured SE shortfall; the factor brings the maximum of noisy estimates under 0.05. It is a
conservative inflation equivalent to testing at 0.045, and that is fine, but calling it "a fixed small-sample
factor" mislabels it: the authors' own small-sample corrections (t reference, CR1) moved nothing.
(b) More important, the claim "at most 0.049" holds in the worlds it was tuned on, not in general. In my worlds
(`r6_dgp.py`: linear probabilities, theta known exactly, items sampled):

| my world | SD of null z (95% CI) | one-sided size with x1.03 |
|---|---|---|
| base, 250-item banks | 0.94-0.95 | 0.03-0.04 |
| few popular items (60-item banks, Zipf 1.2) | 1.10 (1.02-1.20) at theta = 1, 1.02 at 0.75; new seeds: 1.00, 1.07 | 0.067, 0.047; new seeds: 0.032, 0.044 |
| item-dominated (40-item banks) | 1.09 (1.01-1.19), 1.09 (1.01-1.18) | 0.063, 0.057 |
| item-dominated, items shared across orders | **1.29 (1.19-1.42)**, 1.23 (1.14-1.36) | **0.088**, 0.088 |

(C2, C2b; 250-300 replications per row.) When a few items carry most of the variance the effective number of item
clusters is small and the two-way CRVE is biased down, as one-way CRVEs are with few clusters; "hundreds to thousands
of effective clusters" counts task clusters, not the item clusters that matter. Coding items per order (the code's
`owner|stream|order|item`) when the same write task recurs as an item in two orders' banks added little in my worlds
(SD 1.29 against 1.28 with true identities), so that is not the problem.
*Fix:* call 1.03 what it is ("we test at 0.045 to leave room for Monte-Carlo error in our size study"); report the
item share of the variance and an effective number of item clusters (e.g. Carter-Schnepel-Steigerwald) for every
primary test; when the item share is large or the effective item count small, use a CR2/Bell-McCaffrey-type
correction or a wild cluster bootstrap over items; state the size claim as "in our design worlds".
*Pattern in real results that makes the headline intervals fail:* a large `item_share_of_variance` in
`primary_tests.csv`, heavy retrieval hubness (a few items as candidates on many tasks), or banks whose candidates
concentrate on few items.

### W3 [wrong as implemented] One flag in the text, three rules in the code
*Where:* Sec. 3.2 ("a flag on which no primary test and no interval depends"), A9 l.39 ("used in three places only"),
prereg 2.4, 11.3.3 (l.1309), 11.4.2 (l.1365), 11.4.6 (l.1397); code `msr/forecast.py` l.415, `msr/sequential.py` l.1375, l.1632.
The text and the pre-registration define one reporting flag (owner's calibration tasks, z >= 2). The forecast's
registered test F1 instead keeps only swaps whose home signal passes a **same-task 4-SE rule** on the evaluation
tasks (the very rule the authors withdrew because it "selects on the estimate's own noise"), and the keep-or-drop
headline rates (`CheckAuditSixFourFalseKeep`, `CheckHomeOkUndecidedInTable`, in the abstract) use a **4-SE rule on the
truth half**. So the flag decides which swaps enter F1 (a fourth use) and defines the headline set of the replay
differently from what was registered.
*Fix:* one function, one rule, used everywhere, and the text's list of uses made complete.

### W4 [over-stated] The abstract's lower-bound sentence
*Where:* abstract l.10, intro "What we found", Sec. 3.4, Theorem 3.4.
"No keep-or-drop decision with 5% error control can be made with a few checks" needs four qualifiers that the
theorem has and the sentence drops:
1. **design:** the theorem covers rules that check every candidate of uniformly drawn tasks once. Rules that choose
   which (task, candidate) cells to check, importance-weighted so they still test the population theta, face a bound
   1.24 (authors' model), 1.31 and 1.56 times lower in my task models (C6b). The gap is modest, which supports the
   qualitative point, but "any rule" is not what was proved;
2. **margin:** at the registered margin (theta_0 = 0.75 against theta_1 = 1). For "does any signal survive"
   (theta_0 = 0) the bound is 16 times smaller: at A_home = 0.2, 43 checks (C6c);
3. **signal:** the bound scales as E sigma^2 / A_home^2; at A_home = 0.4 it is 171 checks at the registered margin;
4. **estimation:** 262 is a plug-in, second-order estimate (`sequential_bound.csv`, setting `table_plugin`, column
   `bound_tasks_chi2`); a bound estimated from data needs an interval (A_home-hat enters squared).
The pre-registration (11.4.12, l.1456) allowed exactly the qualified sentence: "no rule with error control alpha can
keep a swap that lost nothing with probability 0.8 in fewer than B tasks at this signal".
*Fix:* use the registered sentence with "for rules that check every candidate of randomly drawn tasks", give an
interval for B (bootstrap the plug-in), and add one line on margin and design.
*Pattern in real results that makes it fail:* a strong home signal (A_home >= 0.4 in the real tables) makes B small
(tens of tasks), and the paragraph's message reverses.

### W5 [over-stated] The decomposition's "account of the loss"
*Where:* abstract, intro, contribution (iii), Sec. 3.5 l.23, Sec. 5 l.26, Fig. 2, prereg 11.2.4 (l.1263).
1. The "prediction" 1/2 + gamma-hat V_home / (2 W_swap) uses the reader's results on the same tasks twice (in
   C_on and in W_swap). It is an in-sample consistency check of theta-hat against gamma-hat, not a prediction, and
   gamma-hat is a fitted slope: "no fitted number" and "parameter-free" should go.
2. The MAE horse race measures noise, not an account. The decomposition's error is the sampling error of
   theta-hat - gamma-hat scaled by V_home / 2 W_swap, and gamma-hat has a noisy denominator (the cross-session product).
   In my linear worlds, where L = 0 holds exactly (C4iv): the decomposition never beat R = gamma-hat by more than
   0.001; it beat R = rho-hat only where rho differs from gamma; it LOST to "no change" in 3 of 4 settings
   (0.030-0.035 against 0.012-0.026) whenever the reader's lower noise happened to offset the loss; and gamma-hat's
   median was 0.48 against a true 0.60 at moderate signal (compare the dry run: 0.52 against 0.69). "No change" uses
   no reader data, so it is the wrong comparator in either direction; the registered criterion for "specification
   supported" (prereg 11.2.4) nevertheless uses it as the only one. In the dry run the decomposition ties
   R = rho-hat (0.030 against 0.030).
3. The specification test is not a test of "linear transfer of item usefulness". In my worlds item usefulness
   transfers exactly linearly in all three cases, yet L = 0, +0.125 and -0.075 in theta units depending only on how
   the task-by-item usefulness transfers; the test holds its level at L = 0 (rejection 0.027) and moves in the
   predicted direction otherwise (mean z +0.55 and -0.18 at 4 swaps x 900 tasks, rejection 0.080 and 0.067), so with
   the cross-maker group's data it will reject for that reason alone (C4iii). A8 lists this cause; the body and the
   abstract do not.
*Fix:* compare with R = rho-hat and R = gamma-hat by a paired test, registered as the criterion; drop "accounts for";
rename the test "specification test of L = 0" and say in the body that a rejection can come from task-specific
usefulness.
*Pattern in real results that makes the claim fail:* decomposition MAE not below that of R = rho-hat (as in the dry
run), or T1-diff rejecting in any group with enough tasks (likely in real LLM data, where task-by-item effects are
large).

### W6 [over-stated] "Material drop" is a label on a point estimate
*Where:* A9 (decision categories), prereg PC1, `theta_category`.
The word claims a loss of more than a quarter of the home signal, but no test of theta < 0.75 stands behind it; it
is the drop test plus theta-hat <= 0.75. With true theta = 0.80 and SE 0.10 it is printed in 0.24 of replications;
at 0.76 in up to 0.42 (C3b). With a 4-swap group the word can be printed with an interval that contains 0.75.
*Fix:* add the one-sided test of H0: theta >= 0.75 (linear statistic 0.75 V_home - V_swap) to the family, or print
"drop (point estimate below 0.75)". The three-way reading is otherwise coherent when V_home > 0: "material drop" and
"no material drop" cannot both fire, and drop + no-material-drop reads as "small drop".

### W7 [over-stated] What the swap-minus-home contrasts PC3 and PC4 identify
*Where:* Sec. 3.3 ("so that what a rule gains at home anyway does not count as an effect of the swap"), A1, A9,
prereg PC3-PC4.
The contrast is a difference-in-differences across two outcome distributions (owner and reader). It isolates a swap
effect only if the gain of fixed_0.5 over keep is additive in "home gain" and "swap effect". With perfect transfer
(the reader's chances are the owner's shifted by d logits), the expected contrast is -0.013 to +0.012 nats per check
as d and the memory effect vary (C8), the size of the registered minimum detectable effect. Two sources: the benefit
of shrinking depends on the base rate, and the registered level target (the reader's no-memory success) differs from
the reader's with-item success by the average memory effect.
*Fix:* state the estimand and the additivity assumption; report the owner-reader base-rate gap beside each contrast;
add a sensitivity analysis with the level target set to the reader's mean success with an item on the calibration
checks (which recal_k has anyway).

### W8 [correct, missing condition] What the keep-or-drop guarantee needs on swap day
*Where:* Prop. 3.3, A8, Sec. 3.4 ("which the probe tables hold").
The pairing needs the owner's home result on every drawn task, from the owner's model, which may be retired on swap
day. If the operator uses a stored table and reuses it beyond its size, the guarantee is for the table, not the
population: false keeps at theta = 0.75 exactly rise to 0.044, 0.131 and 0.199 by 1,000, 3,000 and 6,000 tasks with a
300-task store (C5d). The paper's own median at theta = 1 is 720 tasks, above the 300 tasks per order of the replay
stream. Without replacement from the store the test stays conservative (C5b), so the honest rule is "stop at the
store".
*Fix:* state in Prop. 3.3: tasks i.i.d. **and** each with its own home result; on swap day, the store caps the
budget.

### W9 [unclear] Which theta?
*Where:* A8 Setting vs A9 and prereg 4.1; Sec. 3.4.
The primary tests treat items as sampled (item-population theta); A8 conditions on the bank; the betting test's null is
the fixed-bank theta (tasks i.i.d. given the bank). In my world the bank alone moves theta with SD 0.08 for 60-item
banks (C1b). An operator cares about the fixed-bank theta; a paper about score types cares about the item population.
*Fix:* name theta_bank and theta_pop, and say which each procedure targets.

### W10 [over-stated] The forecast test F1
*Where:* A8 "The forecast before the swap", A13, prereg 11.3.8, `msr/forecast.py`.
(a) Double semi-partialling is approximate; in my null world where theta depends on whether the owner is the newer
model of its maker (upgrade/downgrade asymmetry, which this study expects and Q does not span) it rejects at 0.064
(4,000 worlds, SE 0.004) (C7). Add an owner-is-newer indicator to Q, or report that sensitivity. (b) The target is a
per-pair ratio estimate entering a Pearson partial correlation: one weak owner makes seven heavy-tailed values; the
test stays valid (0.035) but loses power. A rank-based or precision-weighted statistic is safer. (c) F1 selects swaps
by the same-task rule (W3). (d) Power at 8 models is low (0.26 at a partial correlation of 0.14 in my world; the
paper's 0.63 is at 0.3).
*Pattern in real results that makes it fail:* F1 rejecting while the same-maker downgrades and upgrades differ
systematically in theta (then the rejection may be the asymmetry, not error consistency).

### W11 [unclear] The pre-registration is not yet a pre-registration; the margin is not tied to stakes
*Where:* Sec. 3.3 l.57, A9 l.4, A7, prereg l.3, 6.1.
"All tests are fixed in a dated pre-registration" is not true today (draft, not frozen, revised on 23 and 24 Nov).
That is acceptable before data, but the sentence must wait for the freeze. The margin 0.75 is defended as an
"anchor-type smallest effect size of interest"; that is a label, not a reason. It is arbitrary, but it was set before
any real data and it is the same in the primary family and in the keep-or-drop rule, which is good.
*Fix:* freeze and deposit before paid runs; give the margin a meaning in success points (from the stakes table: what
first-shown success does theta = 0.75 buy relative to keep - wipe at home?).

### W12 [unclear] Smaller presentation issues that a statistician will trip over
1. "each group's ... between-pair standard deviation" (A9 l.29): `spread_sd_between` is 0.236 for PC1 and 0.048 for
   PC2 in all three groups (C9); it is one model-based SD, as prereg 5.2 (l.793) says, not a per-group SD.
2. theta = A_swap/A_home only with equal candidate counts (claim 21); Harrell's C only for one repeat (claim 4).
3. "per-task standard deviation 0.53" in A8 is the SD of A in a model without between-task variation; the theorem's
   sigma is within-task only. Say which.
4. Fieller "unbounded" printed as the whole line when the set is two rays (claim 11).
5. "simulator truth 0.69" printed beside gamma-hat 0.521 without comment (claim 9).
6. The fixed paired z test needs 899 tasks in the reviewer model, not 700 (that is the known-home z test); the
   paired sequential test's median (896) is about the same as the paired fixed test.

---

## 5. Pre-registration against the paper (five or more statements)

| # | Paper says (file, line) | Pre-registration / code says | Match? |
|---|---|---|---|
| 1 | "All tests are fixed in a (dated) pre-registration" (`03_benchmark.tex` l.57; `A9_statistics.tex` l.4) | "Status: DRAFT. Not frozen." (`PREREGISTRATION.md` l.3) | **no** |
| 2 | flag "used in three places only"; "no primary test and no interval depends" on it (`A9_statistics.tex` l.39; `03_benchmark.tex` Measures) | prereg 11.3.3 (l.1309) and 11.4.2/11.4.6 (l.1365, l.1397) say the Part 2.4 calibration flag; code uses a same-task 4-SE rule for F1 (`forecast.py` l.415) and a truth-half 4-SE rule for the replay (`sequential.py` l.1375) | **no** (code vs both) |
| 3 | "a fixed small-sample factor of 1.03" with size "at most 0.049" (`A9_statistics.tex` l.12) | prereg 4.1 (l.683-695): t and CR1 corrections changed under 0.0005; "These are design aids, not guarantees." | wording **no**; numbers yes |
| 4 | "each group's ... between-pair standard deviation" (`A9_statistics.tex` l.29) | prereg 5.2 item 3 (l.793): one source-and-target model SD plus the within-group SD of predicted pair effects; CSV value identical across groups | **no** |
| 5 | "No keep-or-drop decision with 5% error control can be made with a few checks" (`00_abstract.tex` l.10) | allowed wording, prereg 11.4.12 (l.1456): "no rule with error control alpha can keep a swap that lost nothing with probability 0.8 in fewer than B tasks at this signal" | **no** (goes beyond) |
| 6 | PC1-NI margin theta > 0.75; Holm over 15 (`03_benchmark.tex`, `A9`) | prereg 6.1, 5.1 | yes |
| 7 | P1, P2, P4 by exact permutation over 8! relabellings (`A9`) | prereg Part 7 | yes |
| 8 | Power (0.12 / 0.115 / 0.08; 0.85 / 0.85 / 0.79); gate home Cw >= 0.58 (`A9`) | prereg 6.3, 9.3 | yes |
| 9 | F1 over 384 maker-preserving relabellings (`A8`) | prereg 11.3.8 | yes |
| 10 | Bound 191 / 439 / 548 tasks in the reviewer model (`A8`) | prereg 11.4.10 | yes |

## 6. Dry-run numbers against the CSV files

1,158 macros with a machine-readable source were compared with their CSV rows at printed precision: **0 mismatches**
(`c9_numbers_output.md`). Ten I also checked by hand: theta upgrade 0.731 (`theta_groups.csv` 0.730878), downgrade
0.753, cross 0.204 (0.203504), cross interval 0.006-0.370; decomposition MAE 0.030 / 0.111 / 0.030
(`decomp_summary.csv`); bound 262 (`sequential_bound.csv`, table_plugin, bound_tasks_chi2 262.131); median 720
(`sequential_curve.csv`); audit false keep 0.646 (`sequential_rules.csv`); null error 0.040 (max 0.0398 of
`sequential_null.csv`); known-truth false keep 0.005 and false drop 0.019 (`sequential_simtruth.csv`); PC2 upgrade
0.0692 and PC3 cross 0.0704 (`primary_tests.csv`). All appear in the PDF text. Two remarks: the abstract's "left
1.000 of swap cells undecided" will read oddly in any outcome (write a percentage), and the between-pair SD is
not per group (W12.1).

---

## 7. What would make each main claim fail in the real data

| main claim | the pattern that breaks it |
|---|---|
| theta by group (abstract, Sec. 5) | calibration flag fails for several owners (Fieller sets unbounded); large item share of variance (W2); within-group pairs of opposite sign (the group theta then hides them); theta differing strongly by stream |
| "Old scores lose ranking signal mostly across makers" | cross-maker theta inside the same-maker intervals, or P4 failing |
| the decomposition accounts for each pair | MAE not below R = rho-hat or R = gamma-hat; T1-diff rejecting in any group |
| "no decision with a few checks" | real A_home >= 0.4, or a high share of tasks where candidates differ, making B tens of tasks |
| fixed audits' false keeps | most real swaps far from 0.75, so audits rarely err |
| keep vs wipe stakes (PC2) | swap - home stakes near zero with tight intervals: then the old order matters little either way |
| forecast F1 | rejection that disappears once an owner-is-newer indicator is added to Q (W10) |

---

## 8. Questions for the authors

1. Prop. 3.3 and PC1: will you add V_home > 0 as a condition and make the calibration flag a gate for the two PC1
   tests and the keep-or-drop rule? If not, what should a reader make of "no material drop" with theta-hat < 0?
2. Why is the unscaled mean size of 0.0499 in your own table read as an SE shortfall? What is the item share of the
   variance and the effective number of item clusters in your worlds and in the real tables?
3. Which flag will the final F1 and the replay headline use? Will the code be changed to the registered one?
4. What does theta = 0.75 mean in first-shown success points in the pilot? Is there a decision-theoretic reason for
   0.75 rather than 0.5?
5. In the dry run gamma-hat is below the simulator truth in 10 of 12 swaps (same-maker mean 0.52 against 0.69); in my
   moderate-signal world its median is 0.48 against a true 0.60 (C4iv). Is there a downward finite-sample bias of the
   cross-session ratio (a noisy, positively skewed denominator), and how large is it at the real study's size?
6. For the decomposition: will the registered criterion compare with R = rho-hat and R = gamma-hat rather than "no
   change"?
7. On swap day, where do the owner's home results come from if the owner is retired, and how large is the store
   relative to the expected stopping time?
8. PC3/PC4: how large is the owner-reader base-rate gap in the pilot, and does the contrast change when the level
   target is the reader's mean success with an item?
9. Which theta (bank or item population) does each procedure target, and which one does the abstract report?

---

## 9. Scores

| criterion | score | one line of reason |
|---|---|---|
| Soundness | 2 / 4 | Classical results correct; two propositions miss a sign condition with working counter-examples; the size claim for the two-way variance fails when items dominate; the code's flags differ from the text. |
| Presentation | 2 / 4 | Exceptional traceability of numbers, but the body is dense, several sentences claim more than the appendix proves (bound, decomposition, factor), and the vocabulary ("drop", "material drop", "flag") shifts between sections. |
| Significance | 2 / 4 | A useful, well-posed measurement for a narrow but real question; the value depends on real results that do not exist yet, and the statistical machinery is classical by the authors' own account. |
| Originality | 2 / 4 | The benchmark design (frozen content, per-candidate probe tables, paired swap-day test) is new; the measure, decomposition, sequential test and bound are classical, as the paper says. |
| Overall | 3 / 6 (weak reject) | The statistics are mostly right and fixable, but the paper overstates three of its formal contributions, and without real results the ICML case rests on the benchmark alone. |
| Confidence | 4 / 5 | I re-derived every proof and re-ran each claim in my own worlds; I did not audit the agent leg or the arms' code. |

## 10. What would move my Overall score

**Up by one (to 4, weak accept):** fix W1 (sign condition, gating), W3 (one flag in the code), W4 (qualified bound
sentence with an interval), W5 (decomposition compared with R = rho-hat and R = gamma-hat, no "parameter-free",
no "accounts for"), W6 ("material drop" tested or renamed), and relabel the factor 1.03 honestly (W2a), with real
results that are interpretable under the registered tests.

**Up by two (to 5, accept):** all of the above, plus (i) a demonstrated-valid variance in item-dominated settings
(small-G correction or wild cluster bootstrap over items, with the item share of variance and effective item count
reported for every primary test, and a size study in a world the authors did not tune on); (ii) PC3/PC4 restated
with their additivity assumption and a base-rate sensitivity analysis; (iii) the frozen, deposited pre-registration;
and (iv) real results in which at least one non-obvious finding survives these corrections, for example a clear
same-maker vs cross-maker gap in theta with bounded Fieller sets in all three groups, or a decomposition that beats
R = rho-hat.
