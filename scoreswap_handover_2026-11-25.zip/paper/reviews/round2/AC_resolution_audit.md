# Area-chair resolution audit, round 2

Submission: "ScoreSwap: Do Agent-Memory Usefulness Scores Still Rank Items After a Model Swap?" (revised; ICML 2027, Datasets, Evaluations and Benchmarks).
Auditor: area chair. Date: 24 Nov 2026.

Material read:
- First-round documents: `paper/reviews/round1/AC_first_stage_screen.md`, `R1_evaluation_methodologist.md`, `R2_agent_memory_researcher.md`, `R3_theory_statistics.md`.
- Revised submission: `paper/main.tex`, every file in `paper/sections/`, `paper/assets/*.tex` and the figures, and both builds (`dryrun.pdf`, 33 pp.; `main.pdf`, 29 pp.; both newer than every source file).
- Supplement: `prediction/PREREGISTRATION.md`, `msr/metrics.py`, `msr/theory.py`, `msr/sequential.py`, `scoreswap/`, `docs/BENCHMARK_GUIDE.md`, `docs/power/*`, `docs/forecast_and_sequential_note.md`, `legs/memrl/README.md`, `release/sim`, and `runs/sim/analysis/*.csv` (the CSVs behind the dry-run numbers).
- `docs/STATUS.md` was read only as the authors' claim.

Ground rule: credit is given only for what a reviewer can see in the revised paper or its supplement. Code that exists but is not described in the paper is marked "fixed in code but not in the paper".

Page numbers ("p.") are those of `dryrun.pdf`. The body has the same pages in `main.pdf`; the appendices start one to three pages earlier there.

My own checks are in `paper/reviews/round2/ac_checks/`. Nothing outside `paper/reviews/round2/` was changed.

---

## 0. Summary

**Counts by status** (all 279 rows of the table in Section 1):

| Status | R1 | R2 | R3 | AC | All |
|---|---|---|---|---|---|
| fixed | 49 | 47 | 33 | 26 | 155 |
| partly fixed | 29 | 15 | 11 | 7 | 62 |
| not fixed | 18 | 18 | 4 | 8 | 48 |
| fixed in code but not in the paper | 3 | 2 | 0 | 0 | 5 |
| made worse | 2 | 0 | 1 | 0 | 3 |
| no longer applies | 4 | 1 | 1 | 0 | 6 |
| **Rows** | 105 | 83 | 50 | 41 | 279 |

The table also lists restatements, for example a question that repeats a weakness or an overclaim that repeats a section-level point. Each of these 27 rows is marked "= Rx.y" and carries the same verdict. Counted once, the 252 distinct concerns split as follows:
- 151 fixed (60 %);
- 50 partly fixed (20 %);
- 40 not fixed (16 %);
- 5 fixed only in code;
- 2 made worse;
- 4 no longer apply.

The "fixed" share is inflated by wording-level items (overclaims, labels, units), which the revision handled well. Of the ten points of substance named in the brief (Section 2), seven are fixed and three only partly: the headline measure, the related work and the agent leg.

**Verdict in one paragraph.** The revision repaired most of the statistics. These are real repairs, and I verified each one against code and simulation output:
- the multiple-testing device;
- the clustering;
- the plug-in threshold of the swap-day check;
- the home reference for the calibration comparisons;
- the "law" and "mediation" language;
- the forecast's permutation test;
- the outsider interface.

It did not repair the construct problem that R1 put first. The new headline θ is free of the reader's outcome noise. However, it still scales with how much the reader's success depends on which item it is shown. My check (`ac_checks/scale_check.py`) gives two models whose within-task item order is identical, with the reader's item effects halved. They get θ = 0.51, which the registered test calls a "material drop", under a title that asks whether the scores "still rank items".

The revision also introduced new problems:
- an information bound stated as holding for "any rule", although it is a plug-in, second-order number for one sampling design;
- prediction P1 keeps the permutation test that the paper itself now calls invalid;
- the decomposition's registered readings are replaced by "not rejected";
- Figure 2's caption no longer matches its own bars;
- several practical results (stakes, per-pair spread, the test behind "mostly across makers") sit in the appendix.

There are still no real results; 45 TODO markers remain in `main.pdf` (49 in round 1), and the pre-registration is not frozen.

---

## 1. Concern-by-concern table

Status values: fixed / partly fixed / not fixed / fixed in code but not in the paper / made worse / no longer applies.

### 1.1 R1 (evaluation methodology and statistics)

| ID | Concern (one line) | Status | Where in the revision (paper; code / pre-registration) | What is still missing |
|---|---|---|---|---|
| R1.1 | W1a: R moves with the reader's outcome noise, so it cannot be the headline | fixed | §3.2 Eq. 1 p.4; Prop. 4.2 p.5; `msr/metrics.py` `theta_from_sums`, `theta_inference`; prereg 2.4 | — |
| R1.2 | W1b: even the noise-free ratio (θ → γ = ρ·sd(δᵗ)/sd(δˢ)) is a scale quantity, so it does not answer "do the scores still rank items correctly" | not fixed | §3.2 p.4; Fig. 1 caption p.2 ("1 means the old order agrees ... as strongly"); title | The scale dependence is not stated anywhere. ρ̂ (or R_std) is not reported beside θ. A reader with the same item order but smaller item effects gets θ < 1 (my check: halved spread → θ = 0.51). The NI margin, the title and the name "retained ranking signal" all assume a ranking construct. |
| R1.3 | W1 fix: put the NI margin on the noise-free quantity | fixed | §3.3 p.5; App. C; prereg Part 3 | (The margin now sits on a scale-dependent quantity; see R1.2.) |
| R1.4 | W1 fix: equalise sampling settings across makers | partly fixed | §6 p.6; App. E table p.22 | Open models run at T = 1.0 and top_p = 1.0 "to match" the closed defaults, but no source documents the closed defaults. The OpenAI reasoning setting is still "TODO confirm". |
| R1.5 | W1 fix: report repeat disagreement per model in the main text | fixed in code but not in the paper | `msr/theory.py` A2 check (l. 431); `tau_ties_pairs.csv` | Not in the paper. |
| R1.6 | W2: Holm with min(p_drop, p_NI) does not control the familywise error | fixed | §3.3 p.5; App. C p.19–20; `primary_tests.csv` (15 separate members); `docs/power/fwer_holm_output.md` | — |
| R1.7 | W2: family T uses the same device | fixed | App. C; Table 9 p.26; prereg 11.2.4 (nine members) | — |
| R1.8 | W3.1: tasks recur across orders, so cluster on task id | fixed | §3.3 p.5; §6 p.6; App. C; `cluster_variance` | The share of recurring tasks is reported only in `ANALYSIS.md`. |
| R1.9 | W3.2: items recur across tasks; make the two-way variance primary or say "bank-conditional" | fixed | §3.3; App. C; `msr/metrics.py` l. 1584–1603 | — |
| R1.10 | W3.3: bank-construction randomness; report the second-bank variance | fixed in code but not in the paper | `second_bank.csv` | Not in the paper. |
| R1.11 | W4a: the strata are 4/4/48 fixed pairs but are stated as facts about kinds of swap | partly fixed | §10 p.8 ("after these four upgrades") | The abstract and the "What we found" paragraph still say "after same-maker upgrades". |
| R1.12 | W4b: report the registered heterogeneity summary beside every stratum | partly fixed | Table 1 p.8 (range, opposite-sign share, SD) | The SD column is one pooled source-plus-target-model SD printed in every group (0.236, 0.236, 0.236). The forest plot is in the appendix. |
| R1.13 | W4c: name the cross-maker old→new subset (12 pairs) as a secondary stratum | not fixed | — | Not in the paper, the pre-registration or the code. |
| R1.14 | W4d: show the source/target decomposition in the main text | fixed in code but not in the paper | `heterogeneity_model_effects.csv`; prereg 8.2.12 | Not in the paper. |
| R1.15 | W5: PC3/PC4 need a home reference (swap minus home) or demotion | fixed | §3.3 p.5; App. A "Prediction quality"; App. C; `primary_tests.csv` | The after-swap and home terms are not printed separately (the pre-registration says "always"). |
| R1.16 | W5: use a task-adjusted calibration target | partly fixed | App. A level correction | One logit shift to the reader's no-memory level is used; there is no task adjustment. |
| R1.17 | W6.1: the abstract mixes tasks and checks and omits the undecided share | fixed | abstract p.1; §7 p.7 | — |
| R1.18 | W6.2: the audit is a strawman; compare with a fixed-n test at the same α | partly fixed | Thm. 5.2 p.6; App. N p.32 (fixed-n z test ≈ 700 tasks) | The bound now carries the argument. The abstract still uses the audit's false-keep rate against a threshold the audit does not test. The fixed-n comparison is appendix-only. |
| R1.19 | W6.3: a plug-in Ā_home voids the stated guarantee | fixed | Prop. 5.1 p.6; App. N p.32; `sequential_boundary.csv` | Prop. 5.1 omits the condition Ā_home > 0. |
| R1.20 | W6.4: θ, R_V, T and N proliferate and collide | partly fixed | Text uses θ; prereg 11.0 | The forecast figure still plots "T = N_swap/N_home". ρ̂ is used but never defined. |
| R1.21 | W7a: "law" and "prediction with no fitted parameter" | fixed | §4 p.5–6 | Fig. 2 still says "Predicted C_w" and "measured = predicted". |
| R1.22 | W7b: report the registered T1/T2 decisions | partly fixed | §7 p.7; Table 9 p.26 | Per-member labels are printed ("not rejected", `msr/theory.py` l. 1492), not the registered group readings of prereg 11.2.4. |
| R1.23 | W7c: add the stronger baselines R = γ̂ and R = ρ̂ | fixed | abstract; §7 p.7 | ρ̂ is undefined. In the dry run the decomposition equals ρ̂ (0.030 vs 0.030). |
| R1.24 | W7d: a mean gap hides per-pair error; non-rejection is not support | partly fixed | MAE reported; Table 9 TOST | The intro quotes "not rejected" ×3 and omits "equivalence not shown" ×3. |
| R1.25 | W8a: justify the 1-of-4 probe against how the cited systems use scores | partly fixed | intro "What an item is here" p.2; §10 | Justified by identification only; no comparison with MemRL top-k or ACE playbook use. |
| R1.26 | W8b: k-shown sensitivity from the Shapley subsets, for swap pairs | not fixed | §3.1 p.4 | Still upgrade pairs only, on 100 tasks. |
| R1.27 | W8c: a multi-item score phase for at least one owner | not fixed | — | — |
| R1.28 | W8d: narrow the framing in the title and abstract | fixed | title; abstract s1, s3 | — |
| R1.29 | W8e: a model-independent "stored answer is correct" score as a baseline | not fixed | — | Absent from the paper, the pre-registration and the code, although the write-phase grades make it free. |
| R1.30 | W8f: the agent leg is the only test of the broad claim ("state which legs ran") | partly fixed | §8 p.7–8; prereg 8.4; `legs/memrl/` | Registered but no results. The TODO in §6 remains. Upgrade pairs only. No power statement. |
| R1.31 | W9a: "oracle" is not an oracle; give a real ceiling | fixed | §3.3 p.5; App. A | — |
| R1.32 | W9b: `shuffled` has C_w = ½ by construction; use FS_shuffled vs FS_wipe | partly fixed | Table 6 (App. F) | The body still cites "C_w = 0.499" for the content-only control as evidence (§7 p.7). |
| R1.33 | W10a: the U_self rule is ad hoc; use C_fresh − C_swap | not fixed | §3.3; App. C | The rule is unchanged. |
| R1.34 | W10b: the 4-SE gate selects on noise; report how many cells pass | fixed | §3.2 p.4; App. N (iii); `docs/power/calibration_flag_output.md` | The count is visible only as hatching in Fig. 1. |
| R1.35 | W11a: the pre-registration is a draft; freeze it on a third-party registry | not fixed | prereg header "DRAFT. Not frozen"; App. M p.29–30 | Registry fields blank. App. C even says "a dated pre-registration". |
| R1.36 | W11b: the pre-registration cites internal roles and documents | not fixed | prereg header; "Settled by the research manager" | — |
| R1.37 | W11c: paper and pre-registration disagree (draws, k, decision categories) | fixed | App. A (200 draws); dry-run box (k = 32); App. C (categories) | — |
| R1.38 | W11d: P3 and T2 are registered to predict opposite things | not fixed | prereg 11.2.4; App. M | — |
| R1.39 | W11e: P1 and F1 test one hypothesis in two families without joint control | not fixed | App. M; App. N | P1 also keeps the label permutation that App. N calls invalid (new problem N3). |
| R1.40 | W12a: the re-runnability claim; commit hashes; local vs hosted fp8 | partly fixed | §6 p.6; Impact | The scope is fixed. Commit hashes are TODO and there is no local validation. |
| R1.41 | W12b: "score any new rule offline" overreaches | fixed | abstract; §3.3 "Using"; App. B | — |
| R1.42 | W12c: give the marginal cost of adding a reader model | partly fixed | App. B p.18 | Qualitative only. |
| R1.43 | W12d: give the real total cost in the main text | not fixed | App. K placeholder | — |
| R1.44 | W13a: too many contributions; key definitions only in the supplement | partly fixed | forecast and P1–P4 moved to the appendix | Decomposition, check, agent leg and benchmark remain. U_self and the decision categories are in App. C only. |
| R1.45 | W13b: "family" has three meanings | partly fixed | "maker" for groups; "score type" in the body | Still "score family" (App. N, Table 9) and "family T/L/F". |
| R1.46 | W13c: Sec. 2 claims the arcsin form | fixed | App. N "Gaussian forms" | — |
| R1.47 | W13d: the abstract gives point estimates without intervals or decisions | partly fixed | intro "What we found" p.2 | The abstract still gives none. |
| R1.48 | W13e: Fig. 2 caption vs task-bootstrap bars | made worse | Fig. 2 p.7 | The caption now says "two-way 95% intervals"; the figure says "bars: 95% task bootstrap". |
| R1.49 | W13f: Fig. 1 explains hatching that never appears; two gates unstated | fixed | Fig. 1; §3.2 | — |
| R1.50 | W13g: datasheet, licences, prompts, checklist and AI statement are stubs | not fixed | App. H–M; p.9 | 45 TODO markers in `main.pdf`. |
| R1.51 | W13h: cite EPR and Wang et al. (NeurIPS 2023), whose demonstrations, selected with a small LM, transfer to larger ones | partly fixed | §2 p.3 | EPR is cited. The NeurIPS 2023 latent-variable demonstration paper is not. |
| R1.52 | W13i: backward-compatibility literature (Bansal 2019; MUSCLE) | partly fixed | §2 | MUSCLE and PCT are cited; Bansal 2019 and BCT are absent. |
| R1.53 | W13j: IRT item-level transfer (tinyBenchmarks, anchor points) | not fixed | `references.bib` has both | Not cited. |
| R1.54 | Q1: which construct is the headline, and why R rather than first-shown success | partly fixed | §3.2 | = R1.2 |
| R1.55 | Q2: sampling settings and repeat disagreement per model | partly fixed | §6 | = R1.5 |
| R1.56 | Q3: distinct tasks per pool, recurrence share, clustering | partly fixed | §6; App. C | The share is not in the paper. |
| R1.57 | Q4: the Holm counter-example | fixed | App. C | — |
| R1.58 | Q5: items fixed or sampled; which estimand | fixed | App. C; §10 | — |
| R1.59 | Q6: home log scores of keep, fixed_0.5 and recal | partly fixed | `primary_tests.csv` | Computed, not printed. |
| R1.60 | Q7: which owner repeats enter γ̂; correlated error with V_home | fixed | §4 p.6; App. N (i), (v) | — |
| R1.61 | Q8: identical C_home across strata | no longer applies | `primary_tests.csv`: 0.6834 vs 0.6833 | C_home is not printed in the paper; stratum pooling is stated only in prereg 2.12. |
| R1.62 | Q9: the law's coverage denominator | no longer applies | coverage no longer reported | — |
| R1.63 | Q10: "stored answer is correct" baseline | not fixed | — | = R1.29 |
| R1.64 | Q11: fixed-n sample size; a confidence bound for Ā_home | fixed | App. N; Prop. 5.1 | Appendix only. |
| R1.65 | Q12: which swaps enter the run after the swap; forest weights | not fixed | §7 p.7 | The swap list is unstated; weights are stated only in prereg 2.12. |
| R1.66 | Q13: freeze date, registry id, deviations | not fixed | App. M | = R1.35 |
| R1.67 | 7a.1: "no study has tested this item by item" | fixed | §2 p.3 | — |
| R1.68 | 7a.2: "explain ... with a law" | fixed | — | — |
| R1.69 | 7a.3: "law predicts each pair ... mean gap" | fixed | MAE | — |
| R1.70 | 7a.4: abstract θ as a general fact, though inconclusive and R-confounded | partly fixed | abstract | θ is in place, but the phrasing is general and the decision is absent. |
| R1.71 | 7a.5: the sequential sentence (units, error, undecided) | fixed | abstract s5 | The bound's "any such rule" overreaches (N2). |
| R1.72 | 7a.6: "any new rule offline" | fixed | — | — |
| R1.73 | 7a.7: "slope measured without the scores ... predicted with no fitted parameter" | fixed | intro p.2 | — |
| R1.74 | 7a.8: "the check measures how many checks a decision needs" | fixed | Thm. 5.2 | — |
| R1.75 | 7a.9: the arcsin sentence | fixed | — | — |
| R1.76 | 7a.10: "supplies the measured answer" | fixed | App. A p.17 | — |
| R1.77 | 7a.11: "re-run after the closed models retire" | fixed | §6 | — |
| R1.78 | 7a.12: Impact "before and after" | fixed | Impact | — |
| R1.79 | 7a.13: "open-weight core stays runnable" | fixed | Impact | — |
| R1.80 | 7a.14: "fewer silent failures" | fixed | removed | — |
| R1.81 | 7a.15: "reliability cancels" stated without condition | fixed | App. N "Score families" | — |
| R1.82 | 7a.16: the cross-fitted oracle called a ceiling | fixed | — | — |
| R1.83 | 7a.17: C is not Somers' D | fixed | §3.2 | — |
| R1.84 | 7b.1: definition of the 4-SE gate | fixed | replaced by a calibration flag, defined in §3.2 | — |
| R1.85 | 7b.2: pooling of the stratum ratio (weights) | partly fixed | §3.2 | Equal weight per swap and stream is stated only in prereg 2.4/2.12. |
| R1.86 | 7b.3: which repeats enter γ̂ and V_home | fixed | §4 | — |
| R1.87 | 7b.4: θ = R_V = T never stated | partly fixed | — | = R1.20 |
| R1.88 | 7b.5: "family" | partly fixed | — | = R1.45 |
| R1.89 | 7b.6: decision labels and thresholds only in the pre-registration | fixed | App. C | — |
| R1.90 | 7b.7: definition of U_self | fixed | App. C | The rule itself is unchanged (R1.33). |
| R1.91 | 7b.8: "informative pair" and definedness | fixed | App. N (iii) | — |
| R1.92 | 7b.9: run after the swap: which swaps, arms and k | not fixed | §7 p.7 | The body gives keep, wipe and own only; the dry run used k = 16. |
| R1.93 | 7b.10: A_τ single check vs two-repeat home mean | partly fixed | §5 "stored home result" | Prereg 11.4.1 says mean of repeats 1–2; the paper does not. |
| R1.94 | 7b.11: forecast target θ vs T | partly fixed | — | = R1.20 |
| R1.95 | 7b.12: what "upgrade" holds fixed | fixed | §10 | — |
| R1.96 | 7c.1: identical C_home | no longer applies | — | = R1.61 |
| R1.97 | 7c.2: coverage denominator | no longer applies | = R1.62 | — |
| R1.98 | 7c.3: Fig. 1 vs the law's definedness (two gates) | fixed | one flag | — |
| R1.99 | 7c.4: k in PC4 | fixed | dry-run box | — |
| R1.100 | 7c.5: number of draws | fixed | App. A | — |
| R1.101 | 7c.6: sequential horizons and caps | fixed | §7; Fig. "stopping" (horizon 3,000; pool line 300) | — |
| R1.102 | 7c.7: whether the PC1 p is p_drop or min; the NI column | fixed | Table 1 | — |
| R1.103 | 7c.8: pooling formulas over two streams | partly fixed | §3.2 | = R1.85 |
| R1.104 | 7c.9: Fig. 2 intervals are not the tested ones | made worse | Fig. 2 | = R1.48 |
| R1.105 | 7c.10: cost formula and price snapshot | not fixed | App. K | — |

### 1.2 R2 (agent memory and skill libraries)

| ID | Concern (one line) | Status | Where in the revision | What is still missing |
|---|---|---|---|---|
| R2.1 | W1a: the core is in-context exemplar selection; make an agentic leg with a real scored memory confirmatory (upgrades and some cross-maker pairs) | partly fixed | §8 p.7–8; prereg 8.4 (family L); `legs/memrl/README.md` | Built and registered, but no results. Upgrade pairs only, so the cross-maker headline is untested where realism lives. The control is one shuffled permutation (seed 0). No power statement. |
| R2.2 | W1b: promote labelled items to secondary | partly fixed | §6 sensitivity study | One order, two pairs, DDXPlus; analysed as a separate study (`not_computed.csv`). |
| R2.3 | W1c: report 2–4 items shown together from the subset runs | not fixed | — | = R1.26 |
| R2.4 | W1d: thinking off and cheap tiers vs deployed reasoning modes | not fixed | §6 | Not in the Limitations section; the OpenAI setting is TODO. |
| R2.5 | W2a: a main-text stakes table in success points | partly fixed | intro p.2–3 (keep − wipe); Table 6 (App. F, p.22) | The table is in the appendix and lacks own − keep and keep − relevance. |
| R2.6 | W2b: recovery time (τ95, S_100) as a practitioner headline | not fixed | defined in App. A | Only S_all appears in the body. |
| R2.7 | W2c: "Agent memories keep a usefulness score..."; size the population | fixed | abstract s1 "Some agent memories"; §2 | The population is still not sized. |
| R2.8 | W3a: rename the "law" | fixed | §4 | — |
| R2.9 | W3b: the R headline contradicts Prop. 2 | fixed | §3.2 | — |
| R2.10 | W3c: say that γ̂ needs the reader's probe | fixed | intro p.2; §7 | — |
| R2.11 | W3d: an out-of-sample γ̂ from calibration tasks, with error vs number of tasks | not fixed | — | Calibration tasks decide only the flag (`msr/theory.py`); there is no cross-fitted version. |
| R2.12 | W3e: make the leakage test the claim | partly fixed | §4 p.6 | The test now cannot attribute a failure to leakage; it is framed as a consistency check. |
| R2.13 | W4: PC3/PC4 test home miscalibration | fixed | = R1.15 | — |
| R2.14 | W5a: the `tags_self` caveat in the abstract or intro | fixed | intro "Limits" p.3; §3.1 | — |
| R2.15 | W5b: `credit` as "MemCredit-style"; a policy-conditional credit predicts a drop | partly fixed | §3.1 | The label is fixed; the policy-conditioning point is absent. |
| R2.16 | W5c: z-normalised mix as a secondary analysis | fixed in code but not in the paper | `msr/evaluate.py` value_wz; `mix_weight.csv` | Not in the paper. |
| R2.17 | W6a: tasks vs checks; the fixed rules' error is uncontrolled | fixed | abstract; §5; §7 | — |
| R2.18 | W6b: propagate the error of Ā_home | fixed | Prop. 5.1 | — |
| R2.19 | W7: move the forecast and P1–P4 out; spend the space on stakes, interface and heterogeneity | partly fixed | forecast and P1–P4 to App. N/F; interface §3.3 | Stakes and per-pair spread are still in the appendix. |
| R2.20 | W8a: the scope of inference for heterogeneous pairs | partly fixed | §10 | = R1.11 |
| R2.21 | W8b: min-p in Holm | fixed | = R1.6 | — |
| R2.22 | W8c: the U_self rule | not fixed | = R1.33 | — |
| R2.23 | W9a: a defined interface for a rule | fixed | §3.3 "Using ScoreSwap" p.5; App. B p.18; `scoreswap/` | Verified by running it (Section 2). |
| R2.24 | W9b: canonical metric, leaderboard, hidden test, validation of entries | partly fixed | App. B "Two leaderboards" | No hidden split: the pack ships `harness_only/evaluation_results.csv` to every user. Not discussed. |
| R2.25 | W9c: the "adapter for outside memory systems" is undescribed | no longer applies | claim removed | — |
| R2.26 | W9d: release TODOs (datasheet, BIRD licence, Croissant, checklist) | not fixed | App. H, I, L | The BIRD licence is still "per team notes". |
| R2.27 | W9e: "any new rule" | fixed | — | — |
| R2.28 | W9f: a 20-line example and an appendable results table | fixed | `scoreswap/templates`; `examples/`; leaderboard | The paper body does not point to the templates. |
| R2.29 | W10a: the closest works are read only from abstracts | not fixed | §2 p.3; App. D "R" rows | Unchanged. |
| R2.30 | W10b: Policy-Response Drift and Harmless Here appear only in the table and cannot be found | not fixed | App. D | — |
| R2.31 | W10c: CHIME used as evidence about order | fixed | §2 | — |
| R2.32 | W10d: the Beyond Gain 0.40 is quoted without its noise ceiling | fixed | intro p.1 (0.73); App. G | — |
| R2.33 | W11a: family vs maker | partly fixed | — | = R1.45 |
| R2.34 | W11b: the forecast figure says T, not θ | not fixed | `fig_forecast_readiness` | — |
| R2.35 | W11c: Fig. 1 hatching; diagonal above 1 | fixed | Fig. 1 caption | — |
| R2.36 | W11d: oracle below keep | fixed | — | — |
| R2.37 | W11e: TODOs in the main text | not fixed | `main.pdf` pp.1–9: 10 TODO markers | — |
| R2.38 | W11f: plain register costs precision; "validity"; units | fixed | — | — |
| R2.39 | Q1: share of informative and tied pairs; owners passing the rule | fixed in code but not in the paper | `tau_ties_pairs.csv` | — |
| R2.40 | Q2: candidates matching the gold answer or near-duplicates; θ without them | not fixed | — | — |
| R2.41 | Q3: γ̂ from calibration tasks only | not fixed | — | = R2.11 |
| R2.42 | Q4: keep and fixed_0.5 log scores at home | partly fixed | — | = R1.59 |
| R2.43 | Q5: keep − shuffled in success points per stratum | fixed | Table 6 (App. F) | Appendix only. |
| R2.44 | Q6: z-mix and top-2/3 shown | not fixed | — | z-mix in code only; k-shown nowhere. |
| R2.45 | Q7: which legs ran; confirmatory? | partly fixed | — | = R2.1 |
| R2.46 | Q8: would an active design (choose cells) cut the 500+ tasks? | not fixed | Thm. 5.2 | The theorem assumes whole tasks drawn at random; the scope is unstated. |
| R2.47 | Q9: Holm with min-p | fixed | — | — |
| R2.48 | Q10: adapter and rule interface | fixed | App. B | — |
| R2.49 | Q11: thinking off vs reasoning modes | not fixed | — | = R2.4 |
| R2.50 | Missing: EPR, LLM-R, Nguyen & Wong, Chang & Jia | fixed | §2 p.3; App. D | — |
| R2.51 | Missing: Small-to-Large; Selection via Proxy | fixed | §2 | — |
| R2.52 | Missing: Khraishi switch matrix | fixed | §2 | — |
| R2.53 | Missing: New Model, Old Habits | fixed | §2 | — |
| R2.54 | Missing: MASA; AFTER | fixed | §2 | — |
| R2.55 | Missing: Judge Version Shift | fixed | §2 | — |
| R2.56 | Missing: "When the Judge Changes, So Does the Measurement" (2607.08535) | not fixed | not in `references.bib` | — |
| R2.57 | Missing: Memory Reward Inflation | fixed | §2 | — |
| R2.58 | Missing: ERRAND; When Agent Skills Go Stale | fixed | §2 | — |
| R2.59 | Missing: MUSCLE, PCT, BCT | partly fixed | §2 | BCT is absent. |
| R2.60 | Missing: SkillsBench, SKILL-DISCO, SkillAdam, Learner2Skill (executor calibration) | not fixed | — | None of the four is cited. |
| R2.61 | CHIME's "moves per-item scores" cell should be ✓ or ◦ | fixed | App. D (◦) | — |
| R2.62 | MemRL: the quote's location; the transfer is mainly a strong teacher's content | partly fixed | intro p.1 | The content-vs-order reading of MemRL's transfer is not made. |
| R2.63 | MemCredit is policy-conditional | partly fixed | — | = R2.15 |
| R2.64 | ACE counters are our operationalisation (intro or abstract) | fixed | intro "Limits" | — |
| R2.65 | Scope "no study ... item by item" to learned memory scores | fixed | §2 | — |
| R2.66 | Unverifiable rows decide the novelty margin | not fixed | — | = R2.29 |
| R2.67 | Overclaim 1: "Agent memories keep a usefulness score..." | fixed | abstract s1 | — |
| R2.68 | Overclaim 2: "no study has tested this item by item" | fixed | — | — |
| R2.69 | Overclaim 3: "explain ... law" | fixed | — | — |
| R2.70 | Overclaim 4: "the law predicts ..." | fixed | — | — |
| R2.71 | Overclaim 5: tasks vs checks | fixed | — | — |
| R2.72 | Overclaim 6: "any new rule" | fixed | — | — |
| R2.73 | Overclaim 7: "any score rule, including later ones" | fixed | Contributions | — |
| R2.74 | Overclaim 8: CHIME in the intro | fixed | — | — |
| R2.75 | Overclaim 9: "Spearman only 0.40" | fixed | — | — |
| R2.76 | Overclaim 10: "home × transfer slope" omits the W ratio | fixed | Prop. 4.2 | — |
| R2.77 | Overclaim 11: "the check measures how many checks are needed" | fixed | — | — |
| R2.78 | Overclaim 12: "none holds content fixed" while the nearest works were read from abstracts | partly fixed | §2 "among the works we could read in full" | Honest, but the works not read are the closest ones. |
| R2.79 | Overclaim 13: "supplies the measured answer" | fixed | — | — |
| R2.80 | Overclaim 14: "reliability cancels" | fixed | — | — |
| R2.81 | Overclaim 15: Impact "before and after" | fixed | — | — |
| R2.82 | Overclaim 16: Impact "fewer silent failures" | fixed | — | — |
| R2.83 | Overclaim 17: title/abstract "Benchmark ... for Agent Memory" | fixed | new title; abstract s3 | — |

### 1.3 R3 (theory and statistics)

| ID | Concern (one line) | Status | Where in the revision | What is still missing |
|---|---|---|---|---|
| R3.1 | S1: "unit weights" means unit weights on informative pairs; C is not Somers' D; tie-tolerance precedence | fixed | §3.2 p.4 | — |
| R3.2 | S2: say in the main text that C_w = (1 + Γ)/2, the Gini correlation | fixed | Prop. 4.1 p.5 | — |
| R3.3 | S3: "noise only through W" holds for the first moment only; tasks iid given the bank | fixed | §3.2; App. N proof | — |
| R3.4 | S4: the estimate of the ceiling has a Jensen bias | not fixed | App. N "Ceiling" | — |
| R3.5 | S5/S6: γ is a regression slope; Prop. 2 is a tautology; present both as classical | fixed | §4 | — |
| R3.6 | S7: L = 0 is not mediation; counter-example; list every assumption | fixed | §4 p.5–6; App. N p.31; prereg 11.2.1 | — |
| R3.7 | S8: Eq. 3 and "= ρ" hold only under L = 0 and its conditions | fixed | Prop. 4.2 | — |
| R3.8 | S9: reliability cancels only under L = 0; ratio bias of θ̂; selection by the screen | partly fixed | App. N; calibration flag | The finite-sample ratio bias of θ̂ is not discussed (`calibration_flag_output.md`: mean 0.763 vs true 0.753 at a weak signal). |
| R3.9 | S10: the finite-bank (item-superpopulation) estimand clashes with the rest | fixed | App. C (items sampled throughout) | — |
| R3.10 | S12.1: caching biases γ̂; use the cross-session denominator | fixed | §4 p.6; App. N (i); prereg 11.2.2 | — (but see R3.43) |
| R3.11 | S12.2: weak signal; Fieller or bootstrap-t; definedness selects | fixed | App. N (iii), (iv) | — |
| R3.12 | S12.3: the absolute value of ρ̂ can exceed 1 | not fixed | — | ρ̂ is not even defined in the paper. |
| R3.13 | S13: identification rests on (A2) and on μ away from {0, 1} | fixed | App. N (ii) | — |
| R3.14 | S14: two-way variance details (dyads, negative estimate, co-determined items, shared models) | partly fixed | App. C; `msr/metrics.py` l. 1584–1603 | Items whose scores the adaptive score phase co-determined are not discussed. |
| R3.15 | S15a: "no fitted parameter"; fair baselines; a cross-fitted version | partly fixed | §7 | Baselines added; no cross-fitted version. |
| R3.16 | S15b: Fig. 2 has a common denominator (Pearson 1897); plot θ against γ̂ | not fixed | Fig. 2 p.7 | — |
| R3.17 | S15c: report MAE or RMS gap, not the mean gap | fixed | — | — |
| R3.18 | S19: the main-text count-discount sentence is false | fixed | App. N Prop. N.2 (counter-example included) | — |
| R3.19 | S21: the converse gives co-candidate orders, not a global map | fixed | App. N proof | — |
| R3.20 | S24: the Gaussian misses depend on the data-generating process | fixed | App. N | — |
| R3.21 | S25: the arcsin sentence | fixed | — | — |
| R3.22 | S26: break-even (η_s = η_t; "≤"; dominated estimators) | fixed | App. N | — |
| R3.23 | S27: "zero when there is no information" holds only on average | no longer applies | phrase removed (§5) | — |
| R3.24 | S29: the guarantee needs a known Ā_home; "by construction" is wrong | fixed | Prop. 5.1; App. C | — |
| R3.25 | S30: DROP and the cap both lead to recalibrate, so only KEEP matters | partly fixed | §5; prereg 11.4.5 | Not said in the paper. |
| R3.26 | S31: the replay checks agreement, not the guarantee | fixed | §7 p.7; §10 | — |
| R3.27 | S32: state the information limit as a result | fixed | Thm. 5.2; abstract | Its scope and plug-in nature are unstated (N2). |
| R3.28 | S33: leave-one-model-out sees the other model; use leave-two-out | fixed | App. N forecast | — |
| R3.29 | S35: QAP rejects under maker structure; use MRQAP | fixed | App. N; `docs/forecast_and_sequential_note.md` | Fixed for F1 only; P1 keeps QAP (N3). |
| R3.30 | S36: the forecast is disconnected from the theory; forecast γ from a few reader cells | partly fixed | App. N (20-check baseline, descriptive) | The disconnect is explained only in the docs note. |
| R3.31 | S38/W1: the headline estimand contradicts the paper's own identity | fixed | §3.2; §4 | — (scale: R1.2) |
| R3.32 | W2: a specification test with its full assumption list; the sign is not interpretable | fixed | §4; §10; App. N | — |
| R3.33 | W2: a non-linearity sensitivity analysis (logit scale or monotone spline) | not fixed | — | Only the sizes of the bias are quoted. |
| R3.34 | W3: γ̂ is fragile; state the usable regime | fixed | = R3.10, R3.11 | — |
| R3.35 | W3/§8: a sensitivity analysis for dependent repeats | partly fixed | prereg 11.2.2 (γ̂_within, A2 check) | Not in the paper. |
| R3.36 | W5: theory novelty overstated; cite the classical sources | partly fixed | Prop. 4.1 "Classical form"; Hausman, Angrist–Imbens, Fuller, Fieller, Wald, Kaufmann, Dekker, Bühlmann cited | Berger (the IUT used in PC4), Mantel/Krackhardt, Carroll et al. and Pearson 1897 are absent. The bound is labelled "Theorem". |
| R3.37 | W6: the forecast's test does not test the claim | fixed | = R3.29 | — |
| R3.38 | W7: inference treats randomness inconsistently; state the estimand per claim | fixed | App. C; §10 | P3 and the agent leg still use task-only bootstraps (minor). |
| R3.39 | W8: the list of wrong statements | fixed | each one checked | — |
| R3.40 | W9: the minor list | partly fixed | — | T vs θ (figure) and ρ̂ above 1 in absolute value remain. |
| R3.41 | Q1: which condition gives L = 0 | fixed | §4 | — |
| R3.42 | Q2: cross-session products; within- vs across-session agreement per model | partly fixed | estimator fixed | Agreement per model not reported. |
| R3.43 | Q3: γ̂ lies below the simulator's truth | made worse | App. N "On the simulated study" p.33 | Now 0.521 vs 0.69 and 0.241 vs 0.30, further from the truth than round 1 (0.60, 0.27). Printed beside the truth, unexplained. |
| R3.44 | Q4: reliability of within-task differences; when the definedness rule fails | partly fixed | `calibration_flag_output.md`; App. C power | Per-model reliability not given. |
| R3.45 | Q5: propagate Ā_home; α-split | fixed | Prop. 5.1; App. N | — |
| R3.46 | Q6: a lower bound in tasks and checks, with the undecided share | fixed | — | — |
| R3.47 | Q7: why error consistency should predict θ | partly fixed | — | = R3.30 |
| R3.48 | Q8: the item term for recurring pairs; negative estimates | fixed | `msr/metrics.py`; App. C | — |
| R3.49 | Q9: is PC1 bank-conditional? | fixed | items sampled | — |
| R3.50 | Q10: which baselines the law's MAE is compared with | fixed | §7 | The cross-fitted version is missing (R3.15). |

### 1.4 AC (first-stage screen)

| ID | Concern (one line) | Status | Where in the revision | What is still missing |
|---|---|---|---|---|
| AC.1 | The title collides with Goyal & Ray ("survive") | fixed | title | — |
| AC.2 | No "what we found" paragraph | fixed | intro p.2 | — |
| AC.3 | No figure on pp.1–4; add a schematic plus a per-pair result | partly fixed | Fig. 1 p.2 (θ grid) | No schematic of the probe design. |
| AC.4 | Abstract sentence 3 is overlong | partly fixed | abstract | The new sentence 5 is about 75 words long and packs three results. |
| AC.5 | The swap-day sentence reads as a self-own | fixed | abstract s5 | — |
| AC.6 | The garage analogy takes the first lines | fixed | intro | — |
| AC.7 | The release appears only in the last half-sentence | fixed | abstract s6 | — |
| AC.8 | Streams, scale and measure are undefined on pp.1–2 | fixed | intro "What we measure" p.2 | — |
| AC.9 | No practical swap-day rule | not fixed | §9 "no interpretation" / TODO | The intro asserts "a default has to rest on what is known before the swap" and no rule follows (N9). |
| AC.10 | "Law" in the abstract and contributions | fixed | — | — |
| AC.11 | The law is only partly a prediction | fixed | intro p.2; §7 | — |
| AC.12 | The negative swap-day answer is hidden | fixed | abstract s5 | — |
| AC.13 | The forecast is a likely null among the contributions | fixed | App. N | — |
| AC.14 | Units: tasks vs checks | fixed | — | — |
| AC.15 | Horizons (100 / 300 / 1,000) | fixed | — | — |
| AC.16 | "keep-or-drop" vs "keep-or-recalibrate" | fixed | §5 | — |
| AC.17 | Eight vs nine rules | fixed | §3.3 ("nine rules and seven references") | — |
| AC.18 | "family" vs "maker" in figures and tables | fixed | Table 1; Fig. 2 | — |
| AC.19 | θ vs T on the forecast figure | not fixed | App. F figure | — |
| AC.20 | The diagonal is called a "noise floor" | fixed | Fig. 1 | — |
| AC.21 | The oracle scores below keep | fixed | — | — |
| AC.22 | The run after the swap (keep < wipe) is not reconciled with PC2 | not fixed | §7 p.7 (0.660 vs 0.676) | — |
| AC.23 | The label "not shown" | partly fixed | PC4 "not supported" | "equivalence not shown", "no family difference shown" and family L's "not shown" remain. |
| AC.24 | The abstract's signed mean gap → MAE | fixed | — | — |
| AC.25 | The CHIME contradiction in the motivation | fixed | — | — |
| AC.26 | "Any new rule" | fixed | — | — |
| AC.27 | An 8×8 heatmap at column width is unreadable | not fixed | Fig. 1 at 0.44\textwidth inside `figure*` | — |
| AC.28 | The novelty disclaimer appears five times | partly fixed | "What we do not claim" removed | The "classical" disclaimer is still in the intro, §2, §4, §5 and App. A. |
| AC.29 | The positive novelty sentence is buried in Related Work | partly fixed | abstract s2 states the gap | "None holds content fixed" is still §2 only. |
| AC.30 | Missing: Memory Reward Inflation, Rosetta, Learning on the Job | fixed | §2 | — |
| AC.31 | Machine-written tells | partly fixed | "graded automatically", "keep-or-drop" | "maker" kept; very long list-sentences remain. |
| AC.32 | The overclaim table (no study; law; any rule; units; CHIME; Impact; rule count) | fixed | — | — |
| AC.33 | Impact "before and after" | fixed | — | — |
| AC.34 | TODOs and the red NOTE box are blocking | not fixed | `main.pdf`: 45 TODOs (10 on pp.1–9); NOTE box p.9 | Many need no results. |
| AC.35 | AI disclosure: TODOs, unverified claims, tools and versions, heading name | not fixed | p.9 | — |
| AC.36 | LaTeX comments leak process notes and internal paths | partly fixed | "owner's rule" gone | "written by an AI assistant", "the area chair's reading", `msr/`, `docs/` and `research_notes/` paths remain. "Per team notes" is printed in the App. I table. |
| AC.37 | The anonymous link is a TODO | not fixed | Software and Data | — |
| AC.38 | Use the spare page for Fig. 1 and the findings | fixed | the body ends on p.8 | — |
| AC.39 | Three of the four closest works are unrefereed and read from abstracts | not fixed | — | = R2.29 |
| AC.40 | Contributions as checkable claims | fixed | intro p.3 | — |
| AC.41 | Cut list (biomedical statistics, fourth system, "may come out null") | fixed | — | — |

---

## 2. Verification of the fixes that matter

For each point of substance, I state what I opened or ran and what I found.

1. **Headline measure (R1.1–3, R3.31): the noise confound is fixed; the scale confound is not.**
   - I checked the definitions. θ = ΣV_swap/ΣV_home is defined once in `msr/metrics.py` (`theta_from_sums`, l. 1413; `theta_inference`, l. 1650). The paper's Eq. 1 (§3.2) and prereg 2.4 agree with it. R = θ·W_home/W_swap is stated in §3.2 and Prop. 4.2.
   - I then ran `ac_checks/scale_check.py`, which uses the project's own `theta_cell`. The owner and reader rank the four candidates of every task identically, and only the reader's item-to-item differences are shrunk:

     | Reader's spread relative to the owner's | θ |
     |---|---|
     | 1.00 | 0.996 |
     | 0.75 | 0.773 |
     | 0.50 | 0.512 |
     | 0.25 | 0.236 |

   - Under PC1-NI (margin 0.75) the last two are "material drop", although the old scores still rank every item correctly. A stronger new model that leans less on in-context examples, which is plausible for exactly the upgrades, will show "loss" for this reason.
   - θ is a defensible decision quantity: success points scale with it. But it is not the construct the title, the bolded question and Fig. 1's caption ("agrees ... as strongly") describe, and the paper never says so.

2. **Multiple testing (R1.6–7, R2.21): fixed.**
   - In `runs/sim/analysis/primary_tests.csv`, all 15 tests have `family_size` = 15 with separate Holm ranks; PC1-drop and PC1-NI are distinct rows with their own p-values. The family-T table has 9 separate members.
   - `docs/power/fwer_holm_output.md` reproduces R1's counter-example: the old device gives 0.1432 (Monte-Carlo SE 0.0008). The worst case for the new 15-member device is 0.0499 (MC SE 0.0005), and for the 112-member per-pair flag 0.0492.
   - The numbers in App. C match the file.

3. **Variance (R1.8–9, R3.14, R3.48): fixed.**
   - `cluster_variance` (`msr/metrics.py` l. 1584–1603) computes V = max(two-way, task, item) × 1.03². Rows count as related through an item when they share at least one item (an indicator, so there is no double counting). The two-way term is replaced by the larger one-way term when it is smaller. The Fieller interval is the union of the per-form Fieller sets, so it inverts the same test.
   - `docs/power/coverage_twoway_output.md`, row (iv*), gives the paper's 0.939–0.955 coverage. (The raw two-way Fieller interval reached only 0.927–0.953; the paper quotes the registered version, which is fair.)
   - `docs/power/size_theta_boundary.md` gives the paper's sizes: worst 0.0546 without the factor and 0.0494 with it.
   - Two caveats:
     - The 1.03 factor was chosen on the same 20 configurations that are then quoted as its validation (MC SE ≈ 0.0025).
     - The power figures in App. C predate the factor. For example, NI power at θ = 0.85, 4 swaps and home C_w = 0.66 falls from 0.808 to 0.787 with the factor.

4. **Withdrawn "law" and "mediation" language (R1.21, R2.8, R3.6): fixed in the text, with a residue.**
   - A grep of `sections/*.tex` finds "law" only in labels and file names.
   - §4 states L = 0 as a linear specification (Hausman), gives the monotone counter-example with sizes, and App. N lists A1, A2 and linearity.
   - The residue is Fig. 2, whose axis reads "Predicted C_w after the swap" with a legend "measured = predicted".

5. **The sequential check's guarantee (R1.19, R3.24, R2.18): fixed, with one missing condition.**
   - Prop. 5.1 now tests E[A_swap − 0.75·A_home] ≤ 0 on paired tasks, and the proof in App. N is a standard Ville argument.
   - In `runs/sim/analysis/sequential_boundary.csv` the paired rule's worst error is 0.030 (keep) and 0.039 (drop) over 2,000 replications to 6,000 tasks. The withdrawn plug-in rule reaches 0.3275 (64 home tasks) and 0.1665 (400). This matches App. N.
   - The missing condition: the equivalence of "θ ≤ 0.75" and "E D ≤ 0" needs Ā_home > 0, which Prop. 5.1 does not state.
   - The information-limit number is examined under N2.

6. **The forecast's test (R3.29, R3.37): fixed for F1.**
   - App. N describes a partial-correlation test with double semi-partialling over the 384 maker-preserving relabellings.
   - `docs/forecast_and_sequential_note.md` reports its level as 0.045–0.057 in six null worlds and 0.095 with curved capability, and its power as 0.63–0.68 at ρ = 0.3. The old QAP test rejected 0.47 of the time. The paper's App. N and §10 sentences match.
   - However, P1 (prereg Part 7; App. C) still uses the plain 8! model-label permutation for "agreement predicts θ", the very test App. N now says "tests only whether the two arrays are related at all" (N3).

7. **Related work the reviewers said was missing: mostly fixed.**
   - I extracted every `\cite` key (112 distinct) and checked them against the lists.
   - All three AC items are cited, and 16 of R2's 22 named works.
   - Still missing:
     - "When the Judge Changes...";
     - BCT;
     - SkillsBench, SKILL-DISCO, SkillAdam and Learner2Skill;
     - Bansal et al. 2019;
     - Wang et al. (NeurIPS 2023, latent-variable demonstrations);
     - tinyBenchmarks and anchor points, which are in the `.bib` but not cited.
   - The closest works (three OpenReview submissions, Policy-Response Drift, Harmless Here) are still marked "R" (read from abstracts or cached records).

8. **What "memory" means here (R2.7, R1.28, R2.83): fixed.**
   - The abstract now opens "Some agent memories attach...".
   - The intro paragraph "What an item is here" says plainly that the core is in-context example selection with a learned score, ties it to EPR and LLM-R, and scopes out trajectories, insights and skills.
   - The title still says "Agent-Memory", which is acceptable given that paragraph.

9. **The multi-step agent leg (R2.1, R1.30): partly fixed.**
   - §8 describes MemRL at a pinned commit on LifelongAgentBench OS tasks: top-10 recall, top-5 by a z-scored mix, two repeats, frozen content at evaluation. This matches `legs/memrl/README.md` §2–3.
   - Family L (keep − shuffled, one-sided, Holm over the pairs run) matches prereg 8.4.
   - Problems:
     - No results. `assets/table_agent_leg.tex` does not exist, so the dry run prints a "file missing" stub (p.28).
     - Upgrade pairs only: the cross-maker drop, the paper's main finding, is never tested in the realistic setting.
     - The shuffled control is a single permutation (seed 0), so the registered interval ignores permutation variance.
     - No power statement for 150 tasks × 2 repeats.
     - §6 still carries "TODO: state which legs ran".

10. **The outsider interface (R2.23–24, R2.28, R1.41): fixed, with one caveat.**
    - Using only `docs/BENCHMARK_GUIDE.md`, I wrote a rule (`ac_checks/maker_gate_rule.py`: keep within a maker, wipe across).
    - `python -m scoreswap check` passed all four checks (sealing, contract, determinism, permuted-outcome canary) in 8 s.
    - `score --budget 0` produced a per-pair `SUMMARY.md` in 10 s, written outside the project.
    - `python -m scoreswap.parity --study sim --pack release/sim --only keep,wipe,fixed_0.5,recal_16,audit_16 --families ema_grade` printed ALL MATCH, with a largest per-task difference of 8e-15. That supports the "below 10⁻¹³" claim for the rules I tried.
    - Caveat: the release pack ships `harness_only/evaluation_results.csv` to every user. The sealing therefore prevents accidental leakage during a run, but there is no hidden test split, and an entry can be tuned on the evaluation outcomes. The paper does not say this.

---

## 3. New problems introduced by the revision

### 3.1 Substance

- **N1 (major). θ's scale dependence is now load-bearing.** R1.2 is set out in Section 2, item 1. Because the NI margin and every headline number now sit on θ, a reader with smaller item effects is classed as a "material drop" with no ranking change.
  - Fix: report ρ̂ (or R_std = θ̂·√(S_oo/S_nn), already in prereg 11.2.2) beside θ in Table 1 and the abstract-level numbers.
  - State the identity θ → ρ·sd(δᵗ)/sd(δˢ) under L = 0.
  - Rename the quantity, or the question in the title.
- **N2 (major). The information bound is stated as universal.**
  - The abstract says "any such rule needs at least 262 tasks". The source is `sequential_bound.csv` (`setting=table_plugin`, column `bound_tasks_chi2`): the second-order approximation at plug-in estimates of Ā_home and E σ², with no uncertainty, assuming whole tasks (4 checks) drawn uniformly at random.
  - Theorem 5.2's Wald argument needs that i.i.d. design. A rule that picks which tasks to check, for example tasks where the owner's stored result is informative (the paired test already holds those results), is outside the theorem. R2 Q8 asked exactly this.
  - The paired test also needs the old model's per-candidate results on every check task. In deployment these must be collected before the old model retires, and the paper never states this as an operational requirement.
  - §5 says the paired test needs "about twice the bound"; §7 reports 720 against 262, which is 2.7 times.
- **N3 (major). P1 keeps the invalid permutation test.** App. N says that relabelling models in the predictor array "rejected in about half of simulated worlds" when the predictor adds nothing beyond the maker flag. Yet P1 (App. C; prereg Part 7) tests "agreement predicts θ" with the same 8! label permutation. The repair was applied to F1 and not to its twin.
- **N4 (moderate). The decomposition's registered readings are bypassed.**
  - Prereg 11.2.4 registers group readings: "specification supported / fails / departure within the margin / inconclusive".
  - The code emits per-member labels ("not rejected", `msr/theory.py` l. 1492), and the intro quotes "not rejected, not rejected and not rejected" while omitting that all three equivalence tests read "not shown". Under the registered readings all three groups are "inconclusive".
  - App. N's dry-run paragraph says the study is "too small to test the specification within a swap group", while §7 prints per-group decisions.
- **N5 (moderate). Contribution (iii) does not beat its simplest competitor.**
  - In the dry run the decomposition's MAE equals that of R = ρ̂ (0.030 vs 0.030), and ρ̂ is never defined in the paper.
  - The specification test cannot tell leakage from curvature (§4's own sentence), and no cross-fitted or out-of-sample version exists.
  - The body spends §4, Fig. 2 and a results paragraph on it.
- **N6 (moderate). The γ̂ truth check now shows a bias.** App. N prints γ̂ = 0.521 (truth 0.69) and 0.241 (truth 0.30), 20–25 % low and worse than round 1, under the sentence "these estimates can be checked against the truth" (§7). R3 Q3 asked about this; nothing explains it.
- **N7 (minor). The agent leg design has gaps:** one shuffle permutation, no power analysis, no cross-maker pair, and a missing results file (Section 2, item 9).

### 3.2 Inconsistencies (paper vs paper, paper vs pre-registration, paper vs code)

- **N8.**
  - Fig. 2: the caption says "two-way 95% intervals"; the figure says "bars: 95% task bootstrap". This makes R1's complaint worse.
  - Fig. 2 also says "Predicted".
  - The forecast figure says "T = N_swap/N_home".
- **N9.** Table 1's "SD" column is one source-plus-target-model SD over all swaps (`heterogeneity.csv`, `sd_between`), printed identically for every group (0.236 three times, 0.048 three times, 0.017 six times) under a caption that says "each group's spread". A reviewer will read it as a bug, as R1 did with C_home.
- **N10.** Prereg 11.1 still defines θ's reportability by the old same-task 4-SE rule, while Part 2.4, the code and the paper use the 2-SE calibration flag. Prereg P3 still says "the stratified task bootstrap of Part 4.1", although Part 4.1 is now two-way.
- **N11.** App. C says "fixed in a dated pre-registration"; the pre-registration is "DRAFT. Not frozen". This is a claim that is not true at submission.
- **N12.** §6 says "Thinking is off on every model"; App. E lists the OpenAI reasoning effort as "TODO confirm". §6 also keeps "TODO: state which legs ran" next to the new §8.
- **N13.** App. C's power statements predate the 1.03 factor (Section 2, item 3).
- **N14.** Prop. 5.1 lacks Ā_home > 0.
- **N15. Formatting and wording slips:**
  - "0.0692" next to "0.103";
  - "left 1.000 of swap cells undecided" (should read "all");
  - "equivalence equivalence not shown";
  - decision strings repeated three times inline.
  - Fig. 1 labels readers "(new model)" although downgrade readers are old models.

### 3.3 Claims that grew

- "No keep-or-drop decision with 5% error control can be made with a few checks: ... any such rule needs at least ..." (abstract, intro). See N2.
- "A swap-day default therefore has to rest on what is known before the swap" (intro, p.2). This is a new normative conclusion. What is known before the swap is the forecast (appendix, likely null) or the maker flag (never stated as a rule). The Discussion is a TODO.
- "Old scores lose ranking signal mostly across makers" (intro). The registered test of this comparison is P4, which is in the appendix (and "not testable" in the dry run). In the body the claim rests on comparing group point estimates, with the upgrade interval at 0.47–1.09.
- Fig. 1 caption: "1 means the old order agrees with the reader's results as strongly as with the owner's own". As shown in N1, θ = 1 can also mean larger reader effects with weaker agreement.
- Abstract: the scorer runs rules "sealed from the evaluation outcomes". True of the run, but the outcomes ship with the pack (Section 2, item 10).

### 3.4 Where the body now leans on an appendix for something a reviewer needs

| Claim in the body | Needed evidence | Where it is |
|---|---|---|
| "what is at stake" (intro, §7) | the stakes table: keep − wipe, keep − shuffled, ceiling − keep, at home and after the swap | Table 6, App. F (p.22) |
| per-group spread, "four pairs that differ in what changed" | the per-pair forest plot | App. F |
| "mostly across makers" | P4, the registered test of that contrast | App. F/M |
| "a swap-day default has to rest on what is known before the swap" | the forecast and the maker-flag baseline | App. N/F |
| family-T decisions quoted in the intro | Table 9 (equivalence results, registered readings) | App. F (p.26) |
| Theorem 5.2 numbers, "fixed budgets cannot support a controlled decision" | the frontier (best keep rate at 16 tasks; forced false-keep rate) | App. N (p.32) |
| the decomposition's baseline "R = ρ̂" | a definition of ρ̂ | nowhere |
| the agent leg | Table 10 | App. F (p.28), file missing |
| U_self, decision categories | the decision rules | App. C |

### 3.5 Body space that no longer earns its place, and what was pushed out

- **No longer earns its place:**
  - §4 at its current length, with Fig. 2 and its §7 paragraph. It ties ρ̂, cannot attribute a failure, and its figure is a common-denominator plot with mislabelled bars. Keeping the identity R = θ·W_home/W_swap (one sentence and the reason θ is the headline) and moving γ̂, family T and Fig. 2 to the appendix would free about two thirds of a column.
  - Prop. 4.1 can be one sentence.
  - The PC3 and PC4 numbers in §7's "What to do on swap day", quoted to four decimals; in the dry run they are worth −0.005 to 0.018 in first-shown success.
- **Pushed out but needed:**
  - the stakes table;
  - the per-pair forest plot;
  - P4;
  - the definition of ρ̂ and a scale-free companion to θ;
  - a schematic of the probe table (AC.3);
  - a one-line cost of the study (calls and dollars).

---

## 4. Predicted scores and recommendation

These follow the basis the first-round reviewers used: real results that follow the dry-run pattern. With "results pending" every reviewer would score 1–2, because a paper without results cannot be reviewed.

| Reviewer | Round-1 Overall | Predicted Overall for the revision | The concerns that decide it |
|---|---|---|---|
| R1 (methodology) | 3 | 4 (weak accept) | **Up:** Holm (R1.6), clustering (R1.8–9) and PC3/PC4 (R1.15) are fixed and verified, which covers three of R1's top three items. **Held at 4:** the construct half of W1 (R1.2), which R1 wrote down explicitly, is untouched. The registration is not frozen (R1.35). Datasheet, licences and prompts are still stubs (R1.50). |
| R2 (agent memory) | 3 | 3 (weak reject; 4 if the agent leg reports) | **Up:** honest framing (R2.7) and a working outsider interface (R2.23), verified. **Held:** no agent-leg result, and no cross-maker pair even planned (R2.1). Stakes and per-pair spread stay in the appendix (R2.5). The closest works are still read from abstracts and several named works are missing (R2.29, R2.56, R2.60). |
| R3 (theory) | 3 | 4 (weak accept) | **Up:** every statement R3 called wrong is corrected; the cross-session γ̂, the paired check and the information bound are added; the forecast test is repaired. **Held at 4, not 5:** Fig. 2 still has a common denominator (R3.16); P1 keeps QAP (N3); γ̂ is now further below the simulator truth (R3.43); there is no non-linearity sensitivity analysis (R3.33); the bound's scope is unstated (N2). |
| AC (first-stage screen) | advance (65–75 %) | would advance again (about 80 %) | Pages 1–2 now state the question, the measure, the scale and the findings, with a figure. The remaining first-page risks are the long abstract sentence 5 and the TODOs. |

**My recommendation as area chair:**
- **The revised paper as it stands: reject (not submittable).** It has no real results. `main.pdf` has 45 TODO markers, 10 of them on pp.1–9. The AI statement has four TODOs and a red note. The pre-registration it calls "dated" is unfrozen. The design has become advance-worthy; the paper has not yet.
- **If the real results come out in the shape of the simulated ones** (cross-maker θ ≈ 0.2 with a material drop; upgrades inconclusive; keep − wipe small across makers; the decomposition no better than ρ̂; the check undecided in the table; the forecast null): **weak accept (4), borderline**, conditional on actions 1–6 below. The usable message would be: keep within a maker, wipe across makers, and a controlled check costs hundreds of tasks. That message needs N1, P4 in the body and the stakes table to be credible. If "after upgrades" stays inconclusive, which the 4-pair groups make likely unless the home signal is strong (App. C: NI reaches 80 % power only at θ ≈ 0.85 and home C_w ≥ 0.66), the within-maker half of the message rests on point estimates.
- **If the real results show no drop at all** (θ ≈ 1 and "no material drop" established in every group): **borderline (3–4).** "The scores survive a swap; keep them" is a clean, actionable result, and the table and scorer remain useful. But §4–5 lose their purpose, and the paper must be rebuilt around the NI results and the stakes. If "no material drop" is shown only for the 48 cross-maker swaps and not for the 4-pair groups, it is a 3.
- **If old scores carry no signal even at home** (home C_w ≈ 0.5, most θ flagged): **reject (2)** for this paper. The registered pilot gate (home C_w ≥ 0.58, prereg 9.3) should stop the main run before this happens. A reframed paper ("learned usefulness scores in exemplar memory barely rank items under their own model") could reach 3, but only with the stored-answer-correct baseline (R1.29) and the near-duplicate analysis (R2.40), neither of which exists.

---

## 5. Ranked actions for the authors (most valuable first)

| # | Action (one owner each) | Needs real results? |
|---|---|---|
| 1 | Settle the construct of θ before the freeze. State θ → ρ·sd(δᵗ)/sd(δˢ) in §3.2. Define ρ̂ and report it (or R_std) beside θ in Table 1, the abstract-level numbers and Fig. 1's caption. Register a secondary NI on ρ̂. Retitle the quantity, or the question, so that "rank" is not claimed for a scale-dependent ratio. | No: now (prereg and text). Numbers later. |
| 2 | Freeze and deposit the pre-registration (OSF or similar) before the first paid call, after fixing its inconsistencies: 11.1's 4-SE rule; P1's plain permutation (switch to the maker-preserving partial test used for F1); the P3/T2 contradiction; stale "task bootstrap" wording; internal roles. Fill App. M and remove "dated" from App. C until it is true. | No: now. |
| 3 | Scope the information limit honestly. State it for checks on uniformly drawn whole tasks. Report it as an estimate with an interval, and label the 262 as second-order. Add Ā_home > 0 to Prop. 5.1. State that the paired test needs the old model's per-candidate results on the check tasks, collected before retirement. Answer R2 Q8 (adaptive choice of tasks or cells), or drop "any rule". Reconcile "about twice" with 720/262. | No: now. |
| 4 | Restructure the body. Move the stakes table (with own − keep and keep − relevance) and the per-pair forest plot into §7, and P4 into the body as the test of "mostly across makers". Shrink §4 to the identity and one paragraph, and move γ̂, family T and Fig. 2 to the appendix. If Fig. 2 stays, plot θ̂ against γ̂ with the two-way bars the caption claims. | No: layout now; numbers later. |
| 5 | Make the agent leg able to answer. Write a power analysis for family L (150 tasks × 2 repeats). Use many shuffle permutations, not seed 0 alone. Add at least one cross-maker old→new pair (the paper's headline contrast) to the registered scope. Resolve the §6 TODO. Then run it. | Design now; results need runs (≈ USD 18–90 per pair). |
| 6 | Report family T by the registered readings. Implement prereg 11.2.4's group readings in `msr/theory.py`, quote them (not "not rejected") in the intro, and print the equivalence results beside them. Explain or fix the 20–25 % low γ̂ in the simulator before printing it beside the truth. Add the calibration-task (cross-fitted) γ̂ asked for by R2 and R3, or stop calling the decomposition an account of each pair. | Code and text now; numbers later. |
| 7 | Add the cheap construct checks, all computable from the probe tables: a "stored answer is correct" score (θ and C_w at home and after the swap); the share of informative and tied pairs and of gold-matching or near-duplicate candidates, with θ excluding them; k-shown results from the subset runs for swap pairs. | Code now; numbers need results. |
| 8 | Fix the visible inconsistencies: Fig. 2 bars vs caption and "Predicted"; forecast figure T → θ; Table 1's SD column (label it pooled, or compute per group); "equivalence equivalence"; decimals; "1.000 of cells" → "all"; Fig. 1's "agrees as strongly" and "(new model)"; the "thinking off" vs "reasoning effort TODO" clash. | No: now. |
| 9 | Clear every TODO that needs no results: licences (settle BIRD's CC BY-SA vs CC BY-NC, and delete "per team notes" from the printed table); verbatim prompts with sha256; datasheet fields; release checklist; Accessibility; anonymous link; an AI disclosure that names tools and versions and states only what is true. Strip comments before any source upload. | No: now. |
| 10 | Close the related-work gaps. A person should read in full (in a browser) the three anonymous OpenReview submissions and the two table-only rows, or stop treating them as closest. Cite Wang et al. (NeurIPS 2023, demonstrations transferred from a small LM), Bansal et al. 2019 and BCT, tinyBenchmarks and anchor points (already in the `.bib`), "When the Judge Changes...", and Learner2Skill with the skill-transfer benchmarks. | No: now. |
| 11 | Put into the paper what the code already computes: second-bank variance; z-scored-mix sensitivity; source/target effects; repeat agreement per model; task overlap across orders; the online run's swap list with τ95 and S_100. Register the cross-maker old→new subset as a named secondary stratum. | Registration now; numbers need results. |
| 12 | Rewrite the outcome-dependent sentences only after the confirmatory output. Keep "mostly across makers" only if P4 passes. Write the swap-day rule by kind of swap and budget in §9, or delete "a default has to rest on what is known before the swap". Scope "after upgrades" to "these four upgrade pairs" in the abstract. | Yes. |
