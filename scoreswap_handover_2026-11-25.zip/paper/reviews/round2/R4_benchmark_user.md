# Review R4 (round 2): ScoreSwap — the benchmark-user review

Track: Datasets, Evaluations and Benchmarks. Reviewer stance: I build and use LLM benchmarks; my
question is whether other people could and would use this one, and whether its measure means what
the paper says it means.

Read: `paper/dryrun.pdf` (33 pages) and `paper/sections/*.tex`; `docs/BENCHMARK_GUIDE.md`;
`release/sim/` (SCHEMA.md, manifest.json, the tables); `prediction/PREREGISTRATION.md`; `README.md`;
the code in `scoreswap/`, `msr/` and `config/` where needed. I did not read the authors' internal
notes. The numbers in the dry run come from simulated models and I do not mark the paper down for
that; for each main claim I say which real result would make it fail or make it uninteresting
(section "What real results would sink each claim").

Everything I ran is in `paper/reviews/round2/r4_user_test/` (entries, attacks, scores, boards, logs).

---

## Summary

The paper asks whether per-item usefulness scores that a memory learned under one model still rank
the items for a different model. Eight models from four makers (two closed and two open-weight
old-to-new pairs) each write a 250-item bank (an item is a past single-call task plus the model's own
unlabelled answer) on DDXPlus diagnosis and BIRD text-to-SQL, in three task orders, then run a
1,500-showing score phase that keeps five score types per item. For all 64 owner-reader cells and
500 probe tasks per order, the reader's graded result is recorded with each of the owner's 4 most
similar items shown alone (twice) and with no item (twice). The headline is the retained ranking
signal theta = sum V_swap / sum V_home, where V sums the reader's outcome differences signed by the
old score order. Around it: 15 pre-registered Holm tests, a "transfer decomposition" (theta tends to
gamma + L / E[a delta_s]) with a specification test, a sequential keep-or-drop test with an
information lower bound, a pre-swap forecast, an agent leg on MemRL's released code, and an offline
scorer (`scoreswap`) that lets outsiders score new swap-day rules and score types from frozen tables.

The design question is good and the isolation of "score order" from "content" is the control the
literature has been missing. The statistics are careful. But as a benchmark, in its current form,
it fails the two tests I care about most: (1) the public leaderboard can be won by memorising the
evaluation split, which ships in the public pack, and nothing in the paper or tool addresses this;
(2) the headline theta does not measure what the title asks ("do the scores still rank items?"): it
is a slope that mixes order agreement with how much the new model cares which item it is shown.
There are also a real budget leak in the scorer, a scope gap between "agent memory" in the title and
one-shot example selection in the experiment, and an incomplete datasheet, licence and maintenance
story.

---

## User test

### What I did

I acted as an outside researcher with only Appendix B ("Submitting a Rule to ScoreSwap",
`A14_rule_interface.tex`) and `docs/BENCHMARK_GUIDE.md`. I did not open the scoreswap source until
step 4.

1. Copied the template and ran `check` on it unchanged (7.3 s, all PASS).
2. Wrote a new swap-day rule, `r4_user_test/entries/leverage_eb.py`: spend the k checks on the
   items that appear most often among the evaluation tasks' candidates (candidate lists are public),
   then blend fresh results into the old ema_grade score with a prior strength that depends on the
   kind of swap (8 at home, 4 within a maker, 1 across makers; `--set n0_cross=` overrides).
3. Wrote a new score type, `r4_user_test/entries/lcb_grade.py`: a pessimistic score, the 10 % lower
   confidence bound of each item's graded success rate.
4. Ran `check`, `score --budget 16`, and `leaderboard` on both. Boards are in
   `r4_user_test/boards/`.

Results, so the authors can see the tool does produce interpretable output:

| entry | kind | upgrades | downgrades | cross-maker |
|---|---|---|---|---|
| leverage_eb, k = 16, first-shown success | rule | 0.704 | 0.615 | 0.599 |
| minus keep (paired 95 % interval) | | 0.000 [-0.009, 0.010] | 0.006 [-0.015, 0.026] | 0.017 [0.002, 0.032] |
| minus recal_16 | | 0.025 [0.007, 0.044] | 0.026 [0.004, 0.049] | 0.027 [0.007, 0.046] |
| lcb_grade, theta (ema_grade beside) | score type | 0.75 (0.73) | 0.65 (0.75) | 0.19 (0.20) |

My rule tops the k = 16 board for upgrades and cross-maker swaps; my score type does not beat the
paper's types. The ema_grade theta values (0.73, 0.75, 0.20) match the dry-run abstract and
Figure 1, so I could relate the pack to the paper's tables for theta. I could not relate the rule
numbers to the paper's Table 8 directly, because the dry run's primary k is 32 and the guide's
example uses 16. On the k = 32 board the paper's rules match Table 8's point estimates to three
decimals (keep 0.703 / 0.609 / 0.581, recal_32 0.682 / 0.597 / 0.571), but not its intervals:
keep after upgrades is [0.646, 0.761] on the board and [0.651, 0.754] in Table 8, recal_32
[0.624, 0.740] against [0.631, 0.733]. Nothing tells a user which variance each one uses, so I
could not reproduce a single interval of the paper.

Timings on this machine (8 cores, shared with a background job at load about 14): `check` 4-7 s;
`score` for a score type 9 s; `score` for a rule at one budget 1 min 48 s with the paper's rules
beside it and 27 s without; `leaderboard` for two entries over budgets 0-64: 9 min 27 s.

### Frictions, worst first

1. **scipy crashes the sealed checker with an internal error.** My first `lcb_grade` used
   `from scipy.stats import beta`; the second `from scipy.special import betaincinv`. Both end in a
   Python traceback inside the harness: `AttributeError: 'ChildRunner' object has no attribute
   'denied'` (`scoreswap/harness.py:525`), with no word about what was wrong. The guide names scipy
   as one of the three packages the tool needs, and nothing says an entry may not import it. `--trusted` works. Cause (found in step 4): the child
   puts the project root on `sys.path` (`scoreswap/_child.py:113`) but the audit hook forbids
   listing it, so a fresh import such as `scipy.stats` is "denied" during loading; the harness then
   reads the denial in `ChildRunner.__init__` before `self.denied` exists (assigned at
   `harness.py:498`, after the first `_recv()` at `:493`). Minimal reproduction:
   `r4_user_test/scratch/scipy_stats_probe.py`. I rewrote the score type in plain numpy.
2. **The guide does not document the interface; the template points into the source.** The guide
   describes `bank`, `candidates`, `swap` and `checks` in one sentence each. The template says
   "every field is listed in scoreswap/api.py". To write a rule that names cells I had to discover at
   run time (by raising an exception with `dir()` output, `r4_user_test/scratch/explore_api.py`) that
   cells are `CheckCell(id, task, item, position, item_index, max_answers)`, that `checks.by_item` maps
   an item id to cell ids, that answers carry `.cell` and `.answer_number`, that the rule is also
   called on home cells (`swap.kind == 'home'`), what the four `swap.kind` strings are, and that
   `--set` values arrive as strings. Appendix B says a check "may also carry the reader's no-item
   result"; neither the guide nor the template says how (`with_no_memory=True`, `api.py:226`).
3. **No installable package; outputs land in the repository.** `python -m scoreswap` works only from
   the repository root, and `score` and `leaderboard` default to `scores/` and `boards/` in the
   current folder, i.e. inside the benchmark's own tree. The guide never mentions `--out`.
4. **Speed will not scale to the real study.** The release pack is a toy (4 models, 1 stream, 2
   orders, 80 items, 56 evaluation tasks per order: 32 (cell, order) units). The real tables have 384 (cell,
   stream, order) units, about 400 evaluation tasks per order and 250 items. Scaling my timings
   linearly in cells times tasks (about 84 times the toy) gives roughly 2.5 hours per entry per budget
   with the paper's rules beside it (40 minutes without), about 13 hours for a leaderboard of my two
   entries over five budgets, and days once a board holds a dozen entries. The paper promises boards "re-run from the
   released tables" for every entry; the cost of that promise should be stated.
5. **"Home cells" means two different things in two summaries.** In a score type's SUMMARY.md the
   home row is the self-swap (repeats 3-4 against 1-2; lcb_grade 0.90). In a rule's SUMMARY.md the
   home row uses the same repeats in numerator and denominator (`scoreswap/harness.py`, `CellTables`:
   `Tr = yr = O.home`), so my rule gets theta = 1.04 at home and 1.12 for one owner. Neither summary
   says which.
6. **The family behind a rule's theta is hidden.** A rule's theta divides by "the owner's score of the
   rule's score family", which is ema_grade unless `--set family=...` (`scoreswap/scoring.py:13-14`,
   `:91`). The guide and template never mention it, so a beta_grade-based rule is silently compared
   against ema_grade's home signal.
7. **Small things.** With `--no-compare` the summary table has an empty column header. The guide says
   an entry may read "its own folder and Python"; the check's allowed list also includes `msr/`,
   `scoreswap/` and the user's conda installation. The guide says three packages are needed but
   installs `requirements.txt` (anthropic, openai, datasets, fastembed, matplotlib, pytest). The
   budgets 128 and 256 are listed in the guide but do not fit the pack (96 calibration cells); the
   tool skips them correctly, but the guide does not warn. The README still says "across 12 real
   model changes" (`README.md:16`) while the paper has 56.

What worked well: every check line says PASS or FAIL with a reason; the outputs give per-pair
numbers with two-way intervals and paired differences against the paper's rules; `run.json` records
the entry's sha256, the pack fingerprint and the `--set` options; the symlink and ctypes attacks
below were refused with clear messages.

### Breaking it

All attacks are in `r4_user_test/attacks/`. "Passes" means all four lines of `scoreswap check`
said PASS.

| # | attack | passes check? | effect on the board |
|---|---|---|---|
| A1 | **Memorise the exam.** `hardcoded/leak_hardcoded.py`, one 9 KB file, embeds the best candidate of all 1,792 evaluation tasks, computed offline from the public `harness_only/evaluation_results.csv` (`gen/make_hardcoded.py`). Opens no file at run time. | yes, all four | first-shown success 0.897 / 0.846 / 0.870 (upgrades / downgrades / cross) with 0 checks, regret 0.000, theta 1.47-1.60: exactly the paper's in-sample ceiling. Best honest entry at k = 16: 0.704 / 0.623 / 0.599. |
| A2 | **Read a copy of the exam from the entry's own folder** (`copy/leak_copy.py`). The entry folder is readable by design; the canary permutes only the harness's copy. | yes, all four | same as A1 |
| A3 | Read the harness's own exam file through a symlink in the entry folder | no: refused, the hook resolves the real path | none |
| A4 | Read it through libc (`ctypes`) | no: `ctypes.dlopen` refused | none |
| A5 | **Exceed the budget through process state.** `persist/blend_accumulate.py` keeps every answer it has been given in a module-level dict. The harness runs all draws and all cells in one long-lived child process (`persist/persist_probe.py` saw 40 calls in one process), so by the sixth draw the rule holds both answers of every calibration cell while asking only k per call. | yes, all four; reported "checks used 16.0" | against the identical rule without the cache (`blend_honest.py`): cross-maker 0.590 to 0.624, downgrades 0.616 to 0.644, theta across makers 0.27 to 0.56 |
| A6 | **Tune on the evaluation split.** Four `score --set n0_cross=...` runs of my own rule (0.25, 1, 4, 16) give cross-maker 0.595, 0.599, 0.583, 0.582; I would report 1. | n/a | +0.017, about the size of the gaps that separate entries on the board |
| A7 | **Steer the "seeded" random checks.** The child sends its RNG state to the harness, which draws "random" cells with it (`scoreswap/harness.py`, `run_rule`). One call to `checks.rng.random()` before `checks.request(random=8)` changes the cells from [4, 9, 15, 26, 29, 32, 52, 80] to [9, 12, 15, 25, 28, 31, 57, 78] (`persist/rng_probe_0.py`, `_1.py`). | yes | no unfair gain (naming cells is allowed anyway), but the board's promise that random rules use "the same random checks" as recal_k, which the paired intervals rely on, silently fails for any honest rule that uses `checks.rng` first, as the template tells it to |
| A8 | Condition on the 8 public model names and makers (`swap.reader`, `swap.reader_maker`, `swap.kind`) and hard-code per-pair choices learned from the tables | yes (not tested separately; A1 is the extreme case) | the board has no held-out model or maker, so a rule's rank says nothing about a ninth model |

**What stops a submitter from tuning on the evaluation split? Nothing, and the paper does not raise
the question.** The exam is in the public pack, every board is computed on that same exam, there is
no development split separate from the scored split, no hidden split, no cap on submissions, no
rule about declaring tuning, and the "sealing" protects only the harness's own file at run time.
`A14_rule_interface.tex:38` says "a new entry is listed only after the scorer has re-run it from the
released tables"; re-running a memorised exam reproduces the memorised score. The word "sealed" in the
abstract (`00_abstract.tex:11`) and Section 3 (`03_benchmark.tex:66`) promises more than an audit
hook plus a permutation canary can deliver, and A1, A2 and A5 pass every check.

### What the source explains (step 4)

- A2 works because `allowed_roots()` includes the entry's own folder by design
  (`ChildRunner` docstring, `harness.py`); the permutation canary changes only the harness's copy.
- A5 works because `_child.py` loads the module once and serves every (cell, draw) from the same
  process; the budget is counted per call by the parent (`server.handle`), which cannot see state
  kept across calls.
- The check's determinism test re-runs in a new process in the same order, so deterministic
  cross-call state passes it.
- The authors' own cheat tests (`tests/test_scoreswap_cheats.py`) cover opening the exam file,
  guessing the pack through the project folder, network and writes, over-budget and third asks, bad
  outputs, non-determinism, an entry placed beside the pack, and a `--trusted` rule reading the
  harness's memory. None covers a memorised exam (A1), a copied exam (A2) or state kept across calls
  (A5); these should become must-fail tests.
- A3 and A4 fail because `_child.py:47-62` resolves every path with `realpath` and `_child.py:66-70` blocks
  `ctypes.dlopen`, process and network events. That part is solid.

---

## Fact check of statements in the paper

I checked these against the code, the configuration and the pre-registration.

| # | statement (place) | verdict | evidence |
|---|---|---|---|
| 1 | ema_grade is q <- q + 0.3 (y - q) from q = 0.5 (`03_benchmark.tex:18`) | correct | `msr/scores.py:176-177, 194`; `config/study.yaml` `scores.ema_alpha/ema_q0` |
| 2 | score phase: one of the 4 most relevant items by 0.5 u + 0.5 rel, 0.3 chance of a uniform draw, three passes (`03_benchmark.tex:14`) | correct | `config/study.yaml:40, 43, 45` |
| 3 | score ties within 1e-12 get sign 0 (`03_benchmark.tex:31`) | correct | `msr/scores.py:64`; `msr/metrics.py:1402` |
| 4 | theta flagged when the owner's calibration signal is under 2 SE (`03_benchmark.tex:39`) | correct | `msr/metrics.py:1363` |
| 5 | k in {8, 16, 32, 64}, 128 and 256 exploratory (`03_benchmark.tex:50`) | correct | `config/study.yaml` `evaluate.k_values` |
| 6 | 250 write, 500 score, 500 probe (400 + 100), 250 test tasks (`04_setup.tex:14`) | correct | `config/study.yaml:26`, `evaluate.calib_tasks: 100` |
| 7 | thinking off on every model (`04_setup.tex:6`) | correct as configured, unverified | `config/models.yaml:33, 60, 67, 125, 144` (each marked "verify at smoke test"; Table 5 still has red TODOs) |
| 8 | open-weight models at temperature 1.0, top_p 1.0, no top_k (`04_setup.tex:7`) | correct as configured | `config/models.yaml:123-124, 142-143, 165-166` |
| 9 | MemRL keeps memories above similarity 0.50 and picks 5 by an equal mix of z-scored similarity and value (`06_agent_leg.tex:6`) | correct | `legs/memrl/README.md:97-103` |
| 10 | 200 seeded draws per cell (Appendix A) | correct | `config/study.yaml:74` |
| 11 | "visits, a count of showings, carries no usefulness signal" (`03_benchmark.tex:22`) | **wrong** | the build picks items by ema_grade (`config/study.yaml:46`, `drive: ema_grade`), so showings follow the score. In the simulated run, visits has home concordance 0.650, 0.570, 0.558, 0.566 for the four owners (`runs/sim/results/validity.csv`, order 0), close to ema_grade's 0.657 for the first owner; on my leaderboard visits ranks **first** among score types for cross-maker swaps (theta 0.34) and second for upgrades (`r4_user_test/boards/score_types.md`). It is a proxy of the driving score, not a null baseline. |
| 12 | "All tests are fixed in a pre-registration" (`03_benchmark.tex:57`; "dated", `A9_statistics.tex:4`) | not yet true | `prediction/PREREGISTRATION.md:3`: "Status: DRAFT. Not frozen."; registry fields blank. Acceptable before the run, but the sentence must not survive into a submission unless the freeze happens first. |
| 13 | "all nine rules and seven references here are scored this way" (`01_introduction.tex:50`) | **wrong** | the scorer's entries cover keep, wipe, fixed, recal, powerprior, retest, audit, pooled, fresh (`scoreswap/scoring.py:42-44`; `parity.py:82`); there is no entry for none, constant, own, split_half or ceiling (`scoreswap/reference_rules/`), and `own` cannot be one, since entries may not receive the reader's bank |
| 14 | the released probe tables hold "every graded result with its call's returned model string, time, tokens and cost" (`07_discussion.tex:8`; datasheet `A2_datasheet.tex:8`) | **wrong for the pack format** | the exporter writes 10 columns: owner, reader, stream, order, task_id, position, item_id, set, repeat, result (`scoreswap/export.py:301`; header of `release/sim/calibration_results.csv`) |
| 15 | the scorer runs a rule "sealed from the evaluation outcomes" (`00_abstract.tex:11`, `03_benchmark.tex:66`) | **misleading** | true only for the harness's own file at run time; attacks A1, A2 and A5 pass every check |
| 16 | "A rule never receives ... the reader's own bank" (`A14_rule_interface.tex:14`) | **not enforced** | one child process serves all cells, so a rule called on the reader's home cell keeps the reader's bank for later cells; all banks are also in the public pack |
| 17 | numbers are reported "next to keep, wipe and the paper's rules on the same tasks and draws" (`A14_rule_interface.tex:27`; guide: "the same random checks") | partly | draws are seeded by arm name (`msr/evaluate.py:443`, `harness.py:58-61`), so they are shared only with recal_k, and only if the rule does not touch `checks.rng` first (attack A7) |
| 18 | the paper's rules reproduce its per-rule results with differences below 1e-13 (`03_benchmark.tex:66`) | correct for point values | my run of `python -m scoreswap.parity --study sim --pack release/sim`: ALL MATCH, largest per-task difference 1.02e-14 (audit_32), over 31 rule variants and the 5 score types; it checks values, not intervals (see the interval mismatch in the user test), and does not cover none, constant, own, split_half or ceiling |

### Do the title and abstract promise what the paper delivers?

- "Agent-Memory": the core experiment is one-shot example selection among four candidates on
  single-call tasks (weakness 4).
- "Still Rank Items": the headline theta measures how much of the old order's success-point value
  survives, which is not the same as whether the order survives (weakness 3).
- "sealed from the evaluation outcomes": true only for the harness's own file at run time
  (weaknesses 1 and 2).
- "any rule that chooses among the stored candidates from old scores and a budget of fresh checks":
  an honest and precise scope statement for the interface; I would keep it.
- "the paper's own rules, entered the same way, reproduce its per-rule results exactly": see the
  parity run at the end.
- Sentence 5 packs a lower bound, a median stopping time, an undecided share and an audit false-keep
  rate into one sentence; I had to read it three times.

---

## Strengths

1. **The right control.** Holding content fixed and changing only the reader isolates whether the
   scores' order transfers, which end-task transfer results cannot. Every owner writes its bank on
   the same write tasks, so candidate sets are the same tasks across owners and only the answers
   differ: a clean design.
2. **A full ordered grid with a self-swap reference.** Home cells get two extra repeats in a later
   session, which gives a self-swap reference and the cross-session estimator of gamma that is robust
   to within-session caching. This is better practice than most model-comparison benchmarks.
3. **Serious statistics.** Two-way clustering on task id and item (multiple membership), Fieller sets,
   a Holm family whose size was checked by simulation, swap-minus-home contrasts so that a rule's gain
   at home is not credited to the swap, level-corrected log scores, an in-sample ceiling labelled as
   such, and a "split_half" reference correctly labelled as not a bound.
4. **A clear technical point about measures.** Proposition 4.2 shows that the concordance ratio R moves
   with the reader's outcome spread; the simulated figure that cuts one model to one repeat makes the
   point well.
5. **An honest related-work table** that says, per cell, whether the authors read the full text, the
   abstract or a cached review record, and an outside check on Beyond Gain's released scores that
   shows the question is real before any money is spent.
6. **The scorer is a real piece of engineering**: a child process with an audit hook that resolves
   symlinks and blocks C libraries, a permutation canary, a determinism check, per-pair outputs with
   paired intervals against the paper's rules, entry hashes and options in `run.json`, a parity tool
   that passes (every reference rule and score type within 1.02e-14 of the paper's own numbers),
   a SCHEMA.md that explains every column, a manifest with sha256 per file, and a canary string.

---

## Weaknesses (most serious first)

### 1. The leaderboard can be won by memorising the public evaluation split, and the paper does not address it

Place: abstract last sentence (`00_abstract.tex:11`); Section 3.3 "Using ScoreSwap"
(`03_benchmark.tex:62-67`); Appendix B "Two leaderboards" and "Commands" (`A14_rule_interface.tex:35-50`);
guide "Fair play, in short".

The pack ships `harness_only/evaluation_results.csv` to everyone. The "sealing" stops a rule from
opening the harness's copy at run time, but nothing stops a submitter from reading the public file
offline and embedding the answer in the rule (A1: a 9 KB file reaches the in-sample ceiling with 0
checks and passes every check), reading a copy from the entry folder (A2), or tuning knobs on the
same split that is scored (A6). Every board is computed on that one split, and the 8 model names
are public inputs, so even an honest entry can overfit to these 56 pairs (A8). For a benchmark whose
main deliverable is a public leaderboard, this is the central validity question, and the paper is
silent on it.

Fix: (a) keep a private evaluation split that only the maintainers score (for example one of the
three orders, or a third of the evaluation tasks of every cell), publish boards on it, and let
outsiders develop on the public split; (b) for the open-weight readers, which can be re-run, add a
"fresh calls" verification for top entries; (c) give the board a held-out dimension (leave one maker
out, or score only on swaps into a reader the entry's author never saw); (d) forbid data files in
entry folders and cap entry size, or require entries as a single file; (e) state the honour-system
limits plainly in Appendix B and the guide; (f) drop or qualify "sealed" in the abstract.

### 2. The scorer leaks budget through process state

Place: Appendix B "What a swap-day rule receives", item 4, and "The scorer, not the rule, counts the
checks used" (`A14_rule_interface.tex:12, 19`).

One long-lived child process serves every (cell, draw), so module-level state survives (A5). A rule
that stays within k per call but caches answers across the 200 draws sees the whole calibration pool;
in my test it raised cross-maker first-shown success by 0.034 and doubled theta, while the board said
"checks used 16.0". The same mechanism also defeats "never receives the reader's own bank". The
calibration results are also public, so a rule can hard-code all of them at k = 0.

Fix: run each (cell, draw) in a fresh process or a forked clean snapshot; add a check that permutes
the order of draws and cells and requires each per-call output to be unchanged; serve calibration
results server-side for the private board. Also fix the RNG coupling (A7): draw the rule's random
cells from a harness-owned generator, not from the state the child sends.

### 3. Theta is not a measure of whether scores "still rank items"

Place: title; eq. (1) and the sentence "1 keeps all of the home signal, 0 none"
(`03_benchmark.tex:34-38`); Introduction "unlike a ratio of concordances it does not move with the
new model's outcome noise" (`01_introduction.tex:38`); Proposition 4.2.

By the paper's own Proposition 4.2, theta tends to gamma + L / E[a delta_s], and gamma =
E[delta_s delta_t] / E[delta_s^2] = rho x sd(delta_t) / sd(delta_s). So, where L is near 0, theta is the product of
(i) how well the two models' item usefulness agrees (rho) and (ii) how much the new model's success
depends on which item it is shown, relative to the old model (the spread ratio). A stronger reader
that solves most probe tasks whichever item it sees gets theta near 0 even if the old order is
exactly right for it; a reader that copies the shown answer more readily gets theta above 1 with an
imperfect order. The scale has no ceiling at 1: values above 1 already appear in the dry run (self-swap
references up to 1.105, diagonal cells 1.13-1.14), there from noise, but nothing in the measure stops
a more item-sensitive reader from producing them for real.
Upgrades usually make models stronger and less sensitive to one in-context example, so a low theta
after upgrades is what you would expect from capability alone. The paper argues that R is confounded
by outcome noise and moves to theta, but theta is confounded by outcome stakes. The title's question
is answered by rho, not by theta.

This also shows on the leaderboard: score types are ranked by theta, which rewards losing less rather
than ranking better. tags_self has the best concordance after upgrades (0.694) and ranks fourth;
visits, which the paper calls signal-free, ranks first across makers.

Fix: the paper already computes rho-hat, but only as a comparator for the decomposition's error.
Promote it: report rho-hat and the spread ratio sd(delta_t)/sd(delta_s) per pair and per group beside
theta, with intervals, and make the headline figure show theta as their product; rename theta for what it is (retained
ranking value, in success points); rank score types by concordance or V after the swap, with theta
beside. If rho-hat rests on the reader's within-session repeats, add a separate-session pair of reader
repeats on a subset of swap cells, since within-session products are biased by caching, as the paper
itself shows (Appendix N (i)).

### 4. The title promises "agent memory"; the experiment is one-shot example selection among four candidates

Place: title; abstract sentence 1; Introduction "What an item is here"; Section 8 (agent leg).

The core item is (task, own unlabelled answer) for single-call DDXPlus and BIRD tasks; one item is
shown; the choice is among the 4 most similar items; scores rest on about 6 graded showings per item
on average (1,500 showings over 250 items, skewed by exploitation). That is in-context
demonstration selection with a learned utility, which the paper concedes in its own words. Deployed
scored memories (MemRL, ACE, EvolveR) retrieve sets (MemRL: up to 10 candidates, 5 shown), store
trajectories or insights, and mix z-scored values with similarity. On DDXPlus in particular, an
item's usefulness may largely be whether its stored answer equals the probe's diagnosis (the
limitations note that neighbouring tasks share answers), which makes the task closer to
nearest-neighbour label propagation than to experience reuse. The only bridge to agents is the agent
leg, which runs upgrade pairs only, as many as a budget allows in a fixed maker order, with results
pending, and which measures keep minus shuffled rather than ranking. The Shapley realism check covers
only upgrade pairs on 100 tasks.

Fix: retitle (for example "Do Learned In-Context Example Scores Survive a Model Swap?") and scope the
abstract, or make the agent leg co-primary with at least two pairs and both directions, and report
how much of the item effect is explained by answer match on DDXPlus.

### 5. Eight models, four pairs: too few to say anything about "model swaps" in general

Place: abstract; "What we found"; Limitations "Models and inference".

Each same-maker group has 4 pairs that differ in what changed (a version step; a version step that
skips a version, Qwen3.5 to Qwen3.8, while Appendix G calls Qwen3.6 to Qwen3.8 "the one true version
upgrade"; a size and architecture change, Gemma 3 27B to Gemma 4 31B). Intervals treat the models as
fixed, so a group estimate is a statement about these four pairs, not about upgrades. Cross-maker
swaps (48) are confounded with closed versus open weights and with capability gaps, and all eight
models are small, cheap tiers. The Limitations section says much of this; the abstract and Figure 1's
caption do not.

Fix: put the between-pair standard deviation and a prediction interval for a new pair next to every
group number; phrase the abstract as "for these four upgrades"; add open-weight pairs (cheap, and
they never retire) to grow the same-maker groups.

### 6. The swap-day decision results follow from the probe design, and the leaderboard cannot reach them

Place: abstract sentence 5; Section 5; Theorem 5.2; Results "How many checks does a decision need?".

The information bound is classical, and with tasks of four binary checks and a home signal near 0.2
the conclusion (hundreds of tasks for a controlled keep-or-drop) is arithmetic the appendix already
does before any data (Appendix N). It also holds only for that observation scheme: rules that target
checks at high-leverage items (my entry beats recal_16 by 0.027 across makers with 16 checks) are not
"tasks of four checks". The paired test needed 720 tasks in the dry run and left all swap cells
undecided "within the table", and the board's largest budget is 256 checks (64 tasks), so no entry on
the board can make the decision this section studies. A practitioner wants the expected gain per
check, not 5 % error control.

Fix: present the bound as a property of this probe design and observation scheme; add a
decision-theoretic summary (first-shown success gained per check, by kind of swap and k); either size
the replay pool so the sequential test can decide, or move this section to the appendix and use the
space for the benchmark.

### 7. Release, datasheet, licences and prompts are incomplete, and some promises do not match the pack

Place: Section 9 "Release"; Appendices H (datasheet), I (licences), J (prompts), L (checklist).

Red TODOs are visible in the submitted PDF in Section 6 ("state which legs ran"), Accessibility,
Software and Data, the AI Use Statement, Table 5, the datasheet (row counts, collection window,
removed tasks, distribution, maintenance), every licence row except Beyond Gain, the prompts
appendix (no prompt text at all), and 11 of 14 checklist rows. The BIRD licence conflict (CC BY-SA on
the site, CC BY-NC in the dataset's datasheet, as Appendix I itself records) is unresolved. The pack's format does not carry
the per-call fields the paper promises (fact check 14). Item and task text are not released; task ids
let users rebuild text from the public datasets, which deserves a sentence, but without text no
outsider can write a content-aware rule. For this track, a datasheet, hosting, licence per file and
a maintenance plan are part of the contribution, not camera-ready chores.

Fix: complete every TODO before submission; release prompts verbatim with the sha256; either add the
per-call fields to the pack or a separate call-log file and say so; resolve BIRD's licence or say
which licence the released derivatives carry; add Croissant metadata now.

### 8. What will go stale, and the maintenance story

Place: Section 4 "after the closed models retire, the 12 ordered swaps among the open-weight models
can still be re-run"; Appendix B "Adding a reader model costs ..."; datasheet "Maintenance: TODO".

The closed models (Haiku 4.5, GPT-5.6 Luna) will retire; the open ones are reached "through a host we
do not control". By my count from `config/study.yaml`, adding one reader costs about 0.2 M calls
(8 owners x 2 streams x 3 orders x 500 tasks x 4 candidates x 2 repeats, plus no-item runs), and
adding one owner about 0.26 M (its build plus 9 readers); a new owner can never be read by a retired
reader, so the grid becomes ragged. The paper gives no number for either, no versioning scheme, no
contact or issue tracker, no plan for what the board means once half the readers are gone, and the
leaderboard ranks rules for a fixed 2025-2026 set of models.

The cost table (Appendix K) has the right shape (calls, tokens and dollars per model, and the reader
calls each rule needs on a real swap day), but it does not give the marginal cost of extending the
grid, which is what a maintainer or a lab joining later needs.

Fix: state the calls and dollars per added reader and owner; version the pack (v1 = these 8);
define a stable open-weight core (the 12 swaps among the 4 open models, re-runnable end to end with
pinned weights) as the long-lived board; publish a deprecation policy for retired readers.

### 9. Tool problems a first user hits

See the user test: the scipy crash (an outright bug), an undocumented interface, no installable
package and outputs inside the repository, run times that will not scale to the real tables, an
unexplained "home" row, the hidden reference family for a rule's theta, intervals on the board that differ from
the paper's Table 8 for the same rule, and boards that rank by point estimates whose intervals
overlap (0.704 vs 0.703 for ranks 1 and 2 at k = 16). Fix: fix the
`self.denied` initialisation and allow listing the project root or drop it from `sys.path`; move the
API reference into the guide; make `scoreswap` pip-installable with outputs defaulting outside the
package; cache the paper's rules once per pack and budget (they are recomputed on every
`leaderboard` run into a new folder); group board ranks by paired intervals against keep.

### 10. Smaller points on design and statistics

- The level correction anchors every rule's predictions to the reader's **no-item** success, while
  the predictions are of success **with** an item; the offset cancels only to first order and
  differs by how spread out a rule's p is. Anchor to the with-item success of the checked cells, or
  justify the choice. (`03_benchmark.tex:46`, Appendix A.)
- The home signal is weak by design (home concordance about 0.66 in the dry run; the pilot gate is
  0.58), so theta is a ratio of small numbers and the four-pair groups are likely to read
  "inconclusive". The power section admits this.
- The score phase runs one exploration policy driven by ema_grade, so the other four types are
  computed on data selected by ema_grade; the paper should say that comparisons between types are
  conditional on that policy.
- "keep five types of score per item over 1,500 showings" (`01_introduction.tex:35`) reads as 1,500
  per item; it is 1,500 per bank.
- The cost table lists `powerprior_flat_k`, which the paper never defines.

### 11. Length and density

The 8-page body carries a benchmark, a measurement with 15 tests, a decomposition with 9 more tests,
a sequential test with a lower bound, a forecast, four predictions, an agent leg and a post-swap
run, with 25 pages of appendix. Several sentences carry five or six numbers (abstract sentence 5,
"What we found"), and the reader must hold about twenty coined terms (owner, reader, home, fresh
check, first-shown success, PC1-drop, PC1-NI, family T, family L, ...). Table 1 is shrunk to roughly
5-point type by `\resizebox` (`macros.tex:28`); dry-run numbers print with inconsistent precision
("0.0692", "1.000 of swap cells"). For this track the benchmark interface (Appendix B) belongs in the
body and the decomposition, the forecast and the predictions belong in the appendix.

Accessibility: the PDF is untagged (pdfinfo "Tagged: no"); the figure descriptions passed to
`\ResFig` are used only for stubs and are not emitted as alternative text; the colour-blindness check
is a TODO.

---

## What real results would sink each claim

| claim | fails if | uninteresting if |
|---|---|---|
| Old scores lose ranking signal mostly across makers (theta by group) | same-maker and cross-maker intervals overlap, or P4 fails | the home signal is weak (theta intervals span 0.75 and 1 for both same-maker groups, both "inconclusive"); keep minus wipe at home is under about 3 points (nothing to lose); theta tracks the spread ratio while rho-hat is flat across groups (theta then measures stakes, not order); the self-swap reference is far from 1 for the closed models |
| The transfer decomposition accounts for each pair | its specification test rejects in most groups | its error is no better than rho alone: in the dry run both are 0.030 (abstract), so in the simulator the decomposition adds nothing over the correlation |
| No controlled keep-or-drop decision with a few checks | the real home signal is large (say A_home above 0.5) so tens of tasks suffice | the real home signal is near 0.2 as assumed: then the result is the bound's arithmetic, known before the run; or targeted rules reach near split_half success with 16-64 checks, so no decision is needed |
| What is at stake: keep versus wipe after the swap | n/a | keep minus wipe is within 1-2 points at home and after the swap, or after the swap equals at home (the swap changes nothing) |
| The benchmark separates swap-day rules | n/a | all reasonable rules sit within about 1 point of keep with overlapping paired intervals (the dry run's cross-maker Table 8 already spans only 0.566 to 0.596 for the nine rules, against 0.634 for split_half); the gap between keep and split_half is a few points, so the board has no headroom |
| The agent leg shows score order matters in a deployed agent | keep minus shuffled is not positive for the pairs run | keep minus shuffled is about 0 at home too: then order does not matter in MemRL at all, and the "agent memory" framing has no support |

---

## Questions for the authors

1. How will the public board be protected from tuning on, or memorising, the evaluation split? Will
   there be a private split, and who will run it?
2. Why one child process for all cells and draws? Will you move to a fresh process per (cell, draw)?
3. Can you report rho-hat and the spread ratio per pair? Do group differences in theta survive once
   the spread ratio is separated out? Will you add separate-session reader repeats on a subset of
   swap cells so that rho-hat is identified without the caching bias?
4. What are the home stakes (keep minus wipe at home) in the pilot, on each stream? What is A_home?
5. On DDXPlus, what share of an item's effect is explained by its stored answer equalling the probe's
   label?
6. How many pairs will the agent leg run, and what is keep minus shuffled at home in MemRL?
7. What do one added reader and one added owner cost, in calls and dollars, and who will pay for and
   run additions after publication?
8. Why Qwen3.5 to Qwen3.8 rather than Qwen3.6 to Qwen3.8, which Appendix G calls the true version
   upgrade?
9. Do task ids let anyone rebuild item text from the public datasets? If so, what does withholding
   the text protect, and if not, how can outsiders write content-aware rules?
10. Why anchor the level correction to no-item success? Do `with_no_memory` results count against any
    budget on the board?
11. Why rank score types by theta rather than by concordance after the swap?
12. Will the scorer's run time on the full tables allow every new entry to be re-run, as Appendix B
    promises?

---

## Scores

| | score | reason |
|---|---|---|
| Soundness | 2 | careful statistics, but the headline mixes order agreement with outcome stakes, and the scorer's integrity claims fail under three simple attacks |
| Presentation | 2 | the appendices are thorough, but the body is very dense, red TODOs remain in the PDF, and the datasheet, licences and prompts are stubs |
| Significance | 2 | a narrow construct (one-shot example choice among four, two single-call streams, eight small models) behind an "agent memory" title, and a leaderboard that can be gamed and will age with the closed models |
| Originality | 3 | the content-fixed, full-grid question is new and well motivated; the tools are classical, as the paper says |
| Overall | 3 (weak reject) | a good question and a promising resource, not yet a trustworthy benchmark |
| Confidence | 4 | I ran the tool end to end, built and broke entries, and checked the claims against the code; I have not seen real results |

## What would move my Overall score

**Up by one (to 4, weak accept):** a private evaluation split for the board and a plain statement of
what the public split can and cannot show; a fresh process per (cell, draw) and harness-owned random
draws, with A1, A2, A5 and A7 added to the test suite as must-fail cases; rho-hat and the spread
ratio reported beside theta, and theta's wording changed accordingly; title and abstract scoped to
one-shot example scores with the agent leg as a bridge; the datasheet, licences, prompts and
maintenance completed, with the cost of an added reader and owner; the scipy crash fixed and the
interface documented in the guide; the four wrong statements in the fact check corrected.

**Up by two (to 5, accept):** all of the above, plus real results that show (a) home stakes worth
the trouble (keep minus wipe at home of at least about 5 points on both streams), (b) a pattern of
rho-hat and theta across groups with same-maker intervals that exclude 1 or 0.75, (c) the agent leg
on at least two pairs with order mattering at home and a measured share surviving the swap, and
(d) at least one outside-style rule that separates from keep with a paired interval on the private
split; and a body that leads with the benchmark, moving the decomposition, forecast and predictions
to the appendix.

---

## Parity run

`python -m scoreswap.parity --study sim --pack release/sim` (log: `r4_user_test/parity_run.log`):
**ALL MATCH**. Every reference rule (keep, wipe, relevance, fixed_0.1 to 0.9, shuffled, and
powerprior, recal, retest, audit, pooled and fresh at k = 8, 16, 32) and every score type matches the
paper's own evaluation, with a largest per-task difference of 1.02e-14 (audit_32) and 0 in the printed
CSVs. This supports the abstract's reproduction claim for point values. It took 22 min 44 s on the toy
pack, it does not check intervals, and it does not cover the references none, constant, own,
split_half and ceiling.
