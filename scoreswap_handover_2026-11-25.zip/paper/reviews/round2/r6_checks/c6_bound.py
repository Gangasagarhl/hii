"""Check 6: the information lower bound (Theorem 'Information limit').

(a) Constants: the reviewer's own least-favourable KL (per-cell KKT root, bisection on nu) against
    msr.sequential.least_favourable and against the second-order closed form, in the authors'
    reviewer model and in two reviewer task models (heterogeneous tasks, many with no Bernoulli
    variance); d(1 - beta || alpha) and the bound in tasks.
(b) Is the bound's design the only one? Per CHECK, the least-favourable KL of
      uniform design (every candidate of a uniformly drawn task checked once):   D^2 / (2 * 4 E[sum_i c_i^2 v_i])
      cells allocated within a task in proportion to |c_i| sqrt(v_i):           D^2 / (2 * 4 E[(sum_i |c_i| sqrt v_i)^2] / 4)
      tasks and cells allocated (Neyman, importance-weighted, still unbiased):   D^2 / (2 (E sum_i |c_i| sqrt v_i)^2)
    with D = (theta_1 - theta_0) A_home and v_i = mu_i (1 - mu_i); second order, the reviewer's derivation.
    The ratio is the factor by which the theorem's bound (in checks) overstates what a rule that
    chooses which cells to check must spend (the lower bound for such a rule is that much lower).
(c) The bound in checks as the margin and the signal change (second order, model M2's variance).
Run: .venv/bin/python paper/reviews/round2/r6_checks/c6_bound.py
"""
import math
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", "..", "..", ".."))
sys.path.insert(0, ROOT)
from msr import sequential as S  # noqa: E402

C4 = np.array([0.75, 0.25, -0.25, -0.75])


def dbin(p, q):
    return p * math.log(p / q) + (1 - p) * math.log((1 - p) / (1 - q))


def my_least_favourable(p, c, target):
    def q_of(nu):
        k = nu * c
        disc = np.maximum((1 + k) ** 2 - 4 * k * p, 0)
        return 2 * p / ((1 + k) + np.sqrt(disc))

    def g(nu):
        return float((c * q_of(nu)).sum(-1).mean())
    lo, hi = 0.0, 1.0
    while g(hi) > target:
        hi *= 2
    for _ in range(200):
        mid = (lo + hi) / 2
        if g(mid) > target:
            lo = mid
        else:
            hi = mid
    q = q_of((lo + hi) / 2)
    kl = p * np.log(p / q) + (1 - p) * np.log((1 - p) / (1 - q))
    return float(kl.sum(-1).mean())


def models(rng):
    out = {}
    c, p = S.reviewer_tables()
    out["authors' reviewer model (one task type)"] = (np.repeat(c, 1, 0), p)
    n = 20000
    # M1: heterogeneous levels, every task informative
    lvl = rng.uniform(0.2, 0.8, n)
    p1 = np.clip(lvl[:, None] + 0.12 * np.array([1.5, 0.5, -0.5, -1.5]) + rng.normal(0, 0.12, (n, 4)), 0.01, 0.99)
    out["M1: levels 0.2-0.8, all tasks informative"] = (np.tile(C4, (n, 1)), p1)
    # M2: 60% of tasks near-deterministic (all candidates 0.97 or 0.03), 40% informative
    det = rng.random(n) < 0.6
    hi = rng.random(n) < 0.5
    p2 = p1.copy()
    p2[det] = np.where(hi[det, None], 0.97, 0.03)
    out["M2: 60% of tasks near-deterministic"] = (np.tile(C4, (n, 1)), p2)
    return out


def main():
    rng = np.random.default_rng(6)
    lines = ["# Check 6: the information lower bound", "", "## (a) Constants (KEEP: theta_1 = 1 against theta_0 = 0.75, alpha 0.05, power 0.8)", "",
             "| task model | A_home | E sigma^2 | K* exact (reviewer) | K* exact (msr.sequential) | K* second order | bound in tasks (exact) |",
             "|---|---|---|---|---|---|---|"]
    d08 = dbin(0.8, 0.05)
    designs = []
    for name, (c, p) in models(rng).items():
        A = float((c * p).sum(-1).mean())
        v = p * (1 - p)
        es2 = float((c ** 2 * v).sum(-1).mean())
        target = 0.75 * A
        k_me = my_least_favourable(p, c, target)
        k_au = S.least_favourable(p, c, target)[0]
        k_2 = (0.25 * A) ** 2 / (2 * es2)
        lines.append(f"| {name} | {A:.3f} | {es2:.4f} | {k_me:.6f} | {k_au:.6f} | {k_2:.6f} | {d08 / k_me:.0f} |")
        s_abs = (np.abs(c) * np.sqrt(v)).sum(-1)
        per_check_uniform = (0.25 * A) ** 2 / (2 * 4 * es2)
        per_check_within = (0.25 * A) ** 2 / (2 * 4 * float((s_abs ** 2).mean()) / 4)
        per_check_full = (0.25 * A) ** 2 / (2 * float(s_abs.mean()) ** 2)
        designs.append((name, per_check_uniform, per_check_within, per_check_full, d08))
    lines += ["", f"d(0.8 || 0.05) = {d08:.4f}; d(0.5 || 0.05) = {dbin(0.5, 0.05):.4f}; d(0.9 || 0.05) = {dbin(0.9, 0.05):.4f}. "
              "Wald/KCG lower bound E_1 N >= d / K*; the constants of A8 (K* = 0.0043; 191, 439, 548 tasks) reproduce.", "",
              "## (b) Smarter designs: the bound in CHECKS for the theorem's design and for designs that choose cells", "",
              "| task model | uniform (theorem) | within-task allocation | task and cell allocation | factor |", "|---|---|---|---|---|"]
    for name, u, w, f, d in designs:
        lines.append(f"| {name} | {d / u:.0f} | {d / w:.0f} | {d / f:.0f} | {u and f / u:.2f} |")
    lines += ["", "Second order. 'Factor' = how many times smaller the lower bound on checks is for a rule that may "
              "choose which (task, candidate) cells to check (importance-weighted so that it still tests the "
              "population theta). The theorem's 'any keep-or-drop decision' holds only for rules that check every "
              "candidate of uniformly drawn tasks.", "",
              "## (c) The bound in checks (power 0.8, alpha 0.05, second order, model M2's within-task variance scaled to the signal)", "",
              "| A_home | theta_0 = 0.75 | 0.5 | 0.25 | 0 |", "|---|---|---|---|---|"]
    c, p = models(rng)["M2: 60% of tasks near-deterministic"]
    es2 = float((c ** 2 * p * (1 - p)).sum(-1).mean())
    for A in (0.05, 0.10, 0.20, 0.40):
        row = []
        for t0 in (0.75, 0.5, 0.25, 0.0):
            K = ((1 - t0) * A) ** 2 / (2 * es2)
            row.append(f"{4 * d08 / K:,.0f}")
        lines.append(f"| {A:.2f} | " + " | ".join(row) + " |")
    lines += ["", "With the registered margin (0.75) and a weak signal no design is cheap; with a margin of 0 (does any "
              "signal survive?) or a strong signal, tens of checks suffice. 'No valid rule can decide with a few "
              "checks' is a statement about the margin, the signal, the error levels and the design, all four."]
    txt = "\n".join(lines)
    open(os.path.join(HERE, "c6_bound_output.md"), "w").write(txt + "\n")
    print(txt)


if __name__ == "__main__":
    main()
