"""Check 2, follow-up: items shared across orders in an item-dominated world, the authors' per-order item
codes against true item identities (same replications), and more replications of world C at theta = 1.
Run: .venv/bin/python paper/reviews/round2/r6_checks/c2b_followup.py"""
import math, os, sys, time
from multiprocessing import Pool
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import c2_twoway_size as C2
C2.CONFIGS.clear()
C2.CONFIGS.update({
    "DF shared across orders + item-dominated (bank 40, eta 1, share 1.0)": (C2.G4, dict(bank=40, b=0.12, eta=1.0, h_sd=0.08, g=0.06, share_frac=1.0)),
    "C' few popular items, more replications": (C2.G4, dict(bank=60, zipf=1.2)),
})
def main():
    jobs = [(n, k, 1000 + s) for n in C2.CONFIGS for k in (1.0, 0.75) for s in range(250)]
    t0 = time.time()
    with Pool(2) as p:
        res = p.map(C2.one, jobs, chunksize=10)
    agg = {}
    for name, kappa, out in res:
        for coding, (z, zt) in out.items():
            agg.setdefault((name, kappa, coding), []).append(z)
    lines = ["# Check 2 follow-up", "", f"Wall time {time.time() - t0:.0f} s, 2 processes, 250 replications per row (new seeds).", "",
             "| world | theta | item codes | mean z | SD z (95% CI) | one-sided reject 0.05 raw / x1.03 |", "|---|---|---|---|---|---|"]
    z05 = 1.6448536269514722
    for (name, kappa, coding), z in agg.items():
        z = np.array(z); n = len(z); sd = z.std(ddof=1)
        lo = sd * math.sqrt(n - 1) / math.sqrt(n - 1 + 1.96 * math.sqrt(2 * (n - 1)))
        hi = sd * math.sqrt(n - 1) / math.sqrt(n - 1 - 1.96 * math.sqrt(2 * (n - 1)))
        zr = (-1.0 if kappa == 1.0 else 1.0) * z
        lines.append(f"| {name} | {kappa} | {coding} | {z.mean():+.3f} | {sd:.3f} ({lo:.3f}-{hi:.3f}) | {np.mean(zr > z05):.3f} / {np.mean(zr > z05 * 1.03):.3f} |")
    txt = "\n".join(lines)
    open(os.path.join(HERE, "c2b_followup_output.md"), "w").write(txt + "\n")
    print(txt)
if __name__ == "__main__":
    main()
