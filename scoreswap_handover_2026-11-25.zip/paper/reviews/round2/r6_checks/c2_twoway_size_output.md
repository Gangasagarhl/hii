# Check 2: size of the theta tests with the two-way variance (reviewer's worlds)

Wall time 540 s with 3 processes. theta_pop = kappa exactly in every world (r6_dgp.py).
z = (V_swap - kappa V_home) / SE (registered direction: drop test rejects for z < -crit at kappa = 1; 
no-material-drop test rejects for z > crit at kappa = 0.75). 'x1.03' = with the registered factor.

| world | theta | item codes | reps | mean z | SD z (95% CI) | one-sided reject 0.05 raw / x1.03 | two-sided/2 raw / x1.03 | reject 0.05/15 raw / x1.03 | task-only SD z |
|---|---|---|---|---|---|---|---|---|---|
| A base (bank 250) | 1.0 | per_order | 300 | -0.001 | 0.939 (0.872-1.024) | 0.033 / 0.033 | 0.038 / 0.038 | 0.0033 / 0.0033 | 0.959 |
| A base (bank 250) | 0.75 | per_order | 300 | +0.053 | 0.951 (0.883-1.038) | 0.043 / 0.040 | 0.037 / 0.032 | 0.0133 / 0.0100 | 0.974 |
| B heavy item reuse (bank 20) | 1.0 | per_order | 300 | +0.066 | 0.972 (0.902-1.060) | 0.030 / 0.030 | 0.055 / 0.050 | 0.0000 / 0.0000 | 1.006 |
| B heavy item reuse (bank 20) | 0.75 | per_order | 300 | +0.002 | 1.050 (0.975-1.146) | 0.067 / 0.067 | 0.067 / 0.067 | 0.0033 / 0.0033 | 1.090 |
| C few popular items (bank 60, Zipf 1.2) | 1.0 | per_order | 300 | -0.018 | 1.103 (1.024-1.204) | 0.073 / 0.067 | 0.065 / 0.058 | 0.0033 / 0.0033 | 1.145 |
| C few popular items (bank 60, Zipf 1.2) | 0.75 | per_order | 300 | +0.071 | 1.022 (0.949-1.116) | 0.057 / 0.047 | 0.047 / 0.040 | 0.0000 / 0.0000 | 1.086 |
| D items shared across orders (share 1.0) | 1.0 | per_order | 300 | -0.005 | 1.014 (0.941-1.106) | 0.060 / 0.050 | 0.047 / 0.040 | 0.0033 / 0.0000 | 1.050 |
| D items shared across orders (share 1.0) | 1.0 | true | 300 | -0.012 | 1.027 (0.954-1.121) | 0.060 / 0.057 | 0.047 / 0.045 | 0.0067 / 0.0033 | 1.050 |
| D items shared across orders (share 1.0) | 0.75 | per_order | 300 | -0.001 | 0.985 (0.914-1.075) | 0.040 / 0.040 | 0.048 / 0.047 | 0.0000 / 0.0000 | 1.021 |
| D items shared across orders (share 1.0) | 0.75 | true | 300 | +0.008 | 0.993 (0.922-1.084) | 0.043 / 0.043 | 0.052 / 0.052 | 0.0000 / 0.0000 | 1.021 |
| D2 items shared across orders (share 1/6) | 1.0 | per_order | 300 | -0.094 | 0.952 (0.884-1.039) | 0.067 / 0.053 | 0.045 / 0.038 | 0.0033 / 0.0033 | 0.980 |
| D2 items shared across orders (share 1/6) | 1.0 | true | 300 | -0.094 | 0.951 (0.883-1.038) | 0.067 / 0.053 | 0.045 / 0.038 | 0.0033 / 0.0033 | 0.980 |
| D2 items shared across orders (share 1/6) | 0.75 | per_order | 300 | +0.006 | 1.019 (0.946-1.113) | 0.047 / 0.040 | 0.048 / 0.040 | 0.0067 / 0.0067 | 1.039 |
| D2 items shared across orders (share 1/6) | 0.75 | true | 300 | +0.006 | 1.020 (0.947-1.113) | 0.047 / 0.040 | 0.048 / 0.040 | 0.0067 / 0.0067 | 1.039 |
| E unequal task weights (one swap 15 tasks/order) | 1.0 | per_order | 300 | +0.016 | 1.000 (0.928-1.091) | 0.033 / 0.033 | 0.050 / 0.048 | 0.0000 / 0.0000 | 1.025 |
| E unequal task weights (one swap 15 tasks/order) | 0.75 | per_order | 300 | -0.058 | 1.020 (0.947-1.113) | 0.050 / 0.047 | 0.057 / 0.052 | 0.0100 / 0.0067 | 1.048 |
| F item-dominated (bank 40, eta 1) | 1.0 | per_order | 300 | +0.014 | 1.093 (1.014-1.193) | 0.067 / 0.063 | 0.060 / 0.055 | 0.0067 / 0.0033 | 1.194 |
| F item-dominated (bank 40, eta 1) | 0.75 | per_order | 300 | -0.051 | 1.085 (1.007-1.184) | 0.057 / 0.057 | 0.063 / 0.062 | 0.0067 / 0.0067 | 1.223 |
| D12 shared items, 12 swaps | 1.0 | per_order | 150 | -0.039 | 0.997 (0.900-1.134) | 0.033 / 0.033 | 0.047 / 0.047 | 0.0000 / 0.0000 | 1.022 |
| D12 shared items, 12 swaps | 1.0 | true | 150 | -0.040 | 1.001 (0.904-1.139) | 0.047 / 0.040 | 0.053 / 0.050 | 0.0067 / 0.0000 | 1.022 |
| D12 shared items, 12 swaps | 0.75 | per_order | 150 | -0.030 | 1.054 (0.952-1.199) | 0.060 / 0.060 | 0.063 / 0.060 | 0.0000 / 0.0000 | 1.082 |
| D12 shared items, 12 swaps | 0.75 | true | 150 | -0.034 | 1.056 (0.953-1.201) | 0.060 / 0.060 | 0.067 / 0.063 | 0.0000 / 0.0000 | 1.082 |

Monte-Carlo SE of a rate near 0.05: 0.013 with 300 replications, 0.018 with 150; of SD z: about 4% (300) and 6% (150).
Implied one-sided size of a normal test when z ~ N(0, s^2): Phi(-1.645 / s); s = 1.10 gives 0.068, 1.20 gives 0.085, 1.35 gives 0.111.
With the factor: Phi(-1.645 * 1.03 / s).
