"""Check 3: the 15-test Holm family, the two PC1 members and the decision words.

(a) Holm's step-down controls the familywise error for ANY dependence once every member's p-value is
    valid; the threat is the members' own size. Reviewer's z-level family: three groups; in each,
    z_drop and z_NI built from the same (V_home, V_swap) so they are strongly negatively related;
    PC2-PC4 correlated with PC1 through shared tasks (rho = 0.5 and an adversarial -0.9 / +0.9 mix).
    Least favourable truth: in each group one PC1 member at its boundary, the other PC1 member false
    (it cannot also be true), PC2-PC4 true nulls. The SE of every member is understated by a factor
    s (s = 1: valid); FWER against s, with and without the factor 1.03.
(b) The word 'material drop' rests on the point estimate (theta-hat <= 0.75), not on a test of
    theta < 0.75. Probability of the word when the true theta is above 0.75, for SEs of theta-hat
    typical of a 4-swap group and of the 48-swap group.
Run: .venv/bin/python paper/reviews/round2/r6_checks/c3_holm_family.py
"""
import os

import numpy as np
from scipy.stats import norm

HERE = os.path.dirname(os.path.abspath(__file__))


def holm_reject(p, alpha=0.05):
    m = p.shape[1]
    order = np.argsort(p, axis=1)
    ps = np.take_along_axis(p, order, axis=1)
    thr = alpha / (m - np.arange(m))
    ok = ps <= thr
    # step-down: reject while all previous passed
    cum = np.cumprod(ok, axis=1).astype(bool)
    rej = np.zeros_like(cum)
    np.put_along_axis(rej, order, cum, axis=1)
    return rej


def family_fwer(s, factor, corr_mode, R=200_000, seed=0):
    rng = np.random.default_rng(seed)
    G = 3
    # per group: e1 = noise of V_home (scaled), e2 = noise of V_swap; drop stat = home - swap, NI = swap - .75 home
    zs, true_null = [], []
    for g in range(G):
        eh = rng.standard_normal(R)
        es = 0.6 * eh + 0.8 * rng.standard_normal(R)           # home and swap share tasks and items
        d = eh - es
        nI = es - 0.75 * eh
        zd = d / d.std()
        zn = nI / nI.std()
        # PC2-PC4: correlated with the PC1 noise
        if corr_mode == "rho 0.5":
            others = [0.5 * zd + np.sqrt(0.75) * rng.standard_normal(R) for _ in range(3)]
        elif corr_mode == "adversarial":
            others = [0.9 * zd + np.sqrt(0.19) * rng.standard_normal(R), -0.9 * zd + np.sqrt(0.19) * rng.standard_normal(R),
                      rng.standard_normal(R)]
        else:
            others = [rng.standard_normal(R) for _ in range(3)]
        # which PC1 member sits at its boundary: alternate by group (drop in g0, NI in g1, drop in g2)
        if g % 2 == 0:
            # theta = 1: drop test at boundary (true null); NI test far into H1 (false null): shift +6
            zs += [zd * s, zn * s + 6.0]
            true_null += [True, False]
        else:
            zs += [zd * s + 6.0, zn * s]
            true_null += [False, True]
        zs += [o * s for o in others]
        true_null += [True, True, True]
    Z = np.column_stack(zs)
    tn = np.array(true_null)
    P = np.empty_like(Z)
    for j in range(Z.shape[1]):
        # PC1 members and PC4 one-sided; PC2, PC3 two-sided (members 2, 3 of each block of 5)
        k = j % 5
        if k in (2, 3):
            P[:, j] = 2 * norm.sf(np.abs(Z[:, j]) / factor)
        else:
            P[:, j] = norm.sf(Z[:, j] / factor)
    rej = holm_reject(P)
    return float(np.mean(rej[:, tn].any(axis=1)))


def material_drop_rate(theta, se, alpha_step=0.05 / 15, loss_self_hi=0.10, R=400_000, seed=1):
    rng = np.random.default_rng(seed)
    th = theta + se * rng.standard_normal(R)
    zdrop = (1 - th) / se            # drop test z (linear statistic, scaled by the home signal)
    drop = zdrop > norm.isf(alpha_step)
    beyond = (1 - th) > loss_self_hi
    return float(np.mean(drop & beyond & (th <= 0.75)))


def main():
    out = ["# Check 3: the primary Holm family and the decision words", "",
           "## (a) Familywise error against an understated SE (s = true SD of z / 1)", "",
           "| dependence of PC2-PC4 on PC1 | s | FWER, raw | FWER, with factor 1.03 |", "|---|---|---|---|"]
    for mode in ("independent", "rho 0.5", "adversarial"):
        for s in (1.0, 1.02, 1.05, 1.10, 1.20, 1.35):
            out.append(f"| {mode} | {s:.2f} | {family_fwer(s, 1.0, mode):.4f} | {family_fwer(s, 1.03, mode):.4f} |")
    out += ["", "200,000 replications per row (MC SE about 0.0005 near 0.05). With s = 1 the FWER is below 0.05 "
            "whatever the dependence (Holm's theorem); the authors' search over 2,000 configurations measures the "
            "same thing. The family's real exposure is s, the members' own calibration, which check 2 measures.", "",
            "## (b) Probability of the word 'material drop' when the true theta is ABOVE 0.75", "",
            "Drop test at the first Holm step (0.05/15), self-swap hurdle 1 - theta-hat > 0.10.", "",
            "| true theta | SE of theta-hat 0.05 (48-swap group) | SE 0.10 | SE 0.15 (4-swap group) |", "|---|---|---|---|"]
    for th in (0.76, 0.80, 0.85, 0.90):
        out.append(f"| {th:.2f} | {material_drop_rate(th, 0.05):.3f} | {material_drop_rate(th, 0.10):.3f} | "
                   f"{material_drop_rate(th, 0.15):.3f} |")
    out += ["", "'Material drop' (a loss of more than a quarter of the home signal) is printed when the drop test "
            "rejects and theta-hat <= 0.75; nothing tests theta < 0.75, so the word is not error-controlled. "
            "In the dry run the cross-maker group reads 'material drop' with a two-way interval 0.006-0.370, "
            "which does exclude 0.75; with a 4-swap group the word can be printed with an interval that "
            "contains 0.75."]
    txt = "\n".join(out)
    open(os.path.join(HERE, "c3_holm_family_output.md"), "w").write(txt + "\n")
    print(txt)


if __name__ == "__main__":
    main()
