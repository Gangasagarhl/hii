# Check 2 follow-up

Wall time 241 s, 2 processes, 250 replications per row (new seeds).

| world | theta | item codes | mean z | SD z (95% CI) | one-sided reject 0.05 raw / x1.03 |
|---|---|---|---|---|---|
| DF shared across orders + item-dominated (bank 40, eta 1, share 1.0) | 1.0 | per_order | +0.063 | 1.293 (1.193-1.424) | 0.096 / 0.088 |
| DF shared across orders + item-dominated (bank 40, eta 1, share 1.0) | 1.0 | true | +0.054 | 1.279 (1.179-1.408) | 0.080 / 0.076 |
| DF shared across orders + item-dominated (bank 40, eta 1, share 1.0) | 0.75 | per_order | +0.108 | 1.233 (1.137-1.358) | 0.104 / 0.088 |
| DF shared across orders + item-dominated (bank 40, eta 1, share 1.0) | 0.75 | true | +0.096 | 1.201 (1.107-1.322) | 0.088 / 0.084 |
| C' few popular items, more replications | 1.0 | per_order | +0.025 | 1.004 (0.926-1.106) | 0.036 / 0.032 |
| C' few popular items, more replications | 0.75 | per_order | -0.025 | 1.070 (0.987-1.179) | 0.044 / 0.044 |
