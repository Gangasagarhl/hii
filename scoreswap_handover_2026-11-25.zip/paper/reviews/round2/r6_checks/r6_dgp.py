"""Reviewer R6's own data-generating process (not the authors' simulator).

Linear-probability world in which the item-population theta is known EXACTLY:

    mu_s(tau, i) = 0.5 + h_tau + b * Q_i                + g * U_{tau i}
    mu_t(tau, i) = 0.5 + h'_tau + b * (kappa Q_i + eta R_i) + g * U'_{tau i}
    score x_i    = Q_i + score_sd * eps_i       (the score sees only the owner's item effect)

Q, R, eps are item draws, independent; U, U' are task-by-item draws (U' correlated with U).
Because R and U, U' are independent of the score order a = sgn(x_i - x_j),
E[a delta_t] = kappa E[a delta_s] over the ITEM POPULATION, so theta_pop = kappa exactly,
while for one finite bank theta_bank != kappa (the R part does not average out): items must be
treated as sampled. All magnitudes are bounded so no probability is clipped (the world is linear).

Reproducibility note: before 24 Nov 02:40 the per-model task levels were drawn in set-iteration order
(hash-seed dependent), so checks 1, 2 and 2b are statistically but not bit-for-bit reproducible; the
order is now sorted.

Design knobs (all of them chosen by the reviewer, none tuned to the authors' worlds):
  n_pool       tasks in the pool of one stream; each order draws n_eval evaluation tasks from it
               (tasks recur across orders, as in the paper)
  n_orders     stream orders
  bank         items per bank (small = heavy item reuse)
  share_frac   share of bank slots holding the owner's COMMON items in every order (same item contents
               (write tasks recur across orders), but the item codes passed to the variance can be
               per order (as msr.analysis.TwoWay codes them: owner|stream|order|item) or shared
  zipf         candidate choice skewed toward a few popular items (very unequal item weights)
  n_eval_small evaluation tasks of the LAST swap of a group (unequal task weights across swaps)
"""
from __future__ import annotations

import numpy as np


def make_world(rng, owners, readers_of, kappa, eta=0.5, b=0.10, g=0.10, score_sd=0.5,
               n_pool=600, n_eval=300, n_orders=3, bank=250, share_frac=0.0, zipf=0.0,
               n_eval_small=None, rho_u=0.3, n_cand=4, h_sd=0.18, n_cal=100):
    """Simulate one replication. Returns {"swaps": [...], "kappa": kappa}.

    owners: list of owner ids; readers_of: {owner: [reader ids]} (each reader of an owner is one swap).
    The evaluation tasks of an order are common to every owner (as in the paper's probe design);
    each model has its own task levels (h); a reader's levels are shared by all its swaps.
    share_frac: share of each order's bank slots filled with the owner's COMMON items (the same item
    content in every order: same Q and R), the rest fresh per order; the score noise is per order.
    Item identities are returned (ident) so the variance can be given per-order codes (the authors'
    coding) or true identities.
    n_cal: calibration tasks per order (disjoint from the evaluation tasks of that order), with the
    owner's repeats 1-2 on the same bank: the input of the authors' 'home signal' flag.
    """
    out = {"swaps": [], "kappa": kappa}
    models = sorted(set(owners) | {r for o in owners for r in readers_of[o]})   # sorted: reproducible draws
    h = {m: rng.uniform(-h_sd, h_sd, size=n_pool) for m in models}
    order_tasks, order_cal = [], []
    for _ in range(n_orders):
        perm = rng.permutation(n_pool)
        order_tasks.append(perm[:n_eval])
        order_cal.append(perm[n_eval:n_eval + n_cal])
    if zipf > 0:
        w = 1.0 / np.arange(1, bank + 1) ** zipf
        w = w / w.sum()
    else:
        w = None
    for o in owners:
        Qc = rng.uniform(-1, 1, size=bank)
        Rc = {r: rng.uniform(-1, 1, size=bank) for r in readers_of[o]}
        per_order = []
        for od in range(n_orders):
            common = rng.random(bank) < share_frac
            Q = np.where(common, Qc, rng.uniform(-1, 1, size=bank))
            R = {r: np.where(common, Rc[r], rng.uniform(-1, 1, size=bank)) for r in readers_of[o]}
            ident = np.where(common, np.arange(bank), 10 ** 6 * (od + 1) + np.arange(bank))
            x_item = Q + score_sd * rng.normal(size=bank)
            tasks = order_tasks[od]
            keys = rng.gumbel(size=(n_eval, bank)) + (np.log(w)[None, :] if w is not None else 0.0)
            cand = np.argsort(-keys, axis=1)[:, :n_cand].astype(np.int64)
            U = rng.uniform(-1, 1, size=(n_eval, n_cand))
            mu_s = 0.5 + h[o][tasks][:, None] + b * Q[cand] + g * U
            ys = (rng.random((n_eval, n_cand, 2)) < mu_s[..., None]).astype(float)
            ys34 = (rng.random((n_eval, n_cand, 2)) < mu_s[..., None]).astype(float)
            # calibration tasks of the owner (same bank)
            ct = order_cal[od]
            keys = rng.gumbel(size=(len(ct), bank)) + (np.log(w)[None, :] if w is not None else 0.0)
            ccand = np.argsort(-keys, axis=1)[:, :n_cand].astype(np.int64)
            cmu = 0.5 + h[o][ct][:, None] + b * Q[ccand] + g * rng.uniform(-1, 1, size=(len(ct), n_cand))
            cys = (rng.random((len(ct), n_cand, 2)) < cmu[..., None]).astype(float)
            per_order.append(dict(tasks=tasks, cand=cand, ident=ident[cand], x=x_item[cand], U=U, Q=Q, R=R,
                                  mu_s=mu_s, ys=ys, ys34=ys34, cal_x=x_item[ccand], cal_y=cys))
        for r in readers_of[o]:
            sw = {"owner": o, "reader": r, "orders": []}
            for od, P in enumerate(per_order):
                ne = n_eval
                if n_eval_small is not None and r == readers_of[o][-1] and o == owners[-1]:
                    ne = n_eval_small
                Up = rho_u * P["U"][:ne] + np.sqrt(1 - rho_u ** 2) * rng.uniform(-1, 1, size=(ne, n_cand))
                Rr = P["R"][r]
                mu_t = (0.5 + h[r][P["tasks"][:ne]][:, None]
                        + b * (kappa * P["Q"][P["cand"][:ne]] + eta * Rr[P["cand"][:ne]]) + g * Up)
                yt = (rng.random((ne, n_cand, 2)) < mu_t[..., None]).astype(float)
                sw["orders"].append(dict(tasks=P["tasks"][:ne], cand=P["cand"][:ne], ident=P["ident"][:ne],
                                         x=P["x"][:ne], ys=P["ys"][:ne], ys34=P["ys34"][:ne], yt=yt,
                                         mu_s=P["mu_s"][:ne], mu_t=mu_t, cal_x=P["cal_x"], cal_y=P["cal_y"]))
            out["swaps"].append(sw)
    return out


def signed_V(x, y):
    """Per task V = sum_{i<j} sgn(x_i - x_j)(y_i - y_j) and W = sum |y_i - y_j| (reviewer's own code)."""
    n = x.shape[1]
    V = np.zeros(x.shape[0])
    W = np.zeros(x.shape[0])
    for i in range(n):
        for j in range(i + 1, n):
            dx = x[:, i] - x[:, j]
            s = np.where(np.abs(dx) <= 1e-12, 0.0, np.sign(dx))
            dy = y[:, i] - y[:, j]
            V += s * dy
            W += np.abs(dy)
    return V, W


def group_inputs(world, item_coding="per_order", use_truth=False):
    """Build (v_swap, v_home, psi_swap, psi_home, task codes, item codes) exactly as
    msr.analysis.TwoWay.theta does: per (swap) component the mean over its valid tasks pooled over
    orders; psi = (v - mean) / n per row; swap rows then home rows; task code = task id (pooled over
    orders); items = codes per bank (owner|order|item) or shared over orders (owner|item)."""
    owner_index = {}
    a = b_ = 0.0
    P_s, P_h, T_s, T_h, I_s, I_h = [], [], [], [], [], []
    for sw in world["swaps"]:
        vs_all, vh_all, t_all, it_all = [], [], [], []
        for od, O in enumerate(sw["orders"]):
            if use_truth:
                vs, _ = signed_V(O["x"], O["mu_t"])
                vh, _ = signed_V(O["x"], O["mu_s"])
            else:
                vs, _ = signed_V(O["x"], O["yt"].mean(-1))
                vh, _ = signed_V(O["x"], O["ys"].mean(-1))
            vs_all.append(vs)
            vh_all.append(vh)
            t_all.append(O["tasks"])
            oi = owner_index.setdefault(sw["owner"], len(owner_index))
            if item_coding == "per_order":          # the authors' coding: owner|stream|order|item
                code = oi * 10 ** 8 + (od + 1) * 10 ** 6 + O["cand"]
            else:                                    # true item identity (shared contents share a code)
                code = oi * 10 ** 8 + O["ident"]
            it_all.append(code)
        vs = np.concatenate(vs_all)
        vh = np.concatenate(vh_all)
        n = len(vs)
        ms, mh = vs.mean(), vh.mean()
        a += ms
        b_ += mh
        P_s.append((vs - ms) / n)
        P_h.append((vh - mh) / n)
        T_s.append(np.concatenate(t_all))
        T_h.append(np.concatenate(t_all))
        I_s.append(np.vstack(it_all))
        I_h.append(np.vstack(it_all))
    ps = np.concatenate(P_s)
    ph = np.concatenate(P_h)
    psi_s = np.concatenate([ps, np.zeros(len(ph))])
    psi_h = np.concatenate([np.zeros(len(ps)), ph])
    t = np.concatenate(T_s + T_h)
    items = np.vstack(I_s + I_h)
    # remap item codes to small ints
    _, inv = np.unique(items.ravel(), return_inverse=True)
    items = inv.reshape(items.shape).astype(np.int64)
    return a, b_, psi_s, psi_h, t.astype(np.int64), items


def fast_tests(a, b, ps, ph, t, items, margin=0.75, factor=1.03, level_z=1.959963984540054):
    """The authors' theta tests computed from ONE call of their bilinear forms (msr.metrics._twoway_forms):
    every variance is c' F c for the statistic's coefficient vector c on (psi_swap, psi_home), with the
    same non-negativity rule (max of two-way, task, item) and the factor. Identical to
    msr.metrics.theta_inference for p_drop and p_ni (checked in c2 on a few draws)."""
    import math
    from msr import metrics as M
    F = M._twoway_forms(np.column_stack([ps, ph]), t, items)
    def var(c):
        c = np.asarray(c, float)
        v2, vt, vi = (float(c @ F[k] @ c) for k in ("twoway", "task", "item"))
        return max(v2, vt, vi)
    from statistics import NormalDist
    N = NormalDist()
    out = {"theta": a / b if b else float("nan")}
    vd = var([-1.0, 1.0])
    vn = var([1.0, -margin])
    for tag, f in (("", factor), ("_raw", 1.0)):
        sd = math.sqrt(vd) * f
        sn = math.sqrt(vn) * f
        out["p_drop" + tag] = 1 - N.cdf((b - a) / sd) if sd > 0 else float("nan")
        out["p_ni" + tag] = 1 - N.cdf((a - margin * b) / sn) if sn > 0 else float("nan")
    out["F"] = F
    return out
