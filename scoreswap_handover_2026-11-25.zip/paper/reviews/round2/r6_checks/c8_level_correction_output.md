# Check 8: level-corrected log score and the swap-minus-home contrast (PC3)

Reader = owner shifted by d logits (perfect transfer of item usefulness). g = mean memory effect in logits.
'spread' = how sharply the owner's scores spread compared with the true item effects (1 = calibrated in logit slope).

| d (reader - owner, logits) | g | score spread | DiD, registered target (no-memory) | DiD, oracle target (with-item mean) |
|---|---|---|---|---|
| -1.5 | 0.0 | 1.0 | +0.0068 | +0.0062 |
| -0.5 | 0.0 | 1.0 | +0.0009 | +0.0008 |
| +0.5 | 0.0 | 1.0 | +0.0009 | +0.0008 |
| +1.5 | 0.0 | 1.0 | +0.0068 | +0.0062 |
| -1.5 | 0.6 | 1.0 | +0.0018 | -0.0008 |
| -0.5 | 0.6 | 1.0 | +0.0000 | -0.0020 |
| +0.5 | 0.6 | 1.0 | +0.0012 | +0.0033 |
| +1.5 | 0.6 | 1.0 | +0.0070 | +0.0115 |
| -1.5 | 0.0 | 1.6 | -0.0023 | -0.0035 |
| -0.5 | 0.0 | 1.6 | -0.0002 | -0.0005 |
| +0.5 | 0.0 | 1.6 | -0.0002 | -0.0005 |
| +1.5 | 0.0 | 1.6 | -0.0024 | -0.0036 |
| -1.5 | 0.6 | 1.6 | +0.0018 | -0.0040 |
| -0.5 | 0.6 | 1.6 | +0.0039 | -0.0006 |
| +0.5 | 0.6 | 1.6 | -0.0049 | -0.0004 |
| +1.5 | 0.6 | 1.6 | -0.0126 | -0.0031 |

Expected log score per check (nats). The registered minimum detectable PC3 effect is 0.003-0.014 (prereg 6.3).
A nonzero DiD with perfect transfer means PC3 does not isolate an effect of the swap: it also picks up how the
benefit of shrinking depends on the reader's base rate (and, with the registered target, on the memory effect
that the no-memory target leaves in the level).
