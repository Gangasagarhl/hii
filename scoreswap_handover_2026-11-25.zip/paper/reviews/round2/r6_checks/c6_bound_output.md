# Check 6: the information lower bound

## (a) Constants (KEEP: theta_1 = 1 against theta_0 = 0.75, alpha 0.05, power 0.8)

| task model | A_home | E sigma^2 | K* exact (reviewer) | K* exact (msr.sequential) | K* second order | bound in tasks (exact) |
|---|---|---|---|---|---|---|
| authors' reviewer model (one task type) | 0.200 | 0.2836 | 0.004338 | 0.004338 | 0.004408 | 439 |
| M1: levels 0.2-0.8, all tasks informative | 0.291 | 0.2268 | 0.011376 | 0.011376 | 0.011690 | 168 |
| M2: 60% of tasks near-deterministic | 0.115 | 0.1116 | 0.003597 | 0.003597 | 0.003672 | 530 |

d(0.8 || 0.05) = 1.9064; d(0.5 || 0.05) = 0.8304; d(0.9 || 0.05) = 2.3762. Wald/KCG lower bound E_1 N >= d / K*; the constants of A8 (K* = 0.0043; 191, 439, 548 tasks) reproduce.

## (b) Smarter designs: the bound in CHECKS for the theorem's design and for designs that choose cells

| task model | uniform (theorem) | within-task allocation | task and cell allocation | factor |
|---|---|---|---|---|
| authors' reviewer model (one task type) | 1730 | 1393 | 1393 | 1.24 |
| M1: levels 0.2-0.8, all tasks informative | 652 | 506 | 497 | 1.31 |
| M2: 60% of tasks near-deterministic | 2077 | 1622 | 1330 | 1.56 |

Second order. 'Factor' = how many times smaller the lower bound on checks is for a rule that may choose which (task, candidate) cells to check (importance-weighted so that it still tests the population theta). The theorem's 'any keep-or-drop decision' holds only for rules that check every candidate of uniformly drawn tasks.

## (c) The bound in checks (power 0.8, alpha 0.05, second order, model M2's within-task variance scaled to the signal)

| A_home | theta_0 = 0.75 | 0.5 | 0.25 | 0 |
|---|---|---|---|---|
| 0.05 | 10,933 | 2,733 | 1,215 | 683 |
| 0.10 | 2,733 | 683 | 304 | 171 |
| 0.20 | 683 | 171 | 76 | 43 |
| 0.40 | 171 | 43 | 19 | 11 |

With the registered margin (0.75) and a weak signal no design is cheap; with a margin of 0 (does any signal survive?) or a strong signal, tens of checks suffice. 'No valid rule can decide with a few checks' is a statement about the margin, the signal, the error levels and the design, all four.
