"""Check 9: numbers in the dry-run PDF against runs/sim/analysis/*.csv (reviewer's own reader).

For every macro in paper/assets/numbers.tex with a 'source: file key=value ... column=col' comment,
read the CSV, select the row, and compare the printed value with the CSV value at the printed
precision. Then check, for a hand-picked sample used in the abstract and the body, that the printed
string occurs in the PDF text (pdftotext of paper/dryrun.pdf). Hand-written numbers of the
appendix (the bound's constants, the simulator truth) are recomputed from the CSVs separately.
Run: .venv/bin/python paper/reviews/round2/r6_checks/c9_numbers.py
"""
import csv
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", "..", "..", ".."))
AN = os.path.join(ROOT, "runs", "sim", "analysis")
NUM = os.path.join(ROOT, "paper", "assets", "numbers.tex")
PDF_TXT = os.path.join(HERE, "dryrun.txt")

pat = re.compile(r"\\newcommand\*\{\\Sim(\w+)\}\{(.*?)\}% source: (\S+\.csv) (.*)$")
rows_cache = {}


def rows(f):
    if f not in rows_cache:
        p = os.path.join(AN, f)
        rows_cache[f] = list(csv.DictReader(open(p))) if os.path.exists(p) else None
    return rows_cache[f]


def parse_printed(s):
    s = s.replace("{,}", "").replace("$-$", "-").replace("$", "").strip()
    try:
        return float(s), s
    except ValueError:
        return None, s


checked, mism, skipped = [], [], []
for line in open(NUM):
    m = pat.match(line.strip())
    if not m:
        continue
    name, printed, f, sel = m.groups()
    val, s = parse_printed(printed)
    R = rows(f)
    if R is None:
        skipped.append((name, "file missing"))
        continue
    if sel.startswith("max of column="):
        col = sel.split("=", 1)[1].split()[0]
        vals = [float(r[col]) for r in R if r.get(col, "") not in ("", "nan")]
        truth = max(vals) if vals else None
    else:
        kv = dict(re.findall(r"(\w+)=([^=]+?)(?=\s+\w+=|$)", sel))
        col = kv.pop("column", None)
        cand = [r for r in R if all(str(r.get(k, "")).strip() == v.strip() for k, v in kv.items())]
        if len(cand) != 1 or col is None:
            skipped.append((name, f"{len(cand)} rows match {kv}"))
            continue
        raw = cand[0].get(col, "")
        try:
            truth = float(raw)
        except ValueError:
            if val is None:
                if raw.strip() == "" or "(" in sel:
                    skipped.append((name, f"placeholder or derived text {printed!r} (CSV {raw!r})"))
                    continue
                checked.append(name)
                if raw.strip() != s.strip():
                    mism.append((name, printed, raw))
            else:
                skipped.append((name, f"non-numeric {raw!r}"))
            continue
    if val is None or truth is None:
        skipped.append((name, "printed non-numeric"))
        continue
    dec = len(s.split(".")[1]) if "." in s else 0
    checked.append(name)
    if abs(round(truth, dec) - val) > 10 ** (-dec) * 0.5001 and abs(truth - val) > 10 ** (-dec) * 0.5001:
        mism.append((name, printed, truth))

pdf = open(PDF_TXT).read() if os.path.exists(PDF_TXT) else ""
pdf_flat = re.sub(r"\s+", " ", pdf)
sample = {"TotalCalls": "57,880", "ThetaUpgrade": "0.731", "ThetaDowngrade": "0.753", "ThetaCross": "0.204",
          "DecompMaeDecompAllSwapsValue": "0.030", "DecompMaeNoChangeAllSwapsValue": "0.111",
          "CheckBoundKeepTasks": "262", "CheckThetaOneMedianTasks": "720", "CheckAuditSixFourFalseKeep": "0.646",
          "CheckHomeOkUndecidedInTable": "1.000", "PCTwoUpgradeEst": "0.0692", "PCThreeCrossEst": "0.0704",
          "CheckNullMaxError": "0.040", "CheckKnownTruthMaxFalseKeep": "0.005", "DecompMeanGammaSameMakerValue": "0.521"}
in_pdf = {k: (v in pdf_flat) for k, v in sample.items()}

# hand-written numbers of A8 (reviewer_model rows of sequential_bound.csv) and the simulator truth
hb = {}
for r in rows("sequential_bound.csv"):
    if r["setting"] == "reviewer_model" and r["decision"] == "keep":
        hb[r["power"]] = r
hand = [
    ("K* = 0.0043 (A8)", float(hb["0.8"]["kl_least_favourable"])),
    ("191 / 439 / 548 tasks (A8)", [float(hb[p]["bound_tasks"]) for p in ("0.5", "0.8", "0.9")]),
    ("765 / 1,758 / 2,191 checks (A8)", [4 * float(hb[p]["bound_tasks"]) for p in ("0.5", "0.8", "0.9")]),
    ("fixed z test about 700 (A8)", float(hb["0.8"]["fixed_z_tasks"])),
    ("paired fixed z test (not in paper)", float(hb["0.8"]["fixed_z_tasks_D"])),
    ("best keep rate 0.08/0.10/0.12/0.15 (A8)", [float(hb["0.8"][f"max_power_{n}_tasks"]) for n in (2, 4, 8, 16)]),
    ("false keep >= 0.74/0.72/0.68/0.63 (A8)", [float(hb["0.8"][f"min_error_at_power80_{n}_tasks"]) for n in (2, 4, 8, 16)]),
    ("paired median about twice the bound (A8)", float(hb["0.8"]["measured_paired_median"]) / float(hb["0.8"]["bound_tasks"])),
    ("per-task SD 0.53 (A8)", float(hb["0.8"]["sd_A"])),
]
dp = [r for r in rows("decomp_pairs.csv") if r["family"] == "ema_grade" and r["level"] == "all" and r["group"] != "home"]
sm = [float(r["true_gamma"]) for r in dp if r["group"] in ("upgrade", "downgrade")]
cr = [float(r["true_gamma"]) for r in dp if r["group"] == "cross"]
smh = [float(r["gamma"]) for r in dp if r["group"] in ("upgrade", "downgrade")]
crh = [float(r["gamma"]) for r in dp if r["group"] == "cross"]
hand += [("simulator truth gamma 0.69 within makers (A8)", sum(sm) / len(sm)),
         ("simulator truth gamma 0.30 across makers (A8)", sum(cr) / len(cr)),
         ("gamma-hat within makers (macro 0.521)", sum(smh) / len(smh)),
         ("gamma-hat across makers (macro 0.241)", sum(crh) / len(crh)),
         ("gamma-hat minus truth per same-maker pair", [round(a - b, 3) for a, b in zip(smh, sm)])]
pt = {r["test"]: r for r in rows("primary_tests.csv")}
spread = {g: (pt[f"PC1-drop-{g}"]["spread_sd_between"], pt[f"PC2-{g}"]["spread_sd_between"]) for g in ("upgrade", "downgrade", "cross")}

out = ["# Check 9: dry-run numbers against the CSV files", "",
       f"Macros with a machine-readable source checked: {len(checked)}; mismatches at printed precision: {len(mism)}; "
       f"skipped (selector not unique or file missing): {len(skipped)}.", ""]
for m in mism:
    out.append(f"- MISMATCH {m[0]}: printed {m[1]}, CSV {m[2]}")
out += ["", f"Skipped: {len(skipped)} (meta keys without a column selector, text placeholders such as --, not fitted, and decision words derived from a detail column)."]
out += ["", "Sample of printed strings found in the PDF text (pdftotext of dryrun.pdf):"]
out += [f"- {k} = {sample[k]}: {'found' if v else 'NOT FOUND'}" for k, v in in_pdf.items()]
out += ["", "Hand-written numbers of the appendix recomputed from the CSVs:"]
out += [f"- {a}: {b}" for a, b in hand]
out += ["", "Between-pair SD printed per group (PC1, PC2): identical across the three groups, i.e. not a per-group SD:"]
out += [f"- {g}: {v}" for g, v in spread.items()]
txt = "\n".join(out)
open(os.path.join(HERE, "c9_numbers_output.md"), "w").write(txt + "\n")
print(txt)
