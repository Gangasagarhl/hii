"""Check 5: the paired keep-or-drop test (Proposition 'Error control'), replayed at its boundary.
Object under test: msr.sequential.decide_paired (the registered mixture bet).

(a) i.i.d. tasks from a reviewer-made finite task population (heterogeneous tasks, 4 candidates, the
    owner's home result estimated afresh from 2 repeats per draw, the reader's single fresh check),
    reader set so that theta = 0.75 EXACTLY over the population: false-KEEP rate up to 3,000 tasks.
(b) Tasks drawn WITHOUT replacement from a finite pool whose mean D is exactly at the boundary
    (frozen-table replay): crossing rate of the KEEP test against draws WITH replacement from the
    same pool; adversarial pool shapes.
(c) A negative home signal: A_home < 0 and theta = 0 (<= 0.75): KEEP rate.
(d) A finite stored home table (each cell answered only twice, stored once) reused beyond its size: the
    owner's stored A_h is fixed per task, the reader's checks are fresh; the population sits exactly
    at theta = 0.75; tasks drawn with replacement from a reservoir of 300 tasks.
Run: .venv/bin/python paper/reviews/round2/r6_checks/c5_betting.py
"""
import os
import sys
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", "..", "..", ".."))
sys.path.insert(0, ROOT)

from msr import sequential as S  # noqa: E402

S._THREADS = 1          # keep the replay single-threaded (the reviewer's process budget)

C = np.array([0.75, 0.25, -0.25, -0.75])      # coefficients of A for 4 candidates in score order


def population(rng, n_tasks=2000, theta=0.75):
    """Owner chances mu_s (n, 4) in score order with a signal; an independent model mu_b; the reader
    mu_t = w mu_s + (1 - w) mu_b with w chosen so that A_swap / A_home = theta exactly."""
    lvl = rng.uniform(0.15, 0.85, n_tasks)
    spread = rng.choice([0.0, 0.1, 0.3], size=n_tasks, p=[0.4, 0.4, 0.2])   # many tasks carry no signal
    item = np.sort(rng.uniform(-1, 1, (n_tasks, 4)), axis=1)[:, ::-1] * 0.6 + rng.uniform(-1, 1, (n_tasks, 4)) * 0.4
    mu_s = np.clip(lvl[:, None] + spread[:, None] * item, 0.02, 0.98)
    mu_b = np.clip(lvl[:, None] + spread[:, None] * rng.uniform(-1, 1, (n_tasks, 4)), 0.02, 0.98)
    Ah, Ab = (mu_s @ C).mean(), (mu_b @ C).mean()
    w = (theta * Ah - Ab) / (Ah - Ab)
    mu_t = w * mu_s + (1 - w) * mu_b
    return mu_s, mu_t, (mu_t @ C).mean() / Ah, Ah


def streams_iid(rng, mu_s, mu_t, R, T, chunk=100):
    A_s = np.empty((R, T), np.float32)
    A_h = np.empty((R, T), np.float32)
    Cf = C.astype(np.float32)
    for r0 in range(0, R, chunk):
        r1 = min(R, r0 + chunk)
        idx = rng.integers(0, len(mu_s), size=(r1 - r0, T))
        ms, mt = mu_s[idx].astype(np.float32), mu_t[idx].astype(np.float32)
        ys = (rng.random(ms.shape, dtype=np.float32) < mt).astype(np.float32)
        yh = ((rng.random(ms.shape, dtype=np.float32) < ms).astype(np.float32)
              + (rng.random(ms.shape, dtype=np.float32) < ms).astype(np.float32)) / 2
        A_s[r0:r1] = ys @ Cf
        A_h[r0:r1] = yh @ Cf
    return A_s, A_h


def part_a(rng):
    out = []
    mu_s, mu_t, th, Ah = population(rng)
    R, T = 3000, 3000
    a_s, a_h = streams_iid(rng, mu_s, mu_t, R, T)
    dec, used, tk, td = S.decide_paired(a_s, a_h)
    for t in (100, 300, 1000, 3000):
        out.append(f"| {t} | {np.mean(tk <= t):.4f} |")
    return [f"Population: 2,000 tasks, A_home = {Ah:.3f}, theta = {th:.4f} exactly; 3,000 streams; MC SE 0.004.", "",
            "| tasks | share of streams whose KEEP test has fired (false keep) |", "|---|---|"] + out


def wor_vs_wr(rng, pool, R=4000):
    """KEEP-test crossing share with draws without replacement (the whole pool, random order) and with
    replacement (same length)."""
    N = len(pool)
    perm = np.argsort(rng.random((R, N)), axis=1)
    x_wor = pool[perm]
    x_wr = pool[rng.integers(0, N, size=(R, N))]
    tw = S.crossing_time(x_wor.astype(float), 0.5, +1)
    tr = S.crossing_time(x_wr.astype(float), 0.5, +1)
    return float(np.mean(tw <= N)), float(np.mean(tr <= N))


def part_b(rng):
    out = ["| pool (xi scale, mean exactly 1/2) | N | without replacement | with replacement |", "|---|---|---|---|"]
    shapes = {}
    for N in (50, 300):
        # two-point skewed: a few large values, many slightly below 1/2
        k = max(1, N // 25)
        p = np.full(N, 0.5 - (0.5 * k) / (N - k))
        p[:k] = 1.0
        shapes[f"skewed: {k} at 1, rest at {p[-1]:.3f}"] = p
        q = np.full(N, 0.5 + (0.5 * k) / (N - k))
        q[:k] = 0.0
        shapes[f"skewed: {k} at 0, rest at {q[-1]:.3f}"] = q
        u = rng.uniform(0, 1, N)
        u = np.clip(u - u.mean() + 0.5, 0, 1)
        u = u - u.mean() + 0.5
        shapes["uniform, centred"] = u
        h = np.where(np.arange(N) < N // 2, 1.0, 0.0)
        shapes["half 1, half 0"] = h
        for name, pool in shapes.items():
            a, b = wor_vs_wr(rng, pool)
            out.append(f"| {name} | {N} | {a:.4f} | {b:.4f} |")
        shapes = {}
    return out


def part_c(rng):
    n = 2000
    lvl = rng.uniform(0.2, 0.8, n)
    mu_s = np.clip(lvl[:, None] - 0.04 * np.array([1.5, 0.5, -0.5, -1.5]) + rng.normal(0, 0.05, (n, 4)), 0.02, 0.98)
    mu_t = np.clip(lvl[:, None] + rng.normal(0, 0.05, (n, 4)), 0.02, 0.98)
    Ah, As = (mu_s @ C).mean(), (mu_t @ C).mean()
    a_s, a_h = streams_iid(rng, mu_s, mu_t, 1000, 2000)
    dec, used, tk, td = S.decide_paired(a_s, a_h)
    return [f"A_home = {Ah:+.3f} (the old order is reversed for the owner), A_swap = {As:+.3f}, so theta = {As / Ah:+.2f} "
            f"<= 0.75. Share KEEP within 2,000 tasks: {np.mean(dec == S.KEEP):.3f}; share DROP: {np.mean(dec == S.DROP):.3f}. "
            "Proposition 'Error control' ('keeps with probability at most alpha whenever theta <= 0.75') needs A_home > 0."]


def part_d(rng):
    mu_s, mu_t, th, Ah = population(rng)
    out = ["| reservoir | horizon (tasks, with replacement beyond the reservoir) | false KEEP |", "|---|---|---|"]
    R = 2000
    for N in (300,):
        tk_all = []
        for rep in range(R // 200):
            # 200 reservoirs, one stream each... and 10 streams per reservoir
            for _ in range(20):
                res = rng.integers(0, len(mu_s), size=N)
                yh_store = ((rng.random((N, 4)) < mu_s[res]).astype(float) + (rng.random((N, 4)) < mu_s[res]).astype(float)) / 2
                ah_store = yh_store @ C
                T = 6000
                idx = rng.integers(0, N, size=(10, T))
                ys = (rng.random((10, T, 4)) < mu_t[res][idx]).astype(np.float32)
                a_s = (ys @ C).astype(np.float32)
                a_h = ah_store[idx].astype(np.float32)
                dec, used, tk, td = S.decide_paired(a_s, a_h)
                tk_all.append(tk)
            if len(tk_all) * 10 >= R:
                break
        tk = np.concatenate(tk_all)
        for t in (300, 1000, 3000, 6000):
            out.append(f"| {N} tasks, 2 stored home repeats per cell | {t} | {np.mean(tk <= t):.4f} |")
    return [f"Population theta = {th:.4f} exactly (A_home = {Ah:.3f}); {len(tk)} streams over 200 reservoirs."] + [""] + out


def main():
    t0 = time.time()
    rng = np.random.default_rng(2027)
    out = ["# Check 5: the paired keep-or-drop test at its boundary", "", "## (a) i.i.d. tasks, home estimated", ""]
    out += part_a(rng)
    out += ["", "## (b) Without replacement from a finite pool at the boundary (KEEP test, whole pool)", ""]
    out += part_b(rng)
    out += ["", "4,000 streams per row (MC SE about 0.0034 near 0.05).", "", "## (c) Negative home signal", ""]
    out += part_c(rng)
    out += ["", "## (d) A finite stored home table reused beyond its size", ""]
    out += part_d(rng)
    out += ["", f"Run time {time.time() - t0:.0f} s."]
    txt = "\n".join(out)
    open(os.path.join(HERE, "c5_betting_output.md"), "w").write(txt + "\n")
    print(txt)


if __name__ == "__main__":
    main()
