# Check 5: the paired keep-or-drop test at its boundary

## (a) i.i.d. tasks, home estimated

Population: 2,000 tasks, A_home = 0.059, theta = 0.7500 exactly; 3,000 streams; MC SE 0.004.

| tasks | share of streams whose KEEP test has fired (false keep) |
|---|---|
| 100 | 0.0000 |
| 300 | 0.0010 |
| 1000 | 0.0123 |
| 3000 | 0.0247 |

## (b) Without replacement from a finite pool at the boundary (KEEP test, whole pool)

| pool (xi scale, mean exactly 1/2) | N | without replacement | with replacement |
|---|---|---|---|
| skewed: 2 at 1, rest at 0.479 | 50 | 0.0000 | 0.0000 |
| skewed: 2 at 0, rest at 0.521 | 50 | 0.0000 | 0.0000 |
| uniform, centred | 50 | 0.0000 | 0.0000 |
| half 1, half 0 | 50 | 0.0000 | 0.0013 |
| skewed: 12 at 1, rest at 0.479 | 300 | 0.0000 | 0.0000 |
| skewed: 12 at 0, rest at 0.521 | 300 | 0.0000 | 0.0000 |
| uniform, centred | 300 | 0.0000 | 0.0063 |
| half 1, half 0 | 300 | 0.0027 | 0.0168 |

4,000 streams per row (MC SE about 0.0034 near 0.05).

## (c) Negative home signal

A_home = -0.100 (the old order is reversed for the owner), A_swap = -0.002, so theta = +0.02 <= 0.75. Share KEEP within 2,000 tasks: 0.999; share DROP: 0.001. Proposition 'Error control' ('keeps with probability at most alpha whenever theta <= 0.75') needs A_home > 0.

## (d) A finite stored home table reused beyond its size

Population theta = 0.7500 exactly (A_home = 0.061); 2000 streams over 200 reservoirs.

| reservoir | horizon (tasks, with replacement beyond the reservoir) | false KEEP |
|---|---|---|
| 300 tasks, 2 stored home repeats per cell | 300 | 0.0020 |
| 300 tasks, 2 stored home repeats per cell | 1000 | 0.0435 |
| 300 tasks, 2 stored home repeats per cell | 3000 | 0.1305 |
| 300 tasks, 2 stored home repeats per cell | 6000 | 0.1990 |

Run time 65 s.
