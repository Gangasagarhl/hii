"""Check 4: the transfer decomposition, its propositions and its specification test.

(i)   Proposition 'Classical form': Cw = (1 + Gamma)/2 with Gamma computed by the reviewer's own midrank
      code, and the identity C_swap - 1/2 = theta (W_home / W_swap)(C_home - 1/2), on random tables.
(ii)  Proposition 'Invariance', count discounting: brute force over random count pairs, the pairs that
      fixed_lambda reorders against keep are exactly those with lambda* in (lambda, 1).
(iii) Specification test T1-diff (Q = V_swap C_oo - C_on V_home, two-way variance via the authors' forms):
      size in a world where L = 0 in the item population (task-specific usefulness transfers at the same
      rate kappa as item usefulness), and the rejection rate when only the task-specific part transfers
      at a different rate (item usefulness transfers exactly linearly).
(iv)  The 'accounts for each pair' comparison: per swap, |C_swap - prediction| for the decomposition
      (1/2 + gamma-hat V_home / (2 W_swap)), no change, R = gamma-hat and R = rho-hat (msr.theory's
      gamma_hat and rho_hat), when the reader's noise equals the owner's and when the reader has more
      repeats (less noise).
(v)   The monotone-map numbers of Section 3.5 / A8 (|theta - gamma| < 0.035 within one logit) in owner
      worlds other than the authors' default.
Run: .venv/bin/python paper/reviews/round2/r6_checks/c4_decomposition.py
"""
import math
import os
import sys
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", "..", "..", ".."))
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)


def midrank(v):
    v = np.asarray(v, float)
    order = np.argsort(v, kind="mergesort")
    r = np.empty(len(v))
    i = 0
    sv = v[order]
    while i < len(v):
        j = i
        while j + 1 < len(v) and sv[j + 1] == sv[i]:
            j += 1
        r[order[i:j + 1]] = (i + j) / 2 + 1
        i = j + 1
    return r


def part_i():
    from msr import metrics as M
    rng = np.random.default_rng(3)
    worst_g = worst_r = 0.0
    for rep in range(200):
        E = 50
        x = np.round(rng.normal(size=(E, 4)), 1)               # rounding creates score ties
        yh = rng.integers(0, 3, size=(E, 4)) / 2.0
        ys = rng.integers(0, 3, size=(E, 4)) / 2.0
        Vh, Wh = M.signed_validity_parts(x, yh)
        Vs, Ws = M.signed_validity_parts(x, ys)
        if Wh.sum() == 0 or Ws.sum() == 0 or Vh.sum() == 0:
            continue
        cw = 0.5 + Vh.sum() / (2 * Wh.sum())
        num = den = 0.0
        for e in range(E):
            xr, yr = midrank(x[e]), midrank(yh[e])
            num += np.sum((yh[e] - yh[e].mean()) * (xr - xr.mean()))
            den += np.sum((yh[e] - yh[e].mean()) * (yr - yr.mean()))
        worst_g = max(worst_g, abs(cw - (1 + num / den) / 2))
        cs = 0.5 + Vs.sum() / (2 * Ws.sum())
        th = Vs.sum() / Vh.sum()
        worst_r = max(worst_r, abs((cs - 0.5) - th * (Wh.sum() / Ws.sum()) * (cw - 0.5)))
    return [f"- Cw = (1 + Gamma)/2 with the reviewer's midranks: largest error over 200 random tables with score and "
            f"outcome ties {worst_g:.2e}. Identity C_swap - 1/2 = theta (W_home/W_swap)(C_home - 1/2): largest error {worst_r:.2e}. "
            "Both are exact (correct)."]


def part_ii():
    rng = np.random.default_rng(4)
    bad = ties = 0
    total = 0
    for _ in range(20000):
        n1, n2 = rng.integers(0, 15, 2)
        s1, s2 = rng.integers(0, n1 + 1), rng.integers(0, n2 + 1)
        lam = rng.choice([0.1, 0.25, 0.5, 0.75, 0.9])
        keep = np.sign((1 + s1) / (2 + n1) - (1 + s2) / (2 + n2))
        disc = np.sign((1 + lam * s1) / (2 + lam * n1) - (1 + lam * s2) / (2 + lam * n2))
        m1, m2 = s1 - n1 / 2, s2 - n2 / 2
        A, B = 2 * (m1 - m2), (m1 * n2 - m2 * n1)
        lam_star = -A / B if B != 0 else np.nan
        predicted = (np.isfinite(lam_star) and lam < lam_star < 1) and keep != 0
        reordered = keep != 0 and disc != keep
        total += 1
        if predicted != reordered:
            if np.isfinite(lam_star) and abs(lam_star - lam) < 1e-9:
                ties += 1
            else:
                bad += 1
    return [f"- Count discounting: the pairs that fixed_lambda reverses against keep are exactly those with lambda* in "
            f"(lambda, 1): {bad} exceptions in {total} random pairs; in {ties} further pairs lambda* = lambda exactly and "
            "the discounted scores TIE (sign 0, which changes V and Cw). Correct, with the boundary case lambda* = lambda "
            "(a tie, not a reversal) to be added. The 1-in-1 vs 6-in-10 example (lambda* = 0.25; 0.600 vs 0.571 at 0.5) checks."]


def per_task_parts(x, ys12, ys34, yt):
    """Per task: V_swap, V_home, C_on, C_oo, W_swap, W_home (reviewer's code)."""
    import itertools
    pairs = list(itertools.combinations(range(x.shape[1]), 2))
    yh = ys12.mean(-1)
    yh2 = ys34.mean(-1)
    yr = yt.mean(-1)
    out = {k: np.zeros(x.shape[0]) for k in ("Vs", "Vh", "Con", "Coo", "Ws", "Wh")}
    for i, j in pairs:
        dx = x[:, i] - x[:, j]
        a = np.where(np.abs(dx) <= 1e-12, 0.0, np.sign(dx))
        dh, dh2, dr = yh[:, i] - yh[:, j], yh2[:, i] - yh2[:, j], yr[:, i] - yr[:, j]
        out["Vs"] += a * dr
        out["Vh"] += a * dh
        out["Con"] += dh * dr
        out["Coo"] += dh * dh2
        out["Ws"] += np.abs(dr)
        out["Wh"] += np.abs(dh)
    return out


def spec_z(world):
    """T1-diff z over the group: sum_k Q_k with the two-way variance (authors' forms, max rule, x1.03)."""
    from msr import metrics as M
    Qtot = 0.0
    psis, ts, its = [], [], []
    owner_index = {}
    for sw in world["swaps"]:
        parts = {k: [] for k in ("Vs", "Vh", "Con", "Coo")}
        T, I = [], []
        for od, O in enumerate(sw["orders"]):
            p = per_task_parts(O["x"], O["ys"], O["ys34"], O["yt"])
            for k in parts:
                parts[k].append(p[k])
            T.append(O["tasks"])
            oi = owner_index.setdefault(sw["owner"], len(owner_index))
            I.append(oi * 10 ** 8 + (od + 1) * 10 ** 6 + O["cand"])
        P = {k: np.concatenate(v) for k, v in parts.items()}
        S = {k: v.sum() for k, v in P.items()}
        Qtot += S["Vs"] * S["Coo"] - S["Con"] * S["Vh"]
        psi = (S["Coo"] * (P["Vs"] - P["Vs"].mean()) + S["Vs"] * (P["Coo"] - P["Coo"].mean())
               - S["Vh"] * (P["Con"] - P["Con"].mean()) - S["Con"] * (P["Vh"] - P["Vh"].mean()))
        psis.append(psi)
        ts.append(np.concatenate(T))
        its.append(np.vstack(I))
    psi = np.concatenate(psis)
    items = np.vstack(its)
    _, inv = np.unique(items.ravel(), return_inverse=True)      # small integer codes (msr's _codes keeps ints as given)
    F = M._twoway_forms(psi.reshape(-1, 1), np.concatenate(ts), inv.reshape(items.shape).astype(np.int64))
    v = max(float(F[k][0, 0]) for k in ("twoway", "task", "item")) * 1.03 ** 2
    return Qtot / math.sqrt(v)


def part_iii(reps=150):
    import r6_dgp as D
    owners, readers = ["o1", "o2", "o3", "o4"], {"o1": ["r1"], "o2": ["r2"], "o3": ["r3"], "o4": ["r4"]}
    lines = []
    for label, kappa, rho_u in (("L = 0 (rho_u = kappa = 0.75)", 0.75, 0.75),
                                ("item part linear (kappa 0.75), task-specific part rho_u = 0.5", 0.75, 0.5),
                                ("item part linear (kappa 0.75), task-specific part rho_u = 0.9", 0.75, 0.9)):
        zs = []
        for s in range(reps):
            rng = np.random.default_rng([41, s, int(rho_u * 100)])
            w = D.make_world(rng, owners, readers, kappa=kappa, rho_u=rho_u, bank=120, n_cal=0)
            zs.append(spec_z(w))
        zs = np.array(zs)
        lines.append(f"| {label} | {reps} | {zs.mean():+.2f} | {zs.std(ddof=1):.2f} | {np.mean(np.abs(zs) > 1.96):.3f} |")
    return ["| world (G4 group) | reps | mean z | SD z | two-sided rejection at 0.05 |", "|---|---|---|---|---|"] + lines


def part_iv(reps=60):
    import r6_dgp as D
    from msr import theory as T
    rows = []
    for sig_label, bsig in (("moderate signal (b = 0.10)", 0.10), ("strong signal (b = 0.16)", 0.16)):
        for label, n_rep_t in (("reader 2 repeats (as owner)", 2), ("reader 6 repeats (less noise)", 6)):
            errs = {"decomposition": [], "no change": [], "R = gamma-hat": [], "R = rho-hat": []}
            gam = []
            for s in range(reps):
                rng = np.random.default_rng([43, s, n_rep_t, int(bsig * 100)])
                w = D.make_world(rng, ["o1"], {"o1": ["r1"]}, kappa=0.6, rho_u=0.6, b=bsig, bank=120, n_cal=0)
                O = w["swaps"][0]["orders"]
                x = np.vstack([o["x"] for o in O])
                ys = np.vstack([o["ys"] for o in O])
                ys34 = np.vstack([o["ys34"] for o in O])
                mu_t = np.vstack([o["mu_t"] for o in O])
                yt = (rng.random(mu_t.shape + (n_rep_t,)) < mu_t[..., None]).astype(float)
                p = per_task_parts(x, ys, ys34, yt)
                S = {k: v.sum() for k, v in p.items()}
                ch = 0.5 + S["Vh"] / (2 * S["Wh"])
                cs = 0.5 + S["Vs"] / (2 * S["Ws"])
                g = T.gamma_hat(ys, yt, None, ys34)
                r = T.rho_hat(ys, yt)
                gam.append(g)
                errs["decomposition"].append(abs(cs - (0.5 + g * S["Vh"] / (2 * S["Ws"]))))
                errs["no change"].append(abs(cs - ch))
                errs["R = gamma-hat"].append(abs(cs - (0.5 + g * (ch - 0.5))))
                errs["R = rho-hat"].append(abs(cs - (0.5 + r * (ch - 0.5))) if np.isfinite(r) else np.nan)
            d = {k: float(np.nanmean(v)) for k, v in errs.items()}
            rows.append(f"| {sig_label}, {label} | {d['decomposition']:.4f} | {d['no change']:.4f} | {d['R = gamma-hat']:.4f} | "
                        f"{d['R = rho-hat']:.4f} | {np.nanmedian(gam):.2f} (IQR {np.nanpercentile(gam, 25):.2f}-{np.nanpercentile(gam, 75):.2f}); undefined {np.mean(~np.isfinite(gam)):.2f} |")
    return (["| world (single swap, 3 orders x 300 tasks, linear, kappa = rho_u = gamma = 0.6) | decomposition | no change | R = gamma-hat | R = rho-hat | gamma-hat median (IQR) |",
             "|---|---|---|---|---|---|"] + rows)


def part_v():
    rng = np.random.default_rng(9)
    expit = lambda z: 1 / (1 + np.exp(-z))
    lines = ["| owner world (sd item, sd task-item, sd score noise, task level mean, sd) | reader | theta | gamma | theta - gamma |",
             "|---|---|---|---|---|"]
    worlds = {"authors' default (0.8, 0.8, 0.4, 0.3, 1.0)": (0.8, 0.8, 0.4, 0.3, 1.0),
              "item-dominated (1.5, 0.3, 0.3, 0.3, 1.0)": (1.5, 0.3, 0.3, 0.3, 1.0),
              "hard tasks (0.8, 0.8, 0.4, -1.8, 1.0)": (0.8, 0.8, 0.4, -1.8, 1.0),
              "easy, item-dominated (1.5, 0.3, 0.3, 1.8, 0.5)": (1.5, 0.3, 0.3, 1.8, 0.5)}
    for name, (sb, se, sx, lm, ls) in worlds.items():
        n_t, n_i = 60000, 6000
        lvl = rng.normal(lm, ls, n_t)
        bi = rng.normal(0, sb, n_i)
        xi = bi + rng.normal(0, sx, n_i)
        cand = rng.integers(0, n_i, size=(n_t, 2))
        cand = cand[cand[:, 0] != cand[:, 1]]
        lv = lvl[: len(cand)]
        e = rng.normal(0, se, cand.shape)
        z = lv[:, None] + bi[cand] + e
        ms = expit(z)
        a = np.sign(xi[cand[:, 0]] - xi[cand[:, 1]])
        ds = ms[:, 0] - ms[:, 1]
        for rname, f in (("1 logit weaker", lambda z: expit(z - 1)), ("1 logit stronger", lambda z: expit(z + 1)),
                         ("0.5 logit weaker", lambda z: expit(z - 0.5))):
            mt = f(z)
            dt = mt[:, 0] - mt[:, 1]
            th = np.mean(a * dt) / np.mean(a * ds)
            ga = np.mean(ds * dt) / np.mean(ds * ds)
            lines.append(f"| {name} | {rname} | {th:.3f} | {ga:.3f} | {th - ga:+.3f} |")
    return lines


def main():
    t0 = time.time()
    out = ["# Check 4: the transfer decomposition", "", "## (i) Exact identities", ""] + part_i()
    out += ["", "## (ii) Invariance of count discounting", ""] + part_ii()
    out += ["", "## (iii) Specification test T1-diff (two-way, x1.03), reviewer's worlds", ""] + part_iii()
    out += ["", "In this design gamma = (kappa + rho_u) / 2 because item and task-by-item effects have equal variance, so "
            "with kappa = 0.75 the population gap theta - gamma is 0 (row 1), +0.125 (row 2) and -0.075 (row 3) although "
            "ITEM usefulness transfers exactly linearly in all three. The test holds its level (row 1); in rows 2-3 its "
            "mean z moves in the predicted direction and it rejects somewhat more often than at L = 0, but at 4 swaps x 900 "
            "tasks its power is low. Its mean z grows as the square root of the data, so at 48 swaps x 2 streams x 1,200 tasks row 2 "
            "would sit near z = 3 (an extrapolation). A rejection therefore says that task-specific usefulness and item "
            "usefulness transfer at different rates as often as it says anything about the items (A8 lists this; the "
            "body's 'account of the loss' does not).", "", "## (iv) 'Accounts for each pair': mean absolute error in Cw", ""]
    out += part_iv()
    out += ["", "60 replications per row. The decomposition uses the reader's own per-item results on the same tasks "
            "(gamma-hat and W_swap). With a moderate signal gamma-hat's denominator (the cross-session product C_oo) is "
            "noisy and dominates the decomposition's error (its error is the sampling noise of theta-hat - gamma-hat times "
            "V_home / 2 W_swap, so MAE measures noise, not an 'account'). Whether 'no change' wins depends on whether the "
            "reader's lower noise happens to offset the loss (rows with 6 reader repeats). With equal noise and a strong "
            "signal the decomposition ties R = gamma-hat, as it ties R = rho-hat in the dry run. The informative comparison is with the same-information baselines "
            "(R = rho-hat, R = gamma-hat), not with 'no change'.", "",
            "## (v) |theta - gamma| for a reader that is a monotone map of the owner (noise-free chances)", ""]
    out += part_v()
    out += ["", f"Run time {time.time() - t0:.0f} s."]
    txt = "\n".join(out)
    open(os.path.join(HERE, "c4_decomposition_output.md"), "w").write(txt + "\n")
    print(txt)


if __name__ == "__main__":
    main()
