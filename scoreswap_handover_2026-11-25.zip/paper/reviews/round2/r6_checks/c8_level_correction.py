"""Check 8: the level-corrected log score and the swap-minus-home contrast of PC3 (fixed_0.5 vs keep).

Exact expectations (no Monte Carlo) in a reviewer world where the reader's success chances are the
owner's shifted by a constant on the logit scale: item usefulness transfers PERFECTLY (same item
effects b_i, same order), only the level differs. The registered correction shifts each rule's
predictions by one logit constant so that their mean over the calibration cells equals the reader's
NO-MEMORY success; memory moves success by g logits on average, so that target is off by the memory
effect. We compute
   DiD = [LS*(fixed_0.5) - LS*(keep)]_swap - [LS*(fixed_0.5) - LS*(keep)]_home
with (i) the registered target (no-memory success) and (ii) an oracle target (the reader's mean
success with the item shown). With perfect transfer a contrast that isolates 'the effect of the
swap' should be 0.
Run: .venv/bin/python paper/reviews/round2/r6_checks/c8_level_correction.py
"""
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sig = lambda z: 1 / (1 + np.exp(-z))
logit = lambda p: np.log(p) - np.log1p(-p)


def shift_to(p, target):
    lo, hi = -30.0, 30.0
    L = logit(np.clip(p, 0.01, 0.99))
    for _ in range(100):
        mid = (lo + hi) / 2
        if np.clip(sig(L + mid), 0.01, 0.99).mean() < target:
            lo = mid
        else:
            hi = mid
    return np.clip(sig(L + (lo + hi) / 2), 0.01, 0.99)


def els(p, mu):
    return float(np.mean(mu * np.log(p) + (1 - mu) * np.log(1 - p)))


def did(l_s, l_t, g, spread, oracle, n=40000, seed=0):
    rng = np.random.default_rng(seed)
    b = rng.normal(0, 1.0, n)
    q = np.clip(sig(l_s + g + spread * b), 0.01, 0.99)      # the owner's score as a predicted chance
    fixed = 0.5 + 0.5 * (q - 0.5)
    out = {}
    for who, l in (("home", l_s), ("swap", l_t)):
        mu = sig(l + g + b)                                  # success with the item shown
        z = float(np.mean(sig(l + 0.0 * b)))                 # no-memory success (memory adds g on average)
        tgt = float(mu.mean()) if oracle else z
        out[who] = els(shift_to(fixed, tgt), mu) - els(shift_to(q, tgt), mu)
    return out["swap"] - out["home"], out


def main():
    lines = ["# Check 8: level-corrected log score and the swap-minus-home contrast (PC3)", "",
             "Reader = owner shifted by d logits (perfect transfer of item usefulness). g = mean memory effect in logits.",
             "'spread' = how sharply the owner's scores spread compared with the true item effects (1 = calibrated in logit slope).", "",
             "| d (reader - owner, logits) | g | score spread | DiD, registered target (no-memory) | DiD, oracle target (with-item mean) |",
             "|---|---|---|---|---|"]
    for spread in (1.0, 1.6):
        for g in (0.0, 0.6):
            for d in (-1.5, -0.5, 0.5, 1.5):
                a, _ = did(0.0, d, g, spread, oracle=False)
                b, _ = did(0.0, d, g, spread, oracle=True)
                lines.append(f"| {d:+.1f} | {g:.1f} | {spread:.1f} | {a:+.4f} | {b:+.4f} |")
    lines += ["", "Expected log score per check (nats). The registered minimum detectable PC3 effect is 0.003-0.014 (prereg 6.3).",
              "A nonzero DiD with perfect transfer means PC3 does not isolate an effect of the swap: it also picks up how the",
              "benefit of shrinking depends on the reader's base rate (and, with the registered target, on the memory effect",
              "that the no-memory target leaves in the level)."]
    txt = "\n".join(lines)
    open(os.path.join(HERE, "c8_level_correction_output.md"), "w").write(txt + "\n")
    print(txt)


if __name__ == "__main__":
    main()
