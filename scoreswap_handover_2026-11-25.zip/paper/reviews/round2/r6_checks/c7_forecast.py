"""Check 7: the forecast's single incremental-value test (F1) and its 384 relabellings, 8 models.
Object under test: msr.forecast.incremental_test with msr.forecast.relabelings (maker-preserving group)
and ArrayData; worlds written by the reviewer (not the authors' null_world_*).

Null worlds (error consistency adds nothing about theta beyond Q = [1, same maker, X_owner, X_reader, |gap|]):
 R1 heavy-tailed theta noise: one owner's home signal is weak, so its seven theta-hats are ratio-noisy
    (theta = truth + N(0, 0.1) / max(|N(0.25, 0.12)|, 0.03) for that owner); ec with model effects.
 R2 model effects in both arrays, independent; plus an owner-level effect in theta tied to the
    owner's maker position (old vs new): theta higher when the OWNER is the newer model.
Worlds where the STATISTICAL null fails but the scientific claim ('ec forecasts beyond capability') is false:
 R3 both arrays depend on the product X_owner * X_reader (not spanned by Q).
 R4 both arrays depend on min(X_owner, X_reader) (the weaker model decides both).
Power: R5 ec carries a component that is in theta (correlation about 0.3 at the pair level).
Run: .venv/bin/python paper/reviews/round2/r6_checks/c7_forecast.py
"""
import os
import sys
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", "..", "..", ".."))
sys.path.insert(0, ROOT)
from msr import forecast as Fc  # noqa: E402

MAKERS = Fc.MAKERS_8
M = 8


def world(rng, kind):
    mk = np.array(MAKERS)
    S = (mk[:, None] == mk[None, :]).astype(float)
    X = rng.uniform(0.3, 0.8, M)
    u = rng.normal(0, 0.03, M)
    A = np.triu(rng.normal(0, 0.04, (M, M)), 1)
    ec = 0.10 + 0.08 * S + u[:, None] + u[None, :] + A + A.T
    oi, ti = Fc._pair_index(M)
    th = 0.3 + 0.4 * S[oi, ti] + 0.3 * (X[ti] - X[oi]) + rng.normal(0, 0.08, M)[oi] + rng.normal(0, 0.08, M)[ti]
    if kind == "R1":
        weak = rng.integers(0, M)
        noise = rng.normal(0, 0.12, len(oi))
        heavy = rng.normal(0, 0.1, len(oi)) / np.maximum(np.abs(rng.normal(0.25, 0.12, len(oi))), 0.03)
        th = th + np.where(oi == weak, heavy, noise)
    elif kind == "R2":
        newer = (np.arange(M) % 2 == 1).astype(float)          # second model of each maker is the newer one
        th = th + 0.15 * newer[oi] + rng.normal(0, 0.12, len(oi))
    elif kind == "R3":
        prod = X[:, None] * X[None, :]
        ec = ec + 0.6 * (prod - prod.mean())
        th = th + 2.0 * (X[oi] * X[ti] - prod.mean()) + rng.normal(0, 0.12, len(oi))
    elif kind == "R4":
        mn = np.minimum(X[:, None], X[None, :])
        ec = ec + 0.6 * (mn - mn.mean())
        th = th + 2.0 * (np.minimum(X[oi], X[ti]) - mn.mean()) + rng.normal(0, 0.12, len(oi))
    elif kind == "R5":
        Z = np.triu(rng.normal(0, 1, (M, M)), 1)
        Z = Z + Z.T
        ec = ec + 0.03 * Z
        th = th + 0.05 * Z[oi, ti] + rng.normal(0, 0.12, len(oi))
    else:
        th = th + rng.normal(0, 0.12, len(oi))
    return Fc.ArrayData(M, ec, X, th, MAKERS)


def rate(kind, n_worlds, seed):
    rng = np.random.default_rng(seed)
    perms, exact = Fc.relabelings(MAKERS, "maker")
    rej = 0
    n = 0
    vals = []
    for _ in range(n_worlds):
        D = world(rng, kind)
        y = D.target["T"][0]
        res = Fc.incremental_test(D.pred["ec"][0], y, Fc.controls(D), D.oi, D.ti, M, np.isfinite(y), perms, exact)
        if np.isfinite(res["p"]):
            vals.append(res["value"])
            n += 1
            rej += (res["p"] <= 0.05) and (res["value"] > 0)
    return rej / max(n, 1), n, float(np.mean(vals))


def main():
    t0 = time.time()
    lines = ["# Check 7: the forecast's incremental-value test F1 (384 maker-preserving relabellings, 8 models)", "",
             "| world | what it is | worlds | rejection rate at one-sided 0.05 | mean partial correlation |", "|---|---|---|---|---|"]
    desc = {"R0": "null: maker structure in both, independent noise",
            "R1": "null: one owner's theta-hats ratio-noisy (heavy tails)",
            "R2": "null: theta higher when the owner is the newer model of its maker",
            "R3": "both arrays depend on X_owner * X_reader (outside Q)",
            "R4": "both arrays depend on min(X_owner, X_reader) (outside Q)",
            "R5": "power: ec shares a pair-level component with theta"}
    for kind in ("R0", "R1", "R2", "R3", "R4", "R5"):
        r, n, mv = rate(kind, 1000, 70 + int(kind[1]))
        lines.append(f"| {kind} | {desc[kind]} | {n} | {r:.3f} | {mv:+.3f} |")
    r, n, mv = rate("R2", 3000, 9002)
    lines.append(f"| R2 (repeat, new seed) | {desc['R2']} | {n} | {r:.3f} | {mv:+.3f} |")
    lines += ["", "MC SE near 0.05 with 1,000 worlds: 0.007; with 3,000: 0.004. Findings: the level holds in R0, R1 (heavy-tailed ratio noise makes it conservative, 0.035) and in the "
              "two capability non-linearities R3 and R4 (the linear controls absorbed them here; the authors' own 'square' "
              "world gives 0.095). In R2, a null world in which theta depends on whether the OWNER is the newer model of its "
              "maker (not spanned by Q, which has capability but not position), the rejection rate is 0.077 (1,000 worlds) "
              "and 0.059 (3,000 worlds), pooled 0.064 (SE 0.004): double semi-partialling is approximate, not exact, and "
              "upgrade/downgrade asymmetry is exactly the structure this study expects. R5 shows the power at a mean "
              "partial correlation of 0.14: 0.26.",
              f"Run time {time.time() - t0:.0f} s."]
    txt = "\n".join(lines)
    open(os.path.join(HERE, "c7_forecast_output.md"), "w").write(txt + "\n")
    print(txt)


if __name__ == "__main__":
    main()
