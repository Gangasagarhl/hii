"""Check 2: size of the two theta tests (PC1-drop at theta = 1, PC1-NI at theta = 0.75) with the
authors' two-way variance and its fixed factor 1.03, in the reviewer's own worlds (r6_dgp.py).

Object under test: msr.metrics._twoway_forms (the bilinear forms behind cluster_variance and
theta_inference), with the authors' non-negativity rule max(two-way, task, item) and the factor 1.03
(r6_dgp.fast_tests reproduces msr.metrics.theta_inference's p_drop and p_ni to 1e-15).

Each replication: one group of swaps, the true item-population theta = kappa EXACTLY.
Reported per configuration: mean and SD of the null z (SD > 1 means the SE is too small),
one-sided rejection rates at 0.05 and 0.05/15 with and without the factor, and the two-sided rate / 2
(a less noisy estimate of the one-sided size when z is symmetric).
Run: .venv/bin/python paper/reviews/round2/r6_checks/c2_twoway_size.py
"""
import math
import os
import sys
import time
from multiprocessing import Pool

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", "..", "..", ".."))
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

G4 = (["o1", "o2", "o3", "o4"], {"o1": ["r1"], "o2": ["r2"], "o3": ["r3"], "o4": ["r4"]})
G12 = (["o1", "o2", "o3", "o4"], {o: ["r1", "r2", "r3"] for o in ["o1", "o2", "o3", "o4"]})

CONFIGS = {
    "A base (bank 250)": (G4, dict()),
    "B heavy item reuse (bank 20)": (G4, dict(bank=20)),
    "C few popular items (bank 60, Zipf 1.2)": (G4, dict(bank=60, zipf=1.2)),
    "D items shared across orders (share 1.0)": (G4, dict(share_frac=1.0, bank=60)),
    "D2 items shared across orders (share 1/6)": (G4, dict(share_frac=1 / 6, bank=250)),
    "E unequal task weights (one swap 15 tasks/order)": (G4, dict(n_eval_small=15)),
    "F item-dominated (bank 40, eta 1)": (G4, dict(bank=40, b=0.12, eta=1.0, h_sd=0.08, g=0.06)),
    "D12 shared items, 12 swaps": (G12, dict(share_frac=1.0, bank=60)),
}
REPS = {"G4": 300, "G12": 150}


def one(args):
    name, kappa, seed = args
    import r6_dgp as D
    (owners, readers), kw = CONFIGS[name]
    rng = np.random.default_rng([2026, seed, int(kappa * 100), sum(map(ord, name))])
    w = D.make_world(rng, owners, readers, kappa=kappa, **kw)
    out = {}
    for coding in ("per_order", "true") if kw.get("share_frac", 0) > 0 else ("per_order",):
        a, b, ps, ph, t, it = D.group_inputs(w, item_coding=coding)
        F = D.fast_tests(a, b, ps, ph, t, it)["F"]
        c = np.array([1.0, -kappa])                 # V_swap - kappa V_home: mean exactly 0 in this world
        v = max(float(c @ F[k] @ c) for k in ("twoway", "task", "item"))
        vt = float(c @ F["task"] @ c)
        z = (a - kappa * b) / math.sqrt(v)          # raw z (no factor)
        zt = (a - kappa * b) / math.sqrt(vt)        # task-only z
        out[coding] = (z, zt)
    return name, kappa, out


def main():
    from statistics import NormalDist
    N = NormalDist()
    jobs = []
    for name, ((owners, readers), kw) in CONFIGS.items():
        reps = REPS["G12"] if len(readers["o1"]) > 1 else REPS["G4"]
        for kappa in (1.0, 0.75):
            jobs += [(name, kappa, s) for s in range(reps)]
    t0 = time.time()
    with Pool(3) as p:
        res = p.map(one, jobs, chunksize=10)
    el = time.time() - t0
    agg = {}
    for name, kappa, out in res:
        for coding, (z, zt) in out.items():
            agg.setdefault((name, kappa, coding), []).append((z, zt))
    z05, z15 = N.inv_cdf(0.95), N.inv_cdf(1 - 0.05 / 15)
    lines = ["# Check 2: size of the theta tests with the two-way variance (reviewer's worlds)", "",
             f"Wall time {el:.0f} s with 3 processes. theta_pop = kappa exactly in every world (r6_dgp.py).",
             "z = (V_swap - kappa V_home) / SE (registered direction: drop test rejects for z < -crit at kappa = 1; ",
             "no-material-drop test rejects for z > crit at kappa = 0.75). 'x1.03' = with the registered factor.", "",
             "| world | theta | item codes | reps | mean z | SD z (95% CI) | one-sided reject 0.05 raw / x1.03 | two-sided/2 raw / x1.03 | reject 0.05/15 raw / x1.03 | task-only SD z |",
             "|---|---|---|---|---|---|---|---|---|---|"]
    for (name, kappa, coding), zz in agg.items():
        z = np.array([a for a, _ in zz])
        zt = np.array([b for _, b in zz])
        n = len(z)
        sd = z.std(ddof=1)
        lo, hi = sd * math.sqrt((n - 1) / 1.0) / math.sqrt(n - 1 + 1.96 * math.sqrt(2 * (n - 1))), sd * math.sqrt(n - 1) / math.sqrt(n - 1 - 1.96 * math.sqrt(2 * (n - 1)))
        sgn = -1.0 if kappa == 1.0 else 1.0           # registered direction
        zr = sgn * z
        r_raw = np.mean(zr > z05)
        r_fac = np.mean(zr > z05 * 1.03)
        t_raw = np.mean(np.abs(z) > z05) / 2
        t_fac = np.mean(np.abs(z) > z05 * 1.03) / 2
        h_raw = np.mean(zr > z15)
        h_fac = np.mean(zr > z15 * 1.03)
        lines.append(f"| {name} | {kappa} | {coding} | {n} | {z.mean():+.3f} | {sd:.3f} ({lo:.3f}-{hi:.3f}) | "
                     f"{r_raw:.3f} / {r_fac:.3f} | {t_raw:.3f} / {t_fac:.3f} | {h_raw:.4f} / {h_fac:.4f} | {zt.std(ddof=1):.3f} |")
    lines += ["", "Monte-Carlo SE of a rate near 0.05: 0.013 with 300 replications, 0.018 with 150; of SD z: about 4% (300) and 6% (150).",
              "Implied one-sided size of a normal test when z ~ N(0, s^2): Phi(-1.645 / s); s = 1.10 gives 0.068, 1.20 gives 0.085, 1.35 gives 0.111.",
              "With the factor: Phi(-1.645 * 1.03 / s)."]
    txt = "\n".join(lines)
    open(os.path.join(HERE, "c2_twoway_size_output.md"), "w").write(txt + "\n")
    print(txt)


if __name__ == "__main__":
    main()
