# Check 9: dry-run numbers against the CSV files

Macros with a machine-readable source checked: 1158; mismatches at printed precision: 0; skipped (selector not unique or file missing): 100.


Skipped: 100 (meta keys without a column selector, text placeholders such as --, not fitted, and decision words derived from a detail column).

Sample of printed strings found in the PDF text (pdftotext of dryrun.pdf):
- TotalCalls = 57,880: found
- ThetaUpgrade = 0.731: found
- ThetaDowngrade = 0.753: found
- ThetaCross = 0.204: found
- DecompMaeDecompAllSwapsValue = 0.030: found
- DecompMaeNoChangeAllSwapsValue = 0.111: found
- CheckBoundKeepTasks = 262: found
- CheckThetaOneMedianTasks = 720: found
- CheckAuditSixFourFalseKeep = 0.646: found
- CheckHomeOkUndecidedInTable = 1.000: found
- PCTwoUpgradeEst = 0.0692: found
- PCThreeCrossEst = 0.0704: found
- CheckNullMaxError = 0.040: found
- CheckKnownTruthMaxFalseKeep = 0.005: found
- DecompMeanGammaSameMakerValue = 0.521: found

Hand-written numbers of the appendix recomputed from the CSVs:
- K* = 0.0043 (A8): 0.00433824
- 191 / 439 / 548 tasks (A8): [191.406, 439.45, 547.735]
- 765 / 1,758 / 2,191 checks (A8): [765.624, 1757.8, 2190.94]
- fixed z test about 700 (A8): 701.349
- paired fixed z test (not in paper): 898.604
- best keep rate 0.08/0.10/0.12/0.15 (A8): [0.0811714, 0.0954241, 0.116803, 0.149306]
- false keep >= 0.74/0.72/0.68/0.63 (A8): [0.744027, 0.719099, 0.682392, 0.628177]
- paired median about twice the bound (A8): 2.038912276709523
- per-task SD 0.53 (A8): 0.532541
- simulator truth gamma 0.69 within makers (A8): 0.6942695
- simulator truth gamma 0.30 across makers (A8): 0.302482
- gamma-hat within makers (macro 0.521): 0.5214402499999999
- gamma-hat across makers (macro 0.241): 0.2412149875
- gamma-hat minus truth per same-maker pair: [-0.096, -0.338, -0.016, -0.242]

Between-pair SD printed per group (PC1, PC2): identical across the three groups, i.e. not a per-group SD:
- upgrade: ('0.236264', '0.048112')
- downgrade: ('0.236264', '0.048112')
- cross: ('0.236264', '0.048112')
