# Check 1: theta, the weighted concordance and the Fieller set

## (a) Definitional edge cases

1. Negative home signal (mean V_home -0.242, mean V_swap +0.076): theta-hat = -0.313, Fieller set bounded [-0.717, 0.024], p_drop = 1.000, p_NI = 0.0000; msr.analysis.theta_category gives 'no material drop'. The registered NI test (V_swap - 0.75 V_home > 0) rejects although theta-hat is negative: 'theta > 0.75' and 'V_swap - 0.75 V_home > 0' are the same hypothesis only when V_home > 0, and neither test takes a gate.

2. Two tasks, one with 4 and one with 3 candidates: theta from sums of V = 0.000, from means of A = V/M (M = 4 and 2) = -0.250. Section 3.4 states theta = A_swap/A_home; that holds only when every task has the same number of candidates (true under rule 1.6 with 4 candidates, but it should be stated).

## (b) Population quantity

- 8,000 tasks, 2,000-item bank, kappa = 0.75: theta from true chances 0.7311; theta-hat from two-repeat outcomes 0.6914. Cw at home 0.5769, Cw from true chances 0.7743 (Cw's population value moves with the number of repeats through W; theta's does not).
- One 60-item bank, 20,000 tasks, true chances (no outcome noise): theta_bank over 40 banks has mean 0.732, SD 0.082, range 0.504 to 0.932 (kappa = 0.75). The finite bank alone moves theta; an interval that treats items as fixed targets theta_bank, one that samples items targets kappa. The paper states both conditionings (A8 'Setting': everything conditional on the bank; A9: items drawn from their population).

## (c) Coverage of kappa = 0.75 (the item-population theta) as the home signal weakens

G4 group (4 swaps, distinct owners), 3 orders x 300 evaluation tasks, 120-item banks, 250 replications per row; wall time 221 s. Unbounded sets count as covering.

| home signal | median z of V_home (group) | Fieller x1.03 (registered) | unbounded | Fieller, no factor | delta-method Wald x1.03 | task-only Fieller x1.03 | registered, among draws with z_cal >= 2 (share flagged ok) |
|---|---|---|---|---|---|---|---|
| strong (b=0.10) | 11.32 | 0.976 | 0.000 | 0.964 | 0.972 | 0.968 | 0.976 (1.00) |
| moderate (b=0.05) | 5.80 | 0.984 | 0.000 | 0.984 | 0.976 | 0.984 | 0.983 (0.92) |
| weak (b=0.03) | 3.43 | 0.940 | 0.072 | 0.940 | 0.960 | 0.940 | 0.938 (0.51) |
| very weak (b=0.015) | 1.83 | 0.976 | 0.592 | 0.976 | 0.976 | 0.976 | 1.000 (0.16) |

MC SE of a coverage near 0.95 with 250 replications: 0.014.
