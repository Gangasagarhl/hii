"""Check 1: is theta well posed, is the population quantity what the text says, and does the
Fieller set cover when the denominator is weak? Reviewer's own world (r6_dgp.py), the authors'
functions as the object under test (msr.metrics.signed_validity_parts, theta_inference via the
same bilinear forms, fieller_interval, calibration_z; msr.analysis.theta_category).

Parts
 (a) definitional edge cases, deterministic: a negative home signal makes the registered tests and
     the decision words disagree with theta-hat; the A-statistic normalisation vs V when a task has
     fewer candidates; Cw's dependence on repeats.
 (b) population quantity: theta-hat on a very large sample against kappa (the item-population theta);
     a single finite bank against kappa (why items must be sampled).
 (c) coverage of the registered two-way Fieller set (union of task, item and two-way forms, x1.03),
     of the same without the factor, of the delta-method Wald interval and of the task-only Fieller
     set, at kappa = 0.75, as the home signal weakens; share unbounded; coverage among draws whose
     owners pass the calibration-task flag (z_cal >= 2), which shares the bank's items.
Run: .venv/bin/python paper/reviews/round2/r6_checks/c1_theta_fieller.py
"""
import math
import os
import sys
import time
from multiprocessing import Pool
from types import SimpleNamespace

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", "..", "..", ".."))
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

G4 = (["o1", "o2", "o3", "o4"], {"o1": ["r1"], "o2": ["r2"], "o3": ["r3"], "o4": ["r4"]})
SIGNALS = {"strong (b=0.10)": 0.10, "moderate (b=0.05)": 0.05, "weak (b=0.03)": 0.03, "very weak (b=0.015)": 0.015}
REPS = 250


def part_a():
    from msr import metrics as M
    from msr.analysis import theta_category
    lines = ["## (a) Definitional edge cases", ""]
    # 1. negative home signal: one swap, 400 tasks, per-task V drawn around a negative home mean
    rng = np.random.default_rng(5)
    n = 400
    vh = rng.normal(-0.20, 0.8, n)
    vs = rng.normal(0.05, 0.8, n)
    task = np.arange(n)
    ps = np.concatenate([(vs - vs.mean()) / n, np.zeros(n)])
    ph = np.concatenate([np.zeros(n), (vh - vh.mean()) / n])
    t = np.concatenate([task, task])
    res = M.theta_inference(vs.mean(), vh.mean(), ps, ph, t, None)
    des = SimpleNamespace(ni_fraction=0.25)
    cat = theta_category(des, res["theta"], res["p_drop"], res["p_ni"], 0.10, 0.05, 0.05)
    lines += [f"1. Negative home signal (mean V_home {vh.mean():+.3f}, mean V_swap {vs.mean():+.3f}): theta-hat = "
              f"{res['theta']:+.3f}, Fieller set {res['interval']} [{res['lo']:.3f}, {res['hi']:.3f}], p_drop = "
              f"{res['p_drop']:.3f}, p_NI = {res['p_ni']:.4f}; msr.analysis.theta_category gives '{cat}'. "
              "The registered NI test (V_swap - 0.75 V_home > 0) rejects although theta-hat is negative: "
              "'theta > 0.75' and 'V_swap - 0.75 V_home > 0' are the same hypothesis only when V_home > 0, "
              "and neither test takes a gate.", ""]
    # 2. A = V / M vs V when the number of candidates differs
    x4 = np.array([[4.0, 3.0, 2.0, 1.0]])
    y4h = np.array([[1.0, 1.0, 0.0, 0.0]])
    y4s = np.array([[1.0, 0.0, 1.0, 0.0]])
    x3 = np.array([[3.0, 2.0, 1.0, np.nan]])
    y3h = np.array([[1.0, 0.0, 0.0, 0.0]])
    y3s = np.array([[0.0, 0.0, 1.0, 0.0]])
    pres3 = np.array([[True, True, True, False]])
    V4h, _ = M.signed_validity_parts(x4, y4h)
    V4s, _ = M.signed_validity_parts(x4, y4s)
    V3h, _ = M.signed_validity_parts(x3, y3h, pres3)
    V3s, _ = M.signed_validity_parts(x3, y3s, pres3)
    th_V = (V4s.sum() + V3s.sum()) / (V4h.sum() + V3h.sum())
    th_A = (V4s.sum() / 4 + V3s.sum() / 2) / (V4h.sum() / 4 + V3h.sum() / 2)
    lines += [f"2. Two tasks, one with 4 and one with 3 candidates: theta from sums of V = {th_V:.3f}, from means of "
              f"A = V/M (M = 4 and 2) = {th_A:.3f}. Section 3.4 states theta = A_swap/A_home; that holds only when "
              "every task has the same number of candidates (true under rule 1.6 with 4 candidates, but it should be "
              "stated).", ""]
    return lines


def part_b():
    import r6_dgp as D
    lines = ["## (b) Population quantity", ""]
    rng = np.random.default_rng(11)
    big = D.make_world(rng, ["o1"], {"o1": ["r1"]}, kappa=0.75, n_pool=8000, n_eval=8000, n_orders=1,
                       bank=2000, n_cal=0)
    O = big["swaps"][0]["orders"][0]
    vs, ws = D.signed_V(O["x"], O["mu_t"])
    vh, wh = D.signed_V(O["x"], O["mu_s"])
    vs_y, ws_y = D.signed_V(O["x"], O["yt"].mean(-1))
    vh_y, wh_y = D.signed_V(O["x"], O["ys"].mean(-1))
    lines += [f"- 8,000 tasks, 2,000-item bank, kappa = 0.75: theta from true chances {vs.sum() / vh.sum():.4f}; "
              f"theta-hat from two-repeat outcomes {vs_y.sum() / vh_y.sum():.4f}. Cw at home {0.5 + vh_y.sum() / (2 * wh_y.sum()):.4f}, "
              f"Cw from true chances {0.5 + vh.sum() / (2 * wh.sum()):.4f} (Cw's population value moves with the number of "
              "repeats through W; theta's does not)."]
    th_bank = []
    for s in range(40):
        rr = np.random.default_rng(100 + s)
        w = D.make_world(rr, ["o1"], {"o1": ["r1"]}, kappa=0.75, n_pool=20000, n_eval=20000, n_orders=1, bank=60,
                         n_cal=0)
        O = w["swaps"][0]["orders"][0]
        a, _ = D.signed_V(O["x"], O["mu_t"])
        b, _ = D.signed_V(O["x"], O["mu_s"])
        th_bank.append(a.sum() / b.sum())
    th_bank = np.array(th_bank)
    lines += [f"- One 60-item bank, 20,000 tasks, true chances (no outcome noise): theta_bank over 40 banks has mean "
              f"{th_bank.mean():.3f}, SD {th_bank.std(ddof=1):.3f}, range {th_bank.min():.3f} to {th_bank.max():.3f} "
              "(kappa = 0.75). The finite bank alone moves theta; an interval that treats items as fixed "
              "targets theta_bank, one that samples items targets kappa. The paper states both conditionings "
              "(A8 'Setting': everything conditional on the bank; A9: items drawn from their population).", ""]
    return lines


def one(args):
    label, b, seed = args
    import r6_dgp as D
    from msr import metrics as M
    rng = np.random.default_rng([77, seed, int(b * 1000)])
    owners, readers = G4
    w = D.make_world(rng, owners, readers, kappa=0.75, b=b, bank=120)
    a, bb, ps, ph, t, it = D.group_inputs(w)
    F = M._twoway_forms(np.column_stack([ps, ph]), t, it)
    out = {"theta": a / bb if bb else np.nan}
    for tag, forms, fac in (("reg", ("twoway", "task", "item"), 1.03), ("nofac", ("twoway", "task", "item"), 1.0),
                            ("task", ("task",), 1.03)):
        ivs = [M.fieller_interval(a, bb, F[k] * fac ** 2) for k in forms]
        if any(iv[2] == "unbounded" for iv in ivs):
            lo, hi, st = -np.inf, np.inf, "unbounded"
        elif all(iv[2] == "bounded" for iv in ivs):
            lo, hi, st = min(iv[0] for iv in ivs), max(iv[1] for iv in ivs), "bounded"
        else:
            lo, hi, st = np.nan, np.nan, "other"
        out[tag] = (lo, hi, st)
    th = a / bb
    c = np.array([1.0, -th]) / bb
    v = max(float(c @ F[k] @ c) for k in ("twoway", "task", "item")) * 1.03 ** 2
    se = math.sqrt(v) if v > 0 else np.nan
    out["wald"] = (th - 1.96 * se, th + 1.96 * se, "bounded")
    # home z of the group (same tasks) and the calibration flag (owners' calibration tasks)
    vh_se = math.sqrt(max(float(F[k][1, 1]) for k in ("twoway", "task", "item")))
    out["z_home"] = bb / vh_se
    cal_vals = []
    for sw in w["swaps"]:
        vv = np.concatenate([D.signed_V(O["cal_x"], O["cal_y"].mean(-1))[0] for O in sw["orders"]])
        cal_vals.append(vv)
    out["z_cal"] = M.calibration_z(cal_vals, [1.0] * len(cal_vals))
    return label, out


def part_c():
    jobs = [(lab, b, s) for lab, b in SIGNALS.items() for s in range(REPS)]
    t0 = time.time()
    with Pool(1) as p:
        res = p.map(one, jobs, chunksize=10)
    el = time.time() - t0
    lines = ["## (c) Coverage of kappa = 0.75 (the item-population theta) as the home signal weakens", "",
             f"G4 group (4 swaps, distinct owners), 3 orders x 300 evaluation tasks, 120-item banks, {REPS} replications "
             f"per row; wall time {el:.0f} s. Unbounded sets count as covering.", "",
             "| home signal | median z of V_home (group) | Fieller x1.03 (registered) | unbounded | Fieller, no factor | delta-method Wald x1.03 | task-only Fieller x1.03 | registered, among draws with z_cal >= 2 (share flagged ok) |",
             "|---|---|---|---|---|---|---|---|"]
    for lab in SIGNALS:
        rs = [o for l, o in res if l == lab]
        k = 0.75

        def cov(tag, sel=None):
            rr = rs if sel is None else [o for o in rs if sel(o)]
            if not rr:
                return float("nan"), 0
            c = [(o[tag][2] == "unbounded") or (o[tag][0] <= k <= o[tag][1]) for o in rr]
            return float(np.mean(c)), len(rr)

        unb = np.mean([o["reg"][2] == "unbounded" for o in rs])
        zc_ok = lambda o: np.isfinite(o["z_cal"]) and o["z_cal"] >= 2
        cflag, nflag = cov("reg", zc_ok)
        lines.append(f"| {lab} | {np.median([o['z_home'] for o in rs]):.2f} | {cov('reg')[0]:.3f} | {unb:.3f} | "
                     f"{cov('nofac')[0]:.3f} | {cov('wald')[0]:.3f} | {cov('task')[0]:.3f} | {cflag:.3f} ({nflag / len(rs):.2f}) |")
    lines += ["", "MC SE of a coverage near 0.95 with 250 replications: 0.014."]
    return lines


def main():
    out = ["# Check 1: theta, the weighted concordance and the Fieller set", ""]
    out += part_a()
    out += part_b()
    out += part_c()
    txt = "\n".join(out)
    open(os.path.join(HERE, "c1_theta_fieller_output.md"), "w").write(txt + "\n")
    print(txt)


if __name__ == "__main__":
    main()
