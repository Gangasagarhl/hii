# Check 3: the primary Holm family and the decision words

## (a) Familywise error against an understated SE (s = true SD of z / 1)

| dependence of PC2-PC4 on PC1 | s | FWER, raw | FWER, with factor 1.03 |
|---|---|---|---|
| independent | 1.00 | 0.0494 | 0.0381 |
| independent | 1.02 | 0.0581 | 0.0453 |
| independent | 1.05 | 0.0721 | 0.0578 |
| independent | 1.10 | 0.0997 | 0.0812 |
| independent | 1.20 | 0.1721 | 0.1453 |
| independent | 1.35 | 0.3030 | 0.2667 |
| rho 0.5 | 1.00 | 0.0472 | 0.0368 |
| rho 0.5 | 1.02 | 0.0550 | 0.0434 |
| rho 0.5 | 1.05 | 0.0686 | 0.0548 |
| rho 0.5 | 1.10 | 0.0949 | 0.0772 |
| rho 0.5 | 1.20 | 0.1619 | 0.1366 |
| rho 0.5 | 1.35 | 0.2829 | 0.2492 |
| adversarial | 1.00 | 0.0402 | 0.0313 |
| adversarial | 1.02 | 0.0467 | 0.0369 |
| adversarial | 1.05 | 0.0577 | 0.0466 |
| adversarial | 1.10 | 0.0789 | 0.0647 |
| adversarial | 1.20 | 0.1348 | 0.1142 |
| adversarial | 1.35 | 0.2370 | 0.2082 |

200,000 replications per row (MC SE about 0.0005 near 0.05). With s = 1 the FWER is below 0.05 whatever the dependence (Holm's theorem); the authors' search over 2,000 configurations measures the same thing. The family's real exposure is s, the members' own calibration, which check 2 measures.

## (b) Probability of the word 'material drop' when the true theta is ABOVE 0.75

Drop test at the first Holm step (0.05/15), self-swap hurdle 1 - theta-hat > 0.10.

| true theta | SE of theta-hat 0.05 (48-swap group) | SE 0.10 | SE 0.15 (4-swap group) |
|---|---|---|---|
| 0.76 | 0.421 | 0.377 | 0.133 |
| 0.80 | 0.159 | 0.238 | 0.083 |
| 0.85 | 0.023 | 0.112 | 0.043 |
| 0.90 | 0.001 | 0.043 | 0.021 |

'Material drop' (a loss of more than a quarter of the home signal) is printed when the drop test rejects and theta-hat <= 0.75; nothing tests theta < 0.75, so the word is not error-controlled. In the dry run the cross-maker group reads 'material drop' with a two-way interval 0.006-0.370, which does exclude 0.75; with a 4-swap group the word can be printed with an interval that contains 0.75.
