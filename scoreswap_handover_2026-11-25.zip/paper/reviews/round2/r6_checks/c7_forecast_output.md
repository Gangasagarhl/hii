# Check 7: the forecast's incremental-value test F1 (384 maker-preserving relabellings, 8 models)

| world | what it is | worlds | rejection rate at one-sided 0.05 | mean partial correlation |
|---|---|---|---|---|
| R0 | null: maker structure in both, independent noise | 1000 | 0.052 | +0.005 |
| R1 | null: one owner's theta-hats ratio-noisy (heavy tails) | 1000 | 0.035 | -0.009 |
| R2 | null: theta higher when the owner is the newer model of its maker | 1000 | 0.077 | +0.005 |
| R3 | both arrays depend on X_owner * X_reader (outside Q) | 1000 | 0.050 | +0.008 |
| R4 | both arrays depend on min(X_owner, X_reader) (outside Q) | 1000 | 0.046 | +0.004 |
| R5 | power: ec shares a pair-level component with theta | 1000 | 0.258 | +0.142 |
| R2 (repeat, new seed) | null: theta higher when the owner is the newer model of its maker | 3000 | 0.059 | +0.003 |

MC SE near 0.05 with 1,000 worlds: 0.007; with 3,000: 0.004. Findings: the level holds in R0, R1 (heavy-tailed ratio noise makes it conservative, 0.035) and in the two capability non-linearities R3 and R4 (the linear controls absorbed them here; the authors' own 'square' world gives 0.095). In R2, a null world in which theta depends on whether the OWNER is the newer model of its maker (not spanned by Q, which has capability but not position), the rejection rate is 0.077 (1,000 worlds) and 0.059 (3,000 worlds), pooled 0.064 (SE 0.004): double semi-partialling is approximate, not exact, and upgrade/downgrade asymmetry is exactly the structure this study expects. R5 shows the power at a mean partial correlation of 0.14: 0.26.
Run time 38 s.
