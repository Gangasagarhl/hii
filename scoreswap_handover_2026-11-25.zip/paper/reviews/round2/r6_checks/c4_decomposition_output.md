# Check 4: the transfer decomposition

## (i) Exact identities

- Cw = (1 + Gamma)/2 with the reviewer's midranks: largest error over 200 random tables with score and outcome ties 0.00e+00. Identity C_swap - 1/2 = theta (W_home/W_swap)(C_home - 1/2): largest error 1.01e-15. Both are exact (correct).

## (ii) Invariance of count discounting

- Count discounting: the pairs that fixed_lambda reverses against keep are exactly those with lambda* in (lambda, 1): 0 exceptions in 20000 random pairs; in 62 further pairs lambda* = lambda exactly and the discounted scores TIE (sign 0, which changes V and Cw). Correct, with the boundary case lambda* = lambda (a tie, not a reversal) to be added. The 1-in-1 vs 6-in-10 example (lambda* = 0.25; 0.600 vs 0.571 at 0.5) checks.

## (iii) Specification test T1-diff (two-way, x1.03), reviewer's worlds

| world (G4 group) | reps | mean z | SD z | two-sided rejection at 0.05 |
|---|---|---|---|---|
| L = 0 (rho_u = kappa = 0.75) | 150 | +0.02 | 0.84 | 0.027 |
| item part linear (kappa 0.75), task-specific part rho_u = 0.5 | 150 | +0.55 | 1.02 | 0.080 |
| item part linear (kappa 0.75), task-specific part rho_u = 0.9 | 150 | -0.18 | 0.95 | 0.067 |

In this design gamma = (kappa + rho_u) / 2 because item and task-by-item effects have equal variance, so with kappa = 0.75 the population gap theta - gamma is 0 (row 1), +0.125 (row 2) and -0.075 (row 3) although ITEM usefulness transfers exactly linearly in all three. The test holds its level (row 1); in rows 2-3 its mean z moves in the predicted direction and it rejects somewhat more often than at L = 0, but at 4 swaps x 900 tasks its power is low. Its mean z grows as the square root of the data, so at 48 swaps x 2 streams x 1,200 tasks row 2 would sit near z = 3 (an extrapolation). A rejection therefore says that task-specific usefulness and item usefulness transfer at different rates as often as it says anything about the items (A8 lists this; the body's 'account of the loss' does not).

## (iv) 'Accounts for each pair': mean absolute error in Cw

| world (single swap, 3 orders x 300 tasks, linear, kappa = rho_u = gamma = 0.6) | decomposition | no change | R = gamma-hat | R = rho-hat | gamma-hat median (IQR) |
|---|---|---|---|---|---|
| moderate signal (b = 0.10), reader 2 repeats (as owner) | 0.0295 | 0.0261 | 0.0293 | 0.0289 | 0.48 (IQR 0.34-0.74); undefined 0.02 |
| moderate signal (b = 0.10), reader 6 repeats (less noise) | 0.0347 | 0.0115 | 0.0322 | 0.0293 | 0.48 (IQR 0.37-0.78); undefined 0.02 |
| strong signal (b = 0.16), reader 2 repeats (as owner) | 0.0224 | 0.0430 | 0.0224 | 0.0439 | 0.58 (IQR 0.43-0.76); undefined 0.00 |
| strong signal (b = 0.16), reader 6 repeats (less noise) | 0.0329 | 0.0136 | 0.0343 | 0.0290 | 0.64 (IQR 0.51-0.79); undefined 0.00 |

60 replications per row. The decomposition uses the reader's own per-item results on the same tasks (gamma-hat and W_swap). With a moderate signal gamma-hat's denominator (the cross-session product C_oo) is noisy and dominates the decomposition's error (its error is the sampling noise of theta-hat - gamma-hat times V_home / 2 W_swap, so MAE measures noise, not an 'account'). Whether 'no change' wins depends on whether the reader's lower noise happens to offset the loss (rows with 6 reader repeats). With equal noise and a strong signal the decomposition ties R = gamma-hat, as it ties R = rho-hat in the dry run. The informative comparison is with the same-information baselines (R = rho-hat, R = gamma-hat), not with 'no change'.

## (v) |theta - gamma| for a reader that is a monotone map of the owner (noise-free chances)

| owner world (sd item, sd task-item, sd score noise, task level mean, sd) | reader | theta | gamma | theta - gamma |
|---|---|---|---|---|
| authors' default (0.8, 0.8, 0.4, 0.3, 1.0) | 1 logit weaker | 0.963 | 0.929 | +0.034 |
| authors' default (0.8, 0.8, 0.4, 0.3, 1.0) | 1 logit stronger | 0.841 | 0.844 | -0.003 |
| authors' default (0.8, 0.8, 0.4, 0.3, 1.0) | 0.5 logit weaker | 1.008 | 0.994 | +0.014 |
| item-dominated (1.5, 0.3, 0.3, 0.3, 1.0) | 1 logit weaker | 0.969 | 0.940 | +0.029 |
| item-dominated (1.5, 0.3, 0.3, 0.3, 1.0) | 1 logit stronger | 0.862 | 0.868 | -0.005 |
| item-dominated (1.5, 0.3, 0.3, 0.3, 1.0) | 0.5 logit weaker | 1.007 | 0.995 | +0.012 |
| hard tasks (0.8, 0.8, 0.4, -1.8, 1.0) | 1 logit weaker | 0.626 | 0.674 | -0.048 |
| hard tasks (0.8, 0.8, 0.4, -1.8, 1.0) | 1 logit stronger | 1.312 | 1.175 | +0.136 |
| hard tasks (0.8, 0.8, 0.4, -1.8, 1.0) | 0.5 logit weaker | 0.810 | 0.844 | -0.034 |
| easy, item-dominated (1.5, 0.3, 0.3, 1.8, 0.5) | 1 logit weaker | 1.316 | 1.183 | +0.133 |
| easy, item-dominated (1.5, 0.3, 0.3, 1.8, 0.5) | 1 logit stronger | 0.626 | 0.684 | -0.058 |
| easy, item-dominated (1.5, 0.3, 0.3, 1.8, 0.5) | 0.5 logit weaker | 1.176 | 1.118 | +0.059 |

Run time 62 s.
