# lcb_grade: score type

Scored from the frozen tables of study `sim` with no model call (pack fingerprint `ab522cf6a6002600`).

theta is the retained ranking signal: the share of the score's ranking signal at home (with the owner's results) that is left with the reader's results after the swap (1 = all, 0 = none). Brackets: its two-way Fieller 95 % interval (Part 4.2). Cw is the weighted concordance (0.5 = chance).

## By kind of swap (ddxplus)

| kind | theta | Cw at home | Cw after the swap | theta of ema_grade | theta of beta_grade | theta of tags_self | theta of credit | theta of visits |
|---|---|---|---|---|---|---|---|---|
| same-maker upgrades | 0.75 [0.51, 1.09] | 0.686 | 0.648 | 0.73 | 0.72 | 0.73 | 0.84 | 0.81 |
| same-maker downgrades | 0.65 [0.40, 0.92] | 0.696 | 0.629 | 0.75 | 0.68 | 0.53 | 0.72 | 0.97 |
| cross-maker swaps | 0.19 [0.01, 0.35] | 0.691 | 0.538 | 0.20 | 0.18 | 0.23 | 0.33 | 0.34 |
| home cells (no swap) | 0.90 [0.72, 1.09] | 0.691 | 0.672 | 1.06 | 0.90 | 0.98 | 1.05 | 1.06 |

## Every ordered pair

| owner -> reader | kind | theta | Cw at home | Cw after |
|---|---|---|---|---|
| sim-a-old -> sim-a-old | home | 0.62 [-0.02, 1.22] | 0.679 | 0.602 |
| sim-a-old -> sim-a-new | same_maker_upgrade | 0.74 [0.38, 1.37] | 0.679 | 0.633 |
| sim-a-old -> sim-b-old | cross_maker | -0.25 [-0.97, 0.39] | 0.679 | 0.463 |
| sim-a-old -> sim-b-new | cross_maker | -0.48 [-1.39, 0.06] | 0.679 | 0.426 |
| sim-a-new -> sim-a-old | same_maker_downgrade | 0.75 [0.38, 1.34] | 0.693 | 0.642 |
| sim-a-new -> sim-a-new | home | 0.98 [0.61, 1.65] | 0.693 | 0.695 |
| sim-a-new -> sim-b-old | cross_maker | 0.45 [0.13, 0.87] | 0.693 | 0.592 |
| sim-a-new -> sim-b-new | cross_maker | 0.43 [0.03, 0.83] | 0.693 | 0.587 |
| sim-b-old -> sim-a-old | cross_maker | 0.21 [-0.27, 0.58] | 0.693 | 0.544 |
| sim-b-old -> sim-a-new | cross_maker | 0.25 [-0.11, 0.71] | 0.693 | 0.551 |
| sim-b-old -> sim-b-old | home | 1.04 [0.73, 1.49] | 0.693 | 0.714 |
| sim-b-old -> sim-b-new | same_maker_upgrade | 0.76 [0.45, 1.21] | 0.693 | 0.663 |
| sim-b-new -> sim-a-old | cross_maker | 0.48 [0.12, 0.83] | 0.699 | 0.601 |
| sim-b-new -> sim-a-new | cross_maker | 0.17 [-0.25, 0.60] | 0.699 | 0.538 |
| sim-b-new -> sim-b-old | same_maker_downgrade | 0.55 [0.19, 0.91] | 0.699 | 0.617 |
| sim-b-new -> sim-b-new | home | 0.88 [0.56, 1.27] | 0.699 | 0.676 |

Per-stream values and the task-only bootstrap intervals are in summary.csv; differences in theta against the paper's five score types (bootstrap) are in compare.csv.
