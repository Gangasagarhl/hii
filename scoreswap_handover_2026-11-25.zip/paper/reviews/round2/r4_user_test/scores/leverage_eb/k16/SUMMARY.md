# leverage_eb: swap-day rule at budget k = 16

Scored from the frozen tables of study `sim` with no model call (pack fingerprint `ab522cf6a6002600`). Each value is a mean over the evaluation tasks; 200 seeded draw(s), each task's value the mean over the draws. Brackets: 95 % intervals, two-way (tasks and items; pre-registration Part 4.1). Differences use the same tasks and the same draws.

First-shown success is the reader's success with the candidate the rule shows first (higher is better); regret is the gap to the task's best candidate (lower is better); theta is the share of the owner's home ranking signal the rule's order keeps for the reader.

## By kind of swap (ddxplus)

| kind | first-shown success | minus keep | minus wipe | minus fixed_0.5 | minus recal_16 | minus powerprior_16 | minus retest_16 | minus audit_16 | regret | log score (level-corrected) | theta | checks used |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| same-maker upgrades | 0.704 [0.648, 0.759] | 0.000 [-0.009, 0.010] | 0.070 [0.022, 0.117] | 0.007 [-0.011, 0.025] | 0.025 [0.007, 0.044] | 0.023 [-0.004, 0.050] | 0.035 [-0.007, 0.076] | 0.023 [0.007, 0.040] | 0.194 | -0.734 [-0.786, -0.683] | 0.75 [0.49, 1.10] | 16.0 |
| same-maker downgrades | 0.615 [0.557, 0.673] | 0.006 [-0.015, 0.026] | 0.062 [-0.001, 0.124] | -0.008 [-0.028, 0.013] | 0.026 [0.004, 0.049] | 0.045 [0.002, 0.088] | 0.038 [-0.010, 0.085] | 0.023 [-0.002, 0.049] | 0.231 | -0.739 [-0.785, -0.693] | 0.76 [0.52, 1.08] | 16.0 |
| cross-maker swaps | 0.599 [0.556, 0.642] | 0.017 [0.002, 0.032] | 0.032 [-0.002, 0.066] | 0.016 [-0.001, 0.032] | 0.027 [0.007, 0.046] | 0.025 [0.002, 0.049] | 0.017 [-0.011, 0.046] | 0.026 [0.008, 0.044] | 0.271 | -0.838 [-0.870, -0.805] | 0.35 [0.18, 0.53] | 16.0 |
| home cells (no swap) | 0.692 [0.645, 0.739] | 0.001 [-0.007, 0.009] | 0.094 [0.054, 0.133] | 0.004 [-0.005, 0.013] | 0.020 [0.010, 0.030] | 0.019 [-0.002, 0.039] | 0.033 [0.002, 0.064] | 0.019 [0.008, 0.030] | 0.184 | -0.710 [-0.738, -0.683] | 1.04 [0.99, 1.09] | 16.0 |

## Every ordered pair (ddxplus)

| owner -> reader | kind | first-shown success | minus keep | minus wipe | regret | theta |
|---|---|---|---|---|---|---|
| sim-a-old -> sim-a-old | home | 0.663 [0.584, 0.742] | 0.003 | 0.123 | 0.158 | 1.12 |
| sim-a-old -> sim-a-new | same_maker_upgrade | 0.747 [0.665, 0.828] | 0.001 | 0.108 | 0.160 | 0.69 |
| sim-a-old -> sim-b-old | cross_maker | 0.506 [0.432, 0.580] | 0.024 | -0.020 | 0.324 | 0.14 |
| sim-a-old -> sim-b-new | cross_maker | 0.585 [0.508, 0.662] | -0.004 | -0.053 | 0.321 | -0.05 |
| sim-a-new -> sim-a-old | same_maker_downgrade | 0.690 [0.620, 0.760] | 0.020 | 0.110 | 0.194 | 1.02 |
| sim-a-new -> sim-a-new | home | 0.757 [0.670, 0.845] | 0.003 | 0.079 | 0.158 | 1.03 |
| sim-a-new -> sim-b-old | cross_maker | 0.552 [0.459, 0.646] | 0.039 | 0.097 | 0.242 | 0.56 |
| sim-a-new -> sim-b-new | cross_maker | 0.685 [0.619, 0.751] | 0.038 | 0.060 | 0.190 | 0.68 |
| sim-b-old -> sim-a-old | cross_maker | 0.618 [0.553, 0.683] | 0.019 | 0.033 | 0.257 | 0.43 |
| sim-b-old -> sim-a-new | cross_maker | 0.685 [0.597, 0.772] | 0.028 | 0.095 | 0.208 | 0.48 |
| sim-b-old -> sim-b-old | home | 0.627 [0.548, 0.707] | -0.002 | 0.083 | 0.239 | 1.00 |
| sim-b-old -> sim-b-new | same_maker_upgrade | 0.660 [0.585, 0.736] | -0.000 | 0.031 | 0.228 | 0.80 |
| sim-b-new -> sim-a-old | cross_maker | 0.554 [0.450, 0.658] | -0.013 | 0.027 | 0.321 | 0.30 |
| sim-b-new -> sim-a-new | cross_maker | 0.606 [0.535, 0.676] | 0.007 | 0.021 | 0.305 | 0.15 |
| sim-b-new -> sim-b-old | same_maker_downgrade | 0.540 [0.464, 0.616] | -0.009 | 0.013 | 0.268 | 0.47 |
| sim-b-new -> sim-b-new | home | 0.720 [0.642, 0.798] | 0.001 | 0.090 | 0.182 | 1.00 |

Per-stream values, the Brier scores, the uncorrected log score, Cw and the task-only bootstrap intervals are in summary.csv and compare.csv; one row per cell is in cells.csv.
