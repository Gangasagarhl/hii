"""R4 user test: a new swap-day rule written from docs/BENCHMARK_GUIDE.md and the template only.

Idea: spend fresh checks on the items that appear most often among the candidates of the
evaluation tasks (high leverage: one check moves many first-shown choices), then blend the
fresh results into the old score with a prior strength that depends on the kind of swap,
which is known before the swap (strong prior within a maker, weak prior across makers).
"""
import numpy as np

KIND = "swap_day_rule"
NAME = "leverage_eb"
DESCRIPTION = "Checks the highest-leverage items first; old score worth n0 checks, n0 by kind of swap."

PRIOR_STRENGTH = {"home": 8.0, "same_maker_upgrade": 4.0, "same_maker_downgrade": 4.0}


def rule(bank, candidates, swap, checks):
    fam = "ema_grade"
    u0 = np.asarray(bank.mix_score[fam], dtype=float)
    p0 = np.asarray(bank.p[fam], dtype=float)
    p0 = np.where(np.isfinite(p0), p0, bank.no_memory_rate)
    n0 = float(swap.options.get("n0_cross", 1.0)) if swap.kind == "cross_maker" else PRIOR_STRENGTH.get(swap.kind, 4.0)

    # leverage: how often each item is a candidate of an evaluation task (candidates are public)
    lev = np.zeros(bank.n)
    ev = np.asarray(candidates.roles) == "evaluation"
    idx = np.asarray(candidates.item_index)[ev].ravel()
    np.add.at(lev, idx[idx >= 0], 1.0)

    hits = np.zeros(bank.n)
    tries = np.zeros(bank.n)
    if checks.budget > 0:
        wanted = []
        for i in np.argsort(-lev, kind="stable"):
            cells = checks.by_item.get(bank.items[i], [])
            if cells:
                wanted.append(cells[0])
            if len(wanted) >= checks.budget:
                break
        if wanted:
            for a in checks.request(cells=wanted):
                hits[a.item_index] += a.result
                tries[a.item_index] += 1

    u = (n0 * u0 + hits) / (n0 + tries)
    p = (n0 * p0 + hits) / (n0 + tries)
    return {"u": np.clip(u, 0.0, 1.0), "p": np.clip(p, 0.0, 1.0)}
