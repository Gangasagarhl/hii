"""R4 user test: a new score type written from docs/BENCHMARK_GUIDE.md and the template only.

Idea: a pessimistic score. Rank items by a 10% lower confidence bound of their graded success
rate (Wilson bound, z = 1.2816), so that an item seen twice with two wins does not outrank an
item seen twenty times with eighteen wins.

First version used scipy.stats.beta.ppf (and then scipy.special.betaincinv); both crash the
sealed checker with "AttributeError: 'ChildRunner' object has no attribute 'denied'", so this
version uses numpy only. See R4_benchmark_user.md, User test.
"""
import numpy as np

KIND = "score_type"
NAME = "lcb_grade"
DESCRIPTION = "10% Wilson lower bound of the graded success rate (pessimistic ranking)."

Z = 1.2816


def score(log):
    wins = np.zeros(len(log.items))
    shows = np.zeros(len(log.items))
    np.add.at(wins, log.item_index, log.result)
    np.add.at(shows, log.item_index, 1.0)
    n = np.maximum(shows, 1.0)
    phat = np.where(shows > 0, wins / n, 0.5)
    denom = 1.0 + Z * Z / n
    centre = phat + Z * Z / (2.0 * n)
    half = Z * np.sqrt(phat * (1.0 - phat) / n + Z * Z / (4.0 * n * n))
    lcb = (centre - half) / denom
    return np.where(shows > 0, lcb, 0.0)
