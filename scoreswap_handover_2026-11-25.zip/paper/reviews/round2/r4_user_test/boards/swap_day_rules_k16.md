# Board of swap-day rules, budget k = 16

Study `sim`. Ranked by first-shown success per kind of swap (higher is better), with regret, the level-corrected log score (when the rule returns p) and the checks used beside it. Every entry was re-run by the harness from the released tables. Brackets: two-way 95 % intervals. Per stream and per ordered pair: swap_day_rules_k16.csv.

## same-maker upgrades (ddxplus)

| rank | rule | source | first-shown success | regret | log score (lc) | checks used |
|---|---|---|---|---|---|---|
| 1 | leverage_eb | outside entry | 0.704 [0.648, 0.759] | 0.194 | -0.734 | 16.0 |
| 2 | keep | paper (ema_grade) | 0.703 [0.646, 0.761] | 0.194 | -0.735 | 0.0 |
| 3 | fixed_0.5 | paper (ema_grade) | 0.696 [0.636, 0.757] | 0.201 | -0.679 | 0.0 |
| 4 | powerprior_16 | paper (ema_grade) | 0.680 [0.622, 0.739] | 0.217 | -0.690 | 16.0 |
| 5 | audit_16 | paper (ema_grade) | 0.680 [0.625, 0.735] | 0.217 | -0.724 | 16.0 |
| 6 | recal_16 | paper (ema_grade) | 0.678 [0.622, 0.734] | 0.219 | -0.698 | 16.0 |
| 7 | retest_16 | paper (ema_grade) | 0.669 [0.606, 0.732] | 0.228 | -0.696 | 16.0 |
| 8 | wipe | paper (ema_grade) | 0.634 [0.575, 0.693] | 0.263 | -0.697 | 0.0 |

## same-maker downgrades (ddxplus)

| rank | rule | source | first-shown success | regret | log score (lc) | checks used |
|---|---|---|---|---|---|---|
| 1 | fixed_0.5 | paper (ema_grade) | 0.623 [0.562, 0.684] | 0.223 | -0.678 | 0.0 |
| 2 | leverage_eb | outside entry | 0.615 [0.557, 0.673] | 0.231 | -0.739 | 16.0 |
| 3 | keep | paper (ema_grade) | 0.609 [0.548, 0.671] | 0.237 | -0.756 | 0.0 |
| 4 | audit_16 | paper (ema_grade) | 0.592 [0.536, 0.648] | 0.254 | -0.739 | 16.0 |
| 5 | recal_16 | paper (ema_grade) | 0.589 [0.533, 0.645] | 0.257 | -0.697 | 16.0 |
| 6 | retest_16 | paper (ema_grade) | 0.577 [0.520, 0.635] | 0.269 | -0.692 | 16.0 |
| 7 | powerprior_16 | paper (ema_grade) | 0.570 [0.515, 0.626] | 0.276 | -0.691 | 16.0 |
| 8 | wipe | paper (ema_grade) | 0.554 [0.491, 0.616] | 0.292 | -0.695 | 0.0 |

## cross-maker swaps (ddxplus)

| rank | rule | source | first-shown success | regret | log score (lc) | checks used |
|---|---|---|---|---|---|---|
| 1 | leverage_eb | outside entry | 0.599 [0.556, 0.642] | 0.271 | -0.838 | 16.0 |
| 2 | fixed_0.5 | paper (ema_grade) | 0.583 [0.536, 0.630] | 0.287 | -0.715 | 0.0 |
| 3 | retest_16 | paper (ema_grade) | 0.582 [0.539, 0.624] | 0.288 | -0.699 | 16.0 |
| 4 | keep | paper (ema_grade) | 0.581 [0.534, 0.629] | 0.289 | -0.832 | 0.0 |
| 5 | powerprior_16 | paper (ema_grade) | 0.573 [0.533, 0.614] | 0.297 | -0.704 | 16.0 |
| 6 | audit_16 | paper (ema_grade) | 0.573 [0.532, 0.614] | 0.297 | -0.776 | 16.0 |
| 7 | recal_16 | paper (ema_grade) | 0.572 [0.533, 0.611] | 0.298 | -0.721 | 16.0 |
| 8 | wipe | paper (ema_grade) | 0.566 [0.526, 0.607] | 0.304 | -0.698 | 0.0 |

## home cells (no swap) (ddxplus)

| rank | rule | source | first-shown success | regret | log score (lc) | checks used |
|---|---|---|---|---|---|---|
| 1 | leverage_eb | outside entry | 0.692 [0.645, 0.739] | 0.184 | -0.710 | 16.0 |
| 2 | keep | paper (ema_grade) | 0.691 [0.643, 0.739] | 0.185 | -0.720 | 0.0 |
| 3 | fixed_0.5 | paper (ema_grade) | 0.688 [0.642, 0.733] | 0.189 | -0.672 | 0.0 |
| 4 | powerprior_16 | paper (ema_grade) | 0.673 [0.631, 0.716] | 0.203 | -0.686 | 16.0 |
| 5 | audit_16 | paper (ema_grade) | 0.673 [0.629, 0.718] | 0.203 | -0.715 | 16.0 |
| 6 | recal_16 | paper (ema_grade) | 0.672 [0.629, 0.716] | 0.204 | -0.692 | 16.0 |
| 7 | retest_16 | paper (ema_grade) | 0.659 [0.614, 0.704] | 0.217 | -0.692 | 16.0 |
| 8 | wipe | paper (ema_grade) | 0.598 [0.550, 0.646] | 0.278 | -0.699 | 0.0 |

## Every ordered pair (first-shown success)

| owner -> reader | audit_16 | fixed_0.5 | keep | leverage_eb | powerprior_16 | recal_16 | retest_16 | wipe |
|---|---|---|---|---|---|---|---|---|
| sim-a-old -> sim-a-old | 0.635 | 0.656 | 0.661 | 0.663 | 0.627 | 0.638 | 0.619 | 0.540 |
| sim-a-old -> sim-a-new | 0.707 | 0.728 | 0.746 | 0.747 | 0.704 | 0.705 | 0.686 | 0.638 |
| sim-a-old -> sim-b-old | 0.503 | 0.478 | 0.482 | 0.506 | 0.510 | 0.502 | 0.509 | 0.527 |
| sim-a-old -> sim-b-new | 0.600 | 0.589 | 0.589 | 0.585 | 0.610 | 0.606 | 0.611 | 0.638 |
| sim-a-new -> sim-a-old | 0.640 | 0.674 | 0.670 | 0.690 | 0.603 | 0.630 | 0.626 | 0.580 |
| sim-a-new -> sim-a-new | 0.740 | 0.754 | 0.754 | 0.757 | 0.771 | 0.739 | 0.734 | 0.679 |
| sim-a-new -> sim-b-old | 0.484 | 0.518 | 0.513 | 0.552 | 0.480 | 0.489 | 0.504 | 0.455 |
| sim-a-new -> sim-b-new | 0.637 | 0.647 | 0.647 | 0.685 | 0.642 | 0.620 | 0.604 | 0.625 |
| sim-b-old -> sim-a-old | 0.590 | 0.594 | 0.598 | 0.618 | 0.591 | 0.572 | 0.577 | 0.585 |
| sim-b-old -> sim-a-new | 0.630 | 0.652 | 0.656 | 0.685 | 0.621 | 0.639 | 0.609 | 0.589 |
| sim-b-old -> sim-b-old | 0.621 | 0.629 | 0.629 | 0.627 | 0.611 | 0.618 | 0.607 | 0.545 |
| sim-b-old -> sim-b-new | 0.653 | 0.665 | 0.661 | 0.660 | 0.657 | 0.651 | 0.652 | 0.629 |
| sim-b-new -> sim-a-old | 0.551 | 0.567 | 0.567 | 0.554 | 0.542 | 0.541 | 0.578 | 0.527 |
| sim-b-new -> sim-a-new | 0.587 | 0.621 | 0.598 | 0.606 | 0.591 | 0.608 | 0.661 | 0.585 |
| sim-b-new -> sim-b-old | 0.543 | 0.571 | 0.549 | 0.540 | 0.538 | 0.548 | 0.529 | 0.527 |
| sim-b-new -> sim-b-new | 0.697 | 0.710 | 0.719 | 0.720 | 0.684 | 0.695 | 0.676 | 0.629 |
