# Board of score types

Study `sim`. Ranked by the retained ranking signal theta after the swap, per kind of swap (higher is better), with the home concordance beside it: a type that ranks nothing at home has nothing to lose. Every entry was re-run by the harness from the released tables. Brackets: two-way Fieller 95 % intervals. Per stream and per ordered pair: score_types.csv.

## same-maker upgrades (ddxplus)

| rank | score type | source | theta | Cw at home | Cw after the swap |
|---|---|---|---|---|---|
| 1 | credit | paper | 0.84 [0.54, 1.28] | 0.656 | 0.639 |
| 2 | visits | paper | 0.81 [0.44, 1.42] | 0.623 | 0.607 |
| 3 | lcb_grade | outside entry | 0.75 [0.51, 1.09] | 0.686 | 0.648 |
| 4 | tags_self | paper | 0.73 [0.53, 0.99] | 0.753 | 0.694 |
| 5 | ema_grade | paper | 0.73 [0.47, 1.09] | 0.683 | 0.641 |
| 6 | beta_grade | paper | 0.72 [0.49, 1.03] | 0.703 | 0.654 |

## same-maker downgrades (ddxplus)

| rank | score type | source | theta | Cw at home | Cw after the swap |
|---|---|---|---|---|---|
| 1 | ema_grade | paper | 0.75 [0.51, 1.09] | 0.683 | 0.640 |
| 2 | credit | paper | 0.72 [0.43, 1.16] | 0.668 | 0.623 |
| 3 | beta_grade | paper | 0.68 [0.46, 0.95] | 0.716 | 0.650 |
| 4 | lcb_grade | outside entry | 0.65 [0.40, 0.92] | 0.696 | 0.629 |
| 5 | tags_self | paper | 0.53 [0.32, 0.71] | 0.743 | 0.631 |
| 6 | visits | paper | 0.97 [0.36, 2.08] (home signal too weak) | 0.591 | 0.591 |

## cross-maker swaps (ddxplus)

| rank | score type | source | theta | Cw at home | Cw after the swap |
|---|---|---|---|---|---|
| 1 | visits | paper | 0.34 [0.04, 0.67] | 0.607 | 0.537 |
| 2 | credit | paper | 0.33 [0.11, 0.56] | 0.662 | 0.555 |
| 3 | tags_self | paper | 0.23 [0.11, 0.37] | 0.748 | 0.559 |
| 4 | ema_grade | paper | 0.20 [0.01, 0.37] | 0.683 | 0.538 |
| 5 | lcb_grade | outside entry | 0.19 [0.01, 0.35] | 0.691 | 0.538 |
| 6 | beta_grade | paper | 0.18 [0.01, 0.32] | 0.709 | 0.539 |

## Every ordered pair (theta)

| owner -> reader | beta_grade | credit | ema_grade | lcb_grade | tags_self | visits |
|---|---|---|---|---|---|---|
| sim-a-old -> sim-a-new | 0.64 | 0.86 | 0.66 | 0.74 | 0.59 | 1.20 |
| sim-a-old -> sim-b-old | -0.19 | 0.17 | 0.11 | -0.25 | -0.06 | -0.46 |
| sim-a-old -> sim-b-new | -0.39 | -0.32 | -0.33 | -0.48 | -0.10 | -0.78 |
| sim-a-new -> sim-a-old | 0.86 | 0.72 | 0.99 | 0.75 | 0.65 | 0.93 |
| sim-a-new -> sim-b-old | 0.48 | 0.78 | 0.32 | 0.45 | 0.40 | 0.96 |
| sim-a-new -> sim-b-new | 0.31 | 0.71 | 0.36 | 0.43 | 0.63 | 0.74 |
| sim-b-old -> sim-a-old | 0.28 | 0.15 | 0.35 | 0.21 | 0.31 | 0.09 |
| sim-b-old -> sim-a-new | 0.21 | 0.01 | 0.27 | 0.25 | 0.20 | 0.29 |
| sim-b-old -> sim-b-new | 0.80 | 0.83 | 0.79 | 0.76 | 0.86 | 0.52 |
| sim-b-new -> sim-a-old | 0.35 | 0.51 | 0.28 | 0.48 | 0.28 | 1.59 |
| sim-b-new -> sim-a-new | 0.20 | 0.40 | 0.18 | 0.17 | 0.21 | 0.54 |
| sim-b-new -> sim-b-old | 0.52 | 0.71 | 0.50 | 0.55 | 0.43 | 1.02 |
