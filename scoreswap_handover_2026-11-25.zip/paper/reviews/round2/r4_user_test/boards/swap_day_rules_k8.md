# Board of swap-day rules, budget k = 8

Study `sim`. Ranked by first-shown success per kind of swap (higher is better), with regret, the level-corrected log score (when the rule returns p) and the checks used beside it. Every entry was re-run by the harness from the released tables. Brackets: two-way 95 % intervals. Per stream and per ordered pair: swap_day_rules_k8.csv.

## same-maker upgrades (ddxplus)

| rank | rule | source | first-shown success | regret | log score (lc) | checks used |
|---|---|---|---|---|---|---|
| 1 | leverage_eb | outside entry | 0.708 [0.653, 0.763] | 0.189 | -0.733 | 8.0 |
| 2 | keep | paper (ema_grade) | 0.703 [0.646, 0.761] | 0.194 | -0.735 | 0.0 |
| 3 | fixed_0.5 | paper (ema_grade) | 0.696 [0.636, 0.757] | 0.201 | -0.679 | 0.0 |
| 4 | audit_8 | paper (ema_grade) | 0.678 [0.624, 0.732] | 0.219 | -0.721 | 8.0 |
| 5 | powerprior_8 | paper (ema_grade) | 0.677 [0.620, 0.735] | 0.220 | -0.691 | 8.0 |
| 6 | recal_8 | paper (ema_grade) | 0.675 [0.620, 0.730] | 0.222 | -0.705 | 8.0 |
| 7 | retest_8 | paper (ema_grade) | 0.671 [0.613, 0.730] | 0.226 | -0.694 | 8.0 |
| 8 | wipe | paper (ema_grade) | 0.634 [0.575, 0.693] | 0.263 | -0.697 | 0.0 |

## same-maker downgrades (ddxplus)

| rank | rule | source | first-shown success | regret | log score (lc) | checks used |
|---|---|---|---|---|---|---|
| 1 | fixed_0.5 | paper (ema_grade) | 0.623 [0.562, 0.684] | 0.223 | -0.678 | 0.0 |
| 2 | leverage_eb | outside entry | 0.610 [0.552, 0.669] | 0.236 | -0.742 | 8.0 |
| 3 | keep | paper (ema_grade) | 0.609 [0.548, 0.671] | 0.237 | -0.756 | 0.0 |
| 4 | audit_8 | paper (ema_grade) | 0.590 [0.534, 0.646] | 0.256 | -0.736 | 8.0 |
| 5 | recal_8 | paper (ema_grade) | 0.583 [0.528, 0.638] | 0.263 | -0.704 | 8.0 |
| 6 | powerprior_8 | paper (ema_grade) | 0.572 [0.517, 0.627] | 0.274 | -0.692 | 8.0 |
| 7 | retest_8 | paper (ema_grade) | 0.558 [0.499, 0.617] | 0.288 | -0.691 | 8.0 |
| 8 | wipe | paper (ema_grade) | 0.554 [0.491, 0.616] | 0.292 | -0.695 | 0.0 |

## cross-maker swaps (ddxplus)

| rank | rule | source | first-shown success | regret | log score (lc) | checks used |
|---|---|---|---|---|---|---|
| 1 | leverage_eb | outside entry | 0.589 [0.545, 0.633] | 0.281 | -0.837 | 8.0 |
| 2 | fixed_0.5 | paper (ema_grade) | 0.583 [0.536, 0.630] | 0.287 | -0.715 | 0.0 |
| 3 | keep | paper (ema_grade) | 0.581 [0.534, 0.629] | 0.289 | -0.832 | 0.0 |
| 4 | retest_8 | paper (ema_grade) | 0.577 [0.534, 0.620] | 0.293 | -0.699 | 8.0 |
| 5 | audit_8 | paper (ema_grade) | 0.574 [0.533, 0.615] | 0.296 | -0.773 | 8.0 |
| 6 | recal_8 | paper (ema_grade) | 0.573 [0.533, 0.613] | 0.297 | -0.729 | 8.0 |
| 7 | powerprior_8 | paper (ema_grade) | 0.573 [0.532, 0.614] | 0.297 | -0.705 | 8.0 |
| 8 | wipe | paper (ema_grade) | 0.566 [0.526, 0.607] | 0.304 | -0.698 | 0.0 |

## home cells (no swap) (ddxplus)

| rank | rule | source | first-shown success | regret | log score (lc) | checks used |
|---|---|---|---|---|---|---|
| 1 | keep | paper (ema_grade) | 0.691 [0.643, 0.739] | 0.185 | -0.720 | 0.0 |
| 2 | leverage_eb | outside entry | 0.689 [0.643, 0.736] | 0.187 | -0.713 | 8.0 |
| 3 | fixed_0.5 | paper (ema_grade) | 0.688 [0.642, 0.733] | 0.189 | -0.672 | 0.0 |
| 4 | powerprior_8 | paper (ema_grade) | 0.667 [0.625, 0.709] | 0.209 | -0.688 | 8.0 |
| 5 | recal_8 | paper (ema_grade) | 0.665 [0.622, 0.708] | 0.211 | -0.698 | 8.0 |
| 6 | audit_8 | paper (ema_grade) | 0.664 [0.621, 0.708] | 0.212 | -0.713 | 8.0 |
| 7 | retest_8 | paper (ema_grade) | 0.646 [0.596, 0.696] | 0.230 | -0.693 | 8.0 |
| 8 | wipe | paper (ema_grade) | 0.598 [0.550, 0.646] | 0.278 | -0.699 | 0.0 |

## Every ordered pair (first-shown success)

| owner -> reader | audit_8 | fixed_0.5 | keep | leverage_eb | powerprior_8 | recal_8 | retest_8 | wipe |
|---|---|---|---|---|---|---|---|---|
| sim-a-old -> sim-a-old | 0.627 | 0.656 | 0.661 | 0.663 | 0.622 | 0.631 | 0.589 | 0.540 |
| sim-a-old -> sim-a-new | 0.703 | 0.728 | 0.746 | 0.748 | 0.703 | 0.702 | 0.680 | 0.638 |
| sim-a-old -> sim-b-old | 0.506 | 0.478 | 0.482 | 0.479 | 0.508 | 0.494 | 0.512 | 0.527 |
| sim-a-old -> sim-b-new | 0.608 | 0.589 | 0.589 | 0.598 | 0.607 | 0.605 | 0.616 | 0.638 |
| sim-a-new -> sim-a-old | 0.638 | 0.674 | 0.670 | 0.685 | 0.607 | 0.622 | 0.601 | 0.580 |
| sim-a-new -> sim-a-new | 0.731 | 0.754 | 0.754 | 0.743 | 0.763 | 0.735 | 0.736 | 0.679 |
| sim-a-new -> sim-b-old | 0.486 | 0.518 | 0.513 | 0.523 | 0.480 | 0.490 | 0.502 | 0.455 |
| sim-a-new -> sim-b-new | 0.637 | 0.647 | 0.647 | 0.673 | 0.641 | 0.623 | 0.624 | 0.625 |
| sim-b-old -> sim-a-old | 0.591 | 0.594 | 0.598 | 0.586 | 0.591 | 0.575 | 0.598 | 0.585 |
| sim-b-old -> sim-a-new | 0.628 | 0.652 | 0.656 | 0.653 | 0.620 | 0.638 | 0.609 | 0.589 |
| sim-b-old -> sim-b-old | 0.611 | 0.629 | 0.629 | 0.629 | 0.605 | 0.608 | 0.594 | 0.545 |
| sim-b-old -> sim-b-new | 0.654 | 0.665 | 0.661 | 0.668 | 0.651 | 0.648 | 0.662 | 0.629 |
| sim-b-new -> sim-a-old | 0.554 | 0.567 | 0.567 | 0.577 | 0.543 | 0.548 | 0.534 | 0.527 |
| sim-b-new -> sim-a-new | 0.584 | 0.621 | 0.598 | 0.620 | 0.591 | 0.611 | 0.618 | 0.585 |
| sim-b-new -> sim-b-old | 0.542 | 0.571 | 0.549 | 0.536 | 0.537 | 0.543 | 0.515 | 0.527 |
| sim-b-new -> sim-b-new | 0.689 | 0.710 | 0.719 | 0.722 | 0.679 | 0.685 | 0.665 | 0.629 |
