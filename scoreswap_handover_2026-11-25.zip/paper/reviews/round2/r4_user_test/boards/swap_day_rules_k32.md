# Board of swap-day rules, budget k = 32

Study `sim`. Ranked by first-shown success per kind of swap (higher is better), with regret, the level-corrected log score (when the rule returns p) and the checks used beside it. Every entry was re-run by the harness from the released tables. Brackets: two-way 95 % intervals. Per stream and per ordered pair: swap_day_rules_k32.csv.

## same-maker upgrades (ddxplus)

| rank | rule | source | first-shown success | regret | log score (lc) | checks used |
|---|---|---|---|---|---|---|
| 1 | leverage_eb | outside entry | 0.707 [0.649, 0.766] | 0.190 | -0.731 | 32.0 |
| 2 | keep | paper (ema_grade) | 0.703 [0.646, 0.761] | 0.194 | -0.735 | 0.0 |
| 3 | fixed_0.5 | paper (ema_grade) | 0.696 [0.636, 0.757] | 0.201 | -0.679 | 0.0 |
| 4 | audit_32 | paper (ema_grade) | 0.688 [0.632, 0.744] | 0.209 | -0.728 | 32.0 |
| 5 | powerprior_32 | paper (ema_grade) | 0.686 [0.626, 0.746] | 0.211 | -0.689 | 32.0 |
| 6 | recal_32 | paper (ema_grade) | 0.682 [0.624, 0.740] | 0.215 | -0.692 | 32.0 |
| 7 | retest_32 | paper (ema_grade) | 0.675 [0.610, 0.740] | 0.223 | -0.691 | 32.0 |
| 8 | wipe | paper (ema_grade) | 0.634 [0.575, 0.693] | 0.263 | -0.697 | 0.0 |

## same-maker downgrades (ddxplus)

| rank | rule | source | first-shown success | regret | log score (lc) | checks used |
|---|---|---|---|---|---|---|
| 1 | leverage_eb | outside entry | 0.632 [0.575, 0.688] | 0.214 | -0.732 | 32.0 |
| 2 | fixed_0.5 | paper (ema_grade) | 0.623 [0.562, 0.684] | 0.223 | -0.678 | 0.0 |
| 3 | keep | paper (ema_grade) | 0.609 [0.548, 0.671] | 0.237 | -0.756 | 0.0 |
| 4 | audit_32 | paper (ema_grade) | 0.599 [0.541, 0.657] | 0.247 | -0.747 | 32.0 |
| 5 | recal_32 | paper (ema_grade) | 0.597 [0.540, 0.654] | 0.249 | -0.689 | 32.0 |
| 6 | retest_32 | paper (ema_grade) | 0.573 [0.519, 0.628] | 0.273 | -0.696 | 32.0 |
| 7 | powerprior_32 | paper (ema_grade) | 0.571 [0.515, 0.626] | 0.275 | -0.690 | 32.0 |
| 8 | wipe | paper (ema_grade) | 0.554 [0.491, 0.616] | 0.292 | -0.695 | 0.0 |

## cross-maker swaps (ddxplus)

| rank | rule | source | first-shown success | regret | log score (lc) | checks used |
|---|---|---|---|---|---|---|
| 1 | leverage_eb | outside entry | 0.607 [0.566, 0.648] | 0.263 | -0.836 | 32.0 |
| 2 | retest_32 | paper (ema_grade) | 0.595 [0.555, 0.636] | 0.274 | -0.701 | 32.0 |
| 3 | fixed_0.5 | paper (ema_grade) | 0.583 [0.536, 0.630] | 0.287 | -0.715 | 0.0 |
| 4 | keep | paper (ema_grade) | 0.581 [0.534, 0.629] | 0.289 | -0.832 | 0.0 |
| 5 | powerprior_32 | paper (ema_grade) | 0.575 [0.534, 0.616] | 0.295 | -0.702 | 32.0 |
| 6 | audit_32 | paper (ema_grade) | 0.573 [0.531, 0.615] | 0.297 | -0.783 | 32.0 |
| 7 | recal_32 | paper (ema_grade) | 0.571 [0.532, 0.610] | 0.299 | -0.711 | 32.0 |
| 8 | wipe | paper (ema_grade) | 0.566 [0.526, 0.607] | 0.304 | -0.698 | 0.0 |

## home cells (no swap) (ddxplus)

| rank | rule | source | first-shown success | regret | log score (lc) | checks used |
|---|---|---|---|---|---|---|
| 1 | leverage_eb | outside entry | 0.695 [0.650, 0.741] | 0.181 | -0.707 | 32.0 |
| 2 | keep | paper (ema_grade) | 0.691 [0.643, 0.739] | 0.185 | -0.720 | 0.0 |
| 3 | fixed_0.5 | paper (ema_grade) | 0.688 [0.642, 0.733] | 0.189 | -0.672 | 0.0 |
| 4 | recal_32 | paper (ema_grade) | 0.681 [0.637, 0.726] | 0.195 | -0.685 | 32.0 |
| 5 | audit_32 | paper (ema_grade) | 0.681 [0.635, 0.727] | 0.195 | -0.717 | 32.0 |
| 6 | powerprior_32 | paper (ema_grade) | 0.679 [0.636, 0.721] | 0.197 | -0.685 | 32.0 |
| 7 | retest_32 | paper (ema_grade) | 0.661 [0.618, 0.704] | 0.215 | -0.693 | 32.0 |
| 8 | wipe | paper (ema_grade) | 0.598 [0.550, 0.646] | 0.278 | -0.699 | 0.0 |

## Every ordered pair (first-shown success)

| owner -> reader | audit_32 | fixed_0.5 | keep | leverage_eb | powerprior_32 | recal_32 | retest_32 | wipe |
|---|---|---|---|---|---|---|---|---|
| sim-a-old -> sim-a-old | 0.647 | 0.656 | 0.661 | 0.658 | 0.638 | 0.646 | 0.623 | 0.540 |
| sim-a-old -> sim-a-new | 0.719 | 0.728 | 0.746 | 0.749 | 0.714 | 0.706 | 0.684 | 0.638 |
| sim-a-old -> sim-b-old | 0.502 | 0.478 | 0.482 | 0.535 | 0.513 | 0.506 | 0.536 | 0.527 |
| sim-a-old -> sim-b-new | 0.596 | 0.589 | 0.589 | 0.577 | 0.608 | 0.607 | 0.581 | 0.638 |
| sim-a-new -> sim-a-old | 0.652 | 0.674 | 0.670 | 0.695 | 0.604 | 0.642 | 0.609 | 0.580 |
| sim-a-new -> sim-a-new | 0.746 | 0.754 | 0.754 | 0.762 | 0.780 | 0.751 | 0.694 | 0.679 |
| sim-a-new -> sim-b-old | 0.487 | 0.518 | 0.513 | 0.543 | 0.481 | 0.489 | 0.508 | 0.455 |
| sim-a-new -> sim-b-new | 0.638 | 0.647 | 0.647 | 0.673 | 0.641 | 0.619 | 0.601 | 0.625 |
| sim-b-old -> sim-a-old | 0.590 | 0.594 | 0.598 | 0.639 | 0.594 | 0.567 | 0.617 | 0.585 |
| sim-b-old -> sim-a-new | 0.630 | 0.652 | 0.656 | 0.668 | 0.630 | 0.638 | 0.623 | 0.589 |
| sim-b-old -> sim-b-old | 0.625 | 0.629 | 0.629 | 0.634 | 0.613 | 0.624 | 0.636 | 0.545 |
| sim-b-old -> sim-b-new | 0.658 | 0.665 | 0.661 | 0.666 | 0.658 | 0.658 | 0.665 | 0.629 |
| sim-b-new -> sim-a-old | 0.555 | 0.567 | 0.567 | 0.572 | 0.540 | 0.535 | 0.615 | 0.527 |
| sim-b-new -> sim-a-new | 0.587 | 0.621 | 0.598 | 0.653 | 0.589 | 0.608 | 0.683 | 0.585 |
| sim-b-new -> sim-b-old | 0.546 | 0.571 | 0.549 | 0.569 | 0.538 | 0.553 | 0.538 | 0.527 |
| sim-b-new -> sim-b-new | 0.706 | 0.710 | 0.719 | 0.726 | 0.685 | 0.704 | 0.690 | 0.629 |
