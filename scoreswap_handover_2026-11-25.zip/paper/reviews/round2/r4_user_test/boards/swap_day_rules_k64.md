# Board of swap-day rules, budget k = 64

Study `sim`. Ranked by first-shown success per kind of swap (higher is better), with regret, the level-corrected log score (when the rule returns p) and the checks used beside it. Every entry was re-run by the harness from the released tables. Brackets: two-way 95 % intervals. Per stream and per ordered pair: swap_day_rules_k64.csv.

## same-maker upgrades (ddxplus)

| rank | rule | source | first-shown success | regret | log score (lc) | checks used |
|---|---|---|---|---|---|---|
| 1 | leverage_eb | outside entry | 0.708 [0.650, 0.767] | 0.189 | -0.732 | 50.5 |
| 2 | keep | paper (ema_grade) | 0.703 [0.646, 0.761] | 0.194 | -0.735 | 0.0 |
| 3 | fixed_0.5 | paper (ema_grade) | 0.696 [0.636, 0.757] | 0.201 | -0.679 | 0.0 |
| 4 | audit_64 | paper (ema_grade) | 0.691 [0.634, 0.747] | 0.207 | -0.730 | 64.0 |
| 5 | powerprior_64 | paper (ema_grade) | 0.689 [0.628, 0.750] | 0.209 | -0.688 | 64.0 |
| 6 | recal_64 | paper (ema_grade) | 0.684 [0.625, 0.743] | 0.214 | -0.687 | 64.0 |
| 7 | retest_64 | paper (ema_grade) | 0.652 [0.593, 0.712] | 0.245 | -0.695 | 50.5 |
| 8 | wipe | paper (ema_grade) | 0.634 [0.575, 0.693] | 0.263 | -0.697 | 0.0 |

## same-maker downgrades (ddxplus)

| rank | rule | source | first-shown success | regret | log score (lc) | checks used |
|---|---|---|---|---|---|---|
| 1 | leverage_eb | outside entry | 0.637 [0.580, 0.694] | 0.209 | -0.726 | 50.5 |
| 2 | fixed_0.5 | paper (ema_grade) | 0.623 [0.562, 0.684] | 0.223 | -0.678 | 0.0 |
| 3 | keep | paper (ema_grade) | 0.609 [0.548, 0.671] | 0.237 | -0.756 | 0.0 |
| 4 | recal_64 | paper (ema_grade) | 0.609 [0.550, 0.667] | 0.237 | -0.681 | 64.0 |
| 5 | audit_64 | paper (ema_grade) | 0.605 [0.545, 0.665] | 0.241 | -0.753 | 64.0 |
| 6 | powerprior_64 | paper (ema_grade) | 0.569 [0.512, 0.626] | 0.277 | -0.688 | 64.0 |
| 7 | wipe | paper (ema_grade) | 0.554 [0.491, 0.616] | 0.292 | -0.695 | 0.0 |
| 8 | retest_64 | paper (ema_grade) | 0.552 [0.500, 0.604] | 0.294 | -0.701 | 50.5 |

## cross-maker swaps (ddxplus)

| rank | rule | source | first-shown success | regret | log score (lc) | checks used |
|---|---|---|---|---|---|---|
| 1 | leverage_eb | outside entry | 0.611 [0.569, 0.652] | 0.259 | -0.834 | 50.5 |
| 2 | retest_64 | paper (ema_grade) | 0.598 [0.558, 0.638] | 0.272 | -0.703 | 50.5 |
| 3 | fixed_0.5 | paper (ema_grade) | 0.583 [0.536, 0.630] | 0.287 | -0.715 | 0.0 |
| 4 | keep | paper (ema_grade) | 0.581 [0.534, 0.629] | 0.289 | -0.832 | 0.0 |
| 5 | powerprior_64 | paper (ema_grade) | 0.575 [0.534, 0.616] | 0.295 | -0.701 | 64.0 |
| 6 | recal_64 | paper (ema_grade) | 0.574 [0.534, 0.615] | 0.296 | -0.704 | 64.0 |
| 7 | audit_64 | paper (ema_grade) | 0.572 [0.529, 0.614] | 0.298 | -0.792 | 64.0 |
| 8 | wipe | paper (ema_grade) | 0.566 [0.526, 0.607] | 0.304 | -0.698 | 0.0 |

## home cells (no swap) (ddxplus)

| rank | rule | source | first-shown success | regret | log score (lc) | checks used |
|---|---|---|---|---|---|---|
| 1 | leverage_eb | outside entry | 0.694 [0.649, 0.739] | 0.182 | -0.706 | 50.5 |
| 2 | keep | paper (ema_grade) | 0.691 [0.643, 0.739] | 0.185 | -0.720 | 0.0 |
| 3 | fixed_0.5 | paper (ema_grade) | 0.688 [0.642, 0.733] | 0.189 | -0.672 | 0.0 |
| 4 | audit_64 | paper (ema_grade) | 0.687 [0.640, 0.734] | 0.189 | -0.719 | 64.0 |
| 5 | powerprior_64 | paper (ema_grade) | 0.685 [0.642, 0.729] | 0.191 | -0.684 | 64.0 |
| 6 | recal_64 | paper (ema_grade) | 0.685 [0.640, 0.730] | 0.191 | -0.679 | 64.0 |
| 7 | retest_64 | paper (ema_grade) | 0.644 [0.599, 0.688] | 0.233 | -0.690 | 50.5 |
| 8 | wipe | paper (ema_grade) | 0.598 [0.550, 0.646] | 0.278 | -0.699 | 0.0 |

## Every ordered pair (first-shown success)

| owner -> reader | audit_64 | fixed_0.5 | keep | leverage_eb | powerprior_64 | recal_64 | retest_64 | wipe |
|---|---|---|---|---|---|---|---|---|
| sim-a-old -> sim-a-old | 0.655 | 0.656 | 0.661 | 0.658 | 0.647 | 0.650 | 0.605 | 0.540 |
| sim-a-old -> sim-a-new | 0.721 | 0.728 | 0.746 | 0.744 | 0.715 | 0.706 | 0.655 | 0.638 |
| sim-a-old -> sim-b-old | 0.496 | 0.478 | 0.482 | 0.556 | 0.519 | 0.513 | 0.529 | 0.527 |
| sim-a-old -> sim-b-new | 0.592 | 0.589 | 0.589 | 0.594 | 0.601 | 0.604 | 0.589 | 0.638 |
| sim-a-new -> sim-a-old | 0.661 | 0.674 | 0.670 | 0.699 | 0.601 | 0.656 | 0.587 | 0.580 |
| sim-a-new -> sim-a-new | 0.752 | 0.754 | 0.754 | 0.765 | 0.786 | 0.755 | 0.671 | 0.679 |
| sim-a-new -> sim-b-old | 0.484 | 0.518 | 0.513 | 0.564 | 0.483 | 0.490 | 0.516 | 0.455 |
| sim-a-new -> sim-b-new | 0.638 | 0.647 | 0.647 | 0.663 | 0.643 | 0.627 | 0.613 | 0.625 |
| sim-b-old -> sim-a-old | 0.589 | 0.594 | 0.598 | 0.619 | 0.595 | 0.567 | 0.647 | 0.585 |
| sim-b-old -> sim-a-new | 0.638 | 0.652 | 0.656 | 0.665 | 0.637 | 0.646 | 0.642 | 0.589 |
| sim-b-old -> sim-b-old | 0.629 | 0.629 | 0.629 | 0.633 | 0.619 | 0.629 | 0.628 | 0.545 |
| sim-b-old -> sim-b-new | 0.661 | 0.665 | 0.661 | 0.673 | 0.663 | 0.662 | 0.650 | 0.629 |
| sim-b-new -> sim-a-old | 0.556 | 0.567 | 0.567 | 0.580 | 0.537 | 0.540 | 0.582 | 0.527 |
| sim-b-new -> sim-a-new | 0.579 | 0.621 | 0.598 | 0.647 | 0.584 | 0.606 | 0.665 | 0.585 |
| sim-b-new -> sim-b-old | 0.549 | 0.571 | 0.549 | 0.574 | 0.537 | 0.561 | 0.517 | 0.527 |
| sim-b-new -> sim-b-new | 0.713 | 0.710 | 0.719 | 0.720 | 0.689 | 0.707 | 0.671 | 0.629 |
