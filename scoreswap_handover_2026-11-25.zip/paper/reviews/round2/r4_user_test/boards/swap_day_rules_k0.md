# Board of swap-day rules, budget k = 0

Study `sim`. Ranked by first-shown success per kind of swap (higher is better), with regret, the level-corrected log score (when the rule returns p) and the checks used beside it. Every entry was re-run by the harness from the released tables. Brackets: two-way 95 % intervals. Per stream and per ordered pair: swap_day_rules_k0.csv.

## same-maker upgrades (ddxplus)

| rank | rule | source | first-shown success | regret | log score (lc) | checks used |
|---|---|---|---|---|---|---|
| 1 | keep | paper (ema_grade) | 0.703 [0.646, 0.761] | 0.194 | -0.735 | 0.0 |
| 2 | leverage_eb | outside entry | 0.703 [0.646, 0.761] | 0.194 | -0.735 | 0.0 |
| 3 | fixed_0.5 | paper (ema_grade) | 0.696 [0.636, 0.757] | 0.201 | -0.679 | 0.0 |
| 4 | wipe | paper (ema_grade) | 0.634 [0.575, 0.693] | 0.263 | -0.697 | 0.0 |

## same-maker downgrades (ddxplus)

| rank | rule | source | first-shown success | regret | log score (lc) | checks used |
|---|---|---|---|---|---|---|
| 1 | fixed_0.5 | paper (ema_grade) | 0.623 [0.562, 0.684] | 0.223 | -0.678 | 0.0 |
| 2 | keep | paper (ema_grade) | 0.609 [0.548, 0.671] | 0.237 | -0.756 | 0.0 |
| 3 | leverage_eb | outside entry | 0.609 [0.548, 0.671] | 0.237 | -0.756 | 0.0 |
| 4 | wipe | paper (ema_grade) | 0.554 [0.491, 0.616] | 0.292 | -0.695 | 0.0 |

## cross-maker swaps (ddxplus)

| rank | rule | source | first-shown success | regret | log score (lc) | checks used |
|---|---|---|---|---|---|---|
| 1 | fixed_0.5 | paper (ema_grade) | 0.583 [0.536, 0.630] | 0.287 | -0.715 | 0.0 |
| 2 | keep | paper (ema_grade) | 0.581 [0.534, 0.629] | 0.289 | -0.832 | 0.0 |
| 3 | leverage_eb | outside entry | 0.581 [0.534, 0.629] | 0.289 | -0.832 | 0.0 |
| 4 | wipe | paper (ema_grade) | 0.566 [0.526, 0.607] | 0.304 | -0.698 | 0.0 |

## home cells (no swap) (ddxplus)

| rank | rule | source | first-shown success | regret | log score (lc) | checks used |
|---|---|---|---|---|---|---|
| 1 | keep | paper (ema_grade) | 0.691 [0.643, 0.739] | 0.185 | -0.720 | 0.0 |
| 2 | leverage_eb | outside entry | 0.691 [0.643, 0.739] | 0.185 | -0.720 | 0.0 |
| 3 | fixed_0.5 | paper (ema_grade) | 0.688 [0.642, 0.733] | 0.189 | -0.672 | 0.0 |
| 4 | wipe | paper (ema_grade) | 0.598 [0.550, 0.646] | 0.278 | -0.699 | 0.0 |

## Every ordered pair (first-shown success)

| owner -> reader | fixed_0.5 | keep | leverage_eb | wipe |
|---|---|---|---|---|
| sim-a-old -> sim-a-old | 0.656 | 0.661 | 0.661 | 0.540 |
| sim-a-old -> sim-a-new | 0.728 | 0.746 | 0.746 | 0.638 |
| sim-a-old -> sim-b-old | 0.478 | 0.482 | 0.482 | 0.527 |
| sim-a-old -> sim-b-new | 0.589 | 0.589 | 0.589 | 0.638 |
| sim-a-new -> sim-a-old | 0.674 | 0.670 | 0.670 | 0.580 |
| sim-a-new -> sim-a-new | 0.754 | 0.754 | 0.754 | 0.679 |
| sim-a-new -> sim-b-old | 0.518 | 0.513 | 0.513 | 0.455 |
| sim-a-new -> sim-b-new | 0.647 | 0.647 | 0.647 | 0.625 |
| sim-b-old -> sim-a-old | 0.594 | 0.598 | 0.598 | 0.585 |
| sim-b-old -> sim-a-new | 0.652 | 0.656 | 0.656 | 0.589 |
| sim-b-old -> sim-b-old | 0.629 | 0.629 | 0.629 | 0.545 |
| sim-b-old -> sim-b-new | 0.665 | 0.661 | 0.661 | 0.629 |
| sim-b-new -> sim-a-old | 0.567 | 0.567 | 0.567 | 0.527 |
| sim-b-new -> sim-a-new | 0.621 | 0.598 | 0.598 | 0.585 |
| sim-b-new -> sim-b-old | 0.571 | 0.549 | 0.549 | 0.527 |
| sim-b-new -> sim-b-new | 0.710 | 0.719 | 0.719 | 0.629 |
