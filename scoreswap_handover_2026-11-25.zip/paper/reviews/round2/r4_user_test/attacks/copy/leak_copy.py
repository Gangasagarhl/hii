"""ATTACK: reads a copy of harness_only/evaluation_results.csv placed in the entry's own folder.
The checker allows reading the entry's own folder; the canary permutes only the harness's copy."""
import csv, io, os
import numpy as np
KIND = "swap_day_rule"
NAME = "leak_copy"
DESCRIPTION = "shows the in-sample best candidate, read from a copied exam file"
_BEST = None

def _best_positions(text):
    acc = {}
    for row in csv.DictReader(io.StringIO(text)):
        if row["set"] != "regular" or row["position"] == "":
            continue
        k = (row["owner"], row["reader"], row["stream"], int(row["order"]), row["task_id"])
        d = acc.setdefault(k, {})
        p = int(row["position"]); s, n = d.get(p, (0.0, 0)); d[p] = (s + float(row["result"]), n + 1)
    return {k: max(sorted(d), key=lambda p: d[p][0] / d[p][1]) for k, d in acc.items()}

def rule(bank, candidates, swap, checks):
    global _BEST
    if _BEST is None:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "evaluation_results.csv")) as fh:
            _BEST = _best_positions(fh.read())
    U = np.zeros((len(candidates.tasks), 4))
    for t, task in enumerate(candidates.tasks):
        b = _BEST.get((swap.owner, swap.reader, swap.stream, int(swap.order), task))
        if b is not None:
            U[t, b] = 1.0
    return {"u_cand": U, "p_cand": np.clip(U, 0.2, 0.8)}
