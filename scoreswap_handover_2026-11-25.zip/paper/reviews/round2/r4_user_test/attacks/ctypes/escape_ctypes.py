"""ATTACK probe: try to read the harness's own evaluation file through libc (ctypes), which Python
audit hooks do not see. Raises with what it managed to read."""
import os
import numpy as np
KIND = "swap_day_rule"
NAME = "escape_ctypes"
DESCRIPTION = "probe"

def rule(bank, candidates, swap, checks):
    import ctypes
    here = os.path.dirname(os.path.abspath(__file__))
    root = here.split("/paper/")[0]
    path = (root + "/release/sim/harness_only/evaluation_results.csv").encode()
    libc = ctypes.CDLL("libc.so.6")
    fd = libc.open(path, 0)
    buf = ctypes.create_string_buffer(80)
    n = libc.read(fd, buf, 79)
    raise RuntimeError("fd=%d n=%d head=%r" % (fd, n, buf.value[:79]))
