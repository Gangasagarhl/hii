# leverage_eb: swap-day rule at budget k = 16

Scored from the frozen tables of study `sim` with no model call (pack fingerprint `ab522cf6a6002600`). Each value is a mean over the evaluation tasks; 200 seeded draw(s), each task's value the mean over the draws. Brackets: 95 % intervals, two-way (tasks and items; pre-registration Part 4.1). Differences use the same tasks and the same draws.

First-shown success is the reader's success with the candidate the rule shows first (higher is better); regret is the gap to the task's best candidate (lower is better); theta is the share of the owner's home ranking signal the rule's order keeps for the reader.

## By kind of swap (ddxplus)

| kind | first-shown success |  | regret | log score (level-corrected) | theta | checks used |
|---|---|---|---|---|---|---|
| same-maker upgrades | 0.704 [0.648, 0.759] | 0.194 | -0.734 [-0.786, -0.683] | 0.75 [0.49, 1.10] | 16.0 |
| same-maker downgrades | 0.615 [0.557, 0.673] | 0.231 | -0.739 [-0.785, -0.693] | 0.76 [0.52, 1.08] | 16.0 |
| cross-maker swaps | 0.595 [0.552, 0.637] | 0.275 | -0.954 [-1.002, -0.905] | 0.37 [0.21, 0.55] | 16.0 |
| home cells (no swap) | 0.692 [0.645, 0.739] | 0.184 | -0.710 [-0.738, -0.683] | 1.04 [0.99, 1.09] | 16.0 |

## Every ordered pair (ddxplus)

| owner -> reader | kind | first-shown success | minus keep | minus wipe | regret | theta |
|---|---|---|---|---|---|---|
| sim-a-old -> sim-a-old | home | 0.663 [0.584, 0.742] | - | - | 0.158 | 1.12 |
| sim-a-old -> sim-a-new | same_maker_upgrade | 0.747 [0.665, 0.828] | - | - | 0.160 | 0.69 |
| sim-a-old -> sim-b-old | cross_maker | 0.475 [0.402, 0.548] | - | - | 0.355 | 0.19 |
| sim-a-old -> sim-b-new | cross_maker | 0.578 [0.498, 0.657] | - | - | 0.329 | -0.09 |
| sim-a-new -> sim-a-old | same_maker_downgrade | 0.690 [0.620, 0.760] | - | - | 0.194 | 1.02 |
| sim-a-new -> sim-a-new | home | 0.757 [0.670, 0.845] | - | - | 0.158 | 1.03 |
| sim-a-new -> sim-b-old | cross_maker | 0.555 [0.457, 0.654] | - | - | 0.239 | 0.60 |
| sim-a-new -> sim-b-new | cross_maker | 0.663 [0.597, 0.729] | - | - | 0.212 | 0.68 |
| sim-b-old -> sim-a-old | cross_maker | 0.608 [0.530, 0.685] | - | - | 0.267 | 0.46 |
| sim-b-old -> sim-a-new | cross_maker | 0.685 [0.595, 0.774] | - | - | 0.208 | 0.45 |
| sim-b-old -> sim-b-old | home | 0.627 [0.548, 0.707] | - | - | 0.239 | 1.00 |
| sim-b-old -> sim-b-new | same_maker_upgrade | 0.660 [0.585, 0.736] | - | - | 0.228 | 0.80 |
| sim-b-new -> sim-a-old | cross_maker | 0.574 [0.485, 0.662] | - | - | 0.301 | 0.45 |
| sim-b-new -> sim-a-new | cross_maker | 0.619 [0.550, 0.689] | - | - | 0.291 | 0.14 |
| sim-b-new -> sim-b-old | same_maker_downgrade | 0.540 [0.464, 0.616] | - | - | 0.268 | 0.47 |
| sim-b-new -> sim-b-new | home | 0.720 [0.642, 0.798] | - | - | 0.182 | 1.00 |

Per-stream values, the Brier scores, the uncorrected log score, Cw and the task-only bootstrap intervals are in summary.csv and compare.csv; one row per cell is in cells.csv.
