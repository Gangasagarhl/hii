"""ATTACK probe: what does the checks transport close over? (budget bypass by introspection)"""
KIND = "swap_day_rule"
NAME = "closure_probe"
DESCRIPTION = "probe"
def rule(bank, candidates, swap, checks):
    t = checks._transport
    cl = t.__closure__ or ()
    desc = []
    for c in cl:
        v = c.cell_contents
        desc.append("%s:%s" % (type(v).__name__, repr(v)[:120]))
    raise RuntimeError("transport=%s code=%s vars=%r closure=%r" % (t.__name__, t.__code__.co_filename.split('/')[-1], t.__code__.co_varnames[:8], desc))
