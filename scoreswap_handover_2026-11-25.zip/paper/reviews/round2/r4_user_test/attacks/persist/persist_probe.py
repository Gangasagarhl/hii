"""Attack probe: does module state survive between calls (draws, cells)? What is checks._transport?"""
import numpy as np
KIND = "swap_day_rule"
NAME = "persist_probe"
DESCRIPTION = "counts calls in a module global"
CALLS = []

def rule(bank, candidates, swap, checks):
    CALLS.append((swap.owner, swap.reader, swap.order, swap.budget, swap.draw))
    if len(CALLS) == 40:
        t = checks._transport
        raise RuntimeError("calls so far=%d first=%r last=%r transport=%r attrs=%r" % (
            len(CALLS), CALLS[0], CALLS[-1], type(t), [a for a in dir(t) if not a.startswith('__')]))
    return {"u": bank.mix_score["ema_grade"]}
