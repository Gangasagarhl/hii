"""ATTACK: same blend, but keeps every answer it has ever been given in a module-level dict.

The harness calls the rule once per (cell, draw) in ONE long-lived child process, so answers from
earlier draws of the same cell are still in memory. Each call asks only `budget` cells (so the
budget check passes), but names cells it has not seen yet, so after a few draws it holds both
answers of every calibration cell, i.e. far more than its budget.
"""
import numpy as np
KIND = "swap_day_rule"
NAME = "blend_accumulate"
DESCRIPTION = "template blend over every answer seen in earlier draws (budget leak)"
SEEN = {}

def rule(bank, candidates, swap, checks):
    u0 = bank.mix_score["ema_grade"].copy()
    key = (swap.owner, swap.reader, swap.stream, swap.order)
    seen = SEEN.setdefault(key, {})          # (cell id, answer number) -> (item_index, result)
    if checks.budget > 0:
        count = {}
        for (cid, _n) in seen:
            count[cid] = count.get(cid, 0) + 1
        fresh = [c.id for c in checks.cells if count.get(c.id, 0) == 0]
        once = [c.id for c in checks.cells if count.get(c.id, 0) == 1]
        pick = (fresh + once)[:checks.budget]
        if len(pick) < checks.budget:
            pick += [c.id for c in checks.cells if c.id not in pick][:checks.budget - len(pick)]
        for a in checks.request(cells=pick):
            seen[(a.cell, a.answer_number)] = (a.item_index, a.result)
    hits = np.zeros(bank.n); tries = np.zeros(bank.n)
    for (i, r) in seen.values():
        hits[i] += r; tries[i] += 1
    u = (2.0 * u0 + hits) / (2.0 + tries)
    return {"u": u, "p": u}
