KIND = "swap_day_rule"
NAME = "answer_probe"
DESCRIPTION = "shows an answer object"
def rule(bank, candidates, swap, checks):
    if checks.budget > 0:
        ans = checks.request(cells=[checks.cells[0].id, checks.cells[0].id])
        raise RuntimeError("answers=%r attrs=%r used=%r remaining=%r" % (ans, [a for a in dir(ans[0]) if not a.startswith('_')], checks.used, checks.remaining))
    return {"u": bank.mix_score["ema_grade"]}
