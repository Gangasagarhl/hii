"""Probe: does touching checks.rng before a random request change which 'random' cells arrive?"""
KIND = "swap_day_rule"
NAME = "rng_probe_0"
DESCRIPTION = "probe"
def rule(bank, candidates, swap, checks):
    if checks.budget > 0:
        for _ in range(0):
            checks.rng.random()
        got = [a.cell for a in checks.request(random=8)]
        raise RuntimeError("burn=0 draw=%d cells=%r" % (swap.draw, sorted(got)))
    return {"u": bank.mix_score["ema_grade"]}
