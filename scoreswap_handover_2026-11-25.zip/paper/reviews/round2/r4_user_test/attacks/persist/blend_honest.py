"""Honest baseline for the persistence attack: the template's blend, using only this call's checks."""
import numpy as np
KIND = "swap_day_rule"
NAME = "blend_honest"
DESCRIPTION = "template blend: old score worth 2 checks; unseen cells first is NOT used"

def rule(bank, candidates, swap, checks):
    u0 = bank.mix_score["ema_grade"].copy()
    hits = np.zeros(bank.n); tries = np.zeros(bank.n)
    if checks.budget > 0:
        for a in checks.request(random=checks.budget):
            hits[a.item_index] += a.result; tries[a.item_index] += 1
    u = (2.0 * u0 + hits) / (2.0 + tries)
    return {"u": u, "p": u}
