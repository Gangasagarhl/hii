# blend_accumulate: swap-day rule at budget k = 16

Scored from the frozen tables of study `sim` with no model call (pack fingerprint `ab522cf6a6002600`). Each value is a mean over the evaluation tasks; 200 seeded draw(s), each task's value the mean over the draws. Brackets: 95 % intervals, two-way (tasks and items; pre-registration Part 4.1). Differences use the same tasks and the same draws.

First-shown success is the reader's success with the candidate the rule shows first (higher is better); regret is the gap to the task's best candidate (lower is better); theta is the share of the owner's home ranking signal the rule's order keeps for the reader.

## By kind of swap (ddxplus)

| kind | first-shown success |  | regret | log score (level-corrected) | theta | checks used |
|---|---|---|---|---|---|---|
| same-maker upgrades | 0.703 [0.647, 0.758] | 0.195 | -0.750 [-0.794, -0.707] | 0.84 [0.57, 1.22] | 16.0 |
| same-maker downgrades | 0.644 [0.588, 0.699] | 0.202 | -0.724 [-0.764, -0.684] | 0.92 [0.65, 1.31] | 16.0 |
| cross-maker swaps | 0.624 [0.583, 0.666] | 0.246 | -0.784 [-0.814, -0.753] | 0.56 [0.38, 0.78] | 16.0 |
| home cells (no swap) | 0.710 [0.667, 0.753] | 0.166 | -0.711 [-0.738, -0.683] | 1.20 [1.06, 1.39] | 16.0 |

## Every ordered pair (ddxplus)

| owner -> reader | kind | first-shown success | minus keep | minus wipe | regret | theta |
|---|---|---|---|---|---|---|
| sim-a-old -> sim-a-old | home | 0.663 [0.578, 0.748] | - | - | 0.159 | 1.18 |
| sim-a-old -> sim-a-new | same_maker_upgrade | 0.729 [0.660, 0.799] | - | - | 0.177 | 0.65 |
| sim-a-old -> sim-b-old | cross_maker | 0.550 [0.473, 0.627] | - | - | 0.281 | 0.84 |
| sim-a-old -> sim-b-new | cross_maker | 0.627 [0.549, 0.704] | - | - | 0.280 | 0.11 |
| sim-a-new -> sim-a-old | same_maker_downgrade | 0.707 [0.640, 0.775] | - | - | 0.177 | 1.15 |
| sim-a-new -> sim-a-new | home | 0.756 [0.684, 0.828] | - | - | 0.159 | 1.08 |
| sim-a-new -> sim-b-old | cross_maker | 0.607 [0.530, 0.685] | - | - | 0.187 | 0.72 |
| sim-a-new -> sim-b-new | cross_maker | 0.672 [0.591, 0.753] | - | - | 0.203 | 0.60 |
| sim-b-old -> sim-a-old | cross_maker | 0.653 [0.589, 0.717] | - | - | 0.222 | 0.61 |
| sim-b-old -> sim-a-new | cross_maker | 0.672 [0.582, 0.763] | - | - | 0.220 | 0.65 |
| sim-b-old -> sim-b-old | home | 0.665 [0.590, 0.739] | - | - | 0.201 | 1.16 |
| sim-b-old -> sim-b-new | same_maker_upgrade | 0.676 [0.601, 0.751] | - | - | 0.213 | 1.01 |
| sim-b-new -> sim-a-old | cross_maker | 0.562 [0.459, 0.665] | - | - | 0.313 | 0.47 |
| sim-b-new -> sim-a-new | cross_maker | 0.650 [0.578, 0.722] | - | - | 0.261 | 0.48 |
| sim-b-new -> sim-b-old | same_maker_downgrade | 0.580 [0.506, 0.653] | - | - | 0.228 | 0.67 |
| sim-b-new -> sim-b-new | home | 0.757 [0.692, 0.822] | - | - | 0.145 | 1.38 |

Per-stream values, the Brier scores, the uncorrected log score, Cw and the task-only bootstrap intervals are in summary.csv and compare.csv; one row per cell is in cells.csv.
