# leak_hardcoded: swap-day rule at budget k = 16

Scored from the frozen tables of study `sim` with no model call (pack fingerprint `ab522cf6a6002600`). Each value is a mean over the evaluation tasks; 200 seeded draw(s), each task's value the mean over the draws. Brackets: 95 % intervals, two-way (tasks and items; pre-registration Part 4.1). Differences use the same tasks and the same draws.

First-shown success is the reader's success with the candidate the rule shows first (higher is better); regret is the gap to the task's best candidate (lower is better); theta is the share of the owner's home ranking signal the rule's order keeps for the reader.

## By kind of swap (ddxplus)

| kind | first-shown success |  | regret | log score (level-corrected) | theta | checks used |
|---|---|---|---|---|---|---|
| same-maker upgrades | 0.897 [0.865, 0.929] | 0.000 | -0.724 [-0.766, -0.683] | 1.47 [1.08, 2.20] | 0.0 |
| same-maker downgrades | 0.846 [0.805, 0.887] | 0.000 | -0.697 [-0.746, -0.648] | 1.60 [1.21, 2.32] | 0.0 |
| cross-maker swaps | 0.870 [0.841, 0.899] | 0.000 | -0.705 [-0.736, -0.675] | 1.56 [1.27, 2.02] | 0.0 |
| home cells (no swap) | 0.876 [0.844, 0.908] | 0.000 | -0.710 [-0.746, -0.673] | 1.56 [1.28, 2.00] | 0.0 |

## Every ordered pair (ddxplus)

| owner -> reader | kind | first-shown success | minus keep | minus wipe | regret | theta |
|---|---|---|---|---|---|---|
| sim-a-old -> sim-a-old | home | 0.821 [0.763, 0.879] | - | - | 0.000 | 1.51 |
| sim-a-old -> sim-a-new | same_maker_upgrade | 0.906 [0.865, 0.948] | - | - | 0.000 | 1.46 |
| sim-a-old -> sim-b-old | cross_maker | 0.830 [0.767, 0.893] | - | - | 0.000 | 1.93 |
| sim-a-old -> sim-b-new | cross_maker | 0.906 [0.862, 0.951] | - | - | 0.000 | 1.72 |
| sim-a-new -> sim-a-old | same_maker_downgrade | 0.884 [0.836, 0.932] | - | - | 0.000 | 1.56 |
| sim-a-new -> sim-a-new | home | 0.915 [0.860, 0.970] | - | - | 0.000 | 1.47 |
| sim-a-new -> sim-b-old | cross_maker | 0.795 [0.725, 0.865] | - | - | 0.000 | 1.47 |
| sim-a-new -> sim-b-new | cross_maker | 0.875 [0.828, 0.922] | - | - | 0.000 | 1.42 |
| sim-b-old -> sim-a-old | cross_maker | 0.875 [0.818, 0.932] | - | - | 0.000 | 1.50 |
| sim-b-old -> sim-a-new | cross_maker | 0.893 [0.843, 0.943] | - | - | 0.000 | 1.48 |
| sim-b-old -> sim-b-old | home | 0.866 [0.809, 0.923] | - | - | 0.000 | 1.69 |
| sim-b-old -> sim-b-new | same_maker_upgrade | 0.888 [0.847, 0.930] | - | - | 0.000 | 1.48 |
| sim-b-new -> sim-a-old | cross_maker | 0.875 [0.824, 0.926] | - | - | 0.000 | 1.60 |
| sim-b-new -> sim-a-new | cross_maker | 0.911 [0.862, 0.960] | - | - | 0.000 | 1.45 |
| sim-b-new -> sim-b-old | same_maker_downgrade | 0.808 [0.755, 0.861] | - | - | 0.000 | 1.65 |
| sim-b-new -> sim-b-new | home | 0.902 [0.861, 0.942] | - | - | 0.000 | 1.59 |

Per-stream values, the Brier scores, the uncorrected log score, Cw and the task-only bootstrap intervals are in summary.csv and compare.csv; one row per cell is in cells.csv.
