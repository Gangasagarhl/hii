# blend_honest: swap-day rule at budget k = 16

Scored from the frozen tables of study `sim` with no model call (pack fingerprint `ab522cf6a6002600`). Each value is a mean over the evaluation tasks; 200 seeded draw(s), each task's value the mean over the draws. Brackets: 95 % intervals, two-way (tasks and items; pre-registration Part 4.1). Differences use the same tasks and the same draws.

First-shown success is the reader's success with the candidate the rule shows first (higher is better); regret is the gap to the task's best candidate (lower is better); theta is the share of the owner's home ranking signal the rule's order keeps for the reader.

## By kind of swap (ddxplus)

| kind | first-shown success |  | regret | log score (level-corrected) | theta | checks used |
|---|---|---|---|---|---|---|
| same-maker upgrades | 0.703 [0.647, 0.758] | 0.195 | -0.741 [-0.792, -0.689] | 0.77 [0.51, 1.12] | 16.0 |
| same-maker downgrades | 0.616 [0.559, 0.672] | 0.230 | -0.752 [-0.803, -0.700] | 0.78 [0.55, 1.14] | 16.0 |
| cross-maker swaps | 0.590 [0.545, 0.635] | 0.280 | -0.823 [-0.853, -0.793] | 0.27 [0.10, 0.44] | 16.0 |
| home cells (no swap) | 0.692 [0.647, 0.736] | 0.184 | -0.721 [-0.751, -0.691] | 1.05 [1.01, 1.10] | 16.0 |

## Every ordered pair (ddxplus)

| owner -> reader | kind | first-shown success | minus keep | minus wipe | regret | theta |
|---|---|---|---|---|---|---|
| sim-a-old -> sim-a-old | home | 0.662 [0.585, 0.738] | - | - | 0.160 | 1.05 |
| sim-a-old -> sim-a-new | same_maker_upgrade | 0.746 [0.669, 0.823] | - | - | 0.160 | 0.70 |
| sim-a-old -> sim-b-old | cross_maker | 0.490 [0.416, 0.565] | - | - | 0.340 | 0.19 |
| sim-a-old -> sim-b-new | cross_maker | 0.581 [0.495, 0.667] | - | - | 0.325 | -0.22 |
| sim-a-new -> sim-a-old | same_maker_downgrade | 0.674 [0.606, 0.742] | - | - | 0.210 | 0.99 |
| sim-a-new -> sim-a-new | home | 0.760 [0.681, 0.838] | - | - | 0.155 | 1.05 |
| sim-a-new -> sim-b-old | cross_maker | 0.544 [0.462, 0.626] | - | - | 0.251 | 0.45 |
| sim-a-new -> sim-b-new | cross_maker | 0.652 [0.572, 0.732] | - | - | 0.223 | 0.41 |
| sim-b-old -> sim-a-old | cross_maker | 0.604 [0.530, 0.678] | - | - | 0.271 | 0.39 |
| sim-b-old -> sim-a-new | cross_maker | 0.662 [0.559, 0.766] | - | - | 0.230 | 0.31 |
| sim-b-old -> sim-b-old | home | 0.632 [0.556, 0.708] | - | - | 0.234 | 1.03 |
| sim-b-old -> sim-b-new | same_maker_upgrade | 0.659 [0.587, 0.731] | - | - | 0.229 | 0.83 |
| sim-b-new -> sim-a-old | cross_maker | 0.567 [0.468, 0.666] | - | - | 0.308 | 0.32 |
| sim-b-new -> sim-a-new | cross_maker | 0.619 [0.547, 0.691] | - | - | 0.292 | 0.24 |
| sim-b-new -> sim-b-old | same_maker_downgrade | 0.558 [0.487, 0.629] | - | - | 0.250 | 0.56 |
| sim-b-new -> sim-b-new | home | 0.713 [0.642, 0.784] | - | - | 0.189 | 1.05 |

Per-stream values, the Brier scores, the uncorrected log score, Cw and the task-only bootstrap intervals are in summary.csv and compare.csv; one row per cell is in cells.csv.
