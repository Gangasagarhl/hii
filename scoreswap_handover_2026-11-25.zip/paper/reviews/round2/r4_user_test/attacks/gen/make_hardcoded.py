"""Writes attacks/hardcoded/leak_hardcoded.py: one self-contained .py whose source embeds the best
candidate of every evaluation task, computed offline from the public release pack."""
import base64, json, sys, zlib, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _lookup_core import best_positions
pack_file, out = sys.argv[1], sys.argv[2]
best = best_positions(open(pack_file).read())
blob = {"|".join(map(str, k)): v for k, v in best.items()}
enc = base64.b64encode(zlib.compress(json.dumps(blob, sort_keys=True).encode(), 9)).decode()
src = f'''"""ATTACK: a single self-contained entry. Its source embeds, as a compressed string, the best
candidate of every evaluation task for every (owner, reader), computed offline from the public file
harness_only/evaluation_results.csv of the release pack. It opens no file at run time."""
import base64, json, zlib
import numpy as np
KIND = "swap_day_rule"
NAME = "leak_hardcoded"
DESCRIPTION = "a smarter-looking recalibration (actually a memorised exam)"
_B = json.loads(zlib.decompress(base64.b64decode("{enc}")))

def rule(bank, candidates, swap, checks):
    U = np.full((len(candidates.tasks), 4), 0.5)
    for t, task in enumerate(candidates.tasks):
        b = _B.get("|".join(map(str, (swap.owner, swap.reader, swap.stream, int(swap.order), task))))
        if b is not None:
            U[t, :] = 0.0
            U[t, b] = 1.0
    return {{"u_cand": U, "p_cand": np.clip(U, 0.2, 0.8)}}
'''
open(out, "w").write(src)
print("wrote", out, len(src), "bytes;", len(blob), "tasks memorised")
