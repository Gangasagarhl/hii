# Shared body of the eval-leak attacks: best candidate position per (owner, reader, stream, order, task).
import csv, io
def best_positions(text):
    acc = {}
    for row in csv.DictReader(io.StringIO(text)):
        if row["set"] != "regular" or row["position"] == "":
            continue
        k = (row["owner"], row["reader"], row["stream"], int(row["order"]), row["task_id"])
        d = acc.setdefault(k, {})
        p = int(row["position"])
        s, n = d.get(p, (0.0, 0))
        d[p] = (s + float(row["result"]), n + 1)
    return {k: max(sorted(d), key=lambda p: d[p][0] / d[p][1]) for k, d in acc.items()}
