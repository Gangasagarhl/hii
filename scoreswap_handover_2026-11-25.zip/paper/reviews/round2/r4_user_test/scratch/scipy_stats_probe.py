"""Minimal reproduction: importing scipy.stats in a score type crashes the sealed checker."""
import numpy as np
from scipy.stats import beta
KIND = "score_type"
NAME = "scipy_stats_probe"
DESCRIPTION = "imports scipy.stats"
def score(log):
    return np.zeros(len(log.items))
