KIND = "score_type"
NAME = "scipy_probe"
DESCRIPTION = "does plain import scipy work"
import numpy as np
import scipy
def score(log):
    return np.zeros(len(log.items))
