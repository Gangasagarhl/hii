"""Exploration only: print what the rule receives, then fail on purpose."""
import sys
import numpy as np
KIND = "swap_day_rule"
NAME = "explore_api"
DESCRIPTION = "prints the inputs"

def rule(bank, candidates, swap, checks):
    out = []
    out.append("bank type %r attrs %r" % (type(bank), [a for a in dir(bank) if not a.startswith('__')]))
    out.append("bank.n=%r items[:3]=%r" % (getattr(bank, 'n', None), list(bank.items[:3])))
    out.append("bank.counts keys=%r" % ({k: list(v.keys()) for k, v in bank.counts.items()},))
    out.append("cands attrs %r" % [a for a in dir(candidates) if not a.startswith('__')])
    out.append("cands.tasks[:3]=%r roles[:3]=%r item_index.shape=%r" % (list(candidates.tasks[:3]), list(candidates.roles[:3]), candidates.item_index.shape))
    out.append("swap=%r" % ({a: getattr(swap, a) for a in dir(swap) if not a.startswith('_') and not callable(getattr(swap, a))},))
    out.append("checks attrs %r" % [a for a in dir(checks) if not a.startswith('__')])
    out.append("checks.cells[:3]=%r len=%d" % (list(checks.cells[:3]), len(checks.cells)))
    bi = checks.by_item
    out.append("by_item type %r first=%r" % (type(bi), list(bi.items())[:2] if hasattr(bi, 'items') else bi[:2]))
    raise RuntimeError("\n".join(out))
