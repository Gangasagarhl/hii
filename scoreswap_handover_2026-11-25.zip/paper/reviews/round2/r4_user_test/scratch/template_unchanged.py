"""TEMPLATE: a swap-day rule for ScoreSwap. Copy this file into a folder of your own, rename it,
and change rule(). Nothing else is needed.

Everyday picture: a garage keeps repair tips, each with a score earned with the old mechanic.
A new mechanic starts today. Your rule decides what score each tip carries from now on. It may
ask for a few fresh checks first ("how did the new mechanic do with tip X on test job Y?"), up
to a budget.

The harness calls rule(bank, candidates, swap, checks) once for every cell (the owner of the
bank, the new model reading it, the task stream, the stream order) and, when the budget k is
above 0, once for every seeded random draw (200 in the paper). Each call is a fresh swap day.

What you receive (every field is listed in scoreswap/api.py):
  bank        the old bank: bank.items (ids), bank.score[family], bank.mix_score[family] (in [0, 1]),
              bank.p[family], bank.counts[family][field], bank.visits, bank.showing_probabilities,
              bank.no_memory_rate. Families: ema_grade, beta_grade, tags_self, credit, visits.
  candidates  every probe task with its 4 candidates: candidates.tasks, .roles ('calibration' or
              'evaluation'), .item_index (T x 4, position in bank.items, -1 if none), .relevance (T x 4)
  swap        swap.owner, swap.owner_maker, swap.reader, swap.reader_maker, swap.kind, swap.budget,
              swap.stream, swap.order, swap.draw, swap.options (from --set name=value), swap.settings
  checks      checks.request(cells=[ids]) or checks.request(random=m) -> answers, each with
              .item_index and .result (1.0 right, 0.0 wrong); checks.cells lists the calibration
              cells you may name; checks.by_item / checks.by_task group them; checks.rng is a seeded
              random generator: use it for every random choice

What you return:
  {"u": u} or {"u": u, "p": p}: one number per item, in bank.items order (a list, an array, or a
  dict {item id: number}). u in [0, 1] ranks the items (the harness shows the candidate with the
  largest 0.5 u + 0.5 relevance; ties go to the more relevant item); p in [0, 1] is the chance the
  reader succeeds with the item (the scorer clips it to [0.01, 0.99], as the paper does).
  Or {"u_cand": U, "p_cand": P}: arrays of shape (len(candidates.tasks), 4), one value per probe
  task and candidate, when the value should depend on the task (for example on relevance).

The rules the harness enforces (python -m scoreswap check tests each one):
  - at most swap.budget checks; a cell can be answered at most twice (it holds two repeats);
  - no NaN, no value outside [0, 1], the right shapes;
  - the same output every time for the same seed (use checks.rng, not the clock);
  - no file, network or process use: the rule runs sealed, and never sees an evaluation result.

Try it:
    python -m scoreswap check my_rule.py --pack release/sim
    python -m scoreswap score my_rule.py --pack release/sim --budget 16
"""
import numpy as np

KIND = "swap_day_rule"
NAME = "my_rule"
DESCRIPTION = "Keep the old ema_grade scores; blend each checked item's fresh results into its score."
# DRAW_KEY = "recal"   # random cells come from the same seeded draws as recal_k (the default)


def rule(bank, candidates, swap, checks):
    u = bank.mix_score["ema_grade"].copy()            # the old scores, in [0, 1]
    if checks.budget > 0:
        hits = np.zeros(bank.n)
        tries = np.zeros(bank.n)
        for a in checks.request(random=checks.budget):  # k cells drawn at random
            hits[a.item_index] += a.result
            tries[a.item_index] += 1
        u = (2.0 * u + hits) / (2.0 + tries)           # the old score counts as two checks
    return {"u": u, "p": u}
