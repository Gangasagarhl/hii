# Scale confound check: reader ranks items exactly like the owner (rho = 1), but its success
# depends less on which item is shown (compressed spread). theta from msr.metrics.theta_cell.
import sys, numpy as np
sys.path.insert(0, "<project>")
from msr.metrics import theta_cell
rng = np.random.default_rng(0)
E, C, Rr = 20000, 4, 2
task = rng.normal(0, 1, (E, 1)); item = rng.normal(0, 0.8, (E, C))
mu_s = 1/(1+np.exp(-(task + item)))
x = item + rng.normal(0, 0.5, (E, C))          # score sees the owner's item effect only
for c in [1.0, 0.75, 0.5, 0.25]:
    # reader: same task level, same ORDER of items, item differences shrunk by c (on the prob scale)
    mbar = mu_s.mean(axis=1, keepdims=True)
    mu_t = np.clip(mbar + c*(mu_s - mbar), 0, 1)
    yh = rng.binomial(1, mu_s[..., None].repeat(Rr, -1)).astype(float)
    yt = rng.binomial(1, mu_t[..., None].repeat(Rr, -1)).astype(float)
    out = theta_cell(x, yh, yt)
    # rank agreement of true usefulness within task (Spearman over items, averaged)
    print(f"spread ratio c={c:4.2f}: theta={out['theta']:.3f}  R={out['R']:.3f}  (true within-task item order identical)")
