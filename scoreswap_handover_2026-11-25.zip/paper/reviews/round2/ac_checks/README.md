# Area-chair audit checks (round 2)

- `scale_check.py`: shows that theta (msr.metrics.theta_cell) falls with the reader's item-usefulness spread
  even when the reader's within-task order of items is identical to the owner's. Run from the project root:
  `.venv/bin/python paper/reviews/round2/ac_checks/scale_check.py`. Output (seed 0, 20,000 tasks):
  spread ratio 1.00 -> theta 0.996; 0.75 -> 0.773; 0.50 -> 0.512; 0.25 -> 0.236.
- `maker_gate_rule.py`: a swap-day rule written from docs/BENCHMARK_GUIDE.md alone (keep within a maker, wipe
  across makers). `python -m scoreswap check` passed all four checks on release/sim in 8 s; `score --budget 0`
  wrote a per-pair summary in 10 s (output kept outside the project).
- `python -m scoreswap.parity --study sim --pack release/sim --only keep,wipe,fixed_0.5,recal_16,audit_16
  --families ema_grade`: ALL MATCH, largest per-task difference 8e-15.
