"""AC audit probe: keep old ema_grade scores within a maker, wipe across makers."""
import numpy as np
KIND = "swap_day_rule"
NAME = "maker_gate"
DESCRIPTION = "Keep old scores for same-maker swaps; wipe (0.5) across makers."
def rule(bank, candidates, swap, checks):
    u = bank.mix_score["ema_grade"].copy()
    if swap.owner_maker != swap.reader_maker:
        u = np.full(bank.n, 0.5)
    return {"u": u, "p": u}
