# Paper workspace: "ScoreSwap: Do Agent-Memory Usefulness Scores Still Rank Items After a Model Swap?" (ICML 2027 submission)

Title set in round 2 (23 Nov 2026); the old title echoed an existing paper's title (Goyal and Ray, arXiv 2609.05339). Collision check: `STYLE_CHECKS.md`, row 13.

Anonymous submission draft for ICML 2027, contribution type **Datasets, Evaluations, and Benchmarks**.
Benchmark name: **ScoreSwap**.

## Build

```
(cd .. && .venv/bin/python scripts/make_paper_assets.py --study sim)   # refresh assets/ (simulated study)
bash paper/build.sh          # Linux / macOS: makes main.pdf and dryrun.pdf
paper\build.bat              # Windows
```

Both scripts first run `tools/build_ledger.py`. It regenerates `reference_ledger.md` and `references.bib` from the saved
evidence and stops if any quoted sentence is missing. Then they compile two PDFs from the same sources:

| PDF | Source | Results section |
|---|---|---|
| `main.pdf` | `main.tex` (switch at its top: `\PaperMode` = `submission`) | red placeholders, "Results pending" boxes; no simulated number can appear |
| `dryrun.pdf` | `dryrun.tex` (sets `\PaperMode` = `dryrun`, `\StudyPrefix` = `Sim`, then reads `main.tex`) | the simulated study's numbers, figures and tables from `assets/`, and "DRY RUN - SIMULATED DATA - NOT RESULTS" on every page |

The exact compile commands the scripts run, from inside `paper/`:

```
TZ=UTC ../tools/tectonic_env/bin/tectonic -X compile --keep-logs main.tex
TZ=UTC ../tools/tectonic_env/bin/tectonic -X compile --keep-logs dryrun.tex
```

### How results enter the paper (and how to switch to the real study)

- Every result number in the text is `\Res{Name}`. In `dryrun` or `final` mode it prints the macro
  `\<StudyPrefix>Name` from `assets/numbers.tex`, which `scripts/make_paper_assets.py` writes (each macro carries its
  CSV file and row); a red "missing: ..." marker appears if that macro does not exist. In `submission` mode it prints a
  red placeholder with the name.
- Figures and tables are `\ResFig{width}{file}{what it shows}` and `\ResTable{file}{what it shows}`, read from `assets/`.
- **To fill the paper with the real study:** run `make_paper_assets.py --study study`, then set
  `\providecommand*{\PaperMode}{final}` and `\providecommand*{\StudyPrefix}{}` at the top of `main.tex` (the real study's
  macros have no prefix). Nothing else changes. The interpretation paragraph of the Discussion is written only then.
- The script writes `assets/` and owns it; never edit files there by hand.

## Style kit

| Item | Value |
|---|---|
| URL | https://media.icml.cc/Conferences/ICML2027/styles/icml2027.zip |
| Downloaded | 2026-11-23, 09:28 UTC |
| sha256 of the zip | `52384a2a4f32e562755e44ced55a58f857f8706425f2f04904190f613531801e` |
| sha256 of `example_paper.tex` | `209713159d3590e8fc871a9d629916a8efc21b9bdf90f56482b6060653f065e0` |
| sha256 of `icml2027.sty` | `3a61b88dc041e0f1db75cd8ff0a8e5396979cfb88cbde684333eb1a0ae585e30` |
| sha256 of `icml2027.bst` | `0ec3d5eb9b02efb7e0b44a32f3775882f42a743d0bdc618f34e6936309b98764` |
| Unpacked copy | `tools/downloads/icml2027/` |

`icml2027.sty`, `icml2027.bst`, `algorithm.sty`, `algorithmic.sty` and `fancyhdr.sty` are copied unchanged from the kit.
Their copyright headers name the style authors; leave them as they are. `main.tex` follows `example_paper.tex`: the same
preamble, anonymous submission mode, the same title block, and the closing sections in the kit's order (Accessibility,
Software and Data, Acknowledgements for the camera-ready version only, AI Use Statement, Impact Statement, References,
Appendix). Every addition is marked `ADDED` in `main.tex`.

## Files

| File | What it holds |
|---|---|
| `main.tex` | The paper, built from the kit's example |
| `macros.tex` | Notation (the symbols of `prediction/PREREGISTRATION.md`, plus V, gamma, rho, A_tau, theta, eta of the transfer decomposition and the check), the mode logic (`\Res`, `\ResFig`, `\ResTable`, the watermark) and red markers (`\TODO{}`, `\refcheck{}`, `\placeholder{}`) |
| `dryrun.tex` | Sets the switch to `dryrun` and reads `main.tex` |
| `assets/` | Written by `scripts/make_paper_assets.py`: `numbers.tex` (one macro per number, prefix `Sim` for the simulated study), figures and tables |
| `sections/*.tex` | One file per section; `A*` files are the appendix |
| `references.bib` | Generated. Only VERIFIED and ABSTRACT-ONLY ledger entries |
| `sections/06_agent_leg.tex` | The agent leg (MemRL's released code on LifelongAgentBench OS tasks): design, results pending (round 2) |
| `sections/A14_rule_interface.tex` | The rule interface and the two leaderboards for outside users (round 2; command names TBD) |
| `reference_ledger.md` | Generated. Every work the paper may cite: page opened, date, verbatim quote, status (VERIFIED, ABSTRACT-ONLY, NOT-FOUND, or NOT-CITED: opened and logged, deliberately not cited, with the reason in `why_not`) |
| `STYLE_CHECKS.md` | The ICML 2027 rules that apply to this PDF, pass or fail for the current draft |
| `figures/` | Empty until the results exist |

## Rules for editing

- **Citations:** never type a reference into `references.bib`. Add it to the spec in `tools/build_ledger.py`, save the
  record you opened under `tools/ledger_evidence/`, and re-run. The script checks the quote and writes both files.
  A reference that cannot be opened goes in as NOT-FOUND. The text then uses `\refcheck{...}`, which prints a red marker.
- **Numbers:** results enter only through `\Res{}` from `assets/numbers.tex`. Text around them must stay true for any
  outcome: decisions are quoted from the analysis output (for example `\Res{PCOneCrossDecision}`), never written by hand.
- **Anonymity:** no author names, affiliations, emails, institution URLs or local paths in any file here. The author
  block uses placeholders; the style file replaces them in submission mode.
- **Pending sentences:** a sentence that waits for a worker's final wording carries the comment `% PENDING-STATS`;
  find them with `grep -rn PENDING-STATS sections/` (none left on 24 Nov 2026).
- **Family T and the forecast controls (24 Nov 2026):** `scripts/make_paper_assets.py` writes the nine family-T
  members (`\SimFamT{Spec,Eq,Diff}<group or score family>{Value,Lo,Hi,P,PHolm,Decision}`) and `table_family_t.tex`, and
  the forecast's F1 control models (`same_gap`, `ec_same_gap`, their difference), printed as "not fitted" when the
  study is too small to fit them.
- **Assets in use (24 Nov 2026):** Figure 1 is `fig1_theta_grid`, Figure 2 `fig_decomp_predicted_vs_measured`, the forest
  plot `fig_forest_theta`, and `table_stakes` sits in the appendix. Generated files no longer included anywhere:
  `fig1_retained_validity_grid.*`, `fig_law_predicted_vs_measured.*`, `fig_forest_drop.*` (left in place; the asset
  script owns `assets/`). `scripts/make_paper_assets.py` writes `CheckBoundKeepTasks` and `CheckBoundDropTasks` (the
  information lower bound at the study's own signal, power 0.8) for the abstract.
- **Before submission:** every red marker in the PDF must be gone. Check with
  `pdftotext main.pdf - | grep -E "TODO|to verify|pending|⟨"`.

## Submission checklist (authors' tasks, not text for the PDF)

- **Conflicts of interest:** disclose on the submission form any financial or other substantive conflict that could
  reasonably be seen to influence the submission (ICML Peer Review Ethics). The paper evaluates models from six makers;
  if an author works for one of them, this must be disclosed (and again at camera-ready).
- **Code in the supplement:** remove licence files and author names; an anonymous branch frozen at the deadline,
  its link in a text file inside the zip.
- **Held-out test half:** never in the supplement (the supplement becomes public on acceptance); only its sha256.
- **Pre-registration:** frozen and deposited before the first paid run; cited only through an anonymous view-only link.
- **AI Disclosure Statement:** name each assistant and version; keep only true statements.
- **Strip LaTeX comments** before any source upload.
- **Markers:** no `TODO`, `WAIT-STATS`, `WAIT-THEORY`, `WAIT-LEG` or `WAIT-SCORER` may remain
  (`grep -rn "WAIT-\|TODO" sections/`).
