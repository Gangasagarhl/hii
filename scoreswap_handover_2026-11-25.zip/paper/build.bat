@echo off
REM Compile main.tex to main.pdf with Tectonic on Windows (no admin rights needed).
REM Engine lookup order: %TECTONIC%, then ..\tools\tectonic.exe, then tectonic on PATH.
REM Get tectonic.exe from https://github.com/tectonic-typesetting/tectonic/releases (x86_64-pc-windows-msvc zip)
REM and unzip it into ..\tools\ . The first run downloads the TeX support files (network needed once).
setlocal
cd /d "%~dp0"
set "TZ=UTC"
set "TEC=%TECTONIC%"
if "%TEC%"=="" if exist "..\tools\tectonic.exe" set "TEC=..\tools\tectonic.exe"
if "%TEC%"=="" set "TEC=tectonic"
where python >nul 2>nul && python -I ..\tools\build_ledger.py
if errorlevel 1 (
  echo build_ledger.py failed: a quoted sentence is missing from the saved evidence, or Python is not found.
  exit /b 1
)
"%TEC%" -X compile --keep-logs main.tex
if errorlevel 1 exit /b 1
"%TEC%" -X compile --keep-logs dryrun.tex
if errorlevel 1 exit /b 1
echo Wrote %CD%\main.pdf and %CD%\dryrun.pdf
endlocal
