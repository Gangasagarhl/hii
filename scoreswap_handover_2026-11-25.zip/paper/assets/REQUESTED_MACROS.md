# Macros and assets requested by the paper (revision 2, phases 1, 2a, 2b and 2c; 24 Nov 2026)

Written by the paper worker. Status after phase 2b: every macro and table below has been written by
`scripts/make_paper_assets.py` (0 print "missing" in the dry run) and every marker is cleared (phase 2c: the three `% WAIT-STATS-FINAL` lines now use the unprefixed
`\Method...` macros through `\MethodRes{...}`, which `macros.tex` reads in every mode, the submission included). The tables
below are kept as the record of what each name holds (prefix `\Sim` for the simulated study, none for the real one).
Group suffixes follow the existing convention: `Upgrade`, `Downgrade`, `Cross` (and `AllSwaps`, `SameMaker`, `Home`).

## Measures (decision D2), Section 5 (Q1)

| macro | holds | used in |
|---|---|---|
| `OrderUpgrade`, `OrderCross` (also `Downgrade`, with `Lo`/`Hi`) | retained order = theta x sqrt(S_owner / S_reader), pooled per group; text "not identifiable" when the reader's spread cannot be told from zero | 05_q1_order |
| `StakesRatioUpgrade`, `StakesRatioCross` (also `Downgrade`, `Lo`/`Hi`) | stakes ratio = sqrt(S_reader / S_owner) per group | 05_q1_order |
| `ThetaUpgradeDecision`, `ThetaDowngradeDecision`, `ThetaCrossDecision` | the registered PC1 decision word per group, after the revision (positive home signal required; "material drop" only with its own test) | 05_q1_order |
| `ThetaUpgradePILo`, `ThetaUpgradePIHi`, `ThetaCrossPILo`, `ThetaCrossPIHi` (and `Downgrade`) | 95% prediction interval of theta for a new pair of that kind, from the between-pair spread | 05_q1_order |
| `MakerTermEst`, `MakerTermP` | maker term in the regression of theta on same-maker flag, capability gap and error consistency (R5 W9) | 05_q1_order |

## Stakes (Q2), Section 6

| macro or file | holds | used in |
|---|---|---|
| `table_stakes_body.tex` | body table: keep - wipe, keep - shuffled, relearn - keep, per kind of swap (3 groups), at home, after the swap, after minus home, two-way 95% CI | 05b_q2_stakes (Table 2) |
| `MarginPointsAllSwaps` | what theta = 0.75 means in success points at home: 0.25 x (keep - random choice among candidates) at home, pooled | 05b_q2_stakes |

## Rules and costs (Q3), Section 7 and Appendix F

| macro | holds | used in |
|---|---|---|
| `ArmReanswerMinusKeepCross` | first-shown success, reanswer minus keep, cross-maker swaps | 05c_q3_operator |
| `ArmJudgeMinusKeepCross` | first-shown success, judge minus keep, cross-maker | 05c_q3_operator |
| `ArmRelearnMinusKeepCross` | first-shown success, relearn minus keep, cross-maker | 05c_q3_operator |
| `ArmBestCheckMinusKeepCross` | first-shown success, the best k = 64 rule minus keep, cross-maker (name the rule in MACROS.md) | 05c_q3_operator |
| `PCThreeCrossNoLevelEst`, `PCFourCrossNoLevelEst` | PC3 / PC4 swap-minus-home contrasts with keep given no level information, cross-maker | A13 |
| Dollars per rule (optional) | if the cost table should carry USD, a `table_costs_rules.tex`; today the body table is hand-written in calls per bank from the design | 05c_q3_operator |

## The keep-or-drop decision (phase 2a, theory hand-over sections 1 and 7), Sections 1, 7 and Appendix

| macro | holds (source, as the theory hand-over names it) | used in |
|---|---|---|
| `CheckMarginZeroFirstShownChecks` | median checks of the break-even test, decision (first-shown) form: `sequential_margin0.csv` world=study, version=first_shown, part=needed, theta=1, col checks_median (practice: 281) | 01_introduction, 05c_q3_operator, A15 |
| `CheckMarginZeroFirstShownBoundChecks` | the information bound for that observation scheme: same row, col bound_checks (practice: 100) | 05c_q3_operator, A15 |
| `CheckMarginZeroRankingChecks` | median checks of the break-even test, ranking form: version=ranking, col checks_median (practice: 364) | A15 |
| `CheckMarginZeroRankingBoundChecks` | the bound for whole random tasks at margin 0: version=ranking, col bound_checks (practice: 69; plug-in 65 [49, 91]) | A15 |
| `CheckBoundKeepTasksLo`, `CheckBoundKeepTasksHi` | 95% task-bootstrap interval of `CheckBoundKeepTasks`: `sequential_bound_curve.csv` curve=margin, theta_0=0.75 row of the study plug-in (else `sequential_bound.csv` setting=table_plugin, decision=keep, power=0.8, the bootstrap interval columns of bound_tasks_chi2) (practice: 198, 366) | 01_introduction, 05c_q3_operator, A15 |
| `CheckPairedMedianTasks` | median tasks of the paired 0.75 test when nothing is lost: `sequential_curve.csv` theta=1, col tasks_q50 (practice: 731) | 05c_q3_operator, A15 |
| optional figure `fig_sequential_bound_curve.pdf` | bound in checks against the margin 0 to 0.9 at the study's signal with its interval; second panel against Abar_home at margins 0 and 0.75 (`sequential_bound_curve.csv`); not referenced yet | (A15, if drawn) |

`CheckBetterMedianChecks` (phase 1) is withdrawn: use `CheckMarginZeroFirstShownChecks`. `CheckThetaOneMedianTasks` is no
longer used in the text (replaced by `CheckPairedMedianTasks`); keep it if other files use it.

## Construct checks and free baselines (phase 2a, decision D7), Sections 5, 7 and Appendix "Construct Checks"

Names as `msr/construct.py` `macro_rows` writes them into `construct_macros.csv` (prefix `\SimConstr...` in the
practice study, `\Constr...` in the real one; level suffix `All` = pooled over streams). On 24 Nov the file was not
on disk under `runs/sim/analysis/` (only `CONSTRUCT.md`); the statistics worker is loading it.

| macro | holds | used in |
|---|---|---|
| `ConstrRefThetaCrossAll`, `ConstrRefThetaAllSwapsAll` | theta of the stored-answer-correct reference | 05_q1_order, A16 |
| `ConstrCorrectShareAllOls`, `...OlsLo`, `...OlsHi` | share of the headline score's home signal carried by the grade (1 - V_resid / V), 95% interval | 05_q1_order |
| `ConstrThetaResOlsCrossAll`, `ConstrThetaResOlsAllSwapsAll` | theta of the residualised headline score | 05_q1_order, A16 |
| `ConstrThetaCcCrossAll`, `ConstrThetaIiCrossAll`, `ConstrThetaMixedCrossAll` | theta within correct-correct, wrong-wrong and mixed pairs | 05_q1_order |
| `ConstrThetaAllAllSwapsAll` | theta of the headline score, all swaps (construct pooling) | A16 |
| `ConstrOverlapSharePairsMatchSwap{CrossAll,AllSwapsAll}`, `ConstrOverlapSharePairsNeardupSwap{CrossAll,AllSwapsAll}` | share of informative pairs with an answer-matching / near-duplicate candidate | 05_q1_order, A16 |
| `ConstrOverlapThetaExclEither{CrossAll,AllSwapsAll}` | theta without pairs that hold either kind of candidate | 05_q1_order, A16 |
| `ConstrBase{Reanswer,Correct,Ips,Dr}MinusKeepAll` | first-shown success of each free baseline minus keep, all swaps | 05c_q3_operator, A16 |
| `table_correctness.tex` (exists, 07:46) | used as written: reference and headline Cw home / after, the grade's share, theta cc / ii / mixed, theta residualised | A16 (Table, `table*`) |
| `table_strata.tex` (NEW request) | per kind of swap and all swaps: share of informative pairs with an answer-matching / near-duplicate candidate, theta without either (`construct_overlap.csv`), and theta by visit stratum 0 / 1-2 / 3-5 / 6+ (`construct_visits_theta.csv`), two-way 95% CI; optionally the rank-residual theta | A16 (Table, `table*`) |
| `table_baselines.tex` (exists, 07:46) | used as written | A16 (Table, `table*`) |
| `table_cost_one.tex` (exists, 07:46) | used as written in Appendix "Cost Table". Missing rows: the new paid stages (judge 250 new-model calls, owner's write-time rating 250 old-model calls, relearn 1,500, re-exploration), and for the uncapped paired test the old-model calls at its stopping time (theory hand-over section 8: about 730 stored tasks, about 6,650 old-model calls at the practice signal) rather than the 800 of the calibration pool | A5 (Table, `table*`) |

Phase-1 names `ThetaCorrectCross`, `CorrectShareHome`, `ThetaResidCross` are withdrawn (replaced by the names above).

## Agent leg, Section 8 and Appendix F

| macro or file | holds | used in |
|---|---|---|
| `table_agent_leg.tex` | per directed swap run (both directions of the same-maker pairs, four cross-maker swaps): keep and shuffle_visit (8 repeats, fresh permutation per repeat) for the old model at home (the gate, p_H) and the new model after the swap (S, p_S), the registered reading (uninformative / survives / lost / undetermined), and the secondary references wipe, own, none, relearn, with 95% task-bootstrap intervals | A13 |

`LegMDE` (phase 1) is withdrawn: the minimum detectable effects are registered design numbers
(`legs/memrl/measured/power_family_L.json`) and are printed as plain numbers. The results sentence of Section 8 stays a
TODO until the leg has run.

## Existing names the text keeps using (please keep them, or tell me the new names)

`ThetaUpgrade/Downgrade/Cross` with `Lo`/`Hi` and `Self`; `PCTwo{Group}Est/Decision`; `StakesKeepWipe{Group}Home`;
`CheckThetaOneMedianTasks`; `CheckBoundKeepTasks`; `CheckAuditSixFourFalseKeep`; `NPrimaryTests` (12: PC1-drop, PC1-MD,
PC1-NI and PC2 in each of the three swap groups, one Holm family); `TotalCalls`, `TotalUSD` (the cost line of the setup); `PFourResult`; `ShuffledCwAllSwaps`;
the `Decomp*`, `FamT*` and `Forecast*` names used in the appendix.

## Phase 2c: method-validation numbers (done)

The limitation sentence and the appendix paragraph "Measured size and coverage" use, through `\MethodRes{Name}`:
`ItemShareIndepHi`, `WorstSizeIndep`, `CoverageThetaOursLo/Hi`, `CoverageThetaIndepLo/Hi`, `ItemShareOursHi`,
`CoverageOrderOursLo/Hi`, `CoverageStakesOursLo/Hi`, `SizeOursLo/Hi`, `CoverageOrderIndepLo/Hi`,
`CoverageStakesIndepLo/Hi` (all 17 written by `method_macros` in `scripts/make_paper_assets.py`). The visit thirds use
`ThetaVisitsThird{Low,Mid,High}AllSwaps`; the strata table (`table_strata.tex`, two tabulars) is set with
`\ResTableStack` so the two parts stand one above the other.
