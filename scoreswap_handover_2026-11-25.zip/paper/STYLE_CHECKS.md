# ICML 2027 style checks for `main.pdf`

Checked on 2026-11-23 against the official pages, saved as text in `tools/icml_pages/` on the same day:
Call for Papers, Author Instructions, Contribution Types, Use of Generative AI by Authors, Peer Review Ethics,
LLM Policy, Reviewer Instructions, Dates, Reciprocal Reviewing; and against the style kit (`icml2027.sty`,
`example_paper.tex`, sha256 in `README.md`). ICML said it would announce process changes in late November:
re-read these pages about 1 December and again before 14 January.

Draft state (revision 2, phase 2c, 24 Nov 2026: the scorer and the statistics worker's final pass are integrated; no `% WAIT-...` marker is left; the submission prints no outcome wording and no practice-study number, only the unprefixed `\Method...` method-validation numbers, which `macros.tex` reads in every mode). `main.pdf` (submission layout): 37 pages, 328 KB; the body ends in the right column of page 8. `dryrun.pdf` (simulated, watermarked, small practice study `sim`; one line in `dryrun.tex`, `\PracticeStudy`, switches it to the full-size rehearsal): 41 pages, 643 KB; the body ends at the bottom of page 8; 0 macros and 0 tables print "missing". A fresh reviewer's guide is `reviews/round3/README.md`.

| # | Rule (source) | Applies to | Current draft | Status |
|---|---|---|---|---|
| 1 | Main body at most 8 pages (Author Instructions; CFP) | PDF | Body (Introduction to Limitations) ends on page 8 in both PDFs with the stakes table, the cost table and the primary-test table in. Phase 2b moved the decision table (a TODO until results) to the secondary-results appendix and cut text to make room; there is no slack left in the dry run, so any new body content must replace text | PASS (no slack) |
| 2 | Anonymous submission: no author information; the style file in submission mode (Author Instructions; kit) | PDF and sources | `\usepackage{icml2027}` (submission mode). Author block holds placeholders only; the PDF prints "Anonymous Authors". No acknowledgements. No self-citation. No URL that reveals the authors. PDF metadata author is "Anonymous Authors"; the creation date is written in UTC (`TZ=UTC` in the build scripts). The kit's own `.sty` and `.bst` files carry their original authors' emails in comment headers; they are not printed | PASS |
| 3 | File size: kit says "the total file size may not exceed 10MB"; Author Instructions say "The submission PDF has a maximum size of 50MB" | PDF | `main.pdf` 284 KB, `dryrun.pdf` 588 KB | PASS (under both) |
| 4 | AI Disclosure Statement at the end of the paper (GenAI policy) | PDF | Heading renamed "AI Disclosure Statement" (the policy's name). True statements only; one TODO for the human authors to name each assistant and version. The models used as part of the method are described in the body (Sec. 4) as well | FAIL until the human authors complete it |
| 5 | Impact Statement, unnumbered, before the References (kit) | PDF | Present, a considered paragraph | PASS |
| 6 | Exactly one Contribution Type, selected at submission (Contribution Types page) | OpenReview form | Chosen: "Datasets, Evaluations, and Benchmarks". The page says such a paper "does not need to introduce a new learning algorithm" | PASS (select it on the form) |
| 7 | Abstract: one paragraph, "ideally 4-6 sentences" | PDF and form | 5 sentences, about 190 words, at most one number per sentence; scoped to exemplar memory with the agent leg as the bridge | PASS on form; FAIL until results replace the placeholders |
| 8 | No "placeholder" abstract at the 14 January abstract deadline; "submissions with 'placeholder' abstracts that are substantially rewritten for the full submission risk being removed" (CFP) | Form | Results will not exist before the runs; the abstract filed on 14 Jan must already carry the real headline | Open (timing) |
| 9 | Hallucinated references are a desk-rejection ground (Peer Review Ethics) | PDF | Ledger: 145 entries: 120 VERIFIED, 24 ABSTRACT-ONLY, 0 NOT-FOUND, 1 NOT-CITED; 144 bib entries; 117 distinct keys cited; 0 undefined. Phase 2b added DerSimonian and Laird (1986) and Higgins, Thompson and Spiegelhalter (2009) for the per-group spread and prediction interval. Phase 2a added Berger (1982) for the intersection-union principle (ABSTRACT-ONLY: Crossref metadata and the abstract from two index records; publisher page 403). Revision 2 verified and placed 15 more works (SkillEval, LLM-specific utility, Peng et al., MDR, Zhang-Feng-Tan, CompSkill, UpgradeBench, When the Judge Changes, Frozen Memory Is Not Enough, Generative Agents, MemQ, SkillRevise, Wang et al. 2023, Bansal et al. 2019 [ABSTRACT-ONLY], backward-compatible training), cited Anchor Points, tinyBenchmarks, PromptBridge and warm-start bandits, fixed `kim2026mtl` (EMNLP 2026) and re-checked MemRL (NeurIPS 2026) and EvoKernel (ICML 2026, PMLR author list) against the proceedings | PASS on form; humans must still read every source |
| 10 | 10-point Times, Type-1 fonts (kit); "there is no Type 3 font check" this year (Author Instructions) | PDF | Times (NimbusRomNo9L) via `\usepackage[T1]{fontenc}`; all 19 fonts embedded as Type 1C. No Type 3 fonts | PASS |
| 11 | Do not alter the style template or compress spacing (kit) | Sources | Kit files unchanged; no spacing changes. Wide tables are scaled with `\resizebox` | PASS |
| 12 | Figure captions below figures, table captions above tables (kit) | PDF | Followed in all tables and figure stubs | PASS |
| 13 | Title with content words capitalized | PDF | "ScoreSwap: Are Learned Memory Scores Worth Keeping After a Model Swap?" (manager's decision D1); no collision found in the 23 Nov check | PASS |
| 14 | References with page numbers where possible; full author lists; protect capitals (kit) | Bib | Pages given wherever the opened record gives them (all journal and proceedings entries except HDSR, which has none; Nature Communications uses its article number); arXiv entries have none. Titles are wrapped in braces | PASS |
| 15 | Single PDF with appendix after the references (kit; CFP) | PDF | Appendix A-G after the references, one column | PASS |
| 16 | Methods using generative AI described in the main paper (GenAI policy) | PDF | Models, routes, settings, availability and what changed in each same-maker pair in Sec. 4 (Table 1); the judge and write-time rating baselines in Sec. 3.3; verbatim prompts with sha256 in App. J | PASS (smoke-test values pending) |
| 17 | Code anonymised, licence files and author names removed, frozen branch, link in a text file (Author Instructions) | Supplementary | In the release checklist (item 12) and the README submission checklist; the held-out test half never goes into the supplement (item 7) | Open (packaging in January) |
| 18 | No unresolved TODO markers | PDF | 13 red TODO markers in `main.pdf`, 4 on pages 1-8 (two captions after results, the anonymous link, the AI tool names; the decision table moved to the appendix); in the appendix: funding and conflicts, row counts, collection window, removed tasks, model-output licences, the registry link, the pilot gate, the AI tool names | FAIL (expected) |
| 19 | No simulated number in the submission PDF | PDF | `main.pdf` is built with `\PaperMode` = `submission`: every result is a red placeholder and every figure or table a "Results pending" box; the simulated paragraph of the proofs appendix is shown only in the dry run. Check: `pdftotext main.pdf - \| grep -c "SIMULATED"` gives 0 | PASS |
| 20 | The dry run cannot be mistaken for results | PDF | `dryrun.pdf` carries "DRY RUN - SIMULATED DATA - NOT RESULTS" across and at the top of every page, a boxed note at the head of the Results, and the assets' own "SIMULATED DATA" banners | PASS (never submit `dryrun.pdf`) |
| 21 | Figure 1 on page 2 | PDF | `fig1_theta_grid` at the top of page 2; the probe-table schematic (Fig. 2) and the per-pair forest plot are in the body | PASS |
| 22 | Wording rules | Sources | No "law" outside labels, "mediation", "oracle", "noise floor", "12 tests", "TBD", "calibrated", "dated pre-registration", "has not been measured" unscoped, "per team notes", "parameter-free", "accounts for", "about twice the bound", a 4-SE rule, "a few dozen checks", "any rule needs" (the bound is always scoped: "any rule that checks whole tasks drawn at random"), "memory survives", "Q-learning"; "family" only for score families and test families; every coined word defined at first use | PASS |
| 23 | Process notes and paths in LaTeX comments (area-chair screen) | Sources | No worker names, user names or local paths in any `.tex` file. Comments still name repository files (e.g. the pre-registration, the leg's README); strip all comments before any source upload | PASS for names; strip comments before upload |
| 24 | Registered families reported in full (synchronising pass) | PDF | Family T: the nine Holm members in `table_family_t` (App. Secondary results), with one main-text sentence; the forecast's F1 test and its control models in the forecast appendix ("not fitted" in the 4-model practice study). The `home signal too weak' flag labels theta only; neither primary test is gated | PASS |

## Rule conflicts found on the official pages

1. **Name of the AI statement.** The kit's example heading is "AI Use Statement" ("typically a few sentences, and must
   not exceed one page"). The policy page says "All submissions must include an AI Disclosure Statement at the end of
   the paper, before or after the references", and asks authors to "describe in detail". The draft uses the kit's
   heading and order, under one page, with the detail the policy asks for. If ICML's late-November update names one
   form, follow it.
2. **File size.** The kit says the total file size "may not exceed 10MB". The Author Instructions say "The submission PDF
   has a maximum size of 50MB" (camera-ready 20MB). Staying under 10 MB satisfies both.
3. **Camera-ready notice in the kit.** `icml2027.sty` prints "43rd International Conference on Machine Learning,
   Seoul, South Korea. PMLR 306, 2027" in `[accepted]` mode. The CFP says "The 44th International Conference on Machine
   Learning (ICML 2027) will be held in Rio de Janeiro, Brazil". This affects only the camera-ready version; expect a
   corrected kit.
4. **Order of the closing statements.** The team's plan (report, "Closing sections") puts the Impact Statement first
   and the AI statement last. The kit puts the AI Use Statement before the Impact Statement. The draft follows the kit,
   as the brief asked; the policy allows the AI statement "before or after the references".
5. **Do the Accessibility and Software and Data sections count toward the 8 pages?** The CFP lists only "references,
   the impact statement, and appendices" as unlimited, and the policy exempts the AI statement. The kit places
   Accessibility and Software and Data among the closing sections, but no page says whether they count. In the draft both
   sit after the Limitations section on pages 8-9. To be safe, keep the body plus these two short sections within 8 pages,
   or ask the program chairs.


1. **Name of the AI statement.** The kit's example heading is "AI Use Statement" ("typically a few sentences, and must
   not exceed one page"). The policy page says "All submissions must include an AI Disclosure Statement at the end of
   the paper, before or after the references", and asks authors to "describe in detail". The draft uses the kit's
   heading and order, under one page, with the detail the policy asks for. If ICML's late-November update names one
   form, follow it.
2. **File size.** The kit says the total file size "may not exceed 10MB". The Author Instructions say "The submission PDF
   has a maximum size of 50MB" (camera-ready 20MB). Staying under 10 MB satisfies both.
3. **Camera-ready notice in the kit.** `icml2027.sty` prints "43rd International Conference on Machine Learning,
   Seoul, South Korea. PMLR 306, 2027" in `[accepted]` mode. The CFP says "The 44th International Conference on Machine
   Learning (ICML 2027) will be held in Rio de Janeiro, Brazil". This affects only the camera-ready version; expect a
   corrected kit.
4. **Order of the closing statements.** The team's plan (report, "Closing sections") puts the Impact Statement first
   and the AI statement last. The kit puts the AI Use Statement before the Impact Statement. The draft follows the kit,
   as the brief asked; the policy allows the AI statement "before or after the references".
5. **Do the Accessibility and Software and Data sections count toward the 8 pages?** The CFP lists only "references,
   the impact statement, and appendices" as unlimited, and the policy exempts the AI statement. The kit places
   Accessibility and Software and Data among the closing sections, but no page says whether they count. In the draft both
   sit after the Limitations section on pages 8-9. To be safe, keep the body plus these two short sections within 8 pages,
   or ask the program chairs.
