#!/usr/bin/env bash
# Compile main.tex to main.pdf with the local Tectonic engine (no admin rights needed).
# Engine lookup order: $TECTONIC, then ../tools/tectonic_env/bin/tectonic, then tectonic on PATH.
# The first run downloads the TeX support files into Tectonic's cache (network needed once).
set -euo pipefail
cd "$(dirname "$0")"
export TZ=UTC   # keep the PDF creation date in UTC, so the file does not reveal a local time zone
TEC="${TECTONIC:-}"
if [ -z "$TEC" ] && [ -x ../tools/tectonic_env/bin/tectonic ]; then TEC=../tools/tectonic_env/bin/tectonic; fi
if [ -z "$TEC" ]; then TEC="$(command -v tectonic || true)"; fi
if [ -z "$TEC" ]; then echo "tectonic not found: see README.md" >&2; exit 1; fi
# Refresh the simulated assets first if needed: (cd .. && .venv/bin/python scripts/make_paper_assets.py --study sim)
python3 -I ../tools/build_ledger.py   # regenerate reference_ledger.md and references.bib; stops if a quote is missing
"$TEC" -X compile --keep-logs main.tex      # submission layout: red placeholders, no simulated number
"$TEC" -X compile --keep-logs dryrun.tex    # same paper with the simulated study filled in and a watermark
echo "Wrote $(pwd)/main.pdf and $(pwd)/dryrun.pdf"
