"""Intervals for every scored number, as msr.metrics defines them (pre-registration Part 4, revision 2).

- Primary ("two-way"): msr.metrics.robust_variance, the two-way delete-one-cluster jackknife: two
  values are dependent when they share a task id (within a stream, pooled over the orders) OR share
  at least one candidate item, items coded by IDENTITY within (owner, stream), so a tip that recurs
  in several stream orders is one cluster. Each (cell, stream) mean is one component (the leverage
  term of the jackknife). For one statistic the variance is max(two-way, task-only), as
  msr.metrics.contrast_variance gives it.
- theta (and retained agreement and stakes): msr.metrics.theta_tests, the registered tests with the
  home-sign test; theta's interval is the union of the two-way and the task-only Fieller sets. The
  "home signal" flag is msr.metrics.home_signal_flag (the owner's signal on its CALIBRATION tasks),
  the one rule of the whole project; retained agreement is "not estimated" when the reader's spread on the
  calibration tasks fails msr.metrics' flag.
- Secondary ("task-only"): the task-id cluster bootstrap (task ids resampled per stream, all their
  appearances in every order together; msr.metrics.task_cluster_counts, 10,000 draws, seed 0), the
  SAME draws for every rule, so a difference of two rules is paired. The paper's tables of rule
  values (arms_groups.csv) use this one; on all evaluation tasks it gives them digit for digit.

A statistic is a plain mean of per-(cell, stream) values (Part 2.12), each the mean over the valid
evaluation tasks of the stream (all its orders pooled) of a per-task array; the tasks are those of
one board: 'dev' (the public owners' banks), 'test' (the private owners' banks) or 'all' (every bank:
the paper's tables). Every board scores every evaluation task of its banks.
"""
from __future__ import annotations

import math

import numpy as np

from msr import metrics as M

NAN = float("nan")
SPLIT_SETS = {"dev": ("dev",), "test": ("test",), "all": ("dev", "test")}
SPLIT_LABEL = {"dev": "development board (public owners' banks)", "test": "ranked board (private owners' banks, held out)",
               "all": "every bank (the paper's tables)"}


def preaggregate(P: np.ndarray, T: np.ndarray, I: np.ndarray) -> tuple:
    """Sum the influence rows that share a task and a candidate set. msr.metrics' two-way forms
    begin by doing exactly this (_aggregate); doing it once here, over all columns together, gives
    the same sums and lets every later call work on far fewer rows."""
    key = np.concatenate([T[:, None], np.sort(I, axis=1)], axis=1)
    uk, inv = np.unique(key, axis=0, return_inverse=True)
    inv = inv.ravel()
    P = np.atleast_2d(P.T).T if P.ndim == 1 else P
    out = np.zeros((len(uk), P.shape[1]))
    for j in range(P.shape[1]):
        out[:, j] = np.bincount(inv, weights=P[:, j], minlength=len(uk))
    return out, uk[:, 0].copy(), uk[:, 1:].copy()


class Clusters:
    """Task codes, candidate-item codes and bootstrap counts of the evaluation tasks of one split."""

    def __init__(self, pack, split: str = "dev", B: int | None = None):
        self.pack, self.split = pack, split
        owners = set(pack.board_owners(split))
        tmap: dict = {}
        imap: dict = {}
        self.tcode: dict = {}
        self.icode: dict = {}
        self.tasks: dict = {}
        for (stream, order) in pack.strata:
            ev = pack.eval_tasks(stream, order)
            self.tasks[(stream, order)] = ev
            self.tcode[(stream, order)] = np.array([tmap.setdefault(f"{stream}|{t}", len(tmap)) for t in ev],
                                                   dtype=np.int64)
            for owner in pack.models:
                if owner not in owners or not any(c[0] == owner for c in pack.all_cells):
                    continue
                cp = pack.candidates_payload(owner, stream, order)
                pos = {t: n for n, t in enumerate(cp["tasks"])}
                codes = np.full((len(ev), int(cp["C"])), -1, dtype=np.int64)
                for e, t in enumerate(ev):
                    for c, it in enumerate(cp["items"][pos[t]]):
                        if it:
                            # identity within (owner, stream): the same cluster in every order (revision 2)
                            codes[e, c] = imap.setdefault(f"{owner}|{stream}|{it}", len(imap))
                self.icode[(owner, stream, order)] = codes
        self.B = int(B if B is not None else pack.settings.get("analysis_bootstrap_draws", 10000))
        self.counts = M.task_cluster_counts(self.tasks, self.B, int(pack.settings.get("draw_seed", 0))) if self.B else {}
        self._boot: dict = {}            # (id(store), key, owner, reader, stream) -> (B,) draws of that cell's mean

    def cell_boot(self, store, key, o, r, s) -> np.ndarray:
        """Bootstrap draws of one cell's mean over a stream (its orders pooled), computed once."""
        ck = (id(store), key, o, r, s)
        hit = self._boot.get(ck)
        v = hit[1] if hit is not None and hit[0] is store else None
        if v is None:
            num = np.zeros(self.B)
            den = np.zeros(self.B)
            for d in self.orders_of(s):
                x = self._get(store, key, o, r, s, d)
                if x is None:
                    continue
                ok = np.isfinite(x)
                nd = self.counts[(s, d)] @ np.column_stack([np.where(ok, x, 0.0), ok.astype(np.float64)])
                num += nd[:, 0]
                den += nd[:, 1]
            with np.errstate(invalid="ignore", divide="ignore"):
                v = np.where(den > 0, num / np.where(den > 0, den, 1.0), NAN)
            self._boot[ck] = (store, v)          # the store is kept alive, so its id cannot be reused
        return v

    def orders_of(self, stream: str) -> list:
        return [o for (s, o) in self.pack.strata if s == stream]

    def _get(self, store, key, o, r, s, d):
        rec = store.get((o, r, s, d))
        if rec is None:
            return None
        v = rec.get(key)
        return None if v is None else np.asarray(v, dtype=np.float64)

    def _batch_boot(self, s: str, mats: list) -> np.ndarray:
        """(B, q) bootstrap draws of one cell's stream mean for q columns at once: one matrix product
        per order for all the columns (the orders of a stream are pooled before dividing), and the
        counts of valid tasks computed once per distinct pattern of missing values."""
        num = den = None
        for d, Mx in mats:
            if Mx.shape[0] == 0:
                continue
            W = self.counts[(s, d)]
            ok = np.isfinite(Mx)
            n_d = W @ np.where(ok, Mx, 0.0)
            pat, inv = np.unique(ok, axis=1, return_inverse=True)
            d_d = (W @ pat.astype(np.float64))[:, inv.ravel()]
            num = n_d if num is None else num + n_d
            den = d_d if den is None else den + d_d
        if num is None:
            return np.full((self.B, mats[0][1].shape[1] if mats else 0), NAN)
        with np.errstate(invalid="ignore", divide="ignore"):
            return np.where(den > 0, num / np.where(den > 0, den, 1.0), NAN)

    # ---- many linear statistics with the same components --------------------
    def linear_batch(self, columns: list, items: list) -> list:
        """For every column (store, key): the statistic sum_w w x mean(key of that cell, stream),
        with its two-way SE / interval / two-sided p, the task-only SE, and the task-only bootstrap
        interval. Returns one dict per column."""
        q = len(columns)
        pts = np.zeros(q)
        boot = np.zeros((self.B, q)) if self.B else None
        P, T, I, Cp = [], [], [], []
        missing = np.zeros(q, dtype=bool)
        for k_comp, (o, r, s, w) in enumerate(items):
            mats = []
            for d in self.orders_of(s):
                E = len(self.tasks[(s, d)])
                cols = []
                for j, (store, key) in enumerate(columns):
                    v = self._get(store, key, o, r, s, d)
                    if v is None or len(v) != E:
                        missing[j] = True
                        v = np.full(E, NAN)
                    cols.append(v)
                mats.append((d, np.column_stack(cols) if cols else np.zeros((E, 0))))
            n = sum(np.isfinite(Mx).sum(axis=0) for _d, Mx in mats)
            with np.errstate(invalid="ignore", divide="ignore"):
                mu = sum(np.nansum(Mx, axis=0) for _d, Mx in mats) / n
            missing |= (n == 0)
            pts += w * np.where(n > 0, mu, 0.0)
            for d, Mx in mats:
                with np.errstate(invalid="ignore", divide="ignore"):
                    P.append(w * (Mx - mu) / n)
                T.append(self.tcode[(s, d)])
                I.append(self.icode[(o, s, d)])
                Cp.append(np.full(len(Mx), k_comp, dtype=np.int64))
            if self.B and q:
                boot += w * self._batch_boot(s, mats)
        out = [{"estimate": NAN if missing[j] else float(pts[j]), "se": NAN, "lo": NAN, "hi": NAN, "p": NAN,
                "se_task": NAN, "lo_boot": NAN, "hi_boot": NAN} for j in range(q)]
        if not P:
            return out
        P = np.vstack(P)
        T = np.concatenate(T)
        I = np.vstack(I)
        Cp = np.concatenate(Cp)
        fin = np.isfinite(P)
        groups: dict = {}
        for j in range(q):
            if not missing[j]:
                groups.setdefault(fin[:, j].tobytes(), []).append(j)
        for _m, js in groups.items():
            rows = fin[:, js[0]]
            if not rows.any():
                continue
            res = M.robust_variance(P[np.ix_(rows, js)], T[rows], I[rows], Cp[rows])
            for a, j in enumerate(js):
                vt = float(res["V_task"][a, a])
                V = max(float(res["V_raw"][a, a]), vt)      # = msr.metrics.contrast_variance(res, e_a)
                se = math.sqrt(V) if V > 0 else NAN
                o = out[j]
                o["se"], o["se_task"] = se, (math.sqrt(vt) if vt > 0 else NAN)
                if math.isfinite(se):
                    o["lo"], o["hi"] = o["estimate"] - M.Z95 * se, o["estimate"] + M.Z95 * se
                    o["p"] = M.normal_p(o["estimate"], se)["p_two"]
        if self.B:
            for j in range(q):
                b = boot[:, j]
                b = b[np.isfinite(b)]
                if b.size > 1 and not missing[j]:
                    out[j]["lo_boot"], out[j]["hi_boot"] = (float(x) for x in np.percentile(b, [2.5, 97.5]))
        return out

    # ---- theta (with retained order and stakes) and Cw ------------------------
    def _comps_full(self, store, key, items, cells=None):
        """(point, psi, task codes, item codes, component ids) of sum_k w_k x mean of key in cell k over
        the valid tasks of its stream (orders pooled); None parts when a component has no valid task.
        `cells` replaces each item's (owner, reader) (the self-swap part reads the owner's home cell)."""
        point, P, T, I, C = 0.0, [], [], [], []
        for k, (o, r, s, w) in enumerate(items):
            if cells is not None:
                o, r = cells[k]
            vals = {}
            for d in self.orders_of(s):
                v = self._get(store, key, o, r, s, d)
                if v is not None:
                    vals[d] = v
            n = sum(int(np.isfinite(v).sum()) for v in vals.values())
            if n == 0:
                return NAN, None, None, None, None
            mu = sum(float(np.nansum(v)) for v in vals.values()) / n
            point += w * mu
            for d, v in vals.items():
                ok = np.isfinite(v)
                P.append(w * (v[ok] - mu) / n)
                T.append(self.tcode[(s, d)][ok])
                I.append(self.icode[(o, s, d)][ok])
                C.append(np.full(int(ok.sum()), k, dtype=np.int64))
        if not P:
            return NAN, None, None, None, None
        return point, np.concatenate(P), np.concatenate(T), np.vstack(I), np.concatenate(C)

    def _comps(self, store, key, items):
        return self._comps_full(store, key, items)[:4]

    def _cal_arrays(self, store, what: str, o: str, r: str, streams) -> list:
        out = []
        for s in sorted(streams):
            for d in self.orders_of(s):
                rec = store.get((o, r, s, d))
                cal = (rec or {}).get("_cal") or {}
                v = cal.get(what)
                if v is None:
                    return []
                out.append(np.asarray(v, dtype=float))
        return out

    def home_signal(self, store, items) -> tuple:
        """msr.metrics.home_signal_flag over the owners of the (cell, stream) items: each owner's signed
        validity on its CALIBRATION tasks (every order of the streams involved), weighted by how many
        of the items' cells it owns. Returns (z, status)."""
        per: dict = {}
        for (o, r, s, _w) in items:
            ent = per.setdefault(o, {"cells": set(), "streams": set()})
            ent["cells"].add((o, r))
            ent["streams"].add(s)
        vals, wts = [], []
        for o, ent in per.items():
            arr = self._cal_arrays(store, "V_cal", o, o, ent["streams"])
            if not arr:
                return NAN, M.THETA_CAL_UNDEFINED
            vals.append(np.concatenate(arr))
            wts.append(float(len(ent["cells"])))
        if not vals:
            return NAN, M.THETA_CAL_UNDEFINED
        z, status = M.home_signal_flag(vals, wts)
        return z, status

    def reader_spread_z(self, store, items):
        """z of the readers' spread on the CALIBRATION tasks of the items' cells (order's
        identifiability flag in msr.metrics.order_stakes_inference)."""
        per: dict = {}
        for (o, r, s, _w) in items:
            per.setdefault((o, r), set()).add(s)
        vals = []
        for (o, r), ss in per.items():
            arr = self._cal_arrays(store, "S_reader", o, r, ss)
            if not arr:
                return NAN
            vals.append(np.concatenate(arr))
        return M.calibration_z(vals, [1.0] * len(vals)) if vals else NAN

    def theta(self, store, swap_key: str, home_key: str, items: list, fresh: bool = True,
              spread: bool = True) -> dict:
        """theta = sum of mean V after the swap / sum of mean V at home over the items, with
        msr.metrics.theta_tests (the registered tests, each with the home-sign test; drop also beyond
        the self-swap reference; theta's Fieller set = union of the two-way and task-only sets),
        retained order and stakes (theta = order x stakes), the home-signal flag
        (msr.metrics.home_signal_flag) and the task-only bootstrap interval. The same construction as
        msr.analysis.TwoWay.theta."""
        out = {"estimate": NAN, "lo": NAN, "hi": NAN, "interval": "", "status": M.THETA_CAL_UNDEFINED,
               "z_cal": NAN, "status_same_tasks": "", "v_swap": NAN, "v_home": NAN, "p_drop": NAN, "p_ni": NAN,
               "p_md": NAN, "p_home": NAN, "lo_boot": NAN, "hi_boot": NAN, "order": NAN, "order_lo": NAN,
               "order_hi": NAN, "order_status": M.ORDER_UNIDENTIFIED, "stakes": NAN, "stakes_lo": NAN,
               "stakes_hi": NAN}
        out["z_cal"], out["status"] = self.home_signal(store, items)
        parts = {"swap": self._comps_full(store, swap_key, items), "home": self._comps_full(store, home_key, items)}
        if parts["swap"][1] is None or parts["home"][1] is None:
            return out
        if fresh and items and all(o != r for o, r, _s, _w in items):
            parts["fresh"] = self._comps_full(store, swap_key, items, cells=[(o, o) for o, _r, _s, _w in items])
        if spread:
            parts["so"] = self._comps_full(store, "S_owner", items)
            parts["sr"] = self._comps_full(store, "S_reader", items)
        parts = {k: g for k, g in parts.items() if g[1] is not None and math.isfinite(g[0])}
        if not ("so" in parts and "sr" in parts):
            parts.pop("so", None)
            parts.pop("sr", None)
        if "swap" not in parts or "home" not in parts:
            return out
        colix = {"swap": 0, "home": 1, "fresh": 2, "so": 3, "sr": 4}
        n = sum(len(g[1]) for g in parts.values())
        P = np.zeros((n, 5))
        T, I, C = [], [], []
        at = off = 0
        for name, (_pt, psi, t, it, cp) in parts.items():
            P[at:at + len(psi), colix[name]] = psi
            T.append(t)
            I.append(it)
            C.append(cp + off)
            off += int(cp.max()) + 1
            at += len(psi)
        t, it, cp = np.concatenate(T), np.vstack(I), np.concatenate(C)
        pt = {k: g[0] for k, g in parts.items()}
        has_f, has_s = "fresh" in parts, "so" in parts
        kw = dict(margin=1.0 - float(self.pack.settings.get("ni_fraction", 0.25)),
                  v_fresh=pt["fresh"] if has_f else None, psi_fresh=P[:, 2] if has_f else None,
                  s_owner=pt["so"] if has_s else None, s_reader=pt["sr"] if has_s else None,
                  psi_so=P[:, 3] if has_s else None, psi_sr=P[:, 4] if has_s else None,
                  z_reader_cal=self.reader_spread_z(store, items) if has_s else None)
        r = M.theta_tests(pt["swap"], pt["home"], P[:, 0], P[:, 1], t, it, cp, **kw)
        out.update(estimate=r["theta"], lo=r["lo"], hi=r["hi"], interval=r["interval"],
                   status_same_tasks=r.get("status", ""), v_swap=pt["swap"], v_home=pt["home"],
                   p_drop=r.get("p_drop", NAN), p_ni=r.get("p_ni", NAN), p_md=r.get("p_md", NAN),
                   p_home=r.get("p_home", NAN), se_v_home=r.get("se_V_home", NAN))
        if has_s:
            for k in ("order", "order_lo", "order_hi", "order_status", "stakes", "stakes_lo", "stakes_hi",
                      "z_s_reader_flag"):
                if k in r:
                    out[k] = r[k]
        if self.B:
            dr = self.theta_boot_draws(store, swap_key, home_key, items)
            dr = dr[np.isfinite(dr)]
            if dr.size > 1:              # always written, whatever the flags say
                out["lo_boot"], out["hi_boot"] = (float(x) for x in np.percentile(dr, [2.5, 97.5]))
        return out

    def theta_point(self, store, swap_key: str, home_key: str, items: list) -> float:
        """theta's point value only (msr.metrics.theta_from_sums of the two pooled totals)."""
        a = self._comps_full(store, swap_key, items)[0]
        b = self._comps_full(store, home_key, items)[0]
        if not (math.isfinite(a) and math.isfinite(b)):
            return NAN
        return M.theta_from_sums(a, b)

    def _boot_mean(self, store, key, items) -> np.ndarray:
        tot = np.zeros(self.B)
        for (o, r, s, w) in items:
            tot = tot + w * self.cell_boot(store, key, o, r, s)
        return tot

    def theta_boot_draws(self, store, swap_key: str, home_key: str, items: list) -> np.ndarray:
        with np.errstate(invalid="ignore", divide="ignore"):
            return self._boot_mean(store, swap_key, items) / self._boot_mean(store, home_key, items)

    def _cw_parts(self, store, nk, dk, o, r, s):
        """(sum num, sum weight, bootstrap sums of both) of one cell over a stream, computed once."""
        ck = ("cw", id(store), nk, dk, o, r, s)
        hit = self._boot.get(ck)
        if hit is not None and hit[0] is store:
            return hit[1]
        num = den = 0.0
        bn = np.zeros(self.B) if self.B else None
        bd = np.zeros(self.B) if self.B else None
        for d in self.orders_of(s):
            nv, dv = self._get(store, nk, o, r, s, d), self._get(store, dk, o, r, s, d)
            if nv is None or dv is None:
                continue
            num += float(np.nansum(nv))
            den += float(np.nansum(dv))
            if self.B:
                nd = self.counts[(s, d)] @ np.column_stack([np.nan_to_num(nv), np.nan_to_num(dv)])
                bn += nd[:, 0]
                bd += nd[:, 1]
        val = (num, den, bn, bd)
        self._boot[ck] = (store, val)
        return val

    def cw(self, store, nk: str, dk: str, items: list) -> dict:
        """Cw pooled as the paper pools it (ratio of summed numerators and weights over the orders of
        a stream; plain mean over streams and cells), with the task-only bootstrap interval."""
        pt = 0.0
        bt = np.zeros(self.B) if self.B else None
        for (o, r, s, w) in items:
            num, den, bn, bd = self._cw_parts(store, nk, dk, o, r, s)
            if den <= 0:
                return {"estimate": NAN, "lo_boot": NAN, "hi_boot": NAN}
            pt += w * num / den
            if self.B:
                with np.errstate(invalid="ignore", divide="ignore"):
                    bt = bt + w * np.where(bd > 0, bn / np.where(bd > 0, bd, 1.0), NAN)
        out = {"estimate": pt, "lo_boot": NAN, "hi_boot": NAN}
        if self.B:
            b = bt[np.isfinite(bt)]
            if b.size > 1:
                out["lo_boot"], out["hi_boot"] = (float(x) for x in np.percentile(b, [2.5, 97.5]))
        return out


# ---------------------------------------------------------------------------
# The levels every number is reported at
# ---------------------------------------------------------------------------

KIND_ORDER = ("same_maker_upgrade", "same_maker_downgrade", "same_maker_other", "cross_maker", "home")
KIND_LABEL = {"same_maker_upgrade": "same-maker upgrades", "same_maker_downgrade": "same-maker downgrades",
              "same_maker_other": "other same-maker swaps", "cross_maker": "cross-maker swaps",
              "home": "home cells (each owner reading its own bank)"}


def levels(pack, board: str | None = None) -> list:
    """[(level, owner, reader, kind, stream, [(owner, reader, stream, weight), ...])]: every cell of the
    board (default: every cell the pack can read) per stream and over the streams, then every kind of
    swap per stream and over the streams."""
    streams = pack.streams
    cells_all = pack.board_cells(board) if board else pack.cells
    out = []
    for (o, r) in cells_all:
        k = pack.kind[(o, r)]
        for s in streams:
            out.append(("pair", o, r, k, s, [(o, r, s, 1.0)]))
        if len(streams) > 1:
            out.append(("pair", o, r, k, "all", [(o, r, s, 1.0 / len(streams)) for s in streams]))
    for k in KIND_ORDER:
        cells = [c for c in cells_all if pack.kind[c] == k]
        if not cells:
            continue
        for s in streams:
            out.append(("kind", "", "", k, s, [(o, r, s, 1.0 / len(cells)) for o, r in cells]))
        if len(streams) > 1:
            w = 1.0 / (len(cells) * len(streams))
            out.append(("kind", "", "", k, "all", [(o, r, s, w) for o, r in cells for s in streams]))
    return out
