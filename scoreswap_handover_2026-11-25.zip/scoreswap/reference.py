"""The paper's own rules, computed once per pack with the paper's own batched engine, and kept.

Every board shows keep, wipe, fixed_0.5 and, at each budget k, recal_k, powerprior_k, retest_k and
audit_k beside the entries, on the same tasks and seeded draws. Computing them through the
public interface takes 200 calls per cell and budget; msr.evaluate.family_arms (the code that
wrote the paper's arms.csv) does all draws of a cell at once. So the exporter runs it once, for
the headline family, and stores the per-task values:

    release/<name>/reference/dev/<family>.npz            the development board (the public owners' banks)
    release/<name>_private/reference/test/<family>.npz   the ranked board (the private owners' banks, secret
                                                         seed; maintainers)

Other families are computed on demand (same engine) and cached in the output folder.
Values are stored as float32, as the paper's own analysis stores per-task values.
That the public interface gives the same numbers is the parity test (scoreswap.parity).
"""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

import numpy as np


def _fork_pool(n: int):
    """A fork-started multiprocessing.Pool. Python warns when it forks a process that has other
    threads; here those are only numpy's idle BLAS threads (OpenBLAS re-initialises itself in the
    child through its fork handlers) and no lock is held by them, so the warning is silenced."""
    import gc
    import multiprocessing as mp
    import warnings
    gc.collect()
    gc.freeze()            # inherited tables stay shared with the workers (never walked, so never copied)
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message=".*multi-threaded, use of fork.*", category=DeprecationWarning)
        return mp.get_context("fork").Pool(processes=n)

#: The paper's rules kept for the boards (k-rules at every budget that fits) and their metrics.
NO_CHECK_ARMS = ("keep", "wipe", "fixed_0.5")
CHECK_ARMS = ("recal", "powerprior", "retest", "audit")
METRICS = (("per", "value"), ("reg", "regret"), ("log_lc", "log_lc"), ("brier_lc", "brier_lc"),
           ("log", "log"), ("brier", "brier"))


def arm_names(budgets) -> list:
    return list(NO_CHECK_ARMS) + [f"{a}_{k}" for k in budgets if k > 0 for a in CHECK_ARMS]


_G: dict = {}          # the pack, set before worker processes are forked (they inherit it, nothing is pickled)


def _job(args):
    """All readers of one owner bank: {cell key: ({arm: {metric: array}}, split labels)}."""
    owner, stream, order, family, budgets, board = args
    pack = _G["pack"]
    from msr import arms as A
    from msr import engine as X
    from msr import evaluate as EV
    from scoreswap import api as API
    from scoreswap import harness as H
    S = H.settings_ns(pack, board)
    S.evaluate.k_values = tuple(k for k in budgets if k > 0)
    O = H.OwnerTables(pack, owner, stream, order, board)
    bank = API.Bank(O.bank_payload)
    records = bank.records(family)
    fam = X.Fam(family, bank.rule(family), records, bank.items, bank.no_memory_rate)
    perms = np.array([A.shuffle_order(len(bank.items), EV.shuffle_seed(S, stream, order, owner, 0))], dtype=np.int64)
    want = set(arm_names(budgets))
    out = {}
    for (o, r) in pack.board_cells(board):
        if o != owner:
            continue
        CT = H.CellTables(O, r, S)
        CD = EV.CellDraws(S, (stream, order, owner, r), CT.P)
        res = EV.family_arms(S, (stream, order, owner, r), fam, records, CT.sc, CD, perms, [])
        cell = {}
        for arm, ev in res.items():
            if arm not in want:
                continue
            d = {name: np.asarray(ev[src], dtype=np.float32) for src, name in METRICS if src in ev}
            d["#checks"] = float((ev.get("info") or {}).get("checks", 0.0))
            cell[arm] = d
        out[(owner, r, stream, order)] = (cell, O.split)
    return out


def compute(pack, family: str, budgets=None, processes: int | None = None, printer=None, board: str = "dev") -> dict:
    """{(owner, reader, stream, order): ({arm: {metric: per-task array}}, split labels)} over one board's
    evaluation tasks, with its check pool and seed."""
    budgets = list(budgets if budgets is not None else pack.budgets_fit(board))
    cells = pack.board_cells(board)
    jobs = [(o, s, d, family, budgets, board) for (s, d) in pack.strata for o in pack.models
            if any(c[0] == o for c in cells)]
    pack.load_all()
    _G["pack"] = pack
    out = {}
    t0 = time.time()
    n = processes or min(8, os.cpu_count() or 1)
    if n > 1 and hasattr(os, "fork") and len(jobs) > 1:
        pool = _fork_pool(min(n, len(jobs)))
        try:
            for i, res in enumerate(pool.imap_unordered(_job, jobs), 1):
                out.update(res)
                if printer:
                    printer(f"  [paper's rules, {family}] {i}/{len(jobs)} banks ({time.time() - t0:.0f} s)")
            pool.close()
            pool.join()
        except BaseException:
            pool.terminate()
            raise
        finally:
            import gc
            gc.unfreeze()
    else:
        for i, j in enumerate(jobs, 1):
            out.update(_job(j))
            if printer:
                printer(f"  [paper's rules, {family}] {i}/{len(jobs)} banks ({time.time() - t0:.0f} s)")
    return out


def save(path: Path, ref: dict, split: str | None) -> None:
    """Write the per-task values of one split ('dev', 'test' or None for all) to an npz file."""
    arrays = {}
    for (o, r, s, d), (cell, labels) in ref.items():
        sel = np.ones(len(labels), dtype=bool) if split is None else (labels == split)
        for arm, mets in cell.items():
            for m, v in mets.items():
                key = f"{o}|{r}|{s}|{d}|{arm}|{m}"
                arrays[key] = np.asarray([v], dtype=np.float32) if m == "#checks" else np.asarray(v)[sel]
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.stem + ".part.npz")
    np.savez_compressed(tmp, **arrays)
    tmp.replace(path)


_LOADED: dict = {}


def load(path: Path) -> dict:
    """{(owner, reader, stream, order): {arm: {metric: array}}} from a reference file (read once)."""
    path = Path(path)
    key = (str(path.resolve()), path.stat().st_mtime_ns)
    if key in _LOADED:
        return _LOADED[key]
    out: dict = {}
    with np.load(path, allow_pickle=False) as z:
        for k in z.files:
            o, r, s, d, arm, m = k.split("|")
            v = z[k]
            out.setdefault((o, r, s, int(d)), {}).setdefault(arm, {})[m] = float(v[0]) if m == "#checks" else v
    if len(_LOADED) > 8:
        _LOADED.clear()
    _LOADED[key] = out
    return out


def build_reference(out: Path, priv: Path, printer=print, processes: int | None = None) -> None:
    """Called by the exporter: compute the headline family's paper rules on both boards, write the
    development board's into the public pack and the ranked board's into the private folder, and
    refresh both manifests (the public one lists the new files; the private one pairs with it)."""
    from scoreswap import export as EX
    from scoreswap.pack import Pack
    pack = Pack(out, verify=False, private=priv)
    fam = pack.headline
    printer(f"Computing the paper's rules ({fam}) once per board, for the boards ...")
    ref = compute(pack, fam, processes=processes, printer=printer, board="dev")
    save(out / EX.REFERENCE_DIR / "dev" / f"{fam}.npz", ref, None)
    ref = compute(pack, fam, processes=processes, printer=printer, board="test")
    save(priv / EX.REFERENCE_DIR / "test" / f"{fam}.npz", ref, None)
    manifest = json.loads((out / "manifest.json").read_text(encoding="utf-8"))
    manifest["reference"] = {"family": fam, "arms": arm_names(pack.budgets_fit("dev")),
                             "metrics": [m for _s, m in METRICS],
                             "how": "msr.evaluate.family_arms (the paper's batched engine), float32 per task"}
    EX._write_manifest(out, manifest)
    pm = json.loads((priv / "manifest.json").read_text(encoding="utf-8"))
    pm["public_manifest_sha256"] = EX.sha256_file(out / "manifest.json")
    tf = priv / EX.REFERENCE_DIR / "test" / f"{fam}.npz"
    pm["files"] = [f for f in pm["files"] if not f["path"].startswith(EX.REFERENCE_DIR)] + \
        [{"path": tf.relative_to(priv).as_posix(), "bytes": tf.stat().st_size, "sha256": EX.sha256_file(tf)}]
    (priv / "manifest.json").write_text(json.dumps(pm, indent=1), encoding="utf-8")
