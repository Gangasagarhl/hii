"""Scoring an entry from the frozen tables: per cell, per ordered pair, per stream and per kind
of swap, with intervals, beside keep, wipe and the paper's rules on the same tasks and draws.

Swap-day rule, per cell (owner, reader, stream, order) and evaluation task (pre-registration 2.7,
2.8, 2.2, 2.4):
- first-shown success: the candidate with the largest 0.5 u + 0.5 relevance (ties to the more
  relevant item, then the first listed) and the reader's mean result for it; regret: the gap to
  the task's best candidate;
- log score and Brier score of p against both stored repeats of every candidate (raw, and
  level-corrected: p shifted by one logit constant so its mean over the calibration cells equals
  the reader's no-item success there, the same correction for every rule);
- Cw of u with the reader's results, and the signed validity V; the retained ranking signal
  theta = V(u, reader) / V(owner's score, owner) against the owner's home value of the family
  the rule works on (the headline family unless `--set family=...`). At a home cell the "reader"
  is the owner itself with the same two repeats, so keep's theta there is exactly 1.
A rule that draws at random is run once per seeded draw (the paper's 200 by default) and each
per-task value is the mean over the draws (Part 4.5).

Score type, per cell: Cw at home (the owner's results), after the swap (the reader's results; at
a home cell the owner's extra repeats 3-4, the self-swap) and against the extra home repeats, and
V at home and after the swap; theta = V_swap / V_home (Part 2.4).

Every per-task number comes from msr.engine / msr.evaluate (Scorer, conc_parts, _over_draws), the
same code that wrote the paper's arms.csv and validity.csv. Calls run in parallel processes
(one sealed launcher each), one owner bank per job; summaries are computed per split.
"""
from __future__ import annotations

import csv
import hashlib
import math
import os
import secrets
import time
from pathlib import Path

import numpy as np


def _fork_pool(n: int):
    """A fork-started multiprocessing.Pool. Python warns when it forks a process that has other
    threads; here those are only numpy's idle BLAS threads (OpenBLAS re-initialises itself in the
    child through its fork handlers) and no lock is held by them, so the warning is silenced."""
    import gc
    import multiprocessing as mp
    import warnings
    gc.collect()
    gc.freeze()            # the tables the workers inherit are never walked by their garbage collector, so
    #                        they stay shared with this process instead of being copied into every worker
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message=".*multi-threaded, use of fork.*", category=DeprecationWarning)
        return mp.get_context("fork").Pool(processes=n)

from scoreswap import harness as H
from scoreswap import stats as ST

NAN = float("nan")
REF_DIR = Path(__file__).resolve().parent / "reference_rules"
PAPER_SCORE_TYPES = ("ema_grade", "beta_grade", "tags_self", "credit", "visits")
RULE_METRICS = (("value", "first-shown success"), ("regret", "regret"), ("log_lc", "log score, level-corrected"),
                ("brier_lc", "Brier score, level-corrected"), ("log", "log score"), ("brier", "Brier score"))
COMPARE_METRICS = ("value", "regret", "log_lc")
#: The boards' three measures, each taken from msr.metrics by name: (column, msr.metrics function,
#: its output key, meaning). The function is called once per level with the signature of
#: msr.metrics.theta_tests(v_swap, v_home, psi_swap, psi_home, task, items, comp, **kw) (stats.Clusters.theta
#: builds every input exactly as msr.analysis does); the column takes "<key>", "<key>_lo", "<key>_hi" (theta:
#: "theta", "lo", "hi") and "<key>_status" from its output. A new measure of that output is ONE line here.
SCORE_TYPE_MEASURES = [
    ("theta", "theta_tests", "theta", "value kept: the share of the home ranking signal left after the swap "
                                      "(V after the swap / V at home) = retained agreement x stakes"),
    ("order", "theta_tests", "order", "retained agreement: how well the old order still fits the new model "
                                      "(a noise-corrected correlation; 'not estimated' when the reader's spread "
                                      "on the calibration tasks is below z = 2)"),
    ("stakes", "theta_tests", "stakes", "stakes: how much the new model cares which tip it gets, relative to "
                                        "the old one (sqrt of the readers' / the owner's noise-free spread)"),
]


def measure_rows(base: dict, th: dict) -> list:
    """The SCORE_TYPE_MEASURES rows of one level from one Clusters.theta result."""
    from msr import metrics as M
    rows = []
    for name, _fn, key, meaning in SCORE_TYPE_MEASURES:
        if key == "theta":
            est, lo, hi, status = th["estimate"], th["lo"], th["hi"], th["status"]
        else:
            est, lo, hi = th.get(key, NAN), th.get(f"{key}_lo", NAN), th.get(f"{key}_hi", NAN)
            status = th.get(f"{key}_status", th["status"]) if key == "order" else th["status"]
        rows.append({**base, "metric": name, "meaning": meaning, "estimate": est, "lo": lo, "hi": hi,
                     "interval": th.get("interval", "") if key == "theta" else "", "status": status,
                     "home_signal": th["status"] == M.THETA_DEFINED, "z_home_signal": th.get("z_cal", NAN),
                     "identifiable": (status == M.ORDER_DEFINED) if key == "order" else "",
                     "p_drop": th.get("p_drop", NAN) if key == "theta" else NAN,
                     "p_ni": th.get("p_ni", NAN) if key == "theta" else NAN,
                     "lo_boot": th.get("lo_boot", NAN) if key == "theta" else NAN,
                     "hi_boot": th.get("hi_boot", NAN) if key == "theta" else NAN,
                     "v_home": th.get("v_home", NAN), "v_swap": th.get("v_swap", NAN)})
    return rows


def file_sha(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _mean_last(a) -> float:
    from msr import evaluate as EV
    return float(EV._nanmean_last(np.asarray(a, dtype=float)))


def _stable(text: str) -> int:
    return int.from_bytes(hashlib.sha256(text.encode()).digest()[:8], "big")


def default_workers() -> int:
    return max(1, min(8, os.cpu_count() or 1))


# ---------------------------------------------------------------------------
# Running an entry over the pack (in parallel jobs, one owner bank each)
# ---------------------------------------------------------------------------

_G: dict = {}            # set before the worker processes are forked: they inherit it, nothing is pickled


def _jobs(pack, cells=None, board: str = "dev") -> list:
    """(owner, stream, order, readers) of every bank on the board (only the given cells, if any)."""
    want = None if cells is None else {tuple(c) for c in cells}
    board_cells = pack.board_cells(board)
    out = []
    for (s, d) in pack.strata:
        for o in pack.models:
            rd = [r for (oo, r) in board_cells if oo == o and (want is None or (oo, r) in want)]
            if rd:
                out.append((o, s, d, rd))
    return out


def _worker_runner():
    r = _G.get("runner")
    if r is None:
        spec = _G["spec"]
        r = _G["runner"] = H.make_runner(spec["path"], trusted=spec["trusted"], pack_root=_G["pack"].root,
                                         timeout=spec["timeout"], deadline=spec.get("deadline"),
                                         memory_gb=spec.get("memory_gb"))
    return r


def _rule_job(args):
    return _run_rule_bank(_G["pack"], _worker_runner(), *args)


def _score_job(args):
    runner = None if args[-1].get("family") else _worker_runner()
    return _run_score_bank(_G["pack"], runner, *args)


def _execute(pack, entry, jobs, fn_seq, fn_par, cfg, trusted, workers, runner, timeout, progress, label,
             time_budget=None, memory_gb=None):
    out, sandbox = {}, {}
    pack.load_all()
    t0 = time.time()
    deadline = t0 + float(time_budget) if time_budget else None
    n = workers or default_workers()
    if runner is not None or n <= 1 or len(jobs) <= 1 or not hasattr(os, "fork"):
        r = runner or (_NoRunner() if cfg.get("family") else
                       H.make_runner(entry, trusted=trusted, pack_root=pack.root, timeout=timeout, deadline=deadline,
                                     memory_gb=memory_gb))
        try:
            for i, j in enumerate(jobs, 1):
                res, sandbox = fn_seq(pack, r, *j, cfg)
                out.update(res)
                if progress:
                    progress(i, len(jobs), time.time() - t0)
        finally:
            if runner is None:
                r.close()
        return out, sandbox
    _G.clear()
    _G.update(pack=pack, spec={"path": entry, "trusted": trusted, "timeout": timeout, "deadline": deadline,
                               "memory_gb": memory_gb})
    # multiprocessing.Pool forks every worker before it starts any helper thread (fork with no thread running)
    pool = _fork_pool(min(n, len(jobs)))
    try:
        for i, (res, sandbox) in enumerate(pool.imap_unordered(fn_par, [tuple(j) + (cfg,) for j in jobs]), 1):
            out.update(res)
            if progress:
                progress(i, len(jobs), time.time() - t0)
        pool.close()
        pool.join()
    except BaseException:
        pool.terminate()
        raise
    finally:
        _G.clear()
        import gc
        gc.unfreeze()
    return out, sandbox


def run_rule(pack, entry, budget: int, draws: int | None = None, cells=None, options: dict | None = None,
             trusted: bool = False, workers: int | None = None, progress=None, keep_outputs: bool = False,
             order_seed: int | None = None, runner=None, timeout: float = H.CALL_TIMEOUT, board: str = "dev",
             time_budget: float | None = None, memory_gb: float | None = None, draw_pick: int | None = None,
             first_draws: bool = False) -> dict:
    """Run a swap-day rule on every cell of one board ('dev': the development board; 'test': the
    ranked board, the private owners' banks and the secret seed; 'all': the paper's tables). Returns
    {"cells": {(o, r, s, d): record}, "meta": ...}, each record holding per-task arrays over the
    board's evaluation tasks and a summary row. Raises EntryFailure on any breach.

    `draws` below the pack's number runs that many of its draws, chosen at random; the rule is always
    told the pack's number (swap.draws), so a short run (check) cannot be told from a full one.
    `first_draws`: run draws 0 .. draws-1 instead (the paper's own short runs, e.g. its shuffled
    permutations: parity only)."""
    meta = runner.meta if runner is not None else H._meta(Path(entry))
    if meta["kind"] != "swap_day_rule":
        raise H.EntryFailure(f"this entry is a {meta['kind'].replace('_', ' ')}, not a swap-day rule")
    fit = pack.budgets_fit(board)
    if int(budget) not in pack.settings["budgets_registered"]:
        raise H.EntryFailure(f"budget {budget} is not one of the registered budgets {pack.settings['budgets_registered']}")
    if int(budget) not in fit:
        pool = (pack.settings.get("calibration_pool_cells_by_board") or {}).get(board,
                                                                              pack.settings["calibration_pool_cells"])
        raise H.EntryFailure(f"budget {budget} is larger than this board's check pool ({pool} cells; budgets that "
                             f"fit: {fit}); the paper skips it too")
    D_full = int(pack.settings["draws_per_budget"])
    many = budget > 0 or meta["random"]
    n_draws = (min(int(draws), D_full) if draws else D_full) if many else 1
    o_seed = int(order_seed if order_seed is not None else secrets.randbits(32))
    if many and n_draws < D_full and not first_draws:    # a short run uses draws picked at random among the pack's
        pick = int(draw_pick) if draw_pick is not None else secrets.randbits(32)
        draw_ids = sorted(int(d) for d in np.random.default_rng([pick, 7]).choice(D_full, n_draws, replace=False))
    else:
        draw_ids = list(range(n_draws))
    ref_family = str((options or {}).get("family") or pack.headline)
    if ref_family not in pack.families:
        raise H.EntryFailure(f"family {ref_family!r} is not in this pack ({pack.families})")
    cfg = {"budget": int(budget), "n_draws": n_draws, "draw_ids": draw_ids, "draws_shown": D_full if many else 1,
           "options": dict(options or {}), "ref_family": ref_family, "draw_key": meta["draw_key"],
           "keep_outputs": keep_outputs, "order_seed": o_seed, "board": board}
    out, sandbox = _execute(pack, entry, _jobs(pack, cells, board), _run_rule_bank, _rule_job, cfg, trusted, workers, runner,
                            timeout, progress, meta["name"], time_budget=time_budget, memory_gb=memory_gb)
    return {"cells": out, "meta": {**meta, "budget": int(budget), "draws": n_draws, "ref_family": ref_family,
                                   "options": dict(options or {}), "sandbox": sandbox, "board": board}}


def _run_rule_bank(pack, runner, owner, stream, order, readers, cfg):
    board = cfg.get("board", "dev")
    S = H.settings_ns(pack, board)
    O = H.OwnerTables(pack, owner, stream, order, board)
    key = f"{owner}|{stream}|{order}"
    runner.set_inputs(key, O)
    CTs = {rd: H.CellTables(O, rd, S) for rd in readers}
    n_draws, budget = cfg["n_draws"], cfg["budget"]
    draw_ids = cfg.get("draw_ids") or list(range(n_draws))
    shown = int(cfg.get("draws_shown", n_draws))
    rng = np.random.default_rng([cfg["order_seed"], _stable(key)])
    sealed = bool(getattr(runner, "sealed", False))
    outs = {rd: [None] * n_draws for rd in readers}
    used = {rd: [0] * n_draws for rd in readers}
    rcalls = {rd: [0] * n_draws for rd in readers}
    for ri in rng.permutation(len(readers)):      # cells in a shuffled order, and each cell's draws too
        rd = readers[int(ri)]
        CT = CTs[rd]
        ds = [int(j) for j in rng.permutation(n_draws)]          # positions in draw_ids
        seeds = [H.draw_seed(pack, stream, order, owner, rd, cfg["draw_key"], budget, draw_ids[j], board) for j in ds]
        servers = [H.CheckServer(CT, budget, sd) for sd in seeds]
        swaps = [CT.swap_payload(budget, draw_ids[j], shown, cfg["options"]) for j in ds]
        try:
            raws = runner.run_rule_batch(key, swaps, CT, budget, seeds, servers)
        except H.EntryFailure as e:
            raise H.EntryFailure(f"cell {owner} -> {rd}, {stream} order {order}: {e}") from None
        for d, raw, server in zip(ds, raws, servers):
            try:
                if sealed:            # the sealed call saw the items and tasks in the sealed order: put them back
                    mode, u, p = H.check_rule_output(raw, len(O.items), len(O.tasks_all), O.C, O.sealed_cand_mask)
                    outs[rd][d] = (mode, O.from_sealed(mode, u), O.from_sealed(mode, p))
                else:
                    outs[rd][d] = H.check_rule_output(raw, len(O.items), len(O.tasks_all), O.C, O.cand_mask_all)
            except H.EntryFailure as e:
                raise H.EntryFailure(f"cell {owner} -> {rd}, {stream} order {order}, draw {d}: {e}") from None
            used[rd][d] = server.used
            rcalls[rd][d] = server.reader_calls
    res = {}
    for rd in readers:
        o_ = outs[rd]
        if len({m for m, _u, _p in o_}) > 1:
            raise H.EntryFailure(f"cell {owner} -> {rd}: the rule returned per-item scores in some draws and "
                                 f"per-candidate scores in others")
        if len({p is None for _m, _u, p in o_}) > 1:
            raise H.EntryFailure(f"cell {owner} -> {rd}: the rule returned p in some draws but not in others")
        rec = evaluate_rule_cell(CTs[rd], o_, used[rd], rcalls[rd], cfg["ref_family"])
        rec["split"] = O.split
        sp_arrays, sr_cal = CTs[rd].spread()
        rec["arrays"].update(sp_arrays)
        rec["cal"] = {"S_reader": sr_cal, "V_cal": O.calibration_v(O.score_x(cfg["ref_family"]))}
        if cfg["keep_outputs"]:
            rec["outputs"] = o_
        res[(owner, rd, stream, order)] = rec
    return res, getattr(runner, "sandbox", {})


def evaluate_rule_cell(CT, outs: list, used: list, calls: list, ref_family: str) -> dict:
    """Per-task arrays and the summary row of one cell (the paper's arithmetic throughout)."""
    from msr import engine as X
    from msr import evaluate as EV
    O = CT.O
    mode = outs[0][0]
    D = len(outs)
    has_p = outs[0][2] is not None
    if mode == "item":
        U = outs[0][1] if D == 1 else np.stack([u for _m, u, _p in outs])
        Pp = (outs[0][2] if D == 1 else np.stack([p for _m, _u, p in outs])) if has_p else None
        sc, Tr, Th = CT.sc, CT.Tr, CT.Th
        Sc = U[..., O.cand_e]
    else:
        flat = [u.ravel() for _m, u, _p in outs]
        U = flat[0] if D == 1 else np.stack(flat)
        Pp = None
        if has_p:
            pf = [p.ravel() for _m, _u, p in outs]
            Pp = pf[0] if D == 1 else np.stack(pf)
        sc, Tr, Th = CT.sc_c, CT.Tr_c, CT.Th_c
        Sc = U[..., O.pseudo_e.clip(min=0)]
    ev = sc(U, Pp)
    res = EV._single(ev) if D == 1 else EV._over_draws(ev)
    arrays = {"value": res["per"], "regret": res["reg"]}
    for k in ("log", "brier", "log_lc", "brier_lc"):
        if k in res:
            arrays[k] = res[k]
    for w, v in res.get("wt", {}).items():
        arrays["value_wz" if w == "z" else f"value_w{w:g}"] = v
    num, den, _nu, _du = X.conc_parts(Tr, Sc)
    hnum, hden, _a, _b = X.conc_parts(Th, Sc)
    if D > 1:
        num, hnum = num.mean(0), hnum.mean(0)
        den, hden = den[0], hden[0]
    xr = O.score_x(ref_family)
    rnum, rden, _a, _b = X.conc_parts(CT.Th, xr[O.cand_e])
    arrays["conc_num"], arrays["conc_den"] = num, den
    arrays["V_swap"] = 2.0 * num - den
    arrays["V_home_u"] = 2.0 * hnum - hden
    arrays["V_home_ref"] = 2.0 * rnum - rden
    info = res.get("info", {})
    row = {"owner": CT.owner, "reader": CT.reader, "kind": CT.kind, "stream": CT.stream, "order": CT.order,
           "output": "per item" if mode == "item" else "per task and candidate",
           "draws": D, "draw_sd": info.get("draw_sd", 0.0 if D == 1 else NAN),
           "value_p05": info.get("value_p05", NAN), "value_p95": info.get("value_p95", NAN),
           "log_p05": info.get("log_p05", NAN), "log_p95": info.get("log_p95", NAN),
           "checks_used": float(np.mean(used)) if used else 0.0,
           "reader_calls": float(np.mean(calls)) if calls else 0.0}
    for w in CT.settings.evaluate.w_sensitivity:
        row[f"value_w{w:g}"] = res["w"].get(w, NAN)
    row["value_wz"] = res["w"].get("z", NAN)
    row.update(_cell_values(arrays, None))
    return {"arrays": arrays, "row": row}


def _cell_values(arrays: dict, mask) -> dict:
    """Per-cell means over the tasks in `mask` (all tasks when None)."""
    from msr import engine as X

    def m(a):
        a = np.asarray(a, dtype=float)
        return _mean_last(a if mask is None else a[mask])
    out = {"n_tasks": int(np.count_nonzero(~np.isnan(arrays["value"] if mask is None else arrays["value"][mask]))),
           "value": m(arrays["value"]), "regret": m(arrays["regret"])}
    for k, col in (("log", "log_score"), ("brier", "brier"), ("log_lc", "log_score_lc"), ("brier_lc", "brier_lc")):
        out[col] = m(arrays[k]) if k in arrays else NAN
    if "conc_num" in arrays:
        n, d = np.asarray(arrays["conc_num"]), np.asarray(arrays["conc_den"])
        out["cw_swap"] = float(X.ratio(n if mask is None else n[mask], d if mask is None else d[mask]))
        vs, vh = m(arrays["V_swap"]), m(arrays["V_home_ref"])
        out.update(v_swap=vs, v_home=vh, theta=(vs / vh) if vh and math.isfinite(vh) and vh != 0 else NAN)
    return out


class _NoRunner:
    """Stands for a runner when the scores come from the bank itself (the paper's score types)."""
    meta = {}
    sandbox: dict = {}

    def close(self):
        pass


def run_score_type(pack, entry, cells=None, trusted: bool = False, workers: int | None = None, progress=None,
                   runner=None, timeout: float = H.CALL_TIMEOUT, family: str | None = None, board: str = "dev",
                   time_budget: float | None = None, memory_gb: float | None = None) -> dict:
    """Run a score type on every bank and measure it on every cell of one board. With `family`, the
    paper's score type of that family is measured directly from the bank's stored score (no entry)."""
    if family is not None:
        meta = {"kind": "score_type", "name": family, "draw_key": "", "random": False, "description": ""}
        cfg = {"family": family, "board": board}
        out, _sb = _execute(pack, None, _jobs(pack, cells, board), _run_score_bank, _score_job, cfg, True,
                            workers, _NoRunner(), timeout, progress, family) if (workers or default_workers()) <= 1 \
            else _execute(pack, None, _jobs(pack, cells, board), _run_score_bank, _score_job, cfg, True,
                          workers, None, timeout, progress, family)
        return {"cells": out, "meta": {**meta, "board": board}}
    meta = runner.meta if runner is not None else H._meta(Path(entry))
    if meta["kind"] != "score_type":
        raise H.EntryFailure(f"this entry is a {meta['kind'].replace('_', ' ')}, not a score type")
    out, sandbox = _execute(pack, entry, _jobs(pack, cells, board), _run_score_bank, _score_job,
                            {"family": None, "board": board}, trusted, workers, runner, timeout, progress, meta["name"],
                            time_budget=time_budget, memory_gb=memory_gb)
    return {"cells": out, "meta": {**meta, "sandbox": sandbox, "board": board}}


def _run_score_bank(pack, runner, owner, stream, order, readers, cfg):
    from msr import engine as X
    board = cfg.get("board", "dev")
    S = H.settings_ns(pack, board)
    O = H.OwnerTables(pack, owner, stream, order, board)
    key = f"{owner}|{stream}|{order}"
    if cfg.get("family"):
        x = O.score_x(cfg["family"])
    else:
        runner.set_inputs(key, O)
        try:
            x = H.check_score_output(runner.run_score(key), len(O.items))
            if getattr(runner, "sealed", False):
                x = O.from_sealed("item", x)
        except H.EntryFailure as e:
            raise H.EntryFailure(f"bank {owner}, {stream} order {order}: {e}") from None
    res = {}
    v_cal = O.calibration_v(x)
    for rd in readers:
        CT = H.CellTables(O, rd, S)
        Sx = x[O.cand_e]
        arrays = {}
        for name, T in (("home", CT.Th), ("swap", CT.Ts), ("floor", CT.Tx)):
            num, den, nu, du = X.conc_parts(T, Sx)
            arrays[f"{name}_num"], arrays[f"{name}_den"] = num, den
            arrays[f"{name}_num_u"], arrays[f"{name}_den_u"] = nu, du
            arrays[f"V_{name}"] = 2.0 * num - den
            arrays[f"W_{name}"] = den
        sp_arrays, sr_cal = CT.spread()
        arrays.update(sp_arrays)
        row = {"owner": owner, "reader": rd, "kind": CT.kind, "stream": stream, "order": order}
        row.update(_type_cell_values(arrays, None))
        res[(owner, rd, stream, order)] = {"arrays": arrays, "row": row, "x": x, "split": O.split,
                                           "cal": {"S_reader": sr_cal, "V_cal": v_cal}}
    return res, getattr(runner, "sandbox", {})


def _type_cell_values(arrays: dict, mask) -> dict:
    from msr import engine as X
    out = {}
    for name in ("home", "swap", "floor"):
        n, d = np.asarray(arrays[f"{name}_num"]), np.asarray(arrays[f"{name}_den"])
        if mask is not None:
            n, d = n[mask], d[mask]
        out[f"cw_{name}"] = float(X.ratio(n, d))
        v = np.asarray(arrays[f"V_{name}"])
        out[f"v_{name}"] = _mean_last(v if mask is None else v[mask])
    hd = np.asarray(arrays["home_den"])
    out["n_tasks"] = int(np.count_nonzero(~np.isnan(hd if mask is None else hd[mask])))
    out["theta"] = out["v_swap"] / out["v_home"] if out["v_home"] and math.isfinite(out["v_home"]) else NAN
    return out


# ---------------------------------------------------------------------------
# Splits, the paper's rules beside an entry, and summaries
# ---------------------------------------------------------------------------


def restrict(res: dict, split: str) -> dict:
    """{cell: {key: per-task array}} of a result restricted to one split's tasks."""
    keep = ST.SPLIT_SETS[split]
    out = {}
    for k, rec in res["cells"].items():
        m = np.isin(rec["split"], keep)
        out[k] = {a: np.asarray(v)[m] for a, v in rec["arrays"].items()}
        if rec.get("cal") is not None:
            out[k]["_cal"] = rec["cal"]          # calibration-task inputs of the flags (no split: no estimate uses them)
    return out


def cell_rows(res: dict, split: str, kind: str) -> list:
    rows = []
    keep = ST.SPLIT_SETS[split]
    for k in sorted(res["cells"]):                  # a fixed order: identical runs give identical files
        rec = res["cells"][k]
        m = np.isin(rec["split"], keep)
        row = dict(rec["row"])
        row.update(_cell_values(rec["arrays"], m) if kind == "swap_day_rule" else _type_cell_values(rec["arrays"], m))
        row["split"] = split
        rows.append(row)
    return rows


def paper_rule_stores(pack, budget: int, family: str, split: str, cache_dir: Path | None = None,
                      printer=None, workers: int | None = None) -> dict:
    """{rule name: store over one board} of the paper's rules at this budget (keep, wipe, fixed_0.5,
    recal_k, powerprior_k, retest_k, audit_k): 'dev' from the public pack's reference file, 'test'
    from the private folder's (the private owners' banks, secret seed), 'all' (the paper's tables)
    computed with the paper's batched engine (and cached in `cache_dir`)."""
    from scoreswap import reference as REF
    names = REF.arm_names([budget])
    f = pack.reference_path(split, f"{family}.npz") if split in ("dev", "test") else None
    if f is not None:
        loaded = REF.load(f)
    else:
        cp = None
        if cache_dir is not None:
            cp = Path(cache_dir) / pack.fingerprint[:16] / f"{family}__k{budget}__{split}.npz"
        if cp is not None and cp.exists():
            loaded = REF.load(cp)
        else:
            if printer:
                printer(f"  computing the paper's rules ({family}, k = {budget}, {split}) with the paper's engine ...")
            comp = REF.compute(pack, family, budgets=[0, budget] if budget else [0], processes=workers, board=split)
            loaded = {k: cell for k, (cell, _lab) in comp.items()}
            if cp is not None:
                REF.save(cp, comp, None)
    stores: dict = {}
    for key, arms in loaded.items():
        for arm, mets in arms.items():
            if arm in names:
                stores.setdefault(arm, {})[key] = {m: v for m, v in mets.items() if m != "#checks"}
    return stores


def paper_score_type_stores(pack, split: str) -> dict:
    out = {}
    for f in PAPER_SCORE_TYPES:
        if f in pack.families:
            out[f] = restrict(run_score_type(pack, None, family=f, board=split), split)
    return out


def _diff_store(a: dict, b: dict, keys) -> dict:
    out = {}
    for k, rec in a.items():
        o = b.get(k)
        if o is None:
            continue
        out[k] = {m: np.asarray(rec[m], dtype=float) - np.asarray(o[m], dtype=float)
                  for m in keys if m in rec and m in o}
    return out


def rule_summary(pack, CL: ST.Clusters, store: dict, others: dict | None = None, cells_rows: list | None = None) -> tuple:
    """(summary rows, comparison rows) of a swap-day rule's store on one split."""
    others = others or {}
    has_p = any("log_lc" in a for a in store.values())
    metrics = [(k, lab) for k, lab in RULE_METRICS if has_p or not k.startswith(("log", "brier"))]
    diffs = {o: _diff_store(store, s, COMPARE_METRICS) for o, s in others.items()}
    rows, comp = [], []
    for level, o, r, kind, stream, items in ST.levels(pack, CL.split):
        base = {"split": CL.split, "level": level, "owner": o, "reader": r, "kind": kind, "stream": stream,
                "n_cells": len(items)}
        cols = [(store, k) for k, _l in metrics]
        cmp_cols = []
        if not (level == "pair" and stream != "all" and len(pack.streams) > 1):
            for oname in others:
                for m in COMPARE_METRICS:
                    if m.startswith("log") and not has_p:
                        continue
                    cmp_cols.append((oname, m))
        allc = cols + [(others[on], m) for on, m in cmp_cols] + [(diffs[on], m) for on, m in cmp_cols]
        res = CL.linear_batch(allc, items)
        for (k, lab), st in zip(metrics, res[:len(cols)]):
            rows.append({**base, "metric": k, "meaning": lab, **st})
        nc = len(cmp_cols)
        for i, (on, m) in enumerate(cmp_cols):
            ov, d = res[len(cols) + i], res[len(cols) + nc + i]
            comp.append({**base, "metric": m, "other_rule": on, "other_value": ov["estimate"],
                         "other_lo": ov["lo"], "other_hi": ov["hi"], "other_lo_boot": ov["lo_boot"],
                         "other_hi_boot": ov["hi_boot"], "difference": d["estimate"], "lo": d["lo"], "hi": d["hi"],
                         "p": d["p"], "lo_boot": d["lo_boot"], "hi_boot": d["hi_boot"]})
        th = CL.theta(store, "V_swap", "V_home_ref", items, fresh=False)
        for mr in measure_rows(base, th):
            if mr["metric"] == "theta":
                mr["meaning"] = ("retained ranking signal of u (V with the reader's results / V of the owner's own "
                                 "score with the owner's results) = retained agreement x stakes")
            rows.append(mr)
        rows.append({**base, "metric": "cw", "meaning": "concordance Cw of u with the reader's results",
                     **CL.cw(store, "conc_num", "conc_den", items)})
        if cells_rows is not None:
            sel = [c for c in cells_rows if any(c["owner"] == a and c["reader"] == b and c["stream"] == s
                                                 for a, b, s, _w in items)]
            for m, lab in (("checks_used", "fresh checks used per cell and draw (mean)"),
                           ("reader_calls", "reader calls those checks take on a real swap day")):
                vals = [c[m] for c in sel]
                rows.append({**base, "metric": m, "meaning": lab, "estimate": float(np.mean(vals)) if vals else NAN})
    return rows, comp


def score_type_summary(pack, CL: ST.Clusters, store: dict, others: dict | None = None) -> tuple:
    """(summary rows, comparison rows) of a score type on one split: the measures of
    SCORE_TYPE_MEASURES (theta first) with the home flag, and Cw at home / after the swap /
    against the self-swap."""
    rows, comp = [], []
    for level, o, r, kind, stream, items in ST.levels(pack, CL.split):
        base = {"split": CL.split, "level": level, "owner": o, "reader": r, "kind": kind, "stream": stream,
                "n_cells": len(items)}
        va = CL.linear_batch([(store, "V_swap")], items)[0]
        rows.append({**base, "metric": "value_after", "meaning": "value after the swap: the mean signed validity V "
                     "of the score with the reader's results (the board ranks by it)", **va})
        th = CL.theta(store, "V_swap", "V_home", items)
        rows += measure_rows(base, th)
        for q, label in (("home", "Cw at home (the owner's results, repeats 1-2)"),
                         ("swap", "Cw after the swap (the reader's results; at a home cell the owner's repeats 3-4)"),
                         ("floor", "Cw against the owner's extra home repeats 3-4 (the self-swap)")):
            rows.append({**base, "metric": f"cw_{q}", "meaning": label, **CL.cw(store, f"{q}_num", f"{q}_den", items)})
        if level == "pair" and stream != "all" and len(pack.streams) > 1:
            continue
        for oname, ostore in (others or {}).items():
            a = {"estimate": th["estimate"]}
            b = {"estimate": CL.theta_point(ostore, "V_swap", "V_home", items)}
            da = CL.theta_boot_draws(store, "V_swap", "V_home", items)
            db = CL.theta_boot_draws(ostore, "V_swap", "V_home", items)
            with np.errstate(invalid="ignore"):
                dd = da - db
            dd = dd[np.isfinite(dd)]
            lo, hi = (float(x) for x in np.percentile(dd, [2.5, 97.5])) if dd.size > 1 else (NAN, NAN)
            comp.append({**base, "metric": "theta", "other_rule": oname, "other_value": b["estimate"],
                         "difference": a["estimate"] - b["estimate"], "lo_boot": lo, "hi_boot": hi})
    return rows, comp


def _generic_measure(CL, store, fn, nk, dk, items) -> dict:
    """A measure function with the signature of msr.metrics.theta_inference (kept for a measure that is
    not part of theta_tests' output)."""
    a, pa, ta, ia = CL._comps(store, nk, items)
    b, pb, tb, ib = CL._comps(store, dk, items)
    if pa is None or pb is None:
        return {"estimate": NAN, "lo": NAN, "hi": NAN, "status": ""}
    r = fn(a, b, np.concatenate([pa, np.zeros(len(pb))]), np.concatenate([np.zeros(len(pa)), pb]),
           np.concatenate([ta, tb]), np.vstack([ia, ib]))
    return {"estimate": r.get("theta", r.get("estimate", NAN)), "lo": r.get("lo", NAN), "hi": r.get("hi", NAN),
            "status": r.get("status", ""), "interval": r.get("interval", "")}


# ---------------------------------------------------------------------------
# Writing
# ---------------------------------------------------------------------------


def _fmt(v):
    if v is None:
        return ""
    if isinstance(v, (bool, np.bool_)):
        return "yes" if v else "no"
    if isinstance(v, float):
        return "" if math.isnan(v) else (f"{v:.6g}" if abs(v) < 1e6 else repr(v))
    return str(v)


def write_rows(path: Path, rows: list, cols: list | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if cols is None:
        cols = []
        for r in rows:
            for k in r:
                if k not in cols:
                    cols.append(k)
    with open(path, "w", encoding="utf-8", newline="") as fh:
        w = csv.writer(fh, lineterminator="\n")
        w.writerow(cols)
        for r in rows:
            w.writerow([_fmt(r.get(c)) for c in cols])


def fnum(v, d=3) -> str:
    try:
        v = float(v)
    except (TypeError, ValueError):
        return "-"
    return "-" if not math.isfinite(v) else f"{v:.{d}f}"


def interval(lo, hi, d=3) -> str:
    try:
        lo, hi = float(lo), float(hi)
    except (TypeError, ValueError):
        return ""
    if math.isnan(lo) or math.isnan(hi):
        return ""
    if math.isinf(lo) and math.isinf(hi):
        return "[unbounded]"
    a = "-inf" if math.isinf(lo) else fnum(lo, d)
    b = "inf" if math.isinf(hi) else fnum(hi, d)
    return f"[{a}, {b}]"
