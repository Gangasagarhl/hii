"""Kernel-enforced limits for the process that runs an outside entry (Linux).

Everyday picture: the entry is a guest who may look at the books on one shelf (the Python
installation and the scoreswap and msr packages), may not write anything anywhere, may not make
phone calls, may not invite anyone else in, and leaves the room after every single task. The
locks are the building's (the kernel's), not a polite sign on the door (a Python hook), so
Python tricks cannot open them.

Two Linux mechanisms, both usable without any privilege:
- Landlock (kernel 5.13 or newer): file access is limited to READING the allowed folders. No
  file may be written, created, removed, renamed or truncated, and no program executed. From
  Landlock ABI 4 (kernel 6.7) no TCP connection may be made or accepted; from ABI 6 (kernel 6.12)
  no signal may be sent and no abstract unix socket reached outside the sandbox.
- seccomp: system calls that could carry information from one call of the entry to the next, or
  reach another process, are refused: sockets, System V and POSIX IPC, shared memory (memfd,
  MAP_SHARED), key rings, eventfd, io_uring, ptrace and cross-process memory access, extended
  attributes, file times, modes and owners, namespaces, mounts, execve. The per-call worker
  additionally may not create any process, thread or pipe; may not signal any process; may not
  read or change the resource limits, priority, scheduling or I/O priority of any process but
  itself (prlimit64, setpriority, sched_*, ioprio_*); may not take file locks or leases, watch
  files (inotify, fanotify) or probe the page cache (mincore, cachestat); and has a memory ceiling
  (RLIMIT_AS).

`apply_launcher()` is called by the trusted launcher before it forks the first worker;
`apply_worker()` by each worker right after the fork, before any entry code runs.
On other systems, or an older kernel, the functions report what could not be applied; the
harness then states the weaker guarantee in its output.
"""
from __future__ import annotations

import ctypes
import errno
import os
import platform
import resource
import struct

# --- Landlock ---------------------------------------------------------------
_SYS_LANDLOCK_CREATE_RULESET = 444
_SYS_LANDLOCK_ADD_RULE = 445
_SYS_LANDLOCK_RESTRICT_SELF = 446
_LANDLOCK_CREATE_RULESET_VERSION = 1
_LANDLOCK_RULE_PATH_BENEATH = 1
_PR_SET_NO_NEW_PRIVS = 38
_PR_SET_CHILD_SUBREAPER = 36
_PR_SET_SECCOMP = 22
_SECCOMP_MODE_FILTER = 2

_FS_EXECUTE = 1 << 0
_FS_READ_FILE = 1 << 2
_FS_READ_DIR = 1 << 3
# every file-system right known to each ABI version (1 to 13 bits ... 16 bits)
_FS_ALL_BY_ABI = {1: (1 << 13) - 1, 2: (1 << 14) - 1, 3: (1 << 15) - 1, 4: (1 << 15) - 1, 5: (1 << 16) - 1}
_NET_BIND_TCP, _NET_CONNECT_TCP = 1 << 0, 1 << 1
_SCOPE_ABSTRACT_UNIX, _SCOPE_SIGNAL = 1 << 0, 1 << 1


def _libc():
    return ctypes.CDLL(None, use_errno=True)


def landlock_abi() -> int:
    """The Landlock ABI version of this kernel (0 = not available)."""
    if platform.system() != "Linux":
        return 0
    try:
        libc = _libc()
        libc.syscall.restype = ctypes.c_long
        v = libc.syscall(_SYS_LANDLOCK_CREATE_RULESET, None, ctypes.c_size_t(0),
                         ctypes.c_uint32(_LANDLOCK_CREATE_RULESET_VERSION))
        return int(v) if v > 0 else 0
    except Exception:
        return 0


def _landlock(read_dirs: list, read_files: list) -> dict:
    """Restrict this process (and its future children) to reading `read_dirs` (and below) and
    `read_files`; nothing may be written or executed; no TCP; no signals or abstract unix
    sockets outside the sandbox. Returns what was applied."""
    abi = landlock_abi()
    if abi < 1:
        return {"landlock": "not available on this system"}
    libc = _libc()
    libc.syscall.restype = ctypes.c_long
    fs_all = _FS_ALL_BY_ABI.get(abi, _FS_ALL_BY_ABI[5])
    net = (_NET_BIND_TCP | _NET_CONNECT_TCP) if abi >= 4 else 0
    scoped = (_SCOPE_ABSTRACT_UNIX | _SCOPE_SIGNAL) if abi >= 6 else 0
    if abi >= 6:
        attr = struct.pack("=QQQ", fs_all, net, scoped)
    elif abi >= 4:
        attr = struct.pack("=QQ", fs_all, net)
    else:
        attr = struct.pack("=Q", fs_all)
    buf = ctypes.create_string_buffer(attr, len(attr))
    rfd = libc.syscall(_SYS_LANDLOCK_CREATE_RULESET, buf, ctypes.c_size_t(len(attr)), ctypes.c_uint32(0))
    if rfd < 0:
        return {"landlock": f"could not be created (errno {ctypes.get_errno()})"}
    added = []
    try:
        for path, rights in [(d, _FS_READ_FILE | _FS_READ_DIR) for d in read_dirs] + \
                            [(f, _FS_READ_FILE) for f in read_files]:
            try:
                fd = os.open(path, os.O_PATH | os.O_CLOEXEC)
            except OSError:
                continue
            try:
                rule = struct.pack("=Qi", rights, fd)
                rbuf = ctypes.create_string_buffer(rule, len(rule))
                if libc.syscall(_SYS_LANDLOCK_ADD_RULE, ctypes.c_int(rfd), ctypes.c_int(_LANDLOCK_RULE_PATH_BENEATH),
                                rbuf, ctypes.c_uint32(0)) == 0:
                    added.append(path)
            finally:
                os.close(fd)
        if libc.prctl(_PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) != 0:
            return {"landlock": f"no_new_privs failed (errno {ctypes.get_errno()})"}
        if libc.syscall(_SYS_LANDLOCK_RESTRICT_SELF, ctypes.c_int(rfd), ctypes.c_uint32(0)) != 0:
            return {"landlock": f"restrict_self failed (errno {ctypes.get_errno()})"}
    finally:
        os.close(rfd)
    return {"landlock": f"ABI {abi}: read-only access to {len(added)} folder(s) and file(s); no writes, no execution"
                        + ("; no TCP" if net else "") + ("; signals and abstract sockets scoped" if scoped else ""),
            "landlock_abi": abi, "readable": added}


# --- seccomp ---------------------------------------------------------------
_AUDIT_ARCH_X86_64 = 0xC000003E
_X32_BIT = 0x40000000
_RET_ALLOW = 0x7FFF0000
_RET_ERRNO = 0x00050000
_BPF_LD_W_ABS = 0x20
_BPF_JEQ_K = 0x15
_BPF_JGE_K = 0x35
_BPF_JSET_K = 0x45
_BPF_RET_K = 0x06
_MAP_SHARED = 0x01
_CLONE_THREAD = 0x00010000

#: x86_64 numbers of the system calls refused to the launcher and its workers.
_DENY_X86_64 = {
    "socket": 41, "socketpair": 53,
    "shmget": 29, "shmat": 30, "shmctl": 31, "semget": 64, "semop": 65, "semctl": 66, "msgget": 68,
    "msgsnd": 69, "msgrcv": 70, "msgctl": 71, "semtimedop": 220,
    "mq_open": 240, "mq_unlink": 241, "mq_timedsend": 242, "mq_timedreceive": 243, "mq_notify": 244,
    "mq_getsetattr": 245, "add_key": 248, "request_key": 249, "keyctl": 250,
    "ptrace": 101, "process_vm_readv": 310, "process_vm_writev": 311, "kcmp": 312,
    "eventfd": 284, "eventfd2": 290, "memfd_create": 319, "memfd_secret": 447,
    "io_uring_setup": 425, "io_uring_enter": 426, "io_uring_register": 427,
    "bpf": 321, "perf_event_open": 298, "userfaultfd": 323,
    "unshare": 272, "setns": 308, "mount": 165, "umount2": 166, "pivot_root": 155, "chroot": 161,
    "pidfd_open": 434, "pidfd_getfd": 438, "pidfd_send_signal": 424,
    "execve": 59, "execveat": 322,
    "setxattr": 188, "lsetxattr": 189, "fsetxattr": 190, "removexattr": 197, "lremovexattr": 198,
    "fremovexattr": 199, "setxattrat": 463, "removexattrat": 466,
    "utime": 132, "utimes": 235, "futimesat": 261, "utimensat": 280,
    "chmod": 90, "fchmod": 91, "fchmodat": 268, "fchmodat2": 452, "chown": 92, "fchown": 93, "lchown": 94,
    "fchownat": 260, "mknod": 133, "mknodat": 259,
}
_FORK_X86_64 = {"fork": 57, "vfork": 58}
#: refused to a per-call worker only (the trusted launcher needs some of them: pipes for each call,
#: kill for a call that breaks the protocol)
_WORKER_DENY_X86_64 = {
    "pipe": 22, "pipe2": 293, "kill": 62, "tkill": 200, "tgkill": 234, "rt_sigqueueinfo": 129,
    "rt_tgsigqueueinfo": 297, "setpgid": 109, "setsid": 112, "flock": 73, "inotify_init": 253,
    "inotify_init1": 294, "inotify_add_watch": 254, "fanotify_init": 300, "fanotify_mark": 301, "mincore": 27,
    "cachestat": 451, "fadvise64": 221, "readahead": 187, "process_madvise": 440, "process_mrelease": 448,
    "migrate_pages": 256, "move_pages": 279, "get_robust_list": 274, "name_to_handle_at": 303,
    "open_by_handle_at": 304, "syslog": 103, "setrlimit": 160, "getpgid": 121, "getsid": 124,
}
#: (system call, argument index): refused to a worker unless that argument is 0 (= the calling process)
_WORKER_SELF_ONLY_X86_64 = (("prlimit64", 302, 0), ("getpriority", 140, 1), ("setpriority", 141, 1),
                            ("sched_setparam", 142, 0), ("sched_getparam", 143, 0), ("sched_setscheduler", 144, 0),
                            ("sched_getscheduler", 145, 0), ("sched_rr_get_interval", 148, 0),
                            ("sched_setaffinity", 203, 0), ("sched_getaffinity", 204, 0),
                            ("sched_setattr", 314, 0), ("sched_getattr", 315, 0),
                            ("ioprio_set", 251, 1), ("ioprio_get", 252, 1))
#: fcntl commands refused to a worker: record locks, open-file-description locks, leases, dnotify
_SYS_FCNTL = 72
_WORKER_FCNTL_DENY = (5, 6, 7, 36, 37, 38, 1024, 1026)
_SYS_CLONE, _SYS_CLONE3, _SYS_MMAP = 56, 435, 9


def _ins(code: int, jt: int, jf: int, k: int) -> bytes:
    return struct.pack("=HBBI", code, jt, jf, k & 0xFFFFFFFF)


def _program(no_process: bool) -> bytes:
    """The BPF program: on another architecture, or an x32 call, refuse everything; refuse every
    listed call with EPERM; clone3 with ENOSYS (glibc then uses clone); clone that makes a thread
    always, and any clone or fork in a worker; mmap with MAP_SHARED; in a worker, the calls that act
    on another process unless their pid argument is 0 (itself), and lock / lease / dnotify fcntl
    commands; allow the rest."""
    deny = set(_DENY_X86_64.values())
    if no_process:
        deny |= set(_FORK_X86_64.values()) | set(_WORKER_DENY_X86_64.values())
    deny = sorted(deny)
    LD, RET = _BPF_LD_W_ABS, _BPF_RET_K
    code = [(LD, 0, 0, 4),                                   # seccomp_data.arch
            (_BPF_JEQ_K, 0, "DENY", _AUDIT_ARCH_X86_64),
            (LD, 0, 0, 0),                                   # seccomp_data.nr
            (_BPF_JGE_K, "DENY", 0, _X32_BIT)]
    code += [(_BPF_JEQ_K, "DENY", 0, nr) for nr in deny]
    code.append((_BPF_JEQ_K, "ENOSYS", 0, _SYS_CLONE3))
    if no_process:
        code.append((_BPF_JEQ_K, "DENY", 0, _SYS_CLONE))
        for _name, nr, arg in _WORKER_SELF_ONLY_X86_64:     # only on itself
            code += [(_BPF_JEQ_K, 0, 3, nr),
                     (LD, 0, 0, 16 + 8 * arg),               # args[arg], low word
                     (_BPF_JEQ_K, 0, "DENY", 0),
                     (LD, 0, 0, 0)]
        code += [(_BPF_JEQ_K, 0, 1 + len(_WORKER_FCNTL_DENY) + 1, _SYS_FCNTL),
                 (LD, 0, 0, 16 + 8 * 1)]                     # fcntl's command
        code += [(_BPF_JEQ_K, "DENY", 0, cmd) for cmd in _WORKER_FCNTL_DENY]
        code.append((LD, 0, 0, 0))
    else:
        code += [(_BPF_JEQ_K, 0, 3, _SYS_CLONE),             # clone: look at its flags
                 (LD, 0, 0, 16),                             # args[0], low word
                 (_BPF_JSET_K, "DENY", 0, _CLONE_THREAD),
                 (LD, 0, 0, 0)]
    code += [(_BPF_JEQ_K, 0, 3, _SYS_MMAP),                  # mmap: look at its flags
             (LD, 0, 0, 16 + 8 * 3),                         # args[3], low word
             (_BPF_JSET_K, "DENY", 0, _MAP_SHARED),
             (LD, 0, 0, 0),
             (RET, 0, 0, _RET_ALLOW)]
    exits = {"DENY": len(code), "ENOSYS": len(code) + 1}
    out = b""
    for pos, (op, jt, jf, k) in enumerate(code):
        jt = exits[jt] - pos - 1 if isinstance(jt, str) else jt
        jf = exits[jf] - pos - 1 if isinstance(jf, str) else jf
        if not (0 <= jt < 256 and 0 <= jf < 256):
            raise ValueError("seccomp program too long for 8-bit jumps")
        out += _ins(op, jt, jf, k)
    out += _ins(RET, 0, 0, _RET_ERRNO | errno.EPERM)
    out += _ins(RET, 0, 0, _RET_ERRNO | errno.ENOSYS)
    return out


_PROGRAMS: dict = {}


class _SockFprog(ctypes.Structure):
    _fields_ = [("len", ctypes.c_ushort), ("filter", ctypes.c_void_p)]


_BUILT: dict = {}


def prepare() -> None:
    """Build both BPF programs and their ctypes structures now (the launcher calls this once; its
    workers inherit them, so a worker only makes the two prctl calls)."""
    for flag in (False, True):
        _PROGRAMS[flag] = prog = _program(flag)
        buf = ctypes.create_string_buffer(prog, len(prog))
        _BUILT[flag] = (buf, _SockFprog(len(prog) // 8, ctypes.cast(buf, ctypes.c_void_p)))
    _BUILT["libc"] = _libc()


def _seccomp(no_process: bool) -> dict:
    if platform.system() != "Linux" or platform.machine() not in ("x86_64", "AMD64"):
        return {"seccomp": f"not applied (only built for Linux x86_64; this is {platform.system()} {platform.machine()})"}
    libc = _BUILT.get("libc") or _libc()
    if no_process in _BUILT:
        _fbuf, fp = _BUILT[no_process]
    else:
        prog = _program(no_process)
        fbuf = ctypes.create_string_buffer(prog, len(prog))
        fp = _SockFprog(len(prog) // 8, ctypes.cast(fbuf, ctypes.c_void_p))
    if libc.prctl(_PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) != 0:
        return {"seccomp": f"no_new_privs failed (errno {ctypes.get_errno()})"}
    if libc.prctl(_PR_SET_SECCOMP, _SECCOMP_MODE_FILTER, ctypes.byref(fp), 0, 0) != 0:
        return {"seccomp": f"filter refused (errno {ctypes.get_errno()})"}
    return {"seccomp": ("worker: no processes, threads, pipes or signals; no access to another process's limits, "
                        "priority or scheduling; no file locks, file watches or page-cache probes; " if no_process
                        else "no threads; ")
                       + "no sockets, IPC, shared memory, key rings, ptrace, exec, xattrs or file metadata changes"}


def apply_launcher(read_dirs: list) -> dict:
    """Called once by the trusted launcher, after it has loaded everything it needs and before
    the first fork: Landlock (read-only `read_dirs`) + seccomp (launcher profile) + child
    subreaper (an orphaned grandchild comes back to the launcher, so none can hide)."""
    rep = {"platform": f"{platform.system()} {platform.release()} {platform.machine()}"}
    try:
        _libc().prctl(_PR_SET_CHILD_SUBREAPER, 1, 0, 0, 0)
    except Exception:
        pass
    rep.update(_landlock(read_dirs, []))
    rep.update(_seccomp(no_process=False))
    return rep


def apply_worker(mem_limit: int | None = None) -> dict:
    """Called by each per-call worker right after the fork, before any entry code runs: no new
    process or thread, no core file, a memory ceiling (rlimits, set before seccomp forbids changing
    them), then the worker's seccomp profile, on top of everything the launcher has."""
    rep = {}
    try:
        resource.setrlimit(resource.RLIMIT_NPROC, (0, 0))
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        if mem_limit:
            resource.setrlimit(resource.RLIMIT_AS, (int(mem_limit), int(mem_limit)))
        rep["rlimit"] = "no new processes (RLIMIT_NPROC 0), no core file" + (
            f", at most {mem_limit / (1 << 30):.1f} GB of address space" if mem_limit else "")
    except (ValueError, OSError) as e:
        rep["rlimit"] = f"not applied ({e})"
    rep.update(_seccomp(no_process=True))
    return rep
