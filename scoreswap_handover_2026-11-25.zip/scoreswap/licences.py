"""What the release pack may carry for each stream (task set) and each model's answers, and why.

Everyday picture: a garage may lend out its own notebook of repair tips, but a tip that copies a
page from a car maker's manual can only be lent if the maker's licence allows it, and a tip that
holds a mechanic's own words only if that mechanic's contract allows it.

A memory item is the text of one write task plus the owner model's answer. Releasing it releases
text derived from the task set AND a model output, so two permissions are needed:

- the task set's licence (read at its source on 24 Nov 2026, pages saved under
  tools/ledger_evidence/pages/; the paper's licence appendix, A3, says the same):
  DDXPlus: CC BY 4.0 (its figshare record; its repository README says CC BY). Copying and
  adapting are allowed, also commercially, with attribution.
  BIRD: CC BY-SA 4.0 (the benchmark's site announced on 27 Apr 2024 that the data licence changed
  to CC BY-SA 4.0, replacing the CC BY-NC 4.0 of the dataset paper's datasheet; its Hugging Face
  cards say CC BY-SA 4.0). Copying and adapting are allowed with attribution, and a file that holds
  BIRD text must carry the same licence (ShareAlike). The pack releases no database values.
  Both were taken through StreamBench, whose dataset card states no licence of its own; the
  licence of the source data applies.
- the model's output terms: simulated models (written by this project's code) and open-weight
  models whose model card licence allows it (Mistral Small: Apache-2.0; DeepSeek V4.1-Flash: MIT)
  may have their answers released; every other maker's terms (Anthropic, OpenAI, Qwen, Gemma) are
  NOT yet checked, so their answers are not released (ids and sha256 hashes only).

Task text (the probe task as the model sees it with no item) needs the task set's licence only.
Item text needs both, and is written only for PUBLIC banks: a private bank's text is never
released while the pack is in use. Turn an output-terms entry on only after the terms are read at
their source and logged in paper/reference_ledger.md.
"""
from __future__ import annotations

#: Per stream: whether derived task and item text may be released, the licence, what the pack
#: releases, and the reason. Read by the exporter (one licence file per stream).
STREAMS = {
    "ddxplus": {
        "text_allowed": True,
        "source": "DDXPlus (Fansi Tchango et al. 2022), taken through StreamBench (Wu et al. 2024)",
        "licence": "CC BY 4.0 (stated on the dataset's figshare record; its repository README says it is released "
                   "under CC BY; read at the source on 24 Nov 2026). The StreamBench dataset card states no licence "
                   "of its own; the source data's licence applies.",
        "allows": "copying, redistributing and adapting the data, also commercially, with attribution to the "
                  "DDXPlus authors and a note of the changes (the probe text is the patient profile put into the "
                  "study's prompt).",
        "released": "task ids, item ids, the sha256 of each item's text, scores, counts, selection probabilities, "
                    "relevance and graded results (1 or 0); the probe tasks' text; the text of the items of PUBLIC "
                    "banks whose owner's output terms allow it.",
        "why": "CC BY 4.0 allows it with attribution; an item also holds a model's answer, so its text is released "
               "only where that model's output terms allow it.",
        "attribution": "Fansi Tchango, A., Goel, R., Wen, Z., Martel, J., Ghosn, J. (2022). DDXPlus: A New Dataset For "
                       "Automatic Medical Diagnosis. NeurIPS Datasets and Benchmarks. Licence CC BY 4.0.",
    },
    "bird": {
        "text_allowed": True,
        "source": "BIRD (Li et al. 2023), taken through StreamBench (Wu et al. 2024)",
        "licence": "CC BY-SA 4.0 (the benchmark's site announced on 27 Apr 2024 that the data licence changed to "
                   "CC BY-SA 4.0, replacing the CC BY-NC 4.0 of the dataset paper's datasheet; its Hugging Face cards "
                   "say CC BY-SA 4.0; read at the source on 24 Nov 2026).",
        "allows": "copying, redistributing and adapting the data, also commercially, with attribution, provided "
                  "that what is shared carries the same licence (ShareAlike).",
        "released": "task ids, item ids, the sha256 of each item's text, scores, counts, selection probabilities, "
                    "relevance and graded results (1 or 0); the probe tasks' text (question and table schema, no "
                    "database values); the text of the items of PUBLIC banks whose owner's output terms allow it. "
                    "Every file of this pack that holds BIRD text (task_texts/bird__*.csv and the items.csv of a bird "
                    "bank with a text column) is licensed CC BY-SA 4.0.",
        "why": "CC BY-SA 4.0 allows it with attribution and ShareAlike; database values are left out.",
        "attribution": "Li, J. et al. (2023). Can LLM Already Serve as A Database Interface? A BIg Bench for Large-Scale "
                       "Database Grounded Text-to-SQLs (BIRD). NeurIPS Datasets and Benchmarks. Licence CC BY-SA 4.0.",
    },
    "ds1000": {
        "text_allowed": False,
        "source": "DS-1000 (contingency second stream)",
        "licence": "Not yet recorded in this project.",
        "allows": "unknown",
        "released": "task ids, item ids, the sha256 of each item's text, scores, counts, selection "
                    "probabilities, relevance and graded results (1 or 0). No text.",
        "why": "No licence fact has been checked and logged for this stream.",
        "attribution": "",
    },
}

#: Used for a stream that is not listed above: the safe default.
UNKNOWN = {
    "text_allowed": False,
    "source": "unknown task set",
    "licence": "Not recorded.",
    "allows": "unknown",
    "released": "ids, text hashes, scores, counts, probabilities, relevance and graded results. No text.",
    "why": "A stream with no recorded licence never carries text.",
    "attribution": "",
}

#: Whose answers may be released as text: by provider, then by model family (config/models.yaml).
OUTPUT_TERMS_BY_PROVIDER = {
    "sim": (True, "simulated model: its answers are written by this project's code"),
}
OUTPUT_TERMS_BY_FAMILY = {
    "mistral": (True, "Mistral Small model card: Apache-2.0"),
    "deepseek": (True, "DeepSeek V4.1-Flash model card: MIT"),
}
OUTPUT_TERMS_DEFAULT = (False, "the maker's terms on publishing model outputs are not yet checked")


def licence_of(stream: str) -> dict:
    """The licence entry of a stream (the safe default for an unknown stream)."""
    return dict(STREAMS.get(stream, UNKNOWN))


def text_allowed(stream: str) -> bool:
    return bool(licence_of(stream)["text_allowed"])


def output_terms(st, model: str) -> tuple:
    """(allowed, why) for releasing a model's answers as text."""
    cfg = (st.models_cfg.get("models", {}).get(model, {}) or {}) if st is not None else {}
    prov = cfg.get("provider")
    if prov in OUTPUT_TERMS_BY_PROVIDER:
        return OUTPUT_TERMS_BY_PROVIDER[prov]
    fam = st.family(model) if st is not None else None
    return OUTPUT_TERMS_BY_FAMILY.get(fam, OUTPUT_TERMS_DEFAULT)


def outputs_allowed(st, model: str) -> bool:
    return bool(output_terms(st, model)[0])


def licence_text(stream: str, st=None) -> str:
    """The plain-text licence file written into the release pack for one stream."""
    e = licence_of(stream)
    lines = [f"Stream: {stream}",
             f"Source: {e['source']}",
             f"Licence: {e['licence']}",
             f"What the licence allows: {e['allows']}",
             f"Task text in this pack: {'yes' if e['text_allowed'] else 'no (ids and sha256 hashes only)'}",
             f"What this pack releases for this stream: {e['released']}",
             f"Why: {e['why']}"]
    if e.get("attribution"):
        lines.append(f"Attribution: {e['attribution']}")
    if st is not None:
        lines.append("Item text (each item holds a model's answer), by owner model:")
        for m in st.models:
            ok, why = output_terms(st, m)
            lines.append(f"  {m}: {'may be released' if ok else 'not released'} ({why})")
        lines.append("  A private owner's items are never released while the pack is in use, whatever the terms.")
    lines.append("The benchmark's code has its own licence (licences/README.txt); this file covers the data of this "
                 "stream only.")
    return "\n".join(lines) + "\n"


def pack_licence_text(st=None) -> str:
    """licences/README.txt: the licence of each part of the pack."""
    return ("Licences of this pack, part by part\n"
            "\n"
            "- Data taken from a task set (task text, item text, task ids): the task set's licence, see "
            "<stream>.txt in this folder. A file that holds BIRD text is licensed CC BY-SA 4.0 (ShareAlike).\n"
            "- Model answers inside item text: released only for models whose output terms allow it (listed per "
            "model in <stream>.txt); the others appear as ids and sha256 hashes only.\n"
            "- Everything this project made (scores, counts, selection probabilities, relevance values, graded "
            "results, manifest, schema, datasheet, Croissant metadata): CC BY 4.0.\n"
            "- The scoring code (scoreswap/ and msr/): the licence of the public code release, chosen at the "
            "de-anonymised release; during anonymous review it is shared for reviewing only.\n"
            "Cite the source task sets as given in <stream>.txt, and the ScoreSwap paper.\n")
