"""The pack's datasheet (DATASHEET.md) and its Croissant metadata (croissant.json).

Everyday picture: a jar of jam carries a label: what is inside, where it came from, how it was
made, how long it keeps and who may sell it. DATASHEET.md is that label for people, written with
the question groups of "Datasheets for Datasets" (Gebru et al.); croissant.json is the same label
for machines (MLCommons Croissant 1.0, JSON-LD), so a dataset search or loader can find every file
and column of the public pack.

    write_all(out, manifest, st)          called by scoreswap.export once the public pack is written
    datasheet_text(out, manifest, st)     -> the text of DATASHEET.md
    croissant(out, manifest)              -> the croissant.json document (a dict)

Both are made from the manifest and the files on disk, so they are right for any pack (a practice
pack of simulated models or a real one). Neither names a private owner: the private side is given
as a count. Neither touches manifest.json; the exporter rewrites it afterwards so that it lists
these two files with their sha256.
"""
from __future__ import annotations

import csv
import json
import re
import textwrap
from pathlib import Path

from scoreswap import export as EX
from scoreswap import licences as LIC

DATASHEET = "DATASHEET.md"
CROISSANT = "croissant.json"
WIDTH = 100

#: The standard Croissant 1.0 context (as in the specification's examples).
CONTEXT = {
    "@language": "en",
    "@vocab": "https://schema.org/",
    "sc": "https://schema.org/",
    "cr": "http://mlcommons.org/croissant/",
    "rai": "http://mlcommons.org/croissant/RAI/",
    "dct": "http://purl.org/dc/terms/",
    "citeAs": "cr:citeAs",
    "column": "cr:column",
    "conformsTo": "dct:conformsTo",
    "data": {"@id": "cr:data", "@type": "@json"},
    "dataType": {"@id": "cr:dataType", "@type": "@vocab"},
    "examples": {"@id": "cr:examples", "@type": "@json"},
    "extract": "cr:extract",
    "field": "cr:field",
    "fileProperty": "cr:fileProperty",
    "fileObject": "cr:fileObject",
    "fileSet": "cr:fileSet",
    "format": "cr:format",
    "includes": "cr:includes",
    "isLiveDataset": "cr:isLiveDataset",
    "jsonPath": "cr:jsonPath",
    "key": "cr:key",
    "md5": "cr:md5",
    "parentField": "cr:parentField",
    "path": "cr:path",
    "recordSet": "cr:recordSet",
    "references": "cr:references",
    "regex": "cr:regex",
    "repeated": "cr:repeated",
    "replace": "cr:replace",
    "separator": "cr:separator",
    "source": "cr:source",
    "subField": "cr:subField",
    "transform": "cr:transform",
}
CC_BY = "https://creativecommons.org/licenses/by/4.0/"
CITE_AS = "ScoreSwap benchmark pack (anonymous submission)"
ENCODING = {".csv": "text/csv", ".json": "application/json", ".md": "text/markdown", ".txt": "text/plain",
            ".npz": "application/octet-stream"}

KIND_WORDS = {"home": "home", "same_maker_upgrade": "upgrade", "same_maker_downgrade": "downgrade",
              "same_maker_other": "same-maker other", "cross_maker": "cross-maker"}
KIND_MEANING = ("home: a model reads its own bank; upgrade: the same maker's newer model reads an older one's bank; "
                "downgrade: the reverse; same-maker other: two models of one maker that are not an old-to-new pair; "
                "cross-maker: a model reads another maker's bank")
STRATUM_WORDS = {"extension": "makers of the extension pairs", "closed": "closed-weight makers",
                 "open": "open-weight makers", "other": "other makers (simulated or unknown)"}
GRADING = {"ddxplus": "the diagnosis in the answer is matched against the dataset's label",
           "bird": "the SQL query in the answer is run on a read-only copy of the database and its result is "
                   "compared with the gold query's result"}

#: What each column means, per kind of CSV (short sentences taken from SCHEMA.md).
MEANING = {
    "results": {
        "file": "The file the row comes from: calibration_results.csv (the check pool) or dev_results.csv "
                "(the scored tasks).",
        "owner": "The model whose bank was read (the bank's owner).",
        "reader": "The model that answered the probe task.",
        "stream": "The task set the probe task comes from.",
        "order": "The stream order: the seed of one shuffle of the stream's tasks.",
        "task_id": "The probe task.",
        "position": "The candidate's place (0 to 3) in the owner's retrieval order; empty when no item was shown.",
        "item_id": "The item shown; empty when no item was shown.",
        "set": "regular (repeats 1-2), extra_home (home cells only, repeats 3-4) or no_item.",
        "repeat": "The repeat number within its set, in run order.",
        "result": "The reader's result, graded by a program: 1 right, 0 wrong.",
    },
    "items": {
        "bank": "The bank, <owner>__<stream>__order<k>, taken from the folder name.",
        "item_id": "The item's id: <write task id>@<owner>.",
        "write_task_id": "The write task whose text and answer form the item.",
        "text_sha256": "The sha256 of the item's text (UTF-8).",
        "text": "The item's text (only where the licences allow it).",
        "visits": "How often the item was shown in the score phase.",
        "showings": "Rows of this item in showings.csv (equals visits).",
    },
    "showings": {
        "bank": "The bank, <owner>__<stream>__order<k>, taken from the folder name.",
        "pass": "The score pass (0, 1, 2, ...) over the score tasks.",
        "position": "The task's place in the score-task list.",
        "task_id": "The score task.",
        "item_id": "The item shown.",
        "selection_probability": "The logged chance the build's rule had of showing this item.",
        "explored": "1 if the item was picked by exploration, 0 if by the mix of score and relevance.",
        "result": "The owner's graded result with the item shown: 1 right, 0 wrong.",
        "owner_tag": "The owner's own tag of the item: helpful, harmful or neutral.",
        "no_memory_result": "The owner's result on the same task with no item: 1 right, 0 wrong (written as a "
                            "float), empty if none.",
    },
    "candidates": {
        "bank": "The bank, <owner>__<stream>__order<k>, taken from the file name.",
        "task_id": "The probe task.",
        "role": "calibration (fresh checks come only from these) or evaluation (every number is computed on these).",
        "position": "The candidate's place (0 to 3) in the owner's retrieval order.",
        "item_id": "The candidate item.",
        "relevance": "The cosine similarity of the task and the item (raw scale).",
    },
    "task_texts": {
        "stream_order": "The stream and order, <stream>__order<k>, taken from the file name.",
        "task_id": "The probe task.",
        "text": "The task as the model saw it with no item shown.",
    },
}
#: Columns that hold ids or words, whatever their values look like.
TEXT_COLUMNS = {"owner", "reader", "stream", "task_id", "item_id", "set", "write_task_id", "text_sha256", "text",
                "role", "owner_tag", "file", "bank", "stream_order"}
#: The type of a column (or of a family column's last part) when none of its cells holds a value.
NUMERIC = {"order": "sc:Integer", "position": "sc:Integer", "repeat": "sc:Integer", "result": "sc:Integer",
           "visits": "sc:Integer", "showings": "sc:Integer", "pass": "sc:Integer", "explored": "sc:Integer",
           "successes": "sc:Integer", "failures": "sc:Integer", "helpful": "sc:Integer", "harmful": "sc:Integer",
           "selection_probability": "sc:Float", "relevance": "sc:Float", "no_memory_result": "sc:Float",
           "q": "sc:Float", "credit": "sc:Float", "score": "sc:Float", "mix_score": "sc:Float", "p": "sc:Float"}
FAMILY_COUNT = {"q": "the moving average of the grade",
                "visits": "how often the item was shown",
                "successes": "graded successes with the item shown",
                "failures": "graded failures with the item shown",
                "credit": "the mean over showings of (result with the item minus the owner's no-item result)"}


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------


def _para(text: str) -> list:
    return textwrap.wrap(text, WIDTH, break_on_hyphens=False) + [""]


def _bullet(text: str) -> list:
    return textwrap.wrap(text, WIDTH, initial_indent="- ", subsequent_indent="  ", break_on_hyphens=False)


def _join(xs) -> str:
    xs = [str(x) for x in xs]
    if not xs:
        return "none"
    return xs[0] if len(xs) == 1 else ", ".join(xs[:-1]) + " and " + xs[-1]


def _n(n: int, one: str, many: str | None = None) -> str:
    return f"{n:,} {one if n == 1 else (many or one + 's')}"


def _rows(path: Path) -> int:
    """Data rows of a CSV file (a quoted cell may hold a line break)."""
    with open(path, encoding="utf-8", newline="") as fh:
        return max(sum(1 for _ in csv.reader(fh)) - 1, 0)


def _header(path: Path) -> list:
    with open(path, encoding="utf-8", newline="") as fh:
        return next(csv.reader(fh), [])


def _range(values) -> str:
    values = list(values)
    if not values:
        return "0"
    lo, hi = min(values), max(values)
    return f"{lo:,}" if lo == hi else f"{lo:,} to {hi:,}"


def _kinds(by_kind: dict) -> str:
    parts = [f"{by_kind[k]} {KIND_WORDS.get(k, k)}" for k in KIND_WORDS if by_kind.get(k)]
    parts += [f"{v} {k}" for k, v in by_kind.items() if k not in KIND_WORDS and v]
    return f"{sum(by_kind.values())} ({', '.join(parts)})" if parts else "0"


def _facts(out: Path, manifest: dict) -> dict:
    """Counts read from the files on disk."""
    out = Path(out)
    items = sorted((out / "banks").glob("*/items.csv"))
    shows = sorted((out / "banks").glob("*/showings.csv"))
    cands = sorted((out / "candidates").glob("*.csv"))
    texts = sorted((out / "task_texts").glob("*.csv"))
    refs = sorted((out / EX.REFERENCE_DIR).rglob("*.npz")) if (out / EX.REFERENCE_DIR).exists() else []
    results = {name: _rows(out / name) for name in (EX.CALIB_FILE, EX.DEV_FILE) if (out / name).exists()}
    bird_text = [p for p in texts if p.name.startswith("bird__")]
    bird_text += [p for p in items if "__bird__order" in p.parent.name and "text" in _header(p)]
    return {"items": items, "items_rows": {p.parent.name: _rows(p) for p in items},
            "showings": shows, "showings_rows": sum(_rows(p) for p in shows),
            "candidates": cands, "candidates_rows": sum(_rows(p) for p in cands),
            "task_texts": texts, "references": refs, "results": results,
            "bird_text": sorted(p.relative_to(out).as_posix() for p in bird_text)}


def _simulated(st) -> tuple:
    """(number of simulated models, number of models)."""
    cfg = (getattr(st, "models_cfg", None) or {}).get("models", {})
    return sum(1 for m in st.models if (cfg.get(m) or {}).get("provider") == "sim"), len(st.models)


# ---------------------------------------------------------------------------
# DATASHEET.md
# ---------------------------------------------------------------------------


def datasheet_text(out: Path, manifest: dict, st) -> str:
    """The text of DATASHEET.md for the public pack in `out` (counts from the manifest and the files)."""
    out = Path(out)
    f = _facts(out, manifest)
    split = manifest.get("owner_split", {})
    settings = manifest.get("settings", {})
    text = manifest.get("text", {})
    exposure = split.get("exposure", {})
    models = manifest.get("models", [])
    makers = sorted({m["maker"] for m in models})
    public = list(split.get("public_owners", []))
    n_private = len(models) - len(public)
    streams, orders = list(manifest.get("streams", [])), list(manifest.get("orders", []))
    fit = list(settings.get("budgets_that_fit", []))
    registered = list(settings.get("budgets_registered", EX.BUDGETS))
    n_sim, n_models = _simulated(st)
    all_sim = n_sim == n_models
    version = manifest.get("version", {}).get("pack", "")
    k_example = 16 if 16 in fit else (max(fit) if fit else 0)
    b = getattr(st, "build", None)
    pr = getattr(st, "probe", None)
    L = [f"# Datasheet: ScoreSwap pack `{version}`", ""]
    L += _para(f"Written for the pack `{version}` (study `{manifest.get('study')}`, format "
               f"`{manifest.get('format')}`, made on {str(manifest.get('created', ''))[:10]}). Every count below "
               "was read from this pack's manifest.json and files. Canary string, so that a copy in a training "
               f"corpus can be found: `{manifest.get('canary', EX.CANARY)}`")

    L += ["## What this pack is", ""]
    L += _para("A garage keeps a box of repair tips. Each tip has a score: how often it helped while one mechanic "
               "worked there. Then a new mechanic arrives. Are the old scores still right for the newcomer? This "
               "pack is the garage's written record: every tip with its score and how the score was earned, and "
               "how every mechanic did with every tip on a set of test jobs. In the study the mechanics are "
               "language models" + (" (simulated ones in this pack)" if all_sim else "") + ", the tips are "
               "memory items written by one model (the owner), and the test jobs are probe tasks answered by a "
               "model (the reader) with one item shown.")
    L += _para("With these frozen tables anyone can test, offline and without calling any model, a \"swap-day "
               "rule\" (what to do with the old scores on the day the model changes) or a \"score type\" (a new "
               "way to compute the scores in the first place):")
    L += ["```", "python -m scoreswap describe --pack <this folder>",
          "python -m scoreswap check my_rule.py --pack <this folder>",
          f"python -m scoreswap score my_rule.py --pack <this folder> --budget {k_example}",
          "python -m scoreswap leaderboard my_entries/ --pack <this folder>", "```", ""]
    L += _para("This public pack is the development board. The ranked board is held and run by the maintainers "
               "(see \"The two boards\"). SCHEMA.md says what every file and column holds.")

    L += ["## Composition", ""]
    sim_words = ("all are simulated" if all_sim else "none is simulated" if not n_sim else
                 f"{n_sim} of them {'is' if n_sim == 1 else 'are'} simulated")
    n_pairs = len(manifest.get("upgrade_pairs", []))
    L += _bullet(f"Models: {_n(len(models), 'model')} from {_n(len(makers), 'maker')}, with "
                 f"{_n(n_pairs, 'old-to-new upgrade pair')}; {sim_words}. Every model wrote banks of items (it is "
                 "an owner) and read every bank (it is a reader).")
    pmk = split.get("public_makers", [])
    L += _bullet(f"Public owners ({len(public)}): {_join(f'`{m}`' for m in public)}, from the "
                 f"{'maker' if len(pmk) == 1 else 'makers'} {_join(f'`{m}`' for m in pmk)}. Their banks are in "
                 "this pack. " + ("The other owner is private: no bank, score, log, text or result of its"
                                  if n_private == 1 else
                                  f"The other {n_private} owners are private: no bank, score, log, text or result "
                                  "of theirs") + " is in this pack.")
    L += _bullet(f"Streams (task sets): {_join(f'`{s}`' for s in streams)}. Orders (seeded shuffles of each "
                 f"stream's tasks): {_join(orders)}.")
    sizes = {(s, d): split.get("sizes", {}).get(f"{s}|{d}", {}) for s in streams for d in orders}
    shapes = {(z.get("calibration"), z.get("evaluation")) for z in sizes.values()}
    if len(shapes) == 1:
        c, e = next(iter(shapes))
        L += _bullet(f"Probe tasks per stream and order: {c} calibration tasks (the check pool fresh checks come "
                     f"from) and {e} evaluation tasks (every number is computed on these).")
    else:
        L += _bullet("Probe tasks (calibration + evaluation): " + "; ".join(
            f"`{s}` order {d}: {z.get('calibration')} + {z.get('evaluation')}" for (s, d), z in sizes.items())
            + ". Fresh checks come only from calibration tasks; every number is computed on evaluation tasks.")
    L += _bullet(f"Banks in this pack: {len(f['items'])} (one per public owner, stream and order); items per "
                 f"bank: {_range(f['items_rows'].values())}; {settings.get('candidates_per_task', 4)} candidate "
                 f"items per probe task ({f['candidates_rows']:,} candidate rows); {f['showings_rows']:,} logged "
                 "showings of the score phase.")
    boards = split.get("boards", {})
    L += _bullet("Cells (one owner's bank read by one reader): development board "
                 f"{_kinds(boards.get('dev', {}).get('cells_by_kind', {}))}; ranked board "
                 f"{_kinds(boards.get('test', {}).get('cells_by_kind', {}))}. ({KIND_MEANING}.)"
                 + (f" {_n(len(manifest['cells_left_out']), 'cell')} left out because a probe was missing."
                    if manifest.get("cells_left_out") else ""))
    L += _bullet("Result rows: " + "; ".join(f"{name}: {n:,}" for name, n in f["results"].items()) + ".")
    L += _bullet(f"Budgets of fresh checks that fit the check pool ({settings.get('calibration_pool_cells', 0):,} "
                 f"cells per bank): {_join(fit)} (registered: {_join(registered)}).")
    tts, itb = text.get("task_text_streams", []), text.get("item_text_banks", [])
    L += _bullet("Text: " + (f"probe task text for {_join(f'`{s}`' for s in tts)}" if tts else "no task text")
                 + "; " + (f"item text for {_n(len(itb), 'public owner and stream pair')}" if itb else
                           "no item text") + ". Every item has the sha256 of its text.")
    if manifest.get("reference"):
        ref = manifest["reference"]
        L += _bullet(f"The paper's own rules on the development board, for the family `{ref.get('family')}`: "
                     f"{len(f['references'])} file(s) under reference/.")
    L.append("")

    L += ["## How it was collected", ""]
    write_n, score_n = getattr(b, "n_write", None), getattr(st, "n_score", None)
    L += _para(f"For each stream and order the tasks were shuffled with the order's seed and cut into write tasks"
               + (f" ({write_n})" if write_n else "") + ", score tasks" + (f" ({score_n})" if score_n else "")
               + " and probe tasks. Write phase: each owner answered the same write tasks with no memory; each "
               "task with its answer became one item, and the items were then frozen. Score phase: the owner "
               f"answered the score tasks in {getattr(b, 'epochs', '?')} passes with "
               f"{_n(getattr(b, 'n_show', 1), 'item')} shown per task, chosen by a mix of score and relevance with "
               f"a {getattr(b, 'epsilon', '?')} chance of a random candidate; every showing was logged "
               "(showings.csv) and the scores were updated after every task.")
    rep, ni = getattr(pr, "repeats", 2), getattr(pr, "no_memory_repeats", 2)
    extra = getattr(pr, "home_extra_repeats", 0)
    L += _para(f"Probe phase: every reader answered every probe task with each of the "
               f"{settings.get('candidates_per_task', 4)} candidate items shown, {_n(rep, 'repeat')} each, and "
               f"with no item, {_n(ni, 'repeat')}" + (f"; home cells got {extra} more repeats, run later" if extra
                                                      else "") + ". Every answer was graded by a program: "
               + "; ".join(f"for `{s}`, {GRADING.get(s, 'a program compares the answer with the reference')}"
                           for s in streams) + ". A call is never repeated because its answer was wrong. "
               f"Relevance is the cosine similarity of task and item under the embedding model "
               f"`{getattr(st, 'embedding_model', '?')}`.")
    if all_sim:
        L += _para("Every model of this pack is simulated: a small program with a known truth answers in the "
                   "format the grader accepts. No language model was called, so the numbers test the tools and "
                   "say nothing about real models.")
    elif n_sim:
        L += _para(f"{n_sim} of the {n_models} models are simulated (a program with a known truth); the others "
                   "are language models called through their providers' services, with reasoning switched off.")
    else:
        L += _para("The models are language models called through their providers' services, with reasoning "
                   "switched off, one call per task and no tools.")

    L += ["## Preprocessing", ""]
    excl = list(getattr(st, "exclude_tasks", ()) or ())
    L += _bullet(("No task was removed." if not excl else
                  f"{_n(len(excl), 'task')} removed before the tasks were cut (listed in the study file).")
                 + " Task ids are the stream's own; an item's id is `<write task id>@<owner>`; a bank is named "
                 "`<owner>__<stream>__order<k>`.")
    L += _bullet("Each item's text is kept as the sha256 of its UTF-8 bytes; the text itself only where the "
                 "licences allow it.")
    L += _bullet("Every number is copied from the study's records, never recomputed, except the per-family score "
                 "columns (score, mix score, predicted success), which the paper's engine computes from the "
                 "stored counts exactly as the paper's evaluation does.")
    L += _bullet("Floats are written in Python's shortest exact form, so reading them back gives the same bits; "
                 "truth values are 1 or 0; a missing value is an empty cell. Repeats are numbered 1, 2 (3, 4 for "
                 "the extra home repeats) in the order they were run.")
    L.append("")

    L += ["## The two boards", ""]
    strata = split.get("strata", {})
    L += _para("Whole banks are held out. The owners are split, a whole maker at a time, into a public side and "
               "a private side. The public owners' banks and every reader's results on them are in this pack: "
               "the development board. The private owners' banks, every reader's results on them and the secret "
               "seed of the ranked board's random checks are held by the maintainers: the ranked board, which "
               "they run for submitted entries. Every probe task of a bank belongs to its owner's board.")
    L += _para(f"The split is a seeded, stratified draw (seed {split.get('seed')}; strata: "
               + _join(f"{STRATUM_WORDS.get(g, g)}: {len(v)}" for g, v in sorted(strata.items()))
               + "). The full rule is in manifest.json, \"owner_split\". The list of private owners is committed "
               "by a sha256, and so is every file of the private folder "
               f"({_n(len(manifest.get('private', {}).get('files', [])), 'file')}, manifest.json \"private\"), "
               "so anyone can check, when the pack is retired, that nothing was changed after export.")

    L += ["## Uses and misuses", ""]
    L += _para("Made for research on memory scores, swap-day rules and model swaps: it measures how well a rule "
               "orders the stored candidates for a new reader (first-shown success, regret, log score, value kept) "
               "at the budgets that fit. It cannot score, offline (these need new model calls):")
    for x in ("rules that change an item's text;", "rules that show more than one item at a time, or no item;",
              f"rules that look beyond the {settings.get('candidates_per_task', 4)} stored candidates of a task;",
              "rules that need more than two checks of the same task and item;",
              "rules that call a model themselves;",
              "a new reader or a new owner (each needs its own runs on every bank)."):
        L += _bullet(x)
    L.append("")
    L += _para("A development number is never a ranking: everything on the development board is public. A ranked "
               "number means \"fresh checks plus what is public about the items\". Not for: any clinical use; "
               "ranking models for deployment outside the tested settings; judging the content of memory items.")

    L += ["## Licences", ""]
    lic = manifest.get("licences", {})
    for s in streams:
        e = lic.get(s) or LIC.licence_of(s)
        L += _bullet(f"`{s}`: {e.get('licence')} Allows {e.get('allows')}"
                     + (f" Attribution: {e['attribution']}" if e.get("attribution") else ""))
    L += _bullet("Files that hold BIRD text are licensed CC BY-SA 4.0 (ShareAlike); this pack has "
                 f"{_n(len(f['bird_text']), 'such file')}.")
    by_terms: dict = {}
    for m in public:
        by_terms.setdefault(tuple(LIC.output_terms(st, m)), []).append(f"`{m}`")
    terms = [f"{_join(ms)}: {'may be released' if ok else 'not released'} ({why})"
             for (ok, why), ms in by_terms.items()]
    L += _bullet("Model outputs: an item holds its owner's answer, so its text is released only where the owner's "
                 f"output terms allow it. {'; '.join(terms)}. The other owners' items are never released while "
                 "the pack is in use.")
    L += _bullet("Everything this project made (scores, counts, selection probabilities, relevance, graded "
                 "results, manifest, schema, this datasheet, the Croissant file): CC BY 4.0.")
    L += _bullet("The scoring code: the licence chosen at the de-anonymised release; during anonymous review it is "
                 "shared for reviewing only. Per-stream details are in licences/.")
    L.append("")

    L += ["## Known limits", ""]
    shared = exposure.get("shared_write_tasks", {})
    L += _bullet("Every owner wrote on the same write tasks and every bank has the same probe tasks and the same "
                 "candidate lists. So public results on other owners' items from the same write task are visible, "
                 "and a rule can use them for a private item (manifest.json, \"exposure\", \"shared_write_tasks\")."
                 if shared else "Every owner wrote on the same write tasks.")
    ni_pub = exposure.get("reader_no_item_results_public", {})
    if ni_pub:
        L += _bullet("A reader's no-item results do not depend on the bank, so they are public for every probe "
                     f"task: {ni_pub.get('with_the_same_no_item_runs_public', 0):,} of the "
                     f"{ni_pub.get('reader_task_pairs_on_the_ranked_board', 0):,} reader and task pairs of the "
                     "ranked board.")
    L += _bullet("Practice packs come from simulated models." + (" This is one." if all_sim else ""))
    L += _bullet(f"Only single-call tasks, {_n(getattr(b, 'n_show', 1), 'item')} shown, reasoning off, "
                 f"{settings.get('candidates_per_task', 4)} candidates per task and at most two checks of a cell.")
    L += _bullet(f"Small check pools limit the budgets: {settings.get('calibration_pool_cells', 0):,} cells per "
                 f"bank, so the budgets {_join(fit)} fit"
                 + (f" and {_join(k for k in registered if k not in fit)} do not." if set(registered) - set(fit)
                    else "."))
    L += _bullet("The paper's results describe these models, streams and settings only.")
    L += _bullet("Anything public can be carried in an entry file, and a rule can special-case the model names.")
    L.append("")

    L += ["## Maintenance and versions", ""]
    L += _bullet(f"A pack is replaced, never edited; this one is version `{version}` (manifest.json \"version\"). "
                 "A new pack starts a new board and the old board's entries are re-run on it.")
    L += _bullet("At most 2 ranked runs per team per calendar month and 10 per pack; failed and withdrawn entries "
                 "count.")
    L += _bullet("A public, append-only log lists every ranked run: the entry's sha256, the date, the pack and "
                 "board version, both boards' numbers and the held-out alarm.")
    L += _bullet("When a pack is retired its private half is published, so the sha256 commitments can be checked "
                 "and the log's entries re-run.")
    L += _bullet("Contact: through the venue during anonymous review; the public repository's issue tracker after.")
    L.append("")

    L += ["## When closed models retire", ""]
    L += _para("Their stored results stay valid and scorable forever: the pack holds results, not live models. "
               "But a retired reader can read no new owner bank, and a retired owner can write no new bank, so a "
               "new pack that adds models cannot extend a retired model's row or column. The board of a pack that "
               "holds a retired model is frozen for that model. A replacement pack is built when a pack's models "
               "are mostly retired. Open-weight models can be re-run as long as their weights stay available.")
    while L and L[-1] == "":
        L.pop()
    return "\n".join(L) + "\n"


# ---------------------------------------------------------------------------
# croissant.json
# ---------------------------------------------------------------------------


def _file_description(rel: str, bird: set) -> str:
    parts = rel.split("/")
    name = parts[-1]
    if rel == "SCHEMA.md":
        d = "What every file and column of the pack holds."
    elif rel == DATASHEET:
        d = "The datasheet: what the pack is, how it was made, licences, limits and maintenance."
    elif rel == "licences/README.txt":
        d = "The licence of each part of the pack."
    elif parts[0] == "licences":
        d = f"What may be released for the stream {name[:-4]}, and why."
    elif parts[0] == "banks" and len(parts) == 3:
        d = {"items.csv": f"One row per item of the bank {parts[1]}: scores and the counts behind them.",
             "showings.csv": f"The owner's logged score phase of the bank {parts[1]}.",
             "bank.json": f"The settings of the bank {parts[1]}: no-memory rate and score rules."
             }.get(name, f"A file of the bank {parts[1]}.")
    elif parts[0] == "candidates":
        d = f"The candidates of every probe task of the bank {name[:-4]}, with relevance and role."
    elif parts[0] == "task_texts":
        d = f"The probe tasks' text for {name[:-4]}."
    elif rel == EX.CALIB_FILE:
        d = ("Every reader's graded results on the public banks' calibration tasks (the development board's check "
             "pool), and the no-item runs.")
    elif rel == EX.DEV_FILE:
        d = "Every reader's graded results on the public banks' evaluation tasks (the development board's scored tasks)."
    elif parts[0] == EX.REFERENCE_DIR:
        d = f"The paper's own rules on the development board ({name.rsplit('.', 1)[0]} family)."
    else:
        d = "A file of the pack."
    if rel in bird:
        d += " It holds BIRD text and is licensed CC BY-SA 4.0."
    return d


def _infer(paths: list, cols: list, limit: int = 5000) -> dict:
    """{column: sc type} from up to `limit` rows of the files: Integer, Float or Text."""
    seen = {c: set() for c in cols}
    n = 0
    for p in paths:
        with open(p, encoding="utf-8", newline="") as fh:
            for row in csv.DictReader(fh):
                for c in cols:
                    v = row.get(c)
                    if v:
                        seen[c].add("int" if re.fullmatch(r"-?\d+", v) else
                                    "float" if _is_float(v) else "text")
                n += 1
                if n >= limit:
                    break
        if n >= limit:
            break
    out = {}
    for c in cols:
        s = seen[c]
        if not s:                         # an empty column (e.g. the visits family's p): the type by name
            out[c] = "sc:Text" if c in TEXT_COLUMNS else NUMERIC.get(c.rpartition(".")[2], "sc:Text")
        else:                             # the exporter writes ints bare and floats in repr form (with . or e)
            out[c] = ("sc:Text" if c in TEXT_COLUMNS or "text" in s else
                      "sc:Integer" if s == {"int"} else "sc:Float")
    return out


def _is_float(v: str) -> bool:
    try:
        float(v)
        return True
    except ValueError:
        return False


def _family_meaning(col: str, header: list) -> str:
    fam, _, part = col.rpartition(".")
    if part == "score":
        return f"Family {fam}: the ranking score."
    if part == "mix_score":
        return f"Family {fam}: the score in [0, 1] that the build mixed with relevance."
    if part == "p":
        return f"Family {fam}: the predicted success before clipping (empty where the family gives none)."
    if part in ("helpful", "harmful"):
        own = fam.startswith("tags")
        word = ("the owner's own '" + part + "' tags" if own else
                "graded " + ("successes" if part == "helpful" else "failures") + " (stored under this name)")
        return f"Family {fam}: {word}."
    return f"Family {fam}: {FAMILY_COUNT.get(part, part)}."


def _record_set(rs_id: str, desc: str, kind: str, paths: list, source: dict, file_field: dict | None) -> dict:
    header = _header(paths[0]) if paths else []
    types = _infer(paths, header)
    fields = []
    if file_field:
        fields.append({"@type": "cr:Field", "@id": f"{rs_id}/{file_field['name']}", "name": file_field["name"],
                       "description": MEANING[kind].get(file_field["name"], "The file the row comes from."),
                       "dataType": "sc:Text", "source": {**source, **file_field["source"]}})
    for c in header:
        meaning = MEANING[kind].get(c) or (_family_meaning(c, header) if "." in c else
                                          f"The column {c}; SCHEMA.md gives its meaning.")
        fields.append({"@type": "cr:Field", "@id": f"{rs_id}/{c}", "name": c, "description": meaning,
                       "dataType": types[c], "source": {**source, "extract": {"column": c}}})
    return {"@type": "cr:RecordSet", "@id": rs_id, "name": rs_id, "description": desc, "field": fields}


def _path_regex(folder: str, name: str) -> str:
    return "^(?:.*/)?" + re.escape(folder) + "/" + name + "$"


def croissant(out: Path, manifest: dict, st=None) -> dict:
    """The Croissant 1.0 metadata of the public pack in `out` (every file but manifest.json and
    croissant.json, with size and sha256 from the bytes; one record set per kind of CSV)."""
    out = Path(out)
    f = _facts(out, manifest)
    bird = set(f["bird_text"])
    dist = []
    for p in sorted(out.rglob("*")):
        if not p.is_file() or (p.parent == out and p.name in ("manifest.json", CROISSANT)):
            continue
        rel = p.relative_to(out).as_posix()
        dist.append({"@type": "cr:FileObject", "@id": rel, "name": rel,
                     "description": _file_description(rel, bird), "contentUrl": rel,
                     "contentSize": f"{p.stat().st_size} B",
                     "encodingFormat": ENCODING.get(p.suffix.lower(), "application/octet-stream"),
                     "sha256": EX.sha256_file(p)})
    record_sets = []

    def fileset(fs_id, desc, includes):
        dist.append({"@type": "cr:FileSet", "@id": fs_id, "name": fs_id, "description": desc,
                     "encodingFormat": "text/csv", "includes": includes})

    results = [out / n for n in (EX.CALIB_FILE, EX.DEV_FILE) if (out / n).exists()]
    if results:
        fileset("results-files", "The two results files of the development board (same columns).",
                [p.name for p in results])
        record_sets.append(_record_set(
            "results", "Every reader's graded results on the public banks: one row per (owner, reader, stream, "
            "order, task, candidate shown or none, repeat).", "results", results, {"fileSet": {"@id": "results-files"}},
            {"name": "file", "source": {"extract": {"fileProperty": "filename"}}}))
    # items.csv: the columns depend on the families and on whether a bank's text is included
    groups: dict = {}
    for p in f["items"]:
        groups.setdefault(tuple(_header(p)), []).append(p)
    for j, (_h, paths) in enumerate(groups.items()):
        suffix = "" if j == 0 else f"-{j + 1}"
        includes = "banks/*/items.csv" if len(groups) == 1 else [p.relative_to(out).as_posix() for p in paths]
        fileset(f"items-files{suffix}", "The items.csv file of every public bank"
                + ("" if len(groups) == 1 else " with these columns") + ".", includes)
        record_sets.append(_record_set(
            f"items{suffix}", "One row per item of a public owner's bank: its scores and the counts behind them.",
            "items", paths, {"fileSet": {"@id": f"items-files{suffix}"}},
            {"name": "bank", "source": {"extract": {"fileProperty": "fullpath"},
                                        "transform": {"regex": _path_regex("banks", r"([^/]+)/items\.csv")}}}))
    if f["showings"]:
        fileset("showings-files", "The showings.csv file of every public bank.", "banks/*/showings.csv")
        record_sets.append(_record_set(
            "showings", "The owners' logged score phase: one row per showing of an item, in the order it happened.",
            "showings", f["showings"], {"fileSet": {"@id": "showings-files"}},
            {"name": "bank", "source": {"extract": {"fileProperty": "fullpath"},
                                        "transform": {"regex": _path_regex("banks", r"([^/]+)/showings\.csv")}}}))
    if f["candidates"]:
        fileset("candidates-files", "The candidates file of every public bank.", "candidates/*.csv")
        record_sets.append(_record_set(
            "candidates", "The candidate items of every probe task of a public bank, with relevance and role.",
            "candidates", f["candidates"], {"fileSet": {"@id": "candidates-files"}},
            {"name": "bank", "source": {"extract": {"fileProperty": "fullpath"},
                                        "transform": {"regex": _path_regex("candidates", r"([^/]+)\.csv")}}}))
    if f["task_texts"]:
        fileset("task-texts-files", "The probe tasks' text, per stream and order.", "task_texts/*.csv")
        record_sets.append(_record_set(
            "task_texts", "The probe tasks as the model saw them with no item shown.", "task_texts",
            f["task_texts"], {"fileSet": {"@id": "task-texts-files"}},
            {"name": "stream_order", "source": {"extract": {"fileProperty": "fullpath"},
                                                "transform": {"regex": _path_regex("task_texts", r"([^/]+)\.csv")}}}))

    split = manifest.get("owner_split", {})
    n_models = len(manifest.get("models", []))
    n_public = len(split.get("public_owners", []))
    streams = manifest.get("streams", [])
    sim = None if st is None else _simulated(st)
    desc = (f"Frozen probe tables of the ScoreSwap study '{manifest.get('study')}': memory items written by "
            f"language models{' (simulated ones in this pack)' if sim and sim[0] == sim[1] else ''}, their "
            "usefulness scores and the logged score phase, and every reader model's graded results with each "
            "candidate item shown and with none. Use it to score a swap-day rule or a score type offline "
            "(python -m scoreswap score). This public pack is the development board: the banks of "
            f"{n_public} of the {n_models} owners; the other owners' banks (the ranked board) are held by the "
            "maintainers and committed by sha256 in manifest.json. Streams: " + ", ".join(streams) + ". "
            "Licence: CC BY 4.0 for the project's own data; files that hold BIRD text are licensed CC BY-SA 4.0 "
            f"(ShareAlike); this pack has {len(bird)} such file(s). DATASHEET.md and SCHEMA.md explain every file. "
            f"Canary: {manifest.get('canary', EX.CANARY)}")
    doc = {
        "@context": CONTEXT,
        "@type": "sc:Dataset",
        "conformsTo": "http://mlcommons.org/croissant/1.0",
        "name": f"scoreswap-{manifest.get('study')}",
        "description": desc,
        "license": CC_BY,
        "version": manifest.get("version", {}).get("pack", ""),
        "datePublished": str(manifest.get("created", ""))[:10],
        "citeAs": CITE_AS,
        "keywords": ["memory items", "model swap", "language model agents", "benchmark", "offline evaluation"],
        "isLiveDataset": False,
        "rai:dataCollection": (
            "Each owner model wrote items on the same write tasks and earned scores in a logged score phase; then "
            "every reader model answered every probe task with each candidate item shown and with none, "
            + (f"{_n(st.probe.repeats, 'repeat')} each" if st is not None and getattr(st, "probe", None)
               else "repeated") + ", graded by a program." + (" Every model is simulated (a program with a known truth)."
                                                  if sim and sim[0] == sim[1] else "")),
        "rai:dataAnnotationProtocol": "No human annotation: every result is graded by a program.",
        "rai:dataPreprocessingProtocol": (
            "Numbers are copied, not recomputed, except the per-family score columns; floats in shortest exact "
            "form; item text kept as its sha256, the text itself only where the licences allow it."),
        "rai:dataUseCases": (
            "Research on memory scores, swap-day rules and model swaps, scored offline. A development-board number "
            "is never a ranking. Not for clinical use or for ranking models for deployment."),
        "rai:dataLimitations": (
            "Same write tasks and candidate lists for every owner, so public results on other owners' items are "
            "visible; a reader's no-item results are public; single-call tasks, one item shown, reasoning off; "
            "small check pools limit the budgets; results describe these models only."),
        "rai:personalSensitiveInformation": (
            "No personal information was collected by this project: ids, sha256 hashes, scores and graded results, "
            "and text only where the licences allow it."),
        "rai:dataReleaseMaintenancePlan": (
            "A pack is replaced, never edited. Ranked runs are logged publicly (append-only); when a pack is retired "
            "its private half is published so the sha256 commitments can be checked."),
        "distribution": dist,
        "recordSet": record_sets,
    }
    return doc


# ---------------------------------------------------------------------------
# Both
# ---------------------------------------------------------------------------


def write_all(out: Path, manifest: dict, st) -> None:
    """Write DATASHEET.md, then croissant.json (which lists DATASHEET.md with its sha256), into the
    public pack folder `out`. manifest.json is not touched."""
    out = Path(out)
    (out / DATASHEET).write_text(datasheet_text(out, manifest, st), encoding="utf-8")
    doc = croissant(out, manifest, st)
    (out / CROISSANT).write_text(json.dumps(doc, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")
