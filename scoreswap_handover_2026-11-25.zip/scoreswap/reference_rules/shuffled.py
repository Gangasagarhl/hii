"""shuffled: the owner's scores handed to the wrong items (the content-only control). Draw d uses
the paper's permutation d of this owner's bank (msr.arms.shuffle_order with the paper's seed), so
run it with --draws equal to the pack's shuffled_permutations for parity."""
from msr import arms as A
from msr import engine as X
from msr.build import stable_int
from scoreswap.reference_rules._common import family_of, output

KIND = "swap_day_rule"
NAME = "shuffled"
RANDOM = True          # a random rule even with no checks: one permutation per draw


def rule(bank, candidates, swap, checks):
    F = family_of(bank, swap)
    seed = [int(swap.settings["draw_seed"]), stable_int(f"shuffled|{bank.stream}|{bank.order}|{bank.owner}"), swap.draw]
    perm = A.shuffle_order(bank.n, seed)
    return output(F, X.permute(F, perm))
