"""Replay the owner's logged score phase with one family's own update rule (msr.build's
update_families, the code that built the paper's banks), and return that family's ranking
score x per item (msr.engine.Fam.x, the score the paper's concordance reads)."""
from __future__ import annotations

import math

import numpy as np


def replay_scores(log, family: str) -> np.ndarray:
    from msr import engine as X
    from msr import scores as S
    from msr.build import update_families
    rule = S.rule_from_dict(log.score_rules[family])
    bank = {i: rule.new_record() for i in log.items}
    for j in range(log.n):
        nm = log.no_memory[j]
        update_families({family: rule}, {family: bank}, log.item[j], bool(log.result[j] > 0.5), log.tag[j],
                        None if math.isnan(nm) else float(nm), log.owner)
    return X.Fam(family, rule, bank, log.items, log.no_memory_rate).x
