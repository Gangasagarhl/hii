"""wipe: every item back at its start value (q = 0.5, counts 0, c = 0, n = 0); ranking falls back
to relevance (pre-registration 2.6)."""
from scoreswap.reference_rules._common import family_of, output

KIND = "swap_day_rule"
NAME = "wipe"


def rule(bank, candidates, swap, checks):
    F = family_of(bank, swap)
    return output(F, F.start())
