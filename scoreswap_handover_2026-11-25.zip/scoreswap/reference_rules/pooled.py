"""pooled_k: k random fresh checks added to the old scores at full weight with the family's own
update (pre-registration 2.6)."""
from msr import engine as X
from scoreswap.reference_rules._common import as_draw, family_of, output

KIND = "swap_day_rule"
NAME = "pooled"
DRAW_KEY = "pooled"


def rule(bank, candidates, swap, checks):
    F = family_of(bank, swap)
    answers = checks.request(random=swap.budget, with_no_memory=(F.kind == "credit"))
    ci, cy, cb = as_draw(answers, F)
    return output(F, X.fold(F, F.batch(1), ci, cy, cb))
