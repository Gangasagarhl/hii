"""Score type beta_grade: graded successes and failures as a Beta(1, 1) posterior mean: Memp, ReMe, EvolveR.
Replays the logged score phase with the family's own update (pre-registration Part 0.4)."""
from scoreswap.reference_rules._replay import replay_scores

KIND = "score_type"
NAME = "beta_grade"


def score(log):
    return replay_scores(log, "beta_grade")
