"""recal_k: logistic recalibration p = sigmoid(a + b x') on k random fresh checks, x' the family
score standardised over the owner's bank, a ~ N(0, 1), b ~ N(0.5, 1); u = p (pre-registration 2.6).
Not defined for visits."""
from msr import engine as X
from scoreswap.reference_rules._common import as_draw, family_of

KIND = "swap_day_rule"
NAME = "recal"
DRAW_KEY = "recal"


def rule(bank, candidates, swap, checks):
    F = family_of(bank, swap)
    if not F.has_p:
        raise ValueError(f"recal needs a family with a predicted success; {F.name} has none")
    answers = checks.request(random=swap.budget)
    ci, cy, _cb = as_draw(answers, F)
    a, b, _conv = X.recal_batch(F.xprime[ci], cy, fit_slope=F.slope_ok)
    p = X.recal_probs(F, a, b)[0]
    return {"u": p, "p": p}
