"""audit_k: k/4 calibration tasks drawn at random, all their candidates checked once; if the old
scores' Cw on these checks is above 0.5 use keep, otherwise wipe; no informative pair: keep
(pre-registration 2.6)."""
import numpy as np

from msr import engine as X
from scoreswap.reference_rules._common import family_of, output

KIND = "swap_day_rule"
NAME = "audit"
DRAW_KEY = "audit"


def rule(bank, candidates, swap, checks):
    F = family_of(bank, swap)
    tasks = list(checks.by_task)          # the harness gives the tasks in the paper's (sorted-id) order
    n_cands = int(swap.settings.get("candidates_per_task", 4))
    n_t = min(len(tasks), max(1, int(round(swap.budget / max(1, n_cands)))))
    pick = checks.rng.choice(len(tasks), size=n_t, replace=False) if tasks else []
    cells, labels = [], []
    for n, j in enumerate(pick):
        group = checks.by_task[tasks[int(j)]]
        cells += list(group)
        labels += [n] * len(group)
    answers = checks.request(cells=cells) if cells else []
    items = np.array([a.item_index for a in answers], dtype=np.int64)
    ys = np.array([a.result for a in answers], dtype=float)
    pa, pb = [], []
    start = 0
    while start < len(labels):
        end = start
        while end < len(labels) and labels[end] == labels[start]:
            end += 1
        for i1 in range(start, end):
            for i2 in range(i1 + 1, end):
                pa.append(i1)
                pb.append(i2)
        start = end
    pa, pb = np.array(pa, dtype=np.int64), np.array(pb, dtype=np.int64)
    keep, _num, _den = X.audit_keep(F.x, items, ys, pa, pb, np.zeros(len(pa), dtype=np.int64), 1)
    return output(F, F.A if bool(keep[0]) else F.start())
