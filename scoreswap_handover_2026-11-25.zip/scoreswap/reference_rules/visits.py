"""Score type visits: how often the item was shown (a baseline with no usefulness signal).
Replays the logged score phase with the family's own update (pre-registration Part 0.4)."""
from scoreswap.reference_rules._replay import replay_scores

KIND = "score_type"
NAME = "visits"


def score(log):
    return replay_scores(log, "visits")
