"""relevance: scores ignored; every item gets the same u, so the most relevant candidate is shown."""
import numpy as np

KIND = "swap_day_rule"
NAME = "relevance"


def rule(bank, candidates, swap, checks):
    return {"u": np.full(bank.n, 0.5)}
