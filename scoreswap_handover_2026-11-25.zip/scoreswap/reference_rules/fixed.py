"""fixed_lambda: old evidence at weight lambda (--set lam=0.5): q' = 0.5 + lambda (q - 0.5);
counts and c multiplied by lambda (pre-registration 2.6)."""
from msr import engine as X
from scoreswap.reference_rules._common import family_of, output

KIND = "swap_day_rule"
NAME = "fixed"


def rule(bank, candidates, swap, checks):
    F = family_of(bank, swap)
    lam = float(swap.options.get("lam", 0.5))
    return output(F, X.discount(F, lam))
