"""keep: the owner's scores, unchanged (pre-registration 2.6)."""
from scoreswap.reference_rules._common import family_of, output

KIND = "swap_day_rule"
NAME = "keep"


def rule(bank, candidates, swap, checks):
    F = family_of(bank, swap)
    return output(F, F.A)
