"""Score type credit: mean of (result with the item - the owner's no-item result on the task): MemCredit.
Replays the logged score phase with the family's own update (pre-registration Part 0.4)."""
from scoreswap.reference_rules._replay import replay_scores

KIND = "score_type"
NAME = "credit"


def score(log):
    return replay_scores(log, "credit")
