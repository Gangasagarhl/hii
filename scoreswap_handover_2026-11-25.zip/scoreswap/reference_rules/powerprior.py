"""powerprior_k: the base prior Beta(a0, b0) fitted to the owner's bank, the weight lambda that
maximises the beta-binomial marginal likelihood of k random fresh checks (ties to the smaller),
never a flat prior (pre-registration 2.6). Families with counts only (ema_grade, beta_grade,
tags_self)."""
from msr import engine as X
from scoreswap.reference_rules._common import as_draw, family_of, output

KIND = "swap_day_rule"
NAME = "powerprior"
DRAW_KEY = "powerprior"


def rule(bank, candidates, swap, checks):
    F = family_of(bank, swap)
    if not F.has_counts:
        raise ValueError(f"powerprior needs a family with counts; {F.name} has none")
    answers = checks.request(random=swap.budget)
    ci, cy, _cb = as_draw(answers, F)
    a0, b0 = F.prior
    lam = X.powerprior_lambda(F, ci, cy, swap.settings["lambda_grid"], a0, b0)[0]
    return output(F, X.powerprior_state(F, float(lam), a0, b0))
