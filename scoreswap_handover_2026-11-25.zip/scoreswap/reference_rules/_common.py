"""Shared helpers of the reference rules: the owner's family as msr.engine arrays, and the
output of a state. The arithmetic is msr.engine's, exactly as msr.evaluate uses it."""
from __future__ import annotations

import numpy as np

from msr import engine as X


def family_of(bank, swap, default: str | None = None):
    """msr.engine.Fam of the family the rule works on (the bank's, built once per bank)."""
    f = swap.family(default)
    if f not in bank.families:
        raise ValueError(f"family {f!r} is not in this bank ({bank.families})")
    return bank.engine_family(f)            # built once per bank by the harness


def output(F, A: dict) -> dict:
    """{'u': u, 'p': p} of a family state (arrays over the items); p is left out for visits.
    p is clipped to [0, 1] as the interface asks (credit's r0 + c can leave it); the scorer then
    clips to the study's [0.01, 0.99], so the scored value is exactly the paper's."""
    u = X.u_of(F.kind, A)
    p = X.p_of(F.kind, A, F.r0)
    if p is not None:
        p = np.clip(np.asarray(p, dtype=float), 0.0, 1.0)
    if u.ndim == 2:
        u = u[0]
        p = None if p is None else p[0]
    return {"u": u} if p is None else {"u": u, "p": p}


def as_draw(answers, F, with_base: bool = False):
    """(items (1, m), results (1, m), no-item baselines (1, m)) of a list of answers."""
    ci = np.array([[a.item_index for a in answers]], dtype=np.int64).reshape(1, len(answers))
    cy = np.array([[a.result for a in answers]], dtype=float).reshape(1, len(answers))
    cb = np.array([[(a.no_memory if a.no_memory is not None else 0.0) for a in answers]],
                  dtype=float).reshape(1, len(answers))
    return ci, cy, cb
