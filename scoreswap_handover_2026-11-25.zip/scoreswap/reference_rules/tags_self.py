"""Score type tags_self: the owner's own helpful / harmful tags, given without the grade, smoothed share: ACE.
Replays the logged score phase with the family's own update (pre-registration Part 0.4)."""
from scoreswap.reference_rules._replay import replay_scores

KIND = "score_type"
NAME = "tags_self"


def score(log):
    return replay_scores(log, "tags_self")
