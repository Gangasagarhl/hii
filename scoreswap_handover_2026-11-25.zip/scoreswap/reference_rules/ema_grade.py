"""Score type ema_grade: moving average of the grade (start 0.5, step 0.3): MemRL, RoMeRL, EvoKernel.
Replays the logged score phase with the family's own update (pre-registration Part 0.4)."""
from scoreswap.reference_rules._replay import replay_scores

KIND = "score_type"
NAME = "ema_grade"


def score(log):
    return replay_scores(log, "ema_grade")
