"""retest_k (HEIRS style): the k items with the highest OLD score among the items that appear on a
calibration task get one check each, on one of their calibration cells chosen at random; each is
re-scored from the start value with that check; every other item stays at the start value
(pre-registration 2.6)."""
import numpy as np

from msr import arms as A
from msr import engine as X
from scoreswap.reference_rules._common import as_draw, family_of, output

KIND = "swap_day_rule"
NAME = "retest"
DRAW_KEY = "retest"


def rule(bank, candidates, swap, checks):
    F = family_of(bank, swap)
    recs = bank.records(F.name)
    # ties are broken by the item's place in bank.items (the paper's sorted-id order); names are
    # random in every call, so they cannot be used for that
    keyed = {f"{bank.index[i]:09d}": recs[i] for i in checks.by_item if i in recs}
    top = [bank.items[int(k)] for k in A.top_k_items(keyed, bank.rule(F.name), swap.budget)]
    lists = [checks.by_item[i] for i in top]
    if lists:
        j = checks.rng.integers(0, np.array([len(c) for c in lists], dtype=np.int64))
        cells = [lists[n][int(x)] for n, x in enumerate(j)]
        answers = checks.request(cells=cells, with_no_memory=(F.kind == "credit"))
    else:
        answers = []
    ci, cy, cb = as_draw(answers, F)
    return output(F, X.fold(F, F.start((1,)), ci, cy, cb))
