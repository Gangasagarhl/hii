"""The paper's own swap-day rules and score types, written as ordinary entries through the public
interface (scoreswap.api). They are the parity test of the scorer: run through the harness they
must reproduce the paper's results/arms.csv and results/validity.csv (scoreswap.parity).

Swap-day rules (each works on one score family: `--set family=...`, default the headline family):
    keep.py, wipe.py, fixed.py (--set lam=0.5), relevance.py, shuffled.py,
    powerprior.py, recal.py, retest.py, audit.py, pooled.py, fresh.py   (k = the budget)
Score types: ema_grade.py, beta_grade.py, tags_self.py, credit.py, visits.py

Not expressible as an entry (A14): `none` (shows no item), `own` (needs the reader's own bank),
`constant` (needs the reader's no-item success on the calibration tasks without a check), and the
references `split_half` and `ceiling` (they read the evaluation results by design).
"""
