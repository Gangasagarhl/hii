"""Reading a release pack (the folders `python -m scoreswap export` writes).

    release/<name>/            public: the PUBLIC owners' banks and candidates, every reader's results on
                               them (the development board), the paper's rules on it
    release/<name>_private/    maintainers only: the PRIVATE owners' banks and candidates, every reader's
                               results on them (the ranked board), the secret seed of its random checks;
                               the sha256 of each of its files is in the public manifest

Boards: "dev" (development: the cells of the public owners, public seeds), "test" (ranked: the cells of
the private owners, secret seed) and "all" (every cell, the paper's seeds: the paper's tables). Every
probe task of a bank is on its owner's board: the check pool is every calibration task, the scored
tasks every evaluation task.

Without the private folder a Pack looks like a complete pack whose owners are the public ones
(`cells`); with it, every cell is there and `board_cells(board)` gives each board's.

Two kinds of reading, kept apart on purpose:
- public reading (banks, showings, candidates): what a rule may see; turned into plain payloads
  that the harness hands to the rule;
- harness reading (calibration results to answer fresh checks; evaluation results to score): only
  the harness calls these.

Every file's sha256 is checked against its manifest before it is used, and the private folder
must match the commitment printed in the public manifest.
"""
from __future__ import annotations

import csv
import hashlib
import json
from collections import defaultdict
from pathlib import Path

from scoreswap.export import (CALIB_FILE, DEV_FILE, FORMAT, PRIVATE_FORMAT, RANKED_CALIB_FILE, REFERENCE_DIR,
                              RULE_FIELDS, SECRET_FILE, TEST_FILE, bank_tag, owners_commitment)

SPLITS = ("dev", "test")
#: the owner sides each board holds
BOARD_SIDES = {"dev": ("dev",), "test": ("test",), "all": ("dev", "test")}
BOARD_NAME = {"dev": "DEVELOPMENT board (the public owners' banks)",
              "test": "RANKED board (the private owners' banks, secret check seed)",
              "all": "every bank (every cell: the paper's tables)"}


class PackError(ValueError):
    pass


def _num(s: str):
    """A CSV cell back to a number: whole numbers stay int, others float, empty is None."""
    if s == "" or s is None:
        return None
    try:
        return int(s)
    except ValueError:
        return float(s)


def _sha(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


class Pack:
    """One release pack, optionally with its private half.

    `private`: the private folder (maintainers). `override`: {'dev' or 'test': path} other copies of
    the evaluation results files (the canary of `check` uses copies with the outcomes permuted)."""

    def __init__(self, root, verify: bool = True, private=None, override: dict | None = None):
        self.root = Path(root).resolve()
        mp = self.root / "manifest.json"
        if not mp.exists():
            raise PackError(f"{self.root} is not a release pack (no manifest.json); make one with "
                            f"python -m scoreswap export --study <name> --out <folder>")
        self.manifest = json.loads(mp.read_text(encoding="utf-8"))
        if self.manifest.get("format") != FORMAT:
            raise PackError(f"{mp}: format {self.manifest.get('format')!r}; this scoreswap reads {FORMAT}. "
                            f"Export the pack again with this version.")
        self.settings = self.manifest["settings"]
        self.models = [m["name"] for m in self.manifest["models"]]
        self.maker = {m["name"]: m["maker"] for m in self.manifest["models"]}
        self.upgrades = [tuple(p) for p in self.manifest["upgrade_pairs"]]
        self.streams = list(self.manifest["streams"])
        self.orders = list(self.manifest["orders"])
        self.all_cells = [(c["owner"], c["reader"]) for c in self.manifest["cells"]]
        self.kind = {(c["owner"], c["reader"]): c["kind"] for c in self.manifest["cells"]}
        self.strata = [tuple(s) for s in self.manifest["strata_present"]]
        self.families = list(self.settings["families"])
        self.headline = self.settings["headline_family"]
        self.public_owners = list(self.manifest["owner_split"]["public_owners"])
        self._sha = {f["path"]: f["sha256"] for f in self.manifest["files"]}
        self._verified: set = set()
        self.override = {k: Path(v) for k, v in (override or {}).items()}
        self._res: dict = {}
        self._public_cache: dict = {}
        self.role_of = {}
        for key, info in self.manifest["probe_tasks"].items():
            stream, order = key.split("|")
            self.role_of[(stream, int(order))] = dict(zip(info["tasks"], info["roles"]))
        self.private = None
        self.private_owners: list = []
        self._private_sha: dict = {}
        if private is not None:
            self.private = Path(private).resolve()
            pm = self.private / "manifest.json"
            if not pm.exists():
                raise PackError(f"{self.private} is not the private half of a pack (no manifest.json)")
            pman = json.loads(pm.read_text(encoding="utf-8"))
            if pman.get("format") != PRIVATE_FORMAT:
                raise PackError(f"{pm}: unknown format {pman.get('format')!r}")
            want = {f["path"]: f["sha256"] for f in self.manifest["private"]["files"]}
            have = {f["path"]: f["sha256"] for f in pman["files"]}
            for path, sha in want.items():
                if have.get(path) != sha:
                    raise PackError(f"the private folder does not belong to this pack: {path} is not the one "
                                    f"committed to in the public manifest")
            owners = list(pman.get("private_owners") or [])
            if owners_commitment(owners) != self.manifest["owner_split"]["private_owners_sha256"]:
                raise PackError("the private folder does not belong to this pack: its list of private owners is not "
                                "the one committed to in the public manifest")
            self.private_owners = owners
            self._private_sha = have
        self.side = {o: "dev" for o in self.public_owners}
        self.side.update({o: "test" for o in self.private_owners})
        #: the cells whose owner's bank this Pack can read (public owners; every owner with the private folder)
        self.cells = [c for c in self.all_cells if c[0] in self.side]
        if verify:
            for rel in self._sha:
                if not rel.startswith(REFERENCE_DIR + "/"):
                    self._check(rel)

    # ---- what is available -------------------------------------------------
    @property
    def splits_available(self) -> tuple:
        return ("dev", "test") if self.private is not None else ("dev",)

    @property
    def boards_available(self) -> tuple:
        return ("dev", "test", "all") if self.private is not None else ("dev",)

    def _need_private(self, board: str) -> None:
        if board != "dev" and self.private is None:
            raise PackError(f"the {'ranked board' if board == 'test' else 'whole pack'} needs the private folder "
                            f"(--private); it is held by the maintainers")

    def board_owners(self, board: str = "dev") -> list:
        """The owners whose banks a board holds, in the manifest's model order."""
        self._need_private(board)
        sides = BOARD_SIDES[board]
        return [m for m in self.models if self.side.get(m) in sides]

    def board_cells(self, board: str = "dev") -> list:
        owners = set(self.board_owners(board))
        return [c for c in self.all_cells if c[0] in owners]

    def side_of(self, owner: str) -> str:
        """'dev' (a public owner) or 'test' (a private owner)."""
        if owner not in self.side:
            raise PackError(f"{owner}'s bank is private: it needs the private folder (--private)")
        return self.side[owner]

    def eval_tasks(self, stream: str, order: int, splits=None) -> list:
        """Every evaluation task of one order, in stream order (the same on every board)."""
        info = self.manifest["probe_tasks"][f"{stream}|{order}"]
        return [t for t, r in zip(info["tasks"], info["roles"]) if r == "evaluation"]

    def calib_tasks(self, stream: str, order: int, board: str = "dev") -> list:
        """The calibration tasks of one order (the check pool of every bank), in stream order."""
        self._need_private(board)
        info = self.manifest["probe_tasks"][f"{stream}|{order}"]
        return [t for t, r in zip(info["tasks"], info["roles"]) if r == "calibration"]

    def budgets_fit(self, board: str = "dev") -> list:
        """The registered budgets the check pool can hold."""
        by = self.settings.get("budgets_that_fit_by_board") or {}
        return list(by.get(board, self.settings["budgets_that_fit"]))

    def check_seed(self, board: str = "dev") -> int:
        """The first part of every check seed: the paper's public seed on the development board and for
        the paper's tables; on the ranked board the secret seed of the private folder, so its random
        checks cannot be predicted from public values."""
        if board != "test":
            return int(self.settings["draw_seed"])
        p = self._check_private(SECRET_FILE)
        return int(json.loads(p.read_text(encoding="utf-8"))["seed"])

    # ---- integrity --------------------------------------------------------
    def _check(self, rel: str) -> Path:
        p = self.root / rel
        if rel in self._verified:
            return p
        want = self._sha.get(rel)
        if want is None:
            raise PackError(f"{rel} is not listed in manifest.json")
        if not p.exists():
            raise PackError(f"{p} is missing from the pack")
        if _sha(p) != want:
            raise PackError(f"{p} does not match its sha256 in manifest.json: the table was changed")
        self._verified.add(rel)
        return p

    def _check_private(self, rel: str) -> Path:
        if self.private is None:
            raise PackError("the ranked board needs the private folder (--private); it is held by the maintainers")
        p = self.private / rel
        if ("private:" + rel) in self._verified:
            return p
        if not p.exists():
            raise PackError(f"{p} is missing from the private folder")
        want = self._private_sha.get(rel)
        if want is None:
            raise PackError(f"{rel} is not listed in the private folder's manifest")
        if _sha(p) != want:
            raise PackError(f"{p} does not match the sha256 committed to in the manifests")
        self._verified.add("private:" + rel)
        return p

    def _bank_file(self, owner: str, rel: str) -> Path:
        """A file of an owner's bank (banks/... or candidates/...), from the public pack or, for a
        private owner, from the private folder; checked against its sha256 either way."""
        return self._check(rel) if self.side_of(owner) == "dev" else self._check_private(rel)

    @property
    def fingerprint(self) -> str:
        """sha256 of manifest.json: names the exact tables a result was computed from."""
        return _sha(self.root / "manifest.json")

    def reference_path(self, split: str, name: str) -> Path | None:
        """A cached reference file of the paper's rules (dev: public pack; test: private folder), or None."""
        rel = f"{REFERENCE_DIR}/{split}/{name}"
        if split == "dev":
            return self._check(rel) if rel in self._sha else None
        if self.private is None or rel not in self._private_sha:
            return None
        return self._check_private(rel)

    # ---- public reading (what a rule may see) ------------------------------
    def bank_payload(self, owner: str, stream: str, order: int) -> dict:
        key = ("bank", owner, stream, order)
        if key in self._public_cache:
            return self._public_cache[key]
        tag = bank_tag(owner, stream, order)
        info = json.loads(self._bank_file(owner, f"banks/{tag}/bank.json").read_text(encoding="utf-8"))
        with open(self._bank_file(owner, f"banks/{tag}/items.csv"), encoding="utf-8", newline="") as fh:
            rows = list(csv.DictReader(fh))
        items = [r["item_id"] for r in rows]
        fams = self.families
        rules = info["score_rules"]
        kind_of = {f: rules[f]["name"] for f in fams}
        counts = {f: {k: [_num(r[f"{f}.{k}"]) for r in rows] for k in RULE_FIELDS[kind_of[f]]} for f in fams}
        score = {f: [float(r[f"{f}.score"]) for r in rows] for f in fams}
        mix = {f: [float(r[f"{f}.mix_score"]) for r in rows] for f in fams}
        pp = {f: (None if kind_of[f] == "visits" else [float(r[f"{f}.p"]) for r in rows]) for f in fams}
        probs: dict = defaultdict(list)
        showings = self.showings_payload(owner, stream, order)
        for iid, pi in zip(showings["item"], showings["probability"]):
            probs[iid].append(pi)
        payload = {"owner": owner, "owner_maker": self.maker.get(owner, owner), "stream": stream, "order": order,
                   "items": items, "n": len(items), "families": fams, "score_rules": rules, "rule_kind": kind_of,
                   "counts": counts, "score": score, "mix_score": mix, "p": pp,
                   "visits": [_num(r["visits"]) for r in rows],
                   "text_sha256": [r["text_sha256"] for r in rows],
                   "text": [r["text"] for r in rows] if rows and "text" in rows[0] else None,
                   "showing_probabilities": [probs.get(i, []) for i in items],
                   "no_memory_rate": float(info["no_memory_rate"])}
        self._public_cache[key] = payload
        return payload

    def showings_payload(self, owner: str, stream: str, order: int) -> dict:
        key = ("show", owner, stream, order)
        if key in self._public_cache:
            return self._public_cache[key]
        tag = bank_tag(owner, stream, order)
        with open(self._bank_file(owner, f"banks/{tag}/showings.csv"), encoding="utf-8", newline="") as fh:
            rows = list(csv.DictReader(fh))
        with open(self._bank_file(owner, f"banks/{tag}/items.csv"), encoding="utf-8", newline="") as fh:
            items = [r["item_id"] for r in csv.DictReader(fh)]
        info = json.loads(self._bank_file(owner, f"banks/{tag}/bank.json").read_text(encoding="utf-8"))
        f = lambda r, k: (None if r[k] == "" else float(r[k]))  # noqa: E731
        payload = {"owner": owner, "owner_maker": self.maker.get(owner, owner), "stream": stream, "order": order,
                   "items": items, "score_rules": info["score_rules"], "no_memory_rate": float(info["no_memory_rate"]),
                   "pass": [_num(r["pass"]) for r in rows], "position": [_num(r["position"]) for r in rows],
                   "task": [r["task_id"] for r in rows], "item": [r["item_id"] for r in rows],
                   "probability": [f(r, "selection_probability") for r in rows],
                   "explored": [None if r["explored"] == "" else r["explored"] == "1" for r in rows],
                   "result": [float(r["result"]) for r in rows],
                   "tag": [r["owner_tag"] or None for r in rows],
                   "no_memory": [f(r, "no_memory_result") for r in rows]}
        self._public_cache[key] = payload
        return payload

    def candidates_payload(self, owner: str, stream: str, order: int) -> dict:
        """Every probe task (calibration and evaluation, in stream order) with its candidates."""
        key = ("cand", owner, stream, order)
        if key in self._public_cache:
            return self._public_cache[key]
        tag = bank_tag(owner, stream, order)
        with open(self._bank_file(owner, f"candidates/{tag}.csv"), encoding="utf-8", newline="") as fh:
            rows = list(csv.DictReader(fh))
        info = self.manifest["probe_tasks"][f"{stream}|{order}"]
        by: dict = defaultdict(list)
        for r in rows:
            by[r["task_id"]].append((int(r["position"]), r["item_id"], float(r["relevance"])))
        tasks = list(info["tasks"])
        C = int(self.settings["candidates_per_task"])
        items = [[""] * C for _ in tasks]
        rel = [[None] * C for _ in tasks]
        for n, t in enumerate(tasks):
            for pos, iid, rv in sorted(by.get(t, [])):
                items[n][pos] = iid
                rel[n][pos] = rv
        tt = None
        rel_tt = f"task_texts/{stream}__order{order}.csv"
        if rel_tt in self._sha and self.side_of(owner) == "dev":     # never handed with a private bank
            with open(self._check(rel_tt), encoding="utf-8", newline="") as fh:
                m = {r["task_id"]: r["text"] for r in csv.DictReader(fh)}
            tt = [m.get(t) for t in tasks]
        payload = {"owner": owner, "stream": stream, "order": order, "tasks": tasks, "roles": list(info["roles"]),
                   "items": items, "relevance": rel, "C": C, "task_text": tt}
        self._public_cache[key] = payload
        return payload

    # ---- harness reading ----------------------------------------------------
    @staticmethod
    def _read_results(path: Path) -> dict:
        """{(owner, reader, stream, order): {"reg": {task: {item: [results]}}, "extra": ..., "none": {task: [..]}}}
        with every list in repeat order (as msr.evaluate.tables_from_rows builds it)."""
        raw: dict = defaultdict(list)
        with open(path, encoding="utf-8", newline="") as fh:
            for r in csv.DictReader(fh):
                raw[(r["owner"], r["reader"], r["stream"], int(r["order"]))].append(
                    (r["task_id"], r["item_id"], r["set"], int(r["repeat"]), r["result"] == "1"))
        out = {}
        for key, rows in raw.items():
            reg: dict = defaultdict(lambda: defaultdict(list))
            ext: dict = defaultdict(lambda: defaultdict(list))
            none: dict = defaultdict(list)
            for t, i, s, _rep, ok in sorted(rows, key=lambda x: (x[0], x[1], x[2], x[3])):
                if s == "no_item":
                    none[t].append(ok)
                elif s == "extra_home":
                    ext[t][i].append(ok)
                else:
                    reg[t][i].append(ok)
            out[key] = {"reg": {t: dict(v) for t, v in reg.items()}, "extra": {t: dict(v) for t, v in ext.items()},
                        "none": dict(none)}
        return out

    def _results(self, which: str) -> dict:
        if which not in self._res:
            if which == "calibration":
                p = self._check(CALIB_FILE)
            elif which == "calibration_ranked":
                p = self._check_private(RANKED_CALIB_FILE)
            elif which == "dev":
                p = self.override.get("dev") or self._check(DEV_FILE)
            else:
                p = self.override.get("test") or self._check_private(TEST_FILE)
            self._res[which] = self._read_results(p)
        return self._res[which]

    def load_all(self) -> None:
        """Read every results file now (before worker processes are forked, so they share it)."""
        self._results("calibration")
        if self.private is not None:
            self._results("calibration_ranked")
        for s in self.splits_available:
            self._results(s)

    def cell_results(self, owner: str, reader: str, stream: str, order: int) -> dict:
        """HARNESS ONLY: the calibration and evaluation results of one cell, from the public pack (a
        public owner) or the private folder (a private owner)."""
        out = {"reg": {}, "extra": {}, "none": {}}
        files = ("calibration", "dev") if self.side_of(owner) == "dev" else ("calibration_ranked", "test")
        for which in files:
            part = self._results(which).get((owner, reader, stream, order))
            if part is None:
                continue
            for k in out:
                for t, v in part[k].items():
                    if k == "none":
                        out[k][t] = v
                    else:
                        out[k].setdefault(t, {}).update(v)
        return out
