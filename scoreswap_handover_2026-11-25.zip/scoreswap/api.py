"""The objects an entry receives, and the shape of what it returns.

A **swap-day rule** is a function

    def rule(bank, candidates, swap, checks):
        ...
        return {"u": u}                     # or {"u": u, "p": p}
        # or, per (task, candidate):  {"u_cand": U, "p_cand": P}

and gets exactly the four inputs of the paper's appendix A14:

1. `bank` (Bank): the owner's bank: item ids, each item's score under the five score types
   with the counts behind it, its visits, the selection probability of each of its showings,
   and the owner's no-memory success rate. Item text only where the stream's licence allows.
2. `candidates` (Candidates): for every probe task, its 4 candidate items with their
   relevance, and whether the task is a calibration or an evaluation task.
3. `swap` (Swap): what is known before the swap: the two models' names and makers (and the
   budget k, the stream, the order and the draw number).
4. `checks` (Checks): fresh checks on request, up to the budget k. Name cells, or ask for
   cells drawn at random; each cell can be answered at most twice (the table holds two
   repeats); later requests may depend on earlier answers. The harness counts the checks.

It returns, for every item of the bank, u in [0, 1] (higher is shown first) and optionally a
predicted success p in [0, 1]; or u (and p) for every (probe task, candidate) as arrays of
shape (number of probe tasks, 4), in the order of `candidates.tasks`.

A **score type** is a function

    def score(log):
        return x                             # one number per item, in log.items order

that gets the owner's logged score phase (ScoreLog) and returns a ranking score per item.

Nothing here reads a file: the harness builds these objects from plain payloads, inside the
same process or inside a child process that is never told where the tables are.
"""
from __future__ import annotations

from typing import NamedTuple, Optional

import numpy as np

#: The registered budgets of fresh checks (A14; pre-registration 0.3).
BUDGETS = (0, 8, 16, 32, 64, 128, 256)


class CheckRequestError(RuntimeError):
    """A request the harness refused: over the budget, a cell asked a third time (or more
    often than it has stored results), an unknown cell, or a malformed request. The run is
    recorded as failed even if the rule catches this."""


# ---------------------------------------------------------------------------
# The owner's bank
# ---------------------------------------------------------------------------


class Bank:
    """The owner's bank, as a rule sees it. Every per-item array follows `items`. In a sealed call the
    items come in an order of their own (fixed for a run; drawn from a secret seed on the ranked board),
    so a position in one bank says nothing about the same position in another bank.

    items              list of item ids; `index[item]` is its position
    owner, owner_maker the model that wrote the bank and earned its scores, and its maker
    stream, order       the task set and the stream order (seed) of this bank
    families           the five score types: ema_grade, beta_grade, tags_self, credit, visits
    score[f]           ranking score x of family f, shape (n,)
    mix_score[f]       the score in [0, 1] the build mixed with relevance, shape (n,)
    p[f]               predicted success of family f before clipping (None for visits)
    counts[f][field]   the counts behind each score, as the score rule stores them:
                         ema_grade: q (moving average), visits, successes, failures
                         beta_grade: helpful (= graded successes), harmful (= failures), visits
                         tags_self: helpful, harmful (the owner's own tags), visits
                         credit: credit (mean of with-item minus no-item result), visits
                         visits: visits
    visits             score-phase showings per item
    showing_probabilities  per item, the logged selection probability of each of its showings
    no_memory_rate     the owner's success with no item on its score tasks (r0)
    text_sha256        sha256 of each item's text; `text` is None unless the licence allows it
    score_rules        the settings of each score rule (e.g. ema step 0.3, start 0.5)
    """

    def __init__(self, payload: dict):
        self.owner = payload["owner"]
        self.owner_maker = payload["owner_maker"]
        self.stream = payload["stream"]
        self.order = int(payload["order"])
        self.items = list(payload["items"])
        self.n = len(self.items)
        self.index = {i: n for n, i in enumerate(self.items)}
        self.families = list(payload["families"])
        self.score_rules = {f: dict(v) for f, v in payload["score_rules"].items()}
        self.rule_kind = dict(payload["rule_kind"])
        self.score = {f: np.asarray(v, dtype=float) for f, v in payload["score"].items()}
        self.mix_score = {f: np.asarray(v, dtype=float) for f, v in payload["mix_score"].items()}
        self.p = {f: (None if v is None else np.asarray(v, dtype=float)) for f, v in payload["p"].items()}
        self._raw_counts = {f: {k: list(v) for k, v in d.items()} for f, d in payload["counts"].items()}
        self.counts = {f: {k: np.asarray(v, dtype=float) for k, v in d.items()} for f, d in payload["counts"].items()}
        self.visits = np.asarray(payload["visits"], dtype=float)
        sha = payload.get("text_sha256")
        self.text_sha256 = None if sha is None else list(sha)      # not given to a sealed rule (it would name items)
        self.text = None if payload.get("text") is None else list(payload["text"])
        self.showing_probabilities = [np.asarray(v, dtype=float) for v in payload["showing_probabilities"]]
        self.no_memory_rate = float(payload["no_memory_rate"])
        self._engine: dict = {}

    def records(self, family: str) -> dict:
        """{item: record} in the msr score-bank format (msr.scores), for the paper's helpers
        such as msr.scores.fit_beta_prior or msr.engine.Fam. Items in sorted order."""
        raw = self._raw_counts[family]
        return {i: {k: raw[k][n] for k in raw} for n, i in enumerate(self.items)}

    def rule(self, family: str):
        """The msr.scores rule object of a family (built from its settings)."""
        from msr import scores as S
        return S.rule_from_dict(self.score_rules[family])

    def engine_family(self, family: str):
        """The paper's msr.engine.Fam of a family: the arrays its swap-day rules start from (the
        state, the fitted Beta prior, the standardised score), exactly what
        msr.engine.Fam(family, bank.rule(family), bank.records(family), bank.items,
        bank.no_memory_rate) builds. The harness builds it once per bank before any call (it needs
        only this bank), so a rule that uses it does not pay for it on every call. Treat it as
        read-only: msr.engine's functions return new arrays."""
        fam = self._engine.get(family)
        if fam is None:
            from msr import engine as X
            fam = X.Fam(family, self.rule(family), self.records(family), self.items, self.no_memory_rate)
            self._engine[family] = fam
        if fam.items != self.items:            # the items were renamed for this call
            fam.items = list(self.items)
        return fam

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        return f"Bank(owner={self.owner!r}, stream={self.stream!r}, order={self.order}, items={self.n})"


# ---------------------------------------------------------------------------
# The candidates of every probe task
# ---------------------------------------------------------------------------


class Candidates:
    """Every probe task (calibration and evaluation) with its candidates. In a sealed call the tasks come
    in an order of their own, like the items (see Bank).

    tasks              probe task ids, T of them
    roles              'calibration' or 'evaluation' per task; is_calibration (T,) bool
    items              (T, C) list of item ids ('' where a task has fewer than C candidates)
    item_index         (T, C) int array: position of the item in bank.items, -1 if none
    relevance          (T, C) float array: cosine relevance (NaN if no candidate)
    C                  candidates per task (4)
    calibration_tasks, evaluation_tasks   the two lists
    """

    def __init__(self, payload: dict, bank: Bank | None = None):
        self.tasks = list(payload["tasks"])
        self.roles = list(payload["roles"])
        self.is_calibration = np.array([r == "calibration" for r in self.roles], dtype=bool)
        self.C = int(payload["C"])
        self.items = [list(r) for r in payload["items"]]
        self.relevance = np.array([[np.nan if v is None else float(v) for v in row] for row in payload["relevance"]],
                                  dtype=float).reshape(len(self.tasks), self.C)
        idx = bank.index if bank is not None else {}
        self.item_index = np.array([[idx.get(i, -1) if i else -1 for i in row] for row in self.items],
                                   dtype=np.int64).reshape(len(self.tasks), self.C)
        self.calibration_tasks = [t for t, r in zip(self.tasks, self.roles) if r == "calibration"]
        self.evaluation_tasks = [t for t, r in zip(self.tasks, self.roles) if r == "evaluation"]
        self.task_index = {t: n for n, t in enumerate(self.tasks)}
        tt = payload.get("task_text")
        self.task_text = None if tt is None else list(tt)        # text mode only (see the guide)

    @property
    def T(self) -> int:
        return len(self.tasks)


# ---------------------------------------------------------------------------
# What is known before the swap
# ---------------------------------------------------------------------------


class Swap:
    """What is known before the swap, and the run's settings.

    owner, owner_maker, reader, reader_maker   the two models and their makers
    kind      home, same_maker_upgrade, same_maker_downgrade, same_maker_other or cross_maker
    stream, order    the task set and stream order
    budget    k, the number of fresh checks this run may use
    draw, draws      which random draw this is (0..draws-1) and how many there are
    options   settings passed on the command line (--set name=value), e.g. family
    settings  the study's settings: mix_score_weight, families, headline_family, lambda_grid,
              probability_clip, draw_seed, ... (manifest.json)
    """

    def __init__(self, payload: dict):
        for k in ("owner", "owner_maker", "reader", "reader_maker", "kind", "stream"):
            setattr(self, k, payload[k])
        self.order = int(payload["order"])
        self.budget = int(payload["budget"])
        self.draw = int(payload.get("draw", 0))
        self.draws = int(payload.get("draws", 1))
        self.options = dict(payload.get("options") or {})
        self.settings = dict(payload.get("settings") or {})

    @property
    def is_home(self) -> bool:
        return self.owner == self.reader

    def family(self, default: str | None = None) -> str:
        """The score family a rule should work on: `--set family=...`, else the headline family."""
        return str(self.options.get("family") or default or self.settings.get("headline_family", "ema_grade"))


# ---------------------------------------------------------------------------
# Fresh checks
# ---------------------------------------------------------------------------


class CheckCell(NamedTuple):
    """One calibration (task, candidate) cell that can be checked."""
    id: int                 # the cell's number (pool order); name it in checks.request(cells=[...])
    task: str
    item: str
    position: int           # the candidate's place (0-3) among the task's candidates
    item_index: int         # position of the item in bank.items
    max_answers: int        # how often it can be answered: the stored repeats (2, or 1 if one is missing)


class Answer(NamedTuple):
    """One fresh check: the reader's graded result with the candidate shown alone."""
    cell: int
    task: str
    item: str
    item_index: int
    result: float           # 1.0 right, 0.0 wrong
    answer_number: int      # 1 the first time this cell is answered, 2 the second
    no_memory: Optional[float]   # the reader's no-item success on that task (mean of its 2 runs), if asked for


class Checks:
    """Fresh checks on request, up to the budget.

    budget, used, remaining    the counts (the harness keeps the real count)
    cells                      the checkable calibration cells (CheckCell), in pool order
    by_task, by_item           {task: [cell ids]}, {item: [cell ids]}
    rng                        a seeded numpy Generator, shared with the harness: use it for any
                               random choice so a run is the same every time
    request(cells=None, random=None, with_no_memory=False) -> [Answer]   (alias: request_checks)
        cells=[ids]   name cells (a cell may be named again once: its other stored repeat)
        random=m      m cells drawn at random among the cells not yet answered, uniformly,
                      without replacement (the paper's draw for powerprior, recal, pooled, fresh)
        with_no_memory=True  also return the reader's no-item success on each answered task
                      (the credit family needs it; it costs the 2 no-item runs per task on a
                      real swap day)
    """

    def __init__(self, budget: int, cells: list, rng: np.random.Generator, transport, task_order=None):
        self.budget = int(budget)
        self.cells = [CheckCell(*c) for c in cells]
        self.rng = rng
        self._transport = transport
        self.used = 0
        by_task: dict = {t: [] for t in (task_order or [])}
        by_item: dict = {}
        for c in self.cells:
            by_task.setdefault(c.task, []).append(c.id)
            by_item.setdefault(c.item, []).append(c.id)
        by_task = {t: v for t, v in by_task.items() if v}
        self.by_task = by_task
        self.by_item = by_item

    @property
    def remaining(self) -> int:
        return self.budget - self.used

    def request(self, cells=None, random=None, with_no_memory: bool = False) -> list:
        if (cells is None) == (random is None):
            raise CheckRequestError("name cells OR ask for a number of random cells, not both and not neither")
        if cells is not None:
            cells = [int(c) for c in cells]
        if random is not None:
            random = int(random)
        answers = self._transport(cells, random, bool(with_no_memory), self.rng)
        self.used += len(answers)
        return [Answer(*a) for a in answers]

    #: the same as request (the name used in the paper's appendix)
    request_checks = request


# ---------------------------------------------------------------------------
# The owner's logged score phase (what a score type receives)
# ---------------------------------------------------------------------------


class ScoreLog:
    """The owner's logged score phase: one entry per showing, in the order it happened.

    items             every item of the bank (in a sealed call, in an order of its own): a score type returns one score per item,
                      in this order; `index[item]` is the position
    n                 number of showings
    task, item        per showing: the score task and the item shown (item_index: its position)
    result            per showing: the owner's graded result with the item (1.0 / 0.0)
    tag               per showing: the owner's own tag of the item (helpful, harmful, neutral or None)
    no_memory         per showing: the owner's result on that task with no item (NaN if none)
    probability       per showing: the logged chance the build had of showing that item
    explored          per showing: True if picked by exploration
    pass_, position   per showing: score pass and the task's place in the pass
    no_memory_rate    the owner's no-item success over its score tasks
    score_rules       the five families' settings (ema step and start, counter ranking)
    """

    def __init__(self, payload: dict):
        self.owner = payload["owner"]
        self.owner_maker = payload["owner_maker"]
        self.stream = payload["stream"]
        self.order = int(payload["order"])
        self.items = list(payload["items"])
        self.index = {i: n for n, i in enumerate(self.items)}
        self.task = list(payload["task"])
        self.item = list(payload["item"])
        self.item_index = np.array([self.index[i] for i in self.item], dtype=np.int64)
        self.result = np.asarray(payload["result"], dtype=float)
        self.tag = list(payload["tag"])
        self.no_memory = np.array([np.nan if v is None else float(v) for v in payload["no_memory"]], dtype=float)
        self.probability = np.array([np.nan if v is None else float(v) for v in payload["probability"]], dtype=float)
        self.explored = list(payload["explored"])
        self.pass_ = list(payload["pass"])
        self.position = list(payload["position"])
        self.n = len(self.task)
        self.no_memory_rate = float(payload["no_memory_rate"])
        self.score_rules = {f: dict(v) for f, v in payload["score_rules"].items()}

    def rows(self):
        """Each showing as a dict (task, item, result, tag, no_memory, probability, explored, pass, position)."""
        for j in range(self.n):
            yield {"task": self.task[j], "item": self.item[j], "result": float(self.result[j]), "tag": self.tag[j],
                   "no_memory": None if np.isnan(self.no_memory[j]) else float(self.no_memory[j]),
                   "probability": None if np.isnan(self.probability[j]) else float(self.probability[j]),
                   "explored": self.explored[j], "pass": self.pass_[j], "position": self.position[j]}
