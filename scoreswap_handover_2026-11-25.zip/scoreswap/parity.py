"""Parity: do the paper's rules, written as ordinary entries and scored from the release pack,
give back the paper's own numbers?

    python -m scoreswap.parity --study sim            # exports runs/sim to a temporary pack
    python -m scoreswap.parity --study sim --pack release/sim

It runs every reference rule of scoreswap/reference_rules through the harness (on the pack's
tables only) and compares, cell by cell and family by family, with the files the paper's own
evaluation wrote in runs/<study>/results/:
- arms.csv (value, regret, log and Brier scores raw and level-corrected, the mix-weight
  variants, the spread over draws) and the per-task arrays in per_task/*.npz;
- validity.csv (Cw at home, after the swap, against the extra home repeats) and retained.csv
  (mean V at home and after the swap, theta) for the five score types.
It prints the largest absolute difference per rule. The acceptance bar: 1e-9.
"""
from __future__ import annotations

import csv
import math
import sys
import tempfile
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scoreswap import scoring as SC  # noqa: E402

REF = SC.REF_DIR
ROW_COLS = ("value", "regret", "n_tasks", "log_score", "brier", "log_score_lc", "brier_lc", "value_w0.25",
            "value_w0.75", "value_wz", "draw_sd", "value_p05", "value_p95", "log_p05", "log_p95")
TASK_KEYS = {"value": "value", "regret": "regret", "log": "log", "brier": "brier", "log_lc": "log_lc",
             "brier_lc": "brier_lc", "value_w0.25": "value_w0.25", "value_w0.75": "value_w0.75", "value_wz": "value_wz"}
TOL = 1e-9


def _f(v) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return math.nan


def _printed(v):
    """A number as msr.evaluate writes it into its CSV files (rounded to 6 decimals)."""
    v = _f(v)
    return v if (math.isnan(v) or math.isinf(v)) else round(v, 6)


def _diff(a, b) -> float:
    a, b = _f(a), _f(b)
    if math.isnan(a) and math.isnan(b):
        return 0.0
    if math.isnan(a) or math.isnan(b):
        return math.inf
    return abs(a - b)


def _read(path: Path) -> list:
    with open(path, encoding="utf-8", newline="") as fh:
        return list(csv.DictReader(fh))


def rules_to_check(pack, ks=None) -> list:
    """[(arm name as in arms.csv, file, options, draws override, families)]."""
    fams = pack.families
    counts = [f for f in fams if f in ("ema_grade", "beta_grade", "tags_self")]
    with_p = [f for f in fams if f != "visits"]
    out = [("keep", "keep.py", {}, None, fams), ("wipe", "wipe.py", {}, None, fams),
           ("relevance", "relevance.py", {}, None, ["-"])]
    for lam in pack.settings["fixed_lambdas"]:
        out.append((f"fixed_{lam:g}", "fixed.py", {"lam": str(lam)}, None, fams))
    out.append(("shuffled", "shuffled.py", {}, int(pack.settings["shuffled_permutations"]), fams))
    ks = ks or [k for k in pack.settings.get("study_k_values", []) if k in pack.budgets_fit("all")]
    for k in ks:
        out += [(f"powerprior_{k}", "powerprior.py", {}, None, counts), (f"recal_{k}", "recal.py", {}, None, with_p),
                (f"retest_{k}", "retest.py", {}, None, fams), (f"audit_{k}", "audit.py", {}, None, fams),
                (f"pooled_{k}", "pooled.py", {}, None, fams), (f"fresh_{k}", "fresh.py", {}, None, fams)]
    return out


def parity(results_dir: Path, pack, ks=None, only=None, printer=print, families=None, skip=(), workers=None) -> dict:
    """Compare every reference rule with results_dir/arms.csv (+ per_task) and the score types with
    validity.csv and retained.csv. The pack must carry its private half (the paper's tables use every bank,
    every evaluation task). Returns {rule: {"max_row": d, "max_task": d, "rows": n}}."""
    if pack.private is None:
        raise ValueError("parity needs the private half: the paper's numbers use every bank, private owners included")
    results_dir = Path(results_dir)
    todo = [r for r in rules_to_check(pack, ks) if not only or r[0] in only]
    wanted = {r[0] for r in todo}
    # only the rows of the rules being checked, and only the compared columns: arms.csv holds every
    # arm of every family, which at the full size is far more than the check needs
    arms = {}
    with open(results_dir / "arms.csv", encoding="utf-8", newline="") as fh:
        for r in csv.DictReader(fh):
            if r["arm"] in wanted:
                arms[(r["owner"], r["reader"], r["stream"], int(r["seed"]), r["family"], r["arm"])] = \
                    {c: r[c] for c in ROW_COLS if c in r}
    report: dict = {}

    def per_task(key, fam, arm) -> dict:
        """Only this rule's arrays of one cell's per-task file, read when needed and kept by nobody:
        the whole file of every cell (about 3 GB at the full size) is never held at once."""
        p = results_dir / "per_task" / f"{key[0]}__{key[1]}__{key[2]}__seed{key[3]}.npz"
        with np.load(p, allow_pickle=False) as z:
            names = set(z.files)
            return {theirs: z[f"{fam}|{arm}|{theirs}"] for theirs in TASK_KEYS.values()
                    if f"{fam}|{arm}|{theirs}" in names}

    for arm, fname, opts, draws, fams in todo:
        if only and arm not in only:
            continue
        k = int(arm.rsplit("_", 1)[1]) if fname not in ("fixed.py",) and arm.rsplit("_", 1)[-1].isdigit() else 0
        worst_row = worst_task = 0.0
        worst_where = ""
        n = 0
        for fam in fams:
            if families is not None and fam != "-" and fam not in families:
                continue
            o = dict(opts)
            if fam != "-":
                o["family"] = fam
            res = SC.run_rule(pack, REF / fname, k, draws=draws, options=o, trusted=True, workers=workers, board="all",
                              first_draws=True)          # the paper's draws 0 .. draws-1 (e.g. its permutations)
            for key, rec in res["cells"].items():
                ref = arms.get((*key, fam, arm))
                if ref is None:
                    continue
                n += 1
                row = rec["row"]
                for c in ROW_COLS:
                    if c in skip or c not in ref or ref[c] == "":
                        continue          # the paper leaves this column empty for this arm
                    d = _diff(_printed(row.get(c)), ref[c])
                    if d > worst_row:
                        worst_row, worst_where = d, f"{key} {fam} {c}: scorer {row.get(c)} paper {ref[c]}"
                pt = per_task(key, fam, arm)
                for mine, theirs in TASK_KEYS.items():
                    if mine in skip or {"log_lc": "log_score_lc"}.get(mine) in skip:
                        continue
                    a = rec["arrays"].get(mine)
                    b = pt.get(theirs)
                    if a is None or b is None:
                        continue
                    a, b = np.asarray(a, float), np.asarray(b, float)
                    if a.shape != b.shape or not np.array_equal(np.isnan(a), np.isnan(b)):
                        worst_task = math.inf
                        worst_where = f"{key} {fam} per-task {mine}: missing values differ"
                        continue
                    ok = ~np.isnan(a)
                    if ok.any():
                        worst_task = max(worst_task, float(np.max(np.abs(a[ok] - b[ok]))))
            del res                                # one rule and family's results at a time
        report[arm] = {"max_row": worst_row, "max_task": worst_task, "rows": n, "where": worst_where}
        printer(f"  {arm:<16} cells x families {n:>4}   max |difference|: arms.csv as printed {worst_row:.3g}, "
                f"per-task values {worst_task:.3g}" + ("" if max(worst_row, worst_task) <= TOL else f"   <- {worst_where}"))
    if only is None or "score_types" in only:
        report.update(score_type_parity(results_dir, pack, printer, families))
    return report


def score_type_parity(results_dir: Path, pack, printer=print, families=None) -> dict:
    val = {(r["owner"], r["reader"], r["stream"], int(r["seed"]), r["family"]): r
           for r in _read(results_dir / "validity.csv")}
    ret = {(r["owner"], r["reader"], r["stream"], r["family"]): r for r in _read(results_dir / "retained.csv")}
    out = {}
    for fam in SC.PAPER_SCORE_TYPES:
        if fam not in pack.families or (families is not None and fam not in families):
            continue
        res = SC.run_score_type(pack, REF / f"{fam}.py", trusted=True, board="all")
        worst, worst_t, where, n = 0.0, 0.0, "", 0
        for key, rec in res["cells"].items():
            ref = val.get((*key, fam))
            if ref is None:
                continue
            n += 1
            for mine, theirs in (("cw_home", "home"), ("cw_swap", "swap"), ("cw_floor", "floor")):
                d = _diff(_printed(rec["row"][mine]), ref[theirs])
                if d > worst:
                    worst, where = d, f"{key} {mine}"
            p = results_dir / "per_task" / f"{key[0]}__{key[1]}__{key[2]}__seed{key[3]}.npz"
            with np.load(p, allow_pickle=False) as z:
                for q in ("home", "swap", "floor"):
                    ref_parts = z[f"{fam}|conc_{q}"]
                    for j, part in enumerate(("num", "den")):
                        a, b = np.asarray(rec["arrays"][f"{q}_{part}"], float), ref_parts[:, j]
                        if not np.array_equal(np.isnan(a), np.isnan(b)):
                            worst_t, where = math.inf, f"{key} {q} {part}: missing values differ"
                            continue
                        ok = ~np.isnan(a)
                        if ok.any():
                            worst_t = max(worst_t, float(np.max(np.abs(a[ok] - b[ok]))))
        # retained.csv: mean V per valid task pooled over the orders of a stream; 'all' sums streams
        worst_r = 0.0
        for (o, r) in pack.cells:
            per_stream = {}
            for s in pack.streams:
                vs = vh = ns = nh = 0.0
                for (oo, rr, ss, dd), rec in res["cells"].items():
                    if (oo, rr, ss) != (o, r, s):
                        continue
                    a = rec["arrays"]
                    vs += float(np.nansum(a["V_swap"]))
                    vh += float(np.nansum(a["V_home"]))
                    ns += float(np.isfinite(a["swap_den"]).sum())
                    nh += float(np.isfinite(a["home_den"]).sum())
                per_stream[s] = (vs / ns if ns else math.nan, vh / nh if nh else math.nan)
            levels = [(s, [s]) for s in pack.streams] + [("all", list(pack.streams))]
            for lvl, ss in levels:
                ref = ret.get((o, r, lvl, fam))
                if ref is None:
                    continue
                vsum = sum(per_stream[s][0] for s in ss)
                hsum = sum(per_stream[s][1] for s in ss)
                th = vsum / hsum if hsum else math.nan
                for mine, theirs in ((vsum, "v_swap"), (hsum, "v_home"), (th, "theta")):
                    d = _diff(_printed(mine), ref[theirs])
                    if d > worst_r:
                        worst_r, where = d, f"{(o, r, lvl)} {theirs}"
        out[f"score_type_{fam}"] = {"max_row": max(worst, worst_r), "max_task": worst_t, "rows": n, "where": where}
        printer(f"  score type {fam:<11} cells {n:>4}   max |difference|: validity.csv and retained.csv as printed "
                f"{max(worst, worst_r):.3g}, per-task concordance parts {worst_t:.3g}"
                + ("" if max(worst, worst_r, worst_t) <= TOL else f"   <- {where}"))
    return out


def main(argv=None) -> int:
    import argparse
    from scoreswap import export as EX
    from scoreswap.pack import Pack
    ap = argparse.ArgumentParser(description="Check that the scorer reproduces the paper's own numbers.")
    ap.add_argument("--study", required=True, help="study name (runs/<name>/) or study YAML")
    ap.add_argument("--runs-dir", default=None)
    ap.add_argument("--pack", default=None, help="an exported pack of that study (default: export to a temp folder)")
    ap.add_argument("--private", default=None, help="its private half (default: <pack>_private)")
    ap.add_argument("--workers", type=int, default=None, help="parallel processes (default: up to 8)")
    ap.add_argument("--only", default=None, help="comma-separated arm names (e.g. keep,recal_16,score_types)")
    ap.add_argument("--families", default=None, help="comma-separated score families (default: all)")
    ap.add_argument("--skip", default="", help="comma-separated columns to leave out (e.g. log_score_lc,brier_lc "
                                               "when the results were written by older code)")
    a = ap.parse_args(argv)
    st = EX.resolve_study(a.study, a.runs_dir)
    tmp = None
    if a.pack:
        pack_dir = Path(a.pack)
    else:
        tmp = tempfile.TemporaryDirectory(prefix="scoreswap_parity_")
        pack_dir = Path(tmp.name) / "pack"
        EX.export(a.study, pack_dir, a.runs_dir, reference=False)
    priv = Path(a.private) if a.private else pack_dir.parent / f"{pack_dir.name}_private"
    pack = Pack(pack_dir, private=priv)
    print(f"Parity of the scorer against {st.results_dir} (tolerance {TOL:g}):")
    rep = parity(st.results_dir, pack, only=a.only.split(",") if a.only else None,
                 families=a.families.split(",") if a.families else None,
                 skip=tuple(x for x in a.skip.split(",") if x), workers=a.workers)
    bad = {k: v for k, v in rep.items() if max(v["max_row"], v["max_task"]) > TOL or v["rows"] == 0}
    print("ALL MATCH" if not bad else f"NOT MATCHING: {sorted(bad)}")
    if tmp:
        tmp.cleanup()
    return 0 if not bad else 1


if __name__ == "__main__":
    raise SystemExit(main())
