"""Reading an entry file WITHOUT running it.

The trusted launcher must know an entry's kind, name and settings, and which libraries it
imports (so it can load them once, before the sandbox closes), without executing a single line
of the entry. Both are read from the file's syntax tree. Only simple constant assignments count:

    KIND = "swap_day_rule"          # or "score_type"; optional when rule() or score() is defined
    NAME = "my_rule"                # optional, default: the file name
    DRAW_KEY = "recal"              # optional: whose seeded random checks to share (default recal)
    RANDOM = True                   # optional: run every seeded draw even at budget 0
    DESCRIPTION = "one line"        # optional
"""
from __future__ import annotations

import ast
from pathlib import Path

#: An entry is one Python file. Its folder is never readable to it, so data cannot sit beside it.
MAX_ENTRY_BYTES = 256 * 1024
DEFAULT_DRAW_KEY = "recal"
DRAW_KEYS = ("recal", "powerprior", "powerprior_flat", "retest", "audit", "pooled", "fresh")
KINDS = ("swap_day_rule", "score_type")


class EntryError(ValueError):
    """A plain-language problem with an entry file."""


def read_source(path: Path) -> str:
    path = Path(path)
    if not path.exists():
        raise EntryError(f"{path} does not exist")
    if path.suffix != ".py":
        raise EntryError(f"{path.name}: an entry is one Python file ending in .py")
    size = path.stat().st_size
    if size > MAX_ENTRY_BYTES:
        raise EntryError(f"{path.name} is {size:,} bytes; an entry may be at most {MAX_ENTRY_BYTES:,} bytes "
                         f"(it is a rule, not a data file)")
    try:
        return path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        raise EntryError(f"{path.name} is not UTF-8 text") from None


def parse(src: str, name: str) -> ast.Module:
    try:
        return ast.parse(src, filename=name)
    except SyntaxError as e:
        raise EntryError(f"{name} has a syntax error on line {e.lineno}: {e.msg}") from None


def meta_from_source(src: str, path: Path) -> dict:
    """The entry's kind, name and settings, read from its syntax tree (nothing is executed)."""
    path = Path(path)
    tree = parse(src, path.name)
    consts, funcs = {}, set()
    for node in tree.body:
        if isinstance(node, ast.FunctionDef):
            funcs.add(node.name)
        elif isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            key = node.targets[0].id
            if key in ("KIND", "NAME", "DRAW_KEY", "RANDOM", "DESCRIPTION"):
                try:
                    consts[key] = ast.literal_eval(node.value)
                except ValueError:
                    raise EntryError(f"{path.name}: {key} must be a plain constant (for example "
                                     f"{key} = \"...\"), so it can be read without running the file") from None
    kind = consts.get("KIND")
    if kind is None:
        kind = "swap_day_rule" if "rule" in funcs else ("score_type" if "score" in funcs else None)
    if kind not in KINDS:
        raise EntryError(f"{path.name}: define rule(bank, candidates, swap, checks) for a swap-day rule or "
                         f"score(log) for a score type (and you may set KIND = 'swap_day_rule' or 'score_type')"
                         + (f"; KIND is {kind!r}" if kind is not None else ""))
    fn = "rule" if kind == "swap_day_rule" else "score"
    if fn not in funcs:
        raise EntryError(f"{path.name}: KIND is {kind!r} but there is no top-level `def {fn}(...)`")
    draw_key = str(consts.get("DRAW_KEY", DEFAULT_DRAW_KEY))
    if draw_key not in DRAW_KEYS:
        raise EntryError(f"{path.name}: DRAW_KEY {draw_key!r} is not one of {DRAW_KEYS}")
    name = str(consts.get("NAME") or path.stem).strip().replace(" ", "_") or path.stem
    return {"kind": kind, "name": name, "draw_key": draw_key, "random": bool(consts.get("RANDOM", False)),
            "description": str(consts.get("DESCRIPTION", "") or "").strip()}


def imports_of(src: str) -> list:
    """Every absolute module the file imports anywhere (top level or inside functions), so the
    launcher can load them before the sandbox closes. Relative imports are ignored."""
    out = []
    for node in ast.walk(parse(src, "entry")):
        if isinstance(node, ast.Import):
            out += [a.name for a in node.names]
        elif isinstance(node, ast.ImportFrom) and node.module and not node.level:
            out.append(node.module)
            out += [f"{node.module}.{a.name}" for a in node.names if a.name != "*"]
    seen, res = set(), []
    for m in out:
        if m not in seen:
            seen.add(m)
            res.append(m)
    return res


def entry_meta(path: Path) -> dict:
    """Kind, name and settings of an entry file (read, not run)."""
    return meta_from_source(read_source(path), path)
