"""ScoreSwap command line: export, describe, check, score, leaderboard.

    python -m scoreswap export      --study sim --out release/sim          (also writes release/sim_private:
                                                                            the private owners' banks, the ranked board)
    python -m scoreswap describe    --pack release/sim
    python -m scoreswap check       examples/rank_focus_shrink.py --pack release/sim
    python -m scoreswap score       examples/rank_focus_shrink.py --pack release/sim --budget 16
    python -m scoreswap leaderboard examples/ --pack release/sim --budgets 0,16
Maintainers add --private release/sim_private to score and leaderboard (the ranked board: the banks of the
private owners, held out whole).

No command calls a model, uses the network, or reads an API key.
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

# one BLAS thread per process: the scorer runs in parallel processes, and a process without helper
# threads can be forked safely (set before numpy is first imported)
for _v in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "1")

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def _options(pairs) -> dict:
    out = {}
    for p in pairs or []:
        if "=" not in p:
            raise SystemExit(f"--set needs name=value, got {p!r}")
        k, v = p.split("=", 1)
        out[k.strip()] = v.strip()
    return out


def _budgets(text: str | None):
    if not text:
        return None
    try:
        return [int(x) for x in str(text).replace(" ", "").split(",") if x != ""]
    except ValueError:
        raise SystemExit(f"--budgets must be whole numbers separated by commas, e.g. 0,16,64 (got {text!r})")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m scoreswap",
                                 description="Score a swap-day rule or a score type offline, from frozen probe tables.")
    sub = ap.add_subparsers(dest="cmd", required=True)

    e = sub.add_parser("export", help="write a release pack (frozen tables) from a finished study in runs/<name>/")
    e.add_argument("--study", required=True, help="study name (runs/<name>/) or a study YAML file")
    e.add_argument("--out", required=True, help="folder to write, e.g. release/sim")
    e.add_argument("--private-out", default=None, help="folder for the private half (default: <out>_private)")
    e.add_argument("--runs-dir", default=None, help="where run folders are (default: runs/)")
    e.add_argument("--force", action="store_true", help="replace the folders if they exist")
    e.add_argument("--no-text", action="store_true", help="leave all item and task text out (by default text is "
                                                         "included for public banks wherever the licences allow it)")
    e.add_argument("--with-text", action="store_true", help=argparse.SUPPRESS)   # the default now; kept for old scripts
    e.add_argument("--no-reference", action="store_true", help="skip computing the paper's rules for the boards")
    e.add_argument("--workers", type=int, default=None, help="parallel processes (default: up to 8)")

    d = sub.add_parser("describe", help="print what a rule receives in one call, with sample values")
    d.add_argument("--pack", required=True, help="release pack folder")
    d.add_argument("--owner", default=None)
    d.add_argument("--reader", default=None)
    d.add_argument("--budget", type=int, default=None)

    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--pack", required=True, help="release pack folder")
    common.add_argument("--private", default=None, help="the private half: the ranked board (maintainers only)")
    common.add_argument("--set", action="append", default=None, metavar="NAME=VALUE", help="an option passed to the rule")
    common.add_argument("--trusted", action="store_true", help="run in this process, unsealed (only your own code)")
    common.add_argument("--workers", type=int, default=None, help="parallel processes (default: up to 8)")
    common.add_argument("--timeout", type=float, default=300.0, help="seconds one call may take (default 300)")
    common.add_argument("--memory", type=float, default=None,
                        help="GB of memory one call may use beyond the launcher's (default 2)")
    common.add_argument("--time-budget", type=float, default=None,
                        help="hours the whole run of one entry may take (default: 6 for score, none for check)")

    c = sub.add_parser("check", parents=[common],
                       help="check an entry: interface contract, sealing, order and repeat, canary, held-out gap")
    c.add_argument("entry", help="the entry's .py file")
    c.add_argument("--budget", action="append", type=int, default=None,
                   help="budget k to check at (repeat for several; default 0 and 16)")
    c.add_argument("--draws", type=int, default=3, help="random draws per cell to check (default 3)")
    c.add_argument("--cells", type=int, default=None, help="check only the first N (owner, reader) cells")

    s = sub.add_parser("score", parents=[common], help="score an entry at one budget, beside keep, wipe and the paper's rules")
    s.add_argument("entry", help="the entry's .py file")
    s.add_argument("--budget", type=int, default=0, help="fresh checks k (0, 8, 16, 32, 64, 128 or 256; default 0)")
    s.add_argument("--out", default="scores", help="where results go (default: scores/ in the current folder)")
    s.add_argument("--draws", type=int, default=None, help="random draws (default: the pack's, 200 in the paper)")
    s.add_argument("--split", default=None, choices=("dev", "test", "all"),
                   help="board: dev (the development board, public owners; default without --private), test (the "
                        "ranked board, private owners), all (every bank: the paper's tables); with --private the "
                        "default is dev and test, with the held-out alarm")
    s.add_argument("--no-compare", action="store_true", help="skip the paper's rules beside it")

    b = sub.add_parser("leaderboard", parents=[common], help="re-run every entry in a folder and rebuild both boards")
    b.add_argument("entries", help="folder of entry .py files")
    b.add_argument("--budgets", default=None, help="comma-separated budgets (default: every registered k that fits)")
    b.add_argument("--out", default="boards", help="where the boards go (default: boards/ in the current folder)")
    b.add_argument("--draws", type=int, default=None, help="random draws (default: the pack's)")
    b.add_argument("--no-paper", action="store_true", help="leave the paper's own rules off the boards")

    a = ap.parse_args(argv)
    from scoreswap.harness import EntryFailure
    from scoreswap.pack import PackError
    try:
        if a.cmd == "export":
            from scoreswap.export import export
            export(a.study, Path(a.out), a.runs_dir, force=a.force, private_out=a.private_out,
                   with_text=not a.no_text, reference=not a.no_reference, processes=a.workers)
            return 0
        if a.cmd == "describe":
            from scoreswap.commands import describe
            describe(Path(a.pack), owner=a.owner, reader=a.reader, budget=a.budget)
            return 0
        priv = Path(a.private) if a.private else None
        if a.cmd == "check":
            from scoreswap.check import check
            ok = check(Path(a.entry), Path(a.pack), budgets=a.budget, draws=a.draws, cells=a.cells,
                       trusted=a.trusted, options=_options(a.set), private=priv, workers=a.workers, timeout=a.timeout,
                       memory_gb=a.memory, time_budget=(a.time_budget * 3600 if a.time_budget else None))
            return 0 if ok else 1
        if a.cmd == "score":
            from scoreswap.commands import score
            score(Path(a.entry), Path(a.pack), a.budget, Path(a.out), a.draws, _options(a.set), a.trusted,
                  compare=not a.no_compare, private=priv, split=a.split, workers=a.workers, timeout=a.timeout,
                  memory_gb=a.memory, time_budget=(a.time_budget * 3600 if a.time_budget else None))
            return 0
        if a.cmd == "leaderboard":
            from scoreswap.commands import leaderboard
            leaderboard(Path(a.entries), Path(a.pack), _budgets(a.budgets), Path(a.out), a.draws,
                        include_paper=not a.no_paper, private=priv, workers=a.workers, timeout=a.timeout,
                        memory_gb=a.memory, time_budget=(a.time_budget * 3600 if a.time_budget else None))
            return 0
    except (EntryFailure, PackError, FileNotFoundError, FileExistsError, ValueError) as err:
        print(f"Stopped: {err}")
        return 2
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
