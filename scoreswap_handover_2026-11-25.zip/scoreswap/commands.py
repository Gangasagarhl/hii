"""The `score`, `leaderboard` and `describe` commands (export and check live in their own modules).

    python -m scoreswap score ENTRY --pack PACK [--budget K] [--out scores/]
    python -m scoreswap score ENTRY --pack PACK --private PACK_private [--split test|all]   (maintainers)
    python -m scoreswap leaderboard ENTRIES_DIR --pack PACK [--private PACK_private] [--budgets 0,8,16,32,64]
    python -m scoreswap describe --pack PACK

Which board is scored, said in every output:
- dev (the default): the development board, the PUBLIC owners' banks. You may tune on it; a rule can
  also have memorised it, so a development number is never a ranking.
- test (with --private, maintainers only): the ranked board, the PRIVATE owners' banks (never seen by
  an entrant) with a secret seed for the random checks. This is the board's ranking.
- all (with --private --split all): every bank, the tables of the paper.

`score` writes, into <out>/<entry name>/k<K>/ (a score type: <out>/<entry name>/):
    cells.csv     one row per cell (owner, reader, stream, order) and split
    summary.csv   every measure per ordered pair (each stream and over the streams) and per kind of
                  swap, with the two-way 95 % interval (primary: msr.metrics' delete-one-cluster jackknife)
                  and the task-only bootstrap interval (secondary; the paper's tables of rule values use it)
    compare.csv   the entry minus keep, wipe and the paper's rules at the same budget, on the same
                  tasks and the same seeded draws, with both intervals
    SUMMARY.md    the same in plain words
    run.json      what was run: entry file and its sha256, pack fingerprint, split, budget, draws, sandbox
"""
from __future__ import annotations

import json
import math
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from scoreswap import harness as H
from scoreswap import scoring as SC
from scoreswap import stats as ST
from scoreswap.pack import Pack

KINDS_SHOWN = ("same_maker_upgrade", "same_maker_downgrade", "same_maker_other", "cross_maker", "home")
INTERVAL_NOTE = ("Brackets: 95 % intervals. Two-way = tasks and tips both treated as sampled: msr.metrics.robust_variance, "
                 "the delete-one-cluster jackknife over task ids and tips (a tip that recurs in several stream orders "
                 "is one cluster; the primary interval). Theta's bracket is the union of its two-way and task-only "
                 "Fieller sets (msr.metrics.theta_tests). Task-only = the task-id cluster bootstrap, 10,000 draws, "
                 "seed 0 (secondary; the paper's tables of rule values use this one, so on all evaluation tasks they "
                 "match it digit for digit).")


def _progress(printer, label: str):
    state = {"last": 0.0}

    def p(i, n, secs):
        if i == n or time.time() - state["last"] > 5:
            state["last"] = time.time()
            printer(f"  [{label}] {100.0 * i / n:5.1f} %  ({i}/{n} banks, {secs:.0f} s)")
    return p


BOARD_VERSION = "scoreswap-board/4"   # changes whenever a board is computed differently (4: whole banks held out)
DEFAULT_TIME_BUDGET_H = 6.0       # hours one sealed entry may take per board in `score` (--time-budget)
SPLIT_BOARD = {"dev": "development", "test": "ranked", "all": "all tasks (paper's tables)"}


def _pooled_stream(pack) -> str:
    return "all" if len(pack.streams) > 1 else pack.streams[0]


def choose_splits(pack, split: str | None) -> list:
    if split is None:
        return ["dev", "test"] if pack.private is not None else ["dev"]
    if split in ("test", "all") and pack.private is None:
        raise H.EntryFailure(f"--split {split} needs the private folder (--private), held by the maintainers; "
                             f"without it only the development board can be scored")
    if split not in ST.SPLIT_SETS:
        raise H.EntryFailure(f"--split must be dev, test or all, not {split!r}")
    return [split]


def split_banner(split: str) -> str:
    return {"dev": "DEVELOPMENT board: the banks of the PUBLIC owners, with every reader's results on them. You may "
                   "have tuned on them, and an entry can carry every public result in its file, so this is a "
                   "development number, not a ranking. The RANKED board (the banks of the private owners, never "
                   "published, and a secret seed for the random checks) is scored by the maintainers from your entry "
                   "file.",
            "test": "RANKED board: the banks of the PRIVATE owners (held out whole: no result, score or text of them is "
                    "public) with a secret seed for the random checks (maintainers' scoring). This is the number the "
                    "board ranks.",
            "all": "ALL banks: every cell, with the paper's seeds, as in the paper's tables (maintainers' "
                   "scoring)."}[split]


def sandbox_lines(sb: dict) -> list:
    if not sb:
        return ["Run in this process (--trusted): not sealed."]
    if not sb.get("sealed", True):
        return ["Run unsealed (--trusted)."]
    out = ["Run sealed: one fresh process per call, forked from a launcher that never runs the entry."]
    for k in ("jail", "landlock", "seccomp", "worker"):
        if k in sb:
            out.append(f"{k}: {sb[k]}")
    if sb.get("memory_per_call_gb"):
        out.append(f"memory: at most {sb['memory_per_call_gb']:g} GB per call beyond the launcher's")
    return out


def require_jail(boards: list, trusted: bool, printer) -> None:
    """A RANKED result needs the namespace jail (bubblewrap) on Linux x86_64 with Landlock; development
    scoring falls back to the kernel sandbox alone, with a warning."""
    if trusted:
        return
    ok, why = H.jail_status()
    if ok:
        return
    if "test" in boards or "all" in boards:
        raise H.EntryFailure(f"refused: a RANKED result needs the namespace jail, and it is not available here "
                             f"({why}). Install bubblewrap on Linux x86_64 (kernel 5.13 or newer) and score again.")
    printer(f"  WARNING: no namespace jail ({why}); development scoring continues with the kernel sandbox alone "
            f"(Landlock and seccomp where available). A ranked result would be refused.")


def held_out_alarm(pack, res_dev: dict, res_test: dict, kind: str, family: str) -> dict:
    """The maintainers' held-out alarm, on the FULL runs of both boards: the entry's lead over keep
    (a score type: over ema_grade, in V after the swap) on the development board (public owners' swap
    cells) minus its lead on the ranked board (private owners' swap cells). Both boards score the same
    probe tasks and write tasks with different owners' banks, so the gap's two-way SE comes from one
    jackknife over both boards together (shared task and item clusters count once)."""
    import math as _m
    from scoreswap.check import HELD_OUT_SE, MIN_GAP
    out, diffs, signed = {}, {}, []
    for sign, sp, res in ((1.0, "dev", res_dev), (-1.0, "test", res_test)):
        swaps = [c for c in pack.board_cells(sp) if c[0] != c[1]]
        items = [(o, r, s, 1.0 / (len(swaps) * len(pack.streams))) for o, r in swaps for s in pack.streams]
        store = SC.restrict(res, sp)
        if kind == "swap_day_rule":
            ref, key = SC.paper_rule_stores(pack, 0, family, sp).get("keep", {}), "value"
        else:
            ref, key = SC.restrict(SC.run_score_type(pack, None, family=pack.headline, board=sp), sp), "V_swap"
        diffs.update(SC._diff_store(store, ref, (key,)))
        out[sp] = ST.Clusters(pack, sp, B=0).linear_batch([(SC._diff_store(store, ref, (key,)), key)], items)[0]
        signed += [(o, r, s, sign * w) for o, r, s, w in items]
    both = ST.Clusters(pack, "all", B=0).linear_batch([(diffs, key)], signed)[0]
    gap = out["dev"]["estimate"] - out["test"]["estimate"]
    se = both["se"]
    # a board where the entry equals keep on every task has no variance at all (its SE is 0, shown as NaN)
    if not _m.isfinite(se):
        ses = [out[s]["se"] for s in ("dev", "test")]
        se = _m.sqrt(sum(x * x for x in ses if _m.isfinite(x))) if any(_m.isfinite(x) for x in ses) else float("nan")
    thr = max(MIN_GAP if key == "value" else 0.0, HELD_OUT_SE * se) if _m.isfinite(se) else float("inf")
    raised = bool(_m.isfinite(gap) and gap > thr)
    what = "first-shown success minus keep's" if key == "value" else "V after the swap minus ema_grade's"
    text = (f"held-out alarm {'RAISED' if raised else 'clear'}: {what} is {SC.fnum(out['dev']['estimate'])} on the "
            f"development board and {SC.fnum(out['test']['estimate'])} on the ranked board (gap {SC.fnum(gap)}, "
            f"allowed {SC.fnum(thr)} = max({HELD_OUT_SE:g} SE" + (", 3 points" if key == "value" else "") + "))"
            + (": the entry does far better where it could see the outcomes; it looks tuned to, or memorised from, "
               "the public data" if raised else ""))
    return {"gap": gap, "se": se, "allowed": thr, "raised": raised, "dev": out["dev"]["estimate"],
            "test": out["test"]["estimate"], "text": text}


# ---------------------------------------------------------------------------
# score
# ---------------------------------------------------------------------------


def score(entry: Path, pack_dir: Path, budget: int = 0, out_dir: Path = Path("scores"), draws: int | None = None,
          options: dict | None = None, trusted: bool = False, compare: bool = True, printer=print,
          private: Path | None = None, split: str | None = None, workers: int | None = None,
          timeout: float = H.CALL_TIMEOUT, memory_gb: float | None = None, time_budget: float | None = None) -> Path:
    pack = Pack(pack_dir, private=private)
    entry = Path(entry).resolve()
    meta = H._meta(entry)
    name = meta["name"]
    splits = choose_splits(pack, split)
    require_jail(splits, trusted, printer)
    if time_budget is None and not trusted:
        time_budget = DEFAULT_TIME_BUDGET_H * 3600
    printer(f"Scoring {name} ({meta['kind'].replace('_', ' ')}) on the pack of study '{pack.manifest['study']}'"
            + (f" at budget k = {budget}" if meta["kind"] == "swap_day_rule" else "")
            + ("" if not trusted else " in this process (trusted)") + f"; boards: {', '.join(splits)}")
    cache = Path(out_dir) / "_paper_rules"
    results = {}
    for sp in splits:
        prog = _progress(printer, f"{name}, {sp}")
        if meta["kind"] == "swap_day_rule":
            results[sp] = SC.run_rule(pack, entry, budget, draws=draws, options=options, trusted=trusted,
                                      workers=workers, progress=prog, timeout=timeout, board=sp,
                                      time_budget=time_budget, memory_gb=memory_gb)
        else:
            results[sp] = SC.run_score_type(pack, entry, trusted=trusted, workers=workers, progress=prog,
                                            timeout=timeout, board=sp, time_budget=time_budget, memory_gb=memory_gb)
    res = results[splits[0]]
    dest = Path(out_dir) / name / f"k{budget}" if meta["kind"] == "swap_day_rule" else Path(out_dir) / name
    rows, comp, cells = [], [], []
    for sp in splits:
        CL = ST.Clusters(pack, sp)
        store = SC.restrict(results[sp], sp)
        crow = SC.cell_rows(results[sp], sp, meta["kind"])
        cells += crow
        if meta["kind"] == "swap_day_rule":
            fam = results[sp]["meta"]["ref_family"]
            others = SC.paper_rule_stores(pack, budget, fam, sp, cache, printer, workers) if compare else {}
            r, c = SC.rule_summary(pack, CL, store, others, crow)
        else:
            others = SC.paper_score_type_stores(pack, sp) if compare else {}
            r, c = SC.score_type_summary(pack, CL, store, others)
        rows += r
        comp += c
    alarm = None
    if "dev" in results and "test" in results:
        alarm = held_out_alarm(pack, results["dev"], results["test"], meta["kind"],
                               res["meta"].get("ref_family") or pack.headline)
        printer(f"  {alarm['text']}")
    dest.mkdir(parents=True, exist_ok=True)
    SC.write_rows(dest / "cells.csv", cells)
    SC.write_rows(dest / "summary.csv", rows)
    SC.write_rows(dest / "compare.csv", comp)
    run = {"entry": entry.name, "entry_sha256": SC.file_sha(entry), "name": name, "kind": meta["kind"],
           "pack_study": pack.manifest["study"], "pack_fingerprint": pack.fingerprint,
           "pack_version": (pack.manifest.get("version") or {}).get("pack"), "splits": splits,
           "boards": {sp: SPLIT_BOARD[sp] for sp in splits},
           "budget": budget if meta["kind"] == "swap_day_rule" else None,
           "draws": res["meta"].get("draws"), "draw_key": meta.get("draw_key"), "options": options or {},
           "theta_family": res["meta"].get("ref_family"), "sandbox": res["meta"].get("sandbox", {}),
           "held_out_alarm": alarm,
           "scored_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
           "intervals": "two-way (task id x item) delete-one-cluster jackknife, msr.metrics.robust_variance, 95 % "
                        "(primary; theta: union of the two-way and task-only Fieller sets, msr.metrics.theta_tests); "
                        "task-id cluster bootstrap, 10,000 draws (secondary, the one the paper's rule tables use)",
           "home_signal_rule": "msr.metrics.home_signal_flag (the owner's signal on its calibration tasks)",
           "draw_rule": "each per-task value is the mean over the seeded draws (pre-registration 4.5)"}
    (dest / "run.json").write_text(json.dumps(run, indent=1, default=str), encoding="utf-8")
    md = (rule_markdown if meta["kind"] == "swap_day_rule" else score_type_markdown)(pack, name, run, rows, comp)
    (dest / "SUMMARY.md").write_text(md, encoding="utf-8")
    printer(f"Results in {dest.resolve()} (SUMMARY.md, summary.csv, compare.csv, cells.csv)")
    return dest


def _get(rows, **kw):
    for r in rows:
        if all(r.get(k) == v for k, v in kw.items()):
            return r
    return None


def _both(r, d=3) -> str:
    """'est [two-way] (task-only [..])'."""
    if r is None:
        return "-"
    s = f"{SC.fnum(r.get('estimate'), d)} {SC.interval(r.get('lo'), r.get('hi'), d)}"
    tb = SC.interval(r.get("lo_boot"), r.get("hi_boot"), d)
    return s + (f" (task-only {tb})" if tb else "")


def rule_markdown(pack, name: str, run: dict, rows: list, comp: list) -> str:
    k = run["budget"]
    s_all = _pooled_stream(pack)
    others = []
    for c in comp:
        if c["other_rule"] not in others:
            others.append(c["other_rule"])
    has_p = any(r["metric"] == "log_lc" for r in rows)
    L = [f"# {name}: swap-day rule at budget k = {k}", ""]
    for sp in run["splits"]:
        L += [f"**{split_banner(sp)}**", ""]
    if run.get("held_out_alarm"):
        L += [f"**{run['held_out_alarm']['text']}**", ""]
    L += [f"Scored from the frozen tables of study `{run['pack_study']}` with no model call (pack fingerprint "
          f"`{run['pack_fingerprint'][:16]}`). Each value is a mean over the evaluation tasks; {run['draws']} seeded "
          f"draw(s), each task's value the mean over the draws. Differences use the same tasks and the same draws.",
          "", INTERVAL_NOTE, "",
          "First-shown success: the reader's success with the candidate the rule shows first (higher is better). "
          "Regret: the gap to the task's best candidate (lower is better). Theta: the share of the owner's home "
          f"ranking signal (its `{run.get('theta_family')}` score with its own results) that the rule's order keeps "
          "for the reader; at a home cell the reader is the owner itself with the same results, so keep's theta "
          "there is exactly 1. Theta = retained agreement x stakes; retained agreement reads 'not estimated (reader's "
          "spread below z = 2)' where the reader's spread cannot "
          "be told from zero, and theta reads 'no home signal' where the owner's score has no ranking signal on its "
          "calibration tasks (msr.metrics.home_signal_flag).", ""]
    for line in sandbox_lines(run.get("sandbox") or {}):
        L.append(f"- {line}")
    L.append("")
    for sp in run["splits"]:
        L += [f"## By kind of swap, {ST.SPLIT_LABEL[sp]}" + (" (streams pooled)" if s_all == "all" else f" ({s_all})"), ""]
        head = "| kind | first-shown success | " + "".join(f"minus {o} | " for o in others) + \
               "regret | " + ("log score (level-corrected) | " if has_p else "") + "theta | retained agreement | checks used |"
        L += [head, "|" + "---|" * (head.count("|") - 1)]
        for kind in KINDS_SHOWN:
            v = _get(rows, split=sp, level="kind", kind=kind, stream=s_all, metric="value")
            if v is None:
                continue
            cells = [ST.KIND_LABEL[kind], _both(v)]
            for o in others:
                c = _get(comp, split=sp, level="kind", kind=kind, stream=s_all, metric="value", other_rule=o)
                cells.append("-" if c is None else f"{SC.fnum(c['difference'])} {SC.interval(c['lo'], c['hi'])}")
            rg = _get(rows, split=sp, level="kind", kind=kind, stream=s_all, metric="regret")
            cells.append(SC.fnum(rg["estimate"]) if rg else "-")
            if has_p:
                lg = _get(rows, split=sp, level="kind", kind=kind, stream=s_all, metric="log_lc")
                cells.append(f"{SC.fnum(lg['estimate'])} {SC.interval(lg['lo'], lg['hi'])}" if lg else "-")
            th = _get(rows, split=sp, level="kind", kind=kind, stream=s_all, metric="theta")
            cells.append(_theta_cell(th))
            cells.append(_order_cell(_get(rows, split=sp, level="kind", kind=kind, stream=s_all, metric="order")))
            ch = _get(rows, split=sp, level="kind", kind=kind, stream=s_all, metric="checks_used")
            cells.append(SC.fnum(ch["estimate"], 1) if ch else "-")
            L.append("| " + " | ".join(cells) + " |")
        L += ["", f"### Every ordered pair, {ST.SPLIT_LABEL[sp]}", "",
              "| owner -> reader | kind | first-shown success | minus keep | minus wipe | regret | theta |",
              "|---|---|---|---|---|---|---|"]
        for (o, r) in pack.board_cells(sp):
            v = _get(rows, split=sp, level="pair", owner=o, reader=r, stream=s_all, metric="value")
            if v is None:
                continue
            ck = _get(comp, split=sp, level="pair", owner=o, reader=r, stream=s_all, metric="value", other_rule="keep")
            cw = _get(comp, split=sp, level="pair", owner=o, reader=r, stream=s_all, metric="value", other_rule="wipe")
            rg = _get(rows, split=sp, level="pair", owner=o, reader=r, stream=s_all, metric="regret")
            th = _get(rows, split=sp, level="pair", owner=o, reader=r, stream=s_all, metric="theta")
            L.append(f"| {o} -> {r} | {pack.kind[(o, r)]} | {SC.fnum(v['estimate'])} {SC.interval(v['lo'], v['hi'])} | "
                     f"{SC.fnum(ck['difference']) if ck else '-'} | {SC.fnum(cw['difference']) if cw else '-'} | "
                     f"{SC.fnum(rg['estimate']) if rg else '-'} | {SC.fnum(th['estimate'], 2) if th else '-'} |")
        L.append("")
    L += ["Per-stream values, the Brier scores, the uncorrected log score, Cw, both intervals of every number and "
          "the paper's rules' own values are in summary.csv and compare.csv; one row per cell is in cells.csv.", ""]
    return "\n".join(L)


def score_type_markdown(pack, name: str, run: dict, rows: list, comp: list) -> str:
    s_all = _pooled_stream(pack)
    others = []
    for c in comp:
        if c["other_rule"] not in others:
            others.append(c["other_rule"])
    L = [f"# {name}: score type", ""]
    for sp in run["splits"]:
        L += [f"**{split_banner(sp)}**", ""]
    if run.get("held_out_alarm"):
        L += [f"**{run['held_out_alarm']['text']}**", ""]
    L += [f"Scored from the frozen tables of study `{run['pack_study']}` with no model call (pack fingerprint "
          f"`{run['pack_fingerprint'][:16]}`).", "",
          "Theta (value kept) is the share of the score's ranking signal at home (the owner's results) left with the "
          "reader's results after the swap (1 = all, 0 = none); theta = retained agreement x stakes, where retained agreement is how well the "
          "old order still fits the new model and stakes how much the new model cares which tip it gets. Theta means "
          "something only where there is a home signal to keep: 'no home signal' marks a group whose owner's score "
          f"is less than {_cal_z():g} standard errors above zero on its calibration tasks (msr.metrics.home_signal_flag, the "
          "paper's one rule), and Cw at home is always shown beside it. Retained agreement reads 'not estimated "
          "(reader's spread below z = 2)' where the "
          "reader's spread on the calibration tasks cannot be told from zero. Brackets: theta's 95 % set is the union "
          "of its two-way and task-only Fieller sets (msr.metrics.theta_tests); order and stakes: Fieller intervals "
          "from the same variance. Cw is the weighted concordance (0.5 = chance). In the home row the 'swap' is the "
          "self-swap: the owner's later repeats 3-4 against its repeats 1-2.", ""]
    for sp in run["splits"]:
        L += [f"## By kind of swap, {ST.SPLIT_LABEL[sp]}" + (" (streams pooled)" if s_all == "all" else f" ({s_all})"), "",
              "| kind | theta | retained agreement | stakes | home signal | Cw at home | Cw after the swap |"
              + "".join(f" theta of {o} |" for o in others),
              "|" + "---|" * (7 + len(others))]
        for kind in KINDS_SHOWN:
            th = _get(rows, split=sp, level="kind", kind=kind, stream=s_all, metric="theta")
            if th is None:
                continue
            h = _get(rows, split=sp, level="kind", kind=kind, stream=s_all, metric="cw_home")
            w = _get(rows, split=sp, level="kind", kind=kind, stream=s_all, metric="cw_swap")
            od = _get(rows, split=sp, level="kind", kind=kind, stream=s_all, metric="order")
            sk = _get(rows, split=sp, level="kind", kind=kind, stream=s_all, metric="stakes")
            cells = [ST.KIND_LABEL[kind], f"{SC.fnum(th['estimate'], 2)} {SC.interval(th['lo'], th['hi'], 2)}",
                     _order_cell(od), _plain_cell(sk),
                     "yes" if th.get("home_signal") else "NO (theta not meaningful)",
                     SC.fnum(h["estimate"]) if h else "-", SC.fnum(w["estimate"]) if w else "-"]
            for o in others:
                c = _get(comp, split=sp, level="kind", kind=kind, stream=s_all, other_rule=o)
                cells.append(SC.fnum(c["other_value"], 2) if c else "-")
            L.append("| " + " | ".join(cells) + " |")
        L += ["", f"### Every ordered pair, {ST.SPLIT_LABEL[sp]}", "",
              "| owner -> reader | kind | theta | home signal | Cw at home | Cw after |", "|---|---|---|---|---|---|"]
        for (o, r) in pack.board_cells(sp):
            th = _get(rows, split=sp, level="pair", owner=o, reader=r, stream=s_all, metric="theta")
            if th is None:
                continue
            h = _get(rows, split=sp, level="pair", owner=o, reader=r, stream=s_all, metric="cw_home")
            w = _get(rows, split=sp, level="pair", owner=o, reader=r, stream=s_all, metric="cw_swap")
            L.append(f"| {o} -> {r} | {pack.kind[(o, r)]} | {SC.fnum(th['estimate'], 2)} "
                     f"{SC.interval(th['lo'], th['hi'], 2)} | {'yes' if th.get('home_signal') else 'no'} | "
                     f"{SC.fnum(h['estimate']) if h else '-'} | {SC.fnum(w['estimate']) if w else '-'} |")
        L.append("")
    L += ["Per-stream values and the task-only bootstrap intervals are in summary.csv; differences in theta "
          "against the paper's five score types (bootstrap) are in compare.csv.", ""]
    return "\n".join(L)


# ---------------------------------------------------------------------------
# leaderboard
# ---------------------------------------------------------------------------


def leaderboard(entries_dir: Path, pack_dir: Path, budgets: list | None = None, out_dir: Path = Path("boards"),
                draws: int | None = None, include_paper: bool = True, printer=print, private: Path | None = None,
                workers: int | None = None, timeout: float = H.CALL_TIMEOUT, memory_gb: float | None = None,
                time_budget: float | None = None) -> Path:
    from scoreswap import parity as PA
    pack = Pack(pack_dir, private=private)
    entries = sorted(p for p in Path(entries_dir).glob("*.py") if not p.name.startswith("_"))
    splits = ["dev"] + (["test"] if pack.private is not None else [])
    require_jail(splits, False, printer)
    fit = [k for k in pack.settings["budgets_that_fit"] if k in pack.settings["budgets_registered"]]
    if budgets:
        dropped = [k for k in budgets if k not in fit]
        if dropped:
            printer(f"Budgets {dropped} skipped: not registered, or larger than a board's check pool "
                    f"({pack.settings['calibration_pool_cells']} cells); the paper skips them too.")
        budgets = [k for k in budgets if k in fit]
    budgets = budgets or fit
    if time_budget is None:
        time_budget = DEFAULT_TIME_BUDGET_H * 3600
    CLs = {sp: ST.Clusters(pack, sp) for sp in splits}
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    cache = out_dir / "_paper_rules"
    s_all = _pooled_stream(pack)
    listed, skipped = [], []
    st_rows, rule_rows = [], {k: [] for k in budgets}
    alarms: dict = {}
    t_start = time.time()

    keep_cache: dict = {}

    def keep_of(k, sp):
        if (k, sp) not in keep_cache:
            keep_cache[(k, sp)] = SC.paper_rule_stores(pack, k, pack.headline, sp, cache, printer, workers).get("keep")
        return keep_cache[(k, sp)]

    def add_rule(nm, source, per_split: dict, k):
        for sp in splits:
            res = per_split[sp]
            store = SC.restrict(res, sp)
            crow = SC.cell_rows(res, sp, "swap_day_rule")
            keep_store = keep_of(k, sp) if include_paper else None
            others = {"keep": keep_store} if keep_store is not None and nm != "keep" else None
            rows, comp = SC.rule_summary(pack, CLs[sp], store, others, crow)
            rows += [{"split": c["split"], "level": c["level"], "owner": c["owner"], "reader": c["reader"],
                      "kind": c["kind"], "stream": c["stream"], "n_cells": c["n_cells"], "metric": "minus_keep",
                      "meaning": "first-shown success minus keep's, same tasks and draws", "estimate": c["difference"],
                      "lo": c["lo"], "hi": c["hi"], "p": c["p"], "lo_boot": c["lo_boot"], "hi_boot": c["hi_boot"]}
                     for c in comp if c["metric"] == "value" and c["other_rule"] == "keep"]
            rule_rows[k] += [{"entry": nm, "source": source, "budget": k, **r} for r in rows]

    def add_type(nm, source, per_split: dict):
        for sp in splits:
            rows, _c = SC.score_type_summary(pack, CLs[sp], SC.restrict(per_split[sp], sp), None)
            st_rows.extend({"entry": nm, "source": source, **r} for r in rows)

    def progress(label):
        p = _progress(printer, label)
        return lambda i, n, secs: p(i, n, secs) if (i == n or i % max(1, n // 4) == 0) else None

    for path in entries:
        try:
            meta = H._meta(path)
        except H.EntryFailure as e:
            skipped.append({"entry": path.name, "reason": str(e).splitlines()[0]})
            continue
        nm = meta["name"]
        printer(f"Re-running {nm} ({meta['kind'].replace('_', ' ')}) from the released tables, sealed "
                f"({time.time() - t_start:.0f} s so far) ...")
        try:
            if meta["kind"] == "score_type":
                per = {sp: SC.run_score_type(pack, path, workers=workers, timeout=timeout, board=sp,
                                             progress=progress(f"{nm}, {sp}"), time_budget=time_budget,
                                             memory_gb=memory_gb) for sp in splits}
                add_type(nm, "outside entry", per)
                if "test" in per:
                    alarms[nm] = held_out_alarm(pack, per["dev"], per["test"], "score_type", pack.headline)
                ks = []
            else:
                ks = budgets
                for k in budgets:
                    per = {sp: SC.run_rule(pack, path, k, draws=draws, workers=workers, timeout=timeout, board=sp,
                                           progress=progress(f"{nm}, k = {k}, {sp}"), time_budget=time_budget,
                                           memory_gb=memory_gb) for sp in splits}
                    add_rule(nm, "outside entry", per, k)
                    if "test" in per:
                        alarms[f"{nm} k={k}"] = held_out_alarm(pack, per["dev"], per["test"], "swap_day_rule",
                                                               pack.headline)
            listed.append({"entry": nm, "file": path.name, "sha256": SC.file_sha(path), "kind": meta["kind"],
                           "budgets": ks, "description": meta.get("description", "")})
        except H.EntryFailure as e:
            skipped.append({"entry": path.name, "reason": str(e).splitlines()[0]})
            printer(f"  not listed: {e}")
    if include_paper:
        printer("Adding the paper's rules and score types (run by the harness from the same tables, trusted: they "
                "are the project's own code) ...")
        for f in SC.PAPER_SCORE_TYPES:
            if f in pack.families:
                add_type(f, "paper", {sp: SC.run_score_type(pack, None, family=f, board=sp) for sp in splits})
        from scoreswap import reference as REF
        for k in budgets:
            names = REF.arm_names([k])
            for arm, fname, opts, _rdraws, _fams in PA.rules_to_check(pack, [k]):
                if arm not in names:
                    continue
                kk = int(arm.rsplit("_", 1)[1]) if arm.rsplit("_", 1)[-1].isdigit() and fname != "fixed.py" else 0
                o = dict(opts, family=pack.headline)
                per = {sp: SC.run_rule(pack, PA.REF / fname, kk, draws=draws if kk else None, options=o,
                                       trusted=True, workers=workers, board=sp, progress=progress(f"{arm}, {sp}"))
                       for sp in splits}
                add_rule(arm, f"paper ({pack.headline})", per, k)
    SC.write_rows(out_dir / "score_types.csv", st_rows)
    (out_dir / "score_types.md").write_text(_type_board(pack, st_rows, s_all, splits), encoding="utf-8")
    for k in budgets:
        SC.write_rows(out_dir / f"swap_day_rules_k{k}.csv", rule_rows[k])
        (out_dir / f"swap_day_rules_k{k}.md").write_text(_rule_board(pack, rule_rows[k], s_all, k, splits),
                                                          encoding="utf-8")
    info = {"board_version": BOARD_VERSION, "pack_study": pack.manifest["study"],
            "pack_version": (pack.manifest.get("version") or {}).get("pack"), "pack_fingerprint": pack.fingerprint,
            "splits": splits, "boards": {sp: SPLIT_BOARD[sp] for sp in splits},
            "built_at": datetime.now(timezone.utc).isoformat(timespec="seconds"), "budgets": budgets,
            "listed": listed, "not_listed": skipped, "held_out_alarms": alarms,
            "rule": "every entry was re-run by the harness from the released tables, sealed (a namespace jail, one "
                    "process per call); the ranked board (the private owners' banks, secret check seed) is "
                    "built only by the maintainers, who hold the private folder; without it the boards are "
                    "development boards"}
    (out_dir / "entries.json").write_text(json.dumps(info, indent=1), encoding="utf-8")
    printer(f"Boards written to {out_dir.resolve()}: score_types.md and swap_day_rules_k<k>.md for k in {budgets}"
            + (f"; not listed: {[s['entry'] for s in skipped]}" if skipped else ""))
    return out_dir


def _find(rows, entry, kind, stream, metric, split, level="kind"):
    for x in rows:
        if (x["entry"] == entry and x["level"] == level and x["kind"] == kind and x["stream"] == stream
                and x["metric"] == metric and x["split"] == split):
            return x
    return None


def _board_header(pack, splits) -> list:
    rank = "test" if "test" in splits else "dev"
    ver = (pack.manifest.get("version") or {}).get("pack", "")
    return [f"Study `{pack.manifest['study']}`, pack `{ver}`, board format `{BOARD_VERSION}`. Every entry was re-run "
            "by the harness from the released tables, sealed (one fresh process per call).",
            "",
            ("**RANKED board** (maintainers' scoring): ranked on the banks of the PRIVATE owners, held out whole "
             "(no result, score or text of them is public), with a secret seed for the random checks. The dev "
             "columns are the DEVELOPMENT board (the public owners' banks, other cells than the ranked ones); an "
             "entry may have been tuned on it." if rank == "test" else
             "**DEVELOPMENT board: not a ranking.** It uses the banks of the public owners, so an entry may have been "
             "tuned on them or may carry them in its file. The ranking is the RANKED board, which the maintainers "
             "build from submitted entry files on the banks of the private owners."),
            "", INTERVAL_NOTE, ""], rank


CONTROLS = ("visits", "shuffled")      # registered no-signal controls: shown apart, never ranked


def _type_board(pack, rows: list, s_all: str, splits: list) -> str:
    from scoreswap.scoring import SCORE_TYPE_MEASURES
    head, rank = _board_header(pack, splits)
    measures = [m[0] for m in SCORE_TYPE_MEASURES]
    L = ["# Board of score types", ""] + head + [
        "Ranked by the VALUE AFTER THE SWAP: the mean signed validity V of the score with the new model's results "
        "(how well it still ranks the tips for the new model), with its two-way interval; theta (the share of the "
        "home signal kept), retained agreement and stakes beside it (theta = retained agreement x stakes). Ranks are "
        "grouped: 'tied with rank n' where the two 95 % intervals overlap (a conservative grouping). A score type whose home signal "
        f"is too weak (the owner's score less than {_cal_z():g} standard errors above zero on its calibration tasks: "
        "msr.metrics.home_signal_flag) has no theta to speak of; its theta reads 'no home signal'. Retained agreement "
        "reads 'not estimated (reader's spread below z = 2)' where the reader's spread cannot be told from zero. The "
        "registered no-signal controls "
        f"({', '.join(CONTROLS)}) are listed apart, under 'control', never ranked. Cw at home is shown beside every "
        "number.", ""]
    for kind in KINDS_SHOWN:
        if kind == "home":
            continue
        ents = sorted({r["entry"] for r in rows if r["kind"] == kind and r["level"] == "kind"})
        if not ents:
            continue
        rec = []
        for e in ents:
            va = {sp: _find(rows, e, kind, s_all, "value_after", sp) for sp in splits}
            m = {meas: {sp: _find(rows, e, kind, s_all, meas, sp) for sp in splits} for meas in measures}
            h = {sp: _find(rows, e, kind, s_all, "cw_home", sp) for sp in splits}
            src = next((r["source"] for r in rows if r["entry"] == e), "")
            rec.append((e, src, va, m, h, e in CONTROLS))
        if all(r[2][rank] is None for r in rec):     # no cell of this kind on the ranked board of this pack
            continue
        ranked = sorted([r for r in rec if not r[5] and r[2][rank] is not None],
                        key=lambda r: (-r[2][rank]["estimate"], r[0]))
        controls = sorted([r for r in rec if r[5] or r[2][rank] is None], key=lambda r: r[0])
        shown = {"order": "retained agreement"}
        cols = [f"value after the swap ({sp})" for sp in splits] + [f"{shown.get(meas, meas)} ({rank})" for meas in measures] + \
               [f"Cw at home ({sp})" for sp in splits]
        L += [f"## {ST.KIND_LABEL[kind]}" + (" (streams pooled)" if s_all == "all" else f" ({s_all})"), "",
              "| rank | score type | source | " + " | ".join(cols) + " |", "|" + "---|" * (3 + len(cols))]

        def line(rank_txt, r):
            e, src, va, m, h, _c = r
            vals = [_plain_cell(va[sp], 3) for sp in splits]
            for meas in measures:
                x = m[meas][rank]
                vals.append(_order_cell(x) if meas == "order" else
                            (_theta_cell(x) if meas == "theta" else _plain_cell(x)))
            vals += [SC.fnum(h[sp]["estimate"]) if h[sp] else "-" for sp in splits]
            return f"| {rank_txt} | {e} | {src} | " + " | ".join(vals) + " |"
        lead, lead_rank = None, 1           # a group: every row whose interval overlaps its leader's
        for n, r in enumerate(ranked, 1):
            tie = ""
            if lead is not None and _overlap(lead[2][rank], r[2][rank]):
                tie = f" (tied with {lead_rank})"
            else:
                lead, lead_rank = r, n
            L.append(line(f"{n}{tie}", r))
        if controls:
            L.append("| | **control** (registered no-signal controls: not ranked) | | " + " | ".join([""] * len(cols)) + " |")
            for r in controls:
                L.append(line("control", r))
        L.append("")
    L += [f"## Every ordered pair (value after the swap, {rank})", ""]
    ents = sorted({r["entry"] for r in rows})
    L += ["| owner -> reader | " + " | ".join(ents) + " |", "|" + "---|" * (1 + len(ents))]
    for (o, r_) in pack.board_cells(rank):
        if o == r_:
            continue
        vals = []
        for e in ents:
            x = next((x for x in rows if x["entry"] == e and x["level"] == "pair" and x["owner"] == o and x["reader"] == r_
                      and x["stream"] == s_all and x["metric"] == "value_after" and x["split"] == rank), None)
            vals.append("-" if x is None else SC.fnum(x["estimate"], 3))
        L.append(f"| {o} -> {r_} | " + " | ".join(vals) + " |")
    return "\n".join(L) + "\n"


def _overlap(a, b) -> bool:
    """Two values whose 95 % intervals overlap are not told apart on the board (a conservative
    grouping; the paired difference is in summary.csv)."""
    try:
        return float(a["lo"]) <= float(b["hi"]) and float(b["lo"]) <= float(a["hi"])
    except (TypeError, ValueError, KeyError):
        return False


def _rule_board(pack, rows: list, s_all: str, k: int, splits: list) -> str:
    head, rank = _board_header(pack, splits)
    L = [f"# Board of swap-day rules, budget k = {k}", ""] + head + [
        "Ranked by first-shown success per kind of swap (higher is better), with the difference from keep on the "
        "same tasks and draws and its two-way 95 % interval; 'vs keep' groups the ranks: above keep, below keep, or "
        "not distinguishable (the interval holds 0, so the order between such rows means little). Then regret, the "
        "level-corrected log score (when the rule returns p) and the checks used. To relate a row "
        "to the paper's table, use the task-only interval with --split all (maintainers): it is the paper's.", ""]
    keep = {sp: {} for sp in splits}
    for kind in KINDS_SHOWN:
        for sp in splits:
            keep[sp][kind] = _find(rows, "keep", kind, s_all, "value", sp)
    for kind in KINDS_SHOWN:
        ents = sorted({r["entry"] for r in rows if r["kind"] == kind and r["level"] == "kind"})
        if not ents:
            continue
        rec = []
        for e in ents:
            v = {sp: _find(rows, e, kind, s_all, "value", sp) for sp in splits}
            if v[rank] is None or not isinstance(v[rank].get("estimate"), float) or not math.isfinite(v[rank]["estimate"]):
                continue
            rec.append((e, v))
        if not rec:                     # this kind of swap has no cell on the ranked board of this pack
            continue
        rec.sort(key=lambda r: (-r[1][rank]["estimate"], r[0]))
        cols = [f"first-shown success ({sp})" for sp in splits] + [f"minus keep ({rank})", "vs keep", "regret",
                                                                     "theta (value kept)", "retained agreement", "log score (lc)",
                                                                     "checks used"]
        L += [f"## {ST.KIND_LABEL[kind]}" + (" (streams pooled)" if s_all == "all" else f" ({s_all})"), "",
              "| rank | rule | source | " + " | ".join(cols) + " |", "|" + "---|" * (3 + len(cols))]
        for n, (e, v) in enumerate(rec, 1):
            src = next((r["source"] for r in rows if r["entry"] == e), "")
            vals = [_both(v[sp]) for sp in splits]
            dk = _keep_diff(rows, e, kind, s_all, rank)
            vals.append(dk)
            vals.append(_tier(rows, e, kind, s_all, rank))
            rg = _find(rows, e, kind, s_all, "regret", rank)
            lg = _find(rows, e, kind, s_all, "log_lc", rank)
            ch = _find(rows, e, kind, s_all, "checks_used", rank)
            th = _find(rows, e, kind, s_all, "theta", rank)
            od = _find(rows, e, kind, s_all, "order", rank)
            vals += [SC.fnum(rg["estimate"]) if rg else "-", _theta_cell(th), _order_cell(od),
                     SC.fnum(lg["estimate"]) if lg else "-", SC.fnum(ch["estimate"], 1) if ch else "-"]
            L.append(f"| {n} | {e} | {src} | " + " | ".join(vals) + " |")
        L.append("")
    ents = sorted({r["entry"] for r in rows})
    L += [f"## Every ordered pair (first-shown success, {rank})", "", "| owner -> reader | " + " | ".join(ents) + " |",
          "|" + "---|" * (1 + len(ents))]
    for (o, r_) in pack.board_cells(rank):
        vals = []
        for e in ents:
            x = next((x for x in rows if x["entry"] == e and x["level"] == "pair" and x["owner"] == o and x["reader"] == r_
                      and x["stream"] == s_all and x["metric"] == "value" and x["split"] == rank), None)
            vals.append(SC.fnum(x["estimate"]) if x else "-")
        L.append(f"| {o} -> {r_} | " + " | ".join(vals) + " |")
    return "\n".join(L) + "\n"


def _tier(rows, entry, kind, stream, split) -> str:
    """Rank group against keep by the paired two-way interval."""
    x = _find(rows, entry, kind, stream, "minus_keep", split)
    if entry == "keep":
        return "(keep)"
    if x is None or not all(isinstance(x.get(k), float) and math.isfinite(x[k]) for k in ("lo", "hi")):
        return "-"
    return "above keep" if x["lo"] > 0 else ("below keep" if x["hi"] < 0 else "not distinguishable")


def _cal_z() -> float:
    """The threshold of msr.metrics.home_signal_flag, for the text only (the flag itself is msr's)."""
    from msr import metrics as M
    return float(M.THETA_CAL_MIN_Z)


def _theta_cell(x) -> str:
    """theta with its interval, or 'no home signal' when the owner's own score has too little ranking
    signal on its calibration tasks for a share of it to mean anything (msr.metrics.home_signal_flag)."""
    from msr import metrics as M
    if x is None:
        return "-"
    if x.get("status") and x["status"] != M.THETA_DEFINED:
        return "no home signal"
    return f"{SC.fnum(x.get('estimate'))} {SC.interval(x.get('lo'), x.get('hi'))}"


def _order_cell(x) -> str:
    """Retained agreement with its interval, or 'not estimated (reader's spread below z = 2)' when the reader's
    spread on the calibration
    tasks cannot be told from zero (msr.metrics.ORDER_MIN_Z)."""
    from msr import metrics as M
    if x is None:
        return "-"
    if x.get("status") != M.ORDER_DEFINED:
        return "not estimated (reader's spread below z = 2)"
    return f"{SC.fnum(x.get('estimate'), 2)} {SC.interval(x.get('lo'), x.get('hi'), 2)}"


def _plain_cell(x, d: int = 2) -> str:
    if x is None:
        return "-"
    return f"{SC.fnum(x.get('estimate'), d)} {SC.interval(x.get('lo'), x.get('hi'), d)}"


def _keep_diff(rows, entry, kind, stream, split) -> str:
    """entry - keep from the 'minus keep' rows the board builds (see _attach_keep_diffs)."""
    x = _find(rows, entry, kind, stream, "minus_keep", split)
    if x is None:
        return "-"
    return f"{SC.fnum(x['estimate'])} {SC.interval(x['lo'], x['hi'])}"


# ---------------------------------------------------------------------------
# describe
# ---------------------------------------------------------------------------


def describe(pack_dir: Path, printer=print, owner: str | None = None, reader: str | None = None,
             budget: int | None = None) -> None:
    """Print what a rule receives in one call, built exactly as a sealed call builds it."""
    import secrets as _s
    from scoreswap import api as API
    pack = Pack(pack_dir)
    dev_cells = pack.board_cells("dev")
    owner = owner or dev_cells[0][0]
    reader = reader or next((r for o, r in dev_cells if o == owner and r != o), owner)
    stream, order = pack.strata[0]
    fit = pack.budgets_fit("dev")
    budget = budget if budget is not None else (16 if 16 in fit else fit[-1])
    O = H.OwnerTables(pack, owner, stream, order)
    CT = H.CellTables(O, reader, H.settings_ns(pack))
    b, c, g = O.sealed_payloads()
    n = int(b["n"])
    items = ["i" + _s.token_hex(5) for _ in range(n)]
    tasks = ["t" + _s.token_hex(5) for _ in range(int(c["T"]))]
    bank = API.Bank(dict(b, items=items, text_sha256=None))
    cands = API.Candidates(dict(c, tasks=tasks, items=[[items[j] if j >= 0 else "" for j in row] for row in c["item_pos"]]),
                           bank)
    swap = API.Swap(CT.swap_payload(budget, 0, int(pack.settings["draws_per_budget"]), {}))
    P = printer
    P(f"What a swap-day rule receives in ONE call (pack '{pack.manifest['study']}', cell {owner} -> {reader}, "
      f"{stream} order {order}, budget k = {budget}). Names are random and new in every call.")
    P("")
    by = pack.settings.get("budgets_that_fit_by_board") or {}
    pools = pack.settings.get("calibration_pool_cells_by_board") or {}
    P(f"Budgets this pack can hold (registered: {pack.settings['budgets_registered']}):")
    P(f"  development board (the public owners' banks; check pool {pools.get('dev', '?')} cells per bank): "
      f"{by.get('dev', fit)}")
    P(f"  ranked board (the private owners' banks, maintainers; check pool {pools.get('test', '?')} cells per bank): "
      f"{by.get('test', '?')}")
    P(f"  the paper's tables (every bank, maintainers; check pool {pools.get('all', '?')} cells per bank): "
      f"{by.get('all', '?')}")
    P("")
    P("rule(bank, candidates, swap, checks) is called once per cell (every owner x reader, HOME cells included: "
      f"swap.kind == 'home') x stream x order, and when k > 0 once per seeded draw "
      f"({pack.settings['draws_per_budget']} draws). Each call is a fresh process: nothing is remembered.")
    P("")
    P(f"bank   ({bank.n} items; every per-item array follows bank.items)")
    P(f"  bank.items[:3]            {bank.items[:3]}")
    P(f"  bank.owner / owner_maker  {bank.owner!r} / {bank.owner_maker!r};  bank.stream {bank.stream!r}, bank.order {bank.order}")
    P(f"  bank.families             {bank.families}")
    for f in bank.families:
        P(f"  bank.score[{f!r}][:3]   {np.round(bank.score[f][:3], 4).tolist()}   counts: "
          + ", ".join(f"{k}={np.round(v[:3], 4).tolist()}" for k, v in bank.counts[f].items()))
    P(f"  bank.mix_score['ema_grade'][:3]  {np.round(bank.mix_score['ema_grade'][:3], 4).tolist()} (in [0, 1])")
    P(f"  bank.visits[:3]           {bank.visits[:3].tolist()}")
    P(f"  bank.showing_probabilities[0]  {np.round(bank.showing_probabilities[0], 4).tolist()}")
    P(f"  bank.no_memory_rate       {bank.no_memory_rate:.4f}   bank.text: {'given' if bank.text else 'None'} (text only for a public bank whose licences allow it; never on the ranked board)")
    P("")
    P(f"candidates   ({cands.T} probe tasks x {cands.C} candidates; items and tasks come in an order of their own, "
      f"fixed for a run and secret on the ranked board)")
    P(f"  candidates.tasks[:2]      {cands.tasks[:2]}   roles[:2] {cands.roles[:2]}")
    P(f"  candidates.item_index[0]  {cands.item_index[0].tolist()} (position in bank.items, -1 = none)")
    P(f"  candidates.relevance[0]   {np.round(cands.relevance[0], 4).tolist()}")
    P(f"  calibration tasks {len(cands.calibration_tasks)}, evaluation tasks {len(cands.evaluation_tasks)}"
      f"   task_text: {'given' if cands.task_text else 'None'} (never on the ranked board)")
    P("")
    P("swap")
    for k in ("owner", "owner_maker", "reader", "reader_maker", "kind", "stream", "order", "budget", "draw", "draws"):
        P(f"  swap.{k:<14} {getattr(swap, k)!r}")
    P("  swap.options          {} (from --set name=value; values are strings)")
    P("  swap.family()         " + repr(swap.family()) + " (the family theta is measured against)")
    P("")
    P(f"checks   (budget {budget}; {len(CT.pool)} calibration cells can be checked)")
    ids = list(range(len(CT.pool)))
    P(f"  checks.cells[0]         CheckCell(id=<random>, task='{tasks[CT.sealed_cell_spec[0][0]]}', item='{items[CT.sealed_cell_spec[0][2]]}', "
      f"position={CT.sealed_cell_spec[0][1]}, item_index={CT.sealed_cell_spec[0][2]}, max_answers={CT.sealed_cell_spec[0][3]})")
    P("  checks.by_task / by_item  {task or item name: [cell ids]} (by_task in a fixed order)")
    P("  checks.request(cells=[ids])  or  checks.request(random=m)   (add with_no_memory=True for the reader's")
    P("      no-item success on each task: 2 more reader calls per task on a real swap day)")
    P("  -> [Answer(cell, task, item, item_index, result 1.0/0.0, answer_number 1 or 2, no_memory or None)]")
    P("  checks.rng             a seeded numpy Generator for your own random choices")
    P("")
    P("Return {'u': [one value in [0, 1] per item]} (+ 'p'), or {'u_cand': T x C array} (+ 'p_cand').")
    P("A score type gets score(log): log.task, log.item, log.item_index, log.result, log.tag, log.no_memory, "
      "log.probability, log.explored, log.pass_ per showing; it returns one number per item of log.items.")
    _ = ids
