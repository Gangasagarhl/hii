"""Build the tiny practice study that the scoreswap tests use (free, simulated models).

    python -m scoreswap.fixture            # builds runs/scoreswap_fixture/ if it is missing

Everyday picture: before a garage lets a new mechanic loose on customers' cars, it tries the
whole routine on a toy car. This is the toy car: three made-up models, a few dozen jobs, two
stream orders. It runs the paper's own pipeline (run.py) end to end in under a minute.

No model is called and no key is read: the simulated models answer from a known script, and
the key loader is switched off for this run.
"""
from __future__ import annotations

import contextlib
import io
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
FIXTURE_CONFIG = ROOT / "config" / "scoreswap_fixture.yaml"
FIXTURE_NAME = "scoreswap_fixture"


def fixture_ready(runs_dir: Path | None = None) -> bool:
    """True when the fixture study's results exist (its arms.csv and validity.csv)."""
    runs = Path(runs_dir) if runs_dir else ROOT / "runs"
    res = runs / FIXTURE_NAME / "results"
    return (res / "arms.csv").exists() and (res / "validity.csv").exists() and (res / "retained.csv").exists()


def build_fixture(runs_dir: Path | None = None, quiet: bool = True) -> Path:
    """Run the pipeline on config/scoreswap_fixture.yaml (stages build, probe, probe_extra,
    evaluate; online is off). Returns the study folder. Safe to call again: finished work is
    kept and nothing is paid."""
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    from msr import llm as L
    import run as runner

    old_runs, old_spend, old_env = L.RUNS, L.SPEND_PATH, L.load_env
    try:
        if runs_dir:
            L.RUNS = Path(runs_dir).resolve()
            L.SPEND_PATH = L.RUNS / "spend.json"
        L.load_env = lambda: None          # simulated models need no key: never read one
        args = ["--study", str(FIXTURE_CONFIG)]
        if runs_dir:
            args += ["--runs-dir", str(Path(runs_dir).resolve())]
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf) if quiet else contextlib.nullcontext():
            rc = runner.main(args)
        if rc not in (0, None):
            raise RuntimeError(f"the fixture study did not finish (exit code {rc}):\n{buf.getvalue()[-3000:]}")
        return Path(L.RUNS) / FIXTURE_NAME
    finally:
        L.RUNS, L.SPEND_PATH, L.load_env = old_runs, old_spend, old_env


def main(argv=None) -> int:
    import argparse
    ap = argparse.ArgumentParser(description="Build the tiny simulated study used by the scoreswap tests.")
    ap.add_argument("--runs-dir", default=None, help="where run folders go (default: runs/)")
    a = ap.parse_args(argv)
    d = build_fixture(Path(a.runs_dir) if a.runs_dir else None, quiet=False)
    print(f"Fixture study ready in {d}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
