"""TEMPLATE: a swap-day rule for ScoreSwap. Copy this file into a folder of your own, rename it,
and change rule(). Nothing else is needed.

Everyday picture: a garage keeps repair tips, each with a score earned with the old mechanic.
A new mechanic starts today. Your rule decides what score each tip carries from now on. It may
ask for a few fresh checks first ("how did the new mechanic do with tip X on test job Y?"), up
to a budget.

The harness calls rule(bank, candidates, swap, checks) once for every cell (the owner of the
bank, the new model reading it, the task stream, the stream order) - including the owner reading
its own bank (swap.kind == "home") - and, when the budget k is above 0, once for every seeded
random draw (200 in the paper). Each call is a fresh swap day in a FRESH PROCESS: nothing you store
survives to the next call, and the names of items, tasks and check cells are random and new in every
call, so match things by position (bank.index, candidates.item_index), never by name.
`python -m scoreswap describe --pack <pack>` prints everything a call receives, with sample values;
docs/BENCHMARK_GUIDE.md documents every field.

What you receive:
  bank        the old bank: bank.items (ids), bank.score[family], bank.mix_score[family] (in [0, 1]),
              bank.p[family], bank.counts[family][field], bank.visits, bank.showing_probabilities,
              bank.no_memory_rate. Families: ema_grade, beta_grade, tags_self, credit, visits.
  candidates  every probe task with its 4 candidates: candidates.tasks, .roles ('calibration' or
              'evaluation'), .item_index (T x 4, position in bank.items, -1 if none), .relevance (T x 4)
  swap        swap.owner, swap.owner_maker, swap.reader, swap.reader_maker, swap.kind, swap.budget,
              swap.stream, swap.order, swap.draw, swap.options (from --set name=value), swap.settings
  checks      checks.request(cells=[ids]) or checks.request(random=m) -> answers, each with
              .cell, .item_index, .result (1.0 right, 0.0 wrong), .answer_number (1 or 2) and
              .no_memory (with with_no_memory=True: the reader's no-item success on that task);
              checks.cells lists the calibration cells you may name (CheckCell: id, task, item,
              position, item_index, max_answers); checks.by_item / checks.by_task group their ids;
              checks.rng is a seeded random generator: use it for every random choice

What you return:
  {"u": u} or {"u": u, "p": p}: one number per item, in bank.items order (a list, an array, or a
  dict {item id: number}). u in [0, 1] ranks the items (the harness shows the candidate with the
  largest 0.5 u + 0.5 relevance; ties go to the more relevant item); p in [0, 1] is the chance the
  reader succeeds with the item (the scorer clips it to [0.01, 0.99], as the paper does).
  Or {"u_cand": U, "p_cand": P}: arrays of shape (len(candidates.tasks), 4), one value per probe
  task and candidate, when the value should depend on the task (for example on relevance).

The rules the harness enforces (python -m scoreswap check tests each one):
  - at most swap.budget checks; a cell can be answered at most twice (it holds two repeats);
  - no NaN, no value outside [0, 1], the right shapes;
  - the same output every time for the same seed (use checks.rng, not the clock);
  - one file only: no other file (not even beside this one), network, process or thread; the
    rule runs sealed (on Linux the kernel enforces it) and never sees an evaluation result.

Try it:
    python -m scoreswap check my_rule.py --pack release/sim
    python -m scoreswap score my_rule.py --pack release/sim --budget 16
"""
import numpy as np

KIND = "swap_day_rule"
NAME = "my_rule"
DESCRIPTION = "Keep the old ema_grade scores; blend each checked item's fresh results into its score."
# DRAW_KEY = "recal"   # random cells come from the same seeded draws as recal_k (the default)


def rule(bank, candidates, swap, checks):
    u = bank.mix_score["ema_grade"].copy()            # the old scores, in [0, 1]
    if checks.budget > 0:
        hits = np.zeros(bank.n)
        tries = np.zeros(bank.n)
        for a in checks.request(random=checks.budget):  # k cells drawn at random
            hits[a.item_index] += a.result
            tries[a.item_index] += 1
        u = (2.0 * u + hits) / (2.0 + tries)           # the old score counts as two checks
    return {"u": u, "p": u}
