"""TEMPLATE: a score type for ScoreSwap. Copy this file into a folder of your own, rename it, and
change score().

Everyday picture: while the old mechanic worked, the garage wrote down every time a tip was used:
which job, which tip, whether the repair worked, what the mechanic himself thought of the tip,
how the job went without any tip, and how likely the garage's habit was to pick that tip. A score
type turns that diary into one score per tip. ScoreSwap then measures how well the scores rank
the tips for the old mechanic (at home) and how much of that is left for a new one (theta).

The harness calls score(log) once per bank. `log` (scoreswap.api.ScoreLog) holds, per showing
in the order it happened: log.task, log.item (log.item_index: position in log.items),
log.result (1.0 / 0.0), log.tag ('helpful', 'harmful', 'neutral' or None), log.no_memory (the
owner's no-item result on that task, NaN if none), log.probability (the logged chance of showing
that item), log.explored, log.pass_. Also log.items (every item of the bank), log.no_memory_rate.

Return one finite number per item, in log.items order (a list, an array, or a dict {item: score}).
Higher means more useful. Only the order matters.

Your score learns from the same logged showings as the paper's five types, so it cannot change
which items were shown; the logged probabilities let you reweight for that.

Try it:
    python -m scoreswap check my_score.py --pack release/sim
    python -m scoreswap score my_score.py --pack release/sim
"""
import numpy as np

KIND = "score_type"
NAME = "my_score"
DESCRIPTION = "Share of graded successes, smoothed (the same as the paper's beta_grade)."


def score(log):
    wins = np.zeros(len(log.items))
    shows = np.zeros(len(log.items))
    np.add.at(wins, log.item_index, log.result)
    np.add.at(shows, log.item_index, 1.0)
    return (wins + 1.0) / (shows + 2.0)
