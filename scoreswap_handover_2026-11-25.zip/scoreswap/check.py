"""`python -m scoreswap check ENTRY --pack PACK`: does an entry keep the rules of the interface,
and does it read no evaluation result?

Everyday picture: before a new mechanic's method is tried on the garage's exam, an inspector
checks four things. The method runs in a closed room, a new room for every single job, and any
attempt to open a drawer is refused and written down. It gives the same answer when the jobs come
in another order. When the inspector secretly shuffles the exam answers, its output does not
change by a single byte. And (for the maintainers, who hold the sealed half of the exam) it does
not do suspiciously better on the public half than on the sealed half.

What is checked:
1. Sealing: a launcher that never runs the entry forks one fresh process per call; on Linux with
   bubblewrap the launcher runs in a namespace jail that holds only read-only binds of the system
   libraries, Python, scoreswap, msr and the entry file; the kernel (Landlock, seccomp) refuses any
   write, process, thread, network, pipe, shared memory, IPC, signal, file lock or watch, and any
   system call that reaches another process or its limits. A refused attempt that the Python hook
   sees fails the check, named; the kernel's own refusals are silent (the call just gets an error).
2. The contract on every cell and draw: shapes, no NaN or infinite value, u and p inside [0, 1],
   no more checks than the budget, no cell asked a third time, no unknown cell.
3. Order and repeat: a second run, in a new process, with the calls in another order, must give
   byte-identical output for every call. (A rule that kept something from earlier calls, read the
   clock, used its own unseeded randomness or depended on the random per-call names fails here.)
4. The canary: the evaluation outcomes the harness holds are permuted (in a copy) and the entry is
   run again; its output must be byte-identical, while the harness's own scores do change.
The check runs a few draws chosen at random among the pack's, and tells the rule the pack's number
of draws, as `score` does: a rule cannot tell a check from a score. The held-out comparison (the
lead over keep on the development board against the ranked board) is computed by the maintainers'
`score --private` on the FULL runs of both boards, not here.
"""
from __future__ import annotations

import csv
import math
import tempfile
from pathlib import Path

import numpy as np

from scoreswap import harness as H
from scoreswap import scoring as SC
from scoreswap import stats as ST
from scoreswap.export import DEV_FILE, TEST_FILE
from scoreswap.pack import Pack

MIN_GAP = 0.03
#: The held-out check's allowance: a dev lead over keep may exceed the test lead by at most this many
#: standard errors (and MIN_GAP). An over-fitting alarm of `check`, not a home-signal rule: the only rule
#: for the home signal is msr.metrics.home_signal_flag.
HELD_OUT_SE = 3.0


def default_budgets(pack) -> list:
    fit = [k for k in pack.budgets_fit("dev") if k > 0]
    return [0] + ([16] if 16 in fit else fit[-1:])


def _parts(meta: dict, results: list) -> dict:
    """{call: bytes} of one complete run: every (budget, cell, draw) output of a rule, or every
    bank's scores of a score type."""
    parts = {}
    for res in results:
        for key in sorted(res["cells"]):
            rec = res["cells"][key]
            if meta["kind"] == "swap_day_rule":
                for d, (mode, u, p) in enumerate(rec["outputs"]):
                    b = mode.encode() + np.ascontiguousarray(u, dtype=np.float64).tobytes()
                    b += (b"p" + np.ascontiguousarray(p, dtype=np.float64).tobytes()) if p is not None else b"-"
                    parts[(res["meta"]["budget"],) + key + (d,)] = b
                parts[(res["meta"]["budget"],) + key + ("checks",)] = np.float64(rec["row"]["checks_used"]).tobytes()
            else:
                parts[key] = np.ascontiguousarray(rec["x"], dtype=np.float64).tobytes()
    return parts


def _run_all(pack, path: Path, trusted: bool, budgets: list, draws: int, cells, options: dict, order_seed: int,
             workers, timeout, memory_gb=None, time_budget=None, draw_seed: int = 0) -> tuple:
    meta = H._meta(path)
    results = []
    if meta["kind"] == "swap_day_rule":
        for k in budgets:
            # the same random choice of draws in every run of one check (draw_seed), so runs compare call by call
            results.append(SC.run_rule(pack, path, k, draws=draws, cells=cells, options=options, trusted=trusted,
                                       workers=workers, keep_outputs=True, order_seed=order_seed, timeout=timeout,
                                       memory_gb=memory_gb, time_budget=time_budget, draw_pick=draw_seed))
    else:
        results.append(SC.run_score_type(pack, path, cells=cells, trusted=trusted, workers=workers, timeout=timeout,
                                         memory_gb=memory_gb, time_budget=time_budget))
    return meta, results


def permuted_copy(src: Path, out_dir: Path, seed: int = 20261124) -> Path:
    """A copy of a results file with its `result` column permuted at random (flipped instead if
    the permutation would change nothing)."""
    with open(src, encoding="utf-8", newline="") as fh:
        rows = list(csv.reader(fh))
    head, body = rows[0], rows[1:]
    j = head.index("result")
    vals = np.array([r[j] for r in body])
    new = vals[np.random.default_rng(seed).permutation(len(vals))]
    if np.array_equal(new, vals):
        new = np.where(vals == "1", "0", "1")
    for r, v in zip(body, new):
        r[j] = str(v)
    dst = Path(out_dir) / f"permuted_{Path(src).name}"
    with open(dst, "w", encoding="utf-8", newline="") as fh:
        w = csv.writer(fh, lineterminator="\n")
        w.writerow(head)
        w.writerows(body)
    return dst


def held_out_gap(pack, res: dict, kind: str) -> dict:
    """(entry - keep) on the development board minus (entry - keep) on the ranked board, first-shown
    success over every swap cell of each board and stream with equal weight, with an SE that treats
    the two boards as independent (commands.held_out_alarm, the maintainers' alarm, uses one joint
    jackknife instead). For a score type: (entry - ema_grade) in the signed validity V after the swap.
    `res` must hold the cells of both boards (run with board 'all')."""
    out = {}
    for sp in ("dev", "test"):
        swaps = [c for c in pack.board_cells(sp) if c[0] != c[1]]
        items = [(o, r, s, 1.0 / (len(swaps) * len(pack.streams))) for o, r in swaps for s in pack.streams]
        CL = ST.Clusters(pack, sp, B=0)
        store = SC.restrict(res, sp)
        if kind == "swap_day_rule":
            ref = SC.paper_rule_stores(pack, 0, res["meta"].get("ref_family") or pack.headline, sp).get("keep", {})
            key = "value"
        else:
            ref = SC.restrict(SC.run_score_type(pack, None, family=pack.headline, board=sp), sp)
            key = "V_swap"
        diff = SC._diff_store(store, ref, (key,))
        out[sp] = CL.linear_batch([(diff, key)], items)[0]
    gap = out["dev"]["estimate"] - out["test"]["estimate"]
    se = math.sqrt(out["dev"]["se"] ** 2 + out["test"]["se"] ** 2) if all(
        math.isfinite(out[s]["se"]) for s in ("dev", "test")) else float("nan")
    return {"gap": gap, "se": se, "dev": out["dev"]["estimate"], "test": out["test"]["estimate"], "key": key}


def check(entry: Path, pack_dir: Path, budgets: list | None = None, draws: int = 3, cells: int | None = None,
          trusted: bool = False, options: dict | None = None, printer=print, private: Path | None = None,
          workers: int | None = None, timeout: float = H.CALL_TIMEOUT, memory_gb: float | None = None,
          time_budget: float | None = None) -> bool:
    """Run every check and print a plain report. Returns True when all pass."""
    entry = Path(entry).resolve()
    pack = Pack(pack_dir, private=private)
    budgets = budgets or default_budgets(pack)
    cell_sel = pack.board_cells("dev")[:cells] if cells else None
    ok = True

    def line(passed: bool, text: str):
        nonlocal ok
        ok = ok and passed
        printer(f"  {'PASS' if passed else 'FAIL'}  {text}")

    printer(f"Checking {entry.name} against the pack of study '{pack.manifest['study']}' (development board)")
    import secrets as _sec
    pick = _sec.randbits(32)                 # which of the pack's draws are run: random, unknown to the rule
    extra = dict(memory_gb=memory_gb, time_budget=time_budget, draw_seed=pick)
    if not trusted:
        jok, jwhy = H.jail_status()
        if not jok:
            printer(f"  WARNING: no namespace jail ({jwhy}); the check runs with the kernel sandbox alone")
    try:
        meta, run1 = _run_all(pack, entry, trusted, budgets, draws, cell_sel, options or {}, 1, workers, timeout, **extra)
    except H.EntryFailure as e:
        line(False, f"the entry broke a rule of the interface: {e}")
        return False
    printer(f"  entry: {meta['name']} ({meta['kind'].replace('_', ' ')})"
            + (f"; if it asks for random checks, it gets the cells {meta['draw_key']}_k gets"
               if meta["kind"] == "swap_day_rule" else ""))
    sb = run1[0]["meta"].get("sandbox") or {}
    if trusted:
        printer("  NOTE  run in this process (--trusted): not sealed, and its memory DOES persist between calls; "
                "only the order and canary checks below can catch a leak")
    else:
        kernel = "landlock" in sb and str(sb.get("landlock", "")).startswith("ABI")
        line(True, "sealed: a launcher that never runs the entry forked one fresh process per call; "
                   + (str(sb.get("jail", "")) + "; " if sb.get("jail") else "")
                   + ("the kernel enforced it: " + sb.get("landlock", "") + "; " + sb.get("seccomp", "")
                      if kernel else "WITHOUT kernel sandboxing on this system (" + str(sb.get("landlock", "")) +
                      "): only the Python audit hook guarded files and processes"))
    n_cells = len(SC._jobs(pack, cell_sel))
    if meta["kind"] == "swap_day_rule":
        ups = [max((r["row"]["checks_used"] for r in res["cells"].values()), default=0) for res in run1]
        line(True, f"the contract held on {n_cells} bank(s) x their readers x budgets {budgets} x {draws} of the "
                   f"pack's {pack.settings['draws_per_budget']} draws (picked at random): "
                   f"shapes, no NaN, u and p in [0, 1], checks within the budget (most used per call: "
                   f"{', '.join(f'k={k}: {u:g}' for k, u in zip(budgets, ups))}), no cell asked a third time")
    else:
        line(True, "the contract held on every bank: one finite score per item")
    p1 = _parts(meta, run1)
    det = False
    try:
        _m2, run2 = _run_all(pack, entry, trusted, budgets, draws, cell_sel, options or {}, 2, workers, timeout, **extra)
        p2 = _parts(meta, run2)
        diff = [k for k in p1 if p1[k] != p2.get(k)]
        det = not diff
        line(det, "order and repeat: a second run in a new process, with the calls in another order, gave "
                  "byte-identical output for every call" if det else
             f"a second run with the calls in another order gave different output in {len(diff)} call(s), e.g. "
             f"{diff[:1]}: the output depends on something outside the call (earlier calls, the clock, unseeded "
             f"randomness, or the random per-call names); use checks.rng and positions, not names")
    except H.EntryFailure as e:
        line(False, f"the second run failed: {e}")
    tmp = tempfile.TemporaryDirectory(prefix="scoreswap_canary_")
    try:
        over = {"dev": permuted_copy(pack.root / DEV_FILE, Path(tmp.name))}
        if pack.private is not None:
            over["test"] = permuted_copy(pack.private / TEST_FILE, Path(tmp.name))
        cpack = Pack(pack.root, private=pack.private, override=over)
        _m3, run3 = _run_all(cpack, entry, trusted, budgets, draws, cell_sel, options or {}, 3, workers, timeout, **extra)
        p3 = _parts(meta, run3)
        diff = [k for k in p1 if p1[k] != p3.get(k)]
        live = _canary_live(meta, run1, run3)
        if not diff:
            line(True, f"canary: with the evaluation outcomes permuted the entry's output stayed byte-identical ({live})")
        elif det:
            line(False, f"canary: with the evaluation outcomes permuted the entry's output CHANGED in {len(diff)} "
                        f"call(s), e.g. {diff[:1]}, although it is the same on a repeat: it reads evaluation results")
        else:
            line(False, "canary: the output changed under the permutation, but it also changes on a plain repeat, "
                        "so the canary cannot show that it reads no evaluation result; make the entry deterministic")
    except H.EntryFailure as e:
        line(False, f"the canary run failed: {e}")
    finally:
        tmp.cleanup()
    printer("  NOTE  the held-out comparison (development board against the ranked board) is part of the maintainers' "
            "scoring (score --private), on the full runs")
    printer("All checks passed. (Public checks cannot detect an entry that carries public outcomes in its file; "
            "the ranked board, built by the maintainers on private data, is where that stops helping.)"
            if ok else "Some checks failed: fix them before scoring.")
    return ok


def _canary_live(meta: dict, run1: list, run3: list) -> str:
    """Show that the permutation did change what the harness computes (so the canary was live)."""
    key = "value" if meta["kind"] == "swap_day_rule" else "cw_swap"
    a = [r["row"][key] for res in run1 for r in res["cells"].values()]
    b = [r["row"][key] for res in run3 for r in res["cells"].values()]
    n = sum(1 for x, y in zip(a, b) if not (x == y or (x != x and y != y)))
    what = "first-shown success" if key == "value" else "concordance after the swap"
    return f"while the harness's {what} changed in {n} of {len(a)} cells"
