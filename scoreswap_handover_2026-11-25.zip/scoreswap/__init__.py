"""ScoreSwap: score your own swap-day rule or score type offline, from frozen probe tables.

Everyday picture: a garage keeps repair tips, each with a score earned while one mechanic worked
there. A new mechanic arrives. A swap-day rule says what to do with the old scores on that day
(keep them, wipe them, trust them halfway, check a few first). A score type is a way to compute
the scores in the first place. This package scores either kind of entry against the paper's
frozen tables, with no model call:

    python -m scoreswap export --study sim --out release/sim          # make the frozen tables
    python -m scoreswap check  my_rule.py --pack release/sim           # does it keep the rules?
    python -m scoreswap score  my_rule.py --pack release/sim --budget 64
    python -m scoreswap leaderboard entries/ --pack release/sim        # both boards

The objects an entry receives are in scoreswap.api; templates in scoreswap/templates/;
docs/BENCHMARK_GUIDE.md explains it all in plain words.
"""
from scoreswap.api import (BUDGETS, Answer, Bank, Candidates, CheckCell, CheckRequestError, Checks,  # noqa: F401
                           ScoreLog, Swap)

__version__ = "0.1.0"
