"""The launcher: the trusted process that runs an outside entry, one fresh process per call.

Started by scoreswap.harness.ChildRunner. It never executes a line of the entry itself:
1. It reads the entry file, takes its settings from the syntax tree (scoreswap.entry), compiles
   it, and loads the libraries the file imports (numpy, scipy, ...), so later imports are free.
2. It closes the sandbox (scoreswap.sandbox): on Linux, Landlock lets it read only the Python
   installation and the scoreswap and msr packages (not the entry's folder, not the pack), write
   nothing, execute nothing; seccomp refuses pipes, sockets, IPC, shared memory, ptrace and the
   other calls that could carry state from one call to the next.
3. For every call (one cell, one seeded draw) it resets its own resource limits and forks a
   worker. The worker gives up the harness's pipes (it never holds them: its only channel is a
   pair of pipes to the launcher, new for every call), adds its own limits (no new process or
   thread, a memory ceiling, no system call that reaches another process or changes its limits),
   runs the compiled entry in a fresh module, builds the inputs with NEW opaque names for every
   item, task and check cell (random each call), calls the rule, sends the result to the launcher
   and exits. Nothing the entry does survives the call: its memory goes with the worker, and it has
   no channel (file, pipe, socket, shared memory, process, resource limit) to the next call.
4. The launcher relays the call's check requests and its one answer to the harness (anything else
   the call sends is a protocol breach), reaps the worker (and any orphan) and tells the harness.
On Linux with bubblewrap the launcher itself runs in a namespace jail (scoreswap.harness.jail_command).

Messages are JSON, 8-byte length first. Nothing the entry sends is ever executed by the harness.
"""
import gc
import importlib
import json
import os
import resource
import secrets
import signal
import struct
import sys
import traceback

_IN = sys.stdin.buffer
_OUT = sys.stdout.buffer
sys.stdout = sys.stderr          # whatever the entry prints goes to the harness's log, not the pipe


def _send(obj):
    data = json.dumps(obj, allow_nan=True).encode("utf-8")
    _OUT.write(struct.pack(">Q", len(data)) + data)
    _OUT.flush()


def _recv():
    head = _IN.read(8)
    if len(head) < 8:
        os._exit(0)
    (n,) = struct.unpack(">Q", head)
    return json.loads(_IN.read(n).decode("utf-8"))


MAX_MESSAGE = 1 << 28        # a call's message to the launcher may not exceed 256 MB


def _send_fd(fd: int, obj) -> None:
    data = json.dumps(obj, allow_nan=True).encode("utf-8")
    buf = memoryview(struct.pack(">Q", len(data)) + data)
    while len(buf):
        buf = buf[os.write(fd, buf):]


def _read_exact(fd: int, n: int):
    out = bytearray()
    while len(out) < n:
        chunk = os.read(fd, min(n - len(out), 1 << 20))
        if not chunk:
            return None
        out += chunk
    return bytes(out)


def _recv_fd(fd: int):
    """One message from a call's pipe; None when the call has closed it."""
    head = _read_exact(fd, 8)
    if head is None:
        return None
    (n,) = struct.unpack(">Q", head)
    if n > MAX_MESSAGE:
        raise ValueError(f"a message of {n} bytes")
    data = _read_exact(fd, n)
    if data is None:
        raise ValueError("a message cut short")
    obj = json.loads(data.decode("utf-8"))
    if not isinstance(obj, dict):
        raise ValueError("a message that is not an object")
    return obj


_LIMITS: dict = {}           # the launcher's own resource limits, put back before every fork
_STATM = None                # /proc/self/statm, opened before the sandbox closed (the launcher's memory size)


def _save_limits() -> None:
    for name in dir(resource):
        if name.startswith("RLIMIT_"):
            r = getattr(resource, name)
            try:
                _LIMITS[r] = resource.getrlimit(r)
            except (ValueError, OSError):
                pass


def _reset_limits() -> None:
    for r, lim in _LIMITS.items():
        try:
            if resource.getrlimit(r) != lim:
                resource.setrlimit(r, lim)
        except (ValueError, OSError):
            pass


def _vm_bytes():
    try:
        return int(os.pread(_STATM, 128, 0).split()[0]) * os.sysconf("SC_PAGE_SIZE")
    except Exception:
        return None


def _make_hook(allowed: list, denied: list):
    """The Python audit hook of a worker: plain messages for honest mistakes (the kernel limits
    above are what actually hold). Its state lives in this closure, not in module globals."""
    roots = [os.path.realpath(a) for a in allowed]
    block = ("subprocess.Popen", "os.system", "os.exec", "os.posix_spawn", "os.spawn", "os.fork", "os.forkpty",
             "socket.", "ctypes.dlopen", "ctypes.dlsym", "ctypes.call_function", "os.remove", "os.rename",
             "os.rmdir", "os.mkdir", "os.chmod", "os.symlink", "os.link", "os.truncate", "os.kill", "os.putenv",
             "os.unsetenv", "shutil.", "urllib.Request", "http.client.connect", "webbrowser.open", "mmap.__new__",
             "sys.remote_exec", "winreg.OpenKey", "_posixshmem.")
    write_flags = os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND

    def ok_path(p):
        try:
            rp = os.path.realpath(os.fsdecode(p))
        except Exception:
            return False
        if rp in ("/dev/null", "/dev/urandom"):
            return True
        return any(rp == r or rp.startswith(r.rstrip(os.sep) + os.sep) for r in roots)

    def hook(event, args):
        if event == "open":
            path = args[0] if args else None
            mode = args[1] if len(args) > 1 else None
            flags = args[2] if len(args) > 2 else 0
            if path is None or isinstance(path, int):
                return
            writing = (isinstance(mode, str) and any(c in mode for c in "wax+")) or \
                      (mode is None and isinstance(flags, int) and flags & write_flags)
            shown = os.fsdecode(path)
            try:
                real = os.path.realpath(shown)
                if real != os.path.abspath(shown):
                    shown = f"{shown} (which is {real})"
            except Exception:
                pass
            if writing:
                msg = f"write the file {shown}"
            elif not ok_path(path):
                msg = f"open the file {shown}, outside the folders an entry may read"
            else:
                return
            denied.append(msg)
            raise PermissionError(msg)
        if event in ("os.listdir", "os.scandir", "os.chdir"):
            path = args[0] if args else "."
            if isinstance(path, int):
                return
            if not ok_path(path if path not in (None, "") else "."):
                msg = f"list the folder {os.fsdecode(path) if path else '.'}"
                denied.append(msg)
                raise PermissionError(msg)
            return
        if event.startswith(block):
            msg = f"use '{event}' (files, processes, network, shared memory and C libraries are not allowed)"
            denied.append(msg)
            raise PermissionError(msg)
    return hook


def _tokens(prefix: str, n: int) -> list:
    """n distinct random names, new for every call (os.urandom)."""
    while True:
        vals = struct.unpack(f"<{n}Q", os.urandom(8 * n)) if n else ()
        if len(set(vals)) == n:
            return [f"{prefix}{v:016x}" for v in vals]


def _permutation(n: int) -> list:
    """A uniformly random order of range(n) from one os.urandom read (sorting n distinct random
    64-bit keys), instead of one system call per element."""
    while True:
        keys = struct.unpack(f"<{n}Q", os.urandom(8 * n)) if n else ()
        if len(set(keys)) == n:
            return sorted(range(n), key=keys.__getitem__)


def _templates(bank_p, cand_p, log_p):
    """The input objects of one bank, built once in the launcher with placeholder names; each
    worker renames its own copy (the fork gives it one) before the entry sees them."""
    from scoreswap import api as API
    n, T = int(bank_p["n"]), int(cand_p["T"])
    items = [str(j) for j in range(n)]
    tasks = [str(j) for j in range(T)]
    bank = API.Bank(dict(bank_p, items=items, text_sha256=None))
    cands = API.Candidates(dict(cand_p, tasks=tasks, items=[[items[j] if j >= 0 else "" for j in row]
                                                            for row in cand_p["item_pos"]]), bank)
    return {"bank": bank, "cands": cands, "log_p": log_p, "item_pos": cand_p["item_pos"]}


def _rename(t):
    """Fresh opaque names for this call: items, probe tasks (and score tasks for a score type)."""
    bank, cands = t["bank"], t["cands"]
    items = _tokens("i", bank.n)
    bank.items = items
    bank.index = {name: j for j, name in enumerate(items)}
    tasks = _tokens("t", cands.T)
    cands.tasks = tasks
    cands.task_index = {name: j for j, name in enumerate(tasks)}
    cands.items = [[items[j] if j >= 0 else "" for j in row] for row in t["item_pos"]]
    cands.calibration_tasks = [x for x, r in zip(tasks, cands.roles) if r == "calibration"]
    cands.evaluation_tasks = [x for x, r in zip(tasks, cands.roles) if r == "evaluation"]
    return bank, cands, items, tasks


def _worker(msg, inputs, cells_db, code, meta, entry, allowed, sealed, inline=False, io=None, mem_limit=None):
    """One call in a fresh process; never returns. `io`: (write fd, read fd) of this call's own pipes to
    the launcher (the harness's pipes are given up first). `inline`: no fork on this system, so this
    whole launcher was started for this one call; it reports to the harness directly and exits."""
    denied = []
    status = 0
    gc.disable()                 # a call is short: no collection walks (and copies) the inherited heap
    import time as _t
    marks = [("start", _t.perf_counter(), _t.process_time())]
    if io is not None:
        wfd, rfd = io
        try:
            os.dup2(2, 1)        # print() goes to the log; the harness's pipes are gone from this process
            os.close(0)
            if _STATM is not None:
                os.close(_STATM)
        except OSError:
            pass

        def send(obj):
            _send_fd(wfd, obj)

        def recv():
            m = _recv_fd(rfd)
            if m is None:
                os._exit(3)
            return m
    else:
        send, recv = _send, _recv
    try:
        if sealed:
            from scoreswap import sandbox as SB
            SB.apply_worker(mem_limit)
        marks.append(("sandbox", _t.perf_counter(), _t.process_time()))
        import types
        import numpy as np
        from scoreswap import api as API
        from scoreswap.harness import to_lists
        sys.addaudithook(_make_hook(allowed, denied))
        module = types.ModuleType("scoreswap_entry")
        module.__file__ = entry
        exec(code, module.__dict__)
        marks.append(("exec", _t.perf_counter(), _t.process_time()))
        t = inputs[msg["key"]]
        bank, cands, items, ptasks = _rename(t)
        marks.append(("rename", _t.perf_counter(), _t.process_time()))
        if msg["op"] == "score":
            lp = t["log_p"]
            stasks = _tokens("s", int(lp["n_task_codes"]))
            log = API.ScoreLog(dict(lp, items=items, item=[items[j] for j in lp["item_pos"]],
                                    task=[stasks[c] for c in lp["task_code"]]))
            x = module.score(log)
            if isinstance(x, dict):
                missing = [i for i in items if i not in x]
                if missing:
                    raise ValueError(f"the score type's dict misses {len(missing)} item(s)")
                x = [x[i] for i in items]
            out = np.asarray(x, dtype=float).tolist()
        else:
            cdb = cells_db[msg["ckey"]]
            spec = cdb["cells"]                      # pool order: (task_pos, position, item_pos, max_answers, task_rank)
            perm = _permutation(len(spec))           # cell ids, new and random in every call
            inv = {perm[j]: j for j in range(len(spec))}
            cells = [(perm[j], ptasks[c[0]], items[c[2]], c[1], c[2], c[3]) for j, c in enumerate(spec)]
            task_order = [ptasks[tp] for tp in cdb["task_order"]]
            rng = np.random.default_rng(msg["seed"])

            def transport(cs, random, with_nm, rng_):
                pool = None if cs is None else [inv.get(int(c), -1) for c in cs]
                send({"op": "request", "cells": pool, "random": random, "with_no_memory": with_nm,
                      "rng_state": rng_.bit_generator.state})
                rep = recv()
                if rep.get("op") == "refused":
                    raise API.CheckRequestError(rep.get("message", "refused"))
                rng_.bit_generator.state = rep["rng_state"]
                res = []
                for j, result, number, nm in rep["answers"]:
                    c = spec[j]
                    res.append((perm[j], ptasks[c[0]], items[c[2]], c[2], result, number, nm))
                return res

            checks = API.Checks(msg["budget"], cells, rng, transport, task_order=task_order)
            swap = dict(cdb["swap"], budget=msg["budget"], draw=msg["draw"], draws=msg["draws"])
            marks.append(("checks", _t.perf_counter(), _t.process_time()))
            out = module.rule(bank, cands, API.Swap(swap), checks)
            marks.append(("rule", _t.perf_counter(), _t.process_time()))
            out = to_lists(out, items, cands.T, cands.C)
        marks.append(("output", _t.perf_counter(), _t.process_time()))
        send({"op": "result", "output": out, "denied": denied,
              "timing": [(n, w - marks[0][1], c - marks[0][2]) for n, w, c in marks]})
    except BaseException:
        status = 1
        try:
            send({"op": "failed", "error": traceback.format_exc(limit=6), "denied": denied})
        except BaseException:
            pass
    finally:
        try:
            sys.stderr.flush()
            if inline:
                _send({"op": "reaped", "status": status, "orphans": 0})
        except BaseException:
            pass
        os._exit(status)


def main():
    init = _recv()
    root, entry, allowed, sealed = init["project_root"], init["entry"], init["allowed"], bool(init.get("sealed", True))
    sys.path.insert(0, root)
    import numpy  # noqa: F401
    from scoreswap import api  # noqa: F401
    from scoreswap import entry as EN
    from scoreswap import harness  # noqa: F401
    for m in ("msr.engine", "msr.scores", "msr.arms", "msr.build", "scoreswap.reference_rules._common",
              "scoreswap.reference_rules._replay"):
        try:
            importlib.import_module(m)
        except Exception:
            pass
    try:
        src = EN.read_source(entry)
        meta = EN.meta_from_source(src, entry)
        code = compile(src, entry, "exec")
    except Exception as e:
        _send({"op": "failed", "error": str(e)})
        return
    import linecache                             # tracebacks show the entry's lines without reading its file
    linecache.cache[entry] = (len(src), None, src.splitlines(True), entry)
    import numpy as _np                          # warm what numpy loads lazily (numpy.random is imported on first
    _np.random.default_rng([0, 1]).random(4)     # use: 15 ms per call if every worker had to load it)
    secrets.SystemRandom().random()
    for m in EN.imports_of(src):                 # load the entry's libraries now, before the sandbox closes
        try:
            importlib.import_module(m)
        except Exception:
            pass
    try:
        sys.path.remove(root)                    # scoreswap and msr are loaded; the project folder is not searched
    except ValueError:
        pass
    gc.collect()
    gc.freeze()
    global _STATM
    _save_limits()
    try:
        _STATM = os.open("/proc/self/statm", os.O_RDONLY)
    except OSError:
        _STATM = None
    mem_per_call = int(init.get("memory_per_call") or 0)
    report = {"sealed": sealed}
    if sealed:
        from scoreswap import sandbox as SB
        SB.prepare()
        report.update(SB.apply_launcher(allowed))
    _send({"op": "ready", "meta": meta, "sandbox": report})
    inputs, cells_db = {}, {}
    while True:
        msg = _recv()
        op = msg.get("op")
        if op == "exit":
            return
        if op == "inputs":
            t = inputs[msg["key"]] = _templates(msg["bank"], msg["cands"], msg["log"])
            if meta.get("kind") == "swap_day_rule":
                for f in t["bank"].families:     # the paper's per-bank arrays (msr.engine, never entry code),
                    try:                         # built once here so no call pays for them again
                        t["bank"].engine_family(f)
                    except Exception:
                        pass
            gc.collect()
            gc.freeze()          # inherited objects stay out of the workers' garbage collection (no copy on write)
            continue
        if op == "cell":
            spec = msg["cells"]
            ranks = {}
            for c in spec:
                ranks[c[0]] = c[4]
            cells_db[msg["ckey"]] = {"cells": spec, "swap": msg["swap"],
                                     "task_order": sorted(ranks, key=ranks.get)}
            continue
        if op in ("run", "score", "runs"):
            calls = [msg] if op != "runs" else [dict(msg, op="run", draw=d, seed=sd) for d, sd in msg["calls"]]
            for call in calls:                        # one fresh process per call, back to back
                if not hasattr(os, "fork"):           # Windows: the harness starts a new launcher per call
                    _worker(call, inputs, cells_db, code, meta, entry, allowed, sealed, inline=True)
                _reset_limits()                       # nothing a call did to limits reaches the next
                vm = _vm_bytes()
                mem_limit = (vm + mem_per_call) if (vm and mem_per_call) else None
                r_req, w_req = os.pipe()              # call -> launcher
                r_ans, w_ans = os.pipe()              # launcher -> call
                pid = os.fork()
                if pid == 0:
                    os.close(r_req)
                    os.close(w_ans)
                    _worker(call, inputs, cells_db, code, meta, entry, allowed, sealed, io=(w_req, r_ans),
                            mem_limit=mem_limit)
                os.close(w_req)
                os.close(r_ans)
                got, breach = False, ""
                while True:                           # relay: requests and ONE answer, nothing else
                    try:
                        m = _recv_fd(r_req)
                    except (ValueError, OSError, UnicodeDecodeError) as e:
                        breach = f"it sent an unreadable message ({e})"
                        break
                    if m is None:
                        break
                    o = m.get("op")
                    if o == "request" and not got:
                        _send({"op": "request", "cells": m.get("cells"), "random": m.get("random"),
                               "with_no_memory": m.get("with_no_memory"), "rng_state": m.get("rng_state")})
                        reply = _recv()
                        try:
                            _send_fd(w_ans, reply)
                        except OSError:
                            pass
                    elif o in ("result", "failed") and not got:
                        got = True
                        _send({k: m.get(k) for k in ("op", "output", "error", "denied", "timing") if k in m})
                    else:
                        breach = (f"it sent a {o!r} message" + (" after its answer" if got else ""))
                        break
                if breach:
                    try:
                        os.kill(pid, signal.SIGKILL)
                    except OSError:
                        pass
                os.close(r_req)
                os.close(w_ans)
                _p, status = os.waitpid(pid, 0)
                orphans = 0
                while True:                           # anything the worker left behind comes back here
                    try:
                        p, _s = os.waitpid(-1, os.WNOHANG)
                    except ChildProcessError:
                        break
                    if p == 0:
                        orphans += 1
                        break
                _send({"op": "reaped", "status": status, "orphans": orphans, "protocol": breach})
            continue
        _send({"op": "failed", "error": f"unknown message {op!r}"})


if __name__ == "__main__":
    main()
