"""The harness: it alone reads results, answers fresh checks, and runs an entry call by call.

Everyday picture: the examiner holds the exam answers. A candidate rule sits in another room and
is handed only the notebook (the bank), the list of jobs with their 4 candidate tips (the
candidates) and the names of the two mechanics (the swap). When it wants a fresh check it passes
a note under the door; the examiner counts the notes, refuses any beyond the budget, and answers
each from the calibration results only. Every call happens in a new room that is cleared
afterwards (one fresh process per call), and the room's walls are the kernel's (scoreswap.sandbox).

Every table is built with msr.evaluate's own helpers (table_arrays, fresh_pool, Pool,
level_target, Scorer), so a rule scored here sees exactly the arrays the paper's evaluation uses.
"""
from __future__ import annotations

import json
import math
import os
import select
import struct
import subprocess
import sys
import tempfile
import threading
import time
import traceback
from collections import deque
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from scoreswap import api as API
from scoreswap import entry as EN

ROOT = Path(__file__).resolve().parent.parent
PKG = Path(__file__).resolve().parent
DEFAULT_DRAW_KEY = EN.DEFAULT_DRAW_KEY
DRAW_KEYS = EN.DRAW_KEYS
#: A single call of an entry may take at most this long (seconds) before the run is stopped.
CALL_TIMEOUT = 300.0


class EntryFailure(RuntimeError):
    """An entry broke a rule of the interface (or crashed). The message says which, plainly."""


def _ev():
    from msr import evaluate as EV
    return EV


def settings_ns(pack, board: str = "dev") -> SimpleNamespace:
    """The few study settings msr.evaluate.Scorer, CellDraws and family_arms read, from the pack. The
    seed of the checks is the board's (pack.check_seed: secret on the ranked board)."""
    s = pack.settings
    return SimpleNamespace(build=SimpleNamespace(w_score=float(s["mix_score_weight"])),
                           evaluate=SimpleNamespace(w_sensitivity=tuple(s["mix_weight_sensitivity"]),
                                                    prob_clip=tuple(s["probability_clip"]),
                                                    calib_draws=int(s["draws_per_budget"]),
                                                    seed=int(pack.check_seed(board)),
                                                    fixed_lambdas=(0.5,),
                                                    lambda_grid=tuple(s["lambda_grid"]),
                                                    k_values=tuple(k for k in pack.budgets_fit(board) if k > 0),
                                                    shuffled_seeds=1))


def _stable_int(text: str) -> int:
    import hashlib
    return int.from_bytes(hashlib.sha256(text.encode()).digest()[:8], "big")


def draw_seed(pack, stream: str, order: int, owner: str, reader: str, key: str, k: int, d: int,
              board: str = "dev") -> list:
    """The generator seed of draw d: the paper's own (msr.evaluate.draw_rng), with the board's first
    part (the public seed, or on the ranked board the secret one)."""
    EV = _ev()
    return [int(pack.check_seed(board)), EV.draw_hash(stream, order, owner, reader, key, k), int(d)]


# ---------------------------------------------------------------------------
# One owner bank and one reader table, harness side
# ---------------------------------------------------------------------------


class OwnerTables:
    """The arrays of one owner bank (owner, stream, order) on one board: its check pool (every
    calibration task) and its evaluation tasks. `split` (E,) labels each evaluation task with the
    owner's side ('dev' for a public owner, 'test' for a private one), so a board's tasks are its
    owners' tasks.

    A sealed call gets the bank's items and probe tasks in an order of their own (`item_perm`,
    `task_perm`), drawn from the board's seed (secret on the ranked board): a rule cannot match a
    position in a private bank with the same position in a public bank (all owners wrote their items
    on the same write tasks, and every bank lists the same probe tasks). The harness puts a rule's
    output back in the bank's own order (`from_sealed`) before anything is scored."""

    def __init__(self, pack, owner: str, stream: str, order: int, board: str = "dev"):
        EV = _ev()
        from scoreswap.pack import BOARD_SIDES
        self.pack, self.owner, self.stream, self.order, self.board = pack, owner, stream, order, board
        if pack.side_of(owner) not in BOARD_SIDES[board]:
            raise EntryFailure(f"{owner}'s bank is not on the {board} board")
        self.bank_payload = pack.bank_payload(owner, stream, order)
        self.cand_payload = pack.candidates_payload(owner, stream, order)
        self.log_payload = pack.showings_payload(owner, stream, order)
        self.items = list(self.bank_payload["items"])
        self.index = {i: n for n, i in enumerate(self.items)}
        cp = self.cand_payload
        self.tasks_all = list(cp["tasks"])
        self.tidx = {t: n for n, t in enumerate(self.tasks_all)}
        self.calib = pack.calib_tasks(stream, order, board)
        self.evals = pack.eval_tasks(stream, order)
        self.split = np.array([pack.side_of(owner)] * len(self.evals))
        self.C = int(cp["C"])
        rng = np.random.default_rng([int(pack.check_seed(board)), _stable_int(f"order|{owner}|{stream}|{order}")])
        self.item_perm = rng.permutation(len(self.items)).astype(np.int64)     # sealed position j -> item P[j]
        self.task_perm = rng.permutation(len(self.tasks_all)).astype(np.int64)  # sealed row r -> task Q[r]
        self.item_inv = np.argsort(self.item_perm)
        self.task_inv = np.argsort(self.task_perm)
        self.cands = {t: [(i, r) for i, r in zip(cp["items"][n], cp["relevance"][n]) if i]
                      for n, t in enumerate(self.tasks_all)}
        self.pos = {(t, i): p for t in self.tasks_all for p, (i, _r) in enumerate(self.cands[t])}
        home = pack.cell_results(owner, owner, stream, order)
        self.home = home
        self.cand_e, self.rel_e, self.yh = EV.table_arrays(home["reg"], self.evals, self.cands, self.index, self.C)
        _, _, self.yx = EV.table_arrays(home["extra"], self.evals, self.cands, self.index, self.C)
        self.home_ok = EV._all_valid(self.cand_e, self.yh)
        self.eval_rows = np.array([self.tidx[t] for t in self.evals], dtype=np.int64)
        T = len(self.tasks_all)
        self.cand_mask_all = np.array([[c < len(self.cands[t]) for c in range(self.C)] for t in self.tasks_all],
                                      dtype=bool).reshape(T, self.C)
        pseudo = (self.eval_rows[:, None] * self.C + np.arange(self.C)[None, :]).astype(np.int64)
        self.pseudo_e = np.where(self.cand_e >= 0, pseudo, -1)
        self._sealed = None

    def score_x(self, family: str) -> np.ndarray:
        return np.asarray(self.bank_payload["score"][family], dtype=float)

    def _calib_tables(self):
        if not hasattr(self, "_cal_tab"):
            EV = _ev()
            cand, _rel, yh = EV.table_arrays(self.home["reg"], self.calib, self.cands, self.index, self.C)
            self._cal_tab = (cand, yh)
        return self._cal_tab

    def calibration_v(self, x) -> np.ndarray:
        """Per CALIBRATION task, the owner's signed validity V of the scores x (one per bank item)
        against its own results (repeats 1-2): the input of msr.metrics.home_signal_flag. No estimate
        uses these tasks."""
        from msr import metrics as M
        cand, yh = self._calib_tables()
        if not len(cand):
            return np.zeros(0)
        x = np.asarray(x, dtype=float)
        xs = np.where(cand >= 0, x[cand.clip(min=0)], np.nan)
        with np.errstate(invalid="ignore"):
            import warnings
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", RuntimeWarning)
                yb = np.nanmean(yh, axis=-1)
        return M.signed_validity_parts(xs, yb, cand >= 0)[0]

    def sealed_payloads(self) -> tuple:
        """The inputs as the sealed launcher keeps them: positions only, no item or task names
        (each call gets fresh random names), no text hashes (they would name items), items and probe
        tasks in the sealed order (item_perm, task_perm), and no text with a private bank."""
        if self._sealed is None:
            P, Q = self.item_perm.tolist(), self.task_perm.tolist()
            inv = self.item_inv.tolist()
            src = self.bank_payload
            private = self.pack.side_of(self.owner) != "dev"

            def perm(v):
                return None if v is None else [v[j] for j in P]
            b = {k: v for k, v in src.items() if k not in ("items",)}
            b["text_sha256"] = None
            for key in ("score", "mix_score", "p"):
                b[key] = {f: perm(v) for f, v in src[key].items()}
            b["counts"] = {f: {k: perm(v) for k, v in d.items()} for f, d in src["counts"].items()}
            b["visits"] = perm(src["visits"])
            b["showing_probabilities"] = perm(src["showing_probabilities"])
            b["text"] = None if private else perm(src.get("text"))
            cp = self.cand_payload
            c = {k: v for k, v in cp.items() if k not in ("tasks", "items")}
            c["T"] = len(cp["tasks"])
            c["roles"] = [cp["roles"][r] for r in Q]
            c["relevance"] = [cp["relevance"][r] for r in Q]
            c["task_text"] = None if (private or cp.get("task_text") is None) else [cp["task_text"][r] for r in Q]
            c["item_pos"] = [[inv[self.index[i]] if i else -1 for i in cp["items"][r]] for r in Q]
            lp = self.log_payload
            codes: dict = {}
            g = {k: v for k, v in lp.items() if k not in ("items", "item", "task")}
            g["item_pos"] = [inv[self.index[i]] for i in lp["item"]]
            g["task_code"] = [codes.setdefault(t, len(codes)) for t in lp["task"]]
            g["n_task_codes"] = len(codes)
            self._sealed = (b, c, g)
        return self._sealed

    @property
    def sealed_cand_mask(self) -> np.ndarray:
        return self.cand_mask_all[self.task_perm]

    def from_sealed(self, mode: str, a):
        """A rule's per-item (n,) or per-candidate (T, C) array from the sealed order back to the
        bank's own order (None stays None)."""
        if a is None:
            return None
        a = np.asarray(a, dtype=float)
        out = np.empty_like(a)
        if mode == "item":
            out[self.item_perm] = a
        else:
            out[self.task_perm] = a
        return out


class CellTables:
    """One (owner, reader, stream, order) cell, harness side: the reader's table on the
    evaluation tasks, the fresh-check pool on the calibration tasks, and the scorer."""

    def __init__(self, O: OwnerTables, reader: str, settings: SimpleNamespace):
        EV = _ev()
        from msr import engine as X
        pack = O.pack
        self.O, self.reader = O, reader
        self.owner, self.stream, self.order = O.owner, O.stream, O.order
        self.kind = pack.kind[(O.owner, reader)]
        cell = O.home if reader == O.owner else pack.cell_results(O.owner, reader, O.stream, O.order)
        nr = EV.none_rates(cell["none"])
        self.none_rates = nr
        _, _, self.yr = EV.table_arrays(cell["reg"], O.evals, O.cands, O.index, O.C)
        none_ok = np.array([t in nr for t in O.evals], dtype=bool)
        self.task_ok = EV._all_valid(O.cand_e, self.yr) & O.home_ok & none_ok
        self.Th = X.Table(O.cand_e, O.rel_e, O.yh, self.task_ok)
        self.Tr = X.Table(O.cand_e, O.rel_e, self.yr, self.task_ok)
        self.Tx = X.Table(O.cand_e, O.rel_e, O.yx, self.task_ok)
        self.Ts = self.Tx if reader == O.owner else self.Tr
        self.pool = EV.fresh_pool(cell["reg"], O.calib, nr)
        self.P = EV.Pool(self.pool, O.index, O.C)
        self.target = EV.level_target(nr, O.calib)
        self.settings = settings
        self.sc = EV.Scorer(settings, self.Tr, self.P.item, self.target)
        self.Tr_c = X.Table(O.pseudo_e, O.rel_e, self.yr, self.task_ok)
        self.Th_c = X.Table(O.pseudo_e, O.rel_e, O.yh, self.task_ok)
        cal_pseudo = np.array([O.tidx[t] * O.C + O.pos[(t, i)] for t, i, _v, _b in self.pool], dtype=np.int64)
        self.sc_c = EV.Scorer(settings, self.Tr_c, cal_pseudo, self.target)
        self.no_memory = np.where(self.Tr.ok & none_ok, [nr.get(t, math.nan) for t in O.evals], math.nan)
        ranks = {t: r for r, t in enumerate(sorted({t for t, _i, _v, _b in self.pool}))}
        self.task_order = sorted(ranks, key=ranks.get)
        self.cell_spec = [(O.tidx[t], O.pos[(t, i)], O.index[i], len(v), ranks[t]) for t, i, v, _b in self.pool]
        # the same cells in the sealed order: task rows and item positions as the sealed call sees them,
        # and checks.by_task in the sealed row order (the sorted task ids would line up across banks)
        ti, ii = O.task_inv, O.item_inv
        self.sealed_cell_spec = [(int(ti[O.tidx[t]]), O.pos[(t, i)], int(ii[O.index[i]]), len(v), int(ti[O.tidx[t]]))
                                 for t, i, v, _b in self.pool]

    def spread(self) -> tuple:
        """The noise-free spread parts of this cell (msr.metrics.cross_repeat_parts), the inputs of
        retained order and stakes: ({'S_owner', 'S_reader'} per evaluation task, NaN where the task is
        not valid; the reader's spread on the CALIBRATION tasks, order's identifiability flag).
        S_owner: the owner's home repeats 1-2 (mean) x its later-session repeats 3-4 (mean);
        S_reader: the reader's repeat 1 x repeat 2 (a home cell: the owner's repeats 3 x 4). The same
        construction as msr.analysis.inject_spread_keys and reader_spread_calibration."""
        if getattr(self, "_spread", None) is None:
            from msr import metrics as M
            EV = _ev()
            O = self.O
            pres = O.cand_e >= 0
            nan = np.full(len(O.evals), np.nan)
            so = M.cross_repeat_parts(O.yh, O.yx, pres) if O.yx.shape[2] >= 1 else nan
            ye = O.yx if self.reader == O.owner else self.yr
            sr = M.cross_repeat_parts(ye[..., 0], ye[..., 1], pres) if ye.shape[2] >= 2 else nan
            arrays = {"S_owner": np.where(self.task_ok, so, np.nan), "S_reader": np.where(self.task_ok, sr, np.nan)}
            src = O.home["extra"] if self.reader == O.owner else (
                O.pack.cell_results(O.owner, self.reader, O.stream, O.order)["reg"])
            cand, _rel, yc = EV.table_arrays(src, O.calib, O.cands, O.index, O.C)
            cal = (M.cross_repeat_parts(yc[..., 0], yc[..., 1], cand >= 0) if len(cand) and yc.shape[2] >= 2
                   else np.zeros(0))
            self._spread = (arrays, cal)
        return self._spread

    def public_cells(self) -> list:
        """The checkable calibration cells with real names (the trusted in-process runner)."""
        O = self.O
        return [(j, t, i, O.pos[(t, i)], O.index[i], len(v)) for j, (t, i, v, _b) in enumerate(self.pool)]

    def swap_payload(self, budget: int, draw: int, draws: int, options: dict | None) -> dict:
        pack = self.O.pack
        s = pack.settings
        keep = ("families", "headline_family", "mix_score_weight", "lambda_grid", "probability_clip", "draw_seed",
                "draws_per_budget", "candidates_per_task", "fixed_lambdas", "shuffled_permutations", "score_rules",
                "budgets_registered", "budgets_that_fit")
        return {"owner": self.owner, "owner_maker": pack.maker.get(self.owner, self.owner), "reader": self.reader,
                "reader_maker": pack.maker.get(self.reader, self.reader), "kind": self.kind, "stream": self.stream,
                "order": self.order, "budget": int(budget), "draw": int(draw), "draws": int(draws),
                "options": dict(options or {}), "settings": {k: s[k] for k in keep if k in s}}


# ---------------------------------------------------------------------------
# Answering fresh checks
# ---------------------------------------------------------------------------


class CheckServer:
    """Answers one call's check requests from the calibration pool and counts them.

    The rules of A14: at most `budget` checks; a cell answered at most twice (its two stored
    repeats; once if only one is stored); the first answer of a cell is one of its stored repeats
    chosen at random, the second is the other one; random requests draw distinct cells not yet
    answered, uniformly without replacement.

    Two generators, both seeded with the paper's seed of this (cell, draw, DRAW_KEY, k):
    - random cells come from the harness's own generator, which the rule cannot touch, so a rule
      that asks for k random cells first gets exactly the cells recal_k (or its DRAW_KEY rule) got,
      whatever it did with checks.rng before;
    - the repeat behind a named cell comes from the generator shared with the rule (checks.rng),
      continued after the rule's own draws: this is how the paper's retest_k and audit_k drew their
      checks, so they are reproduced exactly. A rule can only change which of a cell's two repeats
      it hears first, which it may ask for anyway."""

    def __init__(self, cell: CellTables, budget: int, seed: list):
        self.P = cell.P
        self.pool = cell.pool
        self.n = cell.P.n
        self.budget = int(budget)
        self.hrng = np.random.default_rng(seed)        # random requests (harness-owned)
        self.rng = np.random.default_rng(seed)         # named-cell repeats (shared with the rule)
        self.answered = np.zeros(self.n, dtype=np.int64)
        self.first_rep = np.full(self.n, -1, dtype=np.int64)
        self.used = 0
        self.no_memory_tasks: set = set()
        self.violations: list = []

    def refuse(self, msg: str):
        self.violations.append(msg)
        raise API.CheckRequestError(msg)

    def handle(self, cells, random, with_no_memory: bool) -> list:
        """Answers as (pool index, task, item, item position, result, answer number, no-item success)."""
        P = self.P
        if (cells is None) == (random is None):
            self.refuse("a request must name cells OR ask for a number of random cells")
        try:
            if random is not None:
                if isinstance(random, bool) or int(random) != random:
                    raise ValueError
                random = int(random)
            else:
                if not isinstance(cells, (list, tuple)) or any(isinstance(c, bool) or int(c) != c for c in cells):
                    raise ValueError
                cells = [int(c) for c in cells]
        except (TypeError, ValueError, OverflowError):
            self.refuse("a request must give whole numbers: cell ids, or how many random cells")
        if random is not None:
            m = random
            if m < 0:
                self.refuse(f"asked for {m} random checks (a negative number)")
            if self.used + m > self.budget:
                self.refuse(f"asked for {m} more check(s) with {self.budget - self.used} left of a budget of {self.budget}")
            avail = np.flatnonzero(self.answered == 0)
            take = min(m, len(avail))
            if take <= 0:
                picks = reps = np.zeros(0, dtype=np.int64)
            else:
                if len(avail) == self.n:
                    picks = self.hrng.choice(self.n, size=take, replace=False)
                else:
                    picks = avail[self.hrng.choice(len(avail), size=take, replace=False)]
                reps = self.hrng.integers(0, P.nrep[picks])
            seq = [(int(c), int(r)) for c, r in zip(picks, reps)]
        else:
            for c in cells:
                if not (0 <= c < self.n):
                    self.refuse(f"asked for a cell that is not one of this call's {self.n} calibration cells")
            if self.used + len(cells) > self.budget:
                self.refuse(f"asked for {len(cells)} more check(s) with {self.budget - self.used} left of a budget of {self.budget}")
            times: dict = {}
            first = []
            for j, c in enumerate(cells):
                times[c] = times.get(c, 0) + 1
                total = int(self.answered[c]) + times[c]
                if total > int(P.nrep[c]):
                    nth = {1: "once", 2: "twice"}.get(int(P.nrep[c]), f"{int(P.nrep[c])} times")
                    self.refuse(f"asked one cell a {_ordinal(total)} time; a cell can be answered at most {nth} "
                                f"(the tables hold two runs of it)")
                if total == 1:
                    first.append(j)
            first_reps = self.rng.integers(0, P.nrep[np.array([cells[j] for j in first], dtype=np.int64)]) \
                if first else np.zeros(0, dtype=np.int64)
            fr = {j: int(r) for j, r in zip(first, first_reps)}
            seq = [(c, fr.get(j, -1)) for j, c in enumerate(cells)]
        out = []
        for c, r in seq:
            if r < 0 or self.answered[c] >= 1:
                r = 1 - int(self.first_rep[c]) if int(P.nrep[c]) == 2 else int(self.first_rep[c])
            if self.answered[c] == 0:
                self.first_rep[c] = r
            self.answered[c] += 1
            t, i, _v, base = self.pool[c]
            nm = None
            if with_no_memory:
                nm = float(base)
                self.no_memory_tasks.add(t)
            out.append((c, t, i, int(P.item[c]), float(P.y[c, r]), int(self.answered[c]), nm))
        self.used += len(out)
        return out

    @property
    def reader_calls(self) -> int:
        """Reader calls these checks would take on a real swap day: one per check, plus the 2
        no-item runs of every task whose no-item result was asked for."""
        return self.used + 2 * len(self.no_memory_tasks)


def _ordinal(n: int) -> str:
    return {1: "first", 2: "second", 3: "third", 4: "fourth"}.get(n, f"{n}th")


# ---------------------------------------------------------------------------
# Output shapes
# ---------------------------------------------------------------------------


def to_lists(out, items: list, T: int, C: int):
    """A rule's return value with item dicts turned into lists (in `items` order) and arrays into
    lists; nothing is checked here (the harness checks in `check_rule_output`)."""
    if not isinstance(out, dict):
        return out
    res = {}
    for k, v in out.items():
        if isinstance(v, dict) and k in ("u", "p"):
            missing = [i for i in items if i not in v]
            if missing:
                raise EntryFailure(f"'{k}' is a dict that misses {len(missing)} item(s)")
            v = [v[i] for i in items]
        if v is None:
            res[k] = None
            continue
        try:
            arr = np.asarray(v, dtype=float)
        except (TypeError, ValueError) as e:
            raise EntryFailure(f"'{k}' is not a list of numbers ({e})") from None
        res[k] = arr.tolist()
    return res


def check_rule_output(out, n_items: int, T: int, C: int, cand_mask: np.ndarray) -> tuple:
    """(mode, u, p): mode 'item' (u, p of shape (n,)) or 'cand' (shape (T, C)). Raises
    EntryFailure for anything outside the contract: wrong keys, wrong shapes, NaN or infinite
    values, values outside [0, 1]."""
    if not isinstance(out, dict):
        raise EntryFailure(f"the rule returned {type(out).__name__}; it must return a dict such as "
                           f"{{'u': [...], 'p': [...]}} or {{'u_cand': [[...]], 'p_cand': [[...]]}}")
    extra = set(out) - {"u", "p", "u_cand", "p_cand"}
    if extra:
        raise EntryFailure(f"the rule returned unknown keys {sorted(extra)}; allowed: u, p, u_cand, p_cand")
    if ("u" in out) == ("u_cand" in out):
        raise EntryFailure("return exactly one of 'u' (per item) and 'u_cand' (per task and candidate)")
    if "u" in out:
        if "p_cand" in out:
            raise EntryFailure("'p_cand' goes with 'u_cand'; with 'u' return 'p'")
        mode, shape, mask = "item", (n_items,), np.ones(n_items, dtype=bool)
        u, p = out["u"], out.get("p")
        names = ("u", "p")
    else:
        if "p" in out:
            raise EntryFailure("'p' goes with 'u'; with 'u_cand' return 'p_cand'")
        mode, shape, mask = "cand", (T, C), cand_mask
        u, p = out["u_cand"], out.get("p_cand")
        names = ("u_cand", "p_cand")
    arrs = []
    for name, v in zip(names, (u, p)):
        if v is None:
            arrs.append(None)
            continue
        try:
            a = np.asarray(v, dtype=float)
        except (TypeError, ValueError):
            raise EntryFailure(f"'{name}' is not an array of numbers") from None
        if a.shape != shape:
            raise EntryFailure(f"'{name}' has shape {a.shape}; it must have shape {shape} "
                               f"({'one value per bank item' if mode == 'item' else 'probe tasks x candidates'})")
        vals = a[mask]
        if not np.all(np.isfinite(vals)):
            raise EntryFailure(f"'{name}' holds {int((~np.isfinite(vals)).sum())} NaN or infinite value(s)")
        if np.any(vals < 0.0) or np.any(vals > 1.0):
            raise EntryFailure(f"'{name}' holds values outside [0, 1] (smallest {vals.min():.4g}, largest {vals.max():.4g})")
        if mode == "cand":
            a = np.where(mask, a, 0.5)
        arrs.append(a)
    return mode, arrs[0], arrs[1]


def check_score_output(x, n_items: int) -> np.ndarray:
    try:
        a = np.asarray(x, dtype=float)
    except (TypeError, ValueError):
        raise EntryFailure("the score type must return one number per item") from None
    if a.shape != (n_items,):
        raise EntryFailure(f"the score type returned shape {a.shape}; it must return one number per item ({n_items})")
    if not np.all(np.isfinite(a)):
        raise EntryFailure(f"the score type returned {int((~np.isfinite(a)).sum())} NaN or infinite value(s)")
    return a


# ---------------------------------------------------------------------------
# Running an entry: in this process (the project's own rules) or sealed, one process per call
# ---------------------------------------------------------------------------


def load_module(path: Path):
    import importlib.util
    path = Path(path).resolve()
    name = f"scoreswap_entry_{abs(hash(str(path)))}"
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise EntryFailure(f"cannot load {path}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _meta(path: Path) -> dict:
    try:
        return EN.entry_meta(path)
    except EN.EntryError as e:
        raise EntryFailure(str(e)) from None


class InProcessRunner:
    """Runs a trusted entry (the paper's own reference rules) in this process: fast, unsealed,
    real names, and its module state DOES survive from call to call (so `check --trusted` can show
    what the sealing prevents)."""

    sealed = False
    sandbox = {"sealed": False}

    def __init__(self, path: Path, module=None):
        self.path = Path(path).resolve()
        self.meta = _meta(self.path)
        try:
            self.module = module or load_module(self.path)
        except Exception:
            raise EntryFailure("the entry could not be loaded:\n" + traceback.format_exc(limit=4)) from None
        self._inputs: dict = {}

    def set_inputs(self, key: str, O: OwnerTables) -> None:
        if key not in self._inputs:
            b = API.Bank(O.bank_payload)
            self._inputs[key] = (b, API.Candidates(O.cand_payload, b), API.ScoreLog(O.log_payload))

    def run_rule(self, key: str, swap: dict, CT: CellTables, budget: int, seed: list, server: CheckServer):
        bank, cands, _log = self._inputs[key]

        def transport(c, r, nm, _rng):
            return server.handle(c, r, nm)

        checks = API.Checks(budget, CT.public_cells(), server.rng, transport, task_order=CT.task_order)
        try:
            out = self.module.rule(bank, cands, API.Swap(swap), checks)
        except API.CheckRequestError as e:
            raise EntryFailure(f"the harness refused a check request: {e}") from None
        except Exception:
            raise EntryFailure("the rule crashed:\n" + traceback.format_exc(limit=6)) from None
        if server.violations:
            raise EntryFailure(f"the harness refused a check request: {server.violations[0]}")
        return to_lists(out, bank.items, cands.T, cands.C)

    def run_rule_batch(self, key: str, swaps: list, CT: CellTables, budget: int, seeds: list, servers: list) -> list:
        return [self.run_rule(key, sw, CT, budget, sd, sv) for sw, sd, sv in zip(swaps, seeds, servers)]

    def run_score(self, key: str):
        _bank, _cands, log = self._inputs[key]
        try:
            x = self.module.score(log)
        except Exception:
            raise EntryFailure("the score type crashed:\n" + traceback.format_exc(limit=6)) from None
        if isinstance(x, dict):
            missing = [i for i in log.items if i not in x]
            if missing:
                raise EntryFailure(f"the score type's dict misses {len(missing)} item(s)")
            x = [x[i] for i in log.items]
        try:
            return np.asarray(x, dtype=float).tolist()
        except (TypeError, ValueError):
            raise EntryFailure("the score type must return one number per item") from None

    def close(self) -> None:
        pass


class _Drain(threading.Thread):
    """Reads the launcher's stderr pipe as it comes, keeping the last lines (a pipe, not a file:
    a call cannot read back what an earlier call wrote, nor learn how much it wrote)."""

    def __init__(self, stream):
        super().__init__(daemon=True)
        self.stream = stream
        self.lines = deque(maxlen=40)

    def run(self):
        for line in iter(self.stream.readline, b""):
            self.lines.append(line.decode("utf-8", "replace").rstrip())

    def tail(self) -> str:
        txt = "\n".join(list(self.lines)[-12:]).strip()
        return ("\nlast lines the entry printed:\n" + txt) if txt else ""


class ChildRunner:
    """Runs an outside entry sealed: a trusted launcher (scoreswap/_child.py) that never executes
    the entry closes a kernel sandbox, then forks one fresh worker per call (one cell, one draw).
    Without fork (Windows), a new Python process is started for every call instead (slower)."""

    sealed = True

    def __init__(self, path: Path, pack_root: Path | None = None, timeout: float = CALL_TIMEOUT,
                 deadline: float | None = None, memory_gb: float | None = None):
        self.path = Path(path).resolve()
        self.meta = _meta(self.path)
        self.timeout = float(timeout)
        self.deadline = deadline
        self.memory_gb = float(memory_gb if memory_gb else MEMORY_PER_CALL_GB)
        self.jailed, self.jail_why = jail_status()
        self.allowed = allowed_roots()
        if pack_root is not None:
            pr = Path(pack_root).resolve()
            if _inside(self.path, pr):
                raise EntryFailure(f"the entry {self.path.name} sits inside the release pack; put it elsewhere")
        self.per_call_process = not hasattr(os, "fork")
        self._inputs: dict = {}
        self._sent: set = set()
        self.proc = None
        if not self.per_call_process:
            self._start()

    def _start(self) -> None:
        env = {"PATH": "/usr/bin:/bin", "PYTHONHASHSEED": "0", "OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1",
               "MKL_NUM_THREADS": "1", "NUMEXPR_NUM_THREADS": "1", "VECLIB_MAXIMUM_THREADS": "1", "LANG": "C.UTF-8"}
        self.tmp = tempfile.TemporaryDirectory(prefix="scoreswap_launcher_")
        env["HOME"] = self.tmp.name
        if os.name == "nt":  # pragma: no cover - Windows needs SystemRoot to start Python
            env.update({k: os.environ[k] for k in ("SystemRoot", "SYSTEMROOT", "TEMP", "TMP") if k in os.environ})
        argv = [sys.executable, "-I", "-B", str(PKG / "_child.py")]
        if self.jailed:
            argv = jail_command(argv, self.allowed + [str(self.path)], {**env, "HOME": "/tmp"})
        self.proc = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                     cwd=self.tmp.name, env=env)
        self.drain = _Drain(self.proc.stderr)
        self.drain.start()
        self._sent = set()
        self._send({"op": "init", "project_root": str(ROOT), "entry": str(self.path), "allowed": self.allowed,
                    "sealed": True, "memory_per_call": int(self.memory_gb * (1 << 30))})
        msg = self._recv(timeout=120)
        if msg.get("op") != "ready":
            self.close()
            raise EntryFailure("the entry could not be loaded: " + str(msg.get("error", "")) + self.drain.tail())
        self.meta = msg["meta"]
        self.sandbox = dict(msg.get("sandbox", {}))
        self.sandbox["jail"] = ("bubblewrap namespace jail: own user, PID, network, IPC and mount namespaces; only "
                                "read-only binds of the system libraries, Python, scoreswap, msr and the entry file"
                                if self.jailed else f"NO namespace jail ({self.jail_why})")
        self.sandbox["jailed"] = bool(self.jailed)
        self.sandbox["worker"] = ("each call: a fresh process with no pipe to the harness (only its own pipes to the "
                                  "launcher); no processes, threads, pipes, signals, file locks or file watches; no "
                                  "access to another process's limits, priority or scheduling; launcher limits put "
                                  f"back before every call; at most {self.memory_gb:g} GB of memory")
        self.sandbox["memory_per_call_gb"] = self.memory_gb

    # ---- pipe ----------------------------------------------------------------
    def _send(self, obj) -> None:
        data = json.dumps(obj, allow_nan=True).encode("utf-8")
        try:
            self.proc.stdin.write(struct.pack(">Q", len(data)) + data)
            self.proc.stdin.flush()
        except (BrokenPipeError, OSError):
            raise EntryFailure("the entry's process stopped" + self.drain.tail()) from None

    def _read(self, n: int, timeout: float) -> bytes:
        buf = b""
        fd = self.proc.stdout
        while len(buf) < n:
            r, _w, _x = select.select([fd], [], [], timeout)
            if not r:
                self.kill()
                raise EntryFailure(f"a call of the entry took longer than {timeout:.0f} s and was stopped")
            chunk = os.read(fd.fileno(), n - len(buf))
            if not chunk:
                raise EntryFailure("the entry's process stopped" + self.drain.tail())
            buf += chunk
        return buf

    def _recv(self, timeout: float | None = None) -> dict:
        t = self.timeout if timeout is None else timeout
        (n,) = struct.unpack(">Q", self._read(8, t))
        if n > 1 << 31:
            raise EntryFailure("the entry's process sent a message that is too large")
        data = self._read(n, t)
        try:
            msg = json.loads(data.decode("utf-8"))   # JSON only: nothing from the entry is ever executed here
        except (ValueError, UnicodeDecodeError):
            raise EntryFailure("the entry's process sent an unreadable message") from None
        if not isinstance(msg, dict):
            raise EntryFailure("the entry's process sent an unreadable message")
        return msg

    # ---- runs ----------------------------------------------------------------
    def set_inputs(self, key: str, O: OwnerTables) -> None:
        self._inputs[key] = O
        if self.proc is not None and key not in self._sent:
            b, c, g = O.sealed_payloads()
            self._send({"op": "inputs", "key": key, "bank": b, "cands": c, "log": g})
            self._sent.add(key)

    def _fresh_for_call(self, key: str) -> None:
        """Windows: a new process for every call."""
        if self.per_call_process:
            self.close()
            self._start()
            self.set_inputs(key, self._inputs[key])

    def _time_left(self) -> None:
        if self.deadline is not None and time.time() > self.deadline:
            self.kill()
            raise EntryFailure("the entry used up its time budget for this run (--time-budget) and was stopped")

    def _protocol(self, reaped: dict) -> None:
        if reaped.get("protocol"):
            raise EntryFailure(f"the call broke the message protocol: {reaped['protocol']} (only the launcher may "
                               f"speak to the harness; a call's own messages go through the launcher, which accepts "
                               f"one answer per call)")

    def _finish(self, msg: dict, server: CheckServer | None):
        denied = msg.get("denied") or []
        reaped = self._recv()
        if reaped.get("op") != "reaped":
            raise EntryFailure("the entry's process broke the message order")
        self._protocol(reaped)
        if reaped.get("orphans"):
            raise EntryFailure("the entry left a process running after its call (not allowed)")
        if denied:
            raise EntryFailure(f"the entry tried to {denied[0]} (refused)")
        if server is not None and server.violations:
            raise EntryFailure(f"the harness refused a check request: {server.violations[0]}")
        if msg.get("op") == "failed":
            err = str(msg.get("error", "the call failed"))
            if "MemoryError" in err or "Unable to allocate" in err:
                raise EntryFailure(f"the call ran out of memory: a call may use at most {self.memory_gb:g} GB more than "
                                   f"the launcher holds (--memory GB); the error was:\n{err}")
            raise EntryFailure(err + self.drain.tail())

    def run_rule(self, key: str, swap: dict, CT: CellTables, budget: int, seed: list, server: CheckServer):
        self._time_left()
        self._fresh_for_call(key)
        ckey = f"{key}|{CT.reader}|{json.dumps(swap.get('options') or {}, sort_keys=True)}"
        if ckey not in self._sent:
            base = {k: v for k, v in swap.items() if k not in ("budget", "draw", "draws")}
            self._send({"op": "cell", "ckey": ckey, "cells": CT.sealed_cell_spec, "swap": base})
            self._sent.add(ckey)
        self._send({"op": "run", "key": key, "ckey": ckey, "budget": int(budget), "draw": int(swap["draw"]),
                    "draws": int(swap["draws"]), "seed": seed})
        while True:
            msg = self._recv()
            op = msg.get("op")
            if op == "request":
                try:
                    server.rng.bit_generator.state = _state_in(msg.get("rng_state"), server.rng)
                    ans = server.handle(msg.get("cells"), msg.get("random"), bool(msg.get("with_no_memory")))
                    self._send({"op": "answers", "answers": [(a[0], a[4], a[5], a[6]) for a in ans],
                                "rng_state": server.rng.bit_generator.state})
                except API.CheckRequestError as e:
                    self._send({"op": "refused", "message": str(e)})
                continue
            if op in ("result", "failed"):
                self._finish(msg, server)
                return msg.get("output")
            if op == "reaped":
                self._protocol(msg)
                raise EntryFailure(f"the entry's process ended without an answer (exit status {msg.get('status')})"
                                   + self.drain.tail())
            raise EntryFailure(f"unexpected message {op!r} from the entry's process")

    def run_rule_batch(self, key: str, swaps: list, CT: CellTables, budget: int, seeds: list, servers: list) -> list:
        """All the given draws of one cell in one message: the launcher forks one fresh worker per
        draw, back to back, without waiting for the harness between them."""
        self._time_left()
        if self.per_call_process:
            return [self.run_rule(key, sw, CT, budget, sd, sv) for sw, sd, sv in zip(swaps, seeds, servers)]
        ckey = f"{key}|{CT.reader}|{json.dumps(swaps[0].get('options') or {}, sort_keys=True)}"
        if ckey not in self._sent:
            base = {k: v for k, v in swaps[0].items() if k not in ("budget", "draw", "draws")}
            self._send({"op": "cell", "ckey": ckey, "cells": CT.sealed_cell_spec, "swap": base})
            self._sent.add(ckey)
        self._send({"op": "runs", "key": key, "ckey": ckey, "budget": int(budget), "draws": int(swaps[0]["draws"]),
                    "calls": [(int(sw["draw"]), sd) for sw, sd in zip(swaps, seeds)]})
        outs = []
        failure = None
        for server in servers:
            while True:
                msg = self._recv()
                op = msg.get("op")
                if op == "request":
                    try:
                        server.rng.bit_generator.state = _state_in(msg.get("rng_state"), server.rng)
                        ans = server.handle(msg.get("cells"), msg.get("random"), bool(msg.get("with_no_memory")))
                        self._send({"op": "answers", "answers": [(a[0], a[4], a[5], a[6]) for a in ans],
                                    "rng_state": server.rng.bit_generator.state})
                    except API.CheckRequestError as e:
                        self._send({"op": "refused", "message": str(e)})
                    continue
                if op in ("result", "failed"):
                    try:
                        self._finish(msg, server)
                    except EntryFailure as e:
                        failure = failure or e
                    outs.append(msg.get("output"))
                    break
                if op == "reaped":
                    if msg.get("protocol"):
                        failure = failure or EntryFailure(f"the call broke the message protocol: {msg['protocol']}")
                    failure = failure or EntryFailure(
                        f"the entry's process ended without an answer (exit status {msg.get('status')})" + self.drain.tail())
                    outs.append(None)
                    break
                raise EntryFailure(f"unexpected message {op!r} from the entry's process")
            if failure is not None:
                self.kill()                          # stop the remaining draws of this batch
                self.proc = None
                raise failure
        return outs

    def run_score(self, key: str):
        self._time_left()
        self._fresh_for_call(key)
        self._send({"op": "score", "key": key})
        msg = self._recv()
        if msg.get("op") == "reaped":
            raise EntryFailure(f"the entry's process ended without an answer (exit status {msg.get('status')})"
                               + self.drain.tail())
        self._finish(msg, None)
        return msg.get("output")

    def kill(self) -> None:
        try:
            if self.proc is not None and self.proc.poll() is None:
                self.proc.kill()
        except Exception:
            pass

    def close(self) -> None:
        if self.proc is None:
            try:
                self.tmp.cleanup()
            except Exception:
                pass
            return
        try:
            if self.proc.poll() is None:
                try:
                    self._send({"op": "exit"})
                except EntryFailure:
                    pass
                try:
                    self.proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    self.proc.kill()
        finally:
            try:
                self.drain.join(timeout=2)
            except Exception:
                pass
            self.tmp.cleanup()
            self.proc = None

    def __del__(self):  # pragma: no cover - best effort
        self.kill()


def _state_in(state, rng):
    """The rng state a worker sends back (the rule's generator, used for named-cell repeats)."""
    if not isinstance(state, dict) or state.get("bit_generator") != rng.bit_generator.state.get("bit_generator"):
        raise API.CheckRequestError("the request carried a broken random-generator state")
    return state


def _inside(p: Path, root: Path) -> bool:
    try:
        Path(p).resolve().relative_to(Path(root).resolve())
        return True
    except ValueError:
        return False


def allowed_roots() -> list:
    """Folders a sealed entry may read: the Python installation and its packages, and the
    scoreswap and msr packages. Not the entry's own folder, not the project folder, not the pack."""
    import site
    import sysconfig
    roots = {sys.prefix, sys.base_prefix, sys.exec_prefix, sys.base_exec_prefix}
    for k in ("stdlib", "platstdlib", "purelib", "platlib"):
        v = sysconfig.get_paths().get(k)
        if v:
            roots.add(v)
    try:
        roots.update(site.getsitepackages())
    except AttributeError:  # pragma: no cover
        pass
    roots.update({str(PKG), str(ROOT / "msr")})
    out = sorted({str(Path(r).resolve()) for r in roots if r and Path(r).exists()})
    return [r for r in out if Path(r) != ROOT]


def make_runner(path: Path, trusted: bool = False, pack_root: Path | None = None, timeout: float = CALL_TIMEOUT,
                deadline: float | None = None, memory_gb: float | None = None):
    return InProcessRunner(path) if trusted else ChildRunner(path, pack_root, timeout, deadline=deadline,
                                                             memory_gb=memory_gb)


# ---------------------------------------------------------------------------
# The namespace jail (Linux, bubblewrap)
# ---------------------------------------------------------------------------

MEMORY_PER_CALL_GB = 2.0          # default: how much memory one call may add to what the launcher holds
_JAIL: dict = {}


def jail_status() -> tuple:
    """(usable, why): can outside entries run inside a bubblewrap namespace jail here? Needed for a
    RANKED result; development scoring falls back to the kernel sandbox alone, with a warning."""
    if "status" in _JAIL:
        return _JAIL["status"]
    import platform
    import shutil
    from scoreswap import sandbox as SB
    st = (True, "")
    if platform.system() != "Linux":
        st = (False, f"the jail needs Linux (this is {platform.system()})")
    elif platform.machine() not in ("x86_64", "AMD64"):
        st = (False, f"the system-call filter is built for x86_64 only (this is {platform.machine()})")
    elif SB.landlock_abi() < 1:
        st = (False, "Landlock is not available (Linux 5.13 or newer is needed)")
    elif not shutil.which("bwrap"):
        st = (False, "bubblewrap (the bwrap program) is not installed")
    else:
        try:
            r = subprocess.run([shutil.which("bwrap"), "--unshare-all", "--die-with-parent", "--ro-bind", "/", "/",
                                "/bin/true"], capture_output=True, timeout=30)
            if r.returncode != 0:
                st = (False, "bwrap cannot create user namespaces on this system: "
                             + r.stderr.decode(errors="replace").strip()[:200])
        except (OSError, subprocess.TimeoutExpired) as e:
            st = (False, f"bwrap could not be run ({e})")
    _JAIL["status"] = st
    return st


def jail_command(argv: list, binds: list, env: dict) -> list:
    """bwrap: every namespace new (user, PID, network, IPC, mount, UTS, cgroup); a root that holds
    only read-only binds of the system libraries, the Python installation, the virtual environment,
    scoreswap/, msr/ and the entry file (read-only mounts never update access times); its own /proc
    (only the jail's processes), a minimal /dev, an empty /tmp; dies with the harness."""
    import shutil
    args = [shutil.which("bwrap"), "--unshare-all", "--die-with-parent", "--new-session", "--cap-drop", "ALL",
            "--clearenv", "--proc", "/proc", "--dev", "/dev", "--tmpfs", "/tmp", "--ro-bind", "/usr", "/usr"]
    for p in ("/bin", "/sbin", "/lib", "/lib64", "/lib32", "/libx32"):
        if os.path.islink(p):
            args += ["--symlink", os.readlink(p), p]
        elif os.path.isdir(p):
            args += ["--ro-bind", p, p]
    args += ["--ro-bind-try", "/etc/ld.so.cache", "/etc/ld.so.cache"]
    for b in sorted(set(binds)):
        args += ["--ro-bind", b, b]
    for k, v in env.items():
        args += ["--setenv", k, v]
    return args + ["--chdir", "/", "--"] + list(argv)
