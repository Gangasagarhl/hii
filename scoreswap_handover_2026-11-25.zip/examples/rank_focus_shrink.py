"""Example swap-day rule (not in the paper): spend the checks where the ranking matters most,
then shrink.

Everyday picture: a new mechanic starts. Instead of re-testing random tips, the garage re-tests
the tips that are about to decide the most jobs: on many jobs two tips are almost tied for
"use first", and the old score is what breaks the tie. Those tips get the fresh checks. Then the
garage asks how often the old scores pointed the right way on those checks, and trusts every old
score that much (pulling the rest toward "no idea", 0.5). Each checked tip also takes in its
fresh results.

Steps:
1. Stake of an item: on every probe task, the two candidates with the highest old mix value
   (0.5 x score + 0.5 x relevance) compete for the first slot; the closer they are, the more the
   score decides. Each of the two earns 1 / (1 + 50 x gap).
2. Checks: the highest-stake items that sit on a calibration task get one check each (one of
   their calibration cells, chosen with checks.rng), until the budget is spent.
3. Shrink: agree = share of checks where the old score was on the right side of 0.5;
   lam = clip(2 x agree - 1, 0, 1) (0.5 with no checks, like the paper's fixed_0.5).
   u = 0.5 + lam x (old - 0.5); a checked item becomes (2 u + successes) / (2 + checks).
"""
import numpy as np

KIND = "swap_day_rule"
NAME = "rank_focus_shrink"
DESCRIPTION = "Check the items that decide the most close calls, then shrink the old scores by how often they pointed the right way."


def rule(bank, candidates, swap, checks):
    q = bank.mix_score["ema_grade"]
    w = float(swap.settings.get("mix_score_weight", 0.5))
    stake = np.zeros(bank.n)
    for t in range(candidates.T):
        row = candidates.item_index[t]
        ok = row >= 0
        if ok.sum() < 2:
            continue
        items = row[ok]
        mix = w * q[items] + (1.0 - w) * candidates.relevance[t, ok]
        top = np.argsort(-mix, kind="stable")[:2]
        gap = float(mix[top[0]] - mix[top[1]])
        stake[items[top]] += 1.0 / (1.0 + 50.0 * gap)
    answers = []
    if checks.budget > 0:
        # ties by the tip's position, never by its name (names are random in every call)
        order = sorted((i for i in checks.by_item if i in bank.index), key=lambda i: (-stake[bank.index[i]], bank.index[i]))
        cells = []
        for i in order[:checks.budget]:
            cs = checks.by_item[i]
            cells.append(cs[int(checks.rng.integers(0, len(cs)))])
        answers = checks.request(cells=cells) if cells else []
    if answers:
        agree = np.mean([(q[a.item_index] >= 0.5) == (a.result > 0.5) for a in answers])
        lam = float(np.clip(2.0 * agree - 1.0, 0.0, 1.0))
    else:
        lam = 0.5
    u = 0.5 + lam * (q - 0.5)
    hits = np.zeros(bank.n)
    tries = np.zeros(bank.n)
    for a in answers:
        hits[a.item_index] += a.result
        tries[a.item_index] += 1.0
    u = (2.0 * u + hits) / (2.0 + tries)
    return {"u": u, "p": u}
