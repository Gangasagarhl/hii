"""Example swap-day rule that works per (task, candidate) and uses relevance (no checks needed).

Everyday picture: an old score says how well a tip worked for the old mechanic on the jobs it
was used for. A tip that matches today's job closely is likely being used the way it was scored,
so its score is trusted fully. A tip that only loosely matches the job is trusted halfway.

For every probe task and candidate: if the candidate's relevance is within 0.02 of the task's
most relevant candidate, u = the old ema_grade score; otherwise u = 0.5 + 0.5 x (old - 0.5).
p = u. The value depends on the task, so the rule returns u_cand and p_cand.
"""
import numpy as np

KIND = "swap_day_rule"
NAME = "relevance_gate"
DESCRIPTION = "Trust an old score fully only where the item closely matches the task; halfway elsewhere."
MARGIN = 0.02


def rule(bank, candidates, swap, checks):
    q = bank.mix_score["ema_grade"]
    idx = candidates.item_index
    rel = np.where(idx >= 0, candidates.relevance, -np.inf)
    best = rel.max(axis=1, keepdims=True)
    old = np.where(idx >= 0, q[np.maximum(idx, 0)], 0.5)
    close = rel >= best - MARGIN
    U = np.where(close, old, 0.5 + 0.5 * (old - 0.5))
    U = np.where(idx >= 0, U, 0.5)
    return {"u_cand": U, "p_cand": U}
