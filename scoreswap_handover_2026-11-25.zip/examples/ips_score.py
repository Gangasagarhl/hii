"""Example score type (not one of the paper's five): inverse-propensity weighted success.

Everyday picture: the garage's habit was to reach for the tips it already liked, so popular tips
were used on many jobs and rare tips on few. A plain success rate then mixes how good a tip is
with how often it was picked. Weighting each use by 1 / (the chance the tip had of being picked)
gives the rarely-picked uses more say, as if every tip had been picked equally often.

score(i) = (sum over its showings of result / probability + 1) / (sum of 1 / probability + 2):
the self-normalised inverse-propensity success (pre-registration 8.3.5), smoothed so an item never
shown sits at 0.5. A showing without a logged probability counts with probability 1.
"""
import numpy as np

KIND = "score_type"
NAME = "ips_score"
DESCRIPTION = "Success weighted by 1 / selection probability (self-normalised, smoothed)."


def score(log):
    pi = np.where(np.isfinite(log.probability) & (log.probability > 0), log.probability, 1.0)
    num = np.zeros(len(log.items))
    den = np.zeros(len(log.items))
    np.add.at(num, log.item_index, log.result / pi)
    np.add.at(den, log.item_index, 1.0 / pi)
    return (num + 1.0) / (den + 2.0)
