# Instructions for the agent on this machine

You are continuing a research project that arrived here as a zip. The person at this machine will tell you only:
"read the agent instructions and complete the work". Everything you need is in this file. Read it to the end
before you do anything.

## Three rules of this machine

1. NOTHING LEAVES THIS MACHINE. No upload, no push, no paste to any web service, no email, no file copied out.
   You may download (Python packages, the public benchmark data). The only way results leave is that the person
   photographs the screen. So the result must be SHORT PAGES ON THE SCREEN (see "What to show at the end").
2. NO MONEY. Use only the models this machine gives you for free. Never call a paid service.
3. NEVER INVENT A NUMBER. Print only what was measured. If something cannot be done, say so on the screen in one
   plain sentence with the measured reason. A small honest result is the goal.

## The everyday picture

An old mechanic leaves a notebook of tips, each with a score for how useful it was. A new mechanic takes over.
Are the old scores still worth keeping, or should they be wiped and learned again?
Here the mechanics are language models, the notebook is a memory of past examples with a learned usefulness score
each, and "a new mechanic" is a model swap: one version of a model replaced by another version.
One "call" is one job given to one model with one tip shown.

## What this machine has (as the owner described it)

FOUR VERSIONS OF THE SAME MODEL (one model line, four versions), free to call, many calls at the same time.
Call them, from oldest to newest, ver-1, ver-2, ver-3, ver-4. The study runs every version on every version's
notebook: 4 "home" cells (a version reading its own notebook) and 12 swaps (6 upgrades, 6 downgrades). The
question the four versions answer: how much of the old scores' value is kept after a swap, and does it fall as
the versions are further apart (1, 2 or 3 versions)?

## Step 0. Set up (no model call)

```bash
python3 -m venv .venv && .venv/bin/pip install -r requirements.txt
.venv/bin/python scripts/get_data.py          # public benchmarks (free download)
.venv/bin/python -m pytest -q -x              # stops at the first failure
```
The file `TESTS_AT_HANDOVER.txt` in this folder shows what the test run gave on the first machine just before
the zip was made. If a test fails here that passed there, the cause is this machine's set-up: fix that first.
On the first machine all 618 tests passed. If failures appear anyway, know that three workers were stopped in the middle of editing
(`msr/metrics.py`, `msr/analysis.py`, `msr/secondary_stages.py`, `scripts/make_paper_assets.py`, `msr/study.py`
and the score-phase code). Make the tests pass before any model is called; what each unfinished change was
for is in `docs/STATUS.md` (search for "E1." and for "FIRST REAL DATA").

## Step 1. Find the four versions and how to call them

1. Find out how models are called here (for example `opencode models`, a local server with an OpenAI-style
   address, or a command the owner names). If you cannot find four versions of one model line, STOP and print:
   which models you found, and the question "which four versions should I use, and how are they called?".
2. For each of the four write down: exact model id, version, release date if known, the settings you can control
   (temperature, output limit, thinking on or off).
3. Check what the model really receives: only our prompt (and at most one neutral system sentence), no tools,
   no hidden instructions. `runs/prelim_opencode/ROUTE_NOTES.md` shows how this was checked for the `opencode`
   tool (code: `msr/opencode_route.py`, provider `opencode_cli`). Thinking must be OFF or the same for all four.
4. Add the four to `models:` in `config/models.yaml` as `ver-1` ... `ver-4` (copy an existing block that uses the
   same way of calling: `opencode_cli`, `local`, `openai`, `openrouter` or `anthropic`), all with the SAME
   `family`, `price_in: 0.0`, `price_out: 0.0`. Add `[ver-1, ver-2]`, `[ver-2, ver-3]`, `[ver-3, ver-4]` to `pairs:`.
5. `.venv/bin/python scripts/smoke_test.py --yes` : one call per model. All four must answer.

## Step 2. Measure how many calls you really get (10 minutes, before anything long)

Send 50 one-word questions at once to each version, then 500. Record per version: answers per minute, the share
that fail, any message about a usage limit, any daily limit. Then set `run.workers` in
`config/study_four_versions.yaml` (and `max_parallel` of the provider block) to the highest number that keeps
failures under 1 in 100. On the first machine the free models of the `opencode` tool stopped after about 40
calls a DAY in total, whatever the number sent at once. If you meet such a limit here, STOP and print the
measured numbers and how many days the study would need. Do not wait silently.

## Step 3. Choose the size from what you measured

```bash
.venv/bin/python run.py --study config/study_four_versions.yaml --estimate     # prints the calls; nothing is called
```
The file is set to the SMALL size: one benchmark (DDXPlus, medical diagnosis from a description), one task order,
5 learning passes, 500 check tasks, all 16 cells, core stages only. That is 109,000 calls (27,250 per version). Use this ladder; go up only if the measured
speed finishes the next size within the time the person gives you (ask if they did not say; assume 24 hours):

| size | change in the study file | what it adds |
|---|---|---|
| small (start here) | as delivered | all 16 cells once |
| medium | `seeds: [0, 1, 2]` | three task orders: tighter intervals |
| large | also `streams: [ddxplus, bird]` | a second benchmark (SQL questions; needs the BIRD download) |
| extras | switch on `relearn`, `judge`, `online` (set `enabled: true`) | the comparison baselines |

If even the small size is too large, shrink in this order and print what you did: `sizes: {n_build: 450,
n_probe: 300, n_test: 150}` with `build.n_write: 150` and `evaluate.calib_tasks: 60`; then fewer versions
(ver-1 and ver-4 only: the largest gap). Never change the prompts, `data/splits`, or the scoring code.

## Step 4. Run

```bash
.venv/bin/python run.py --study config/study_four_versions.yaml --yes --workers <N>
```
- Every answer is saved as it arrives. If the run stops, start the same command again: nothing is asked twice.
- The second repeat of each cell is meant to run in a later session than the first (6 hours later by the written
  plan). If time does not allow, set `probe.repeat_gap_hours` to what you can afford, and print the gap you used.
- When the calls are done the same command runs the evaluate stage and writes `runs/four_versions/results/`
  (`SUMMARY.md` is the long version; do not print it).
- Then: `.venv/bin/python -m msr.analysis --study four_versions` (group results and tests). If it fails because
  of the unfinished statistics edits and you cannot fix it within an hour, skip it and say so; the pages below
  need only the evaluate stage.
- Watch for: answers that cannot be read (the first pilot had 122 of 17,900, all from one model: look at 10 of
  them and print what they look like), refusals, answers cut at the output limit, a model id that changes
  during the run (stop the run if it does).

## What to show at the end (this is the only thing that leaves the machine)

```bash
.venv/bin/python scripts/print_results.py --study four_versions            # all pages
.venv/bin/python scripts/print_results.py --study four_versions --page 1   # one page at a time for photos
```
It prints numbered pages of at most 36 lines and 100 characters, each table with a "sum of each column" line so
the reader of the photo can check the digits. Tell the person: "photograph each page, one page per photo, the
whole page readable". Print one more page yourself, BEFORE those, in exactly this form (plain text, no more than
36 lines of 100 characters), and call it page 0:

```
ScoreSwap run report | page 0
models: ver-1 = <exact id> | ver-2 = <exact id> | ver-3 = <exact id> | ver-4 = <exact id>
how they were called: <tool or address> | thinking: <off / same for all> | temperature: <value>
size run: <small / medium / large / shrunk: say how> | benchmark(s): <...> | task orders: <...>
calls made: <n> | answered: <n> | failed: <n> | unreadable answers: <n> | refused: <n>
calls at once: <n> | answers per minute: <n> | hours it took: <n> | limits met: <none / which>
gap between repeat 1 and repeat 2: <hours>
tests before the run: <passed / failed counts> | analysis step: <ran / skipped: why>
changed from the delivered files: <list every file you edited and why, one line each>
not done: <list>
anything a reader must know before trusting these numbers: <plain sentences>
```
If the person asks for "the summary", these pages are it. Keep every other output on this machine.

## What already exists that is real (for your orientation only)

`runs/pilot_shot/` holds a first small pilot made on the first machine with two versions of another model line
(17,900 calls). `.venv/bin/python scripts/print_results.py --study pilot_shot` shows what your pages will look
like. In that pilot the old scores picked the better stored example about 63 to 68 times in 100 at home, and
keeping them beat wiping them by 3 to 5 points at home and by 3.3 points after the upgrade.

## More background, if you need it

`AGENTS.md` (the project, its folders and rules), `README.md` (set-up), `docs/STATUS.md` (the full record, newest
at the bottom), `prediction/PREREGISTRATION.md` (the written plan), `docs/BENCHMARK_GUIDE.md` (the scoring tool;
not needed for this run). The paper itself is written on the first machine from your photographed pages; do not
build or edit the paper here.
