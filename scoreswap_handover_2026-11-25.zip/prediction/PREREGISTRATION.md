# Pre-registration: the model-swap benchmark (working name ScoreSwap)

**Status: DRAFT. Not frozen.** This file replaces `prediction/PREDICTIONS_DRAFT.md`. The name SwapBench is taken by
ZenML's model-swap benchmark (October 2026), the closest neighbour on topic; the paper cites it in related work.
Written 23 November 2026. Sources: `docs/MASTER_PLAN.md` (sections 2.3 and 2.4 as revised on 23 Nov after the
first dry run; the master plan wins over older files) and `research_notes/Model swap benchmark ICML plan/statistics_and_power.md`
(called "the statistics note" below), including its power tables in `power_simulation_output.md`.

How to read this file:
- Parts 0 to 10 follow the layout in section Q7 of the statistics note. Part 11 registers the two additions adopted
  on 23 Nov 2026 (`docs/MASTER_PLAN.md` 2.11): the transfer decomposition with its pre-swap forecast, and the
  keep-or-drop swap-day check.
- An outside statistician should be able to run every confirmatory analysis from this file alone.
- **SET AFTER PILOT** marks the few values that the pilot may fix. Each one is fixed by the rule stated in Part 9.
  None of those rules reads a swap (cross-model) result.
- The end of the file has two lists. "Settled by the research manager, 23 Nov 2026" records rulings that are already
  written into this file. "Open points" lists what must still be settled **before** the freeze. After the freeze,
  every change goes into the deviations log (Part 10).
- Nothing in this file is a result. Numbers marked [sim] come from the statistics note's simulation or from the
  simulations in `docs/power/` (round-1 revision). They are design aids under stated assumptions, not measurements.
- **Round-1 revision (23 Nov 2026, before the freeze, so no deviation).** After the first round of mock reviews the
  research manager decided seven changes (S1–S7), written into Parts 0–10: (S1) the headline is the noise-free
  retained ranking signal θ = V_swap / V_home, and the non-inferiority margin sits on θ; the concordance ratio R, the
  drop D and R_adj are secondary; (S2) the drop test and the no-material-drop test are two separate members of the Holm
  family (15 primary tests), also for the per-pair flags; (S3) every primary interval and test clusters on task id
  pooled over the stream orders and treats items as sampled (two-way); the power statement was re-simulated;
  (S4) prediction quality is compared on level-corrected log scores, as swap-minus-home contrasts, with decision
  quality in success points beside every result and a constant-prediction reference; (S5) `oracle` is renamed
  `split_half` (a reference, not a bound), an in-sample `ceiling` is added, swap groups are named by maker, and each
  group's spread sits in the group table; (S6) every open-weight model samples at temperature 1.0, top_p 1.0, no top_k,
  and the settings are part of each model's logged identity; (S7) a "what is at stake" table in success points.
  The list "Settled in the round-1 revision" at the end records them.
- **Revision 2 (24 Nov 2026, before the freeze, so no deviation).** After the second round of mock reviews (R4–R6 and
  the area chair's audit) the statistics core was revised in Parts 0–10 (Part 11 changed only in the two sentences of
  11.3.8 that the core-grid ruling touches): (D1) one number with one
  identity: θ (value kept) = order × stakes, with the order reported "not identifiable" by a calibration-task rule
  (Part 2.4); (D2) every PC1 claim is an intersection-union test that includes the test of a positive home signal
  (Part 3); (D3) every decision word comes from a registered test (`msr.metrics.pc1_label`; no "practical size" label);
  (D4) one home-signal flag for the whole code base (`msr.metrics.home_signal_flag`); (D5) the primary variance is the
  two-way delete-one-cluster jackknife with items coded by identity across the orders, every primary test reports its
  item share and effective item clusters, and the small-sample factor 1.03 is withdrawn (Part 4.1); (D6) the primary
  family is PC1 (three members per group) + PC2 = 12 tests; PC3 and PC4 are secondary, with their additivity
  assumption, the owner–reader base-rate gap and a base-rate sensitivity analysis (Parts 3, 5.1); (D7) a between-pair
  SD and a prediction interval for a new pair per group (Part 5.2); (D8) a capability table: θ against capability gap
  and error consistency with maker as a separate term (Part 8.2.17); (D9) P1 is F1's test of Part 11.3.8 (partial
  correlation given F1's controls, maker-preserving relabellings), computed on the core grid only (Part 7); (D10) two
  extension pairs (Mistral Small 3 → 3.2, DeepSeek V4.1-Flash → V4.1-Flash-1017) run as same-maker cells only, so the
  same-maker groups have 6 swaps each (Parts 0.2, 0.3, 2.1); (D11) the new stages and construct checks are registered
  secondary analyses (re-answer, the new model as judge, the owner's write-time self-rating, relearn, re-exploration,
  the stored-answer-correct reference, the construct strata, the doubly robust score; Part 8.2.18–8.2.25), the
  benchmark's development / test split is registered (Part 1.8), and repeat 2 of every cell runs in a defined later
  session (Parts 0.3, 2.4). The list "Settled in revision 2" at the end records them.
- **Public registration.** The frozen file (with Part 0.1 and the freeze block filled) is deposited by the authors on
  a public, time-stamped registry before the first paid main-run call, and the registry's identifier is written into
  Part 0.1 and the freeze block: registry ____, identifier ____, URL ____ (left blank until the deposit).

---

## Part 0. Identity, terms and design constants

### 0.1 Identity (filled in at the freeze)

| Item | Value |
|---|---|
| Git commit of the repository at the freeze | ____ |
| sha256 of `config/models.yaml`, `config/study.yaml`, `config/study_memprompt.yaml`, `config/pilot_shot.yaml`, `config/pilot_memprompt.yaml`, `config/pilot_bird.yaml` (and the DS-1000 files, if used) | ____ |
| sha256 of `msr/theory.py`, `msr/forecast.py`, `msr/sequential.py` (their constants are registered in Part 11.5) | ____ |
| sha256 of `msr/prompts.py` (all prompt templates, verbatim) | ____ |
| sha256 of the stream data files checked by `msr/data.py` | ____ |
| sha256 of the split files `runs/study/splits/*.json` (made from the seeds below before any paid main call) | ____ |
| Per model, from the smoke test (settled point 19): the fields listed below this table | ____ |
| Price snapshot: date and USD per million input and output tokens per model | ____ |
| Embedder | `BAAI/bge-base-en-v1.5`, run locally, the same for every model |
| Analysis code run end to end on the simulated models (`python run.py --study config/sim.yaml`), recovering the simulation's known truth | yes / no, date ____ |
| Pilot-set values (Part 9.2) | headline family ____; score passes ____; exploration ____; second stream ____ |
| Public, time-stamped registry: name, identifier, URL and deposit date (deposited by the authors before the first paid main-run call) | ____ |
| Agent leg L3 (Part 8.4): pairs run, set by its budget rule | ____ |

Per-model fields, copied into this Part from `config/models.yaml` after the smoke test (settled point 19), for each of
the 12 models (the 8 of the core grid and the 4 of the extension pairs, Part 0.2):
- the exact endpoint model string sent, and the model string returned by the smoke-test call;
- the provider and route: Anthropic API, OpenAI API, or OpenRouter with the pinned host (DeepInfra for Qwen, Parasail
  for Gemma), fallbacks off, and the quantisation (fp8);
- the thinking or reasoning setting: Haiku 4.5 none sent; Haiku 5.5 thinking disabled; the Luna pair's
  `reasoning_effort` (the lowest level both models accept, the same for both); the Qwen and Gemma thinking switch as
  the host exposes it;
- sampling: closed models (Anthropic, OpenAI) take no sampling value, so their fixed provider default applies; every
  open-weight model is sent temperature 1.0 and top_p 1.0 with no top_k (round-1 revision, S6: matched to the closed
  models' default as closely as the hosts allow); any other value a host accepts is stated, none left to the host's
  default. These settings are part of the model's identity: they are logged per run (`model_settings.json`) and in
  `results/model_identity.csv` beside the model strings the API returned;
- the answer limit (1,024 tokens) and any provider seed field used;
- the price per million input and output tokens on the snapshot date, and any tokenizer factor used by the estimate.

### 0.2 Terms (each defined once)

- **Stream.** A task set taken in sequence. Stream 1 is DDXPlus (medical diagnosis). Stream 2 is BIRD (text to SQL),
  or DS-1000 if BIRD fails its pilot rule (Part 9.2).
- **Stream order (order).** One seeded shuffle of a stream. Seeds 0, 1 and 2 give three orders. Each order has its
  own split and its own banks.
- **Item.** One memory item: the text of one write task plus the model's answer to it, with **no** right or wrong
  label (StreamBench's plain "shot" style).
- **Bank.** The 250 items one model wrote for one stream and order, together with every item's scores.
- **Bank owner (owner).** The model that wrote a bank and earned its scores.
- **Score family.** A rule that turns an item's history into a score. There are five (Part 0.4).
- **Reader.** The model that answers a probe task while one item from the owner's bank is shown.
- **Home.** A cell where the reader is the owner. **Swap.** A cell where the reader is a different model. A swap is
  written owner → reader.
- **Core grid and extension pairs (revision 2).** The core grid is the 8 models of four makers with every ordered pair:
  8 home cells and 56 swaps per stream and order. The two extension pairs (Mistral Small 3 → Mistral Small 3.2 and
  DeepSeek V4.1-Flash → DeepSeek V4.1-Flash-1017, two more makers) run as same-maker cells only: per pair the upgrade,
  the downgrade and both home cells, so 4 more home cells and 4 more swaps (12 home cells and 60 swaps in all). The
  grid is therefore not square: an extension model is never paired with a model of another maker. Which cells exist,
  and the group of each swap, are read from the study configuration (`pairs`, `upgrade_pairs`, each model's maker), never
  inferred from the grid's shape.
- **Same-maker swap.** Owner and reader come from the same maker: 6 same-maker upgrades (old → new: 4 in the core grid,
  2 extension) and 6 same-maker downgrades (new → old). **Cross-maker swap.** Owner and reader come from different
  makers: 48 swaps, all in the core grid. ("Family" is used only for the five score families.)
- **Swap group.** One of the three groups of swaps that the confirmatory tests treat separately: (a) the 6 same-maker
  upgrades, (b) the 6 same-maker downgrades, (c) the 48 cross-maker swaps. (Called "swap group" before the round-1
  revision; 4, 4 and 48 swaps before revision 2.)
- **Task stratum.** One (stream, order). **Task cluster.** One task id within a stream, with all its appearances in the
  three orders (Part 4.1).
- **Headline family.** The score family used by the primary comparisons and the predictions P1, P2 and P4:
  `ema_grade`, unless the pilot rule of Part 9.2 replaces it.
- **Probe task.** One of the 500 tasks per order used for measuring. **Evaluation task:** one of 400 probe tasks on
  which every concordance, success, regret, log score and Brier score is computed. **Calibration task:** one of 100
  probe tasks kept apart from them: they supply the arms' fresh checks and the other uses listed in Part 1.3.
- **Candidates.** For one probe task, the 4 items of the owner's bank that are most relevant to it.
- **Relevance.** (cos + 1) / 2 of the cosine similarity between the embedding of the probe task's TEXT and the
  embedding of the item's source task TEXT (the task's question field only, as StreamBench embeds it: DDXPlus the
  patient profile, BIRD the question; the stored answer is not embedded), in [0, 1], rounded to 6 decimals, ties by
  item id (`msr/embed.py`, `msr/retrieval.py`; the item's vector is its write task's vector, `msr/probe.py`,
  `msr/build.py`).
- **Probe table.** For every owner-reader cell: the graded result (1 right, 0 wrong) of the reader on every probe task
  with each candidate shown alone, twice (repeats 1 and 2), and with no item, twice. Home cells get two extra
  repeats with each candidate shown (repeats 3 and 4).
- **Fresh check.** One program-graded result of the reader on one (probe task, candidate) cell, taken from the probe
  table, which a swap-day rule may use. The arms of Part 2.6 draw them from calibration tasks only; the replay of the
  swap-day check (Part 11.4) also uses one half of the evaluation tasks. A rule "with k checks" uses k of them.
- **Arm (swap-day rule).** A way to turn the owner's old scores (and, for some arms, k fresh checks) into the scores
  used with the reader (Part 2.6).
- **Mix.** The value retrieval ranks by: 0.5 × normalised score + 0.5 × relevance.
- **First-shown item.** The candidate with the highest mix value under an arm.
- **Informative pair.** Two candidates of one task whose mean results for the reader differ.
- **Concordance.** How often, within a task, the higher-scored candidate is the one that worked better (Part 2.2).
  0.5 is chance.
- **Signed validity V.** Per task, the outcome differences of the candidate pairs, signed by the old score order
  (Part 2.2). Linear in the outcomes, so outcome noise does not bias it.
- **Retained ranking signal θ (the headline; "value kept").** V after the swap divided by V at home, on the same tasks
  (Part 2.4).
- **Item spread S (revision 2).** Per task, the noise-free sum over candidate pairs of the squared difference of one
  model's success chances, estimated by the product of two independent measurements (cross-repeat product, Part 2.4).
- **Stakes and order (revision 2).** Stakes = √(S_reader / S_owner): how much the reader's success depends on which item
  it is shown, against the owner's. Order = θ / stakes: whether the old order of the items still fits the reader. So
  θ = order × stakes exactly (Part 2.4).
- **Concordance ratio R (secondary).** The share of the home model's above-chance concordance left after the swap
  (Part 2.4); it moves with the reader's outcome noise. Called "retained validity" before the round-1 revision.
- **Self-swap reference.** What the measures give when the "new" model is the same model run again: home scores
  against the extra home repeats (Parts 2.3, 4.4). It shows what a loss looks like when nothing changed. (Called the
  "self-swap reference" before the round-1 revision.)
- **Noise reference.** The split-half value defined in Part 2.5. It is not an upper bound.
- **Pilot.** The gating run on seed 99 (Part 9). Pilot data never enter any confirmatory analysis.

### 0.3 Design constants

Config keys refer to `config/study.yaml` unless another file is named. Every key named below is read by the code
(`msr/study.py`) (amended 23 Nov 2026, before any paid run).

| Constant | Value | Config key |
|---|---|---|
| Models of the core grid (8, four makers) | `claude-haiku-4-5-20251001` → `claude-haiku-5-5`; `gpt-5.6-luna` → `gpt-6-luna`; `Qwen3.5-27B` → `Qwen3.8-27B` (one pinned host, DeepInfra fp8); `gemma-3-27b` → `gemma-4-31b` (one pinned host, Parasail fp8) | `models`; per-model entries in `config/models.yaml` |
| Extension pairs (revision 2; 4 models, two more makers) | Mistral Small 3 → Mistral Small 3.2; DeepSeek V4.1-Flash → DeepSeek V4.1-Flash-1017 (model strings and pinned hosts copied into Part 0.1 at the freeze) | `models`, `pairs`, `upgrade_pairs` in the study file; per-model entries in `config/models.yaml` |
| Old → new pairs (define "same maker" and "upgrade") | the six above | `upgrade_pairs` in the study file, else `pairs` in `config/models.yaml` |
| Cells | core grid: every ordered pair of its 8 models (56 swaps + 8 home cells); extension pairs: the upgrade, the downgrade and both home cells of each (4 swaps + 4 home cells); 60 swaps + 12 home cells in all | `pairs` in the study file |
| Thinking and reasoning | off on every model | `config/models.yaml` per model |
| Sampling (round-1 revision, S6) | closed models: nothing sent (their fixed provider default); open-weight models: temperature 1.0, top_p 1.0, no top_k, sent explicitly; part of each model's logged identity (`results/model_identity.csv`). Sensitivity: the Qwen pair at temperature 0.7 (Part 8.2.15) | `extra_body` in `config/models.yaml`; `config/study_temperature.yaml` |
| Streams | DDXPlus; second stream **SET AFTER PILOT** (BIRD or DS-1000) | `streams` |
| Stream orders (seeds) | 0, 1, 2. Pilot: 99 | `seeds`; `seeds` in the `config/pilot_*.yaml` files (amended 23 Nov 2026, before any paid run) |
| Write tasks per order | 250 (answered with no memory; each becomes one item; content then frozen) | `build.n_write` (amended 23 Nov 2026, before any paid run) |
| Score tasks per order | 500 | `sizes.n_build` − `build.n_write` (`sizes.n_build` = 750 = write + score tasks) (amended 23 Nov 2026, before any paid run) |
| Probe tasks per order | 500 = 400 evaluation + 100 calibration | `sizes.n_probe`; `evaluate.calib_tasks` = 100 |
| Test tasks per order | 250 (post-swap run only) | `sizes.n_test` |
| DS-1000 sizes (contingency, only if it becomes stream 2) | 150 write, 300 score, 500 probe (400 + 100), 50 test; visits rule at 60% of the bank; no post-swap run on DS-1000 | `sizes.*` in the DS-1000 study file |
| Pilot | Haiku 4.5 and Haiku 5.5; seed 99; DDXPlus and BIRD at 250 write, 500 score, 200 probe (150 evaluation + 50 calibration), 100 test; DS-1000 check (Part 9.1) | `config/pilot_shot.yaml` (DDXPlus), `config/pilot_bird.yaml` (BIRD), `config/pilot_memprompt.yaml` (labelled items); no DS-1000 file yet (amended 23 Nov 2026, before any paid run) |
| Score passes over the score tasks | fixed by the pilot rule of Part 9.2: the first pass p in 3..6 at which at least 150 of the 250 items have 5 or more score-phase visits (rerun at exploration 0.5 if none); the budget assumes 5 (`build.epochs: 5` until the pilot sets it). Relearn (Part 8.2.21) uses the same number of passes as the build (amended 24 Nov 2026, before any paid run) | `build.epochs` |
| Items shown per score-phase task | 1 | `build.n_show` |
| Candidates retrieved | 4 (build and probe) | `build.candidates`; `probe.candidates` |
| Exploration | 0.3: with this chance a candidate is drawn uniformly from the 4 instead of the top of the mix; **SET AFTER PILOT** (0.3 or 0.5, Part 9.2) | `build.epsilon`; `build.explore_pool: relevance` |
| Mix weight on score | 0.5 (0.5 × score + 0.5 × relevance) | `build.w_score` |
| Family that drives retrieval in the build | `ema_grade` | `build.drive` |
| Headline family (the primary tests PC1–PC2, the secondary PC3–PC4, P1, P2, P4, post-swap run) | `ema_grade`; **SET AFTER PILOT** only if `ema_grade` fails its gate-2 test, by the fixed order of Part 9.2 | `evaluate.headline_family`; `online.families` for the post-swap run (amended 23 Nov 2026, before any paid run) |
| Item style | plain "shot" (task + answer, no label); all items stored, right or wrong | `build.item_style: shot`; `build.store: all` |
| Labelled style | "memprompt", sensitivity only: the pilot, and four models (Haiku 4.5, Haiku 5.5, Qwen3.5-27B, Qwen3.8-27B) with all 12 ordered swaps among them and their 4 home cells, on DDXPlus with stream order 0 only (Part 8.3.6; about USD 31–45 by the pipeline's estimate) (amended 23 Nov 2026 in the round-1 revision, before any paid run) | `build.item_style: memprompt` in `config/pilot_memprompt.yaml` and `config/study_memprompt.yaml` (`streams: [ddxplus]`, `seeds: [0]`) |
| No-memory run | each score task answered once with no memory (used by `credit`) | `build.no_memory_run` |
| Selection probability | logged for every score-phase selection | (logged by `msr/build.py`) |
| Score families | `ema_grade`, `beta_grade`, `tags_self`, `credit`, `visits` (Part 0.4) | `scores.families`; `scores.counter_ranking: smoothed` (the smoothed share of Part 0.4) (amended 23 Nov 2026, before any paid run) |
| What the `tags_self` tagger sees | the task, the item and its own answer only, never the grade | `build.self_tag: true`; `build.self_tag_sees_grade: false` (amended 23 Nov 2026, before any paid run) |
| `ema_grade` step and start | 0.3 and 0.5; reward 1 or 0 | `scores.ema_alpha`; `scores.ema_q0` (amended 23 Nov 2026, before any paid run) |
| Repeats per probe cell | 2; no-memory repeats 2; extra home repeats 2 | `probe.repeats`; `probe.no_memory_repeats`; `probe.home_extra_repeats` |
| Timing of the extra home repeats | in the last third of each model's collection window; call times logged | (run order) |
| Timing of the repeats of EVERY cell (revision 2) | repeat 2 of every probe cell, home cells included, runs in a later session than repeat 1 (evaluation and calibration tasks); in home cells the extra repeats 3–4 run in a later session than repeats 1–2, and repeat 4 in a later session than repeat 3. No extra calls. "Later session" is defined in Part 2.4 (at least 6 hours later, `probe.repeat_gap_hours`; a new connection; provider and local caches off; logged per call). Why every cell: every spread S of Part 2.4 is a product of two measurements of the same cells, and a cached repeat inflates it: the reader's (repeat 1 × repeat 2 of a swap cell; repeat 3 × repeat 4 of a home cell read as a self-swap) and the owner's (repeats 1–2 × 3–4 of its home cell; a same-session home repeat would inflate S_owner and deflate stakes). `docs/power/order_stakes.md`: a cache rate of 0.1 inflates stakes × 1.32 and shrinks order × 0.76; 0.3 gives × 1.80 and × 0.56. If the schedule cannot do this: one later-session repeat on the 12 same-maker swap cells and the 12 home cells on 100 evaluation tasks per order (2,400 calls per cell: 19,200 for the 8 core swap cells, 28,800 with the 4 extension swap cells, 57,600 with the 12 home cells), the home check of within- against across-session products, and the identical-response rate between repeats; a model flagged by either check gets a later-session repeat on all its cells | (run order; call times, session and process ids logged per call) |
| Fresh checks k | 8, 16, 32, 64, 128, 256. Primary comparison PC4 uses k = 64; the curve over k = 8–64 is secondary; k = 128 and 256 are exploratory (Part 8.3.7). A k larger than the calibration pool (calibration tasks × 4 candidates: 400 cells in the main study, 200 in the pilots) is skipped with a one-line note (amended 24 Nov 2026, before any paid run) | `evaluate.k_values` |
| Random draws of the k checks per cell, and permutations of `shuffled` | 200 each (amended 23 Nov 2026, before any paid run): the Monte-Carlo error of a mean over 200 draws is small next to the task-sampling error; in the simulated study its standard error was about 0.002 (at most 0.007) for first-shown success and 0.001 for the log score per cell and order, against task-sampling standard errors of about 0.046 and 0.013 for that cell's 56 tasks (about 0.010 and 0.003 at the 1,200 tasks of a stream) | `evaluate.calib_draws`; `evaluate.shuffled_seeds` (amended 23 Nov 2026, before any paid run) |
| Fixed discount weights λ | 0.1, 0.2, …, 0.9. Primary comparison PC3 uses λ = 0.5 | `evaluate.fixed_lambdas` |
| Weight grid for the power prior | 0, 0.05, …, 1 | `evaluate.lambda_grid` |
| Primary variance (revision 2) | two-way delete-one-cluster jackknife (CV3 in each dimension): task ids (pooled over the orders of a stream) × items (multiple membership, coded by identity within owner and stream across the orders); normal reference; Fieller sets for θ, stakes and order; item share, effective item clusters and Satterthwaite df printed beside every primary test (Part 4.1); a t reference with effective-cluster df was tried and not adopted (no change in size or coverage, Part 4.1). Before revision 2: the linearised two-way variance with items coded per bank and order | (analysis code: `msr.metrics.robust_variance`, `contrast_variance`, `theta_tests`; `msr.analysis.TwoWay`) |
| Task-only bootstrap (secondary intervals): draws and seed | 10,000; seed 0; task ids resampled per stream with all their appearances | `evaluate.bootstrap`; `evaluate.seed` |
| Probability clip for log score and Brier | [0.01, 0.99] | `evaluate.prob_clip` (amended 23 Nov 2026, before any paid run) |
| Level correction of predicted success (round-1 revision, S4) | every arm's p shifted by one constant on the logit scale so that its mean over the (calibration task, candidate) cells equals the reader's no-memory success on the calibration tasks (Part 2.8). Sensitivity (revision 2): the same shift with the target set to the reader's mean success with an item shown on those cells (keys `log_lcw`, `brier_lcw`) | (evaluate code: `msr.metrics.level_shift`) |
| Non-inferiority fraction | 0.25 of the home ranking signal: "no material drop" is θ > 0.75 (round-1 revision, S1) | `evaluate.ni_fraction` (amended 23 Nov 2026, before any paid run) |
| Difference threshold | 5 points (0.05 in concordance; 5 percentage points in success) | `evaluate.min_difference` (amended 23 Nov 2026, before any paid run) |
| θ's reporting flag (24 Nov 2026; one rule since revision 2) | "defined" when the owner's signed validity on its CALIBRATION tasks is at least 2 standard errors above 0 (z = ΣV / (sd √n); 600 calibration tasks per owner over both streams). It only labels: θ, its Fieller set and every test are always computed and written. It is the one home-signal flag of the whole code base: every module (analysis, transfer decomposition, forecast, keep-or-drop check, scorer) calls `msr.metrics.home_signal_flag`, which returns (z, status); none keeps a rule of its own. The former same-task rule (V̄_home ≥ 4 SEs on the same evaluation tasks) is kept as a secondary column only and decides nothing | `msr.metrics.home_signal_flag` (built on `THETA_CAL_MIN_Z`, `calibration_z`, `theta_status_calibration`; the same-task rule: `THETA_MIN_Z`) |
| Order identifiable (revision 2) | the reader's item spread on the swap cell's CALIBRATION tasks (repeat 1 × repeat 2) is at least 2 standard errors above 0, and both spreads are positive on the evaluation tasks; otherwise the order is labelled "not identifiable: the reader's item spread cannot be told from zero" (point and set still written) | `msr.metrics.ORDER_MIN_Z` (2), `order_stakes_inference` |
| R defined only if the home signal ≥ this many standard errors | 4 (R: C_home − 0.5 with the task-only SE) | `evaluate.ratio_min_z` (amended 23 Nov 2026, before any paid run) |
| Small-sample factor of every two-way standard error | withdrawn in revision 2 (it was 1.03, 24 Nov 2026): the jackknife's leverage term does its job (Part 4.1) | `msr.metrics.TWOWAY_SE_FACTOR` = 1 |
| Familywise error rate | 0.05; Holm over 12 primary tests (4 hypotheses: PC1-drop, PC1-MD, PC1-NI, PC2 × 3 swap groups); PC3 and PC4 are secondary (revision 2) | (analysis code: `msr.analysis.primary_tests`) |
| Answer length limit | 1,024 tokens | `llm.max_tokens` |
| Excluded tasks | `bird-0701`, and any task removed by rule 1.4.1 | `exclude_tasks` |
| BIRD grading | corrected parser (primary); StreamBench's original is a sensitivity run | `grading.bird_faithful: false` |
| Prompt wording | v1 (primary); v2 for the second-wording run | `prompt_variant`; `variants.*` |
| Second bank | Haiku 4.5 and Qwen3.5-27B, another exploration seed, the same items | `build.second_bank_models` |
| Realism check (several items shown together) | Part 8.3.2 | `probe.subsets.*` |
| Mix-weight sensitivity | score weight 0.25 and 0.75 | `evaluate.w_sensitivity` |
| Constants of the additions | Part 11.5 | module constants in `msr/theory.py`, `msr/forecast.py`, `msr/sequential.py` |
| Post-swap run | 12 swaps (Part 2.10), headline family, 1 item shown, 1 repeat, exploration 0, every arm keeps learning by its family's own update rule, content frozen | `online.pairs: upgrades_and_reverse` with `online.extra_pairs: cross_cycle`; `online.arms`; `online.families`; `online.n_show`; `online.epsilon`; `online.learn`; `online.window`, `online.first_n`, `online.target_share` (n95 and S_100); the single repeat is fixed in the code (amended 23 Nov 2026, before any paid run) |

### 0.4 Score families

Every family is kept on every item at the same time. Visits and grades count only score-phase shows. For item i:
n = number of score-phase shows, s = successes among them, f = n − s; h and g = number of "helpful" and "harmful"
self-tags; c = mean over its shows of (result with the item − result of the no-memory run on the same task).

| Family | Evidence | Ranking score x (used by concordance) | Normalised score u in [0, 1] (used in the mix) | Predicted success p (used by log score and Brier) |
|---|---|---|---|---|
| `ema_grade` | program grade | q, the moving average: start 0.5, q ← q + 0.3 (y − q) | q | q |
| `beta_grade` | program grade | (1 + s) / (2 + n), the Beta(1,1) posterior mean | same | same |
| `tags_self` | owner's own helpful / harmful tag, given without the grade (it sees the task, the item and its own answer) | (1 + h) / (2 + h + g) | same | same |
| `credit` | grade with item minus grade without | c (start 0) | (1 + c) / 2 | clip(r0 + c), where r0 = owner's no-memory success over its score tasks |
| `visits` | none (baseline) | n | n / max over the bank of n (0 if all are 0) | none: not scored by log score or Brier |

`tags_self` ranks by the smoothed share so that it uses the same estimator as `beta_grade` and differs only in who
gave the evidence (settled point 14). Ranking by helpful − harmful is a sensitivity analysis. A variant in which
the tagger sees the grade is not run.

---

## Part 1. Units, splits and data exclusions

### 1.1 Unit of analysis

- The unit is the **evaluation probe task**, inside a task stratum (stream, order).
- A cell of data is (task, candidate, repeat).
- All confirmatory inference is **conditional on the twelve models** (the core grid and the extension pairs, Part
  0.2): the question is "these 60 swaps", not "all possible swaps". Statements about other pairs rest only on the
  secondary between-pair SD and prediction interval of each group (Part 5.2), the source-and-target summary and the
  leave-one-model-out check (Part 8).

### 1.2 Splits

- For each stream and each seed 0, 1, 2: one seeded shuffle of the usable tasks, cut into parts that share no task:
  250 write, 500 score, 500 probe, 250 test (1,500 in all).
- The probe tasks are split into 100 calibration and 400 evaluation tasks by a fixed hash of (stream, seed, task id)
  (`Study.calib_eval`). The same split is used by every model, arm and family.
- The three orders reshuffle one task pool, so a task can be an evaluation task in more than one order (with different
  banks). Every interval clusters on task id within a stream (Part 4.1), and the overlap (appearances, distinct tasks,
  share of appearances whose task sits in another order) is reported.
- All models use the same tasks in the same order. Each model writes its own bank from the same 250 write tasks.
- DS-1000 has 1,000 tasks and cannot hold 1,500. If DS-1000 becomes stream 2 (contingency only), its sizes are 150
  write, 300 score, 500 probe (400 evaluation + 100 calibration) and 50 test. The probe table keeps its full size, so
  its power is unchanged. The visits rule is scaled to 60% of the bank, and there is no post-swap run on DS-1000.
- The split files are made and hashed before any paid main-run call.

### 1.3 What each part is used for

| Part | Used for | Never used for |
|---|---|---|
| Write tasks (250) | writing the items, with no memory; their no-memory answers are forecast predictor data (Part 11.3) | scores, evaluation |
| Score tasks (500 × passes) | earning scores; the no-memory run for `credit`, which is also forecast predictor data (Part 11.3) | evaluation |
| Calibration tasks (100) | fresh checks of the arms; agreement for P1 (Part 2.11); forecast predictor data (no-memory runs, Part 11.3); part of the test stream of the swap-day check replay (Part 11.4) | any number computed on evaluation tasks |
| Evaluation tasks (400) | every concordance, success, regret, log score and Brier; in the swap-day check replay, one fixed half gives the truth and the other half joins the test stream (Part 11.4) | fresh checks of the arms of Part 2.6; forecast predictors |
| Test tasks (250) | the post-swap run only | anything before the main probe analysis is frozen |

### 1.4 Data exclusions fixed in advance

1. **BIRD task `bird-0701`.** Its gold query does not finish (measured on 23 Nov 2026: not even in 360 s), so every
   answer would be graded wrong. It is removed from the BIRD stream **before** the splits are drawn. Any other BIRD
   task whose gold query fails, times out (30 s) or returns an empty result is removed the same way. This decision
   uses the gold query alone and is made before any model call.
2. **Answers that hit the token limit** (stop reason "max_tokens" or "length"). Primary: kept and graded as given
   (it is the model's answer). The share per model and stage is reported. Sensitivity: those cells treated as
   missing (1.6).
3. **Refusals** (an API-level refusal or content-filter stop reason, or an answer with no parseable diagnosis or SQL).
   Primary: graded wrong, as the program grader does. The share per model is reported. Sensitivity: API-level
   refusals treated as missing.
4. **API errors** (rate limits, server errors, time-outs, dropped connections). A failed attempt is not an outcome and
   is never graded. The client retries (up to 5 times with back-off), and a stage that is resumed retries again.
   Retries never create extra repeats: the repeat number is fixed by the design and the answer cache is keyed by
   (model, prompt, repeat). A call that returned an answer is final. **No call is ever repeated because its answer
   was wrong or could not be parsed.**
5. **No other task exclusions.** A task found later to be broken (for example a gold label that cannot be parsed) may
   be excluded only by a rule that does not look at model results, logged as a deviation.

### 1.5 BIRD grading

- **Primary:** corrected grading (`faithful=False`). An answer that already starts with `WITH` or with `select` in any
  case is not given an extra `SELECT ` in front.
- **Sensitivity:** StreamBench's original grading (`faithful=True`). Every stored raw answer is graded again; the
  score-phase updates are replayed from the logged episodes with the original grades (the same items shown, as
  logged); and every analysis is repeated. Item selection during the build followed the corrected grades, so the
  replay is not a full counterfactual build. This limit is stated with the result.
- DDXPlus is graded by StreamBench's label parser, unchanged.

### 1.6 Missing cells

- A cell is missing if it has no graded answer after all retries, or under a sensitivity rule in 1.4.
- Within one (owner, reader, stream, order) cell, a task is dropped **for every arm and family** if any of its
  candidate cells has no valid repeat or its no-memory cells have no valid repeat. This keeps every comparison paired.
- If one of two repeats is missing, the mean uses the one that exists.
- Missing cells are assumed to be unrelated to the outcome. Counts are reported per model, stage and stream. If more
  than 2% of tasks in any cell are dropped, an available-case sensitivity analysis is added.

### 1.7 A model retired or changed mid-study

- A model counts as retired when its endpoint stops serving, or its maker announces a retirement date that falls
  before its remaining calls can finish.
- **All its calls done:** nothing changes.
- **Retirement known before the first main-run call:** the fallback pair in the master plan replaces the Anthropic
  pair (Sonnet 4.6 → Sonnet 5.5) if Haiku 4.5 is the one affected; for another model, the manager decides. Either
  way, this file is updated by a dated deviation before the first main-run call.
- **Retirement during the main run:** the retired model and every cell that involves it (as owner or reader) are
  removed from all confirmatory analyses. The 12 primary tests, the per-pair results and P1–P4 are computed
  on the remaining models (a core model retired: 46 swaps, 5 upgrades, 5 downgrades, 36 cross-maker; an extension
  model retired: 58 swaps, 5 upgrades, 5 downgrades, 48 cross-maker). Its partial data are reported as exploratory.
  No replacement model enters the confirmatory set mid-run.
- **Silent change:** the model string returned by each call is logged. If it changes for a model during the study,
  that is a deviation. The primary analysis uses all data; a sensitivity analysis treats the data before and after
  the change as two models.

---

### 1.8 The benchmark release: development and test halves (revision 2)

The released benchmark (`scoreswap`; `docs/BENCHMARK_GUIDE.md`) splits the evaluation tasks into a public development
half and a held-out test half. Rule (`scoreswap/export.py`, `SPLIT_RULE`, `assign_splits`): per stream, the evaluation
task ids are ordered by sha256("devtest|<seed>|<stream>|<task id>") with the study's seed (`evaluate.seed`), and each
is put in the TEST or the DEV half so that every stream order gets about half of its evaluation tasks in each
(stratified by stream and order); a task id is on the same side in every order it appears in, and a task that is a
calibration task in any order is always DEV, because calibration results are public. So no test outcome of any reader
on any swap cell is in the public pack; the one exception, stated in the guide and counted in the manifest, is that a
home row can sometimes be inferred from the owner's public score-phase log of another order.
- **Public pack** (`python -m scoreswap export`): SCHEMA.md; `manifest.json` (settings, models and makers, cells, and
  the sha256 of every file, the private test file included); the licence notes; per bank `items.csv` (scores and
  counts), `showings.csv` (the owner's logged score phase) and `bank.json`; the 4 candidates of every probe task with
  relevance, role and split; every reader's graded results on the calibration tasks and its no-item runs
  (`calibration_results.csv`); the same on the DEV half (`dev_results.csv`); the paper's rules on the DEV half
  (`reference/dev/`). No task or item text (licences); each item has an id and a hash of its text.
- **Private pack** (held by the maintainers, never published): the same results on the TEST half
  (`<pack>_private/test_results.csv`) and the paper's rules on it (`reference/test/`). Its sha256 is in the public
  manifest, a commitment that the held-out half was fixed in advance. It is replaced by fresh results when new model
  pairs are added.
- **Use.** Boards rank entries on the TEST half only (the maintainers score the submitted entry file); a DEV number is
  never a ranking. The held-out check flags an entry whose lead over `keep` on DEV exceeds its lead on TEST by more
  than 3 standard errors and 3 points. **The paper's tables use all evaluation tasks** (DEV and TEST together,
  `--split all`), so the split changes no estimate registered in Parts 2–8.

## Part 2. Estimands

### 2.1 Notation

- Models m = 1..12 (8 in the core grid, 4 in the extension pairs). Streams b. Orders o ∈ {0, 1, 2}. Evaluation tasks
  E(b, o), 400 each. Calibration tasks Q(b, o), 100 each.
- Bank B(s, b, o): owner s's 250 items. Candidates K(τ) = the 4 items of B(s, b, o) most relevant to task τ.
- y(s→t; τ, i, r) ∈ {0, 1}: reader t's result on task τ with owner s's item i shown, repeat r ∈ {1, 2}.
  ȳ(τ, i) = mean over r ∈ {1, 2}. For home cells, repeats 3 and 4 give the extra mean ȳ⁺(τ, i).
- z(t; τ, r): reader t's result on task τ with no item, r ∈ {1, 2}; z̄(τ) is their mean.
- x(i): the owner's ranking score for item i in family f (Part 0.4).
- Every estimand is computed separately for each family f. The primary comparisons use the headline family
  (`ema_grade` unless Part 9.2 replaces it).
- Swap strata (the letters a, b, c are names, not streams): S(a) = the 6 upgrades, S(b) = the 6 downgrades,
  S(c) = the 48 cross-maker swaps; g stands for any one of them. Membership is read from the study configuration
  (Part 0.2).
- Every definition below needs, for a swap s → t, only the swap cell, the owner's home cell and the owner's calibration
  tasks. None needs a full row or column of the grid, so an owner with one reader (an extension model) gets its home
  value, self-swap reference and home-signal flag exactly as an owner with seven.

### 2.2 Concordance Cw and its parts V and W (Cw is secondary; V gives the headline θ of Part 2.4)

For one owner s, one reader t (t may equal s), one stream b and one family f, pooled over the three orders:

```
Cw = Σ_o Σ_{τ ∈ E(b,o)} Σ_{i<j in K(τ)} w(τ,i,j) · κ(τ,i,j)
     ------------------------------------------------------
     Σ_o Σ_{τ ∈ E(b,o)} Σ_{i<j in K(τ)} w(τ,i,j)

w(τ,i,j) = |ȳ(τ,i) − ȳ(τ,j)|                      (reader t's results)
κ(τ,i,j) = 1    if (x(i) − x(j)) · (ȳ(τ,i) − ȳ(τ,j)) > 0
           1/2  if |x(i) − x(j)| ≤ 1e−12            (tie in score)
           0    otherwise
```

- **Weights.** Each pair is weighted by how much the two outcomes differ. With 2 repeats the weight is 0, 0.5 or 1.
- **Ties in outcome.** A pair with equal means has weight 0, so it is left out. It carries no information about the score.
- **Ties in score.** Count one half. The estimand is then "the validity of the score as deployed"; a score that cannot
  separate two items earns what a coin earns.
- Pairs never cross tasks.
- With all weights equal to 1 for informative pairs, Cw is the within-stratum Harrell's C (tasks as strata), which
  equals (within-stratum Somers' D + 1) / 2 (Newson 2002; 2006). The weighted form is the statistics note's
  recommendation because it uses the repeat information (Table 3 there: higher signal-to-noise at R = 2) [sim].
- Per-task form, used by the bootstrap and by Part 11: the signed validity
  V(τ) = Σ_{i<j} sgn(x(i) − x(j)) · (ȳ(τ,i) − ȳ(τ,j)), with sgn = 0 for a score tie, and the outcome spread
  W(τ) = Σ_{i<j} |ȳ(τ,i) − ȳ(τ,j)|. The numerator of Cw is (W(τ) + V(τ)) / 2, so Cw = 1/2 + Σ V(τ) / (2 Σ W(τ)) exactly.
- A task with W(τ) = 0 contributes nothing.

Named values for owner s, stream b, family f:
- C_home(s, b): reader = s, repeats 1 and 2.
- C_swap(s→t, b): reader = t ≠ s, repeats 1 and 2. Same candidates and same scores as at home.
- C_fresh(s, b): reader = s, extra repeats 3 and 4 (the self-swap).

### 2.3 The concordance drop D (secondary) and the self-swap reference

```
D(s→t, b)  = C_home(s, b) − C_swap(s→t, b)       (positive = the old scores rank worse for the reader)
Dself(s, b) = C_home(s, b) − C_fresh(s, b)        (the self-swap drop; expected 0)
```

Swap-group averages (equal weight for every swap in the group and every stream; Part 2.12). For swap group g:

```
C̄_home(g) = mean over swaps (s→t) in S(g) and streams b of C_home(s, b)
C̄_swap(g) = mean over the same swap-stream cells of C_swap(s→t, b)
D̄(g)      = C̄_home(g) − C̄_swap(g)
D̄self(g)  = mean over the same swap-stream cells of Dself(s, b)      (s = the owner of each swap)
```

- In group (a) the owners are the 6 old models; in (b) the 6 new models; in (c) every core model owns 6 of the 48
  swaps, so C̄_home(c) is the plain mean over the 8 core owners.
- The same formulas over all 60 swaps give the all-swap average. It is descriptive only (Part 8).

### 2.4 The headline: the retained ranking signal θ (round-1 revision, 23 Nov 2026)

```
θ = Σ V_swap / Σ V_home          (the same tasks, pairs and scores; V of Part 2.2)
```

- **Meaning.** V sums, over the candidate pairs of every task, the difference of the outcomes signed by the old score
  order. θ is the share of the home ranking signal that the old order still carries for the reader: θ = 1, all of it;
  θ = 0, none (a coin); θ < 0, reversed. It is called the **retained ranking signal** in the paper.
- **Why it is the headline.** V is linear in the outcomes, so outcome noise does not bias it; θ does not move when the
  reader's repeats are noisier. The concordance ratio R below does: on the same tasks R = θ × W̄_home / W̄_swap exactly,
  so a noisier reader lowers R with no change in transfer, and sampling settings that differ between makers would
  enter R (Reviewers 1–3, round 1).
- **Computation (one implementation, `msr.metrics`).** Per task, V = Σ_{i<j} sgn(x(i) − x(j)) (ȳ(τ,i) − ȳ(τ,j)) with a
  score tie (|difference| ≤ 1e−12) at sign 0, over the candidates kept by rule 1.6; with the parts of Cw,
  V = 2 × numerator − W. For one swap and stream: θ = (mean V over the swap cell's valid tasks of the three orders, the
  reader's repeats 1–2) / (the same with the owner's repeats 1–2), on the same tasks. Over both streams and over a
  group of swaps: the ratio of the plain sums of those per-(swap, stream) means (equal weight per swap and stream,
  Part 2.12). `msr.theory`'s R_V (Part 11) is the same number; a test checks that they agree to rounding.
- **Self-swap θ_self:** the home cell with the extra home repeats 3–4 as the "reader"; expected 1. Its numerator,
  V̄_fresh (the owner's own repeats 3–4, a later session, on the swap's tasks and scores), is the self-swap member of the
  drop test (Part 3, PC1).
- **θ is always reported, with a flag (24 Nov 2026; one rule since revision 2).** θ̂ and its two-way Fieller set (Part
  4.2) are always computed and written; an unbounded set is a valid answer and is reported as such. The reporting flag
  reads "defined" when the owner's home ranking signal on its CALIBRATION tasks (which no estimate, test or interval of
  θ uses) is at least 2 standard errors above 0: z = ΣV / (sd(V) √n) over the owner's calibration tasks of every order
  of the streams involved (for a group of swaps, each owner weighted by its number of swaps); otherwise "undefined:
  home signal too weak on the calibration tasks". A flag computed on the same evaluation tasks would select on θ̂'s own
  noise (a draw whose V̄_home came out high by chance passes more often); the former same-task rule (V̄_home ≥ 4 SEs)
  is kept as a secondary column and decides nothing. No test of Part 3 depends on the flag: the tests carry their own
  home-sign member (Part 3).
- **One flag rule (revision 2).** This flag is the only home-signal rule of this file and of the code:
  `msr.metrics.home_signal_flag(v_calibration, weights)` returns (z, status), and every module that labels θ or gates
  on the home signal (analysis, the transfer decomposition, the forecast, the keep-or-drop check, the scorer) calls it.
  Where Part 11 states another reportability rule for θ (11.1 still names the same-task 4-SE rule), the rule of this
  Part governs; Part 11.1 is to be brought into line before the freeze (open point 27).
- **Stakes and order: what θ is made of (revision 2).** Per evaluation task, the item spread of model m is
  S_m(τ) = Σ_{i<j} (μ_m(τ,i) − μ_m(τ,j))², the noise-free second moment of m's within-task differences over the same
  candidate pairs as V. It is estimated by a cross-repeat product of two INDEPENDENT measurements a and b of the same
  cells, Ŝ_m(τ) = Σ_{i<j} (ȳᵃ(τ,i) − ȳᵃ(τ,j)) (ȳᵇ(τ,i) − ȳᵇ(τ,j)) (outcome noise has mean 0 and is independent between a
  and b, so it does not inflate the product): for the owner, a = mean of home repeats 1–2 and b = mean of home repeats
  3–4 (a later session); for the reader, a = repeat 1 and b = repeat 2 of the swap cell (run in a later session than
  repeat 1, Part 0.3); for a home cell read as a self-swap, the reader's a and b are repeats 3 and 4 (repeat 4 in a
  later session than repeat 3) (`msr.metrics.cross_repeat_parts`). Pooling is exactly θ's (per-(swap, stream) means, plain sums over streams and
  over a group). Then
  ```
  stakes = √(Σ S̄_reader / Σ S̄_owner)        order = θ · √(Σ S̄_owner / Σ S̄_reader)        θ = order × stakes (exactly)
  ```
  Stakes asks how much the reader's success depends on which item it is shown, against the owner's; order asks whether
  the old order of the items still fits the reader (under linear transfer it tends to a correlation, the R_std of Part
  11.2.2). Intervals (`msr.metrics.order_stakes_inference`, the variance of Part 4.1): stakes by the Fieller set of
  S̄_reader / S̄_owner, square-rooted (lower end floored at 0); order by the Fieller set of V̄_swap / (V̄_home × stakes)
  with the denominator linearised. When Ŝ_reader ≤ 0 the order has no point and its set is the whole line.
- **When the order is identifiable (revision 2).** The order is labelled "not identifiable: the reader's item spread
  cannot be told from zero" unless the reader's spread on the swap cell's CALIBRATION tasks (repeat 1 × repeat 2,
  pooled over the group's swap-stream members as the flag pools owners) is at least 2 standard errors above 0
  (`msr.metrics.ORDER_MIN_Z` = 2) and both spreads are positive on the evaluation tasks. Like θ's flag it only labels:
  the point and the set are always written, and stakes and θ are reported either way. Measured ([sim],
  `docs/power/order_stakes.md`, 1,000–4,000 replications per row): when the reader ignores the item the rule calls the
  order identifiable in 2.1–2.7% of replications (nominal 2.3%); the same z on the evaluation tasks would select on
  the estimate's noise (reviewer's world, one pair: median order 0.344 among passing replications against a truth of
  0.577; the calibration rule gives 0.580). Medians of θ, order and stakes sit within 0.011 of the truth in our worlds;
  coverage of the 95% sets 0.939–0.968 (θ), 0.941–0.972 (order), 0.943–0.971 (stakes); in the reviewer's worlds
  0.966–0.997 (order) and 0.950–0.981 (stakes). θ's set, with the registered jackknife and identity codes, covered
  0.950–0.978 in all nine of the reviewer's worlds, including two where items carry 73–90% of the variance, and
  0.940–0.970 in ours (`docs/power/coverage_items_t.md`). The earlier 0.902–0.946 was the round-1 variance's.
- **Caching.** A reader repeat that copies the previous answer inflates Ŝ_reader (stakes × 1.32 and order × 0.76 at a
  copy rate of 0.1; × 1.80 and × 0.56 at 0.3) and leaves θ unbiased; a cached home repeat inflates Ŝ_owner and
  deflates stakes the same way. This is why repeat 2 of every cell, home cells included, runs in a later session
  (Part 0.3). The within-session against across-session products of the home cells and the rate of
  identical responses between repeats are reported per model.
- **What counts as a later session (revision 2; enforced and logged by the pipeline).** It applies to repeat 2 of every
  probe cell, home cells included, and to the home cells' extra repeats (3–4 after 1–2, and 4 after 3). A repeat is in
  a later session than the earlier repeat of the same cell only if all of these hold, call by call: (a) **gap**: its first call starts at least
  6 hours after the last call of repeat 1 of that cell (`probe.repeat_gap_hours`, default 6; longer than the default lifetime of the prompt and response caches of the providers used, minutes to one hour; opt-in extended caches stay off, item c); (b) **new connection**: it runs in a new process with a new HTTP client and session (no reused
  keep-alive connection, no reused conversation or thread id); (c) **no provider cache**: every provider cache that the
  API lets the caller turn off is off (no prompt-cache or response-cache flag set, cache-control headers asking for no
  stored response where the provider honours them); where a provider caches automatically and offers no switch, this
  is logged and the checks below decide; (d) **no local cache**: the local call cache key includes the repeat index, so
  a repeat is always a fresh call; (e) **same question**: the prompt text and sampling settings equal repeat 1's, and
  only the logged repeat index differs. Logged per call: session id, process id, start and end time, and the
  provider's cache-hit field where the response carries one. A repeat that fails (a)–(d) is not a later session: its
  cell is flagged and the fallback of Part 0.3 (a later-session repeat on 100 evaluation tasks per order, and the two
  checks) applies to the model that answered it.
- **Secondary ratio R (concordance).** R = (C_swap − 0.5) / (C_home − 0.5), at the same three levels, reported only if
  (C_home − 0.5) ≥ 4 × SE(C_home) (task-only bootstrap SD at the same pooling), with the percentile interval, or
  "unbounded" if more than 0.5% of draws have a denominator ≤ 0. R is reported beside θ with the spread ratio
  W̄_home / W̄_swap, so a reader sees how much of R is outcome noise. D (Part 2.3) and R_adj (Part 2.5) are secondary too.

### 2.5 Split-half noise reference

For any cell with repeats split into two halves A and B, with the same candidates:

```
C_SH = ½ [ Cw(score = ȳ_A, outcome = ȳ_B) + Cw(score = ȳ_B, outcome = ȳ_A) ]
```

- In every cell: A = repeat 1, B = repeat 2 (one repeat each). This version exists for home and swap cells alike.
- In home cells, a second version: A = repeats 1–2, B = repeats 3–4.
- Score ties are counted one half, as in 2.2.
- **Meaning.** C_SH is the concordance that a score as reliable as one fresh measurement of the same cell would reach.
  It is a noise reference, **not an upper bound**: a score built from many visits can exceed it.
- Noise-normalised concordance (C − 0.5) / (C_SH − 0.5) is a secondary measure only (Part 8). No primary statistic is
  ever normalised by the noise reference.
- **Noise-adjusted retained validity R_adj** (secondary; settled 23 Nov 2026). For a swap s→t in stream b:
  R_adj = [(C_swap − 0.5) / (ref_t − 0.5)] / [(C_home − 0.5) / (ref_s − 0.5)], where ref_m is model m's split-half
  noise reference on its own home cells with A = repeats 1–2 and B = repeats 3–4. For a group of swaps (a stratum, or
  both streams), the bracketed numerator and denominator are each averaged over the group's swap-stream cells before
  dividing. R_adj is reported only where R is reported and every noise reference it uses is at least 4 bootstrap SEs
  above 0.5. Its interval is the bootstrap percentile interval, reported as unbounded if more than 0.5% of draws have a
  denominator ≤ 0. It allows for both models' noise. It is never a test statistic.

### 2.6 Arms (swap-day rules)

Every arm gives, for every item of the owner's bank, a normalised score u (for the mix) and, where the family has
one, a predicted success p (for log score and Brier). All p are clipped to [0.01, 0.99]. A fresh check is always the
program's grade of the reader's answer, for every family, `tags_self` included: no tag is asked on swap day. Where an
arm adds checks to a count family, a success counts as a success (for `tags_self`, as "helpful") and a failure as a
failure ("harmful").
Arms with k checks draw them as follows, separately for each (owner, reader, stream, order) and each of 200 draws d (amended 23 Nov 2026, before any paid run):
take the pool of all (calibration task, candidate) cells of the reader; pick k distinct cells uniformly without
replacement; use one of the two repeats, chosen uniformly. The random generator is seeded by
(`evaluate.seed`, a hash of stream | order | owner | reader | arm | k, d), so every family sees the same checks.
The arm's value on a task is the mean over the 200 draws (Part 4.5) (amended 23 Nov 2026, before any paid run).
k takes the values 8, 16, 32, 64, 128 and 256 (`recal_k`, `powerprior_k`, `retest_k`, `audit_k`, `pooled_k`, `fresh_k`); k = 64 stays the registered value for the primary comparison PC4 (amended 24 Nov 2026, before any paid run).

| Arm | Scores used with the reader | Predicted success p |
|---|---|---|
| `none` | no item shown | not applicable |
| `relevance` | scores ignored; rank by relevance | not applicable |
| `keep` | the owner's scores, unchanged | family p (Part 0.4) |
| `wipe` | every item at the start value (q = 0.5, counts 0, c = 0, n = 0); ranking falls back to relevance | 0.5 (`credit`: r0) |
| `constant` | as `wipe` (ranking by relevance) | the reader's no-memory success on the calibration tasks, for every item: the constant-prediction reference of the log-score comparisons (round-1 revision, S4) |
| `fixed_λ` | old evidence at weight λ: q′ = 0.5 + λ(q − 0.5); counts s, f, h, g multiplied by λ; c′ = λc | family p of the discounted values |
| `shuffled` | the owner's scores permuted at random across the 250 items (content-only control); 200 permutations (amended 23 Nov 2026, before any paid run) | family p of the permuted values |
| `powerprior_k` | base prior Beta(a0, b0) fitted to the owner's bank by beta-binomial maximum likelihood over items with n ≥ 1 (pseudo-counts q·n and (1 − q)·n for `ema_grade`); weight λ̂ = the grid value that maximises the beta-binomial marginal likelihood of the k checks (ties to the smaller λ); never a flat Beta(1,1) base. Not defined for `credit` and `visits` (no Beta pseudo-counts): those families skip this arm | (a0 + λ̂ s) / (a0 + b0 + λ̂ n) |
| `recal_k` | logistic recalibration, the primary calibrated arm: p = σ(a + b·x′), with x′ the family score standardised over the owner's bank (z-score of q for `ema_grade`; logit of the fitted-prior posterior mean minus its bank mean for `beta_grade` and `tags_self`; z-score of c for `credit`; a z-score is centred on the bank mean and divided by the population SD over the bank's items with at least one score-phase visit); (a, b) by penalised maximum likelihood on the k checks with priors a ~ N(0, 1), b ~ N(0.5, 1). a is the level shift. b̂ = 0 means the old order carries no information. Because x′ is standardised, b̂ is read against b̂_home, the slope fitted the same way in the owner's home cell: b̂ near b̂_home means the old order predicts the reader as well as it predicts the owner. Not defined for `visits` | σ(â + b̂·x′) |
| `retest_k` | the k items with the highest old score among items that appear on a calibration task get one check each; each is re-scored from the start value with that check; all other items at the start value | family p of the re-scored values |
| `audit_k` | k/4 calibration tasks drawn, all 4 candidates checked once; if Cw of the old scores on these checks > 0.5, use `keep`, otherwise `wipe`; no informative pair → `keep` | that of the chosen arm |
| `pooled_k` | the k checks added to the old scores at full weight with the family's own update | family p |
| `fresh_k` | every item at the start value, then the k checks added with the family's own update | family p |
| `own` | the reader's own bank, candidates and scores, measured on the reader's home cells | family p |
| `split_half` | per task, the candidate with the best reader result on one repeat, scored on the other repeat; both ways, averaged; ties to the more relevant item. A one-repeat reference, NOT an upper bound: it picks on one noisy repeat, so a rule ranking by scores built from many visits can beat it. Called `oracle` before the round-1 revision (S5); not in headline tables | not applicable |
| `ceiling` | per task, the candidate with the best mean of the reader's two repeats, scored on the same repeats: the in-sample ceiling for any rule that shows one of the four candidates (biased upward; round-1 revision, S5) | not applicable |

For `visits`, arms that need a probability are not scored by log score or Brier.

### 2.7 First-shown success and regret (decision quality)

For arm a, family f, swap s→t, task τ:

```
m(i)   = 0.5 · u_a(i) + 0.5 · relevance(τ, i)          for i in K(τ)
i*_a   = argmax m(i); ties to higher relevance, then to the candidate listed first
FS_a(τ) = ȳ(τ, i*_a)                                    (reader t's mean over repeats 1–2)
Reg_a(τ) = max_{i in K(τ)} ȳ(τ, i) − FS_a(τ)
FS_a(s→t, b) = mean over the 1,200 evaluation tasks of the stream (three orders) of FS_a(τ)
```

- For `none`: FS(τ) = z̄(τ). For `own`: the reader's own candidates and home results.
- Regret against the observed best is biased upward (it takes the maximum of noisy means); the observed best is the
  `ceiling` arm (FS_ceiling(τ) = max_i ȳ(τ, i)). Regret against `split_half` is reported beside it.
- Wipe ties every score, so FS_wipe = FS_relevance. "Keep minus wipe" therefore measures what the old scores add
  beyond relevance.
- The mix uses raw relevance and scores in [0, 1], as the build does.

### 2.8 Held-out log score and Brier score

For arm a, family f (not `visits`), swap s→t, task τ:

```
ℓ_a(τ) = 1 / (|K(τ)| · 2) · Σ_{i in K(τ)} Σ_{r=1,2} [ y log p_a(i) + (1 − y) log(1 − p_a(i)) ]
β_a(τ) = 1 / (|K(τ)| · 2) · Σ_{i in K(τ)} Σ_{r=1,2} ( y − p_a(i) )²
LS_a(s→t, b) = mean over evaluation tasks of ℓ_a(τ)        (higher is better; at most 0)
BS_a(s→t, b) = mean over evaluation tasks of β_a(τ)        (lower is better)
```

- "Held out" means by task: no evaluation task ever supplies a fresh check. An item that is a candidate on both a
  calibration and an evaluation task may carry its check into its evaluation appearances; that is the rule working
  as intended.
- How each family becomes a probability: Part 0.4 and the arm table above. All p are clipped to [0.01, 0.99].
- For arms with k checks, ℓ and β are averaged over the 200 draws (amended 23 Nov 2026, before any paid run).
- **Level correction (round-1 revision, S4).** A moving-average score is not a calibrated probability, so a plain log
  score mostly measures each arm's level. Every arm (including `keep`, `wipe`, the discounts and `recal_k`) therefore
  gets the same correction, available to every rule without an item check: one constant δ on the logit scale,
  p* = σ(logit p + δ), with δ chosen so that the mean of p* (clipped as above) over the (calibration task, candidate)
  cells equals the reader's no-memory success on the calibration tasks (`msr.metrics.level_shift`; one δ per cell and
  draw). The level-corrected scores ℓ* and β* are the primary log-score endpoints (PC3, PC4); the uncorrected ℓ and β
  are reported beside them. The target is the level of "no item"; the reader's success with an item shown differs from
  it (memory helps, gate 1), so the corrected scores share a common level error, which is common to every arm and
  cancels in the arm differences to first order.
- **Base-rate sensitivity (revision 2; R6 W7).** The same correction with the target set to the reader's mean success
  WITH an item shown on the same (calibration task, candidate) cells (both repeats; what `recal_k` sees anyway):
  scores ℓ** and β** (keys `log_lcw`, `brier_lcw`). Every secondary log-score contrast (PC3, PC4) is reported under
  both targets (Part 3).
- **Swap minus home.** Every comparison of two arms on prediction quality is also computed at the owner's home cell
  (the owner reading its own bank, repeats 1–2) and reported as [a − b after the swap] − [a − b at home] (PC3, PC4,
  Part 8.2.6), always with the same contrast in first-shown success points beside it.

### 2.9 Top-1 and top-2 agreement

Reported apart from concordance. For swap s→t, family f, on evaluation tasks with at least one informative pair:
- Let Best(τ) = the candidates with the highest ȳ for the reader. Rank candidates by the owner's score x alone (ties to
  higher relevance).
- **Top-1 agreement A1** = share of tasks where the owner's top candidate is in Best(τ). Its chance value per task is
  |Best(τ)| / |K(τ)|.
- **Top-2 agreement A2** = share of tasks where the owner's top two contain a member of Best(τ). Chance value per task:
  1 − C(|K| − |Best|, 2) / C(|K|, 2).
- Both are reported raw, with their chance value, and at home for reference.

### 2.10 The post-swap run (online, on test tasks)

- **Swaps (12):** the 8 same-maker swaps of the core grid and 4 cross-maker swaps (the extension pairs are not in the
  post-swap run, so the study file lists these 12 swaps explicitly). The cross-maker swaps take each maker's old model
  to the next maker's new model in the fixed order Anthropic → OpenAI → Qwen → Gemma → Anthropic:
  `haiku-4.5 → gpt-6-luna`, `gpt-5.6-luna → qwen3.8-27b`, `qwen3.5-27b → gemma-4-31b`, `gemma-3-27b → haiku-5.5`.
- **Streams and orders:** both streams, three orders, 250 test tasks each, in the order's sequence (DDXPlus only if
  DS-1000 is stream 2).
- **Arms:** `none`, `relevance`, `keep`, `wipe`, `fixed_0.5`, `recal_64` (fresh-check draw d = 0), `own`, and
  (revision 2, registered secondary, Part 8.2.22) `reexplore_25` and `reexplore_50` (`online.arms` in the study file).
  Headline family.
- **Procedure:** the bank content stays frozen. For each test task: take the 4 most relevant items, show the top one
  by the mix (exploration 0; the `reexplore_m` arms explore, see below), grade it, and update the shown item by the
  headline family's own update rule (for
  `ema_grade`, q ← q + 0.3(y − q); for `tags_self`, the reader tags the item without seeing the grade; for `credit`,
  each test task is also answered once with no memory). One repeat.
- **Starting values:** each arm starts from its own record in the family's state and keeps learning from there.
  `keep`: the owner's record. `wipe`: the start record. `fixed_0.5`: the discounted record. `own`: the reader's own
  bank. `recal_64` gives a probability p̂. For `ema_grade` the start is q = p̂. For a count family (`beta_grade`,
  `tags_self`) it is p̂(n + 2) − 1 successes (helpful) and (1 − p̂)(n + 2) − 1 failures (harmful), with n the item's old
  visit count, so that the smoothed mean (1 + successes) / (2 + n) is exactly p̂; the counts may be fractional or
  negative, and the Beta parameters 1 + count stay positive. For `credit` it is c = p̂ − r0. If the headline family is
  not `ema_grade`, the run ranks and learns with that family's own update rule (settled points 13 and 22). `none`
  shows nothing; `relevance` does not learn. `reexplore_m` (m = 25, 50) starts from the owner's record and learns
  exactly as `keep`, but for the first m test tasks of each order the pick explores with chance
  `online.reexplore_epsilon` = 0.3 (a uniform draw among the 4 candidates), then exploration 0 (`msr/online.py`).
- **Metrics per arm and swap:**
  - S_all = mean success over all 250 × 3 test tasks.
  - S_100 = mean success over the first 100 test tasks of each order.
  - n95 = the first position n ≥ 50 at which the trailing 50-task success, averaged over the three orders, reaches
    0.95 × S_all(`own`). If it is never reached, n95 is reported as "not reached by 250".
- **Cost per arm:** calls, tokens and dollars, including the k reader calls a k-check arm would need on a real swap day.

### 2.11 Quantities used by the predictions

- **Agreement κ(s→t, b)** (for P1): Cohen's kappa between the owner's home results and the reader's results on the same
  (task, candidate) cells, over the **calibration** tasks of the three orders (so it shares no outcome with the
  evaluation tasks behind R). Every repeat of the owner is compared with every repeat of the reader on the same cell:
  p_obs = share that agree; p_exp = p_s·p_t + (1 − p_s)(1 − p_t), with p_s and p_t the two success rates over these
  cells; κ = (p_obs − p_exp) / (1 − p_exp). Averaged over the two streams.
- **No-memory success X(t, b)** (for P2): mean of z̄(τ) for reader t over the 1,200 evaluation tasks of stream b.
- **Keep–wipe gap G(s→t, b)** (for P2): FS_keep − FS_wipe, headline family (Part 2.7).

### 2.12 Pooling

- Within a stream, tasks of the three orders are pooled with equal weight per task (for Cw, through the pair weights).
- Within a swap group, every swap and every stream gets equal weight: the group value is the plain mean of the
  per-swap, per-stream values (a core and an extension swap weigh the same). For the ratio θ the numerator and the denominator are each such a mean (the ratio of
  the group-averaged mean V per task), never a mean of per-swap ratios. The pair-count-weighted value is a secondary
  analysis.
- Confirmatory tests never pool across swap groups. The all-60 average is descriptive.
- If neither BIRD nor DS-1000 qualifies (Part 9.2), every average uses DDXPlus alone and the MemRL-code leg is run;
  this is logged as a deviation.

---

## Part 3. The primary hypotheses (revision 2, 24 Nov 2026)

All use the headline family (`ema_grade` unless Part 9.2 replaces it) and both streams. Each is tested separately in
each swap group: (a) the 6 same-maker upgrades, (b) the 6 same-maker downgrades, (c) the 48 cross-maker swaps. The
statistic in group g pools its swaps and the two streams with equal weight (Part 2.12); its variance is the two-way
jackknife of Part 4.1. That gives **4 hypotheses × 3 groups = 12 primary tests in one Holm family** (Part 5.1): three
members for PC1 (drop, material drop, no material drop) and one for PC2. PC3 and PC4, the prediction quality of the
discount arms, are **secondary since revision 2**: they are reported beside every primary result with unadjusted
intervals and support no confirmatory claim (below; Part 5.5). There is no confirmatory test over all 60 swaps
together. Per-pair results and the spread of each group are in Part 5.2. Below, every statistic is computed within one
group g; the "(g)" is left out.

| | Question | Endpoint | Hypotheses (one test each) |
|---|---|---|---|
| H (inside every PC1 member; not a member of its own) | Does the old order carry a ranking signal at home? | Σ V̄_home | H1: Σ V̄_home > 0 (one-sided) |
| PC1-drop | Do the old scores rank items worse for a different model? | retained ranking signal θ | H1: Σ V̄_home > 0 **and** θ < 1 **and** Σ V̄_swap < Σ V̄_fresh (intersection-union) |
| PC1-MD | Is there a material drop? | θ | H1: Σ V̄_home > 0 **and** θ < 0.75 (intersection-union) |
| PC1-NI | Is there no material drop? | θ | H1: Σ V̄_home > 0 **and** θ > 0.75 (intersection-union, non-inferiority) |
| PC2 | Are the old scores worth keeping rather than wiping? | first-shown success after the swap | keep − wipe; H0: 0; two-sided |
| PC3 (secondary) | Does a blind fixed discount (λ = 0.5) predict the reader better than keep, beyond what it does at home? | level-corrected held-out log score, swap minus home | [fixed_0.5 − keep] after the swap − [fixed_0.5 − keep] at home; H0: 0; two-sided |
| PC4 (secondary) | Does a calibrated discount with 64 fresh checks predict better than both keep and wipe, beyond home? | the same | [recal_64 − keep] and [recal_64 − wipe], each swap minus home; H0: either ≤ 0; H1: both > 0 (intersection-union) |

No hypothesis judges a single global discount by concordance or by θ: a global discount barely changes the order of
items ([sim] Table 9: λ = 0.5 reorders 1.6% of within-task pairs), so discount arms are judged by log score (PC3, PC4,
secondary), with decision quality beside them, and in Part 8.

### PC1. The retained ranking signal: three intersection-union tests

- **Statistic:** θ = Σ V̄_swap / Σ V̄_home over the group's swap-stream cells (Part 2.4), reported with its order and
  stakes (θ = order × stakes, Part 2.4).
- **The home member H.** p_H = the one-sided p (evidence that Σ V̄_home > 0) from the two-way SE of Σ V̄_home.
- **The contrasts** (linear in the V̄'s; no ratio enters a test), each with its two-way SE and one-sided p:
  - drop: Σ V̄_home − Σ V̄_swap > 0, and the self-swap reference Σ V̄_fresh − Σ V̄_swap > 0 (V̄_fresh: the owner's own
    later-session repeats 3–4 on the same tasks and scores, Part 2.4; the swap must lose more than a second home
    session of the owner shows);
  - material drop: 0.75 Σ V̄_home − Σ V̄_swap > 0;
  - no material drop: Σ V̄_swap − 0.75 Σ V̄_home > 0.
- **The members' p-values (intersection-union, Berger 1982):** p_drop = max(p_H, p_drop-contrast, p_self);
  p_MD = max(p_H, p_MD-contrast); p_NI = max(p_H, p_NI-contrast) (`msr.metrics.theta_tests`). Each is a level-α test of
  its intersection alternative at every point of its null, including Σ V̄_home ≤ 0, with no adjustment.
- **Why the home member (R6 W2).** The contrasts read θ only when the home signal is positive: with Σ V̄_home ≤ 0 a
  contrast such as Σ V̄_swap − 0.75 Σ V̄_home > 0 can hold for any reader. In simulated worlds with V_home ≤ 0 the
  contrasts alone rejected in up to 0.725 of replications; every intersection-union member rejected in at most 0.043
  (our worlds) and 0.010 (the reviewer's) (`docs/power/variance_items.md`, "sign condition"). A non-positive home
  signal therefore never yields "drop" or "no material drop".
- **No gate.** Every member is always computed and always enters the family, per group and per pair; the flag of Part
  2.4 is reported beside it and decides nothing.
- **Decision words** (`msr.metrics.pc1_label`; each member at its own Holm threshold; every word is a function of
  rejections only, revision 2):
  - **material drop shown:** PC1-MD rejected (θ < 0.75 implies θ < 1);
  - **small drop shown:** PC1-drop and PC1-NI both rejected (θ between 0.75 and 1);
  - **drop shown:** PC1-drop rejected, neither PC1-MD nor PC1-NI;
  - **no material drop shown:** PC1-NI rejected, PC1-drop not;
  - **inconclusive:** none rejected. A failed drop test is never reported as "no drop".

  The words cannot contradict each other: PC1-MD and PC1-NI test one statistic with opposite signs (their z's are
  equal and opposite), so they never both reject at any level below 0.5; no word reads θ̂ or an interval end against
  0.75. (Before revision 2 "material drop" read θ̂ ≤ 0.75 from the point estimate and the self-swap reference was an
  extra condition outside the test; both are withdrawn.)
- **Reported beside it:** θ̂ with its two-way Fieller set and its task-only bootstrap interval; order and stakes with
  their sets and the order's identifiability (Part 2.4); θ_self and loss_self = 1 − θ_self with its interval
  (descriptive); Σ V̄_home, Σ V̄_swap, Σ V̄_fresh; p_H and each contrast's p; for each member its item share,
  effective item clusters and Satterthwaite df with the concern marks of Part 4.1; the secondary concordance
  quantities C̄_home, C̄_swap, D̄ (in concordance points), R̄ and R_adj (Parts 2.3–2.5); and the spread of the group's
  pairs with its between-pair SD and the prediction interval for a new pair (Part 5.2).

### PC2. Keep versus wipe on first-shown success

- **Statistic:** Δ2 = mean over the group's swaps and the streams of [FS_keep − FS_wipe] after the swap (Part 2.7).
- H0: Δ2 = 0. H1: Δ2 ≠ 0. Two-sided, two-way jackknife standard error.
- **Decision:** "keep beats wipe" if Holm rejects and Δ2 > 0; "wipe beats keep" if Holm rejects and Δ2 < 0; otherwise
  "no difference detected" (never "the same"). No size word is attached (revision 2: no label without a test); the
  estimate and its interval are printed in success points beside the 5-point mark of Part 6.2.
- Beside it: the same contrast at home (the owners on their own banks), in success points; item share, effective
  item clusters and Satterthwaite df; the group's between-pair SD and prediction interval (Part 5.2).

### PC3 (secondary). Fixed discount (λ = 0.5) versus keep, swap minus home, level-corrected log score

- **Statistic:** Δ3 = mean over the group's swaps and streams of {[LS*_fixed_0.5 − LS*_keep] after the swap −
  [LS*_fixed_0.5 − LS*_keep] at the owner's home cell}, with LS* the level-corrected held-out log score (Part 2.8).
  Positive: the discount gains more over keep after the swap than at home.
- Why swap minus home: a moving-average score is not a calibrated probability even at home (in the dry run a constant
  0.5 beat keep at home and after every swap), so a plain "fixed − keep" after the swap measures that miscalibration,
  not the swap. The level correction removes each arm's own level; the home term removes what the arm gains anyway.
- **Estimand and its assumption (revision 2; R6 W7).** Δ3 is the change from home to swap in the log-score gain of
  fixed_0.5 over keep. It measures an effect of the swap only if that gain is additive: gain after the swap = gain at
  home + swap effect, with the same home part for owner and reader. Additivity fails when the benefit of shrinking
  depends on the base rate: with perfect transfer (the reader's success chances are the owner's shifted by d logits)
  and no swap effect, the expected contrast is −0.013 to +0.012 nats per check as d and the memory effect vary (R6,
  check C8), the size of the minimum detectable effect of Part 6.3. The level target (the reader's no-memory success)
  also differs from the reader's with-item success by the average memory effect.
- **Reported beside every PC3 and PC4 value, per group and per pair:** the owner–reader base-rate gap X(s) − X(t)
  (no-memory success on the evaluation tasks, Part 2.11; mean over the group's swaps and streams), and the base-rate
  sensitivity: the same contrast with the level target set to the reader's with-item success (ℓ**, Part 2.8). Both
  targets are printed side by side; neither is chosen after seeing them.
- Two-sided test with the two-way jackknife SE; unadjusted p and 95% interval. **Words (secondary):** "the fixed
  discount gains more over keep after the swap than at home" or the reverse when the unadjusted p ≤ 0.05; otherwise
  "no difference detected". No practical-size threshold for log score (settled point 18). No confirmatory claim.
- **Reported beside it, always:** the after-swap and home terms separately; the same swap-minus-home contrast in
  first-shown success (success points); the uncorrected log score and the Brier score; and, for the swaps of the run
  after the swap, S_all and S_100 (Part 2.10), so the stakes are visible in success points.

### PC4 (secondary). Calibrated discount (recal_64) versus both keep and wipe, swap minus home

- **Statistics:** Δ4a = the swap-minus-home contrast of [LS*_recal_64 − LS*_keep]; Δ4b = the same for
  [LS*_recal_64 − LS*_wipe] (Part 2.8; LS*_wipe equals the `constant` reference after the level correction).
- H0: Δ4a ≤ 0 or Δ4b ≤ 0. H1: Δ4a > 0 and Δ4b > 0. Intersection-union: each part one-sided with its two-way standard
  error; p = max(p4a, p4b). Beating "the better of keep and wipe" is tested as beating both, so no arm is chosen on
  the data. The estimand, its additivity assumption, the base-rate gap and the base-rate sensitivity are those of PC3.
- **Words (secondary):** "the calibrated discount beats both keep and wipe beyond its home advantage (unadjusted)" when
  p ≤ 0.05; otherwise "not supported". No confirmatory claim.
- Fresh checks come only from calibration tasks (Part 2.6). Reported beside it as for PC3 (success points, the terms,
  the raw scores, the run after the swap). Equal-budget comparisons and the curve over k = 8, 16, 32, 64 are secondary.

### What is at stake (always reported with the primary tests; decision S7)

For each group, in first-shown success points with two-way 95% intervals: keep − wipe (what the old order adds beyond
relevance), keep − shuffled (what the old order adds beyond content), ceiling − keep (what a perfect pick among the four
candidates would add; in-sample, so biased upward) and keep − none, each at home (the owners on their own banks) and
after the swap, and after minus home (`stakes.csv`). (This table is in success points; the "stakes" of Part 2.4 is
the ratio of item spreads, a different quantity.)

---

## Part 4. Tests and intervals

### 4.1 Variance: tasks and items both sampled (round-1 revision; estimator replaced in revision 2)

- **Two clusterings of dependence.** (i) The three stream orders reshuffle ONE task pool per stream, so a task can be an
  evaluation task in more than one order (with different banks). Tasks are therefore clustered by **task id within a
  stream, pooled over the orders**; the overlap (appearances, distinct tasks, share of appearances whose task sits in
  another order) is reported with every result. (ii) One item is a candidate on many tasks, and its score error and its
  usefulness for the reader are fixed across them. Items are clustered **by identity within (owner, stream)**: the same
  written item met in two orders is ONE cluster (code owner | stream | item id; revision 2). Before revision 2 items
  were coded per bank and order, which split a recurring item into several clusters and dropped the covariance
  between orders through it.
- **Primary (revision 2): the two-way delete-one-cluster jackknife.** Every registered statistic is a linear statistic of
  component means, L = Σ_c coef_c · mean_c(v), where a component is one (key, cell, stream) mean pooled over the three
  orders (θ's swap part, home part and self-swap part, and the two item spreads, are separate components); a ratio is
  never tested directly. Each row's influence is ψ = coef_c (v − mean_c) / n_c. Two rows are dependent when they share a
  task id **or** at least one candidate item (a task's value depends on all four of its candidates: multiple
  membership, Aronow, Samii and Assenova 2015). The variance is V = J_task + J_item − J_both (the two-way
  inclusion–exclusion of Cameron, Gelbach and Miller 2011), where J_d is the delete-one-cluster jackknife over the
  clusters of dimension d (both = (task, item) cells): deleting a cluster recomputes every component mean without its
  rows, which for a linear statistic is the exact factor n_c / (n_c − k) on that cluster's sum of ψ in the component
  (k its rows there); with D_g the centred change of L when cluster g is deleted, J = (G − 1)/G · Σ_g D_g D_gᵀ (CV3 in
  each dimension; MacKinnon, Nielsen and Webb 2023). Deleting item i deletes every row that lists i. Non-negativity:
  for one contrast V = max(J_task + J_item − J_both, J_task); for several columns the positive part of J_item − J_both
  is added to J_task. Normal reference. Code: `msr.metrics.robust_variance` and `contrast_variance`; every primary test
  and interval uses it (`msr.metrics.theta_tests`, `msr.analysis.TwoWay`).
- **Why this estimator ([sim], `docs/power/variance_items.md`, 400–600 replications per world in the reviewer's
  simulator `paper/reviews/round2/r6_checks/r6_dgp.py`, 5,000 per boundary cell in ours).** The round-1 estimator
  (linearised two-way, items per bank and order) under-stated the variance when a few items carry it: in the
  reviewer's world with items shared across orders and an item-dominated outcome (bank 40) its null z had SD up to
  1.27, and its one-sided 0.05 tests rejected in up to 0.107. Two defects add up: the per-order codes hide the
  covariance through a recurring item, and centring on component means removes part of the item variance when the
  dependence is dense (the jackknife's leverage factor restores it by construction). With the jackknife and identity
  codes the null z had SD 0.93–0.94 and the size was 0.033–0.047 in those worlds; the worst cell in all of the
  reviewer's worlds was 0.063 (world E, whose z had SD 1.009, within Monte-Carlo error of 0.05 at 600 replications;
  with 2,000 replications world E gives 0.045 and the worst cell of all nine worlds is 0.052).
  In our worlds the boundary size was 0.0428–0.0525 (mean 0.0476) over 21 world × group cells, against 0.0446–0.0554
  before. Power: 0 to +2.7 points against the round-1 test with its factor; PC2's SE unchanged.
- **Small-sample factor withdrawn (revision 2).** The fixed factor 1.03 on every two-way SE (registered 24 Nov 2026 after
  `docs/power/size_theta_boundary.md` measured an unscaled worst size of 0.0546 with the round-1 estimator) is set to 1
  (`msr.metrics.TWOWAY_SE_FACTOR` = 1): the jackknife's leverage term does that job for a stated reason, and keeping both
  would stack two corrections (mean size 0.043, up to 2.7 points of power lost).
- **Diagnostics printed beside every primary test (revision 2):** the item share of its variance, 1 − J_task / V; the
  effective number of item clusters, min(G_items, 3 (Σ_i D_i²)² / Σ_i D_i⁴) over the item-deletion deviations (about the
  number of items when they carry the variance evenly, a handful when a few do); and the Satterthwaite degrees of
  freedom of the whole variance, V² / (J_task² / eff_tasks + (V − J_task)² / eff_items). Tested range: item share up to
  0.90 with at least 96 effective item clusters (`docs/power/coverage_items_t.md`, 2,000 replications per world: worst
  size 0.052 at nominal 0.05, θ coverage 0.950–0.978 in the reviewer's worlds; 0.940–0.970 in ours).
- **Reference distribution (revision 2 follow-up): normal, and a t reference was tried and not adopted.** A t with df =
  min(effective items, effective tasks) − 1 or the Satterthwaite df of the contrast, in the tests and in the Fieller sets,
  moved no size and no coverage by more than 0.004 in any world tried (effective items 96–4,200, df 71–3,700), and
  cost no power at the planning values (drop at θ = 0.85: 0.743 at 0.05/12 either way). The normal reference stays; the
  concern marks below keep the t(df) p beside it where df < 100. **Concern marks, fixed now:** df < 100 (outside the tested range):
  the t(df) p-value is printed beside the normal one, and a claim that passes only with the normal p is reported as
  "not robust to the reference distribution"; item share ≥ 0.5: items carry most of the variance, and the report says
  so beside the claim. Neither mark changes a decision.
- **Coverage history (round-1, `docs/power/coverage_twoway.py`, [sim]).** In a world with a shared task pool and items
  recurring about 6 times per order, the 95% interval of θ covered 0.905–0.938 (one swap) and 0.919–0.937 (groups) with
  the former task bootstrap within (stream, order); 0.908–0.940 with a task-id cluster bootstrap; 0.939–0.955 with the
  two-way variance; and 0.999–1.000 with Owen's pigeonhole bootstrap, whose intervals were 2.2–2.7 times too wide (it
  counts the outcome noise once through tasks and again through items). These are design aids, not guarantees.
- **The estimand is therefore not conditional on these particular banks:** both the tasks and the items are treated as
  drawn from their populations. It IS conditional on the twelve models (Part 1.1): dependence through a shared model
  is not in any interval.
- **Secondary: the task-only interval.** A cluster bootstrap that resamples **task ids per stream, pooled over the
  orders** (one draw carries every appearance of a task; `msr.metrics.task_cluster_counts`), 10,000 draws, seed 0; the
  SAME draws are applied to every owner, reader, arm, family, home and swap cell. Percentile intervals. It is printed
  beside every primary result and used by the secondary analyses of Part 8 that say so; every primary test, every
  secondary contrast of Part 3 and the test of P3 use the jackknife. (The former scheme, tasks resampled within each (stream, order)
  stratum, is withdrawn: it treated a task's appearances in two orders as independent.)
- Orders are never used as clusters on their own (three are too few; Cameron, Gelbach and Miller 2011; Cameron and
  Miller 2015).

### 4.2 p-values

- **Primary tests:** normal p-values from the two-way jackknife standard error (Part 4.1) of a linear statistic:
  p_upper = 1 − Φ(est / se) (evidence that the statistic is above 0), p_lower = Φ(est / se), two-sided =
  min(1, 2 min(p_upper, p_lower)). The θ tests are on the linear statistics of Part 3 (no ratio enters a test); a PC1
  member's p is the largest of its parts' p_upper (intersection-union, Part 3).
- **θ's interval:** the Fieller set (Fieller 1954) that inverts the same variance: every θ0 with
  |V̄_swap − θ0 V̄_home| ≤ 1.96 × se(V̄_swap − θ0 V̄_home), taken as the union of the sets from the raw two-way jackknife
  matrix and from its task-only part, so it is never narrower than the tests. Reported as "unbounded" when V̄_home is
  not clearly away from 0.
- **Stakes and order:** the Fieller sets of Part 2.4 from the same variance (`msr.metrics.order_stakes_inference`).
- **Secondary (task-only bootstrap):** from the draws θ*₁..θ*_B (B = 10,000):

```
p_upper (evidence that θ > 0) = (1 + #{θ*_b ≤ 0}) / (B + 1)
p_lower (evidence that θ < 0) = (1 + #{θ*_b ≥ 0}) / (B + 1)
two-sided p                   = min(1, 2 · min(p_upper, p_lower))
```

### 4.3 Non-inferiority

- The margin is on θ: "no material drop" means θ > 0.75, i.e. less than a quarter of the home ranking signal lost
  (Part 6.1). It is tested as the single linear statistic V̄_swap − 0.75 V̄_home with the two-way variance, so the
  uncertainty of the home signal is inside the test, together with the home member H (Part 3): p_NI =
  max(p_H, p of the contrast).
- "No material drop" is claimed only if p_NI is at or below its own Holm threshold. "Material drop" is the opposite
  one-sided test of the same contrast (PC1-MD), with its own Holm threshold.
- The concordance version N = 0.75 (C_home − 0.5) − (C_swap − 0.5) is reported as secondary (it moves with the reader's
  outcome noise).

### 4.4 The self-swap reference (inside the drop test since revision 2)

- The self-swap reference is a member of the drop test: Σ V̄_fresh − Σ V̄_swap > 0 (one-sided, two-way jackknife SE),
  with V̄_fresh the owner's later-session repeats 3–4 on the same tasks and scores (per group: the home cells of the
  group's owners, one per swap; per pair: the owner's own home cell). A drop is claimed only if the swap loses more
  than a second home session of the owner shows, and this condition is now inside the test's p (Part 3) rather than
  an extra rule outside it.
- Reported (descriptive): loss_self = 1 − θ_self with the upper end U_self of its two-way 95% interval; the former rule
  "1 − θ̂ > U_self" is no longer a condition.
- Secondary: the concordance-scale rule (D̄ beyond the upper end of D̄self) and the contrast C_fresh − C_swap.

### 4.5 Arms with random fresh checks

- An arm with k checks has, on each task, the mean of its values over the 200 draws (amended 23 Nov 2026, before any paid
  run). The variance resamples evaluation tasks and items with these means held fixed. The estimand is therefore the
  expected value of the rule over swap days, given the fixed calibration tasks.
- The spread over draws (5th to 95th percentile of the arm's pooled value) is reported as "what a single swap day may
  look like".

### 4.6 Cross-checks (reported, not decisive)

- Every primary test with the task-only variance beside the two-way one (columns `*_task*` of `primary_tests.csv`).
- Paired sign-flip permutation test (10,000 flips, seed 0) on the task-level differences of PC2.
- Owen's pigeonhole bootstrap for the concordance drop D (resample task ids and items independently; Owen 2007), reported
  as a conservative bound (Part 4.1).
- No confirmatory cell has fewer than 400 tasks. For any reported cell under 200 tasks, paired Bayesian beta-binomial
  intervals are used (Bowyer, Aitchison and Ivanova 2025).

---

## Part 5. Multiplicity

### 5.1 Primary family

- **The 12 primary tests (revision 2):** four hypotheses (PC1-drop, PC1-MD, PC1-NI, PC2; Part 3) × three swap groups
  (same-maker upgrades, same-maker downgrades, cross-maker swaps). Familywise error 0.05, Holm's step-down procedure
  (Holm 1979): sort the 12 p-values, p(1) ≤ … ≤ p(12); reject H(j) while p(j) ≤ 0.05 / (12 − j + 1); stop at the first
  that fails. PC3 and PC4 are not members (secondary, Part 3; Part 5.5).
- Each member has its own p: PC1-drop max(p_H, p of V̄_home − V̄_swap, p of V̄_fresh − V̄_swap); PC1-MD max(p_H, p of
  0.75 V̄_home − V̄_swap); PC1-NI max(p_H, p of V̄_swap − 0.75 V̄_home) (intersection-union, Berger 1982; no definedness
  gate); PC2 two-sided. A claim is made only for a member that Holm rejects, and every decision word is a function of
  the rejections (Part 3).
- **Why Holm over separate members, and not simultaneous Fieller sets (revision 2).** The three PC1 claims of a group are
  one-sided tests of linear contrasts, and each claim needs its own error control, including where the home signal is
  not positive; each intersection-union member is valid there by construction, and Holm keeps the familywise error at
  0.05 under any logical relation and any dependence between the members, which share models, tasks and items. A
  simultaneous Fieller band for θ would give coherent labels too, but its sets are unbounded whenever the home signal is
  weak, so it would also need a home test, and it spends error on two-sided statements that no claim uses. The labels
  are coherent by construction (Part 3): PC1-MD and PC1-NI are opposite tails of one statistic.
- **Measured familywise error ([sim], `docs/power/fwer_family2.py`, output `fwer_family2_output.md`).** z-level
  model of the 12 members (200,000 families per configuration; groups sharing a common factor or not): with a correctly
  sized SE the worst named configuration, θ = 0.75 exactly in every group (material drop and no material drop both at
  their boundary) with PC2 null, gave 0.0464 (Monte-Carlo SE 0.0005); θ = 1 everywhere 0.0234; a home signal of 0 in
  every group 0.0244. If every SE were 6% too small (the worst single-test size seen anywhere, 0.063 at 0.05, Part 4.1)
  the worst over a grid of 280 configurations was 0.0696 (SE 0.0006), at θ = 0.75 in every group. With the data-level
  jackknife z's of the simulated world (three independent replications as one family, θ = 1): 0.000–0.050 (SE
  0.017–0.028). The family error therefore rests on the members' own sizes, which Part 4.1 reports. Before revision 2:
  the 15-member family's worst familywise error was 0.0499 (`docs/power/fwer_holm.py`, 200,000 replications per
  configuration and a random search over 2,000 configurations); the withdrawn device (min(p_drop, p_NI) per group,
  both claims allowed) reached 0.143 in Reviewer 1's counter-example (0.11–0.13 with correlated tests).
- The diagnostics of Part 4.1 (item share, effective item clusters, df, concern marks) are printed beside every member
  and change no decision.

### 5.2 Per-pair results and the spread of each group (secondary)

- Every ordered swap gets θ with its two-way interval, order and stakes with their sets, every Part 3 statistic with an
  **unadjusted** 95% interval, pooled over the streams, shown in a forest plot grouped by swap group. Per swap and
  stream values are shown too.
- Beside each per-pair interval, a **Holm-adjusted flag** (familywise error 0.05) is shown as a secondary result. For
  PC1 the drop, material-drop and no-material-drop tests of every swap (each intersection-union, Part 3) are **three
  separate members**: Holm over 3 × 60 = 180, and the pair's word is `msr.metrics.pc1_label` of its three Holm
  decisions. (Round-1: two members per swap, Holm over 2 × 56 = 112, worst familywise error 0.0492; the earlier
  device, min(1, 2 × min(p_drop, p_NI)) per swap with both claims allowed, reached 0.76 and stays withdrawn.) PC2–PC4
  flags: Holm across the 60 swaps per comparison.
- **The spread of each group**, pre-stated, reported in the group table beside every group estimate (decision S5),
  so that a group average can never hide opposite effects:
  1. the range: the smallest and the largest per-pair estimate, with the pairs named;
  2. the share of swaps whose estimate has the opposite sign to the group average (for PC1, of the loss 1 − θ);
  3. **the group's own between-pair SD and a prediction interval for a new pair (revision 2; R6 W12.1, R4).** Per group
     and per comparison (PC1: θ; PC2: keep − wipe; the secondary PC3 and PC4 likewise), the k per-pair estimates y_i
     with their two-way jackknife variances s_i² are summarised by a random-effects model y_i = μ + u_i + e_i,
     u_i ~ (0, τ²): τ² by DerSimonian and Laird (1986), with its 95% interval by the Q-profile method (Viechtbauer
     2007); τ̂ is the group's between-pair SD. The random-effects mean μ̂ (weights 1 / (s_i² + τ̂²)) and its SE are
     printed beside the registered equal-weight group value. **Prediction interval for a new pair** (Higgins, Thompson
     and Spiegelhalter 2009): μ̂ ± t_{k−2, 0.975} √(τ̂² + SE(μ̂)²), computed for k ≥ 3 (k = 6 in each same-maker group,
     t₄ = 2.78; k = 48 cross-maker). It describes where the effect of one more pair "like these" would fall; with 6 pairs
     it is wide, and it is reported as such. The pairs of a group share models, tasks and items, so the s_i are not
     independent; the model treats them as if they were (an approximation, stated with the numbers). This replaces
     the single model-based SD of the round-1 text (one value for all three groups).
  4. The source-and-target summary of Part 8.2.12 (σ_source, σ_target, τ_pair over all 60 swaps) stays as a secondary
     description beside it.

### 5.3 Prediction family

- P1 to P4 (Part 7) form a second family. Holm at 0.05 across the four one-sided p-values.

### 5.4 Families of the additions (confirmatory-secondary)

- Family T (the transfer decomposition, Part 11.2): 9 tests, each its own Holm member (the specification test and the
  equivalence test in each of the three swap groups, and three score-family differences), Holm at 0.05.
- Family F (the pre-swap forecast, Part 11.3): 1 test (incremental value), one-sided at 0.05, no Holm.
- Neither is part of the 12 primary tests or of the prediction family, and no result in them changes a primary
  decision. Their status (confirmatory-secondary or exploratory) is the one Part 11 states.
- The min(p, p) device withdrawn in Part 5.1 (round-1) is not used in any family of Parts 3–10; family T of Part 11 is
  defined there (its own text governs it).
- Family L (the agent leg L3, Part 8.4): its own Holm family.
- The keep-or-drop decision (Part 11.4) controls each of its two errors at 0.05 at every stopping time (proved, 11.4.4;
  checked, 11.4.8), and its cost is reported beside an information lower bound (11.4.10).

### 5.5 Everything else

- All other analyses in Parts 8 and 11 are secondary or exploratory, and so are PC3 and PC4 (Part 3, since revision 2).
  They are shown with unadjusted 95% intervals and support no confirmatory claim.

---

## Part 6. Margins, thresholds and power

### 6.1 Non-inferiority margin

- θ > 0.75: "losing less than a quarter of the home ranking signal". In the terms of Lakens, Scheel and Isager (2018)
  this is an anchor-type smallest effect size of interest, tied to the size of the signal, not to a benchmark
  convention or to the budget. It is fixed here, before any data, as they require. (Before the round-1 revision the
  same quarter was put on R; R moves with the reader's outcome noise, θ does not.)
- Why relative and not a fixed number: the home signal will differ between models and streams; the pilot covers one
  pair on DDXPlus only, so a number frozen from it could not serve 12 models and 2 streams (settled point 2).
- Two-sided equivalence (TOST) is used only for a claim of "the same", which this study does not make.

### 6.2 Difference threshold

- 5 points: 0.05 in concordance, 5 percentage points in success rates.
- Since revision 2 the threshold labels nothing in the primary family (no label without a test): it is drawn as a
  reference mark beside PC2's estimate and interval, in the stakes table and in the forest plots, and the reader sees
  whether the interval lies above it. (Before revision 2 a detected PC2 difference was called "of practical size" or
  "detected, below the 5-point threshold" from its point estimate; withdrawn.)

### 6.3 Power of the registered tests (design aid, [sim])

**Revision 2 (12-member family, intersection-union members, the jackknife variance; same-maker groups of 4 and of 6
swaps side by side):** `docs/power/family2.md` (`power_family2.py`, 180 replications per row, MC SE at most 0.037), power at 0.05/12 (a member tested first) / 0.05/6 (after six rejections), 4 swaps → 6 swaps per same-maker group: PC1-drop at θ = 0.85 is 0.16/0.22 → 0.21/0.28 (home Cw 0.56), 0.74/0.78 → 0.93/0.96 (0.62), 0.99 → 1.00 (0.66); at θ = 0.7 it is 0.72/0.78 → 0.91/0.93 (0.56) and 1.00 at 0.62 and 0.66; PC1-NI at θ = 1 is 0.74/0.79 → 0.91/0.96 (0.56) and 1.00 at 0.62 and 0.66, at θ = 0.9 it is 0.15/0.22 → 0.29/0.37, 0.88/0.93 → 0.98/0.98 and 0.99 → 1.00; PC1-MD at θ = 0.7 (0.05 below its boundary) is 0.01–0.18 (it exists so that "material drop" is a tested claim). At θ = 1 the drop member rejects at most 0.01 of the time. Family-wise error (`fwer_family2_output.md`): worst case 0.046 (θ = 0.75 in every group, PC2 null, exact SEs), 0.049 if every SE were 1 % too small, 0.070 in a stress case with SEs 6 % too small at the far tail, which no simulated world shows for the jackknife. PC2 (keep − wipe, two-sided; home Cw 0.62,
`fwer_family2_output.md` part c): SE 0.36 success points with 4 swaps and 0.30 with 6; power at a 1-point gap 0.45
(4 swaps) and 0.68 (6 swaps) at 0.05/12 (0.54 and 0.76 at 0.05/6); 1.00 at 2 points for both. The extension pairs
raise the same-maker groups from 4 to 6 swaps; the cross-maker group stays at 48.

The round-1 table below (4-swap groups, Holm over 15, the round-1 variance with its factor 1.03) is kept for the
record.

Re-simulated for the tests registered in round 1 (`docs/power/power_theta.py`, output `power_theta_output.md`): 2 streams ×
3 orders × 400 evaluation tasks drawn from one task pool per stream, 2 repeats, 250-item banks, 8 models in 4 makers,
the headline θ with the two-way variance, Holm over 15 (powers at the first-step threshold 0.05/15; the threshold of a
realistic later step, 0.05/9, moves the points by under 0.01 in θ). 300 replications per cell; a design aid under
the stated assumptions, not a measurement.

| Test | Home signal | Same-maker upgrades (4) | Same-maker downgrades (4) | Cross-maker (48) |
|---|---|---|---|---|
| PC1-drop: θ loss detected with 80% power | sim-like (home Cw ≈ 0.66) | 0.12 | 0.115 | 0.08 |
| | weak (home Cw ≈ 0.56) | 0.33 | 0.335 | 0.17 |
| PC1-NI: θ at which "no material drop" has 80% power | sim-like | 0.85 | 0.85 | 0.79 |
| | weak | not reached (0.68 at θ = 1) | not reached | 0.886 |
| PC2: power at a keep − wipe gap of 2 / 3 points | sim-like | 0.99 / 1.00 | 0.99 / 1.00 | 1.00 / 1.00 (0.41 at 1 point for 4-swap groups) |
| PC3, PC4: minimum detectable swap-minus-home difference at 80%, log-score units | dry-run per-task SDs | about 0.006–0.014 | about 0.006–0.014 | about 0.003–0.007 |

- At θ = 1 the drop test rejected in at most 0.003 of replications (nominal 0.0033 at the first step).
- PC3 and PC4 come from the dry run's per-task SDs of uncorrected log-score differences, scaled to 1,200 tasks per
  stream; the range is widened by √2 for the home term of the swap-minus-home contrast.
- What the simulation leaves out: bank-to-bank variation of the score phase, selection-biased visits, model-specific
  noise beyond two levels, and dependence through shared models. The pilot estimates the home signal and the repeat
  disagreement, and `power_theta.py` is re-run with them. **The pilot may update the stated power; it may not change any
  margin, test or threshold in this file.**
- If the real home signal is as weak as the "weak" row, the same-maker groups may not show "no material drop" even
  when nothing changed; the paper then reports that limit as a result, not as "no drop".
- P1, P2 and P4 rest on comparisons across 8 core models (and, for P1, the 4 extension models). Their power is low by
  design (Part 7).

---

### 6.4 Cost of one swap day (revision 2)

One cost table charges every rule for every call it uses on one swap day (one owner bank, one reader, one stream, one
order), split by who makes the call (the old model before it retires, or the reader) and when
(`paper/assets/table_cost_one.tex` from `construct_costs.csv`; `costs_by_arm.csv` from `msr.analysis.cost_tables`).
Two accounting rules are fixed here:
- **The level information is one shared fixed cost.** Every level-corrected log and Brier score (PC3, PC4 and the
  arms read on them) needs the reader's no-memory runs of the calibration tasks (200 reader calls per swap day in the
  registered study, three times the 64 checks of recal_64; 48 in the practice study). They are bought once per swap
  day and serve every rule read on those scores at once, so they are stated once, as a shared fixed row, and not
  added to each rule's total; first-shown success (PC2) needs none. A comparison of two rules on the log score
  therefore carries the same fixed cost on both sides.
- **own is charged one reader build** (write, no-memory run, score passes and tags on this stream and order:
  250 + 500 + 2 × 500 × passes reader calls in the registered study, 3,750 at 3 passes and 5,750 at the budgeted 5;
  1,200 in the practice study), not the per-model total over every stream, order and second bank that the round-1
  table charged (27,000 at 3 passes). `msr.analysis.swap_day_sizes` computes it from the study file.
- **The keep-or-drop tests and the forecast** are charged by the functions that run them (theory hand-over, section
  8): the paired 0.75 test needs 8 old-model calls per stored check task (4 candidates × 2 home repeats) plus 800 for
  the home flag (100 calibration tasks × 4 candidates × 2 repeats), all before the old model retires: 2,400 old-model
  calls with the replay's store of 200 tasks, about 6,644 with a store large enough for the test's median stop at the
  practice study's signal (730 tasks), plus 4 new-model checks per task used (`msr.sequential.swap_day_calls`). The
  break-even (margin-0) tests need no old-model call: 4 new-model checks per task (ranking form) or 2 per task where
  keep and wipe differ (first-shown form). The pre-swap forecast needs 1,150 calls per swap day, 950 by the new model
  and 200 by the old one (`msr.forecast.forecast_calls`). Each has its own row.
- **The paid secondary rules of Part 8.2.18–8.2.22** are charged their design counts until the run logs them: the
  judge one new-model call per stored item (250), the owner's self-rating one old-model call per item at write time
  (250), relearn one score phase by the new model (500 × passes), re-exploration nothing beyond the run itself, and
  re-answer one new-model call per item (250).

## Part 7. Predictions registered in advance (P1–P4)

P1–P4 stay registered as written here and are reported in the paper's appendix (round-1 revision). Since that revision
they read the headline θ in place of R (P1, P3, P4); P2 is unchanged. Revision 2 makes P1 F1's test of Part 11.3.8
on the core grid (partial correlation given F1's controls, double semi-partialling over the maker-preserving
relabellings), replaces P3's task bootstrap by the jackknife of Part 4.1, and states how each prediction uses the
extension pairs.

Each is reported as **pass** or **fail**. "Contradicted" is added when the opposite direction is significant at
one-sided 0.05. Each prediction also reports a leave-one-model-out check: the statistic recomputed once without all
swaps that involve each model in turn (8 times for P1, P2 and P4, which use the core grid only; 12 times for P3, which
uses all 60 swaps). A pass with a sign flip in any of those is reported as "pass, not robust to leaving out model X".

**Relabellings.** A permutation test applies one relabelling π of the models to the quantity under test (rows and
columns of a grid together), keeps the other quantity fixed, and recomputes the statistic; p = (number of relabellings
with a statistic at least as extreme as observed, identity included) / (number of relabellings). This keeps the
dependence between swaps that share a model, which an ordinary correlation test would ignore. Two groups of
relabellings are used:
- **Maker-preserving (P1; revision 2).** P1 is F1's test (Part 11.3.8): "the models of the residual ec array are
  relabelled within makers and as whole makers among makers of equal size (8 models in 4 makers of 2: 2^4 × 4! = 384
  relabellings, enumerated; every relabelling keeps each pair's same-maker flag)", with agreement in place of ec and
  double semi-partialling on F1's controls (`msr.forecast.pair_incremental_test`). Ruling of 24 Nov 2026 (open point
  29, closed): P1 and F1 are computed on the **core grid only** (the 8 core models, 4 makers, 56 swaps), so the
  relabellings are within and among the four core makers (384); the extension pairs enter only the same-maker group
  estimates (PC1 and PC2 for the upgrade and downgrade groups), the spread and prediction-interval summaries (Part
  5.2) and the descriptive tables. In the code, `msr.analysis.predictions` passes P1 the core-grid swaps only and
  `msr.analysis.design_from_study` gives `msr.forecast` the core-grid design (`core_design`). Because every
  relabelling keeps each pair's
  same-maker flag and the controls hold capability and model position fixed, neither a maker effect nor a capability
  effect shared by the two quantities can by itself produce a rejection, which the plain 8! permutation of the round-1
  text allowed.
- **All labels of the core grid (P2, P4).** All 8! = 40,320 permutations of the 8 core models, enumerated (exact),
  applied to the 56 swaps of the core grid. P4 needs relabellings that move the maker structure: a maker-preserving
  relabelling maps the cross-maker swaps onto themselves and so cannot test a maker effect. The extension models have
  no cross-maker cells to be relabelled into, so P2 and P4 are tested on the core grid and the extension swaps enter
  their secondary analyses.

### P1. The retained ranking signal rises with agreement

- **Quantity (revision 2, AC audit N3):** the partial correlation of θ(s→t) (pooled over the streams, headline family)
  and agreement κ(s→t) (Part 2.11, calibration tasks, averaged over streams) given Q = [1, same_maker, Z_A, Z_B,
  abs_gap, owner_newer, reader_newer], over the swaps whose θ is reported (not flagged "home signal too weak on the
  calibration tasks", Part 2.4): F1's statistic of Part 11.3.8 with agreement in place of ec (the t of κ in OLS
  θ ~ Q + κ). Z is the no-memory success averaged over the streams. **Core grid only** (ruling of 24 Nov 2026):
  the 56 swaps of the 8 core models (4 makers); the extension pairs do not enter P1.
- **Test:** F1's test, as Part 11.3.8 registers it ("P1 uses the same test (Part 7 governs P1):
  `msr.forecast.pair_incremental_test(x, y, owners, readers, makers, controls)` with x = agreement and the controls
  of F1"): double semi-partialling over the maker-preserving relabellings; one-sided (> 0); the smallest attainable p
  decides testability as in 11.3.8. Why the controls: with the same-maker flag alone the test passed wrongly in 0.099
  (capability world), 0.20 (capability level) and 0.13 (newer-model position in both arrays) of 800 null worlds; with
  F1's controls 0.056, 0.048 and 0.07, at a power cost of 0.67 → 0.61 at an incremental correlation of 0.3
  (`docs/handover/theory_round2.md`, section 9).
- **Pass:** the statistic > 0 and the Holm-adjusted p ≤ 0.05. **Fail:** otherwise.
- Secondary: the same test with θ kept on the 48 cross-maker swaps only; Spearman's ρ1(κ, θ), the round-1 statistic,
  reported beside it without a test.

### P2. The keep–wipe gap shrinks as the new model's no-memory success rises

- **Quantity:** ρ2 = the mean over the two streams of Spearman's correlation, within each stream, between G(s→t, b) and
  X(t, b) across the 56 swaps of the core grid (Part 2.11). Computed within stream so that differences between
  streams cannot drive it.
- **Test:** permutation of X over the 8 core models (all 8!, the same permutation in both streams); one-sided (ρ2 < 0).
- **Pass:** ρ2 < 0 and the Holm-adjusted p ≤ 0.05. **Fail:** otherwise.
- Note: X takes only 8 values per stream, so the effective sample size is 8 readers.
- Secondary: ρ2 over all 60 swaps (descriptive).

### P3. Self-given tags lose more ranking signal than program-graded scores

- **Quantity:** Δ_P3 = θ(`ema_grade`) − θ(`tags_self`), θ pooled over all 60 swaps and both streams (Part 2.4).
  Positive means the tags keep less.
- **Test:** the two-way jackknife of Part 4.1 applied to the linearised difference, Σ (V̄_swap − θ̂ V̄_home) / Σ V̄_home
  of `ema_grade` minus the same of `tags_self`; both families sit on the same tasks, outcomes and items, so the test is
  paired; one-sided p_upper. (Round-1 text: "the stratified task bootstrap of Part 4.1"; Part 4.1 has been two-way since
  the round-1 revision, so that wording is withdrawn.)
- **Pass:** Δ_P3 > 0 and the Holm-adjusted p ≤ 0.05. **Fail:** otherwise. If θ(`tags_self`) is flagged "home signal
  too weak on the calibration tasks" (Part 2.4), P3 is reported as "not testable" and counts as not passed.
- P3 and the transfer decomposition's T2(tags_self) (Part 11.2.4) expect opposite things for the same difference; both
  stay registered, both are reported, and at most one of them can come out as expected (Part 11.2.4 says so).
- Secondary: Δ_P3 within each swap group; the same against `beta_grade`; and the drop D in concordance points.

### P4. Same-maker upgrades retain more ranking signal than cross-maker swaps

- **Quantity:** Δ_P4 = mean of θ(s→t) over the 4 upgrades of the core grid (old → new, same maker) minus the mean over
  the 48 cross-maker swaps (θ as in P1).
- **Test:** permutation of the 8 core labels (all 8!): under π, the "upgrades" become the 4 cells π(old) → π(new) and
  "cross-maker" the cells between different π-makers; one-sided (Δ_P4 > 0). The smallest possible p is
  24 / 40,320.
- **Pass:** Δ_P4 > 0 and the Holm-adjusted p ≤ 0.05. **Fail:** otherwise.
- Secondary: the 6 upgrades (the 4 core and the 2 extension upgrades) against the 48 cross-maker swaps (descriptive);
  all 12 same-maker swaps (upgrades and downgrades) against the 48 cross-maker swaps; and θ against capability gap and
  error consistency with maker as a separate term (Part 8.2.17), since the same-maker pairs are also the pairs closest
  in capability (R5 W9).

---

## Part 8. Controls, secondary and exploratory analyses

### 8.1 Controls (part of the design)

- Self-swap reference on every home cell (Part 4.4). Each model's extra home repeats run in the last third of that
  model's collection window, with call times logged, so the floor also catches drift over time. It also checks
  whether the standard errors are right.
- `shuffled` arm: the content-only control. `visits` family: a score with no usefulness signal.
- `relevance` and `none` arms: the baselines.
- Repeat disagreement per model (share of home cells whose repeats 1 and 2 differ), reported for every model in the
  main text, beside each model's sampling settings (Part 0.1).
- Caching checks (revision 2; Part 2.4): per model, the within-session products of the home cells (repeat 1 × 2, 3 × 4)
  against the across-session product (mean 1–2 × mean 3–4), and the rate of identical responses between repeats within
  a session against across sessions.

### 8.2 Secondary analyses (pre-specified, always reported, not confirmatory)

1. **Keep against the references:** FS_keep − FS_own, FS_ceiling − FS_keep (the in-sample ceiling) and
   FS_keep − FS_split_half (Part 2.7); `split_half` is a reference, not an upper bound, and stays out of headline
   tables. **What is at stake** (S7): the table of Part 3 (keep − wipe, keep − shuffled, ceiling − keep, keep − none, at
   home and after the swap, in success points, two-way intervals) is always reported with the primary tests.
2. **All 60 swaps together:** PC1–PC4 statistics averaged over every swap (descriptive, no test).
3. **Per stream** and **per swap and stream** results; per-pair results and the heterogeneity summary (Part 5.2).
4. **Each score family:** every Part 2 estimand for every family other than the headline family.
5. **All arms at all k:** first-shown success, regret, log score, Brier and cost, with the equal-budget comparisons
   recal_k against `fresh_k`, `pooled_k`, `powerprior_k`, `retest_k` and `audit_k`.
6. **Discount arms by decision quality and in the post-swap run:** FS and regret for `fixed_0.5` and `recal_64`
   against keep and wipe; S_all, S_100 and n95 (Part 2.10) for every post-swap arm against keep, by the stratified
   task bootstrap (positions resampled within order).
7. **Concordance variants:** unweighted C (weight 1 for every informative pair); C on pairs not tied in score; the
   share of score ties; Kendall's τ_b as a sensitivity (via Newson 2002); concordance by visit third. The thirds are
   cut at the 1/3 and 2/3 quantiles of score-phase visits over the owner's bank, and a pair is classed by its
   less-visited item. This tercile split is the registered visit analysis; θ per visit third and swap group (two-way
   Fieller sets) is in `paper/assets/table_strata.tex` and the macros `ThetaVisitsThird{Low,Mid,High}{Upgrade,
   Downgrade,Cross,AllSwaps}`. **Registered sensitivity (revision 2):** the same with fixed bins of the less-visited
   item's score-phase showings, 0 / 1–2 / 3–5 / 6+ (`msr/construct.py`, `construct_visits_theta.csv`), so that strata
   mean the same number of showings in every bank.
8. **Noise:** both split-half noise references, the noise-normalised C, and a model-based ceiling (fit a logistic model with
   task and item-in-task random effects to the probe outcomes and simulate the concordance of the true
   probabilities; reported as model-based); and the noise-adjusted retained validity R_adj (Part 2.5).
9. **Top-1 and top-2 agreement** (Part 2.9).
10. **Fitted values of the calibrated arms by k:** distribution of λ̂ and b̂ over draws, and λ̂ / λ̂ at home. Expected
    from the simulation, not tested: b̂ is imprecise at every planned k ([sim] Table 10: interquartile range about
    0.6 wide at k = 64).
11. **Self-swap contrast** C_fresh − C_swap.
12. **Source-and-target summary, by least squares** (amended and settled 23 Nov 2026). Per swap, the estimate of each
    comparison (D̂ for PC1; likewise for PC2–PC4), pooled over the streams, with its bootstrap variance se², is fitted
    over all 60 swaps by ordinary least squares: estimate = μ + stratum + u(source) + v(target) + residual, with
    sum-to-zero source and target effects (the crossed source-and-target structure of Baayen, Davidson and Bates
    2008, fitted here as fixed effects; an extension model is a source and a target of one swap only, so its effects are
    poorly separated from its pair's residual). σ²_source and σ²_target are the sample variances of the fitted u and v;
    τ²_pair = max(0, residual sum of squares / residual df − mean se²). This model's between-pair SD,
    √(σ²_source + σ²_target + τ²_pair), with a percentile interval from refitting every bootstrap draw, is a secondary
    description over all swaps; since revision 2 each group's own between-pair SD and prediction interval (Part 5.2)
    sit beside every group estimate. The predicted
    pair effects are u + v plus the residual shrunk by τ²_pair / (τ²_pair + se²). This replaces the mixed model and the
    cell-level logistic model of the first draft. With 12 models (8 in the core grid) these spreads are rough: they describe these models,
    not models in general.
13. **Leave-one-model-out:** PC1–PC4 statistics and P1–P4 recomputed once without each model (Part 7 for the
    predictions).
14. **Sensitivity analyses named in Part 1:** original BIRD grading; token-limit and refusal cells as missing;
    available-case missing data; the pair-count-weighted pooling; `tags_self` ranked by helpful − harmful; the
    pigeonhole bootstrap.
15. **Sampling settings (round-1 revision, S6).** Sampling cannot be made identical across makers: the closed models
    take no sampling value and run at their providers' fixed defaults, while the open-weight models are sent
    temperature 1.0 and top_p 1.0 (no top_k) to match those defaults as closely as the hosts allow. θ does not move
    with outcome noise, but a sampling setting can also change which items help a model. Sensitivity: the Qwen pair
    (same maker, open weights) is run again at temperature 0.7 (top_p 1.0, no top_k) with its own banks
    (`config/study_temperature.yaml`: the upgrade, the downgrade and both home cells, DDXPlus, orders 0–2; about USD 18
    by the pipeline's estimate). Reported: θ, D, R and repeat disagreement of the two same-maker swaps at 0.7 beside
    the main study's values at 1.0. Secondary; no test.
16. **Secondary measures beside θ (round-1 revision, S1):** the concordance ratio R with the spread ratio
    W̄_home / W̄_swap, the drop D in concordance points, R_adj (Part 2.5), the uncorrected log and Brier scores, and
    every θ quantity with the task-only interval. Since revision 2 also order and stakes (Part 2.4) per pair and per
    group, with their sets and the order's identifiability.
17. **Capability, error consistency and maker (revision 2; R5 W9).** The same-maker pairs are also the pairs closest in
    capability, so "same-maker swaps keep more" may be "more alike pairs keep more". Per swap, a table of θ (two-way
    interval) beside its capability gap gap = Z_reader − Z_owner and |gap| (Z: no-memory success on the predictor
    tasks, Part 11.3; read from the forecast's output `forecast_pairs.csv`, not recomputed), its error consistency ec
    (Part 11.3) and its same-maker flag. Summary: the ordinary least-squares fit of θ on [1, same_maker] and on
    [1, same_maker, |gap|, gap, ec] (the signed gap too, as coded in `msr.analysis.capability_tables` and in
    `msr.forecast`'s `forecast_capability_regression.csv`) over the swaps with θ reportable, printing the same-maker
    coefficient with and without the controls. On the 56 core swaps of the full-size simulated rehearsal this design
    matrix is well conditioned (condition number 35 raw, 1.9 after centring and scaling; corr(|gap|, gap) = 0.00,
    corr(same_maker, ec) = 0.47), so the signed gap stays. Descriptive only: the swaps share models, so no p-value is
    claimed for the maker term (maker-preserving relabellings cannot move it); it is read with its interval (the
    registered test of
    whether ec adds beyond maker and capability is F1, Part 11.3.8). Wording rule, fixed now: the paper says "same-maker
    swaps keep more" only if the same-maker coefficient keeps its sign and at least half of its size once |gap|, gap and
    ec are in the fit; otherwise it says "pairs that are more alike keep more".
18. **Re-answer (revision 2, decision D7; registered secondary).** Score `reanswer`: x = 1 if the reader's own
    write-phase answer (no memory) to the item's source task agrees with the stored answer (DDXPlus: the same label;
    BIRD: the same result set), else 0. The write tasks are shared by every model of a (stream, order), and each
    model's write answer is stored; the owner's home value uses its second no-memory answer to each write task
    (`build.write_repeat`, stage `write2`), so `reanswer` has a home value and a self-swap reference. Cells: every probe
    cell. Computed as every arm: Cw, V and θ at home and after the swap, first-shown success minus keep and minus wipe
    (two-way intervals), per swap group and stream (`construct_reference.csv`, `construct_baselines.csv`). Read: does
    the reader's own view of the stored answer rank the items as well as the old scores? Cost: one new-model call per
    item (Part 6.4). Not in any family.
19. **The new model as judge (registered secondary).** Stage `judge`: the reader rates each of the owner's stored
    items (its task and its stored answer, never the grade) as a whole number 1..10 (`build.rating_scale`); one call
    per owner item per cell, on every probe cell, home cells included (`judge.cells: cells`). Score type and swap-day
    rule `judge`: x = the rating (a missing or unreadable rating is a tie at the scale's middle), ranked by the mix like
    any score. Computed: Cw, V and θ, first-shown success minus keep and minus wipe (two-way intervals), per swap group
    and stream; no log or Brier score (a rating is not a probability). Read beside keep and wipe: can the new model
    pick good items from their content alone? Cost: one new-model call per stored item (250) per cell. Not in any
    family.
20. **The owner's write-time self-rating (registered secondary).** Stage `selfrate`: right after writing, the owner
    rates each of its stored items (its task and its answer, no label) on the same 1..10 scale (`build.self_rating`);
    one rating per item, for every item, before any use (unlike `tags_self`, which tags items after they are shown).
    Score type `self_rating`, carried to the reader unchanged like any old score; computed and read as `judge` (18–19)
    on every probe cell. Cost: one old-model call per item at write time (250). Not in any family.
21. **Relearn on frozen content (registered secondary).** Stage `relearn`: the reader re-runs the whole score phase on
    the owner's frozen items: scores start from zero; the same score tasks, the same number of passes as the build
    (Part 0.3) and the owner's bank-1 exploration draws; fresh repeats (`relearn.repeat_offset`); the `credit` family's
    no-memory baseline is the reader's own; no self-tags (`relearn.self_tag: false`), so `tags_self` is not relearned.
    Cells (the list rule, `relearn.pairs: [same_maker, cross_cycle, cross_cycle_back]`): every same-maker upgrade and
    downgrade (12, the extension pairs included), each core maker's old model → the next core maker's new model
    (`cross_cycle`, 4: haiku-4.5 → gpt-6-luna, gpt-5.6-luna → qwen3.8-27b, qwen3.5-27b → gemma-4-31b, gemma-3-27b →
    haiku-5.5) and each core maker's new model → the previous core maker's old model (`cross_cycle_back`, 4:
    haiku-5.5 → gemma-3-27b, gpt-6-luna → haiku-4.5, qwen3.8-27b → gpt-5.6-luna, gemma-4-31b → qwen3.5-27b): 20 swaps,
    each core maker twice as owner and twice as reader in the cross part. Swap-day rule `relearn`: the relearned bank's
    scores, ranked as the owner's own bank would be (same families and rules), scored on the cell's probe table.
    Computed: first-shown success relearn − keep and relearn − wipe (two-way intervals), Cw and θ of the relearned
    scores, per swap group (upgrade, downgrade, the 8 cross-maker swaps) and stream. Read: what paying the new model to
    re-earn the scores buys over keeping the old ones (the pay-to-relearn reference). Cost: one score phase by the new
    model (500 × passes calls). Not in any family.
22. **Re-exploration after the swap (registered secondary).** The post-swap run's arms `reexplore_25` and
    `reexplore_50` (Part 2.10): keep's start and learning, with exploration chance 0.3 for the first m test tasks of each
    order. Cells: the 12 swaps of the post-swap run. Computed: S_all, S_100 and n95 against keep (Part 8.2.6). Read:
    does a short burst of exploration after the swap recover what the old scores lose? Not in any family.
23. **The stored-answer-correct reference score (registered secondary).** Score `correct`: x = 1 if the stored answer
    was graded correct at write time, else 0 (`correct_rel`: ties broken by relevance, x = grade + 0.001 × relevance).
    Computed on every probe cell: Cw, V and θ (two-way Fieller set, the tests, the home-signal flag) at home and after
    the swap, per cell and group, per stream and pooled (`construct_reference.csv`), and as a free swap-day rule
    (first-shown success minus keep and minus wipe, `construct_baselines.csv`). Read: how much of the learned score's
    ranking a correctness detector reproduces. Needs `build.store: all` (with `correct_only` every grade is 1). Not in
    any family.
24. **Construct strata (registered secondary).** For the headline score, per swap group and stream
    (`msr/construct.py`; meanings in `runs/<study>/analysis/CONSTRUCT.md`): (a) V, W and θ within correct-correct,
    wrong-wrong and mixed pairs (by the stored answers' write-time grades), the share of V in mixed pairs against its
    null (the weight share W_mixed / W) and the excess over it; (b) the residualised score: ols (x minus its bank mean
    among items of the same grade) and rank (within-grade mid-rank), with Cw, V, θ and the grade's share of the home
    signal 1 − V_resid / V (Fieller set) (`construct_correctness.csv`); (c) answer match (the grader marks the stored
    answer correct for the probe task) and near duplicates (relevance above the 0.999 quantile of the similarity of
    pairs that cannot be the same case: DDXPlus a different pathology, BIRD a different database): their shares of the
    informative pairs and θ with such pairs left out (`construct_overlap.csv`, `construct_candidates.csv`). Read, per
    stream, by the fixed rule of `msr.construct.reading`: if the learned score has no home signal on the calibration
    tasks (the one home-signal rule), "cannot tell"; else by the 95% Fieller set of the grade's share of the home
    signal against 1/2: above 1/2 "mostly a correctness detector", covering 1/2 "partly a correctness detector",
    below 1/2 "signal beyond correctness" ("mostly signal beyond correctness, partly correctness" when the set is also
    above 0; "inconclusive" when the residualised score has no home signal); each with ", with signal beyond it" when
    the residualised score keeps a home signal. θ of the residualised score is reported as the part of θ that is not
    correctness. Not in any family.
25. **The doubly robust score beside the IPS score (registered secondary).** Beside the self-normalised IPS score of
    8.3.5: the doubly robust score of each item, with the owner's no-memory result on the score task as the direct
    model and the logged selection probabilities clipped at 0.05 (`msr/construct.py`). Computed: Cw, V and θ, and
    first-shown success minus keep and minus wipe, on every probe cell (`construct_reference.csv`,
    `construct_baselines.csv`). Read beside IPS: does correcting the selection bias of the score phase change the
    ranking? Not in any family.

### 8.3 Exploratory analyses (labelled as such wherever they appear)

1. **Mix weight:** decision-quality results re-ranked offline with score weight 0.25 and 0.75 (banks unchanged), and
   with relevance and score both z-scored within each task's 4 candidates (a sensitivity for MemRL's z-normalised
   mix; settled 23 Nov 2026).
2. **Shapley realism check** (`probe.subsets`; scope as configured in `config/study.yaml`): both streams, three
   orders, the first 100 evaluation tasks of each order (in stream order), every same-maker upgrade swap and every home
   cell (18 cells: the 6 upgrades and 12 home cells of the core grid and the extension pairs, as `probe.subset_cells`
   in the study file).
   Every group of 2, 3 and 4 candidates is run once (11 groups, items listed in the build's prompt order); the single
   items and the no-item runs come from the probe table. Exact Shapley values per task and candidate. Reported: the
   within-task concordance between single-item results and Shapley values, and D computed with Shapley values as
   outcomes beside the single-item D.
3. **Second prompt wording** (`variants`, wording v2): the Haiku and Qwen pairs in both directions (4 within-pair
   swaps) with their 4 home cells, both streams, the first 100 evaluation tasks of each order, 2 repeats. Reported: D
   under each wording, and the wording variance component beside the repeat and task components. (Open point 25: the
   config does not yet run the home cells or keep the raw results that these need.)
4. **Second independent bank:** Haiku 4.5 and Qwen3.5-27B, the same 250 items, the score phase re-run with a
   different exploration seed. Because the content is identical, the existing probe tables apply with no new calls.
   Reported: within-task concordance between the two banks' scores, home Cw, and D for that owner's swaps under each bank.
5. **Selection-probability (inverse-propensity) correction:** each score-phase show j of item i has its logged
   selection probability π_j. IPS score of item i = Σ_j y_j / π_j divided by Σ_j 1 / π_j over its shows
   (self-normalised; logged propensities as in logged bandit feedback, Zhang et al. 2019). Reported: Cw and D with
   these scores.
6. **Labelled ("memprompt") items:** the pilot, and four models, Haiku 4.5, Haiku 5.5, Qwen3.5-27B and Qwen3.8-27B,
   with all 12 ordered swaps among them and their 4 home cells, on DDXPlus with stream order 0 only
   (`config/study_memprompt.yaml`; about USD 31 by the pipeline's estimate, 45 with margin). Reported: θ, D and R beside
   the shot-style values (amended 23 Nov 2026 in the round-1 revision, before any paid run).
7. **More fresh checks by look-up:** k = 128 and 256, listed in `evaluate.k_values`; a study whose calibration pool
   holds fewer cells than k skips that k with a note (in the pilots, k = 256) (amended 24 Nov 2026, before any paid run).
8. **Legs outside this registration:** AppWorld (L4), the "Beyond Gain" check (L5) and the optional fifth pair are not
   covered by Parts 3, 5, 7 and 11. The MemRL-code leg (L3) is registered in Part 8.4.

### 8.4 The confirmatory agent leg (L3): MemRL's released code on LifelongAgentBench (revision 2, 24 Nov 2026)

Design: `legs/memrl/README.md` (MemRL, MemTensor/MemRL at commit `c1b322ca43de36ddf64c6712f89d0095bfc35ce0`, MIT, run
with its own training, retrieval and evaluation; LifelongAgentBench operating-system tasks, 350 training and 150
validation tasks; a multi-step agent with up to 15 turns; graded by the task's own check script). Revised on 24 Nov 2026
after the round-2 reviews (R5 W2 and question 4, R4 weakness 4, AC audit N7 and action 5), before any paid call.

- **Role.** The bridge from the main study's exemplar memory (one stored example shown per task) to an agent memory
  (MemRL: 10 training passes over 350 tasks, up to 10 similar memories recalled and 5 shown per episode, every shown
  memory credited with the episode's reward). Family L is its own Holm family; no main-study decision depends on it.
- **Arms.** Every evaluation is MemRL's own `_evaluate` on the 150 validation tasks with the bank frozen (no Q update,
  no new memory). Within one bank the arms differ only in the Q-values (checked file by file before any run):
  - `keep`: Q as learned.
  - `shuffle_visit` (the registered control): the learned Q-values permuted only among memories with similar visit
    counts (strata of 0, 1, 2, 3-4, 5-8, 9-16 and 17+ training episodes in which the memory was shown), over the
    memories retrieval can reach. It keeps the link between Q and exposure, which MemRL's shared reward builds in, so
    keep - shuffle_visit measures what the learned order says beyond how often a memory was shown. A fresh permutation
    is drawn for every repeat (seed = repeat), so the contrast averages over permutations and its interval includes
    the permutation variance.
  - Secondary arms: `wipe` (all Q = 0.5, MemRL's start value), `shuffled` (one permutation over all reachable memories
    per repeat; the round-1 control), `shuffle_bucket` (within the memories stored under one query, which have the same
    similarity to every new task), `none` (no memory), `own` (the reader's own bank), and `relearn` (the reader runs one
    more MemRL training pass over the 350 training tasks on the old bank with the content frozen, so only Q moves: the
    pay-to-relearn reference).
- **Directed swaps, in a fixed order (scope).** Block k (k = 1, 2, 3, 4: Anthropic, OpenAI, Qwen, Gemma) trains maker
  k's old and new model and adds three directed swaps: old -> new (upgrade), new -> old (downgrade), and maker k's old
  model read by maker (k+1)'s new model (cross-maker, cyclic over the makers of the design). Blocks are run in order and a
  budget cut removes whole blocks from the end, so every completed scope holds same-maker swaps in both directions and at
  least one cross-maker swap. Designs: **minimum** = blocks 1-2 (6 directed swaps: haiku-4.5 <-> haiku-5.5,
  gpt-5.6-luna <-> gpt-6-luna, haiku-4.5 -> gpt-6-luna, gpt-5.6-luna -> haiku-5.5); **recommended** = blocks 1-4
  (12 directed swaps: 8 same-maker, 4 cross-maker: haiku-4.5 -> gpt-6-luna, gpt-5.6-luna -> qwen3.8-27b,
  qwen3.5-27b -> gemma-4-31b, gemma-3-27b -> haiku-5.5); **full** = recommended with every secondary arm at 8 repeats, the
  in-bank evaluation (the same contrasts on the 350 training tasks, 4 repeats) and a one-memory probe (priced only). The
  registered choice is **recommended**; the design actually run, and any cut, is recorded in Part 0.1 before the first
  L3 call.
- **Repeats.** 8 for `keep` and `shuffle_visit` in every home and swap cell; 2 for the secondary arms (8 in the full
  design); 2 for `none`.
- **Power, stated before any run** (`legs/memrl/tools/power_family_L.py`, `legs/memrl/measured/power_family_L.json`).
  Binary outcomes with the ceiling respected, 150 tasks, one-sided 0.05, 80 % power, under three stated scenarios
  (success 0.85 / 0.75 / 0.70; repeatability ICC 0.6 / 0.5 / 0.3; a different set of 5 memories moves a task at 50 %
  success by about 10 / 15 / 20 points), with the share of tasks whose shown memories change under the shuffle taken
  from the rehearsal (f = 1.00: on a full-size bank built with MemRL's own retrieval and update rule and dice outcomes,
  every validation task sees a different set of 5 memories under keep and under a within-visit shuffle, mean overlap
  0.10; no effect size is taken from the rehearsal). Minimum detectable keep - shuffle_visit difference with 8
  repeats: 2.5-4.6 points for one pair alone, 3.6-6.4 under Holm over the 12 directed swaps of the recommended design, 4.1-7.1 for the gated reading under Holm (optimistic to pessimistic scenario); central scenario 3.5 alone, 4.9 under Holm, 5.5 gated under Holm. The round-1 design (2 repeats, one permutation) detected 4.7-8.1 points for one pair alone (Holm over 4: 5.9-10.0).
  So the leg is powered for about 5 points per pair in the central scenario; anything smaller is reported as
  "undetermined" or "uninformative", never as "no effect".
- **Registered tests (family L).** Task-level bootstrap, 2,000 draws, paired on the 150 validation tasks, repeats averaged
  per task. For each directed swap X -> Y of the design run:
  1. Home gate: H = keep - shuffle_visit for X on its own bank; one-sided p_H (H1: H > 0).
  2. Swap: S = keep - shuffle_visit for Y on X's bank; one-sided p_S.
  3. "Survives": the intersection-union p = max(p_H, p_S), Holm over the directed swaps run (family L, FWER 0.05).
  4. "Lost": drop = H - S, paired on tasks, one-sided p_drop (H1: drop > 0), Holm over the directed swaps run (family
     L-drop, FWER 0.05).
  Readings, applied in this order: (a) p_H > 0.05: **uninformative for this pair** (the order is not shown to matter at
  home; S is reported but not read); (b) step 3 rejects: **the order matters at home and survives the swap**; (c) p_S > 0.05
  and step 4 rejects: **the order matters at home and is lost after the swap**; (d) otherwise: **matters at home; after
  the swap undetermined**. Never "the order does not matter".
- **Secondary (95 % intervals, no test).** keep - wipe, keep - shuffled, keep - shuffle_bucket, keep - none, keep - own,
  relearn - keep and relearn - own, per directed swap and at home; group means of S (upgrades, downgrades, cross-maker);
  the same-maker minus cross-maker swap contrast on a shared old bank (paired on tasks); the permutation spread (SD of
  success across shuffle repeats beside the SD across keep repeats); in the full design, the in-bank contrasts.
- **Ranking inside the leg (secondary, observational).** Per validation task, among the memories the shuffle arms showed
  (exposure set by a random permutation, not by Q), the concordance of the old Q order with "solved more often when this
  memory was shown" (memory pairs within a task, pooled over tasks; 0.5 = chance; task bootstrap), at home and after each
  swap; and per memory shown at least 3 times in the Q-free arms (wipe and the shuffles), Spearman of old Q against the
  reader's success when shown. Up to 5 memories share each outcome, so both are associations. An experimental per-memory
  ranking needs a one-memory probe (each validation task run with each of its 8 most similar memories alone, 2 repeats:
  2,400 episodes per cell); it is priced in the full design (USD 75 for its 20 cells) and not registered.
- **Not run:** a single global discount (a no-op in MemRL's z-scored mix; README section 3.4).
- **Deviations from MemRL's release** (README section 4): the 350/150 split and 10 passes are set by configuration;
  MemRL's temperatures are not sent (closed models at their default, open models at `config/models.yaml`); thinking is
  off; the evaluate-only entry point, the content freeze for `relearn` and the call log are added by patches.

---

## Part 9. Pilot, pilot-set values, gate and stopping

### 9.1 Pilot design

- Models: Haiku 4.5 and Haiku 5.5. Seed 99 (its own shuffle of each stream).
- Streams: DDXPlus (the gate) and, in the same pilot window, BIRD and DS-1000 (the second-stream check).
- DDXPlus and BIRD at the main build size: 250 write tasks, 500 score tasks × 3 passes (or as set by 9.2), then 200
  probe tasks (150 evaluation + 50 calibration), 2 repeats, 2 extra home repeats, 2 no-memory repeats, and 100 test
  tasks for a trial of the post-swap run.
- DS-1000 at its contingency build size (150 write, 300 score) with the same 200 probe tasks and no test tasks
  (settled point 21); only gate 1's quantity is computed on it.
- The gate and every rule of 9.2 use all 200 probe tasks, because they read home cells only. The 150 / 50 split serves
  a trial of the arms, which is exploratory.
- Item styles: shot (primary; the gate is judged on it) and memprompt (sensitivity).
- **Pilot data (seed 99) are excluded from every confirmatory analysis.** They are reported as the pilot.

### 9.2 Values the pilot may set, and the rule for each

Each rule reads only home cells, visit counts or no-memory runs. None reads a swap result.

1. **Score passes (3 to 6) and exploration (0.3 or 0.5).**
   - Run the score phase of Haiku 4.5's DDXPlus shot bank with exploration 0.3 for 3 passes.
   - After pass 3, and after each further pass, count the items with at least 5 score-phase visits.
   - Stop at the first pass p in {3, 4, 5, 6} at which at least 150 of the 250 items have 5 or more visits.
   - If fewer than 150 items have 5 visits after pass 6: run the score phase again from pass 1 with exploration 0.5,
     with the same pass rule.
   - The main study uses the final (passes, exploration) for every model and both streams.
2. **Headline family.** `ema_grade` stays the headline family if it meets the per-family part of gate 2 (home Cw of
   Haiku 4.5 on DDXPlus ≥ 0.58, with the lower end of its 95% interval > 0.5, in the final pilot run). If it does not,
   the headline family is the first family that meets it in this fixed order: `beta_grade`, `credit`, `tags_self`. If
   none meets it, gate 2 fails.
3. **Second stream.** BIRD stays if, for at least one of the two pilot models (at least half), the memory gain (gate
   1's quantity, computed on BIRD) is at least 3 points **and** its 95% interval excludes 0. Otherwise DS-1000 takes
   its place if it meets the same rule. If neither does, the main study runs on DDXPlus plus the MemRL-code leg, and
   this is logged as a deviation.

Nothing else may be set by the pilot. Item style, items shown, mix weight, repeats, margins, tests and thresholds are
fixed in this file.

### 9.3 The gate (all five must hold; judged on DDXPlus, shot items, final passes and exploration)

| Gate | Quantity | Pass rule |
|---|---|---|
| 1. Memory helps | FS_keep at home (Haiku 4.5, `ema_grade`, mix) − FS_none (Haiku 4.5), paired over the 200 probe tasks | ≥ 0.03, and the 95% paired bootstrap interval (10,000 draws, seed 0) excludes 0 |
| 2. Scores are valid at home | home Cw of Haiku 4.5 for each of `ema_grade`, `beta_grade`, `tags_self`, `credit` (not `visits`, the no-signal baseline) | for at least one family: Cw ≥ 0.58 and the lower end of its 95% interval > 0.5 |
| 3. Repeats agree (a settings check) | share of home cells (both pilot models) whose repeats 1 and 2 differ | always reported; fails only above 0.40 |
| 4. Enough visits and spread | (a) items of Haiku 4.5's bank with ≥ 5 visits; (b) share of probe tasks whose 4 home candidates (Haiku 4.5) do not all have the same mean result | (a) ≥ 150 of 250; (b) ≥ 0.30 |
| 5. Cost as estimated | measured USD per 1,000 paid calls, all pilot calls | ≤ 2 × the estimate from `run.py --estimate` |

Gates 1, 2 and 4 apply to the old model (Haiku 4.5), whose bank is the one swapped; Haiku 5.5's values are reported.
Gate 2 counts the four usefulness families only.

**Operating characteristic of gate 2** (normal approximation, one family): the statistics note's Table 13 gives a
standard error of Cw of about 0.031–0.036 at 100 tasks and 2 repeats, so about 0.025 at 200 tasks. The pass chance is
then about 0.95 if the true Cw is 0.62, 0.79 at 0.60, 0.50 at 0.58 and 0.12 at 0.55. With four families eligible the
chance is higher.

### 9.4 Actions after the gate

| Result | Action |
|---|---|
| All five pass | Fill in Part 0.1 (pilot-set values, hashes), freeze this file, deposit it on the public time-stamped registry (header), record the identifier, then make the first paid main-run call. |
| Gate 4(a) fails after the full rule of 9.2 (both exploration values) | Stop. The finding becomes "scores are weak even before a swap" (the smaller paper). |
| Gate 2 fails, or gate 4(b) fails, with gate 4(a) passing | One re-run of the score phase with 6 passes and the same exploration. If it fails again: stop, as above. |
| Gate 1 fails on DDXPlus | Treated like gate 2. |
| Gate 3 fails (disagreement above 0.40) | Check the settings (thinking off, sampling values, host pinning). Fix configuration errors only and re-measure on the home cells. No change to the build. |
| Gate 5 fails | Re-estimate the budget and get the owner's approval before the main run. Not a scientific stop. |

At most one re-run of the build is allowed beyond the pass-and-exploration rule of 9.2.

### 9.5 Stopping rule for the main study

- There is no interim look at any swap result, and no stopping for significance or futility.
- Each stream's grid is run to completion. No confirmatory analysis is computed until every probe table of both
  streams is complete and the analysis code is committed; the commit is recorded in Part 10.
- Allowed while collecting data: call errors, parse failures, refusal and token-limit rates, costs, repeat
  disagreement, and home-only numbers (home Cw, visit counts).
- If the budget cap would be reached, cut in the master plan's order: L4, the fifth pair, the second wording, L3 down
  to two pairs. The full DDXPlus grid, the self-swap reference and the content-only control are never cut. A cut is logged as
  a deviation; an analysis whose data were cut is reported as not run.
- Model retirement: Part 1.7.

---

## Part 10. Deviations log

Every change after the freeze gets a dated row with its reason. The paper reports every registered analysis and every
deviation (Hofman et al. 2023; Bertinetto et al., eds., 2021).

| # | Date (UTC) | Part affected | What changed | Why | Decided by | Data seen before the change? |
|---|---|---|---|---|---|---|
| | | | | | | |

Commit of the analysis code used for the confirmatory analysis: ____ (filled when that analysis is run).

---

## Part 11. Additions registered before any paid main run

Adopted by the research manager on 23 Nov 2026 (`docs/MASTER_PLAN.md` 2.11) and revised the same day after the theory
review (round 1, Reviewer 3). Reasoning and proofs: `docs/theory_note.md` and `docs/forecast_and_sequential_note.md`;
paper: the swap-day section and the appendix (revision 2: the decomposition and the forecast are appendix items;
ready-to-paste text `docs/handover/theory_round2.md`). This Part replaces the drafts `docs/theory_prereg_text.md` and
`docs/forecast_sequential_prereg_text.md` wherever they differ. Code: `msr/theory.py`, `msr/forecast.py` and
`msr/sequential.py`; their constants are registered in 11.5. In this study all three read only the probe tables, the
no-memory runs and the build's no-memory answers. On a real swap day they are not free: the 0.75 question of 11.4
needs the old model's results on every check task (8 old-model calls per task, before it retires) and the forecast
needs 1,150 no-memory calls (11.3); the break-even question of 11.4.0 needs none of the old model's calls
(`msr.sequential.swap_day_calls`, `msr.forecast.forecast_calls`; the cost table of Part 6.4). Pilot data never enter
them.

**Status: confirmatory-secondary.** The transfer decomposition (family T, 9 tests, Holm at 0.05) and the forecast
(family F, 1 test at one-sided 0.05) are each their own family (Part 5.4). Neither is part of the 12 primary tests of
Parts 3 and 5.1 or of P1–P4, and no result in this Part changes a primary decision. The keep-or-drop decision (11.4)
has no hypothesis family: its primary form is the operator's break-even at margin 0 (11.4.0); the 0.75 question is the
hard case (11.4.1–11.4.9); the error control of each is proved and checked and its rates are reported, and the
information lower bound (11.4.10) is a reported quantity with its four qualifiers.

**What changed in the revision, and why (all before the freeze).** (1) "Law" and "mediation" are withdrawn: the
decomposition is an identity, and its restriction L = 0 is a linear-transfer specification, which a monotone but
non-linear relation between the two models breaks even when the scores know nothing about the reader (11.2.1).
(2) γ̂ uses the owner's two time-separated home sessions, so dependence between repeats inside a session (caching)
cannot bias it; the specification test is in product form and needs no ratio; definedness of γ̂ is decided on data
no estimate uses; intervals are Fieller sets with the two-way variance of Part 4.1. (3) Family T has separate members
(no min of two p-values). (4) The keep-or-drop decision compares the reader with the owner's stored result on the same
task, so no estimated home value is treated as known; the old plug-in rule is a reported comparison only. (5) The
forecast's label-permutation tests are replaced by one test of incremental value.

**What changed in revision 2 (24 Nov 2026, before the freeze; review round 2, R6, the AC audit N2–N6 and N14).**
(1) The swap-day decision is re-centred on the operator's break-even (D6): "does keeping still beat wiping?" at margin 0,
a one-sample betting test on the new model's checks with no home value (11.4.0), in a ranking form and in a decision form
on first-shown success; the paper leads with the decision form. (2) The 0.75 question keeps its paired test but its
guarantee now states, and the code enforces, a positive home signal (the single flag of Part 2.4, as an
intersection-union condition) and a fresh home result for every task drawn (the test stops when the stored home results
run out); the old model's results on the check tasks are charged as calls made before it retires (11.4.4). (3) The bound
is stated with its four qualifiers (observation scheme, margin, signal, error levels), as an estimate with a bootstrap
interval, as curves against the margin and the signal, and extended to adaptive choice of cells (11.4.10). (4) The
decomposition leaves the paper's body (D5): an in-sample consistency check, compared with R = γ̂ and R = ρ̂ (descriptive),
without "parameter-free" or "accounts for"; "specification supported" no longer needs a win over "no change"; the
registered group readings are written by the code; γ̂ is printed only with its Fieller interval (11.2). (5) The forecast
uses the single flag, controls for which model of a maker is the newer one, and lends its test to P1 (11.3). (6) Every
interval of this Part uses the variance of Part 4.1 (`msr.metrics.robust_variance`) and every home-signal label the one
flag (`msr.metrics.home_signal_flag`).

**What changed in revision 3 (24 Nov 2026, before the freeze; review round 3, R7, decisions E1, E3, E5).**
(1) The home-signal flag gates BOTH decisions of the 0.75 question, as the code always did: the text said a drop needed
no sign check, which is false (a reversed home order with θ = 1 drops in 1.000 of streams without the gate) (11.4.2,
11.4.4, 11.4.5). (2) The information bound bounds the EXPECTED number of checks: measured means are compared with it and
medians are reported apart; the exact bound is reported beside the second-order approximation where the chance table is
known, and on real data the approximation is reported with a guaranteed floor (11.4.10). (3) The random-order condition
is stated where the tests are defined and enforced by the replay (11.4.0, 11.4.6). (4) Every statistic of this Part that
pools more than one owner clusters items by WRITE TASK within stream (ruling E1; 11.1, 11.2, 11.4.10). (5) The forecast's
fragility is stated (11.3.8). (6) Names (ruling E3): "retained agreement" (a correlation-type measure; formerly "retained
order"); "not estimated (reader's spread below z = 2)" (formerly "not identifiable"). (7) Mismatches fixed: the replay's
cap is 200 tasks per order (11.4.6); the old-model calls for the median stop are 6,644 (11.4.4).

### 11.0 Symbols

The drafts and the code use letters that this file already uses for something else. This file uses:

| Here | In the drafts or the code | Meaning |
|---|---|---|
| V(τ), V_home, V_swap | V (theory); "N" in the first brief | signed validity (Part 2.2) |
| W(τ), W_home, W_swap | W | outcome spread (Part 2.2) |
| φ(τ) | A_τ (paper), a(τ) (`msr.sequential.task_stat`) | per-task agreement (11.1) |
| φ_h(τ) | A^home_τ | the owner's stored home result on task τ in the same form (mean of home repeats 1–2) |
| d(τ) | d_τ (`margin0_first_shown`) | y(keep's first-shown candidate) − y(wipe's first-shown candidate), one check each (11.4.0) |
| θ | R_V (older theory files), T (older forecast files) | the retained ranking signal of Part 2.4 |
| γ, γ̂ | γ ("β" in the first brief) | score-free transfer slope |
| C_on, C_oo | C_on, C_oo | Σ Δȳ_s^(12) Δȳ_t and Σ Δȳ_s^(12) Δȳ_s^(34) (11.2.2) |
| Q | spec_Q | V_swap C_oo − C_on V_home, the specification statistic |
| Δ_L | gap_cw (G in the law draft) | the decomposition's gap in Cw; G stays the keep–wipe gap of Part 2.11 |
| ν_i | U | unbiased square of a cell mean (sensitivity estimator only) |
| Z_A, Z_B | x_owner, x_reader | no-memory success on the predictor tasks; X stays P2's quantity |
| succ_A, succ_B | p_A, p_B | success shares in the error-consistency comparison |
| D_k, D_d | D (paired statistic) | φ − 0.75 φ_h and φ − 0.25 φ_h (11.4) |
| ξ, ω | u, m | the decision's observations and thresholds on the [0, 1] scale |
| Ψ_t | K_t | wealth; K(τ) stays the candidate set |
| η_d | λ_d | bet sizes; λ stays the discount weight |
| K* | kl_least_favourable | the smallest per-task Kullback–Leibler divergence of the lower bound (11.4.10) |
| κ(x) | floor_kappa | 1 − x − x²/4, the factor of the guaranteed floor of the bound (11.4.10) |

### 11.1 Shared quantities (one definition for all three additions)

- **Per-task agreement.** For a task τ with n candidates that have a valid result (n = 4 for every task kept by rule
  1.6): φ(τ) = V(τ) / M_n, with V(τ) the signed validity of Part 2.2 and M_n = ⌊n/2⌋·⌈n/2⌉ (M_4 = 4). φ lies in
  [−1, 1]; a task with n < 2 has no value. φ and V are linear in the outcomes, so outcome noise and dependence
  between repeats do not bias their means. Computed by `msr.sequential.task_stat` (φ) and `msr.metrics` (V).
- **θ is the retained ranking signal of Part 2.4**, defined once in `msr.metrics` (`theta_from_sums`, with its
  inference `theta_tests`); the additions import it. `msr.theory` sums V over the pairs of both streams; that equals
  Part 2.4 within a stream and over both streams whenever the streams keep the same number of evaluation tasks; if
  they differ, both values are reported and the decomposition's tests use the pair sums of 11.2. A test checks the
  agreement (`tests/test_round1_revision.py`).
- **Reportability of θ:** the one flag of Part 2.4 (`msr.metrics.home_signal_flag`: the owner's signed validity on its
  calibration tasks at least 2 SEs above 0). No module of this Part keeps a rule of its own (the forecast's former
  same-task 4-SE rule and the replay's former truth-half 4-SE rule are withdrawn).
- **Intervals for θ and γ:** Fieller sets that invert the variance of Part 4.1 (`msr.metrics.robust_variance`, the
  two-way delete-one-cluster jackknife: tasks pooled over orders, one component per (owner, reader, stream)), as the
  union of the raw two-way and the task-only sets, exactly as `msr.metrics.theta_tests` does for θ; "unbounded" when the
  denominator is not clearly away from 0.
- **Item clusters (revision 3, ruling E1).** An item is "<write task>@<owner>", and every owner's bank is written from
  the same write tasks, so for a probe task every owner shows the same four write tasks. Every statistic of this Part
  that pools more than one owner (family T's group members, the pooled family differences T2, the plug-in bound of
  11.4.10) clusters items by WRITE TASK within stream: all owners' versions of a write task are one cluster
  (`msr.theory.ITEM_CLUSTER = "write_task"`, `write_task_key`). For a statistic of one owner this is the same partition
  as the former coding by identity within (owner, stream), so per-swap results do not change. The former coding is
  reported beside family T as a sensitivity (`se_owner_coding`, `p_raw_owner_coding`).
- **Link to R.** On the same tasks R = θ · W_home / W_swap exactly (Part 2.2: Cw − 1/2 = Σ V / (2 Σ W)): R moves with
  the two models' outcome noise and θ does not (the reason θ is the headline).

### 11.2 Addition 1a: the transfer decomposition

**11.2.1 Statement.** For owner s, reader t and a candidate pair, let a = sgn(x(i) − x(j)) and δ_m the true difference
of model m's success chances. The transfer slope is γ = E[δ_s δ_t] / E[δ_s²] (score-free). Let L = E[a (δ_t − γ δ_s)].
Then, identically, E[a δ_t] = γ E[a δ_s] + L, so θ → γ + L / E[a δ_s]. L = 0 means: the part of the reader's usefulness
difference that is not a linear function of the owner's is uncorrelated with the sign of the score difference;
equivalently, θ (an instrumental-variable slope with instrument a) equals γ (the least-squares slope). It is a
specification restriction (Hausman 1978), NOT mediation: if the reader's chance is an increasing function of the
owner's, cell by cell, and the scores see only the owner, θ − γ = E[(s − γ) a δ_s] / E[a δ_s] with s the local slope,
which in general is not 0 when the function is not linear (sizes over five owner worlds: within one logit of the
owner |θ − γ| < 0.035 in three of them and 0.10–0.15 when tasks are hard or easy; 0.07–0.11 for a reader 2.5 logits
weaker, three times sharper or threshold-like in our two main worlds; theory note, round 2 and Remark 3a). The weighted concordance is
Cw = (1 + Γ)/2 with Γ the pooled within-task Gini correlation (Schechtman and Yitzhaki 1987). The classical pieces are
cited, not claimed; what is ours is the use (the confound of R; the consistency check). Proofs: `docs/theory_note.md`,
Results 1–4.

**11.2.2 Estimators.** For owner s, reader t ≠ s and family f, per stream and over both streams (sums over both
streams), over the evaluation tasks kept by rule 1.6 in both cells. Δȳ_s^(12): differences of the owner's home repeats
1–2; Δȳ_s^(34): of the owner's home repeats 3–4 (the second home session, from the home cell); Δȳ_t: of the reader's
repeats 1–2.
- V_home = Σ a Δȳ_s^(12), V_swap = Σ a Δȳ_t; W_home, W_swap; θ̂ = V_swap / V_home (Part 2.4).
- **γ̂ (primary, cross-session)** = C_on / C_oo, C_on = Σ Δȳ_s^(12) Δȳ_t and C_oo = Σ Δȳ_s^(12) Δȳ_s^(34), over the pairs
  where both owner sessions and the reader have a valid result on both candidates. C_oo is unbiased for Σ δ_s²
  whenever the two sessions are independent, even if repeats inside a session are not. In a home row (reader =
  session 3–4) γ̂ = 1 exactly.
- **γ̂_within (sensitivity)** = Σ Δȳ_s^(12) Δȳ_t / Σ d̂²_s, d̂²(i, j) = ν_i + ν_j − 2 ȳ_i ȳ_j, ν_i = ȳ_i² − var_i / n_i:
  unbiased only for independent repeats inside a session. **A2 check:** mean d̂²_s minus mean Δȳ_s^(12) Δȳ_s^(34) per
  pair, reported per owner (0 in expectation; positive under within-session dependence or drift between sessions).
- ρ̂ = S_on / √(S_oo S_nn) and R_std = θ̂ √(S_oo / S_nn) (within-session U-statistics; descriptive; |ρ̂| may exceed 1).
- **Specification statistic** Q = V_swap C_oo − C_on V_home (zero in expectation under L = 0, whatever the strength of
  the denominator); the gap in Cw: Δ_L = Q / (2 C_oo W_swap) = C_swap − (1/2 + γ̂ V_home / (2 W_swap)).
- **Definedness of γ̂:** decided on the owner's CALIBRATION tasks, which no estimate of the decomposition uses: γ̂ is
  "defined" when Σ Δȳ_s^(12) Δȳ_s^(34) over the owner's calibration tasks (all orders of the level) is at least 2
  standard errors above 0 (`msr.metrics.calibration_z` with `THETA_CAL_MIN_Z` = 2, the z rule of Part 2.4's flag
  applied to the cross-session product); θ's label is Part 2.4's flag itself. Otherwise "undefined: … too weak on the calibration tasks", and the Fieller set is
  printed as computed (often unbounded); no point value enters a statement. Reason: a rule on the same tasks selects
  on the estimate's own noise (theory note, Result 4: median γ̂ 0.23 against a true 0.60 among the draws the earlier
  rule admitted in a weak world). If no pair of a swap has both owner sessions, γ̂ is "not estimable" for that swap.

**11.2.3 Intervals.** All on per-(cell, task) influence values with the variance of Part 4.1
(`msr.metrics.robust_variance`): Fieller intervals for θ and γ (11.1) and for the weighted gap of each group (95% beside
T1-diff, 90% beside T1-eq, written in the lo/hi columns); normal tests for Q and its group sums; a delta-method SE for
Δ_L where γ̂ is defined. The task bootstrap within each stream order is reported
beside them as a cross-check only. The decomposition treats items as sampled, because a finite bank makes L non-zero
by chance (SD 0.10–0.12 in θ for 80-item banks in simulation).

**11.2.4 Tests: family T (Holm at 0.05 over nine SEPARATE members).** Headline family, both streams. Groups g: the
three groups of Part 3 (same-maker upgrades, same-maker downgrades, cross-maker swaps). An appendix item since
revision 2: an in-sample consistency check of θ̂ against γ̂ on the same tasks (γ̂ is a fitted slope that uses the
reader's results), not a prediction.
- **T1-diff(g)**: H0: Σ_{k∈g} Q_k = 0 (the linear specification holds for the group, denominator-weighted); two-sided
  normal p from the two-way SE of the stacked influence values (rows share tasks; rows of every owner share write
  tasks, 11.1).
  Point value: Δ̄_L(g) = Σ Q_k / Σ 2 C_oo,k W_swap,k.
- **T1-eq(g)**: H0: |Δ̄_L(g)| ≥ 0.02 against H1: |Δ̄_L(g)| < 0.02, by two one-sided tests on Σ Q ∓ 0.02 Σ 2 C_oo W_swap
  (Fieller form, no division); p_eq = the larger of the two (intersection-union).
- **T2(f)**, f ∈ {beta_grade, tags_self, credit}: pooled θ (Σ V_swap / Σ V_home over all swaps, both streams) of f
  minus that of the headline family; H0: 0; two-sided; two-way variance.
- Each member has its own p-value and its own Holm threshold. The former device (T1(g) entering with min(p_eq, p_diff),
  both claims allowed) is withdrawn: its familywise error reached 0.1445 in the matching configuration, against 0.0499
  with separate members (`docs/power/fwer_holm.py`, devices E and E-new).
- **Readings, fixed now (each at its own Holm threshold).**
  - **Specification supported in g:** T1-eq(g) rejects. (Until revision 2 it also required a mean absolute error below
    that of "no change"; withdrawn: "no change" uses no reader data, and the error comparisons measure noise, not an
    account. The comparisons with R = γ̂, R = ρ̂ and "no change" are reported with paired bootstrap intervals, 11.2.5.)
  - **Specification fails in g:** T1-diff(g) rejects **and** |Δ̄_L(g)| ≥ 0.02. **Departure within the margin:** T1-diff(g)
    rejects and |Δ̄_L(g)| < 0.02.
  - Otherwise **inconclusive**. The code writes these readings (`msr.theory.group_reading`; rows `T1_reading_<g>`
    of decomp_summary.csv, with the 90% Fieller interval of the weighted gap).
  - The sign is read only as "the scores' signal sits where transfer is better (Δ̄_L > 0) or worse (Δ̄_L < 0) than
    the variance-weighted average". Candidate causes are listed, never chosen from the sign alone: leakage (the scores
    see the reader's own item effects), a non-linear relation between the two models (a weaker reader pushes Δ_L up; a
    sharper or threshold-like reader pushes it down), owner-specific quirks, task-specific usefulness an item-level
    score cannot see, or drift between the owner's two sessions.
  - A T2 rejection is a family-specific failure of the linear specification, read the same way.
- **P3 and T2.** On the same tasks R = θ · W_home / W_swap, and W does not depend on the family. So P3 (the tags keep
  less) and the decomposition (no difference between families) predict opposite things for `tags_self`. Both stay
  registered; at most one of them can come out as predicted.

**11.2.5 Reported, not tested.**
- Per swap: θ̂ and γ̂ with Fieller intervals and statuses, γ̂_within, the A2 check, ρ̂, R, R_std, the spread ratio,
  Q with its z and two-sided p, Δ_L with its SE. The share of swaps whose own Q test rejects at 0.05 (descriptive: the
  swaps are dependent).
- The decomposition's mean absolute error against three references: no change; R = γ̂ (spreads ignored); R = ρ̂ (ρ̂:
  the cross-model correlation of the within-task usefulness differences, corrected for both models' outcome noise);
  each as a difference with a joint task-bootstrap interval (`mae_decomp_minus_<reference>`), descriptive. In our
  linear worlds the decomposition ties R = γ̂ when owner and reader are equally noisy and loses to "no change" when the
  reader is less noisy (theory note, round 2); the paper says so.
- γ̂ is printed only with its Fieller interval. It is compared with a simulator's truth only on the full-size simulated
  study (where it tracks the truth: mean difference −0.013 over 56 swaps, every interval covering the truth), never on
  the 4-model practice study (whose owner denominators rest on 56 tasks per order).
- The least-squares line of C_swap − 1/2 on Ĉ_swap − 1/2 over swaps, labelled "attenuated by noise in the prediction".
- Specificity: a model-label permutation of the mean absolute error over all 8! relabellings (descriptive).
- Leave-one-model-out: the mean gap and the mean absolute error without each model's 14 swaps.
- The noise dials: R, θ̂ and the spread ratio with the reader (or the owner) cut to its first repeat.
- The former equivalence row on the delta-method mean gap (`tost_gap_cw_margin_0.02`), as a cross-check of T1-eq.

**11.2.6 Exploratory (labelled as such).** The Gaussian forms (their misses for 0/1 outcomes depend on the
data-generating process: +0.02 to +0.09 for the arcsin form, +0.006 to +0.03 for (1 + r)/2 over seven processes); the
home ceilings; the break-even number of fresh checks (Bühlmann credibility; illustrative).

**11.2.7 What counts against the decomposition's linear specification.** "Fails" (T1-diff) in any group; a T2
rejection. Reported but not decisive: the comparisons with the three references, the specificity permutation and
leave-one-model-out. A rejection says only that the scores' signal sits where transfer is better or worse than
average (leakage, task-specific usefulness transferring at another rate, curvature, owner quirks, session drift).

### 11.3 Addition 1b: the pre-swap forecast (reported in the appendix)

**11.3.1 Predictor data.** For each model and order: every graded answer given with **no memory item** on the 250 write
tasks, in the no-memory run of the 500 score tasks, and in the no-memory probe repeats 1–2 of the 100 calibration tasks.
Evaluation tasks are never used, so predictors and targets share no task.

**11.3.2 Predictors per ordered pair** (A = owner s, B = reader t), per stream from counts summed over the three orders,
then the mean over the streams: error consistency ec (Cohen's kappa on the right/wrong patterns, every run of A against
every run of B on the same task; Geirhos et al.); raw agreement; no-memory success Z_A and Z_B; gap = Z_B − Z_A; abs_gap;
same_maker.

**11.3.3 Targets per ordered swap** (headline family; pooled over the orders, then over the streams with equal weight):
θ (primary; labelled by the one flag of Part 2.4, `owner_home_flag` → `msr.metrics.home_signal_flag`; the former
same-task 4-SE rule is withdrawn); C_swap; D; R.

**11.3.4 Models** (ordinary least squares with an intercept; no tuning; all descriptive): grand_mean, same_maker, gap,
same_gap (the F1 controls: same_maker, Z_A, Z_B, abs_gap) as baselines; ec, ec + gap and ec_same_gap (ec + the F1
controls) as forecasts; agree, abs_gap, Z_A, Z_B alone; subsample_20 (5 calibration tasks × 4 candidates per bank
after the swap, 200 draws) as the post-swap baseline.

**11.3.5 Validation.** Leave one model out (fit on swaps involving neither the owner nor the reader m; predict every swap
involving m; each swap predicted twice). Because that still sees the other model of every predicted swap, same_gap and
ec_same_gap are also validated leaving BOTH models out. Out-of-fold R² against the grand mean fitted in the same fold;
Spearman; mean absolute error; differences forecast minus baseline (ec_same_gap − same_gap is the out-of-fold
counterpart of F1) with bootstrap intervals.

**11.3.6 Intervals.** Tasks resampled per stream with the task-id cluster draws of Part 4.1 for the targets and their own
seeded draws for the predictor tasks; B = 10,000; 95% percentile intervals. Each target is one owner's; the intervals
hold the write tasks (and so the items) fixed, so a write-task component shared by owners is not in them; they are
descriptive (11.3.4).

**11.3.7 Reliability of each predictor** (reported): between-pair SD; mean bootstrap SE; reliability; split-half
correlation and its Spearman–Brown value; each model's test-retest kappa (a ceiling for ec).

**11.3.8 Test: family F, one test (one-sided, α = 0.05, no Holm).**
- **F1, incremental value:** does ec forecast θ beyond the same-maker flag, capability and which model of a maker is
  the newer one? Statistic: the partial correlation of θ and ec given Q = [1, same_maker, Z_A, Z_B, abs_gap,
  owner_newer, reader_newer] over the swaps of the core grid (the 8 core models, 4 makers, 56 swaps; ruling of 24 Nov
  2026, Part 7) with θ flagged "defined" (the t of ec in OLS θ ~ Q + ec). H1: > 0. (The
  two newer-model indicators were added in revision 2: review R6 found a level of 0.064 in a world where θ depends on
  whether the owner is the newer model of its maker; with them the level there is 0.059 over 8,000 worlds, and 0.060
  in a world where ec also carries that position, against 0.118 without them.)
- **Null by double semi-partialling** (Dekker, Krackhardt and Snijders 2007): ec is residualised on Q; the models of the
  residual ec array are relabelled within makers and as whole makers among makers of equal size (8 models in 4 makers
  of 2: 2^4 × 4! = 384 relabellings, enumerated; every relabelling keeps each pair's same-maker flag); the statistic is
  recomputed with θ still controlled for Q. p = the share of relabellings with a statistic at least the observed one
  (identity included). The DSP with all 8! relabellings is reported as a sensitivity analysis.
- **Testability.** The smallest attainable p is (relabellings that leave the residual array unchanged) / |G|, at least
  1/|G|; a test whose smallest attainable p exceeds 0.05 is "not testable" (with makers of 2 models this needs at
  least 6 models; 4 models from 2 makers give 8 relabellings).
- **Pass:** testable, p ≤ 0.05 and the statistic above 0. **Fail:** testable and not a pass.
- **Why this test** (the former F1/F2 permuted model labels of the ec array, a Mantel test of "the two arrays are
  related at all"): with ec and θ both carrying the maker structure and ec adding nothing, the former test rejected in
  0.47 of 1,500 simulated worlds. With the controls of revision 2 the level was 0.050–0.059 in our null worlds
  (maker, capability, maker-pair and model effects) and 0.059 in review R6's; power at 8 models 0.57–0.68 for an
  incremental correlation of 0.3 and 0.98 for 0.6. Its known limit: a capability effect curved in both arrays raises the
  level to about 0.12. Rank-based and precision-weighted statistics were tried and not adopted (levels up to 0.086 in
  R6's worlds, or weights that would have to be estimated). Tests: `tests/test_forecast.py`.
- **What F1 detects, and its fragility (revision 3, review R7 W11; `docs/power/forecast_r7_w11.json`, maker-preserving
  relabellings, one-sided 0.05).** F1 detects association at the pair level and at the model level alike. ec is
  symmetric and Q treats owner and reader alike, so the test reads θ only through (θ_st + θ_ts)/2; the relabellings
  move whole models, so a property of single models that raises both ec and θ counts as "incremental value": in a world
  with no pair-level link (W8) it rejected in 0.085, 0.17 and 0.45 of 4,000 worlds as that property grew (0.06 without
  it; up to 0.70 when it acts through both models). Owner and reader fixed effects in Q remove that exactly (0.046–0.056
  in every world above except the curved one), at a cost: power at a partial correlation of 0.3 with pair-level noise
  0.60 → 0.48 (0.99 → 0.94 at 0.6; no loss when half the noise is at the model level, 0.67 → 0.69); 10 more degrees of
  freedom (rank 17 of Q at 8 models). A capability effect curved in both arrays (W5 'square') gives 0.106 with the
  registered controls and 0.102 with fixed effects: no linear control removes it. Dropping the owners the flag drops does
  not raise the level (0.050–0.062). A pass therefore reads "ec and θ move together beyond same maker, capability and
  the newer/older position", not "a pair's own error consistency predicts that pair's θ". The test with owner and reader
  fixed effects is reported beside F1 (`pair_incremental_test(..., fixed_effects=True)`). Its status (registered
  secondary or exploratory) is the research manager's ruling of revision 3; the theory worker recommends exploratory.
- **P1 uses the same test** (Part 7 governs P1): `msr.forecast.pair_incremental_test(x, y, owners, readers, makers,
  controls)` with x = agreement and the controls of F1, on the same core grid; the extension pairs enter neither.
- **Capability against maker** (Part 8.2, descriptive): `forecast_capability.csv` (per swap: θ and retained agreement
  with intervals, the capability gap, ec, same_maker, the newer-model indicators, the flag) and
  `forecast_capability_regression.csv` (θ and retained agreement on [1, same_maker, gap, abs_gap, ec], task-bootstrap
  intervals, F1's maker-preserving p for ec).
- **Cost:** 950 new-model and 200 old-model no-memory calls per swap day (`msr.forecast.forecast_calls`), none of them
  a check of a memory item; the paper says so in the same paragraph as the forecast.
- **F0 (descriptive):** the plain Spearman(ec, θ), with no p-value.

**11.3.9 Wording, and what counts against the forecast.** "The memory-free check forecasts the retained ranking signal
beyond the maker flag and capability" is said only if F1 passes **and** ec_same_gap has a higher out-of-fold R² than
same_gap with a 95% interval of the difference that excludes 0. If subsample_20 has a lower mean absolute error, the
paper says so in the same sentence. Otherwise: "no evidence that a memory-free check forecasts the retained ranking
signal beyond the maker flag and capability". A failed test is never reported as "the check does not work".

### 11.4 Addition 2: the keep-or-drop decision on the swap day

**11.4.0 The primary swap-day question (revision 2): does keeping still beat wiping? (margin 0)**
- **Decision form (the paper leads with it):** per fresh-check task, d(τ) = y(keep's first-shown candidate) −
  y(wipe's first-shown candidate), one check each of the new model (no check where both rules show the same
  candidate: d = 0); keep's and wipe's first-shown candidates follow the arms of Part 2.6 (`msr.sequential.shown_pair`).
  H0: E[d] ≤ 0. **Ranking form (reported beside it):** φ(τ) from one check of every candidate; H0: E[φ] ≤ 0 (the old
  order no better than a random order; note that a random order is not wipe).
- **Test:** the registered mixture betting test of 11.4.4 on (d + 1)/2 or (φ + 1)/2 with boundary 1/2; KEEP when it
  rejects, WIPE when the mirror test (H0: E ≥ 0) rejects, otherwise undecided at the cap (`decide_margin0`).
- **Guarantee and its conditions:** (i) the bank is fixed, so the target is the bank's value; (ii) check tasks are drawn
  independently and AT RANDOM BY THE HARNESS from a fixed held-out pool: checks must be drawn at random by the harness,
  not chosen or ordered by the operator (live traffic in arrival order or checks grouped by topic break the guarantee);
  (iii) every check is a fresh call; (iv) the statistic is bounded. Then P(KEEP) ≤ α whenever keeping is in truth no
  better than wiping (decision form) or the old order no better than random (ranking form), at every stopping time, by
  Ville's inequality. No result of the old model is used. Condition (ii) is load-bearing: with the reader exactly at
  the boundary and the tasks checked in topic blocks (200 tasks with a positive keep-minus-wipe value, then 200 with a
  non-positive one) the test kept falsely in 0.749 of 1,000 streams (review R7, W8) and in 0.961 of 1,000 in our hetero
  world, against 0.024 with the harness's random order (`sequential_order.csv`). The replay draws the order itself and refuses a given order (`NonRandomOrderError`)
  unless it is run as a labelled diagnostic (`diagnostic=True`, no guarantee).
- **Checks** (reported; `sequential_margin0.csv`): the exact boundary in four worlds (the reviewer model, the
  heterogeneous model, review R6's simulator, the study's own tables), 2,000 streams each, error by every task up to
  3,000; pass: at most α + 2.33 Monte-Carlo SE. Tasks and checks needed (median, mean) at θ = 0.5 and 1 times the
  study's signal, beside the lower bound of 11.4.10 at margin 0.
- **Cost:** 2 new-model checks per task where the arms differ (decision form) or 4 per task (ranking form); no
  old-model call (`msr.sequential.swap_day_calls`).

**11.4.1 Unit.** One fresh-check task: one probe task with every candidate checked once with the reader (one
program-graded result each). One task = 4 checks; budgets are stated in tasks, with checks given once as 4 × tasks.
Its values: φ(τ; y) from the reader's single checks, and φ_h(τ) from the owner's stored home results on the SAME task
(mean of its home repeats 1–2; the probe table holds them for every probe task). Tasks, not pairs, are the independent
units.

**11.4.2 Thresholds** (fixed now; the 0.75 question is the hard case since revision 2). KEEP needs θ > 0.75 (no
material loss: the margin of PC1, Part 6.1) and a positive home signal; DROP needs θ < 0.25 and a positive home signal
(revision 3: the flag gates both decisions, as the code does). They enter through the
paired statistics D_k(τ) = φ(τ) − 0.75 φ_h(τ) and D_d(τ) = φ(τ) − 0.25 φ_h(τ); no estimate of the home signal is ever
treated as a known constant. Cells whose home signal fails the reporting flag of
Part 2.4 (the owner's calibration tasks, ≥ 2 SEs) are replayed but reported apart ("home signal too weak") and left
out of the headline rates.

**11.4.3 Error level.** α = 0.05 for each of the two errors (a false keep and a false drop).

**11.4.4 Test martingales and the guarantee.** ξ = (D + 1 + c) / (2 + 2c) ∈ [0, 1] with c = 0.75 (KEEP) or 0.25 (DROP);
boundary ω = 1/2.
- KEEP test, H0: E[D_k] ≤ 0: wealth Ψ_t = (1/20) Σ_{d=1..20} Π_{i≤t} (1 + η_d (ξ_i − 1/2)), η_d = d/40 (each factor ≥ 0.75).
- DROP test, H0: E[D_d] ≥ 0: Ψ_t = (1/20) Σ_d Π_{i≤t} (1 − η_d (ξ_i − 1/2)).
- A test rejects at the first t with Ψ_t ≥ 1/α.
- **Guarantee (paper: Proposition "Error control for the 0.75 question"; its proof in the appendix).** Conditions:
  (i) fixed bank; (ii) tasks i.i.d. from the stream, drawn at random by the harness (11.4.0); (iii) fresh reader
  checks; (iv) a FRESH home result for every task drawn (never a stored result used twice); (v) the one flag of Part 2.4,
  on calibration tasks disjoint from the stream, gates BOTH decisions. Then the pairs (φ, φ_h) are i.i.d. (dependence
  inside a task is allowed), D is bounded with mean Ā_swap − c Ā_home, Ψ is a nonnegative supermartingale under H0, and
  KEEP = (the paired KEEP test rejects) AND (the flag is positive), DROP = (the paired DROP test rejects) AND (the flag is
  positive), are intersection-union rules (Berger 1982). With α_flag the flag's size at Ā_home = 0 (0.015–0.032 with 100
  and 24 calibration tasks; asymptotically 0.023), at every stopping time: if Ā_home > 0, P(KEEP) ≤ α whenever
  θ ≤ 0.75 and P(DROP) ≤ α whenever θ ≥ 0.25; if Ā_home ≤ 0, P(KEEP or DROP) ≤ α_flag. So a keep is wrong with
  probability at most max(α, α_flag) whenever θ ≤ 0.75 or Ā_home ≤ 0, and a drop likewise whenever θ ≥ 0.25 or
  Ā_home ≤ 0. Without the gate on KEEP a reversed home order keeps in 0.999 of streams (R6's counter-example); without
  the gate on DROP a reversed home order with θ = 1 (Ā_swap = Ā_home < 0, so E[D_d] < 0) drops in 1.000 of 1,000
  streams in review R7's world (W6; Ā_home = −0.12) and in 0.999 in ours (Ā_home = −0.10; with the gate: 0 keeps, 0
  drops, 1.000 not testable; `sequential_gate.csv`, part `drop_counter_example`); without (iv) a 300-task store re-used
  gives false keeps of 0.11 by 3,000 tasks. The code enforces all three: "not testable: home signal not shown positive"
  (neither KEEP nor DROP), "home table exhausted" (the stream stops) and the harness's random order. The text before
  revision 3 said a drop needed no sign check; the code never allowed it.
- **What this means on a real swap day:** the old model's per-candidate results on every check task must be collected
  BEFORE it retires: 4 candidates × 2 repeats = 8 old-model calls per stored task, plus the flag's calibration tasks
  (100 × 4 × 2 = 800), charged in the cost table (`msr.sequential.swap_day_calls`). The store must be as large as the
  test may need: for the median stop at the practice study's signal (730.5 tasks, `sequential_curve.csv` at θ = 1),
  8 × 730.5 + 800 = 6,644 old-model calls (about 6,650; Part 6.4 gives the same number).
- Comparison rules, reported but never used for a decision: `sequential_plugin` (thresholds 0.75 and 0.25 times the
  owner's estimated home mean: valid only if that mean were known; with an estimated one its false keeps exceed α near
  the boundary on long streams) and `sequential_split` (an α/2 betting bound on Ā_home from the owner's home tasks and
  the swap confidence sequence at α/2; valid by a union bound, much slower).
- The bet was chosen on simulated data before any real data existed; the predictable plug-in and aGRAPA bets
  (truncated at 0.5/ω or 0.5/(1 − ω)) are sensitivity analyses.

**11.4.5 Decision rule.** Tasks are taken one at a time. At the first task where the KEEP test rejects: **KEEP** (the old
scores unchanged). At the first task where the DROP test rejects: **DROP** (recalibrate with `recal` from the checks
collected, or wipe). Both at the same task: DROP. Neither by the budget cap: the default, **recalibrate** from the
checks collected (`recal`, Part 2.6), so that a KEEP only ever comes from the controlled test. Two further endings
(revision 2): "not testable" (the flag is not positive: neither KEEP nor DROP; revision 3 states it for both) and "home
table exhausted" (counted as undecided). **What the operator does when the answer is "not testable"** (revision 3): the
old scores showed no positive signal even for the old model, so the 0.75 question has no meaning for this bank; the
operator answers the break-even question of 11.4.0 instead (keep or wipe, no old-model call). The replay reports the
not-testable share beside every rate.

**11.4.6 Replay on the real probe tables** (no model calls). For every ordered pair and every home cell, in each stream
and order:
- **Halves.** The evaluation tasks of the stream order are split once by a fixed hash (sha256 of "truth-half |
  `evaluate.seed` | stream | order | task id"); the first half is the truth half; the same split serves every pair.
- **Truth.** θ = φ̄_swap / φ̄_home, both on the truth half (the same tasks), with a 95% task-bootstrap interval; home
  cells have θ = 1 by definition (the estimate from repeats 3–4 reported beside it). `home_signal_ok` = the reporting
  flag of Part 2.4 (the owner's calibration tasks, ≥ 2 SEs).
- **Test stream.** The other half of the evaluation tasks (200 tasks = 800 checks per order; since revision 2 the
  calibration tasks feed the flag only), in an order drawn uniformly at random by the harness (`harness_order`),
  without replacement; a given order is refused (11.4.0); each candidate's check is one of its two stored repeats,
  chosen uniformly; φ_h from the owner's stored home results on the same tasks.
- **Replays.** 1,000 per cell, seeded by (`evaluate.seed`, owner, reader, stream, order). **Budget cap:** the number
  of tasks in the stream (200 per order, fewer if rule 1.6 drops tasks; the 300 of revision 1 counted the
  calibration tasks, which left the stream in revision 2). **Control:** scores permuted at random within
  each task (θ = 0) replayed too.
- **Undecided within the table is a result, not hidden.** A cell-order counts as undecided when at least half of its
  replays reach the end of the stream without a decision; the share is reported per kind of swap and per pair.
- The replay checks agreement between two finite-sample estimates (the truth has its own error, and the replays of a
  cell share one pool); the guarantee is checked by 11.4.8.

**11.4.7 Reported per rule** (per cell and per kind of swap): false-keep rate (KEEP share among cells with θ < 0.75, and
among cells whose whole θ interval lies below 0.75); false-drop rate (likewise above 0.25); the undecided share; tasks
and calls used (mean, 10th, 50th, 90th percentiles, maximum). Rules compared on the same replays: the paired rule; the
same cut at 2, 4, 8 and 16 tasks (8, 16, 32 and 64 checks) and at 100 tasks; `sequential_plugin`; `sequential_split`;
`audit_k` at those budgets (KEEP if Cw on the checks > 0.5, KEEP if no pair is informative, else WIPE); a fixed-budget
plug-in rule (KEEP if mean φ / φ̄_home ≥ 0.5, else DROP); and both fixed rules at the paired rule's mean cost.

**11.4.8 Checks of the guarantee** (reported; a failure is a defect to fix before any claim):
- **Boundary with the home estimated** (`sequential_boundary.csv`): generative task models with Ā_swap = θ Ā_home
  exactly (the reviewer's model, Ā_home = 0.20, one with task heterogeneity, and review R6's simulator), a fresh home
  sample and a fresh stream per replication, 2,000 replications, θ ∈ {0.60, 0.70, 0.74, 0.75} (KEEP) and {0.25, 0.26, 0.30, 0.40} (DROP),
  checkpoints 100–6,000 tasks. Pass: the paired rule's share wrong is at most α + 2.33 Monte-Carlo SE at every
  checkpoint.
- **Null streams** for D exactly at the boundary (a table-based law, a two-point law, a Beta law; 5,000 streams):
  the share rejecting by task t is at most α + 2.33 Monte-Carlo SE for every t.
- **Known truth** (simulated studies): tasks drawn with replacement, fresh Bernoulli reader checks AND fresh owner home
  results from the simulator's probabilities, 1,000 streams per cell: false keep at most α + 2.33 Monte-Carlo SE
  wherever θ < 0.75, false drop likewise wherever θ > 0.25.
- **The conditions (revision 2, extended in revision 3):** a negative home signal (Ā_home = −0.10) must give "not
  testable", never KEEP, and with the reader at θ = 1 against it never DROP (`sequential_gate.csv`, parts
  `counter_example` and `drop_counter_example`); a finite store re-used beyond its size must show the inflation and the
  stopping rule must remove it (`sequential_store.csv`); checks in topic order must show the failure of 11.4.0 and
  checks in the harness's random order must not (`sequential_order.csv`).

**11.4.9 Stopping time against θ.** Synthetic paired streams generated with a FRESH home result for every task
(revision 2: the former sampler re-used the study's stored home results with replacement), calibrated to the study's
home cells, at θ ∈ {−0.6, −0.4, −0.2, 0, 0.1, 0.25, 0.4, 0.5, 0.6, 0.75, 0.9, 1}, 2,000 streams of up to 3,000
tasks: decision shares, the 10th–90th percentiles of tasks used, and the share decided by 2, 4, 8, 16, 100 and 300
tasks.

**11.4.10 The information lower bound (a reported quantity, with four qualifiers).** It is stated for an
observation scheme (whole tasks drawn uniformly at random, every candidate checked once; or, extended, any adaptive
choice of (task, candidate) cells with one fresh check per pick), a margin θ_0, a signal (Ā_home and E[σ²]) and error
levels (α, power 1 − β); every number is reported with all four. For any keep-or-drop decision, sequential or
fixed-sample, that keeps with probability at most α at θ_0 and at least 1 − β at θ_1:
E_{θ_1}[N] ≥ d(1 − β ‖ α) / K*, d the binary Kullback–Leibler divergence, K* = the smallest per-task divergence of the
checks between the reader at θ_1 and any reader table with θ ≤ θ_0 (Wald 1945; Kaufmann, Cappé and Garivier 2016). K*
is computed by convex optimisation (one linear constraint) and, to second order, K* = (θ_1 − θ_0)² Ā_home² /
(2 E[σ²(τ)]), σ²(τ) = Σ_i c_i² μ_i(1 − μ_i) the within-task Bernoulli variance of φ. The theorem bounds the EXPECTED
number of tasks: a rule's measured MEAN stopping time is what is compared with it (at the rule's measured power; a mean
capped at the horizon is itself a lower bound on the mean); medians are reported apart, labelled as medians.
**Exact against second order (revision 3, review R7 W7).** The second-order form is an approximation: in R7's worlds it
was 0.98–1.02 times the exact bound where chances are spread out and 0.59 (margin 0.75) and 0.28 (margin 0) of it where
most cells are near 0 or 1. The exact bound is reported wherever the chance table is known (the stated worlds; a
simulated study's truth), with a two-way 95% interval (the per-task Lagrangian of the least-favourable problem is the
influence of K*; `msr.metrics.robust_variance`, task id × write task within stream; log scale;
`exact_bound_twoway`). On real data the exact bound cannot be estimated from a few repeats per cell (it depends on how
close each cell's chance is to 0 or 1; computed on the table of observed home means it was about 0.5 times the exact
bound with two repeats and 2–30 times it in a near-deterministic world). Real-data rows therefore report the
second-order value from unbiased moments (Ā_home linear; μ(1 − μ) per cell from pairs of repeats) as "an
approximation", and beside it a **guaranteed floor**: for whole random tasks, E_{θ_1}[N] ≥ d(1 − β ‖ α)/K* ≥ κ(x)·B₂,
B₂ the second-order bound, κ(x) = 1 − x − x²/4, x = t·c_max, t = |θ_1 − θ_0| Ā_home / E[σ²], c_max the largest |c_i|
(3/4 with four candidates), valid whenever x < 0.83 (otherwise no floor is given). Proof: the null q_i = p_i ∓ t c_i
p_i(1 − p_i) is feasible and meets the constraint exactly; kl(p ‖ q) ≤ (p − q)²/(2 min over [p, q] of r(1 − r)) and
q(1 − q) ≥ p(1 − p)(1 − x − x²/4), so K* ≤ (second-order K)/κ(x). The floor needs only Ā_home and E[σ²], which two
home repeats estimate without bias (`bound_floor`, `chi2_floor_twoway`). Reported (`sequential_bound.csv`):
- at the study's own signal: Ā_home and E[σ²] estimated from the owner's two home repeats (unbiased μ(1 − μ) per cell),
  for KEEP (θ_1 = 1 against 0.75) and DROP (θ_1 = 0 against 0.25), at power 0.5, 0.8 and 0.9: the bound in tasks and
  checks; the bound for tests that see only φ (K_inf); the fixed-sample one-sided z test's size;
- for fixed budgets of 2, 4, 8 and 16 tasks (8–64 checks): the largest keep rate at θ_1 any rule with false keep ≤ α
  can have, and the smallest false-keep rate of a rule that keeps at θ_1 with probability 0.8;
- beside them the paired rule's measured mean stopping time and its ratio to the bound at the rule's measured power
  (`ratio_mean_to_bound_*`); the median and its ratio to the bound at power 0.8 apart, labelled as a median;
- the bound's 95% interval (revision 3): the plug-in pools the owners' home cells, so its interval is the two-way
  jackknife (task id × write task within stream), delta method on the log scale, for the second-order value and for the
  floor; it is the interval of the approximation, not of the exact bound. The task bootstrap within cells and the
  owner-level bootstrap of revision 2 are reported beside it (`*_boot_lo/hi`, `*_owner_lo/hi`)
  (`sequential_bound.csv`, `sequential_bound_curve.csv`);
- (revision 2) the curves: the bound against the margin θ_0 ∈ {0, 0.1, …, 0.9} at the study's signal, and against
  Ā_home ∈ {0.05, …, 0.5} at margins 0 and 0.75 (E[σ²] held at the study's value, and at review R6's model M2 value
  beside it), with two markers: the current scores and scores equal to the owner's true item usefulness (the limit of a
  long score phase, simulated studies only);
- (revision 2) the adaptive bound: the sup over allocations of the inf over nulls (Kaufmann, Cappé and Garivier 2016,
  Lemma 1, holds for adaptive sampling), its ratio to the uniform-task bound (`sequential_adaptive.csv`); what the
  theorem does not cover (observations other than fresh checks, smaller nulls, non-fresh repeats, finite-pool targets)
  is stated beside it.
At the reviewer's model (Ā_home = 0.20) the bound is 191 / 439 / 548 tasks at power 0.5 / 0.8 / 0.9. At the practice
study's signal (power 0.8, α 0.05, whole random tasks; revision 3): margin 0.75, exact bound at the simulator's truth 262
tasks (two-way 95% interval 169–405), second order at the truth 257; the real-data style plug-in gives 262 tasks as the
second-order approximation (two-way 140–491; the task bootstrap of revision 2 gave 198–366, too narrow because it held
the write tasks fixed) and a guaranteed floor of 207 tasks (two-way 100–425). Margin 0: exact 17.3 tasks (69 checks;
11.4–26.1), second order 16.1, plug-in 16.4 (8.7–30.7); no useful floor (x = 0.81). The paired rule's MEAN stopping
time at θ = 1 is 803 tasks with every stream keeping, 1.95 times the bound at that power (412 tasks); its median, 730.5,
is 2.79 times the bound at power 0.8. The ranking break-even test's mean is 95 tasks (380 checks), 3.5 times the bound
at its power (27 tasks); the decision form's mean is 307 checks, 1.9 times its bound at its power (158 checks). The
adaptive bound is 1.30 times lower.

**11.4.11 Sensitivity.** Thresholds (θ_drop, θ_keep) ∈ {(0.25, 0.75), (0, 0.5), (0.25, 0.5), (0.5, 0.5)}; α = 0.10; the
plug-in and aGRAPA bets.

**11.4.12 Wording, and what counts against the decision rule.**
- Tasks and checks are never mixed: "N tasks (4N checks)".
- Allowed claims: "KEEP and DROP decisions were wrong at most α of the time", only if 11.4.8 passes; "whether keeping
  still beats wiping was decided after a median of N checks of the new model (M tasks), with no call to the old
  model", with N from 11.4.0 at the study's signal and the lower bound beside it; "a controlled keep-or-drop decision on
  the 0.75 question needs about N tasks (4N checks) when θ = …", with N the median of 11.4.9 at the study's signal,
  always with the share undecided and the old-model calls it needs; "no rule with error control α that checks whole
  tasks drawn at random can keep a swap that lost nothing with probability 0.8 in fewer than B tasks ON AVERAGE at this
  signal", with B the guaranteed floor of 11.4.10 and its interval, or "in fewer than about B tasks on average" with B
  the second-order approximation and its interval (named as an approximation), the adaptive factor beside it;
  comparisons of a rule with the bound use the rule's MEAN (a median only labelled as a median); "fixed budgets of 8 to 64
  checks decide but do not control errors", with their false-keep and false-drop rates and the 11.4.10 frontier beside
  them.
- Not allowed: "any rule needs …" without the observation scheme, the margin and the signal; a median compared with
  the bound as if the theorem bounded it; checks taken in an order the operator chose; "a few dozen checks
  suffice" unless a registered test's median is a few dozen (at the practice study's signal the margin-0 floor is
  about 65–100 checks and the registered tests need about 280–360).
- Counts against the rule: a failed check of 11.4.8 (then no claim about error control is made, and the defect is fixed
  first). In substance, a large share undecided within the table means the table cannot support a controlled decision
  at the benchmark's scale; the paper then reports that share, with the lower bound, as the finding.
- The betting test and the lower bound are classical; only the paired comparison and the evaluation at the benchmark's
  signal are ours.

### 11.5 Constants of the additions

These are module constants in the code (not config keys). Their files are hashed at the freeze (Part 0.1).

| Constant | Value | Where |
|---|---|---|
| Decomposition: repeats | owner home session 1–2 and session 3–4; reader 1–2 | `msr/theory.py` |
| Decomposition: definedness of γ̂ | ≥ 2 SEs on the owner's calibration tasks (θ: the flag of Part 2.4) | `CAL_MIN_Z` = `msr.metrics.THETA_CAL_MIN_Z` |
| Decomposition: intervals | Fieller sets with the variance of Part 4.1 (`robust_variance`) | `msr.metrics` via `msr/theory.py` |
| Decomposition: readings | supported / fails / departure within the margin / inconclusive | `group_reading` |
| Decomposition: equivalence margin | 0.02 in Cw | `EQ_MARGIN` |
| Holm family T | T1-diff (3 groups) + T1-eq (3) + T2 (3 families) = 9 separate members at 0.05 | `family_t`, `T_STRATA`, `T2_FAMILIES` |
| Family F | F1, one-sided 0.05, one test | `msr/forecast.py`, `ALPHA`, `N_TESTS` |
| F1 controls | same_maker, Z_A, Z_B, abs_gap, owner_newer, reader_newer (+ intercept) | `F1_CONTROLS` |
| P1 test | F1's test with x = agreement | `pair_incremental_test` |
| Forecast: calls per swap day | 950 new-model + 200 old-model no-memory calls | `forecast_calls` |
| F1 relabellings | within makers × makers of equal size (384 at 4 × 2) | `relabelings` |
| Forecast: subsample baseline | 5 calibration tasks (20 checks) per bank, 200 draws | `SUBSAMPLE_TASKS`, `SUBSAMPLE_DRAWS` |
| Forecast: reportability of θ | the flag of Part 2.4 | `owner_home_flag` → `msr.metrics.home_signal_flag` |
| Decision (margin 0): rules | decision form on first-shown success (lead), ranking form beside it | `decide_margin0`, `MARGIN0_THETAS`, `MARGIN0_REPS` |
| Decision: calls per swap day | margin 0: no old-model call; 0.75: 4 × 2 old-model calls per stored task + 800 for the flag | `swap_day_calls`, `HOME_REPEATS` |
| Decision (0.75): sign condition and store | KEEP and DROP need the flag of Part 2.4; otherwise "not testable" and the break-even question decides; the stream stops when the stored home results run out | `decide_keep_or_drop`, `home_signal_flag` (adapter), `NOT_TESTABLE_ACTION` |
| Decision: check order | drawn at random by the harness from a fixed held-out pool; a given order is refused unless run as a labelled diagnostic | `harness_order`, `check_order`, `NonRandomOrderError` |
| Decision: error level | 0.05 for each error | `msr/sequential.py`, `ALPHA` |
| Decision: thresholds | KEEP θ > 0.75; DROP θ < 0.25, through D_k and D_d | `RHO_KEEP`, `RHO_DROP` |
| Decision: bets | equal mixture of the constant bets η_d = d/40, d = 1..20 | `BET`, `MIX_GRID` |
| Decision: truncation of the sensitivity bets | 0.5 | `TRUNC_C` |
| Decision: budget cap in the replay | every task of the stream pool (200 tasks = 800 checks per order since revision 2) | `STORE_TASKS_REAL` |
| Decision: default at the cap | recalibrate | `DEFAULT_AT_CAP` |
| Decision: replays | 1,000 per cell | `REPLAYS` |
| Decision: fixed budgets compared | 2, 4, 8, 16 tasks (8, 16, 32, 64 checks) | `FIXED_CHECKS`, `BOUND_BUDGETS` |
| Decision: synthetic horizon and θ grid | 3,000 tasks; the grid of 11.4.9 | `LONG_CAP`, `THETA_GRID` |
| Decision: boundary check | 2,000 replications; checkpoints up to 6,000 tasks; 400 and 64 home tasks for the comparison rules | `BOUNDARY_REPS`, `BOUNDARY_TASKS`, `HOME_TASKS`, `HOME_TASKS_FLOOR` |
| Decision: lower bound | powers 0.5, 0.8, 0.9; measured horizon 6,000 tasks | `BOUND_POWERS`, `BOUND_HORIZON` |
| Decision: bound curves and interval | margins 0–0.9; Ā_home 0.05–0.5; two-way jackknife interval (task id × write task within stream), 2,000 bootstrap draws beside it | `BOUND_MARGINS`, `BOUND_SIGNALS`, `chi2_floor_twoway`, `BOUND_BOOT` |
| Decision: exact bound and floor | exact (least-favourable) where the chance table is known, with a two-way interval; on real data the second-order approximation and the floor κ(x)·B₂, x < 0.83 | `exact_bound_twoway`, `bound_floor`, `FLOOR_X_MAX` |
| Item clusters of pooled statistics | write task within stream (owner coding as a sensitivity) | `msr.theory.ITEM_CLUSTER`, `write_task_key` |
| F1 sensitivity | owner and reader fixed effects added to Q | `pair_incremental_test(..., fixed_effects=True)` |

Why the margin is 0.02: at the main study's size per pair (2,400 tasks, about 1,500 items over the six banks,
2 repeats), the simulated SD of the gap is about 0.010–0.013 Cw per swap, so a group mean over 4 swaps has an SE below
about 0.007 if the swaps' errors are independent, and 0.02 is about three SEs. Curvature alone moves the gap by under
0.01 Cw for readers within one logit of the owner in three of our five owner worlds, by more when tasks are hard or
easy, and by 0.02–0.03 for much weaker or sharper readers (11.2.1). The
margin is a design choice stated before any main-study data exist. Groups (a) and (b) hold only 4 swaps, which share
models; the two-way variance handles shared tasks and items but not dependence through models; the permutation and
leave-one-model-out rows of 11.2.5 are the check on that.

---

## Sources (as verified in the statistics note or in `paper/reference_ledger.md`; the opening status is given where it was less than full text)

- Baayen, Davidson and Bates (2008). Crossed random effects for subjects and items. Journal of Memory and Language 59(4).
- Bertinetto, Henriques, Albanie, Paganini and Varol, eds. (2021). NeurIPS 2020 Workshop on Pre-registration in ML, PMLR 148 (preface).
- Bowyer, Aitchison and Ivanova (2025). Don't use the CLT in LLM evals with fewer than a few hundred datapoints. ICML 2025.
- Cameron, Gelbach and Miller (2011). Robust inference with multiway clustering. JBES 29(2) (2008 author draft read).
- Cameron and Miller (2015). A practitioner's guide to cluster-robust inference. Journal of Human Resources 50(2).
- Holm (1979). A simple sequentially rejective multiple test procedure. Scandinavian Journal of Statistics 6 (abstract only).
- Hofman, Chatzimparmpas, Sharma, Watts and Hullman (2023). Pre-registration for predictive modeling. arXiv 2311.18807.
- Lakens (2017). Equivalence tests: a practical primer. Social Psychological and Personality Science 8(4).
- Lakens, Scheel and Isager (2018). Equivalence testing for psychological research: a tutorial. AMPPS 1(2) (preprint read).
- Newson (2002). Parameters behind "nonparametric" statistics. Stata Journal 2(1).
- Newson (2006). Confidence intervals for rank statistics: Somers' D and extensions. Stata Journal 6(3).
- Owen (2007). The pigeonhole bootstrap. Annals of Applied Statistics 1(2).
- Schuirmann (1987). Two one-sided tests procedure. J Pharmacokinet Biopharm 15(6).
- Zhang, Agarwal, Daumé III, Langford and Negahban (2019). Warm-starting contextual bandits. ICML 2019, PMLR 97.
- ZenML (2026). SwapBench: which checks can tell if a model swap is safe? Web page, run 13–15 October 2026,
  https://www.zenml.io/benchmarks/swapbench (verified in `paper/reference_ledger.md`). Cited in related work.
- Spearman (1904), the correction for attenuation (statistics note; read in the IJE 2010 reprint).
- Named in Part 11 but not yet opened and logged (Open point 23): Waudby-Smith and Ramdas (betting confidence
  sequences); Ville's inequality; Geirhos et al. (error consistency).
- Named in revision 2 and not yet opened and logged (Open point 28): Berger (1982), intersection-union tests;
  MacKinnon, Nielsen and Webb (2023), cluster-robust inference (the CV3 jackknife); DerSimonian and Laird (1986),
  random-effects meta-analysis; Viechtbauer (2007), confidence intervals for the amount of heterogeneity (Q-profile);
  Higgins, Thompson and Spiegelhalter (2009), a re-evaluation of random-effects meta-analysis (prediction intervals).
  Already verified in `paper/reference_ledger.md`: Fieller (1954); Aronow, Samii and Assenova (2015); Dekker,
  Krackhardt and Snijders (2007).
- The arms come from: Ibrahim and Chen (2000) (abstract; formula via Ibrahim et al. 2015); Ibrahim, Chen, Gwon and
  Chen (2015); Gravestock and Held (2017) (abstract); Steyerberg et al. (2004) (abstract); Janssen et al. (2008)
  (abstract); Vergouwe et al. (2017) (abstract).

---

## Freeze block (left blank until the freeze)

| Field | Value |
|---|---|
| Date and time of the freeze (UTC) | |
| Git commit at the freeze, or sha256 of `config/models.yaml`, `config/study.yaml`, `config/study_memprompt.yaml`, `config/pilot_shot.yaml`, `config/pilot_memprompt.yaml`, `config/pilot_bird.yaml` | |
| sha256 of this file | |
| Public registry, identifier and deposit time stamp | |
| Frozen by | |

The sha256 of this file is computed with its own field left empty. It is recorded in the freeze commit message and in
`docs/STATUS.md`. If it is then copied into this field, that is done in one follow-up commit that changes nothing else.

---

## Settled by the research manager, 23 Nov 2026

These rulings are written into the file above. Points 1–22 use the numbers of the first draft's open-points list. The
later rows come from `docs/STATUS.md` ("Rulings to write into the pre-registration at the freeze", "More rulings ...",
"Analysis follow-up done") and from the manager's message of the same night.

| Point | Ruling |
|---|---|
| 1. The four primary comparisons (amended by the round-1 revision: 5 hypotheses × 3 groups = 15 tests, PC1 on θ, PC3 and PC4 swap minus home on level-corrected log scores; amended again by revision 2: PC1 as three intersection-union members + PC2 = 4 × 3 = 12 tests, PC3 and PC4 secondary; see the lists below) | PC1–PC4 confirmed, with λ = 0.5 and k = 64 (the curve over k = 8–64 is secondary). Headline family `ema_grade`; if it fails its gate-2 test, the first that passes in the order `beta_grade`, `credit`, `tags_self` (Part 9.2). The confirmatory tests are swap-stratum averages pooled over both streams with the joint bootstrap: (a) 4 upgrades, (b) 4 downgrades, (c) 48 cross-family swaps. Holm over 4 × 3 = 12 tests. Per-pair results: unadjusted 95% intervals, a Holm-adjusted flag as secondary, a forest plot and a pre-stated heterogeneity summary per stratum (Part 5.2). |
| 2. Non-inferiority margin | Relative margin, R ≥ 0.75, joint bootstrap. |
| 3. Per-pair power | Quote the simulation's power only for the unadjusted per-pair case, and say so (Part 6.3). |
| 4. Split-half value | Called the "noise reference"; no primary statistic is ever normalised by it. |
| 5. Pilot size | 250 write + 500 score × 3 passes, 200 probe tasks (150 evaluation + 50 calibration), 100 test tasks, seed 99. |
| 6. Gate-2 remedy | One re-run at 6 passes with the same exploration, then stop. |
| 7. Gates 1, 3 and 5 | As in Part 9.4. |
| 8. Gate 3 | A settings check: always reported; fails only above 40% disagreement. |
| 9. Gate scope | Gates 1, 2 and 4 on the old model (Haiku 4.5); gate 2 counts the four usefulness families only. |
| 10. Second-stream rule | The gain's 95% interval must also exclude 0. BIRD and DS-1000 are both checked in the pilot window; if both fail, the main study runs on DDXPlus plus the MemRL-code leg, logged as a deviation. |
| 11. DS-1000 sizes | 150 write, 300 score, 500 probe (400 + 100), 50 test; contingency only. |
| 12. Test-set size | 250 test tasks everywhere; "the first 100 tasks" stays. |
| 13. Post-swap run | Cross-family swaps: each maker's old model to the next maker's new model, in the order Anthropic → OpenAI → Qwen → Gemma → Anthropic. Content frozen, exploration 0, every arm keeps learning with its family's own update rule from its starting values. |
| 14. `tags_self` | Given without the grade (the model sees the task, the item and its own answer only), ranked by the smoothed share; helpful − harmful is a sensitivity check. The with-grade variant is not run. |
| 15. P4 | The 4 upgrades against the 48 cross-family swaps; the 8 same-family swaps as secondary; low power stated. |
| 16. Self-swap timing | Each model's extra home repeats run in the last third of that model's collection window, with times logged. |
| 17. Unnamed models and pairs | Second bank: Haiku 4.5 and Qwen3.5-27B. Labelled-item (memprompt) check and second wording: the Haiku and Qwen pairs. |
| 18. Log-score threshold | Accepted: no practical-size threshold; the Brier difference is reported beside it. |
| 19. Per-model fields | Filled from the smoke test: sampling values, reasoning setting and OpenRouter route among them. The field list is in Part 0.1. |
| 20. Code checklist | Removed: the code was brought into line with this file. The differences that remain are Open points 24–26. |
| 21. DS-1000 pilot | If DS-1000 is piloted, it uses its smaller build (150 write, 300 score) with 200 probe tasks (Part 9.1). |
| 22. Post-swap run, other headline family | If the headline family is not `ema_grade`, the run after the swap ranks and learns with the headline family's own update rule (Part 2.10). |
| Fresh checks | Always program-graded results, also for the `tags_self` family (Part 2.6). |
| `powerprior_k` | Not defined for `credit` and `visits`; those families skip it (Part 2.6). |
| Slope wording | Not "b = 1 is keep": with a standardised score, the fitted slope is compared with the slope fitted the same way at home (Part 2.6). |
| Starting counts after the swap | helpful = p(n + 2) − 1 and harmful = (1 − p)(n + 2) − 1, so that the smoothed mean is p (Part 2.10). |
| z-scored mix | Computed within each task's 4 candidates; a sensitivity only (Part 8.3.1). |
| Visit thirds and the standardising SD | Thirds are terciles of visits over the owner's bank, and a pair is classed by its less-visited item (Part 8.2.7). The standardising SD is the population SD over the items with at least one visit (Part 2.6). |
| Per-pair PC1 flag | Superseded in the round-1 revision (S2): the drop and no-material-drop tests of every swap are two separate members, Holm over 2 × 56 (Part 5.2). The former 2 × min(p_drop, p_NI) device did not hold the familywise error. Revision 2: three intersection-union members per swap (drop, material drop, no material drop), Holm over 3 × 60. |
| Heterogeneity | By least squares; this amends Part 8.2.12 and replaces the mixed and cell-level logistic models. Revision 2: each group's own between-pair SD (DerSimonian–Laird, Q-profile interval) and a prediction interval for a new pair sit beside every group estimate (Part 5.2); the least-squares summary stays secondary. |
| Noise-adjusted ratio | R_adj is a secondary measure; its noise reference is each model's home repeats 1–2 against 3–4 (Part 2.5). |
| ZenML's SwapBench | Cited in related work (header and Sources). |
| Two additions | The transfer decomposition, the pre-swap forecast and the keep-or-drop check are registered in Part 11, as confirmatory-secondary tests with their own Holm families (Part 5.4). |
| Real-data replay of the check | Truth from a fixed random half of the evaluation tasks; the stream from the other half plus the calibration tasks, in random order; 1,000 replays; the cap is the number of tasks available; the share undecided within the table is reported as a result (Part 11.4.6). |

---

## Settled in the round-1 revision (23 Nov 2026, before the freeze)

| Decision | Ruling, as written into Parts 0–10 |
|---|---|
| S1. Headline measure | θ = V_swap / V_home (the retained ranking signal) is the headline, implemented once in `msr.metrics` (`msr.theory`'s R_V agrees, tested); the non-inferiority margin 0.75 sits on θ; R, D and R_adj are secondary (Parts 2.4, 3, 6.1). |
| S2. Multiplicity | The drop and the no-material-drop tests are two members of the Holm family: 5 hypotheses × 3 groups = 15 (Part 5.1); per-pair flags Holm over 2 × 56 (Part 5.2). Familywise error measured by simulation (`docs/power/fwer_holm_output.md`). Superseded by revision 2 (12 members; below). |
| S3. Intervals | Two-way (task id pooled over orders × item) cluster-robust variance, Fieller interval for θ; task-only cluster bootstrap secondary; coverage simulation and power re-simulation in `docs/power/` (Parts 4.1, 6.3). The estimator is the two-way jackknife since revision 2 (below). |
| S4. Prediction quality | Level-corrected log scores (the reader's no-memory success on the calibration tasks, one logit shift for every arm), swap-minus-home contrasts, success points beside every log-score result, a `constant` reference arm (Parts 2.6, 2.8, 3). |
| S5. Names and references | `oracle` → `split_half` (not a bound, out of headline tables); in-sample `ceiling` added; swap groups named by maker; each group's spread in the group table (Parts 0.2, 2.6, 5.2). |
| S6. Sampling | Open-weight models at temperature 1.0, top_p 1.0, no top_k; closed models at their provider defaults; settings part of the logged identity; Qwen pair at temperature 0.7 as a secondary sensitivity (Parts 0.1, 0.3, 8.2.15). |
| S7. Stakes | Keep − wipe, keep − shuffled, ceiling − keep and keep − none in success points, at home and after the swap, per group (Part 3, 8.2.1). |
| Leg L3 | Registered as a confirmatory leg with its own family (Part 8.4); scope set after the pilot by its budget rule. |
| Labelled items | DDXPlus, stream order 0 only (Part 8.3.6). |
| Registry | The frozen file is deposited by the authors on a public time-stamped registry before the first paid main-run call (header; Part 0.1). |
| θ's reporting flag (24 Nov 2026) | The flag is decided on the owner's calibration tasks (≥ 2 SEs); θ, its Fieller set and both tests are always computed; the same-task 4-SE rule is a secondary column (Parts 0.3, 2.4, 3). |
| Small-sample factor (24 Nov 2026) | Every two-way SE is multiplied by 1.03 (Part 4.1), after the boundary sizes were measured with 5,000 replications per configuration. Withdrawn in revision 2 (the jackknife replaces it). |

## Settled in revision 2 (24 Nov 2026, before the freeze)

| Decision | Ruling, as written into Parts 0–10 |
|---|---|
| D1. Value, order, stakes | θ (value kept) = order × stakes exactly; S by cross-repeat products (owner: home repeats 1–2 × 3–4; reader: repeat 1 × repeat 2 of the swap cell, run in a later session); stakes and order with Fieller sets; order "not identifiable" unless the reader's calibration-task spread z ≥ 2 (Parts 0.2, 0.3, 2.4). |
| D2. Sign condition | Every PC1 claim is an intersection-union test that includes H1: Σ V̄_home > 0; the drop member also includes the self-swap contrast (Parts 3, 4.4). |
| D3. Labels | Decision words only from test outcomes (`msr.metrics.pc1_label`); "material drop" from its own test; no "practical size" label on PC2; Holm over separate members chosen over simultaneous Fieller sets (Parts 3, 5.1, 6.2). |
| D4. One flag | `msr.metrics.home_signal_flag` is the only home-signal rule; every module calls it (Parts 0.3, 2.4). |
| D5. Variance | Two-way delete-one-cluster jackknife, items coded by identity across orders, normal reference; item share, effective item clusters and Satterthwaite df with concern marks beside every primary test; factor 1.03 withdrawn (Parts 0.3, 4.1, 4.2). |
| D6. Family | PC1-drop, PC1-MD, PC1-NI and PC2 in three groups: 12 members, Holm. PC3 and PC4 secondary with the additivity assumption, the base-rate gap and the with-item level target as a sensitivity (Parts 2.8, 3, 5.1, 5.5). |
| D7. Spread | Per-group between-pair SD and a prediction interval for a new pair (Part 5.2). |
| D8. Capability | θ against capability gap and error consistency with maker as a separate term; descriptive; wording rule for "same-maker" (Part 8.2.17). |
| D9. P1 permutation | Maker-preserving relabellings as F1 (Part 11.3.8), extended block-wise to the extension makers; P2 and P4 keep the permutation of the 8 core labels (Part 7). |
| D10. Extension pairs | Mistral Small 3 → 3.2 and DeepSeek V4.1-Flash → V4.1-Flash-1017 as same-maker cells only; same-maker groups of 6; membership from the study configuration; nothing requires a square grid (Parts 0.2, 0.3, 1.1, 2.1). |

## Open points for the research manager

23. **References in Part 11 that are not yet opened and logged.** Waudby-Smith and Ramdas (betting confidence
    sequences and the plug-in and aGRAPA bets), Ville's inequality, and Geirhos et al. (error consistency). Each must be
    opened and logged in `paper/reference_ledger.md`, with its year and venue, before the freeze. Until then this file
    names them without a year.
24. **The code differs from three rulings written into this file.**
    - The z-scored mix: `msr.engine.first_shown_z` z-scores the score over the whole bank and only the relevance within
      the task. The ruling (Part 8.3.1) z-scores both within the task's 4 candidates.
    - The standardising SD of `recal_k`: `msr.scores._zscore` uses every item of the bank. The ruling (Part 2.6) uses
      the items with at least one visit.
    - The starting counts after the swap: `msr.arms` (recal) starts a count family at n·p̂ and n·(1 − p̂). The ruling
      (Part 2.10) uses p̂(n + 2) − 1 and (1 − p̂)(n + 2) − 1.

    Recommended: change the code to the rulings before the freeze.
25. **Two exploratory runs cannot yet produce what this file registers.**
    - The second wording: `variants.pairs` holds only the 4 within-pair swaps, so there is no home cell under the second
      wording and D cannot be computed under it. The raw results under the second wording are not kept, so the wording
      variance component cannot be computed either.
    - k = 128 and 256 are not in `evaluate.k_values`.

    Recommended: add the 4 home cells to `variants.pairs` and keep the raw results; add 128 and 256 to
    `evaluate.k_values`, which is look-up only. Otherwise strike both from Part 8.3 before the freeze.
26. **The DS-1000 contingency cannot run yet.** There is no DS-1000 loader, grader or pilot config (`msr/grade.py`
    knows only DDXPlus and BIRD), but ruling 10 checks DS-1000 in the pilot window. Recommended: build them before the
    pilots, or record that DS-1000 is checked only if BIRD fails its pilot rule.
27. **Part 11 is not yet in line with revision 2 (Parts 0–10).** (a) 11.1 still states θ's reportability by the
    same-task 4-SE rule; Part 2.4's calibration-task flag (`msr.metrics.home_signal_flag`) governs. (b) The status
    paragraph of Part 11 says its families are not part of "the 15 primary tests"; there are 12. (c) F1's relabellings
    (11.3.8) permute "whole makers among makers of equal size"; with the extension makers (also of size 2) a relabelling
    must not map a core maker onto an extension maker (their cross-maker cells do not exist), so F1 needs the
    block-wise group of Part 7 or the core grid only. (d) 11.1 names `theta_inference` and `fieller_interval`; the
    registered tests and sets are now `msr.metrics.theta_tests` and `robust_variance`. Recommended: the authors of
    Part 11 align these before the freeze.
28. **References of revision 2 not yet opened and logged:** Berger (1982); MacKinnon, Nielsen and Webb (2023);
    DerSimonian and Laird (1986); Viechtbauer (2007); Higgins, Thompson and Spiegelhalter (2009). Each must be opened
    and logged in `paper/reference_ledger.md` before the freeze.
29. **P1's relabelling group with the extension pairs: CLOSED (ruling of 24 Nov 2026).** P1 and the forecast's
    test F1 are computed on the core grid only (the 8 models, 4 makers, 56 swaps); relabellings are within and among
    the four core makers (384). The extension pairs enter only the same-maker group estimates (PC1/PC2 for the
    upgrade and downgrade groups), the spread and prediction-interval summaries and the descriptive tables (Parts 7,
    11.3.8).
30. **Registered secondary analyses whose analysis code does not exist yet (Part 8.2.18–8.2.22).** The stages run
    (`msr/stages.py`: judge, relearn; `msr/build.py`: write2, selfrate; `msr/online.py`: reexplore_m), but on 24 Nov
    2026 no code turns the judge's ratings, the self-ratings or the relearned banks into scored rules (`msr.evaluate`,
    `msr.analysis`), and `msr.construct` does not yet read the second write answer (write2) for re-answer's home value.
    These must be written, and tested on the simulated study, before the freeze; until then the paper prints their
    numbers as missing.
