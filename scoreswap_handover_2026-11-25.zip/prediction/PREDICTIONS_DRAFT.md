# Prediction file: DRAFT, not yet dated or frozen

Reviewers trust results that were predicted in advance. Finish this file and write the date and
time before the FIRST paid run of the pilot. After that, do not change it. Add a dated addendum instead.

Date frozen: ____ (UTC)          Frozen by: ____

## 1. Three predictions
- **P1 (agreement).** Retained validity rises with how often the old and new model agree on the same
  task-and-item cells. The test is a rank correlation across the 12 ordered swaps.
- **P2 (stronger new model).** The gap between keep and wipe shrinks as the new model's no-memory
  success rises.
- **P3 (who gave the score).** Self-assigned counters (ACE-style) lose more validity than scores earned
  from a program's grade (MemRL-style values).

## 2. Four primary comparisons (Holm-corrected)
1. Retained validity after the swap vs at home, per ordered pair.
2. Keep vs wipe: first-shown success on the probe tasks.
3. Calibrated discount vs keep.
4. Calibrated discount vs the re-scored ceiling (what share of the ceiling it recovers at k fresh checks).

## 3. Margins
- A difference counts if it is at least 5 points and beyond the self-swap noise floor.
- "No drop" means the 90% interval lies within ±3 points (the equivalence test).

## 4. Choices fixed here (the owner must confirm; these are the code's current defaults)
- **Counter ranking:** helpful − harmful. The smoothed (h+1)/(h+h'+2) is used for normalising.
- **Retrieval score:** 0.5 × relevance + 0.5 × normalised score.
- **Build-phase ranking:** which score drives retrieval during the build: ____. Values or counters; the other is recorded alongside.
- **Items shown per build attempt:** ____ (1, or 3 to 5).
- **Exploration during the build:** epsilon = ____.
- **Embedding model:** text-embedding-3-large, fixed for all models. What is embedded: ____ (the task text or the lesson).
- **Thinking and reasoning:** off for every model.
  - Haiku 4.5: none sent.
  - Haiku 5.5: disabled.
  - Luna pair: ____ effort.
  - Qwen: enable_thinking false.
- **Ties in concordance:** count as 0.5.
- **Fresh checks for the calibrated rule:** drawn from held-out probe tasks, never from the test tasks.
- **Splits:** three seeded orders (0, 1, 2), each 600 build / 200 probe / 300 test, shared by all models.

## 5. Pilot go or no-go (all five must hold)
1. Old model with its own memory beats no memory by at least 5 points, and the interval excludes 0.
2. Home concordance is at least 0.60 for at least one score type.
3. Repeats of identical cells disagree less than 15% of the time.
4. At least 150 items have 5 or more visits, and at least 30% of probe tasks have candidates with differing outcomes.
5. Measured cost per 1,000 calls is within 2× the estimate.

If the gate fails twice, stop this paper for January.
