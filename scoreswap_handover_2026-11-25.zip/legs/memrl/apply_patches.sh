#!/usr/bin/env bash
# Apply legs/memrl/patches/*.patch, in order, to the pinned MemRL checkout in legs/memrl/src.
# Safe to re-run: a patch that is already applied is skipped; a patch that neither applies nor is
# already applied stops the script (the checkout was changed by hand, or the pin moved).
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
SRC="$HERE/src"
PIN="$(head -1 "$HERE/SOURCE_SHA")"
cd "$SRC"
HEAD_SHA="$(git rev-parse HEAD)"
if [ "$HEAD_SHA" != "$PIN" ]; then
  echo "MemRL checkout is at $HEAD_SHA, expected $PIN" >&2; exit 1
fi
for p in "$HERE"/patches/*.patch; do
  name="$(basename "$p")"
  if git apply --check "$p" 2>/dev/null; then
    git apply "$p"; echo "applied  $name"
  elif git apply --reverse --check "$p" 2>/dev/null; then
    echo "already  $name"
  else
    echo "CANNOT apply $name (checkout differs from the pinned commit plus earlier patches)" >&2; exit 1
  fi
done
