"""Prove the MemRL leg's environment works, with NO model call.

Everyday picture: before the exam, check the hall: the question papers load, the room's tap
gives water (a container starts), the marking scheme marks a right answer right and a wrong
answer wrong, and the dictionary (embedding server) answers.

Checks, all through MemRL's / LifelongAgentBench's own code:
1. data: MemRL's build_task (memrl/lifelongbench_eval/task_wrappers.py:73-133) loads the 350 train
   and 150 validation OS tasks; the shipped default file os_interaction_data.json is rejected
   (its nested fields are strings, task.py:113-116).
2. docker + grader: for one validation task, LLB's own OSInteraction reset / interact / complete
   (task.py:154-270) with a hand-written correct command (graded CORRECT) and a hand-written
   wrong command (graded INCORRECT), in fresh local-os/default containers.
3. embeddings: MemRL's own OpenAIEmbedder (providers/embedding.py:181) asks the local server.

Run with the leg's Python:  legs/memrl/env/bin/python legs/memrl/check_env.py [--embed-url http://127.0.0.1:8791/v1]
Writes legs/memrl/measured/check_env.json.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

LEG = Path(__file__).resolve().parent
SRC = LEG / "src"
sys.path.insert(0, str(SRC))
sys.path.insert(0, str(SRC / "3rdparty" / "LifelongAgentBench"))
import enum as _enum  # noqa: E402  (MemRL's Python 3.10 shims, run_llb.py:21-42)
if not hasattr(_enum, "StrEnum"):
    class _StrEnum(str, _enum.Enum):
        pass
    _enum.StrEnum = _StrEnum
import typing as _typing  # noqa: E402
if not hasattr(_typing, "reveal_type"):
    _typing.reveal_type = lambda x: x
if not hasattr(_typing, "Self"):
    _typing.Self = object

from memrl.lifelongbench_eval.task_wrappers import build_task  # noqa: E402
from src.typings import Role, SampleStatus, Session, SessionEvaluationOutcome  # noqa: E402

DATA = SRC / "data" / "llb"
TASK_ID = "101"  # validation task: build a project tree with set permissions and a log
# Written by hand for this check (not copied from the dataset's ground truth).
CORRECT = r"""mkdir -p project/src project/doc
printf 'Project Title\n' > project/README.txt
printf '1.0.0\n' > project/VERSION
printf 'src/\n*.log\n' > project/.gitignore
printf "print('Hello World')\n" > project/src/main.py
printf 'Documentation\n' > project/doc/notes.txt
find project -type d -exec chmod 755 {} +
find project -type f -exec chmod 644 {} +
ls -lR project > structure.log
echo 'Setup completed' >> structure.log"""
WRONG = r"""mkdir -p project/src
echo 'Project Title' > project/README.txt"""


def run_episode(script: str) -> dict:
    task, name = build_task("os", str(DATA / "os_interaction_val.json"), max_round=15, os_timeout=20)
    s = Session(task_name=name, sample_index=TASK_ID)
    t0 = time.time()
    task.reset(s)
    status_after_reset = str(s.sample_status)
    s.chat_history.inject({"role": Role.AGENT, "content": f"Act: bash\n```bash\n{script}\n```"})
    task.interact(s)
    os_output = s.chat_history.get_item_deep_copy(-1).content
    s.chat_history.inject({"role": Role.AGENT, "content": "Act: finish"})
    task.interact(s)
    task.complete(s)
    return {"status_after_reset": status_after_reset, "final_status": str(s.sample_status),
            "outcome": str(s.evaluation_record.outcome),
            "graded_correct": s.evaluation_record.outcome == SessionEvaluationOutcome.CORRECT,
            "os_output_head": (os_output or "")[:200], "seconds": round(time.time() - t0, 2)}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--embed-url", default=None, help="local server base URL, e.g. http://127.0.0.1:8791/v1")
    args = ap.parse_args()
    out: dict = {}

    tr, _ = build_task("os", str(DATA / "os_interaction_train.json"), max_round=15)
    va, _ = build_task("os", str(DATA / "os_interaction_val.json"), max_round=15)
    ntr, nva = len(tr.get_sample_index_list()), len(va.get_sample_index_list())
    overlap = len(set(tr.get_sample_index_list()) & set(va.get_sample_index_list()))
    try:
        build_task("os", str(DATA / "os_interaction_data.json"), max_round=15)
        default_file = "loaded (unexpected)"
    except Exception as e:
        default_file = f"rejected as expected: {type(e).__name__}: {str(e).splitlines()[0][:160]}"
    out["data"] = {"train_tasks": ntr, "val_tasks": nva, "overlap": overlap, "shipped_default_file": default_file}
    print("data:", out["data"], flush=True)

    out["docker_grader"] = {"task": TASK_ID, "correct_command": run_episode(CORRECT), "wrong_command": run_episode(WRONG)}
    print("correct:", out["docker_grader"]["correct_command"], flush=True)
    print("wrong:  ", out["docker_grader"]["wrong_command"], flush=True)

    if args.embed_url:
        from memrl.providers.embedding import OpenAIEmbedder
        emb = OpenAIEmbedder(api_key="local-no-key", base_url=args.embed_url, model="served-by-local-desk",
                             token_log_dir=str(LEG / "runs" / "_check_env"))
        vecs = emb.embed(["Create a user named alice", "Count the .log files in /var/log"])
        out["embedding"] = {"via": "memrl.providers.embedding.OpenAIEmbedder", "url": args.embed_url,
                            "n": len(vecs), "dim": len(vecs[0])}
        print("embedding:", out["embedding"], flush=True)

    ok = (ntr == 350 and nva == 150 and overlap == 0 and out["docker_grader"]["correct_command"]["graded_correct"]
          and not out["docker_grader"]["wrong_command"]["graded_correct"])
    out["all_ok"] = bool(ok)
    (LEG / "measured").mkdir(exist_ok=True)
    (LEG / "measured" / "check_env.json").write_text(json.dumps(out, indent=2))
    print("ALL OK" if ok else "SOMETHING FAILED", flush=True)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
