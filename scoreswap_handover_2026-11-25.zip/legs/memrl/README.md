# L3: the model-swap test on MemRL's own released code (revision 2)

**The story.** A garage helper (the OLD model) works through 350 practice jobs ten times with
MemRL, and builds a box of repair notes. MemRL gives every note a score (its Q-value) from how
the jobs went whenever the note was handed over. A NEW helper arrives and does 150 exam jobs with
that box. We compare two ways of using the same box: the scores as learned (`keep`), and the same
scores dealt out again at random among notes that were handed over about equally often
(`shuffle_visit`, a fresh deal on every repeat). But first the OLD helper sits the same exam with
its own box under both: if the learned order does not help even at home, the swap says nothing
for that pair, and we say so.

**Why this leg.** Reviewers said the main study (one stored example shown per task) looks like
"exemplar selection sold as agent memory", and that the agent leg could not carry the bridge: one
contrast, no power statement, one shuffle permutation, upgrade pairs only, a control that breaks
the link between Q and exposure. Revision 2 (24 Nov 2026) answers each point; the leg is still
run only on MemRL's released code (MemTensor/MemRL, MIT, commit
`c1b322ca43de36ddf64c6712f89d0095bfc35ce0`) on LifelongAgentBench's OS tasks (multi-step bash
agent, up to 15 turns, 5 memories shown per episode).

Everything here was built and checked **without a single paid model call**.

| Reviewer point (R5 W2 / Q4, R4 W4, AC N7 / action 5) | Revision 2 |
|---|---|
| no minimum detectable effect | section 2.5: about 5 points per pair with 8 repeats (2.5-4.6 alone, 3.6-6.4 under Holm over 12; the round-1 design: 4.7-8.1) |
| home contrast not required | section 2.4: the home gate and four registered readings |
| one shuffle permutation (seed 0) | a fresh permutation per repeat; the spread is reported |
| `shuffled` breaks Q vs exposure; Q mixes usefulness and task difficulty | `shuffle_visit` (within visit-count strata) is the registered control; `shuffle_bucket` (within same-similarity neighbourhoods) and the global shuffle are secondary |
| upgrade pairs only, no cross-maker pair | both directions of every same-maker pair plus one cross-maker swap per block, in a fixed block order so a cut never leaves one kind |
| "measures keep - shuffled rather than ranking" | section 2.6: a per-task ranking measure from the logs (free), and the priced one-memory probe |
| pay-to-relearn not an arm | `relearn`: the new model runs one more MemRL pass on the frozen content |

---

## 1. What works today, without keys

| Check | Result | Evidence |
|---|---|---|
| MemRL cloned at the pin, 4 patches applied by script | applies cleanly to a fresh checkout; re-running is a no-op | `SOURCE_SHA`, `apply_patches.sh`, `patches/` |
| Isolated Python 3.10 env with MemRL's requirements | 187 packages, wheels only (no install script ran) | `env/`, `env_freeze.txt` |
| Docker image `local-os/default` | their Dockerfile with the base pinned (Ubuntu 24.04.4) | `docker/` |
| Data | 350 train + 150 validation tasks load through MemRL's `build_task`; the shipped default file is rejected | `measured/check_env.json` |
| Container + grader | hand-written correct command graded CORRECT, wrong command INCORRECT (task 101) | `measured/check_env.json` |
| Reference answers | 499 / 500 pass; validation task 359 is broken in the dataset (ceiling 149 / 150) | `measured/ground_truth_check.json` |
| Embedding endpoint | local OpenAI-compatible desk (text-embedding-3-large through the desk, or bge) | `local_server.py` |
| Whole flow with a stub model | round 1: one pair, 14 cells; revision 2: one pair, both directions, 34 cells incl. relearn, then the gated readings | section 9 |
| Arm copies differ only in Q | every copy of every bank checked file by file (stub banks and the full-size simulated bank) | `arms_check.json` files |
| Power analysis | binary model with ceiling, Monte Carlo check | `tools/power_family_L.py`, `measured/power_family_L.json` |
| Tests | 30 unit tests pass (leg env: 18 for the arm copies and MemRL's own retrieval, 2 for the logged provider; project venv: 8 for designs and power, 2 for the gated readings); 2 end-to-end tests (the revision-2 pair flow; training resume) | section 9 |

## 2. The design (revision 2)

### 2.1 Arms (all on MemRL's own `_evaluate`, bank frozen: no Q update, no new memory)
| Arm | What is on disk (a copy of the bank; only Q changes) | Role |
|---|---|---|
| `keep` | Q as learned | registered |
| `shuffle_visit` | learned Q permuted only among memories in the same visit-count stratum (0, 1, 2, 3-4, 5-8, 9-16, 17+ training episodes shown), over the memories retrieval can reach; a fresh permutation per repeat (seed = repeat) | registered control |
| `shuffled` | one permutation over all reachable memories per repeat (the round-1 control) | secondary |
| `shuffle_bucket` | permuted only within a retrieval bucket (the memories stored under one training task's query: identical similarity to every new task, so only Q decides among them) | secondary |
| `wipe` | every Q = 0.5 (MemRL's start value): retrieval by similarity alone | secondary |
| `relearn` | the reader runs ONE more MemRL training pass over the 350 training tasks on the old bank, content frozen (patch 0003): only Q moves | secondary: pay-to-relearn |
| `own` | the reader's own bank, `keep` | secondary |
| `none` | no memory | secondary |

Why `shuffle_visit`: MemRL credits every shown memory with the episode's reward
(`memory_service.py:812-820`), so Q mixes what a memory is worth with how often, and on which tasks,
it was shown. A global shuffle hands a rarely shown memory's untouched 0.5 to a memory shown 30
times and vice versa, so keep - shuffled > 0 could come from exposure alone. Inside a visit stratum
the exposure is held about fixed; keep - shuffle_visit is what the order says beyond that.
`shuffle_bucket` holds the neighbourhood fixed instead (the task source and its difficulty).

### 2.2 Directed swaps and the fixed run order
Block k (Anthropic, OpenAI, Qwen, Gemma, in that order) trains maker k's old and new model and adds
three directed swaps: upgrade (old -> new), downgrade (new -> old), and **cross-maker** (maker k's old
model read by maker k+1's new model, cyclic over the makers in the design). The cross-maker reader
needs no training of its own. A budget cut removes whole blocks from the end, so every completed
scope has both kinds of swap (tested: `test_every_budget_cut_keeps_both_kinds_of_swap`).

| Design | Blocks | Directed swaps | Repeats: keep, shuffle_visit / secondary / none | Extras |
|---|---|---|---|---|
| minimum | 1-2 | 6 (4 same-maker, 2 cross-maker: haiku-4.5 -> gpt-6-luna, gpt-5.6-luna -> haiku-5.5) | 8 / - / 2 | - |
| **recommended** | 1-4 | 12 (8 same-maker, 4 cross-maker: haiku-4.5 -> gpt-6-luna, gpt-5.6-luna -> qwen3.8-27b, qwen3.5-27b -> gemma-4-31b, gemma-3-27b -> haiku-5.5) | 8 / 2 / 2 | relearn for every swap |
| full | 1-4 | 12 | 8 / 8 / 2 | relearn; in-bank (the 350 training tasks) x 4; one-memory probe (priced, not built) |

Each home cell and each swap cell runs `keep` and `shuffle_visit` 8 times; each model's home `keep`
doubles as its `own`.

### 2.3 What is measured
Task success from LifelongAgentBench's grader. Per directed swap X -> Y, paired on the 150
validation tasks with the repeats averaged per task:
- **H** = keep - shuffle_visit for X on its own bank (the home gate);
- **S** = keep - shuffle_visit for Y on X's bank (the swap contrast);
- **drop** = H - S.
Intervals and one-sided p by task-level bootstrap (2,000 draws). Because each shuffle repeat is a
new permutation, the permutation variance is inside every interval, and `permutation_spread.csv`
shows the SD of success across shuffle repeats beside the SD across keep repeats (run noise alone).

### 2.4 Registered readings (prereg Part 8.4; family L)
1. Home gate: one-sided p_H.
2. "Survives": intersection-union p = max(p_H, p_S), Holm over the directed swaps run.
3. "Lost": one-sided p_drop for drop > 0, Holm over the directed swaps run (its own family).
Applied in order: p_H > 0.05 -> **uninformative for this pair** (S shown, not read); step 2 rejects ->
**the order matters at home and survives**; p_S > 0.05 and step 3 rejects -> **matters at home and
is lost**; otherwise **matters at home; after the swap undetermined**. Never "the order does not matter".

### 2.5 Power (before any run)
`tools/power_family_L.py`: 0/1 outcomes with the ceiling respected; for task t the success
log-odds are the task's own level plus, on the share f of tasks whose shown memories change under
the shuffle, the shown set's effect (keep's set fixed per task, the shuffle's set redrawn every
repeat) plus the order's effect gamma. Stated scenarios (not data): success 0.85 / 0.75 / 0.70;
repeatability ICC 0.6 / 0.5 / 0.3; a different set of 5 memories moves a task at 50 % success by
about 10 / 15 / 20 points. f = 1.00 from the rehearsal (MemRL's own retrieval on a full-size bank,
section 9.2; only this structure number is taken from it, never an effect size). A Monte Carlo of
whole experiments reproduces the formula's 80 % power (R8: 0.804 at 4.9 points; R2: 0.806 at 6.3 points).

MDE in success points (80 % power, one-sided 0.05, 150 tasks; "gated" = home and swap must both reject, equal effects):

| Scenario | Repeats | SD of D_t | one pair alone | Holm over 6 (minimum) | Holm over 12 (recommended) | gated, alone | gated, Holm over 12 |
|---|---|---|---|---|---|---|---|
| optimistic | 2 | 0.228 | 4.6 | 6.2 | 6.7 | 5.4 | 7.6 |
| optimistic | 4 | 0.166 | 3.4 | 4.5 | 4.9 | 4.0 | 5.6 |
| optimistic | 6 | 0.138 | 2.8 | 3.7 | 4.1 | 3.3 | 4.7 |
| optimistic | 8 | 0.121 | 2.5 | 3.3 | 3.6 | 2.9 | 4.1 |
| optimistic | round-1 design: 2, one permutation | 0.230 | 4.7 | (Holm over 4: 5.9) | | | |
| central | 2 | 0.311 | 6.3 | 8.2 | 8.8 | 7.3 | 9.9 |
| central | 4 | 0.228 | 4.6 | 6.0 | 6.5 | 5.4 | 7.3 |
| central | 6 | 0.192 | 3.9 | 5.1 | 5.5 | 4.5 | 6.1 |
| central | 8 | 0.171 | 3.5 | 4.5 | 4.9 | 4.0 | 5.5 |
| central | round-1 design: 2, one permutation | 0.315 | 6.4 | (Holm over 4: 7.9) | | | |
| pessimistic | 2 | 0.392 | 7.9 | 10.2 | 11.0 | 9.2 | 12.2 |
| pessimistic | 4 | 0.293 | 5.9 | 7.7 | 8.2 | 6.9 | 9.2 |
| pessimistic | 6 | 0.250 | 5.1 | 6.6 | 7.0 | 5.9 | 7.8 |
| pessimistic | 8 | 0.225 | 4.6 | 5.9 | 6.4 | 5.3 | 7.1 |
| pessimistic | round-1 design: 2, one permutation | 0.401 | 8.1 | (Holm over 4: 10.0) | | | |

**Reading the table.** The round-1 design (2 repeats, one permutation) detected 4.7-8.1 points for one pair alone (Holm over 4: 5.9-10.0); the
reviewer's 7-11 points is the pessimistic-to-central range of that design. With 8 repeats and a
fresh permutation per repeat, a single pair detects 2.5-4.6 points, and under Holm over the 12
directed swaps of the recommended design 3.6-6.4 points (4.1-7.1 gated). So the leg is powered for **about 5
points per pair**; the gated reading (home and swap both needed) costs about one more point.
Holm's later steps are easier than the worst case shown. What more would take: 5 points gated
under Holm-12 at R = 8 needs 182 (central) to 303 (pessimistic) validation tasks, more than LifelongAgentBench OS holds
(150 held out; a 2-fold cross-fit on all 500 tasks would give 500 held-out tasks for about 1.4x
the training cost and 3.3x the evaluation cost, with a split that is no longer MemRL's; not chosen). Beyond 8 repeats the gain is small (the
keep set's own effect on each task does not average out). MemRL's own held-out gain over its
strongest baseline (MemP) was about 2.6 points on these tasks (paper Table 2: 0.746 vs MemP 0.720 on OS); if the
order effect at home is that small, the honest outcome is "uninformative", and the leg says so.

### 2.6 Ranking inside the leg
- **Free, from the logs (secondary, observational).** The shuffle arms show memories chosen by a
  random permutation, not by Q, so across a task's shuffle episodes (8 + 2 + 2 per cell) each
  memory is sometimes shown and sometimes not. Per validation task, for pairs of such memories,
  does the old Q order agree with "solved more often when shown"? Pooled concordance
  (`task_rank.csv`, 0.5 = chance, task bootstrap), at home and after each swap. Up to 5 memories
  share each outcome, so it is an association.
- **Experimental, priced.** A one-memory probe (each validation task run with each of its 8 most
  similar memories alone, 2 repeats: 2,400 episodes per cell) would give a per-task ranking like the
  main study's. It needs a small extra patch (show exactly one chosen memory) and costs USD 75
  for the 20 home and swap cells of the recommended design (included in the full design).


## 3. MemRL's mechanisms this leg relies on (line numbers at c1b322c)

### 3.1 Training loop and reward
- Sections: every section replays all training keys (`memrl/run/llb_rl_runner.py:327-332`),
  in mini-batches of `batch_size` 5 run in parallel (`:488-499`).
- Per episode: one retrieval before the episode (`:601-605`), memories placed in the system
  prompt (`:615-619`, `lifelongbench_eval/prompts.py:102-123`), then up to `max_steps` 15 agent turns (`:723-733`).
- After each mini-batch: `update_values` (`:1204-1207`) gives **every** retrieved memory of an
  episode that episode's reward, 1 or 0 (`memory_service.py:812-820`; `rl_llb_config.yaml:155-156`),
  Q <- 0.7 Q + 0.3 r (`value_driven.py:193-195`, alpha 0.3, gamma 0). Then one new memory per
  episode: success -> LLM-written script plus the trajectory; failure -> LLM reflection
  (`updater.py:316-343`). New memories start at Q 0.5 whether they succeeded or failed
  (`llb_rl_runner.py:1240-1244`, `rl_llb_config.yaml:153-154`).
- A snapshot after every section (`llb_rl_runner.py:1347-1349`).
- Evaluation (`_evaluate`, `:998-1084`) retrieves and runs episodes but never calls
  `update_values` or `add_memories`.

### 3.2 Where Q is read at retrieval (`memory_service.py:1254-1506`)
1. Similarity of the task to every stored query; keep those >= threshold 0.50 (`:1305-1313`),
   the top `k_retrieve` 10 queries (`:1315-1316`), all memories stored under them (`:1321-1358`).
2. Q of each candidate: `_q_cache` if it has the id (`:1378-1379`), else the item's metadata
   (`:1381-1390`, from `_mem_cache` or the MemOS store `:1326-1335`), else `q_init_pos`.
3. Score = 0.5 * (sim - 0.1857) / 0.0941 + 0.5 * clip((Q - mean_Q) / sd_Q, -3, 3), mean and sd
   over **this task's candidates** (`:1239-1252`, `:1442-1460`).
4. Top `topk` 5 by score; with probability epsilon 0.01 a random 5 instead (`:1465-1473`).

### 3.3 The three places Q is stored, and which wins
| Place (in `snapshot/<section>/`) | Written by | Read |
|---|---|---|
| `local_cache/q_cache.json` | `memory_service.py:2083-2092` | first, at every retrieval (`:1378`); restored on load (`:2177-2197`) |
| `local_cache/mem_cache.json` (item metadata `q_value`) | `:2065-2081` | only if the id is not in q_cache (`:1326`, `:1381`) |
| `cube/textual_memory.json` (payload metadata `q_value`) + `qdrant/` | `cube.dump` (`:1694`), Qdrant copy (`:1696-1700`) | on load the JSON is upserted into the store (MemOS `memories/textual/general.py:171-191`), so the JSON wins over the Qdrant copy; Q updates read the store (`value_driven.py:186-193`) |

Two traps found on the way, both handled by `qsnap.py`:
- **mem_cache is stale.** Q updates write the store and q_cache but never `_mem_cache`, so its
  metadata keeps old values. Seen in the stub run: 11 of 20 memories had a mem_cache Q that
  differed from the Q MemRL actually used.
- **A copied snapshot loads the ORIGINAL.** `snapshot_meta.json` holds absolute `cube_dir` /
  `qdrant_dir`, and the loader prefers them when they exist (`_resolve_snapshot_dirs`,
  `memory_service.py:188-225`, used at `:1802-1810`). A plain `cp -r` of a bank would silently load
  (and write into) the source bank.

**How `qsnap.py` makes an arm** (`qsnap.py make <snapshot> <dest> --arm ...`): copy the snapshot
without `qdrant/`; compute each memory's effective Q (q_cache > mem_cache > textual > 0.5); write
the arm's target Q into **all three** places for **every** memory (so no read can fall back to a
stale value); leave an empty `qdrant/` (rebuilt from the edited JSON on load); rewrite
`snapshot_meta.json`'s paths to the copy and record the provenance (arm, source, seed, hash of
the Q map) there and in `ARM.json`. It never writes to the source and refuses to overwrite.
`qsnap.py verify A B` proves two copies are identical except for `q_value` fields. Every
evaluation run then makes its own private copy (loading writes to the store).

### 3.4 Why a single global discount changes nothing
Q enters the score only through z = (Q - mean_Q) / sd_Q over the candidates
(`memory_service.py:1443-1454`). Any Q -> a + bQ with b > 0 (a discount toward the start value
is a = 0.5(1 - lambda), b = lambda) leaves every z unchanged, hence the clip, the score, the
ranking and the selection. The other Q-dependent steps do not bind for Q in [0, 1]:
`q_min_threshold` -0.8 (`:1425-1427`), `q_floor` 0.0 (`:1410-1416`), `recency_boost` 0 (`:1405`).
(The one edge case: if all candidates' Q differ by less than 1e-9, sd is replaced by 1.)
Checked with MemRL's own `retrieve_query` (`memrl_probe.py`, and the test
`test_memrl_retrieval_discount_is_a_no_op_and_wipe_is_similarity_only`). The same arithmetic
shows `wipe` is retrieval by similarity alone: all Q equal -> sd 0 -> replaced by 1 -> every
z is 0 -> score = 0.5 * sim_z.

## 4. What MemRL's code does not allow as written, and what we changed

1. **No "evaluate only" entry point, no 350/150 run.** The shipped config trains on all 500
   tasks (`rl_llb_config.yaml:106-108`) and its default data file is rejected by the task loader
   (string fields). We point `split_file` / `valid_file` at `os_interaction_train.json` /
   `_val.json` in a generated config (no code change) and add `--eval-only` (patch 0002), which
   calls MemRL's own `_evaluate` once on a loaded bank.
2. **Epochs.** The shipped YAML says 20 sections (`:111`); the paper's OS runs are 10 epochs
   (App. H; Table 1). We use **10** (`--sections` changes it; 20 roughly doubles training cost).
3. **Temperature.** MemRL asks for temperature 0.0 (agent), 0.3 (reflection), 0 (keywords)
   (`providers/llm.py:216,333`, `updater.py:264`). Current Claude models reject temperature < 1,
   and the study's rule is: no temperature to closed models, the `config/models.yaml` values
   (temperature 1.0 etc.) for open models. So no MemRL temperature is sent; each call logs what
   was dropped. This makes agent answers more varied than in the paper. Same for every arm.
4. **Credit and timing are MemRL's, not ours.** Up to 5 memories share each episode's reward;
   Q is updated after each batch of 5 parallel episodes, which retrieved with the Q from before
   the batch. So Q mixes what a memory is worth with how often, and on which tasks, it was shown.
   The leg keeps this (it is MemRL) and controls for exposure with the within-visit shuffle
   (section 2); the per-memory statistics stay observational.
5. **Exploration at evaluation.** MemRL's epsilon 0.01 random retrieval also applies in
   `_evaluate`; kept (their setting), identical in all arms.
6. **`test_interval` is never used** by the LLB runner (only stored, `llb_rl_runner.py:147`);
   only `valid_interval` triggers an evaluation (`:1357-1364`). Correction to the 17 Nov note,
   which said it doubles the calls.
7. **The YAML's similarity statistics are never read.** `run_llb.py:238-255` builds
   `MemoryService` without `sim_norm_mean/std`, so the class defaults 0.1857 / 0.0941
   (`memory_service.py:311-312`) apply, not 0.39 / 0.14 (`rl_llb_config.yaml:50-51`). Our check
   shows 0.388 / 0.140 are exactly the mean / sd of text-embedding-3-large cosines over OS task
   pairs, so the authors computed them but the runner does not pass them. We keep the released
   behaviour. Correction to `memory_systems_and_tasks.md` §1.
8. **Thinking.** Claude goes through Anthropic's OpenAI-compatible endpoint, as asked. That
   layer accepts a `thinking` field in the request body and never returns thinking text; it
   documents `{"type": "enabled", ...}` and ignores `reasoning_effort`. Haiku 5.5's
   `{"type": "disabled"}` (from `config/models.yaml`) is sent the same way; **whether the compatibility
   layer accepts "disabled" is not documented - check at the smoke test** (if refused, the
   provider stops the run at once; the fallback is the native SDK route).

**Patches** (`patches/`, applied by `apply_patches.sh`; their files are never edited by hand):

| Patch | What it does |
|---|---|
| 0001 `memrl/providers/leg_chat.py` (new file) | The one chat provider: model, route, thinking and sampling from a JSON spec written from `config/models.yaml`; key read from the environment variable it names (ANTHROPIC_API_KEY, OPENAI_API_KEY, OPENROUTER_API_KEY); drops MemRL's temperature; logs every call to `runs/<run>/calls.jsonl` with the fields of `msr/llm.py`'s `CallResult` and stores each prompt once (gzip) by its sha256; spending guard on the study's `runs/spend.json` and `budget.hard_cap_usd`; replay cache within one evaluation run; **any rejected or failed call stops the process** (`FATAL.json`, exit 17) instead of becoming a silently failed episode. |
| 0002 `run/run_llb.py` | uses that provider when `MSR_LEG_MODEL_JSON` is set; `--eval-only`; log folder from the environment; similarity statistics from the environment only for the bge stand-in. |
| 0003 `memrl/run/llb_rl_runner.py` | fixed checkpoint folder per run; one JSON line per episode (phase, section, task, success, steps, LLB status, memories shown with Q / similarity / z-scores); tags each model call with its task; re-run only listed validation tasks; a summary file; and (revision 2) `MSR_LEG_FREEZE_CONTENT=1`, which keeps MemRL's Q updates but adds no memory, for the `relearn` arm. |
| 0004 `memrl/service/memory_service.py` | the vector-store dimension (hard-coded 3072) from the environment, for the 768-d stand-in. |

## 5. Setup (pinned, reproducible)

```bash
legs/memrl/setup.sh        # clone at the pin + patches, env, Docker image, RoMeRL data; re-run safe
legs/memrl/env/bin/python legs/memrl/check_env.py --embed-url http://127.0.0.1:8791/v1   # needs a desk on 8791
```
- `src/` (MemRL), `env/`, `calib/romerl/`, `runs/` are git-ignored (`legs/memrl/.gitignore`).
- **Environment.** Python 3.10.22 (conda, `env/`). `requirements.leg.txt` is MemRL's
  `requirements.txt` minus `alfworld`, `browsergym`, `textworld`, `fast-downward-textworld` (other
  benchmarks; the last compiles C++ at install), with `torch==2.8.0` taken from the PyTorch CPU
  index. Installed with `--only-binary=:all:`: no package ran a setup script. Key versions:
  MemoryOS 1.0.0, openai 1.109.1, qdrant-client 1.20.0, docker 7.1.0, pydantic 2.14.4.
- **Their Dockerfile** (`3rdparty/LifelongAgentBench/scripts/dockerfile/os_interaction/default`):
  `FROM ubuntu` (unpinned "latest"), `apt install` python3, python3-pip, git, vim, curl, wget,
  unzip, zip, tree, `CMD bash`. Nothing else. LLB starts one fresh container per task
  (`os_interaction/task.py:158`, `container.py:14-23`, `remove=True`, label
  `created_by=os-pipeline`), runs the task's setup, the agent's bash, then the check script
  (`task.py:154-270`). Ours (`docker/Dockerfile`) is the same with `FROM` pinned to Ubuntu 24.04
  by digest (sha256:4fbb8e6a...), because "latest" is now a newer Ubuntu than the tasks were
  written for. Image id and package list: `docker/IMAGE_ID`, `docker/IMAGE_PACKAGES.txt`.
- **The OS tasks need no MySQL image** (that is the DB task).

## 6. Embeddings

**What MemRL needs.** An OpenAI-style `/v1/embeddings` endpoint, used in two places with the
same model: MemRL's `OpenAIEmbedder` (`run_llb.py:145-151`, `providers/embedding.py:181`) for task
and query vectors, and MemOS's `universal_api` embedder (`run_llb.py:187-195`,
`memory_service.py:360-370`) which embeds each memory's key when it is added **and again on every
Q update** (MemOS `general.py:102-115`). The configured model is `text-embedding-3-large`; the
vector store's size is hard-coded to 3072 (`memory_service.py:381`, `:1840`).

**The local desk** (`local_server.py`, run by `run_leg.py` with the project venv) answers that
endpoint, keeps every vector it makes (one file per distinct text), and logs every request. It
is the single embedding route for every chat model, so the embedding model is fixed across the
swap:
- `--embed te3l` (default for real runs): text-embedding-3-large, MemRL's own setting. The desk
  calls OpenAI itself with OPENAI_API_KEY from `.env`, so the key never enters MemRL's process or
  a file. Each distinct text is paid once: about 500 instructions x ~60 tokens, i.e. **under one
  cent for the whole leg**.
- `--embed bge` (default for `--fake`; free fallback): bge-base-en-v1.5 from `msr/embed.py`.
  It works mechanically (patch 0004 sets the 768-d store), but MemRL's two tuned constants were
  cut for text-embedding-3-large. `tools/calibrate_bge.py` converts them using RoMeRL's released
  text-embedding-3-large vectors for 498 of the 500 OS instructions (no API call):
  threshold 0.50 -> **0.688** (same share of task pairs kept, 19.4 %), similarity sd 0.0941 -> **0.0629**
  (least-squares line bge = 0.339 + 0.669 te3l). Even so the two embedders agree on the nearest
  train task for only **51 %** of validation tasks, and on **67 %** of the top-10 candidate queries
  (`calib/bge_calibration.json`). So bge would be "MemRL with a different embedder".
  **Recommendation: use te3l for the paper runs** (cost negligible); bge stays for the free
  pipeline runs and as a fallback if no OpenAI key arrives.

## 7. Running it for real

Before: keys in `.env` (ANTHROPIC_API_KEY; OPENAI_API_KEY, also for the embeddings; OPENROUTER_API_KEY
from block 2's cross-maker reader on), the owner's yes on the cost of section 8, and
`budget.hard_cap_usd` raised (it is 30 today). Do not run two leg stages at the same time (a failed
stage kills all `created_by=os-pipeline` containers).

```bash
cd Model_Swap_Research
.venv/bin/python legs/memrl/run_leg.py estimate                       # the three designs, per block; spends nothing
# smoke test first (well under USD 1): route, thinking setting, logged model_id
.venv/bin/python legs/memrl/run_leg.py eval --reader haiku-5.5 --arm none --limit-val 3 --embed bge --runs-root legs/memrl/runs/smoke --yes
.venv/bin/python legs/memrl/run_leg.py campaign --design recommended --yes   # blocks 1-4 in the fixed order
.venv/bin/python legs/memrl/run_leg.py collect --design recommended          # readings + tables -> legs/memrl/results/
```
`campaign` runs block by block; inside a block: train the bank owner when its bank is first needed,
make its arm copies (keep, wipe, discount, 8 permutations of each shuffle; every copy verified, and
MemRL's own retrieval probed on each), the primary cells (home gate and swap contrasts, 8 repeats),
`none`, then the secondary cells and `relearn`. Single stages: `train`, `arms`, `relearn`,
`eval --reader R --bank B --arm A --repeat r`, and `pair --old A --new B` (one pair, both
directions). Every stage is re-run safe (DONE files; training resumes after the last saved
section; an evaluation re-runs only missing tasks and replays answers already paid for in that
run). To stop at a budget, stop between blocks: the next `campaign` call continues where it stopped.

**Disk.** A real bank snapshot is about 260-300 MB (3,500 memories with 3,072-number vectors stored as
JSON). So a finished training keeps only its final snapshot; every arm copy except `keep` is slimmed
to its record (`ARM.json` + the Q map) after it has been checked and probed, and is rebuilt exactly
(same Q map, checked by hash) when an evaluation needs it; a finished evaluation drops its private
copy. Peak use is about 8 GB while one bank's 27 copies are being checked.

## 8. Calls, tokens and cost

Basis (measured from MemRL's code and data, `measured/prompt_sizes.json`, tokens = chars/4): system
prompt 244 tokens; LLB's OS instructions 383; task instruction 56; 5 memories add 4,301 tokens to
every turn (MemRL's own formatter on the 679 MemRL-format memories of RoMeRL's released OS bank);
2.0 agent turns and 249 output tokens per turn (RoMeRL's trajectories: an estimate); one
memory-building call per training episode (~1,140 in, ~395 out). Per training run (350 tasks x 10
passes): 10,500 calls, 41.1 M input, 3.1 M output tokens. Per evaluation run with memory (150 tasks):
300 calls, 1.6 M input. `relearn`: one pass, 700 calls, 3.7 M input. Prices: `config/models.yaml`
(23 Nov 2026). Range x0.7 to x2.5 (turns per episode; input grows with the square of the turns).
`run_leg.py estimate` prints all of this; `measured/estimate_designs.json` holds it.

| Design | Block (pair; cross-maker swap) | Calls | USD | range (x0.7-x2.5) | cumulative USD |
|---|---|---|---|---|---|
| minimum | 1: haiku-4.5 <-> haiku-5.5; haiku-4.5->gpt-6-luna | 46,800 | 136.32 | 95-341 | 136.32 |
| minimum | 2: gpt-5.6-luna <-> gpt-6-luna; gpt-5.6-luna->haiku-5.5 | 45,600 | 40.43 | 28-101 | 176.75 |
| **minimum total** | 6 directed swaps, 4 trainings, 168 evaluation runs | **92,400** | **176.75** | **124-442** | by kind: train 80, eval 97 |
| recommended | 1: haiku-4.5 <-> haiku-5.5; haiku-4.5->gpt-6-luna | 59,700 | 173.65 | 122-434 | 173.65 |
| recommended | 2: gpt-5.6-luna <-> gpt-6-luna; gpt-5.6-luna->qwen3.8-27b | 59,100 | 57.49 | 40-144 | 231.14 |
| recommended | 3: qwen3.5-27b <-> qwen3.8-27b; qwen3.5-27b->gemma-4-31b | 59,100 | 86.29 | 60-216 | 317.43 |
| recommended | 4: gemma-3-27b <-> gemma-4-31b; gemma-3-27b->haiku-5.5 | 58,500 | 38.15 | 27-95 | 355.58 |
| **recommended total** | 12 directed swaps, 8 trainings, 480 evaluation runs | **236,400** | **355.58** | **249-889** | by kind: train 123, eval 220, relearn 12 |
| full | 1: haiku-4.5 <-> haiku-5.5; haiku-4.5->gpt-6-luna | 144,100 | 387.77 | 271-969 | 387.77 |
| full | 2: gpt-5.6-luna <-> gpt-6-luna; gpt-5.6-luna->qwen3.8-27b | 143,500 | 134.60 | 94-336 | 522.37 |
| full | 3: qwen3.5-27b <-> qwen3.8-27b; qwen3.5-27b->gemma-4-31b | 143,500 | 195.85 | 137-490 | 718.22 |
| full | 4: gemma-3-27b <-> gemma-4-31b; gemma-3-27b->haiku-5.5 | 142,900 | 88.24 | 62-221 | 806.46 |
| **full total** | 12 directed swaps, 8 trainings, 1072 evaluation runs | **574,000** | **806.46** | **565-2016** | by kind: train 123, eval 596, relearn 12, probe 75 |

Training is now a minority of the cost: the eight repeats of keep and shuffle_visit in every home
and swap cell dominate, and Haiku 4.5 as a reader (its home cells and the Haiku downgrade) is the
largest single item. The round-1 design (4 pairs, both directions, 2 repeats, one permutation) was
USD 176 and could detect only about 6-8 points per pair (section 2.5).

## 9. Rehearsals (no paid call)

### 9.1 The stub model through MemRL's full stack
The stub (`local_server.py --fake-chat`) answers like a model: per task it either sends the task's
reference command or only looks around, decided by a hash of (model, task, the memories in the
prompt), so memories change outcomes and Q moves; the real container and grader decide. Two pretend
makers (fake-*, fakex-*) let the campaign's block order and cross-maker swaps run too.
- Round 1 (23 Nov): train -> 3 arm copies -> 14 evaluation runs -> tables; every chat call logged,
  none with a temperature; MemOS never called a chat model on its own.
- Revision 2: one pair, both directions, keep and shuffle_visit x 2 repeats (a new permutation per repeat), the secondary arms x 1, relearn on both banks, none: all 34 evaluation runs and both relearn passes finished in real containers (6 training tasks x 2 passes, 3 validation tasks). Every copy of both banks equals keep except Q; both relearned banks have the same content as the old bank with 12 Q-values moved; each shuffle repeat read its own permutation; finished runs keep no private copy; all 300 chat calls went through the logged provider, none with a temperature; collect wrote the gated readings (both swaps 'uninformative', as expected with a stub and 3 tasks). The first attempt hit the test's 50-minute limit on the loaded machine (other workers' jobs, load 40-50); re-running the same stage finished the remaining cells without redoing any (re-run safety), and every check of the test passes on the result. The test's limit is now 14,000 s.

### 9.2 What the stratified shuffle changes (structure only)
- **Full-size simulated bank (350 tasks x 10 passes; MemRL's retrieval and update rule, dice outcomes; `tools/simulate_bank.py`)** (3,500 reachable memories in 350 buckets): 31% never shown in training (Q stays 0.5); Spearman(Q, visits) +0.08; 20% of the Q variance lies between visit strata. Share of validation tasks whose 5 shown memories change against `keep`: global shuffle 1.00 (SD 0.00 over permutations; mean overlap with keep's 5 0.05); **within-visit 1.00 (SD 0.00 over permutations; mean overlap with keep's 5 0.10)**; within-bucket 0.99 (SD 0.01 over permutations; mean overlap with keep's 5 0.21); wipe 0.94; discount 0.00. All 14 copies identical to `keep` except Q: yes.
- **Stub-model bank after 3 real MemRL passes (Docker, stub chat model; the 10-pass run was stopped because the shared machine ran it at ~15 episodes a minute)** (1,050 reachable memories in 350 buckets): 27% never shown in training (Q stays 0.5); Spearman(Q, visits) -0.07; 3% of the Q variance lies between visit strata. Share of validation tasks whose 5 shown memories change against `keep`: global shuffle 1.00 (SD 0.00 over permutations; mean overlap with keep's 5 0.14); **within-visit 1.00 (SD 0.00 over permutations; mean overlap with keep's 5 0.18)**; within-bucket 0.95 (SD 0.02 over permutations; mean overlap with keep's 5 0.40); wipe 0.98; discount 0.00. All 26 copies identical to `keep` except Q: yes.

What the within-visit shuffle changes. After several passes MemRL's choice of 5 out of up to ~100 candidates is decided mostly by Q (even `wipe` changes the shown set on 94-98 % of tasks), so every shuffle changes the shown memories on essentially every validation task (f = 1.00 enters the power analysis). The within-visit shuffle keeps somewhat more of keep's choice than the global one (mean overlap 0.10 vs 0.05 in the simulated bank, 0.18 vs 0.14 in the stub bank) and leaves the never-shown memories (27-31 %) at their untested 0.5, which the global shuffle hands to tested memories and the other way round. In the simulated bank 20 % of the Q variance lies between visit strata (Q about 0.40 for memories shown once or twice, 0.60-0.63 for those shown 5 times or more): under the global shuffle that part of keep - shuffled is exposure; the within-visit shuffle no longer counts it as order (in the 3-pass stub bank it is only 3 %). The permutations differ from each other (overlap with keep varies by permutation), which is why every repeat draws a new one and the interval includes that spread.

Tests (on this shared machine give the leg's tests their own temporary folder: other workers' pytest
runs delete all but the three newest `/tmp/pytest-of-*` folders, which once removed a running test's files):
```bash
B=--basetemp=legs/memrl/work/pytest_tmp
legs/memrl/env/bin/python -m pytest legs/memrl/tests/test_fake_flow.py legs/memrl/tests/test_leg_chat.py legs/memrl/tests/test_qsnap.py -q $B   # leg env (Docker)
.venv/bin/python -m pytest legs/memrl/tests/test_design_power.py legs/memrl/tests/test_collect.py legs/memrl/tests/test_qsnap.py -q $B  # project venv
```

## 10. Risks

1. **Ceiling and small effects.** 2026 models may solve 80-90 % of these tasks; the ceiling is
   149 / 150. MemRL's own held-out gain over its strongest baseline (MemP) was ~2.6 points on these tasks. If the order's
   effect at home is below ~4-5 points, most pairs will read "uninformative" or "undetermined":
   the leg then shows the limit of what a 150-task agent benchmark can say, not a negative result.
2. **Shared credit, batch updates** (MemRL's design): Q is a noisy, partly collective score. The
   within-visit shuffle controls exposure, not every confounder (e.g. the difficulty of the tasks a
   memory was shown on is only held fixed by `shuffle_bucket`).
3. **One training per model** (bank-to-bank noise is not measured here).
4. **Docker** (one container per episode; about 0.3 million container starts in the recommended
   design): start failures in evaluation are re-run; in training they count as failures (MemRL's
   behaviour), logged in `episodes.jsonl`.
5. **Time.** About 480 evaluation runs plus 8 trainings: roughly 70-90 hours of wall time at 5
   episodes in parallel, unless several evaluation runs are launched side by side (they are
   independent; rate limits permitting).
6. **Haiku 4.5 retirement**: block 1 runs first, and Haiku 4.5 is trained first inside it.
7. **Cost uncertainty** (turns per episode): x0.7-x2.5; the spending guard stops at the cap.
8. **Licence**: LifelongAgentBench declares none; release ids, outcomes and `episodes.csv`, not task
   text or prompts.
9. **Thinking-off for Haiku 5.5 through Anthropic's compatibility layer** is undocumented; the smoke
   test settles it (a refusal stops the run before any cost).

## 11. Sentences the paper's agent-leg section must use

Use these sentences (numbers from `measured/power_family_L.json`; replace the results sentence when the leg has run):

1. "The main study measures exemplar memory: one stored example is shown per task. To test the same question on an agent memory, we ran MemRL's released code (MemTensor/MemRL, commit c1b322c; changed only to log calls, to send no sampling temperature, to evaluate a frozen bank, and to freeze content for the relearn reference) on LifelongAgentBench's operating-system tasks: a bash agent with up to 15 turns that is shown 5 of up to 10 similar stored experiences in each episode. Each model builds its own bank with MemRL's rule: 10 passes over 350 training tasks, each shown memory's score a moving average of the episodes' 0/1 rewards."
2. "On the 150 held-out tasks, with the bank frozen, we compare the learned order of the scores (keep) with the same scores re-dealt at random among memories that were shown about equally often in training, with a new permutation on each of 8 repeats. Holding the visit count fixed matters because MemRL credits every shown memory with the episode's outcome, so a score also records how often a memory was shown."
3. "The swap contrast is read only where the old model's learned order beats the re-dealt order on its own bank (an intersection-union test; Holm over the 12 directed swaps: both directions of the four same-maker pairs and four cross-maker swaps). Each swap gets one of four registered readings: the order matters at home and survives the swap; matters at home and is lost; matters at home, after the swap undetermined; or uninformative."
4. "By the pre-registered power analysis the leg detects about 5 success points per pair (2.5-4.6 points for one pair alone and 3.6-6.4 points (4.1-7.1 gated) under Holm, across three stated scenarios); the earlier design with 2 repeats and one permutation could detect only 4.7-8.1 points for one pair alone (Holm over 4: 5.9-10.0). Smaller effects are reported as undetermined, not as absent."
5. "Secondary references, reported per directed swap without tests: keep minus wipe (scores reset), the new model's own bank, no memory, and relearn (the new model runs one more MemRL pass on the frozen content, the pay-to-relearn reference); and an observational per-task ranking measure from the re-dealt episodes."
6. Results (template): "Of the 12 directed swaps, the learned order mattered at home in A; of these it survived the swap in B (C same-maker, D cross-maker), was lost in E, and was undetermined in F."
7. Limits: "This is one memory system on one benchmark of short operating-system tasks. Strong models solve most of these tasks, and MemRL's own gain over its strongest baseline (MemP) on held-out tasks was 2.6 points on these tasks and 2.8 points over all its benchmarks (MemRL, Table 2), so some pairs may be uninformative. Up to 5 memories share each episode's outcome, so the per-memory ranking numbers are associations."

Do not write that "memory survives"; write that the learned order of the scores carries over (or is lost). Call MemRL's Q-value a moving average of rewards, not Q-learning.

## 12. Files

| Path | What |
|---|---|
| `run_leg.py` | the stages and the three designs (project venv) |
| `qsnap.py` | arm copies of a bank (keep, wipe, discount, three shuffles), the "only Q differs" and "same content" checks, the bank's structure (stdlib) |
| `memrl_probe.py` | MemRL's own retrieval on every copy, no model call (leg env) |
| `collect.py` | the gated readings, secondary contrasts, permutation spread, ranking measures, RESULTS.md (project venv) |
| `tools/power_family_L.py` | the power analysis (project venv) |
| `tools/simulate_bank.py`, `tools/rehearsal_structure.py` | the full-size structural rehearsal (leg env) and its summary |
| `local_server.py` | the local embedding desk and the stub chat model |
| `check_env.py`, `tools/check_ground_truth.py`, `tools/measure_prompts.py`, `tools/calibrate_bge.py` | environment proofs and the measured basis |
| `patches/`, `apply_patches.sh`, `setup.sh`, `docker/`, `requirements.leg.txt`, `SOURCE_SHA`, `env_freeze.txt` | the pinned setup |
| `runs/<fake or real>/{train,banks,relearn,eval}/` | per run: `config.yaml`, `model_spec.json` (no key), `calls.jsonl`, `prompts/`, `episodes.jsonl`, snapshots, logs, `DONE.json`; banks hold `keep/`, `wipe/`, `discount/`, `<shuffle>_s<seed>/`, `relearn_by_<reader>/`, `arms_check.json`, `retrieval_probe.json` |
| `results/` | `readings.csv`, `secondary.csv`, `permutation_spread.csv`, `task_rank.csv`, `memory_rank.csv`, `arms.csv`, `episodes.csv`, `RESULTS.md` |
| `measured/` | `power_family_L.json`, `rehearsal_probe.json`, `estimate_designs.json`, `prompt_sizes.json`, checks |
