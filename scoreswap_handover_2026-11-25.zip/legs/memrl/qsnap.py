"""Make swap-day copies of a MemRL memory bank that differ ONLY in the Q-values.

Everyday picture: a box of repair tips, each with a score card. For each swap-day rule we
photocopy the whole box and change only the score cards: `keep` (as learned), `wipe` (every card
back to the starting score), `shuffled` (the learned cards dealt out to the wrong tips). The tips
themselves are never touched, and the original box is never opened for writing.

Where MemRL keeps a memory's Q (MemRL c1b322c), and which copy wins:
1. local_cache/q_cache.json  {memory_id: Q}                      written by memory_service.py:2083-2092
2. local_cache/mem_cache.json  {memory_id: item}, item.metadata.q_value      memory_service.py:2065-2081
3. cube/textual_memory.json  [VecDBItem], payload.metadata.q_value           cube.dump, memory_service.py:1694
   (and the Qdrant folder qdrant/, a copy of the vector store, memory_service.py:1696-1700)
On load (memory_service.py:1760-1945) the cube is rebuilt from textual_memory.json, which is
upserted into the Qdrant store (memos GeneralTextMemory.load), then local_cache/ is restored
(:1921-1926, :2103-2196). At retrieval Q is read from q_cache first (:1378-1379); only an id
missing there falls back to the item's metadata (mem_cache, else the store) (:1381-1390).
Q updates (training only) read the store's metadata, not q_cache (value_driven.py:186-193), and
mem_cache's metadata is never refreshed after an update, so it is often stale.

So the effective Q of a memory = q_cache, else mem_cache metadata, else textual_memory metadata,
else q_init. Every arm copy writes its target Q into ALL THREE places for every memory (so q_cache
covers the whole bank and no read can fall back to a stale value), and:
- drops the copied qdrant/ folder (it is rebuilt from the edited textual_memory.json on load);
- rewrites snapshot_meta.json's cube_dir / qdrant_dir: MemRL PREFERS these absolute paths when
  they exist (_resolve_snapshot_dirs, memory_service.py:188-225), so an unedited copy would load
  the ORIGINAL bank's cube and open the original's Qdrant store.

Arms: keep, wipe (Q = q_start for all), discount (Q = q_start + lam (Q - q_start); only used to
show that it changes nothing), and three shuffles of the learned Q, each over the memories that
retrieval can reach (the ids listed in local_cache/dict_memory.json) and seeded (one seed per
evaluation repeat, so the shuffled arm averages over many permutations):
- shuffled        one permutation over all reachable memories (the round-1 control);
- shuffle_visit   permutations only WITHIN strata of visit count (how many training episodes
                  showed the memory: 0, 1, 2, 3-4, 5-8, 9-16, 17+). MemRL credits every shown
                  memory with the episode's reward (memory_service.py:812-820), so Q mixes what a
                  memory is worth with how often and on which tasks it was shown. Keeping each
                  stratum's Q values inside the stratum keeps the link between Q and exposure;
                  keep - shuffle_visit then measures what Q says beyond exposure. Visit counts are
                  read from the store's metadata q_visits (value_driven.py:204, :209-216).
- shuffle_bucket  permutations only WITHIN a retrieval bucket: the memories stored under the same
                  query (dict_memory, memory_service.py:1637-1642), i.e. the same training task's
                  memories from different passes. They have the SAME similarity to every new task,
                  so only Q decides among them; this shuffle keeps each neighbourhood's Q values.
Standard library only, so it runs under either Python.

    python legs/memrl/qsnap.py inspect <snapshot>
    python legs/memrl/qsnap.py make <snapshot> <dest> --arm keep|wipe|shuffled|discount [--seed 0] [--q-start 0.5] [--lam 0.5]
    python legs/memrl/qsnap.py verify <arm_snapshot_a> <arm_snapshot_b>
"""
from __future__ import annotations

import argparse
import hashlib
import json
import random
import shutil
from datetime import datetime, timezone
from pathlib import Path

ARMS = ("keep", "wipe", "shuffled", "shuffle_visit", "shuffle_bucket", "discount")
SHUFFLES = ("shuffled", "shuffle_visit", "shuffle_bucket")
VISIT_EDGES = (0, 1, 2, 3, 5, 9, 17)      # strata: 0 | 1 | 2 | 3-4 | 5-8 | 9-16 | 17+


def visit_stratum(v: int) -> int:
    s = 0
    for i, edge in enumerate(VISIT_EDGES):
        if v >= edge:
            s = i
    return s
Q_KEY = "q_value"


# --------------------------------------------------------------------------- reading
def _read(p: Path):
    return json.loads(p.read_text(encoding="utf-8"))


def _write(p: Path, obj, indent=None) -> None:
    tmp = p.with_name(p.name + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=indent), encoding="utf-8")
    tmp.replace(p)


def snapshot_files(snap: Path) -> dict:
    snap = Path(snap)
    f = {"meta": snap / "snapshot_meta.json", "textual": snap / "cube" / "textual_memory.json",
         "q_cache": snap / "local_cache" / "q_cache.json", "mem_cache": snap / "local_cache" / "mem_cache.json",
         "dict_memory": snap / "local_cache" / "dict_memory.json"}
    missing = [k for k, p in f.items() if not p.exists()]
    if missing:
        raise FileNotFoundError(f"{snap} is not a MemRL snapshot (missing {missing})")
    return f


def _item_q(item: dict):
    md = (item.get("payload") or item).get("metadata") or {}
    return md.get(Q_KEY)


def three_places(snap: Path, q_init: float = 0.5) -> dict:
    """Q of every memory in each of the three places, and the effective Q MemRL would use."""
    f = snapshot_files(snap)
    textual = _read(f["textual"])
    qc = {str(k): float(v) for k, v in _read(f["q_cache"]).items()}
    mc = _read(f["mem_cache"])
    dm = _read(f["dict_memory"])
    bank = [str(it["id"]) for it in textual]
    tq = {str(it["id"]): _item_q(it) for it in textual}
    visits = {str(it["id"]): int(((it.get("payload") or it).get("metadata") or {}).get("q_visits") or 0) for it in textual}
    bucket_of = {}
    for qtext, ids in dm.items():
        for x in ids:
            bucket_of[str(x)] = qtext
    mq = {str(k): ((v or {}).get("metadata") or {}).get(Q_KEY) for k, v in mc.items()}
    eff = {}
    for mid in bank:
        if mid in qc:
            eff[mid] = qc[mid]
        elif mq.get(mid) is not None:
            eff[mid] = float(mq[mid])
        elif tq.get(mid) is not None:
            eff[mid] = float(tq[mid])
        else:
            eff[mid] = float(q_init)
    reachable = sorted({str(x) for ids in dm.values() for x in ids} & set(bank))
    return {"bank": bank, "q_cache": qc, "mem_cache": mq, "textual": tq, "effective": eff, "reachable": reachable,
            "visits": visits, "bucket_of": bucket_of}


def inspect(snap: Path, q_init: float = 0.5) -> dict:
    t = three_places(snap, q_init)
    eff = t["effective"]
    stale = sum(1 for m, q in t["mem_cache"].items() if m in eff and q is not None and abs(float(q) - eff[m]) > 1e-12)
    tdiff = sum(1 for m, q in t["textual"].items() if q is not None and abs(float(q) - eff[m]) > 1e-12)
    vals = sorted(eff.values())
    return {"memories": len(t["bank"]), "reachable_by_retrieval": len(t["reachable"]),
            "in_q_cache": sum(1 for m in t["bank"] if m in t["q_cache"]),
            "q_cache_ids_not_in_bank": sum(1 for m in t["q_cache"] if m not in eff),
            "mem_cache_q_differs_from_effective": stale, "textual_q_differs_from_effective": tdiff,
            "effective_q": {"min": vals[0] if vals else None, "max": vals[-1] if vals else None,
                            "mean": (sum(vals) / len(vals)) if vals else None,
                            "share_equal_q_init": (sum(1 for v in vals if abs(v - q_init) < 1e-12) / len(vals)) if vals else None}}


# --------------------------------------------------------------------------- making arms
def strata_for(arm: str, reachable: list, visits: dict, bucket_of: dict) -> dict:
    """Which memories may exchange Q in a shuffle arm: {stratum key: [memory ids]}."""
    groups: dict = {}
    for m in reachable:
        if arm == "shuffled":
            key = "all"
        elif arm == "shuffle_visit":
            key = f"visits:{visit_stratum(visits.get(m, 0))}"
        elif arm == "shuffle_bucket":
            key = f"bucket:{bucket_of.get(m, m)}"
        else:
            raise ValueError(arm)
        groups.setdefault(key, []).append(m)
    return groups


def targets_for(arm: str, eff: dict, reachable: list, *, seed: int, q_start: float, lam: float,
                visits: dict | None = None, bucket_of: dict | None = None) -> dict:
    if arm == "keep":
        return dict(eff)
    if arm == "wipe":
        return {m: float(q_start) for m in eff}
    if arm == "discount":
        return {m: float(q_start) + float(lam) * (q - float(q_start)) for m, q in eff.items()}
    if arm in SHUFFLES:
        tgt = dict(eff)
        rng = random.Random(seed)
        groups = strata_for(arm, reachable, visits or {}, bucket_of or {})
        for key in sorted(groups):
            pop = sorted(groups[key])
            vals = [eff[m] for m in pop]
            rng.shuffle(vals)
            tgt.update(zip(pop, vals))
        return tgt
    raise ValueError(f"unknown arm {arm!r}; choose from {ARMS}")


def q_map_sha(tgt: dict) -> str:
    return hashlib.sha256(json.dumps(sorted((k, round(v, 12)) for k, v in tgt.items())).encode()).hexdigest()


def make_arm(src: Path, dst: Path, arm: str, *, seed: int = 0, q_start: float = 0.5, lam: float = 0.5,
             force: bool = False) -> dict:
    src, dst = Path(src).resolve(), Path(dst).resolve()
    snapshot_files(src)
    if dst.exists():
        if not force:
            raise FileExistsError(f"{dst} exists (use force=True to replace it)")
        shutil.rmtree(dst)
    if src == dst or src in dst.parents:
        raise ValueError("destination must be outside the source snapshot")
    t = three_places(src, q_start)
    tgt = targets_for(arm, t["effective"], t["reachable"], seed=seed, q_start=q_start, lam=lam,
                      visits=t["visits"], bucket_of=t["bucket_of"])

    shutil.copytree(src, dst, ignore=shutil.ignore_patterns("qdrant", "*.tmp", "ARM.json"))
    (dst / "qdrant").mkdir()   # empty: MemRL rebuilds the store from cube/textual_memory.json on load
    f = snapshot_files(dst)

    _write(f["q_cache"], {m: float(tgt[m]) for m in t["bank"]})
    mc = _read(f["mem_cache"])
    for m, item in mc.items():
        if str(m) in tgt and isinstance(item, dict):
            item.setdefault("metadata", {})[Q_KEY] = float(tgt[str(m)])
    _write(f["mem_cache"], mc)
    textual = _read(f["textual"])
    for it in textual:
        holder = it.get("payload") if isinstance(it.get("payload"), dict) else it
        holder.setdefault("metadata", {})[Q_KEY] = float(tgt[str(it["id"])])
    _write(f["textual"], textual, indent=4)

    meta = _read(f["meta"])
    source_meta = {k: meta.get(k) for k in ("cube_dir", "qdrant_dir", "textual_memory_md5", "checkpoint_id")}
    meta["cube_dir"] = str(dst / "cube")
    meta["qdrant_dir"] = str(dst / "qdrant")
    meta["textual_memory_md5"] = hashlib.md5(f["textual"].read_bytes()).hexdigest()
    prov = {"arm": arm, "source_snapshot": str(src), "source_meta": source_meta, "seed": seed if arm in SHUFFLES else None,
            "q_start": q_start, "lam": lam if arm == "discount" else None, "q_sha256": q_map_sha(tgt),
            "created_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "memories": len(t["bank"]), "reachable": len(t["reachable"]),
            "changed_q": sum(1 for m in t["bank"] if abs(tgt[m] - t["effective"][m]) > 1e-12),
            "shuffle_fixed_points": (sum(1 for m in t["reachable"] if abs(tgt[m] - t["effective"][m]) <= 1e-12)
                                     if arm in SHUFFLES else None),
            "shuffle_strata": ({"groups": len(g), "memories_in_groups_of_2_or_more": sum(len(v) for v in g.values() if len(v) > 1)}
                               if arm in SHUFFLES and (g := strata_for(arm, t["reachable"], t["visits"], t["bucket_of"])) else None)}
    meta["msr_leg"] = prov
    _write(f["meta"], meta, indent=2)
    _write(dst / "ARM.json", prov, indent=2)
    return prov


# --------------------------------------------------------------------------- light copies (disk)
SLIM_KEEP = ("ARM.json", "local_cache/q_cache.json")


def slim(dst: Path) -> None:
    """Keep only ARM.json and the Q map of an arm copy; materialize() rebuilds the copy exactly.
    A real bank is about 260 MB per copy (3,072-number vectors in JSON); a design needs 27 copies per
    bank and one private copy per evaluation run, so copies are made when needed and then slimmed."""
    dst = Path(dst)
    for p in sorted(dst.rglob("*"), reverse=True):
        rel = str(p.relative_to(dst))
        if p.is_file() and rel not in SLIM_KEEP:
            p.unlink()
        elif p.is_dir() and not any(p.iterdir()):
            p.rmdir()
    (dst / "SLIM").write_text("only ARM.json and local_cache/q_cache.json are kept; qsnap.materialize() rebuilds the copy\n")


def is_slim(d: Path) -> bool:
    return (Path(d) / "SLIM").exists()


def materialize(light: Path, dst: Path, force: bool = True) -> dict:
    """Rebuild an arm copy from its ARM.json (source snapshot, arm, seed) and check it is the same Q map."""
    prov = _read(Path(light) / "ARM.json")
    again = make_arm(Path(prov["source_snapshot"]), Path(dst), prov["arm"], seed=prov["seed"] or 0,
                     q_start=prov["q_start"], lam=prov["lam"] if prov["lam"] is not None else 0.5, force=force)
    if again["q_sha256"] != prov["q_sha256"]:
        raise RuntimeError(f"rebuilt copy of {light} has a different Q map")
    return prov


# --------------------------------------------------------------------------- checking
def _strip_q(obj):
    if isinstance(obj, dict):
        return {k: _strip_q(v) for k, v in obj.items() if k != Q_KEY}
    if isinstance(obj, list):
        return [_strip_q(v) for v in obj]
    return obj


import re as _re
_QMASK = _re.compile(r'"q_value":\s*-?[0-9.eE+-]+')
_STRIP_CACHE: dict = {}


def _stripped(p: Path):
    st = p.stat()
    key = (str(p), st.st_mtime_ns, st.st_size)
    if key not in _STRIP_CACHE:
        if len(_STRIP_CACHE) > 8:
            _STRIP_CACHE.clear()
        _STRIP_CACHE[key] = _strip_q(_read(p))
    return _STRIP_CACHE[key]


def verify_only_q_differs(a: Path, b: Path) -> dict:
    """Compare two arm copies file by file. Everything must be identical except Q-values
    (and the copy's own paths / provenance in snapshot_meta.json and ARM.json)."""
    a, b = Path(a), Path(b)
    fa, fb = snapshot_files(a), snapshot_files(b)
    problems, checked = [], []
    files_a = {p.relative_to(a) for p in a.rglob("*") if p.is_file() and "qdrant" not in p.relative_to(a).parts}
    files_b = {p.relative_to(b) for p in b.rglob("*") if p.is_file() and "qdrant" not in p.relative_to(b).parts}
    if files_a != files_b:
        problems.append(f"different file lists: {sorted(map(str, files_a ^ files_b))}")
    q_json = {Path("local_cache/q_cache.json"), Path("local_cache/mem_cache.json"), Path("cube/textual_memory.json")}
    for rel in sorted(files_a & files_b):
        checked.append(str(rel))
        if rel in (Path("ARM.json"),):
            continue
        if rel == Path("snapshot_meta.json"):
            ma, mb = _read(a / rel), _read(b / rel)
            drop = {"cube_dir", "qdrant_dir", "textual_memory_md5", "msr_leg"}
            if {k: v for k, v in ma.items() if k not in drop} != {k: v for k, v in mb.items() if k not in drop}:
                problems.append("snapshot_meta.json differs beyond paths/provenance")
            continue
        if rel == Path("local_cache/q_cache.json"):
            if set(_read(a / rel)) != set(_read(b / rel)):
                problems.append("q_cache.json covers different memory ids")
            continue
        if rel in q_json:
            # fast path: both copies are written by the same serializer, so the texts must be equal
            # once the q_value numbers are masked; otherwise compare parsed JSON without q_value
            if _QMASK.sub('"q_value": Q', (a / rel).read_text(encoding="utf-8")) == \
                    _QMASK.sub('"q_value": Q', (b / rel).read_text(encoding="utf-8")):
                continue
            if _stripped(a / rel) != _strip_q(_read(b / rel)):
                problems.append(f"{rel} differs beyond q_value")
            continue
        if (a / rel).read_bytes() != (b / rel).read_bytes():
            problems.append(f"{rel} differs")
    qa = three_places(a)["effective"]
    qb = three_places(b)["effective"]
    n_diff = sum(1 for m in qa if abs(qa[m] - qb.get(m, float("nan"))) > 1e-12 or m not in qb)
    for name, f in (("a", fa), ("b", fb)):
        t = three_places(Path(f["meta"]).parent)
        for m, q in t["effective"].items():
            if t["mem_cache"].get(m) is not None and abs(float(t["mem_cache"][m]) - q) > 1e-12:
                problems.append(f"{name}: mem_cache Q disagrees with q_cache for {m}")
                break
            if t["textual"].get(m) is not None and abs(float(t["textual"][m]) - q) > 1e-12:
                problems.append(f"{name}: textual_memory Q disagrees with q_cache for {m}")
                break
    return {"identical_except_q": not problems, "problems": problems, "files_checked": checked,
            "memories": len(qa), "memories_with_different_q": n_diff}


def verify_same_content(a: Path, b: Path) -> dict:
    """For a relearned bank: the same memories with the same text, keys and vectors (scores and their
    bookkeeping may differ: q_value, q_visits, reward_ma, last_reward, q_updated_at, last_used_at)."""
    a, b = Path(a), Path(b)
    fa, fb = snapshot_files(a), snapshot_files(b)
    problems = []

    def content(f):
        out = {}
        for it in _read(f["textual"]):
            md = (it.get("payload") or it).get("metadata") or {}
            out[str(it["id"])] = ((it.get("payload") or it).get("memory"), md.get("full_content"), md.get("success"),
                                  md.get("type"), md.get("task_id"))
        return out
    ca, cb = content(fa), content(fb)
    if set(ca) != set(cb):
        problems.append(f"different memory ids: {len(set(ca) ^ set(cb))} differ ({len(ca)} vs {len(cb)})")
    elif any(ca[k] != cb[k] for k in ca):
        problems.append("memory text / full_content / success / type differ")
    if _read(fa["dict_memory"]) != _read(fb["dict_memory"]):
        problems.append("dict_memory differs")
    qa, qb = (Path(fa["dict_memory"]).parent / "query_embeddings.json"), (Path(fb["dict_memory"]).parent / "query_embeddings.json")
    if _read(qa) != _read(qb):
        problems.append("query_embeddings differ")
    ea, eb = three_places(a)["effective"], three_places(b)["effective"]
    return {"same_content": not problems, "problems": problems, "memories": len(ca),
            "memories_with_different_q": sum(1 for m in ea if m in eb and abs(ea[m] - eb[m]) > 1e-12)}


def structure(snap: Path) -> dict:
    """How Q relates to exposure in a bank: the facts behind the stratified shuffle."""
    t = three_places(snap)
    eff, vis = t["effective"], t["visits"]
    reach = t["reachable"]
    by = {}
    for m in reach:
        by.setdefault(visit_stratum(vis.get(m, 0)), []).append(eff[m])
    def rank(xs):
        order = sorted(range(len(xs)), key=lambda i: xs[i])
        r = [0.0] * len(xs)
        i = 0
        while i < len(order):
            j = i
            while j + 1 < len(order) and xs[order[j + 1]] == xs[order[i]]:
                j += 1
            for k in range(i, j + 1):
                r[order[k]] = (i + j) / 2.0
            i = j + 1
        return r
    q = [eff[m] for m in reach]
    v = [vis.get(m, 0) for m in reach]
    rq, rv = rank(q), rank(v)
    n = len(reach)
    mq, mv = sum(rq) / n, sum(rv) / n
    cov = sum((x - mq) * (y - mv) for x, y in zip(rq, rv))
    sd = (sum((x - mq) ** 2 for x in rq) * sum((y - mv) ** 2 for y in rv)) ** 0.5
    buckets = {}
    for m in reach:
        buckets.setdefault(t["bucket_of"].get(m), []).append(m)
    return {"memories_reachable": n, "spearman_q_vs_visits": (cov / sd) if sd else None,
            "visit_strata": {f"{VISIT_EDGES[k]}{'+' if k == len(VISIT_EDGES) - 1 else ''}": {
                "memories": len(by[k]), "mean_q": sum(by[k]) / len(by[k]),
                "sd_q": (sum((x - sum(by[k]) / len(by[k])) ** 2 for x in by[k]) / len(by[k])) ** 0.5}
                for k in sorted(by)},
            "buckets": len(buckets), "mean_bucket_size": n / max(1, len(buckets))}


def main() -> None:
    ap = argparse.ArgumentParser(description="Swap-day copies of a MemRL memory bank (Q-values only).")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("inspect"); p.add_argument("snapshot"); p.add_argument("--q-init", type=float, default=0.5)
    p = sub.add_parser("make"); p.add_argument("snapshot"); p.add_argument("dest")
    p.add_argument("--arm", choices=ARMS, required=True); p.add_argument("--seed", type=int, default=0)
    p.add_argument("--q-start", type=float, default=0.5); p.add_argument("--lam", type=float, default=0.5)
    p.add_argument("--force", action="store_true")
    p = sub.add_parser("verify"); p.add_argument("a"); p.add_argument("b")
    p = sub.add_parser("structure"); p.add_argument("snapshot")
    args = ap.parse_args()
    if args.cmd == "inspect":
        out = inspect(Path(args.snapshot), args.q_init)
    elif args.cmd == "make":
        out = make_arm(Path(args.snapshot), Path(args.dest), args.arm, seed=args.seed, q_start=args.q_start,
                       lam=args.lam, force=args.force)
    elif args.cmd == "structure":
        out = structure(Path(args.snapshot))
    else:
        out = verify_only_q_differs(Path(args.a), Path(args.b))
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
