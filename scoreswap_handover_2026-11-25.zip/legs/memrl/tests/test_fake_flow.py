"""End-to-end test of the whole leg with the scripted stub model (no paid call, ~5 minutes).

train (fake-old, fake-new) -> arm copies -> 14 evaluation runs -> collect, on a few tasks, into a
temporary folder, with MemRL's real code and real Docker containers. Then a second identical run
must do nothing and make no new call.

Needs Docker with the image local-os/default (legs/memrl/docker/build_image.sh), the leg env
(legs/memrl/env) and the project venv (.venv). Skipped when one is missing.
Run:  legs/memrl/env/bin/python -m pytest legs/memrl/tests/test_fake_flow.py -q
"""
from __future__ import annotations

import csv
import json
import os
import shutil
import subprocess
from pathlib import Path

import pytest

LEG = Path(__file__).resolve().parent.parent
ROOT = LEG.parent.parent
VENV_PY = ROOT / ".venv" / "bin" / "python"
CALL_FIELDS = {"call_id", "model", "model_id", "called_at", "prompt_sha256", "answer", "tokens_in", "tokens_out",
               "cost_usd", "stop_reason", "latency_s", "fingerprint", "cached", "meta", "served_by"}  # msr/llm.py CallResult


def _have_docker_image() -> bool:
    if not shutil.which("docker"):
        return False
    r = subprocess.run(["docker", "image", "inspect", "local-os/default"], capture_output=True)
    return r.returncode == 0


pytestmark = pytest.mark.skipif(not (VENV_PY.exists() and (LEG / "env" / "bin" / "python").exists() and _have_docker_image()),
                                reason="needs .venv, legs/memrl/env and the local-os/default Docker image")


def run_leg(args: list[str], env: dict) -> str:
    r = subprocess.run([str(VENV_PY), str(LEG / "run_leg.py"), *args], capture_output=True, text=True, env=env,
                       timeout=14000)   # a shared, heavily loaded machine: ~1-3 min per evaluation run
    assert r.returncode == 0, r.stdout[-3000:] + r.stderr[-3000:]
    return r.stdout


def count_calls(root: Path) -> int:
    return sum(len(p.read_text().splitlines()) for p in root.rglob("calls.jsonl"))


def test_fake_pair_end_to_end(tmp_path):
    """Revision 2: one pair, both directions; keep and the within-visit shuffle x 2 repeats (a fresh
    permutation per repeat), the secondary arms x 1, relearn on both banks, none; then the gated readings."""
    env = {**os.environ, "MSR_LEG_RUNS_ROOT": str(tmp_path / "runs"), "MSR_LEG_RESULTS_ROOT": str(tmp_path / "results")}
    args = ["pair", "--old", "fake-old", "--new", "fake-new", "--fake", "--sections", "2", "--limit-train", "6",
            "--limit-val", "3", "--repeats", "2", "--repeats-secondary", "1"]
    run_leg(args, env)
    root = tmp_path / "runs" / "fake"

    for m in ("fake-old", "fake-new"):
        assert (root / "train" / m / "DONE.json").exists()
        chk = json.loads((root / "banks" / m / "arms_check.json").read_text())
        assert all(v["identical_except_q"] for v in chk["only_q_differs"].values()), chk["only_q_differs"]
        assert {"shuffle_visit_s0", "shuffle_visit_s1", "shuffled_s0", "shuffle_bucket_s1"} <= set(chk["arms"])
        assert chk["retrieval_probe"]["share_changed"]["discount"] == 0.0
    # relearn: same content as the old bank, only Q moved
    for reader, bank in (("fake-new", "fake-old"), ("fake-old", "fake-new")):
        done = json.loads((root / "relearn" / f"{reader}__{bank}" / "DONE.json").read_text())
        assert done["same_content_as_old_bank"]["same_content"]
    # 2 homes x 2 arms x 2 + 2 swaps x 2 x 2 + 2 none x 2 + (2 homes + 2 swaps) x 3 secondary + 2 relearn = 34 runs
    evals = sorted((root / "eval").iterdir())
    assert len(evals) == 34
    for d in evals:
        assert json.loads((d / "DONE.json").read_text())["tasks"] == 3
    # each shuffle repeat read its own permutation
    srcs = {json.loads((root / "eval" / f"fake-new__fake-old__shuffle_visit__r{r}" / "ARM_source.json").read_text())["seed"]
            for r in (0, 1)}
    assert srcs == {0, 1}
    # disk: finished runs keep no private bank copy; banks keep light records except keep
    assert not any((d / "bank").exists() for d in evals)
    assert all((root / "banks" / "fake-old" / n / "SLIM").exists() for n in ("shuffle_visit_s0", "wipe", "relearn_by_fake-new"))
    # Every model call logged in the main study's format, through the patched provider, never with a temperature.
    for p in root.rglob("calls.jsonl"):
        for line in p.read_text().splitlines():
            rec = json.loads(line)
            assert CALL_FIELDS <= set(rec), set(rec) ^ CALL_FIELDS
    for p in root.rglob("desk_requests.jsonl"):
        for line in p.read_text().splitlines():
            rec = json.loads(line)
            if rec["path"] == "chat":
                assert rec["via_shim"] and "temperature" not in rec["sent_keys"]
    # Tables with the registered readings.
    run_leg(["collect", "--fake", "--design", "minimum"], env)
    res = tmp_path / "results" / "fake"
    for name in ("readings.csv", "secondary.csv", "permutation_spread.csv", "task_rank.csv", "memory_rank.csv",
                 "arms.csv", "episodes.csv", "RESULTS.md"):
        assert (res / name).exists(), name
    with open(res / "readings.csv") as f:
        rows = list(csv.DictReader(f))
    assert {(r["old"], r["reader"], r["kind"]) for r in rows} == {("fake-old", "fake-new", "upgrade"), ("fake-new", "fake-old", "downgrade")}
    assert all(r["reading"] for r in rows)
    assert "FAKE" in (res / "RESULTS.md").read_text()

    # Re-running is safe: nothing is redone and no call is made.
    n_before = count_calls(root)
    run_leg(args, env)
    assert count_calls(root) == n_before


def test_training_resumes_after_the_last_saved_section(tmp_path):
    env = {**os.environ, "MSR_LEG_RUNS_ROOT": str(tmp_path / "runs"), "MSR_LEG_KEEP_SNAPSHOTS": "1"}
    args = ["train", "--model", "fake-old", "--fake", "--sections", "2", "--limit-train", "5"]
    run_leg(args, env)
    td = tmp_path / "runs" / "fake" / "train" / "fake-old"
    # Pretend the run was interrupted during section 2.
    shutil.rmtree(td / "ckpt" / "snapshot" / "2")
    (td / "DONE.json").unlink()
    out = run_leg(args, env)
    assert "resuming after section 1" in out
    assert (td / "ckpt" / "snapshot" / "2" / "local_cache" / "q_cache.json").exists()
    assert (td / "resume" / "1" / "ARM.json").exists()
    eps = [json.loads(x) for x in (td / "episodes.jsonl").read_text().splitlines()]
    assert [e["section"] for e in eps].count(2) == 2 * 5 and [e["section"] for e in eps].count(1) == 5
    # A third call finds it finished.
    assert "done (2 sections)" in run_leg(args, env)
