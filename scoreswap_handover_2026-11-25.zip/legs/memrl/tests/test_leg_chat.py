"""Tests for the patched chat provider (memrl/providers/leg_chat.py, added by patches/0001).

It talks to the local desk (local_server.py) with the stub chat model, so nothing is paid.
Checks: MemRL's temperature is never sent; every call is logged with the main study's CallResult
fields; the replay cache answers a repeated request inside the same run; a failed request stops
the process with exit code 17 and FATAL.json instead of becoming an answer.
Run with the leg's Python: legs/memrl/env/bin/python -m pytest legs/memrl/tests/test_leg_chat.py -q
"""
from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import time
from pathlib import Path

import pytest

LEG = Path(__file__).resolve().parent.parent
SRC = LEG / "src"
CALL_FIELDS = {"call_id", "model", "model_id", "called_at", "prompt_sha256", "answer", "tokens_in", "tokens_out",
               "cost_usd", "stop_reason", "latency_s", "fingerprint", "cached", "meta", "served_by"}

try:
    sys.path.insert(0, str(SRC))
    from memrl.providers.leg_chat import LegChatLLM  # noqa: E402
    HAVE = True
except Exception:
    HAVE = False
pytestmark = pytest.mark.skipif(not HAVE, reason="needs the leg env (legs/memrl/env/bin/python)")


def _port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@pytest.fixture
def desk(tmp_path):
    port = _port()
    log = tmp_path / "desk.jsonl"
    p = subprocess.Popen([sys.executable, str(LEG / "local_server.py"), "--port", str(port), "--embed", "hash",
                          "--fake-chat", "--log", str(log), "--cache-root", str(tmp_path / "emb")],
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    line = p.stdout.readline()
    assert "ready" in line, line
    yield port, log
    p.terminate()
    p.wait(10)


def spec(tmp_path: Path, port: int, **kw) -> Path:
    s = {"name": "fake-old", "api_model": "fake-old", "base_url": f"http://127.0.0.1:{port}/v1", "key_env": None,
         "max_tokens_field": "max_tokens", "max_tokens": 64, "price_in": 0.0, "price_out": 0.0,
         "run_dir": str(tmp_path / "run"), "spend_path": str(tmp_path / "spend.json"), "cap_usd": 1.0,
         "cache_dir": str(tmp_path / "cache"), "max_retries": 0, "timeout_s": 30, **kw}
    p = tmp_path / "spec.json"
    p.write_text(json.dumps(s))
    return p


MSGS = [{"role": "user", "content": "Analyze the following detailed task trajectory ...\n\nHigh-level script:"}]


def test_no_temperature_logged_and_replayed(tmp_path, desk, monkeypatch):
    port, log = desk
    monkeypatch.setenv("MSR_LEG_RUN", "unit")
    llm = LegChatLLM(str(spec(tmp_path, port)))
    a1 = llm.generate(MSGS, temperature=0.3, max_tokens=64)
    sent = [json.loads(x) for x in log.read_text().splitlines() if '"chat"' in x]
    assert sent and "temperature" not in sent[0]["sent_keys"] and sent[0]["via_shim"]
    recs = [json.loads(x) for x in (tmp_path / "run" / "calls.jsonl").read_text().splitlines()]
    assert CALL_FIELDS <= set(recs[0])
    assert recs[0]["meta"]["dropped_params"] == {"temperature": 0.3}
    assert recs[0]["meta"]["kind"] == "memory_script"
    assert recs[0]["model_id"] == "fake-old-stub-v1" and not recs[0]["cached"]
    assert list((tmp_path / "run" / "prompts").glob("*.json.gz"))
    # A fresh provider in the same run replays the first answer instead of asking again.
    n_before = len(log.read_text().splitlines())
    a2 = LegChatLLM(str(spec(tmp_path, port))).generate(MSGS, temperature=0.3, max_tokens=64)
    assert a2 == a1 and len(log.read_text().splitlines()) == n_before
    last = json.loads((tmp_path / "run" / "calls.jsonl").read_text().splitlines()[-1])
    assert last["cached"] is True and last["cost_usd"] == 0.0
    # A second identical request in the same process is a new occurrence: asked again, not replayed.
    llm.generate(MSGS, max_tokens=64)
    assert len(log.read_text().splitlines()) == n_before + 1


def test_failed_call_stops_the_process(tmp_path):
    port = _port()   # nothing listens here: the call fails after the SDK's retries
    sp = spec(tmp_path, port, cache_dir=None)
    code = ("import sys; sys.path.insert(0, %r)\n"
            "from memrl.providers.leg_chat import LegChatLLM\n"
            "print(LegChatLLM(%r).generate([{'role':'user','content':'hi'}]))\n" % (str(SRC), str(sp)))
    r = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, timeout=120)
    assert r.returncode == 17, r.stdout + r.stderr
    fatal = json.loads((tmp_path / "run" / "FATAL.json").read_text())
    assert "failed after retries" in fatal["error"]
    rec = json.loads((tmp_path / "run" / "calls.jsonl").read_text().splitlines()[-1])
    assert rec.get("error") and "answer" not in rec
