"""The registered readings of collect.py on made-up episode logs (no model, no Docker).

Run with the project venv: .venv/bin/python -m pytest legs/memrl/tests/test_collect.py -q
"""
from __future__ import annotations

import csv
import json
import random
import sys
from pathlib import Path

import pytest

LEG = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(LEG))
try:
    import collect
    import run_leg  # noqa: F401
    HAVE = True
except Exception:
    HAVE = False
pytestmark = pytest.mark.skipif(not HAVE, reason="needs the project venv (.venv/bin/python)")

N, R = 150, 8


def write_cell(root: Path, reader: str, bank: str, arm: str, rate: float, seed: int) -> None:
    rng = random.Random(seed)
    for r in range(R if arm != "none" else 2):
        d = root / "fake" / "eval" / f"{reader}__{bank}__{arm}__r{r}"
        d.mkdir(parents=True)
        (d / "run.json").write_text(json.dumps({"stage": "eval", "reader": reader, "bank": bank, "arm": arm, "repeat": r,
                                                "split": "val", "fake": True}))
        (d / "DONE.json").write_text("{}")
        with open(d / "episodes.jsonl", "w") as f:
            for t in range(N):
                mems = [{"memory_id": f"m{(t + k + (r if arm != 'keep' else 0)) % 40}", "q": 0.5, "sim": 0.8} for k in range(5)]
                f.write(json.dumps({"phase": "eval", "sample_index": str(t), "success": rng.random() < rate,
                                    "steps": 2, "status": "SampleStatus.COMPLETED", "retrieved": mems}) + "\n")


def test_gated_readings(tmp_path, monkeypatch):
    root = tmp_path / "runs"
    cells = {   # (reader, bank, arm): success rate
        ("fake-old", "fake-old", "keep"): 0.85, ("fake-old", "fake-old", "shuffle_visit"): 0.65,      # home: strong
        ("fake-new", "fake-old", "keep"): 0.85, ("fake-new", "fake-old", "shuffle_visit"): 0.65,      # swap: survives
        ("fakex-new", "fake-old", "keep"): 0.65, ("fakex-new", "fake-old", "shuffle_visit"): 0.65,    # cross: lost
        ("fake-new", "fake-new", "keep"): 0.70, ("fake-new", "fake-new", "shuffle_visit"): 0.70,      # home: nothing
        ("fake-old", "fake-new", "keep"): 0.90, ("fake-old", "fake-new", "shuffle_visit"): 0.60,      # swap read? no
    }
    for i, ((reader, bank, arm), rate) in enumerate(cells.items()):
        write_cell(root, reader, bank, arm, rate, seed=i)
    bank_q = root / "fake" / "banks" / "fake-old" / "keep" / "local_cache"
    bank_q.mkdir(parents=True)
    (bank_q / "q_cache.json").write_text(json.dumps({f"m{i}": i / 40 for i in range(40)}))
    monkeypatch.setenv("MSR_LEG_RUNS_ROOT", str(root))
    monkeypatch.setenv("MSR_LEG_RESULTS_ROOT", str(tmp_path / "res"))
    collect.collect(fake=True, design="minimum")
    with open(tmp_path / "res" / "fake" / "readings.csv") as f:
        rows = {(r["old"], r["reader"]): r for r in csv.DictReader(f)}
    assert set(rows) == {("fake-old", "fake-new"), ("fake-old", "fakex-new"), ("fake-new", "fake-old")}
    assert rows[("fake-old", "fake-new")]["reading"] == "matters at home and survives"
    assert rows[("fake-old", "fakex-new")]["reading"] == "matters at home and is lost"
    assert rows[("fake-new", "fake-old")]["reading"].startswith("uninformative"), "home gate failed: swap not read"
    assert rows[("fake-old", "fake-new")]["kind"] == "upgrade" and rows[("fake-old", "fakex-new")]["kind"] == "cross-maker"
    for name in ("secondary.csv", "permutation_spread.csv", "task_rank.csv", "RESULTS.md"):
        assert (tmp_path / "res" / "fake" / name).exists()


def test_holm():
    assert collect.holm([0.01, 0.04, 0.03]) == pytest.approx([0.03, 0.06, 0.06])
