"""Tests for qsnap.py (arm copies that differ only in Q) and for the claim that a global discount
changes nothing in MemRL's retrieval, checked with MemRL's OWN retrieve_query.

Run with the leg's Python (it has MemRL's dependencies):
    legs/memrl/env/bin/python -m pytest legs/memrl/tests -q
The qsnap-only tests also pass under the project venv; the MemRL ones are skipped there.
"""
from __future__ import annotations

import hashlib
import json
import random
import sys
from pathlib import Path

import pytest

LEG = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(LEG))
import qsnap  # noqa: E402

try:
    import memrl_probe  # noqa: E402  (imports MemRL + MemOS)
    from memos.memories.textual.item import TextualMemoryItem, TextualMemoryMetadata  # noqa: E402
    HAVE_MEMRL = True
except Exception:   # project venv: no MemRL dependencies
    HAVE_MEMRL = False


# --------------------------------------------------------------------------- a synthetic bank
def unit(v):
    n = sum(x * x for x in v) ** 0.5
    return [x / n for x in v]


def make_bank(root: Path, n_tasks=12, per_task=3, dim=16, seed=1, q_cache_share=0.6) -> Path:
    """A snapshot laid out exactly like MemRL's save_checkpoint_snapshot (memory_service.py:1667-1758)."""
    rng = random.Random(seed)
    snap = root / "ckpt" / "snapshot" / "3"
    (snap / "cube").mkdir(parents=True)
    (snap / "local_cache").mkdir()
    (snap / "qdrant").mkdir()
    (snap / "qdrant" / "storage.sqlite").write_bytes(b"pretend store")
    textual, mem_cache, q_cache, dict_memory, qemb = [], {}, {}, {}, {}
    for t in range(n_tasks):
        query = f"task {t}: do thing {t} with files"
        qemb[query] = unit([rng.gauss(0, 1) for _ in range(dim)])
        dict_memory[query] = []
        for j in range(per_task):
            mid = f"m{t:02d}-{j}"
            learned = round(rng.random(), 6)
            meta = {"q_value": learned, "success": rng.random() < 0.6, "full_content": f"Task: {query}\nnote {j}",
                    "task_id": t, "q_visits": rng.randint(0, 5), "type": "procedure"}
            textual.append({"id": mid, "vector": qemb[query], "payload": {"id": mid, "memory": query, "metadata": dict(meta)}})
            mem_cache[mid] = {"id": mid, "memory": query, "metadata": {**meta, "q_value": 0.5}}   # stale, as in MemRL
            if rng.random() < q_cache_share:
                q_cache[mid] = learned
            dict_memory[query].append(mid)
    if HAVE_MEMRL:   # serialise mem_cache the way MemRL does (TextualMemoryItem.model_dump(mode="json"))
        mem_cache = {k: TextualMemoryItem(id=k, memory=v["memory"], metadata=TextualMemoryMetadata(**v["metadata"]))
                     .model_dump(mode="json") for k, v in mem_cache.items()}
    (snap / "cube" / "textual_memory.json").write_text(json.dumps(textual, indent=4))
    (snap / "cube" / "config.json").write_text(json.dumps({"user_id": "u", "cube_id": "c"}))
    lc = snap / "local_cache"
    (lc / "q_cache.json").write_text(json.dumps(q_cache))
    (lc / "mem_cache.json").write_text(json.dumps(mem_cache))
    (lc / "dict_memory.json").write_text(json.dumps(dict_memory))
    (lc / "query_embeddings.json").write_text(json.dumps(qemb))
    (snap / "snapshot_meta.json").write_text(json.dumps({"user_id": "u", "checkpoint_id": 3, "cube_dir": str(snap / "cube"),
                                                         "qdrant_dir": str(snap / "qdrant"), "textual_memory_md5": "x"}))
    return snap


def tree_hash(d: Path) -> str:
    h = hashlib.sha256()
    for p in sorted(d.rglob("*")):
        if p.is_file():
            h.update(str(p.relative_to(d)).encode())
            h.update(p.read_bytes())
    return h.hexdigest()


@pytest.fixture
def bank(tmp_path):
    return make_bank(tmp_path)


# --------------------------------------------------------------------------- qsnap
def test_effective_q_precedence(bank):
    t = qsnap.three_places(bank)
    for mid, q in t["effective"].items():
        if mid in t["q_cache"]:
            assert q == t["q_cache"][mid]
        else:   # stale mem_cache (0.5) wins over the store, exactly as retrieve_query reads it
            assert q == 0.5
    assert qsnap.inspect(bank)["mem_cache_q_differs_from_effective"] > 0


@pytest.mark.parametrize("arm", ["keep", "wipe", "shuffled", "discount"])
def test_arm_copy_writes_all_three_places_and_leaves_source_alone(bank, tmp_path, arm):
    before = tree_hash(bank)
    eff = qsnap.three_places(bank)["effective"]
    dst = tmp_path / f"arm_{arm}"
    prov = qsnap.make_arm(bank, dst, arm, seed=7, q_start=0.5, lam=0.5)
    assert tree_hash(bank) == before, "the source snapshot must never change"
    t = qsnap.three_places(dst)
    assert set(t["q_cache"]) == set(t["bank"]), "q_cache must cover every memory"
    for mid in t["bank"]:
        q = t["q_cache"][mid]
        assert t["textual"][mid] == q and t["mem_cache"][mid] == q
        if arm == "keep":
            assert q == pytest.approx(eff[mid])
        elif arm == "wipe":
            assert q == 0.5
        elif arm == "discount":
            assert q == pytest.approx(0.5 + 0.5 * (eff[mid] - 0.5))
    if arm == "shuffled":
        assert sorted(t["q_cache"].values()) == pytest.approx(sorted(eff.values()))
        assert prov["changed_q"] > 0
    meta = json.loads((dst / "snapshot_meta.json").read_text())
    assert meta["cube_dir"] == str(dst.resolve() / "cube") and meta["qdrant_dir"] == str(dst.resolve() / "qdrant")
    assert meta["msr_leg"]["arm"] == arm
    assert list((dst / "qdrant").iterdir()) == [], "the copied store is dropped (rebuilt from textual_memory.json)"


def test_shuffle_is_seeded(bank, tmp_path):
    a = qsnap.make_arm(bank, tmp_path / "a", "shuffled", seed=3)
    b = qsnap.make_arm(bank, tmp_path / "b", "shuffled", seed=3)
    c = qsnap.make_arm(bank, tmp_path / "c", "shuffled", seed=4)
    assert a["q_sha256"] == b["q_sha256"] != c["q_sha256"]


def test_verify_only_q_differs(bank, tmp_path):
    for arm in ("keep", "wipe", "shuffled"):
        qsnap.make_arm(bank, tmp_path / arm, arm, seed=1)
    for x, y in (("keep", "wipe"), ("keep", "shuffled"), ("wipe", "shuffled")):
        r = qsnap.verify_only_q_differs(tmp_path / x, tmp_path / y)
        assert r["identical_except_q"], r["problems"]
        assert r["memories_with_different_q"] > 0
    # Tamper with content in one copy: must be caught.
    tf = tmp_path / "wipe" / "cube" / "textual_memory.json"
    items = json.loads(tf.read_text())
    items[0]["payload"]["metadata"]["full_content"] += " (edited)"
    tf.write_text(json.dumps(items))
    assert not qsnap.verify_only_q_differs(tmp_path / "keep", tmp_path / "wipe")["identical_except_q"]


def test_refuses_to_overwrite_or_nest(bank, tmp_path):
    qsnap.make_arm(bank, tmp_path / "k", "keep")
    with pytest.raises(FileExistsError):
        qsnap.make_arm(bank, tmp_path / "k", "keep")
    with pytest.raises(ValueError):
        qsnap.make_arm(bank, bank / "inside", "keep")


# --------------------------------------------------------------------------- MemRL's own retrieval
needs_memrl = pytest.mark.skipif(not HAVE_MEMRL, reason="needs the leg env (legs/memrl/env/bin/python)")


def _queries(bank: Path, n=40, seed=5):
    rng = random.Random(seed)
    qemb = json.loads((bank / "local_cache" / "query_embeddings.json").read_text())
    base = list(qemb.values())
    out = {}
    for i in range(n):   # new queries near existing ones, so several candidates pass the threshold
        v = rng.choice(base)
        out[f"new query {i}"] = unit([x + rng.gauss(0, 0.35) for x in v])
    return out


@needs_memrl
def test_memrl_retrieval_discount_is_a_no_op_and_wipe_is_similarity_only(bank, tmp_path):
    for arm in ("keep", "discount", "wipe", "shuffled"):
        qsnap.make_arm(bank, tmp_path / "banks" / arm, arm, seed=2, lam=0.3)
    qv = _queries(bank)
    embed = lambda texts: [qv[t] for t in texts]   # noqa: E731
    res = memrl_probe.probe(tmp_path / "banks", list(qv), embed, threshold=0.0)
    n = len(qv)
    assert res["vs_keep"]["discount"]["same_selected_order"] == n, "a global discount must not change MemRL's choice"
    assert res["vs_keep"]["wipe"]["same_selected_set"] < n, "wiping learned Q must change some choices"
    assert res["vs_keep"]["shuffled"]["same_selected_set"] < n, "shuffling Q must change some choices"
    # Under wipe every candidate has the same Q, so q_z = 0 (memory_service.py:1445-1454) and the
    # choice is the 5 most similar memories.
    ms = memrl_probe.bare_service(tmp_path / "banks" / "wipe" / "local_cache", memrl_probe.FixedEmbedder(embed),
                                  sim_mean=None, sim_std=None)
    for q in list(qv)[:10]:
        res_q, _ = ms.retrieve_query(task_description=q, k=10, threshold=0.0)
        sims = [c["similarity"] for c in res_q["candidates"]]
        chosen = [c["similarity"] for c in res_q["selected"]]
        assert chosen == sorted(sims, reverse=True)[:len(chosen)]
        assert all(abs(c["q_z"]) < 1e-12 for c in res_q["selected"])


@needs_memrl
def test_memrl_loader_reads_the_arm_q(bank, tmp_path):
    """MemRL's own cache loader sees the arm's Q for every memory (no fallback to stale metadata)."""
    qsnap.make_arm(bank, tmp_path / "w", "wipe")
    ms = memrl_probe.bare_service(tmp_path / "w" / "local_cache", memrl_probe.FixedEmbedder(lambda t: []),
                                  sim_mean=None, sim_std=None)
    assert ms._q_cache and set(ms._q_cache.values()) == {0.5}
    assert all(item.metadata.q_value == 0.5 for item in ms._mem_cache.values())


# --------------------------------------------------------------------------- revision 2: stratified shuffles
def _groups(t, key):
    g = {}
    for m in t["reachable"]:
        g.setdefault(key(m), []).append(m)
    return g


@pytest.mark.parametrize("arm", ["shuffle_visit", "shuffle_bucket"])
def test_stratified_shuffle_keeps_each_stratum_and_differs_only_in_q(bank, tmp_path, arm):
    src = qsnap.three_places(bank)
    prov = qsnap.make_arm(bank, tmp_path / arm, arm, seed=5)
    dst = qsnap.three_places(tmp_path / arm)
    if arm == "shuffle_visit":
        key = lambda m: qsnap.visit_stratum(src["visits"][m])   # noqa: E731
    else:
        key = lambda m: src["bucket_of"][m]                      # noqa: E731
    for members in _groups(src, key).values():
        assert sorted(dst["q_cache"][m] for m in members) == pytest.approx(sorted(src["effective"][m] for m in members))
        if len(members) == 1:
            assert dst["q_cache"][members[0]] == pytest.approx(src["effective"][members[0]])
    assert prov["shuffle_strata"]["groups"] == len(_groups(src, key))
    qsnap.make_arm(bank, tmp_path / "k", "keep")
    v = qsnap.verify_only_q_differs(tmp_path / "k", tmp_path / arm)
    assert v["identical_except_q"], v["problems"]


def test_one_permutation_per_seed(bank, tmp_path):
    shas = {qsnap.make_arm(bank, tmp_path / f"s{s}", "shuffle_visit", seed=s)["q_sha256"] for s in range(6)}
    assert len(shas) >= 5, "different seeds must give different permutations"


def test_visit_strata_edges():
    assert [qsnap.visit_stratum(v) for v in (0, 1, 2, 3, 4, 5, 8, 9, 16, 17, 40)] == [0, 1, 2, 3, 3, 4, 4, 5, 5, 6, 6]


def test_verify_same_content_for_relearned_bank(bank, tmp_path):
    qsnap.make_arm(bank, tmp_path / "keep", "keep")
    qsnap.make_arm(bank, tmp_path / "rl", "keep")
    tf = tmp_path / "rl" / "cube" / "textual_memory.json"
    items = json.loads(tf.read_text())
    for it in items[:5]:   # what a relearn pass changes: Q and its bookkeeping
        it["payload"]["metadata"].update(q_value=0.9, q_visits=99, reward_ma=0.4)
    tf.write_text(json.dumps(items))
    qc = tmp_path / "rl" / "local_cache" / "q_cache.json"
    q = json.loads(qc.read_text())
    for it in items[:5]:
        q[it["id"]] = 0.9
    qc.write_text(json.dumps(q))
    r = qsnap.verify_same_content(tmp_path / "keep", tmp_path / "rl")
    assert r["same_content"] and r["memories_with_different_q"] >= 1
    items[0]["payload"]["metadata"]["full_content"] += " (new text)"
    tf.write_text(json.dumps(items))
    assert not qsnap.verify_same_content(tmp_path / "keep", tmp_path / "rl")["same_content"]


def test_structure_reports_q_and_visits(bank):
    s = qsnap.structure(bank)
    assert s["memories_reachable"] == 36 and s["buckets"] == 12
    assert sum(v["memories"] for v in s["visit_strata"].values()) == 36


@needs_memrl
def test_memrl_retrieval_under_stratified_shuffles(bank, tmp_path):
    for arm in ("keep", "discount"):
        qsnap.make_arm(bank, tmp_path / "banks" / arm, arm, lam=0.3)
    for arm in ("shuffle_visit", "shuffle_bucket", "shuffled"):
        for s in range(3):
            qsnap.make_arm(bank, tmp_path / "banks" / f"{arm}_s{s}", arm, seed=s)
    qv = _queries(bank)
    res = memrl_probe.probe(tmp_path / "banks", list(qv), lambda texts: [qv[t] for t in texts], threshold=0.0)
    assert res["share_changed"]["discount"] == 0.0
    for arm in ("shuffle_visit", "shuffle_bucket", "shuffled"):
        assert 0.0 < res["share_changed"][arm] <= 1.0


@needs_memrl
def test_fast_probe_gives_the_same_choice(tmp_path):
    bank = make_bank(tmp_path / "b", n_tasks=40, per_task=3, seed=4)
    qsnap.make_arm(bank, tmp_path / "keep", "keep")
    qv = _queries(bank, n=30, seed=9)
    emb = memrl_probe.FixedEmbedder(lambda texts: [qv[t] for t in texts])
    ms = memrl_probe.bare_service(tmp_path / "keep" / "local_cache", emb, sim_mean=None, sim_std=None)
    random.seed(0)
    full = memrl_probe.selections(ms, list(qv), 0.0, restrict=0)
    random.seed(0)
    fast = memrl_probe.selections(ms, list(qv), 0.0, restrict=12)
    assert full == fast and any(full)
