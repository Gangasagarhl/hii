"""Tests for the revision-2 designs (run order, cells, costs) and the power model.

Run with the project venv (it has scipy and the model config):
    .venv/bin/python -m pytest legs/memrl/tests/test_design_power.py -q
"""
from __future__ import annotations

import math
import sys
from pathlib import Path

import pytest

LEG = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(LEG))
sys.path.insert(0, str(LEG / "tools"))

try:
    import run_leg
    import power_family_L as pw
    HAVE = True
except Exception:     # the leg env lacks the project's packages
    HAVE = False
pytestmark = pytest.mark.skipif(not HAVE, reason="needs the project venv (.venv/bin/python)")


@pytest.mark.parametrize("design,swaps", [("minimum", 6), ("recommended", 12), ("full", 12)])
def test_every_budget_cut_keeps_both_kinds_of_swap(design, swaps):
    blocks = run_leg.design_blocks(design, fake=False)
    assert sum(len(b["swaps"]) for b in blocks) == swaps
    for k in range(1, len(blocks) + 1):
        kinds = {kind for b in blocks[:k] for _, _, kind in b["swaps"]}
        assert {"upgrade", "downgrade", "cross-maker"} <= kinds, f"blocks 1-{k} lack a kind of swap: {kinds}"
    assert blocks[0]["train"][0] == "haiku-4.5", "the model that may retire first is trained first"


def test_cells_of_a_directed_swap():
    plan = run_leg.design_cells("recommended", fake=False)
    cells = set(plan["cells"])
    for old, reader, _ in plan["swaps"]:
        for arm in run_leg.PRIMARY_ARMS:
            assert all((reader, old, arm, r, "val") in cells for r in range(8)), "swap contrast, 8 repeats"
            assert all((old, old, arm, r, "val") in cells for r in range(8)), "home gate, 8 repeats"
        assert (reader, old, "relearn", 0, "val") in cells
    assert len(cells) == len(plan["cells"]), "no cell is run twice"
    # each shuffle repeat reads its own permutation
    assert run_leg.arm_source("haiku-4.5", "shuffle_visit", 3, "haiku-5.5", False).name == "shuffle_visit_s3"


def test_costs_increase_with_the_design():
    usd = {d: run_leg.estimate_design(d)["usd"] for d in ("minimum", "recommended", "full")}
    assert 0 < usd["minimum"] < usd["recommended"] < usd["full"]
    blocks = run_leg.estimate_pair_blocks("recommended")
    assert math.isclose(sum(b["block_usd"] for b in blocks), usd["recommended"], rel_tol=1e-6)


@pytest.fixture(scope="module")
def central():
    return pw.Model(pw.SCENARIOS["central"], 0.5)


def test_mde_falls_with_repeats_and_rises_with_multiplicity(central):
    a = [central.mde(R, 0.05, 0.8)[0] for R in (2, 4, 8)]
    assert a[0] > a[1] > a[2] > 0
    assert central.mde(8, 0.05 / 12, 0.8)[0] > central.mde(8, 0.05, 0.8)[0]


def test_round1_design_matches_the_reviewers_range():
    m = pw.Model(pw.SCENARIOS["pessimistic"], 0.5)
    mde, sd, _ = m.mde(2, 0.05, 0.8, many_perms=False)
    assert 0.35 <= sd <= 0.45 and 0.07 <= mde <= 0.09      # R5: "about 7-9 points" with SD 0.35-0.45


def test_monte_carlo_agrees_with_the_formula(central):
    mde, _, g = central.mde(2, 0.05, 0.8)
    assert abs(central.simulate_power(g, 2, 0.05, sims=600) - 0.8) < 0.06
