#!/usr/bin/env bash
# Build the image the OS tasks need (local-os/default) from the pinned Dockerfile next to this script,
# then write down what was built. Re-running rebuilds from Docker's cache.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
docker build -t local-os/default -f "$HERE/Dockerfile" "$HERE"
docker image inspect local-os/default --format '{{.Id}}' > "$HERE/IMAGE_ID"
docker run --rm local-os/default bash -c 'cat /etc/os-release | head -2; dpkg-query -W -f "\${Package} \${Version}\n"' > "$HERE/IMAGE_PACKAGES.txt"
echo "built local-os/default $(cat "$HERE/IMAGE_ID")"
