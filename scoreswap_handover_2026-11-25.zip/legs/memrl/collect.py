"""Turn the MemRL leg's evaluation runs into tables and the registered readings (prereg Part 8.4).

Everyday picture: the marking office. Every exam run hands in one sheet per task (solved or not,
which notes the helper was given and the score on each). The office first asks the OLD helper's
question: with its own box, does the learned order beat a fair reshuffle? Only if yes does it read
the NEW helper's sheet for that box. Every number gets a range by re-drawing the tasks at random
(task-level bootstrap, 2,000 draws); the shuffles were re-dealt on every repeat, so their spread is
inside that range.

Registered (family L, one-sided, alpha 0.05, Holm over the directed swaps of the design):
  home H = keep - shuffle_visit for the OLD model on its own bank   (the gate)
  swap S = keep - shuffle_visit for the NEW model on the OLD bank
  "survives"      if Holm rejects the intersection-union p = max(p_H, p_S)
  "lost"          if p_H <= 0.05, p_S > 0.05, and Holm rejects drop = H - S > 0
  "undetermined"  if p_H <= 0.05 and neither of the above
  "uninformative" if p_H > 0.05 (the swap contrast is then shown but not read)
Secondary (two-sided 95 % intervals, no test): keep - wipe, keep - shuffled (one global permutation
per repeat), keep - shuffle_bucket, keep - none, keep - own, relearn - keep, relearn - own;
same-maker minus cross-maker reader on a shared bank; group means; the in-bank versions (training
tasks, full design); the permutation spread; and two OBSERVATIONAL ranking measures:
  task_rank.csv    per validation task, among the memories the SHUFFLE arms happened to show
                   (exposure set by a random permutation, not by Q): does the old Q order agree
                   with "solved more often when this memory was shown"? Concordance over memory
                   pairs within a task, pooled over tasks (0.5 = chance).
  memory_rank.csv  per memory shown at least m times in the Q-free arms (wipe and the shuffles):
                   Spearman of old Q against the reader's success when shown.
Up to 5 memories share each episode's outcome, exactly as they share MemRL's reward.
"""
from __future__ import annotations

import csv
import json
import os
from collections import defaultdict
from pathlib import Path

import numpy as np
from scipy import stats

LEG = Path(__file__).resolve().parent
B = 2000
ALPHA = 0.05
SHUFFLE_ARMS = ("shuffle_visit", "shuffled", "shuffle_bucket")
Q_FREE_ARMS = ("wipe",) + SHUFFLE_ARMS


def _read_jsonl(p: Path) -> list[dict]:
    if not p.exists():
        return []
    return [json.loads(x) for x in p.read_text().splitlines() if x.strip()]


def load_runs(root: Path) -> list[dict]:
    runs = []
    for d in sorted((root / "eval").glob("*")) if (root / "eval").exists() else []:
        if not (d / "DONE.json").exists():
            continue
        meta = json.loads((d / "run.json").read_text())
        meta.setdefault("split", "val")
        last = {}
        for r in _read_jsonl(d / "episodes.jsonl"):
            if r.get("phase") == "eval" and r.get("success") is not None:
                last[r["sample_index"]] = r
        runs.append({**meta, "dir": d.name, "episodes": last})
    return runs


def holm(ps: list[float]) -> list[float]:
    """Holm step-down adjusted p-values."""
    m = len(ps)
    order = sorted(range(m), key=lambda i: ps[i])
    adj, running = [0.0] * m, 0.0
    for rank, i in enumerate(order):
        running = max(running, min(1.0, (m - rank) * ps[i]))
        adj[i] = running
    return adj


class Stats:
    def __init__(self, seed: int = 0):
        self.rng = np.random.default_rng(seed)

    def boot(self, v: np.ndarray) -> np.ndarray:
        return v[self.rng.integers(0, len(v), size=(B, len(v)))].mean(axis=1)

    def ci(self, v: np.ndarray) -> tuple[float, float, float]:
        if len(v) == 0:
            return (float("nan"),) * 3
        b = self.boot(v)
        return float(v.mean()), float(np.quantile(b, 0.025)), float(np.quantile(b, 0.975))

    def p_one(self, v: np.ndarray) -> float:
        """One-sided bootstrap p for H1: mean > 0 (share of re-drawn means at or below 0, plus one)."""
        if len(v) == 0:
            return float("nan")
        if np.all(v == 0):
            return 1.0
        b = self.boot(v)
        return float((1 + np.sum(b <= 0)) / (B + 1))


def collect(fake: bool, m_min: int = 3, design: str = "recommended") -> None:
    import run_leg   # the makers and the design's run order
    root = (Path(os.environ["MSR_LEG_RUNS_ROOT"]) if os.environ.get("MSR_LEG_RUNS_ROOT") else LEG / "runs") / ("fake" if fake else "real")
    out = (Path(os.environ["MSR_LEG_RESULTS_ROOT"]) if os.environ.get("MSR_LEG_RESULTS_ROOT") else LEG / "results") / ("fake" if fake else "")
    out.mkdir(parents=True, exist_ok=True)
    runs = load_runs(root)
    st = Stats(0)
    if not runs:
        print("no finished evaluation runs under", root)
        return

    def runs_of(reader, bank, arm, split="val"):
        return [r for r in runs if (r["reader"], r["bank"], r["arm"], r["split"]) == (reader, bank, arm, split)]

    def per_task(reader, bank, arm, split="val") -> dict:
        acc = defaultdict(list)
        for r in runs_of(reader, bank, arm, split):
            for t, e in r["episodes"].items():
                acc[t].append(1.0 if e["success"] else 0.0)
        return {t: float(np.mean(v)) for t, v in acc.items()}

    def dvec(a: dict, b: dict) -> dict:
        return {t: a[t] - b[t] for t in sorted(set(a) & set(b))}

    def diff(a: dict, b: dict) -> np.ndarray:
        return np.array(list(dvec(a, b).values()))

    pairs = run_leg.maker_pairs(fake)
    maker = {m: i for i, p in enumerate(pairs) for m in p}

    def kind(old, reader):
        if old == reader:
            return "home"
        if maker.get(old) != maker.get(reader):
            return "cross-maker"
        return "upgrade" if (old, reader) in pairs else "downgrade"

    # ---------------------------------------------------------------- episodes.csv, arms.csv, permutation spread
    with open(out / "episodes.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["reader", "bank", "arm", "repeat", "split", "sample_index", "success", "steps", "status",
                    "n_memories", "memory_ids", "memory_q", "memory_sim"])
        for r in runs:
            for t, e in sorted(r["episodes"].items()):
                mem = e.get("retrieved") or []
                w.writerow([r["reader"], r["bank"], r["arm"], r["repeat"], r["split"], t, int(bool(e["success"])), e.get("steps"),
                            e.get("status"), len(mem), ";".join(str(x["memory_id"]) for x in mem),
                            ";".join(f"{x['q']:.4f}" if x.get("q") is not None else "" for x in mem),
                            ";".join(f"{x['sim']:.4f}" if x.get("sim") is not None else "" for x in mem)])
    cells = sorted({(r["reader"], r["bank"], r["arm"], r["split"]) for r in runs})
    arm_rows, spread_rows = [], []
    for reader, bank, arm, split in cells:
        rates = []
        for r in sorted(runs_of(reader, bank, arm, split), key=lambda x: x["repeat"]):
            v = np.array([1.0 if e["success"] else 0.0 for e in r["episodes"].values()])
            m, lo, hi = st.ci(v)
            rates.append(m)
            arm_rows.append([reader, bank, arm, split, r["repeat"], len(v), m, lo, hi])
        v = np.array(list(per_task(reader, bank, arm, split).values()))
        m, lo, hi = st.ci(v)
        arm_rows.append([reader, bank, arm, split, "all", len(v), m, lo, hi])
        if len(rates) > 1 and arm in ("keep",) + SHUFFLE_ARMS:
            spread_rows.append([reader, bank, arm, split, len(rates), float(np.mean(rates)), float(np.std(rates, ddof=1))])
    with open(out / "arms.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["reader", "bank", "arm", "split", "repeat", "tasks", "success", "ci_low", "ci_high"])
        w.writerows([[*x[:6], *(round(y, 4) for y in x[6:])] for x in arm_rows])
    with open(out / "permutation_spread.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["reader", "bank", "arm", "split", "repeats", "mean_success", "sd_across_repeats"])
        w.writerows([[*x[:5], round(x[5], 4), round(x[6], 4)] for x in spread_rows])

    # ---------------------------------------------------------------- registered readings (family L)
    registered = run_leg.design_cells(design, fake)["swaps"]
    present = [(o, r, k) for o, r, k in registered
               if all(per_task(*c) for c in ((r, o, "keep"), (r, o, "shuffle_visit"), (o, o, "keep"), (o, o, "shuffle_visit")))]
    zz = stats.norm.ppf(1 - ALPHA) + stats.norm.ppf(0.8)
    read_rows = []
    for old, reader, k in present:
        H = dvec(per_task(old, old, "keep"), per_task(old, old, "shuffle_visit"))
        S = dvec(per_task(reader, old, "keep"), per_task(reader, old, "shuffle_visit"))
        hv, sv, dv = np.array(list(H.values())), np.array(list(S.values())), diff(H, S)
        (hm, hlo, hhi), (sm, slo, shi), (dm, dlo, dhi) = st.ci(hv), st.ci(sv), st.ci(dv)
        read_rows.append({"old": old, "reader": reader, "kind": k, "tasks": len(sv),
                          "home": hm, "home_lo": hlo, "home_hi": hhi, "p_home": st.p_one(hv),
                          "swap": sm, "swap_lo": slo, "swap_hi": shi, "p_swap": st.p_one(sv),
                          "drop": dm, "drop_lo": dlo, "drop_hi": dhi, "p_drop": st.p_one(dv),
                          "mde_swap_alone_observed": zz * sv.std(ddof=1) / np.sqrt(len(sv)) if len(sv) > 1 else float("nan")})
    if read_rows:
        for r, a in zip(read_rows, holm([max(r["p_home"], r["p_swap"]) for r in read_rows])):
            r["p_iut"], r["p_iut_holm"] = max(r["p_home"], r["p_swap"]), a
        for r, a in zip(read_rows, holm([r["p_drop"] for r in read_rows])):
            r["p_drop_holm"] = a
        for r in read_rows:
            if r["p_home"] > ALPHA:
                r["reading"] = "uninformative (no order effect shown at home)"
            elif r["p_iut_holm"] <= ALPHA:
                r["reading"] = "matters at home and survives"
            elif r["p_swap"] > ALPHA and r["p_drop_holm"] <= ALPHA:
                r["reading"] = "matters at home and is lost"
            else:
                r["reading"] = "matters at home; after the swap undetermined"
    cols = ["old", "reader", "kind", "tasks", "home", "home_lo", "home_hi", "p_home", "swap", "swap_lo", "swap_hi", "p_swap",
            "p_iut", "p_iut_holm", "drop", "drop_lo", "drop_hi", "p_drop", "p_drop_holm", "mde_swap_alone_observed", "reading"]
    with open(out / "readings.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(cols)
        for r in read_rows:
            w.writerow([round(r[c], 4) if isinstance(r[c], float) else r[c] for c in cols])

    # ---------------------------------------------------------------- secondary contrasts
    sec = []

    def add(label, who, d):
        if len(d):
            m, lo, hi = st.ci(d)
            sec.append([who, label, len(d), m, lo, hi])
    homes = sorted({o for o, _, _ in present})
    for old, reader, k in present + [(o, o, "home") for o in homes]:
        tag = f"{old} at home" if k == "home" else f"{old} -> {reader} ({k})"
        keep = per_task(reader, old, "keep")
        for arm in ("wipe", "shuffled", "shuffle_bucket"):
            add(f"keep - {arm}", tag, diff(keep, per_task(reader, old, arm)))
        add("keep - none", tag, diff(keep, per_task(reader, "none", "none")))
        if k != "home":
            own = per_task(reader, reader, "keep")
            rl = per_task(reader, old, "relearn")
            add("keep - own", tag, diff(keep, own))
            add("relearn - keep", tag, diff(rl, keep))
            add("relearn - own", tag, diff(rl, own))
        add("keep - shuffle_visit, in-bank (training tasks)", tag,
            diff(per_task(reader, old, "keep", "train"), per_task(reader, old, "shuffle_visit", "train")))
    for old in homes:
        same = [r for o, r, k in present if o == old and k in ("upgrade", "downgrade")]
        cross = [r for o, r, k in present if o == old and k == "cross-maker"]
        for rs in same:
            for rc in cross:
                Ss = dvec(per_task(rs, old, "keep"), per_task(rs, old, "shuffle_visit"))
                Sc = dvec(per_task(rc, old, "keep"), per_task(rc, old, "shuffle_visit"))
                add("swap contrast, same-maker reader minus cross-maker reader", f"bank {old}: {rs} vs {rc}", diff(Ss, Sc))
    for kname in ("upgrade", "downgrade", "cross-maker"):
        group = [(o, r) for o, r, k in present if k == kname]
        if group:
            per = defaultdict(list)
            for o, r in group:
                for t, v in dvec(per_task(r, o, "keep"), per_task(r, o, "shuffle_visit")).items():
                    per[t].append(v)
            add("group mean of the swap contrast (keep - shuffle_visit)", f"{kname} ({len(group)} swaps)",
                np.array([np.mean(v) for v in per.values()]))
    with open(out / "secondary.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["cell", "contrast", "tasks", "mean_diff", "ci_low", "ci_high"])
        w.writerows([[*x[:3], *(round(y, 4) for y in x[3:])] for x in sec])

    # ---------------------------------------------------------------- ranking inside the leg (observational)
    def old_q(bank):
        f = root / "banks" / bank / "keep" / "local_cache" / "q_cache.json"
        return {str(k): float(v) for k, v in json.loads(f.read_text()).items()} if f.exists() else {}
    rank_rows, mem_rows = [], []
    for old in sorted({r["bank"] for r in runs if r["bank"] != "none"}):
        q = old_q(old)
        for reader in sorted({r["reader"] for r in runs if r["bank"] == old}):
            by_task = defaultdict(list)
            for arm in SHUFFLE_ARMS:
                for r in runs_of(reader, old, arm):
                    for t, e in r["episodes"].items():
                        by_task[t].append(({str(x["memory_id"]) for x in (e.get("retrieved") or [])}, 1.0 if e["success"] else 0.0))
            per_task_c = []
            for t, eps in by_task.items():
                mems = set().union(*[s for s, _ in eps])
                h = {}
                for m in mems:
                    yin = [y for s, y in eps if m in s]
                    yout = [y for s, y in eps if m not in s]
                    if yin and yout and m in q:
                        h[m] = float(np.mean(yin) - np.mean(yout))
                ms = sorted(h)
                c = n = 0
                for i in range(len(ms)):
                    for j in range(i + 1, len(ms)):
                        a, b = ms[i], ms[j]
                        if h[a] == h[b] or q[a] == q[b]:
                            continue
                        n += 1
                        c += int((h[a] - h[b]) * (q[a] - q[b]) > 0)
                if n:
                    per_task_c.append((c, n))
            if per_task_c:
                cs = np.array([c for c, _ in per_task_c], float)
                ns = np.array([n for _, n in per_task_c], float)
                idx = st.rng.integers(0, len(cs), size=(B, len(cs)))
                bC = cs[idx].sum(1) / np.maximum(ns[idx].sum(1), 1)
                rank_rows.append([old, reader, kind(old, reader), len(per_task_c), int(ns.sum()), round(float(cs.sum() / ns.sum()), 4),
                                  round(float(np.quantile(bC, 0.025)), 4), round(float(np.quantile(bC, 0.975)), 4)])
            else:
                rank_rows.append([old, reader, kind(old, reader), 0, 0, "", "", ""])
            shown = defaultdict(list)
            for arm in Q_FREE_ARMS:
                for r in runs_of(reader, old, arm):
                    for e in r["episodes"].values():
                        for x in e.get("retrieved") or []:
                            shown[str(x["memory_id"])].append(1.0 if e["success"] else 0.0)
            ids = [m for m, v in shown.items() if len(v) >= m_min and m in q]
            if len(ids) >= 3:
                qq = np.array([q[m] for m in ids])
                ss = np.array([np.mean(shown[m]) for m in ids])
                rho = stats.spearmanr(qq, ss).statistic if qq.std() > 0 and ss.std() > 0 else float("nan")
                mem_rows.append([old, reader, kind(old, reader), len(ids), round(float(rho), 4) if rho == rho else "no variation"])
            else:
                mem_rows.append([old, reader, kind(old, reader), len(ids), "too few"])
    with open(out / "task_rank.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["bank_owner", "reader", "kind", "tasks_used", "memory_pairs", "concordance", "ci_low", "ci_high"])
        w.writerows(rank_rows)
    with open(out / "memory_rank.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["bank_owner", "reader", "kind", "memories_shown_at_least_m", "spearman_oldQ_vs_success_when_shown"])
        w.writerows(mem_rows)

    # ---------------------------------------------------------------- RESULTS.md
    L = []
    if fake:
        L += ["# MemRL leg - FAKE pipeline check (NOT results)", "",
              "The chat model is the local scripted stub (local_server.py). These numbers only show that every",
              "stage ran end to end with MemRL's code and real Docker grading.", ""]
    else:
        L += ["# MemRL leg (L3) - results", ""]
    L += [f"{len(runs)} finished evaluation runs under {root}. Design: {design}.", "",
          "## Registered readings (family L; one-sided, alpha 0.05; Holm over the directed swaps shown)", "",
          "| old -> reader | kind | home H [95%] | p_H | swap S [95%] | p_S | IUT p (Holm) | drop H-S [95%] | p drop (Holm) | reading |",
          "|---|---|---|---|---|---|---|---|---|---|"]
    for r in read_rows:
        L.append(f"| {r['old']} -> {r['reader']} | {r['kind']} | {r['home']:+.3f} [{r['home_lo']:+.3f}, {r['home_hi']:+.3f}] | "
                 f"{r['p_home']:.3f} | {r['swap']:+.3f} [{r['swap_lo']:+.3f}, {r['swap_hi']:+.3f}] | {r['p_swap']:.3f} | "
                 f"{r['p_iut_holm']:.3f} | {r['drop']:+.3f} [{r['drop_lo']:+.3f}, {r['drop_hi']:+.3f}] | {r['p_drop_holm']:.3f} | {r['reading']} |")
    if not read_rows:
        L.append("| (no directed swap of the design has all four cells yet) | | | | | | | | | |")
    L += ["", "## Permutation spread (each repeat of a shuffle arm is a new permutation; keep repeats show run noise alone)", "",
          "| reader | bank | arm | split | repeats | mean success | SD across repeats |", "|---|---|---|---|---|---|---|"]
    L += [f"| {x[0]} | {x[1]} | {x[2]} | {x[3]} | {x[4]} | {x[5]:.3f} | {x[6]:.3f} |" for x in spread_rows]
    L += ["", "## Secondary contrasts (two-sided 95% task-bootstrap intervals, no test)", "",
          "| cell | contrast | tasks | mean diff | 95% interval |", "|---|---|---|---|---|"]
    L += [f"| {x[0]} | {x[1]} | {x[2]} | {x[3]:+.3f} | [{x[4]:+.3f}, {x[5]:+.3f}] |" for x in sec]
    L += ["", "## Ranking inside the leg (observational; exposure randomised by the shuffles; 0.5 = chance)", "",
          "| bank owner | reader | kind | tasks used | memory pairs | concordance | 95% interval |", "|---|---|---|---|---|---|---|"]
    L += [f"| {x[0]} | {x[1]} | {x[2]} | {x[3]} | {x[4]} | {x[5]} | [{x[6]}, {x[7]}] |" for x in rank_rows]
    L += ["", "## Q-values MemRL actually used when choosing memories (episode logs)", "",
          "| reader | bank | arm | split | memories shown | distinct Q | mean Q | min Q | max Q |", "|---|---|---|---|---|---|---|---|---|"]
    for reader, bank, arm, split in cells:
        qv = [x["q"] for r in runs_of(reader, bank, arm, split) for e in r["episodes"].values()
              for x in (e.get("retrieved") or []) if x.get("q") is not None]
        if qv:
            L.append(f"| {reader} | {bank} | {arm} | {split} | {len(qv)} | {len(set(round(v, 9) for v in qv))} | "
                     f"{np.mean(qv):.3f} | {min(qv):.3f} | {max(qv):.3f} |")
    L += ["", "## Success per arm (task-bootstrap 95% interval; repeats pooled per task)", "",
          "| reader | bank | arm | split | tasks | success | 95% interval |", "|---|---|---|---|---|---|---|"]
    L += [f"| {x[0]} | {x[1]} | {x[2]} | {x[3]} | {x[5]} | {x[6]:.3f} | [{x[7]:.3f}, {x[8]:.3f}] |" for x in arm_rows if x[4] == "all"]
    (out / "RESULTS.md").write_text("\n".join(L) + "\n")
    print(f"wrote {out}: readings, secondary, permutation_spread, task_rank, memory_rank, arms, episodes, RESULTS.md "
          f"({len(runs)} runs; {len(read_rows)} directed swaps with all four registered cells)")
