"""A tiny local OpenAI-compatible server for the MemRL leg: embeddings, and (for --fake runs) a stub chat model.

Everyday picture: a reception desk in front of the lab. MemRL only knows how to phone an
"OpenAI-style" number. This desk answers that number on this computer:
- /v1/embeddings: always. It answers from ONE fixed embedding model for every chat model in the
  study, keeps every vector it ever made (so the same text always gets the same vector and
  re-runs cost nothing), and writes down every request.
    --embed bge     BAAI/bge-base-en-v1.5 on this computer (msr/embed.py), free, 768 numbers.
    --embed hash    a hashed bag of words (msr/embed.py), for tests only, 512 numbers.
    --embed openai  text-embedding-3-large, MemRL's own setting, 3072 numbers. The desk phones
                    OpenAI itself with OPENAI_API_KEY from this process's environment, so the key
                    never enters MemRL's process or any file. Each distinct text is paid once.
- /v1/chat/completions: only with --fake-chat. A scripted stand-in for a chat model
  (deterministic, no network): it solves an LLB OS task by sending the task's own ground-truth
  command when a hash of (model name, prompt) says so, and otherwise gives up. Success therefore
  depends on which memories were put in the prompt, so Q-values move during fake training, and
  the real Docker grader decides pass or fail. Without --fake-chat the endpoint answers HTTP 500
  and logs the call: MemRL should never reach a chat model except through its patched provider.
- GET /info: which embedding model and size this desk serves.

Run with the project venv: .venv/bin/python legs/memrl/local_server.py --port 8791 --embed bge
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import numpy as np

LEG = Path(__file__).resolve().parent
ROOT = LEG.parent.parent
OPENAI_EMBED_MODEL = "text-embedding-3-large"


# --------------------------------------------------------------------------- embeddings
class EmbedBackend:
    """One fixed embedding model with a vector store on disk (one .npy per distinct text)."""

    def __init__(self, kind: str, cache_root: Path):
        self.kind = kind
        self.lock = threading.Lock()
        if kind in ("bge", "hash"):
            sys.path.insert(0, str(ROOT))
            from msr.embed import DEFAULT_MODEL, HASH_MODEL, get_embedder
            self.model_name = DEFAULT_MODEL if kind == "bge" else HASH_MODEL
            self._emb = get_embedder(self.model_name)
            self.dim = int(self._emb.embed(["probe"]).shape[1])
            self._client = None
        elif kind == "openai":
            from openai import OpenAI
            key = os.environ.get("OPENAI_API_KEY")
            if not key:
                raise SystemExit("--embed openai needs OPENAI_API_KEY in the environment (run_leg.py loads it from .env).")
            self.model_name = OPENAI_EMBED_MODEL
            self._client = OpenAI(api_key=key, max_retries=6)
            self.dim = 3072
        else:
            raise SystemExit(f"unknown --embed {kind}")
        self.cache = cache_root / re.sub(r"[^A-Za-z0-9._-]+", "_", self.model_name)
        self.cache.mkdir(parents=True, exist_ok=True)
        self.paid_tokens = 0

    def _path(self, text: str) -> Path:
        h = hashlib.sha256(text.encode("utf-8")).hexdigest()
        return self.cache / h[:2] / f"{h}.npy"

    def embed(self, texts: list[str]) -> tuple[list[list[float]], int, int]:
        out: list[np.ndarray | None] = [None] * len(texts)
        missing = []
        for i, t in enumerate(texts):
            p = self._path(t)
            if p.exists():
                out[i] = np.load(p)
            else:
                missing.append(i)
        hits = len(texts) - len(missing)
        tokens = 0
        if missing:
            new_texts = [texts[i] for i in missing]
            if self._client is not None:
                vecs, tokens = [], 0
                for start in range(0, len(new_texts), 256):
                    r = self._client.embeddings.create(model=self.model_name, input=new_texts[start:start + 256])
                    vecs.extend(np.asarray(d.embedding, dtype=np.float32) for d in r.data)
                    tokens += int(getattr(r.usage, "total_tokens", 0) or 0)
                with self.lock:
                    self.paid_tokens += tokens
            else:
                vecs = list(np.asarray(self._emb.embed(new_texts), dtype=np.float32))
            for i, v in zip(missing, vecs):
                p = self._path(texts[i])
                p.parent.mkdir(parents=True, exist_ok=True)
                tmp = p.with_suffix(f".{os.getpid()}.{threading.get_ident()}.tmp.npy")
                np.save(tmp, v)
                os.replace(tmp, p)
                out[i] = v
        return [v.astype(float).tolist() for v in out], hits, tokens


# --------------------------------------------------------------------------- fake chat model
class FakeChat:
    """Deterministic scripted answers for LLB-OS tasks (see module docstring)."""

    # Chance to solve a task, in percent, without / with retrieved memories, per fake model.
    POLICY = {"fake-old": (35, 65), "fake-new": (45, 60), "fakex-old": (40, 55), "fakex-new": (50, 62)}

    def __init__(self, data_dir: Path):
        self.solution: dict[str, str] = {}
        for f in ("os_interaction_train.json", "os_interaction_val.json"):
            for v in json.loads((data_dir / f).read_text()).values():
                ev = v["evaluation_info"]
                gt = ev["ground_truth_command_item"] if isinstance(ev, dict) else None
                if gt and gt.get("command_name") == "bash":
                    self.solution[v["instruction"]] = gt["script"]

    @staticmethod
    def _memory_block(system: str) -> str:
        if "[Retrieved Memory Context]" not in system:
            return ""
        return system.split("[Retrieved Memory Context]", 1)[1].split("STRICT OUTPUT FORMAT", 1)[0]

    def answer(self, model: str, messages: list[dict]) -> tuple[str, str]:
        last = str(messages[-1].get("content", "")) if messages else ""
        if "High-level script:" in last:
            return "memory_script", ("1. Read the task and list the files and users it names.\n"
                                     "2. Run the commands that create or change them.\n"
                                     "3. Check the result with ls or cat before finishing.")
        if "Provide a brief reflection:" in last:
            return "memory_reflection", ("The attempt stopped before doing the work. Next time: run the "
                                         "commands that the task asks for, then check the files, then finish.")
        if "Keywords:" in last:
            return "keywords", "files, permissions, users"
        system = next((str(m.get("content", "")) for m in messages if m.get("role") == "system"), "")
        users = [str(m.get("content", "")) for m in messages if m.get("role") == "user"]
        instruction = next((u for u in users if u in self.solution), None)
        if instruction is None:
            return "agent_turn", "I cannot tell what the task is.\nAct: finish"
        done_turns = sum(1 for m in messages if m.get("role") == "assistant") - 1   # minus LLB's "OK."
        mem = self._memory_block(system)
        p_plain, p_mem = self.POLICY.get(model, (40, 60))
        h = hashlib.sha256(f"{model}|{instruction}|{mem}".encode("utf-8")).hexdigest()
        solve = int(h[:8], 16) % 100 < (p_mem if mem.strip() else p_plain)
        if done_turns >= 1:
            return "agent_turn", "The commands ran. I will stop here.\nAct: finish"
        if solve:
            return "agent_turn", ("I will run the commands the task needs.\nAct: bash\n```bash\n"
                                  + self.solution[instruction] + "\n```")
        return "agent_turn", "I will only look around.\nAct: bash\n```bash\nls /\n```"


# --------------------------------------------------------------------------- HTTP
def make_handler(state: dict):
    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, *a):   # quiet; we keep our own log
            return

        def _send(self, code: int, obj: dict) -> None:
            body = json.dumps(obj).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _log(self, rec: dict) -> None:
            rec["t"] = round(time.time(), 3)
            with state["log_lock"]:
                with open(state["log_path"], "a", encoding="utf-8") as f:
                    f.write(json.dumps(rec) + "\n")

        def do_GET(self):
            if self.path.rstrip("/") in ("/info", "/v1/info", "/health"):
                emb = state["embed"]
                self._send(200, {"embedding_model": emb.model_name, "dim": emb.dim, "fake_chat": state["fake"] is not None,
                                 "paid_embedding_tokens": emb.paid_tokens})
            else:
                self._send(404, {"error": {"message": "not found"}})

        def do_POST(self):
            n = int(self.headers.get("Content-Length") or 0)
            try:
                req = json.loads(self.rfile.read(n) or b"{}")
            except ValueError:
                return self._send(400, {"error": {"message": "bad json"}})
            path = self.path.rstrip("/")
            if path.endswith("/embeddings"):
                inp = req.get("input")
                texts = [inp] if isinstance(inp, str) else list(inp or [])
                try:
                    vecs, hits, tokens = state["embed"].embed([str(t) for t in texts])
                except Exception as e:   # backend failure: say so, never invent vectors
                    self._log({"path": "embeddings", "n": len(texts), "error": f"{type(e).__name__}: {e}"})
                    return self._send(502, {"error": {"message": f"embedding backend failed: {type(e).__name__}"}})
                self._log({"path": "embeddings", "n": len(texts), "cache_hits": hits, "paid_tokens": tokens})
                ntok = sum(len(t) for t in texts) // 4
                return self._send(200, {"object": "list", "model": state["embed"].model_name,
                                        "data": [{"object": "embedding", "index": i, "embedding": v} for i, v in enumerate(vecs)],
                                        "usage": {"prompt_tokens": ntok, "total_tokens": ntok}})
            if path.endswith("/chat/completions"):
                via_shim = self.headers.get("X-MSR-Leg-Shim") == "1"
                if state["fake"] is None:
                    self._log({"path": "chat", "via_shim": via_shim, "model": req.get("model"), "refused": True})
                    return self._send(500, {"error": {"message": "this local desk serves no chat model (start it with --fake-chat)"}})
                model = str(req.get("model"))
                msgs = req.get("messages") or []
                kind, text = state["fake"].answer(model, msgs)
                pin = sum(len(str(m.get("content", ""))) for m in msgs) // 4
                self._log({"path": "chat", "via_shim": via_shim, "model": model, "kind": kind,
                           "sent_keys": sorted(k for k in req if k not in ("messages",))})
                return self._send(200, {
                    "id": "fake-" + hashlib.sha1(text.encode()).hexdigest()[:12], "object": "chat.completion",
                    "created": int(time.time()), "model": model + "-stub-v1",
                    "choices": [{"index": 0, "finish_reason": "stop", "message": {"role": "assistant", "content": text}}],
                    "usage": {"prompt_tokens": pin, "completion_tokens": len(text) // 4, "total_tokens": pin + len(text) // 4}})
            self._send(404, {"error": {"message": "not found"}})

    return Handler


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--port", type=int, default=8791)
    ap.add_argument("--embed", choices=["bge", "hash", "openai"], default="bge")
    ap.add_argument("--fake-chat", action="store_true")
    ap.add_argument("--cache-root", default=str(LEG / "runs" / "_embed_cache"))
    ap.add_argument("--log", default=str(LEG / "runs" / "_server" / "requests.jsonl"))
    ap.add_argument("--data-dir", default=str(LEG / "src" / "data" / "llb"))
    args = ap.parse_args()
    Path(args.log).parent.mkdir(parents=True, exist_ok=True)
    state = {"embed": EmbedBackend(args.embed, Path(args.cache_root)),
             "fake": FakeChat(Path(args.data_dir)) if args.fake_chat else None,
             "log_path": args.log, "log_lock": threading.Lock()}
    srv = ThreadingHTTPServer(("127.0.0.1", args.port), make_handler(state))
    print(f"ready on 127.0.0.1:{args.port} embed={state['embed'].model_name} dim={state['embed'].dim} "
          f"fake_chat={args.fake_chat}", flush=True)
    srv.serve_forever()


if __name__ == "__main__":
    main()
