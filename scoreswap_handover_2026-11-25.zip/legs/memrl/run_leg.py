"""L3: the model-swap test on MemRL's own released code (LifelongAgentBench OS tasks). Revision 2.

Everyday picture: a garage helper (the OLD model) works through 350 practice jobs ten times with
MemRL, building a box of repair notes with a learned score on each. A NEW helper then does the 150
exam jobs with that box, under rules that differ ONLY in the scores: keep them, or deal them out
again at random among notes that were used about equally often (the within-visit shuffle, a fresh
deal on every repeat). First the OLD helper sits the same exam with its own box and both orderings:
if the scores' order does not help it at home, the swap test for that pair is not read.

Revision 2 (24 Nov 2026, reviewers R4/R5 and the AC audit): power analysis (tools/power_family_L.py),
the home gate, the within-visit and within-neighbourhood shuffles with one permutation per repeat,
both directions of each same-maker pair plus cross-maker swaps in a fixed block order, the
"relearn" reference, a ranking measure from the logs, and three costed designs.

One command per stage; every stage is safe to re-run (finished work is skipped, an interrupted
training resumes from its last saved section, an evaluation re-runs only the tasks it lacks).
Run with the project venv:  .venv/bin/python legs/memrl/run_leg.py <stage> ...

  estimate  [--design D]                calls, tokens and dollars of the three designs (no call is made)
  campaign  --design minimum|recommended|full   the whole design, block by block, in the fixed order
  pair      --old A --new B             one pair, both directions (no cross-maker swap)
  train     --model M                   MemRL training on the 350 train tasks -> a memory bank
  arms      --model M                   keep / wipe / discount and the shuffles (one copy per seed) + checks
  relearn   --reader R --bank B         R runs one more MemRL pass on B's bank, content frozen
  eval      --reader R --bank B --arm A --repeat r   (or --arm none)   150 validation tasks
  collect   [--design D]                results/*.csv and RESULTS.md (the gated readings of Part 8.4)
  status                                what is done

Paid stages print the cost and stop unless --yes is given. --fake replaces the chat model with a
local scripted stub (fake-old / fake-new / fakex-old / fakex-new, two pretend makers): the whole flow
runs for free with real Docker containers and MemRL's real code; its numbers are a pipeline check only.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import signal
import socket
import subprocess
import sys
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

import yaml

LEG = Path(__file__).resolve().parent
ROOT = LEG.parent.parent
SRC = LEG / "src"
ENV_PY = LEG / "env" / "bin" / "python"
DATA = SRC / "data" / "llb"
sys.path.insert(0, str(LEG))
sys.path.insert(0, str(ROOT))
import qsnap  # noqa: E402

FAKE_PAIRS = (("fake-old", "fake-new"), ("fakex-old", "fakex-new"))   # two pretend makers
FAKE_MODELS = tuple(m for p in FAKE_PAIRS for m in p)
PRIMARY_ARMS = ("keep", "shuffle_visit")                 # the registered contrast: keep - shuffle_visit
SECONDARY_ARMS = ("wipe", "shuffled", "shuffle_bucket")  # plus relearn, none and own
SHUFFLE_ARMS = qsnap.SHUFFLES                            # one fresh permutation per repeat (seed = repeat)
DESIGNS = {   # see README section 2 and measured/power_family_L.json
    "minimum": {"pairs": 2, "r_primary": 8, "r_secondary": 0, "relearn": False, "r_none": 2, "in_bank": 0, "probe": False},
    "recommended": {"pairs": 4, "r_primary": 8, "r_secondary": 2, "relearn": True, "r_none": 2, "in_bank": 0, "probe": False},
    "full": {"pairs": 4, "r_primary": 8, "r_secondary": 8, "relearn": True, "r_none": 2, "in_bank": 4, "probe": True},
}
INFRA_STATUSES = {"runner_exception", "SampleStatus.TASK_ENVIRONMENT_ERROR", "SampleStatus.TASK_UNKNOWN_ERROR",
                  "SampleStatus.AGENT_UNKNOWN_ERROR", "SampleStatus.AGENT_OUT_OF_MEMORY",
                  "task_environment_error", "task_unknown_error", "agent_unknown_error", "agent_out_of_memory"}
DEFAULT_SECTIONS = 10       # MemRL paper: "10-epoch OS-Interaction run" (App. H); shipped YAML says 20


def now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def say(msg: str) -> None:
    print(f"[run_leg {datetime.now().strftime('%H:%M:%S')}] {msg}", flush=True)


# =========================================================================== config
def load_models() -> dict:
    return yaml.safe_load((ROOT / "config" / "models.yaml").read_text())


def load_dotenv() -> dict:
    """Keys from the project's .env, by name, into a dict (never printed or written)."""
    out = {}
    p = ROOT / ".env"
    if p.exists():
        for line in p.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                v = v.strip().strip('"').strip("'")
                if v:
                    out[k.strip()] = v
    for k in ("ANTHROPIC_API_KEY", "OPENAI_API_KEY", "OPENROUTER_API_KEY"):
        if os.environ.get(k) and k not in out:
            out[k] = os.environ[k]
    return out


def model_spec(name: str, run_dir: Path, port: int, mode: str, replay_cache: bool) -> dict:
    """The JSON the patched MemRL provider reads (memrl/providers/leg_chat.py)."""
    cfg = load_models()
    common = {"name": name, "run_dir": str(run_dir), "max_tokens": 10240,   # rl_llb_config.yaml:24
              "spend_path": str(ROOT / "runs" / "spend.json"), "cap_usd": cfg["budget"]["hard_cap_usd"],
              "max_retries": 6, "timeout_s": 600}
    if mode == "fake":
        if name not in FAKE_MODELS:
            raise SystemExit(f"--fake runs use {FAKE_MODELS}, not {name}")
        return {**common, "provider": "fake", "api_model": name, "base_url": f"http://127.0.0.1:{port}/v1",
                "key_env": None, "max_tokens_field": "max_tokens", "price_in": 0.0, "price_out": 0.0, "cache_dir": None}
    m = cfg["models"].get(name)
    if m is None or m.get("provider") not in ("anthropic", "openai", "openrouter", "dashscope", "deepinfra"):
        raise SystemExit(f"model {name!r} is not a paid API model in config/models.yaml")
    prov = cfg["providers"][m["provider"]]
    if m["provider"] == "anthropic":
        base_url, field = "https://api.anthropic.com/v1/", "max_tokens"   # Anthropic's OpenAI-compatible endpoint
    elif m["provider"] == "openai":
        base_url, field = None, m.get("max_tokens_field") or "max_completion_tokens"
    else:
        base_url, field = prov["base_url"], m.get("max_tokens_field") or "max_tokens"
    return {**common, "provider": m["provider"], "api_model": m["api_model"], "base_url": base_url,
            "key_env": prov["key_env"], "max_tokens_field": field, "extra_body": m.get("extra_body"),
            "anthropic_thinking": m.get("anthropic_thinking"), "reasoning_effort": m.get("reasoning_effort"),
            "price_in": float(m["price_in"]), "price_out": float(m["price_out"]),
            # Replay cache only for evaluation runs (a re-run of missing tasks replays the answers it
            # already paid for). Training resumes at a section boundary instead, so a resumed run never
            # re-uses an answer given to an identical prompt in an earlier section.
            "cache_dir": str(runs_root() / "_call_cache") if replay_cache else None}


def embed_settings(embed: str) -> dict:
    """What changes with the embedding model. te3l = MemRL's own (text-embedding-3-large)."""
    if embed == "te3l":
        return {"server": "openai", "dim": 3072, "threshold": 0.50, "sim_mean": None, "sim_std": None,
                "model": "text-embedding-3-large"}
    if embed == "bge":
        cal = json.loads((LEG / "calib" / "bge_calibration.json").read_text())["bge"]
        return {"server": "bge", "dim": 768, "threshold": cal["threshold"], "sim_mean": cal["sim_norm_mean"],
                "sim_std": cal["sim_norm_std"], "model": "BAAI/bge-base-en-v1.5"}
    if embed == "hash":   # tests only
        return {"server": "hash", "dim": 512, "threshold": 0.0, "sim_mean": None, "sim_std": None, "model": "hash"}
    raise SystemExit(f"unknown --embed {embed}")


def base_yaml() -> dict:
    return yaml.safe_load((SRC / "configs" / "rl_llb_config.yaml").read_text())


def subset_file(split: str, limit: int | None, out_dir: Path) -> Path:
    """The full data file, or the first `limit` tasks of it (by key) for a small run."""
    src = DATA / f"os_interaction_{split}.json"
    if not limit:
        return src
    data = json.loads(src.read_text())
    keys = sorted(data, key=str)[:limit]
    dst = out_dir / f"os_interaction_{split}_first{limit}.json"
    dst.write_text(json.dumps({k: data[k] for k in keys}, indent=1))
    return dst


def write_config(run_dir: Path, *, name: str, port: int, emb: dict, sections: int, train_file: Path,
                 val_file: Path, checkpoint: Path | None, trace: bool) -> Path:
    c = base_yaml()
    c["llm"].update({"api_key": "unused-see-MSR_LEG_MODEL_JSON", "base_url": f"http://127.0.0.1:{port}/v1",
                     "model": name})   # MemOS's own config gets this desk, which refuses chat (logged)
    c["embedding"].update({"api_key": "local-desk", "base_url": f"http://127.0.0.1:{port}/v1", "model": emb["model"]})
    c["memory"]["load_from_checkpoint"] = checkpoint is not None
    c["memory"]["checkpoint_path"] = str(checkpoint) if checkpoint else None
    c["experiment"].update({
        "experiment_name": run_dir.name, "task": "os", "split_file": str(train_file), "valid_file": str(val_file),
        "num_sections": int(sections), "valid_interval": 0, "test_interval": 0, "val_before_train": False,
        "trace_jsonl_path": str(run_dir / "trace.jsonl") if trace else None, "output_dir": str(run_dir / "work" / "results")})
    c["rl_config"]["sim_threshold"] = emb["threshold"]
    c["rl_config"]["sim_threshold_by_task"] = {"os": emb["threshold"], "db": c["rl_config"]["sim_threshold_by_task"].get("db", 0.37)}
    p = run_dir / "config.yaml"
    p.write_text(yaml.safe_dump(c, sort_keys=False))
    return p


# =========================================================================== processes
def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@contextmanager
def local_desk(embed_server: str, fake: bool, log_dir: Path, keys: dict):
    port = free_port()
    log_dir.mkdir(parents=True, exist_ok=True)
    env = {k: os.environ[k] for k in ("PATH", "HOME", "LANG", "HF_HOME") if k in os.environ}
    if embed_server == "openai":
        if "OPENAI_API_KEY" not in keys:
            raise SystemExit("--embed te3l needs OPENAI_API_KEY in .env (or use --embed bge, the free stand-in).")
        env["OPENAI_API_KEY"] = keys["OPENAI_API_KEY"]
    cmd = [sys.executable, str(LEG / "local_server.py"), "--port", str(port), "--embed", embed_server,
           "--log", str(log_dir / "desk_requests.jsonl")] + (["--fake-chat"] if fake else [])
    out = open(log_dir / "desk_stdout.log", "a")
    proc = subprocess.Popen(cmd, stdout=out, stderr=subprocess.STDOUT, env=env, cwd=str(LEG))
    try:
        for _ in range(240):
            if proc.poll() is not None:
                raise SystemExit(f"local desk stopped; see {log_dir / 'desk_stdout.log'}")
            if "ready on" in (log_dir / "desk_stdout.log").read_text():
                break
            time.sleep(0.5)
        else:
            raise SystemExit("local desk did not start in 120 s")
        yield port
    finally:
        proc.send_signal(signal.SIGTERM)
        try:
            proc.wait(10)
        except subprocess.TimeoutExpired:
            proc.kill()
        out.close()


def kill_leftover_containers() -> None:
    ids = subprocess.run(["docker", "ps", "-q", "--filter", "label=created_by=os-pipeline"],
                         capture_output=True, text=True).stdout.split()
    if ids:
        subprocess.run(["docker", "kill", *ids], capture_output=True)
        say(f"killed {len(ids)} leftover task containers")


def run_memrl(run_dir: Path, cfg: Path, spec: dict, keys: dict, extra_env: dict, eval_only: bool) -> int:
    (run_dir / "work").mkdir(parents=True, exist_ok=True)
    spec_path = run_dir / "model_spec.json"
    spec_path.write_text(json.dumps(spec, indent=2))
    env = {k: os.environ[k] for k in ("PATH", "HOME", "LANG", "DOCKER_HOST", "TMPDIR") if k in os.environ}
    if spec.get("key_env"):
        if spec["key_env"] not in keys:
            raise SystemExit(f"{spec['key_env']} is not in .env")
        env[spec["key_env"]] = keys[spec["key_env"]]
    env.update({"MSR_LEG_MODEL_JSON": str(spec_path), "MSR_LEG_LOG_DIR": str(run_dir / "logs"),
                "MSR_LEG_EPISODES": str(run_dir / "episodes.jsonl"), "MSR_LEG_RUN": run_dir.name,
                "PYTHONUNBUFFERED": "1", "TOKENIZERS_PARALLELISM": "false"})
    env.update({k: str(v) for k, v in extra_env.items() if v is not None})
    cmd = [str(ENV_PY), str(SRC / "run" / "run_llb.py"), "--config", str(cfg)] + (["--eval-only"] if eval_only else [])
    with open(run_dir / "stdout.log", "a") as out:
        out.write(f"\n===== {now()} {' '.join(cmd)}\n")
        out.flush()
        rc = subprocess.run(cmd, stdout=out, stderr=subprocess.STDOUT, env=env, cwd=str(run_dir / "work")).returncode
    if (run_dir / "FATAL.json").exists():
        kill_leftover_containers()
        raise SystemExit(f"STOPPED: model call failed, see {run_dir / 'FATAL.json'} (nothing was graded from it)")
    return rc



# =========================================================================== paths
def runs_root() -> Path:
    """legs/memrl/runs, or $MSR_LEG_RUNS_ROOT (the tests and the rehearsal use their own folder)."""
    return Path(os.environ["MSR_LEG_RUNS_ROOT"]) if os.environ.get("MSR_LEG_RUNS_ROOT") else LEG / "runs"


def mode_root(fake: bool) -> Path:
    return runs_root() / ("fake" if fake else "real")


def train_dir(m: str, fake: bool) -> Path:
    return mode_root(fake) / "train" / m


def bank_dir(m: str, fake: bool) -> Path:
    return mode_root(fake) / "banks" / m


def relearn_dir(reader: str, bank: str, fake: bool) -> Path:
    return mode_root(fake) / "relearn" / f"{reader}__{bank}"


def eval_dir(reader: str, bank: str, arm: str, rep: int, fake: bool, split: str = "val") -> Path:
    return mode_root(fake) / "eval" / (f"{reader}__{bank}__{arm}__r{rep}" + ("" if split == "val" else f"__{split}"))


def arm_source(bank: str, arm: str, rep: int, reader: str, fake: bool) -> Path:
    """The bank copy an evaluation cell reads. Shuffle arms use a FRESH permutation per repeat (seed = repeat)."""
    if arm in SHUFFLE_ARMS:
        return bank_dir(bank, fake) / f"{arm}_s{rep}"
    if arm == "relearn":
        return bank_dir(bank, fake) / f"relearn_by_{reader}"
    return bank_dir(bank, fake) / arm


def check_run_json(run_dir: Path, want: dict) -> None:
    p = run_dir / "run.json"
    if p.exists():
        have = json.loads(p.read_text())
        diff = {k: (have.get(k), v) for k, v in want.items() if have.get(k) != v}
        if diff:
            raise SystemExit(f"{run_dir} was started with other settings {diff}; move it away or use the same settings")
    else:
        run_dir.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps({**want, "started_at": now()}, indent=2))


def snapshots(ck: Path) -> list[int]:
    s = ck / "snapshot"
    if not s.is_dir():
        return []
    return sorted(int(d.name) for d in s.iterdir() if d.name.isdigit() and (d / "local_cache" / "q_cache.json").exists()
                  and (d / "snapshot_meta.json").exists())


# =========================================================================== designs
def maker_pairs(fake: bool) -> list[tuple[str, str]]:
    """Same-maker old -> new pairs in the FIXED run order (Anthropic, OpenAI, Qwen, Gemma)."""
    return list(FAKE_PAIRS) if fake else [tuple(p) for p in load_models()["pairs"]]


def maker_of(model: str, fake: bool) -> str:
    for i, (o, n) in enumerate(maker_pairs(fake)):
        if model in (o, n):
            return f"maker{i}"
    return model


def design_blocks(design: str, fake: bool) -> list[dict]:
    """The run order. Block i trains maker i's pair and adds: both same-maker directions and ONE
    cross-maker swap (maker i's old model read by maker i+1's new model, cyclic over the makers of the
    design). So a budget cut after any block still leaves both kinds of swap."""
    d = DESIGNS[design]
    pairs = maker_pairs(fake)[: d["pairs"]]
    k = len(pairs)
    blocks = []
    for i, (old, new) in enumerate(pairs):
        cross_new = pairs[(i + 1) % k][1]
        blocks.append({"index": i + 1, "train": [old, new],
                       "swaps": [(old, new, "upgrade"), (new, old, "downgrade"), (old, cross_new, "cross-maker")],
                       "homes": [old, new]})
    return blocks


def design_cells(design: str, fake: bool, upto: int | None = None) -> dict:
    """Every evaluation cell (reader, bank, arm, repeat, split), relearn run and priced probe of a design, in run order."""
    d = DESIGNS[design]
    cells, relearns, probes, trains, seen = [], [], [], [], set()

    def add(c):
        if c not in seen:
            seen.add(c)
            cells.append(c)
    blocks = design_blocks(design, fake)[:upto]
    for b in blocks:
        trains += [m for m in b["train"] if m not in trains]
        # 1. primary arms: the home gate and the swap contrast, for every directed swap of the block
        for owner in b["homes"]:
            for arm in PRIMARY_ARMS:
                for r in range(d["r_primary"]):
                    add((owner, owner, arm, r, "val"))
        for old, reader, _kind in b["swaps"]:
            for arm in PRIMARY_ARMS:
                for r in range(d["r_primary"]):
                    add((reader, old, arm, r, "val"))
        for m in sorted({x for _, x, _ in b["swaps"]} | set(b["homes"])):
            for r in range(d["r_none"]):
                add((m, "none", "none", r, "val"))
        # 2. secondary arms
        for owner in b["homes"]:
            for arm in SECONDARY_ARMS:
                for r in range(d["r_secondary"]):
                    add((owner, owner, arm, r, "val"))
        for old, reader, _kind in b["swaps"]:
            for arm in SECONDARY_ARMS:
                for r in range(d["r_secondary"]):
                    add((reader, old, arm, r, "val"))
            if d["relearn"]:
                relearns.append((reader, old))
                for r in range(d["r_secondary"]):
                    add((reader, old, "relearn", r, "val"))
        # 3. in-bank evaluation on the 350 training tasks (full design): keep and the within-visit shuffle
        for old, reader, _kind in b["swaps"]:
            for who in (old, reader):
                for arm in PRIMARY_ARMS:
                    for r in range(d["in_bank"]):
                        add((who, old, arm, r, "train"))
        if d["probe"]:
            probes += [(o, o) for o in b["homes"]] + [(reader, old) for old, reader, _ in b["swaps"]]
    swaps = [(old, reader, kind) for b in blocks for old, reader, kind in b["swaps"]]
    return {"trains": trains, "cells": cells, "relearns": relearns, "probes": probes, "swaps": swaps}


# =========================================================================== estimate
def estimate_design(design: str, sections: int = DEFAULT_SECTIONS, fake: bool = False, upto: int | None = None) -> dict:
    """Calls / tokens / dollars of a whole design, from measured/prompt_sizes.json (tools/measure_prompts.py).
    Range: x0.7 to x2.5 (turns per episode and answer length are borrowed from RoMeRL's trajectories)."""
    ms = json.loads((LEG / "measured" / "prompt_sizes.json").read_text())
    cfg = load_models()["models"]
    turns = ms["agent_turns_per_episode_from_trajectories"]["mean"]
    plain = ms["episode_input_without_memory"]["mean"]
    mem5 = ms["memory_context_added_by_k_memories"]["5"]["mean"]
    mem1 = ms["memory_context_added_by_k_memories"]["1"]["mean"]
    out_turn = ms["agent_answer_per_turn"]["mean"]
    build_in = ms["memory_build_trajectory_input"]["mean"] + 100
    build_out = 0.6 * ms["memory_build_script_output"]["mean"] + 0.4 * ms["memory_build_reflection_output"]["mean"]

    def ep(mem: float, n: int, calls_extra=0, in_extra=0.0, out_extra=0.0) -> dict:
        return {"calls": n * (turns + calls_extra), "in": n * (plain + turns * mem + in_extra),
                "out": n * (turns * out_turn + out_extra)}
    unit = {"train": ep(mem5, 350 * sections, 1, build_in, build_out), "eval_val": ep(mem5, 150),
            "eval_train": ep(mem5, 350), "none": ep(0.0, 150), "relearn_train": ep(mem5, 350),
            "probe": ep(mem1, 150 * 8 * 2)}

    def usd(m: str, t: dict) -> float:
        p = cfg.get(m)
        return (t["in"] * p["price_in"] + t["out"] * p["price_out"]) / 1e6 if p else 0.0
    plan = design_cells(design, fake, upto)
    lines = []   # (what, model, unit name, count)
    for m in plan["trains"]:
        lines.append(("train", m, "train", 1))
    for reader, bank, arm, r, split in plan["cells"]:
        u = "none" if arm == "none" else ("eval_train" if split == "train" else "eval_val")
        lines.append(("eval", reader, u, 1))
    for reader, bank in plan["relearns"]:
        lines.append(("relearn", reader, "relearn_train", 1))
    for reader, bank in plan["probes"]:
        lines.append(("probe", reader, "probe", 1))
    tot = {"calls": 0.0, "in": 0.0, "out": 0.0, "usd": 0.0}
    by_kind, by_model = {}, {}
    for kind, m, u, n in lines:
        t = unit[u]
        c = usd(m, t) * n
        for k in ("calls", "in", "out"):
            tot[k] += t[k] * n
        tot["usd"] += c
        by_kind[kind] = by_kind.get(kind, 0.0) + c
        by_model[m] = by_model.get(m, 0.0) + c
    per_block = []
    for b in design_blocks(design, fake)[:upto]:
        per_block.append({"block": b["index"], "pair": b["train"], "swaps": [f"{o}->{r} ({k})" for o, r, k in b["swaps"]]})
    return {"design": design, "settings": DESIGNS[design], "sections": sections,
            "eval_runs": len(plan["cells"]), "trainings": len(plan["trains"]), "relearn_runs": len(plan["relearns"]),
            "probe_cells_priced": len(plan["probes"]), "directed_swaps": len(plan["swaps"]),
            "calls": round(tot["calls"]), "input_tokens_M": round(tot["in"] / 1e6, 1), "output_tokens_M": round(tot["out"] / 1e6, 1),
            "usd": round(tot["usd"], 2), "usd_range": [round(0.7 * tot["usd"], 2), round(2.5 * tot["usd"], 2)],
            "usd_by_kind": {k: round(v, 2) for k, v in by_kind.items()},
            "usd_by_model": {k: round(v, 2) for k, v in sorted(by_model.items(), key=lambda x: -x[1])},
            "blocks": per_block,
            "basis": {"turns_per_episode": turns, "episode_input_no_memory": plain, "memory_block_5": mem5,
                      "memory_block_1": mem1, "answer_per_turn": out_turn}}


def estimate_pair_blocks(design: str, fake: bool = False) -> list[dict]:
    """Cost of each block of a design run alone and cumulatively (what a budget cut keeps)."""
    out = []
    for i in range(1, len(design_blocks(design, fake)) + 1):
        e = estimate_design(design, fake=fake, upto=i)
        prev = out[-1] if out else {"usd": 0.0, "calls": 0}
        out.append({"blocks": i, "usd": e["usd"], "calls": e["calls"], "block_usd": round(e["usd"] - prev["usd"], 2),
                    "block_calls": e["calls"] - prev["calls"], "eval_runs": e["eval_runs"], "trainings": e["trainings"],
                    "same_maker_swaps": sum(1 for s in e["blocks"] for x in s["swaps"] if "cross" not in x),
                    "cross_maker_swaps": sum(1 for s in e["blocks"] for x in s["swaps"] if "cross" in x)})
    return out


def print_design(e: dict) -> None:
    s = e["settings"]
    say(f"design {e['design']}: {e['directed_swaps']} directed swaps, {e['trainings']} trainings, {e['eval_runs']} evaluation "
        f"runs (primary arms x{s['r_primary']}, secondary x{s['r_secondary']}, relearn {'yes' if s['relearn'] else 'no'}, "
        f"in-bank x{s['in_bank']}, probe {'priced' if s['probe'] else 'no'})")
    say(f"  {e['calls']:,} calls, {e['input_tokens_M']}M in, {e['output_tokens_M']}M out: USD {e['usd']:.2f} "
        f"(range {e['usd_range'][0]:.0f}-{e['usd_range'][1]:.0f}); by kind {e['usd_by_kind']}")
    for b in e["blocks"]:
        say(f"  block {b['block']}: train {b['pair']}; swaps {b['swaps']}")


def guard_paid(fake: bool, yes: bool, cost_usd: float, what: str) -> None:
    if fake:
        return
    say(f"{what}: estimated USD {cost_usd:.2f} (range {0.7 * cost_usd:.0f}-{2.5 * cost_usd:.0f})")
    if not yes:
        raise SystemExit("This stage calls paid models. Re-run with --yes once the owner has agreed to the cost above.")


def unit_cost(model: str, unit: str, sections: int = DEFAULT_SECTIONS) -> float:
    ms = json.loads((LEG / "measured" / "prompt_sizes.json").read_text())
    p = load_models()["models"].get(model)
    if not p:
        return 0.0
    turns = ms["agent_turns_per_episode_from_trajectories"]["mean"]
    plain = ms["episode_input_without_memory"]["mean"]
    mem5 = ms["memory_context_added_by_k_memories"]["5"]["mean"]
    out_turn = ms["agent_answer_per_turn"]["mean"]
    n = {"train": 350 * sections, "eval": 150, "relearn": 350}[unit]
    extra_in = (ms["memory_build_trajectory_input"]["mean"] + 100) if unit == "train" else 0
    extra_out = (0.6 * ms["memory_build_script_output"]["mean"] + 0.4 * ms["memory_build_reflection_output"]["mean"]) if unit == "train" else 0
    tin = n * (plain + turns * mem5 + extra_in)
    tout = n * (turns * out_turn + extra_out)
    return (tin * p["price_in"] + tout * p["price_out"]) / 1e6


# =========================================================================== stages
def stage_train(model: str, *, fake: bool, sections: int, limit_train: int | None, embed: str, yes: bool,
                keys: dict) -> Path:
    rd = train_dir(model, fake)
    want = {"stage": "train", "model": model, "sections": sections, "limit_train": limit_train, "embed": embed, "fake": fake}
    check_run_json(rd, want)
    done = snapshots(rd / "ckpt")
    if done and done[-1] >= sections:
        say(f"train {model}: done ({sections} sections)")
        return rd / "ckpt" / "snapshot" / str(sections)
    guard_paid(fake, yes, unit_cost(model, "train", sections), f"train {model}")
    emb = embed_settings(embed)
    train_file = subset_file("train", limit_train, rd)
    resume = None
    if done:
        resume = rd / "resume" / str(done[-1])
        qsnap.make_arm(rd / "ckpt" / "snapshot" / str(done[-1]), resume, "keep", q_start=0.5, force=True)
        say(f"train {model}: resuming after section {done[-1]} (from a private copy)")
    with local_desk(emb["server"], fake, rd / "logs", keys) as port:
        cfg = write_config(rd, name=model, port=port, emb=emb, sections=sections, train_file=train_file,
                           val_file=subset_file("val", None, rd), checkpoint=resume, trace=False)
        spec = model_spec(model, rd, port, "fake" if fake else "real", replay_cache=False)
        say(f"train {model}: MemRL training, {sections} sections over {train_file.name}")
        run_memrl(rd, cfg, spec, keys, {"MSR_LEG_PHASE": "train", "MSR_LEG_CKPT_DIR": rd / "ckpt",
                                        "MSR_LEG_VECTOR_DIM": emb["dim"], "MSR_LEG_SIM_NORM_MEAN": emb["sim_mean"],
                                        "MSR_LEG_SIM_NORM_STD": emb["sim_std"]}, eval_only=False)
    done = snapshots(rd / "ckpt")
    if not done or done[-1] < sections:
        raise SystemExit(f"train {model}: stopped after section {done[-1] if done else 0}; see {rd / 'stdout.log'}. "
                         f"Re-run the same command to resume.")
    final = rd / "ckpt" / "snapshot" / str(sections)
    (rd / "DONE.json").write_text(json.dumps({"finished_at": now(), "snapshot": str(final),
                                              "bank": qsnap.inspect(final), "structure": qsnap.structure(final)}, indent=2))
    if os.environ.get("MSR_LEG_KEEP_SNAPSHOTS") != "1":
        # disk: a real bank snapshot is ~300 MB; keep the final one only, drop MemRL's live store
        for k in snapshots(rd / "ckpt"):
            if k != sections:
                shutil.rmtree(rd / "ckpt" / "snapshot" / str(k), ignore_errors=True)
        shutil.rmtree(rd / "work" / "results", ignore_errors=True)
        shutil.rmtree(rd / "resume", ignore_errors=True)
    say(f"train {model}: done -> {final}")
    return final


def stage_arms(model: str, *, fake: bool, seeds: int, keys: dict, embed: str, probe: bool = True) -> Path:
    """keep / wipe / discount copies, and `seeds` permutations of each shuffle (one per evaluation repeat);
    then checks that every copy differs from keep only in Q, and MemRL's own retrieval on each copy."""
    td = train_dir(model, fake)
    run = json.loads((td / "run.json").read_text())
    final = td / "ckpt" / "snapshot" / str(run["sections"])
    if not final.exists():
        raise SystemExit(f"no finished bank for {model}; run: train --model {model}")
    bd = bank_dir(model, fake)
    bd.mkdir(parents=True, exist_ok=True)
    wanted = [("keep", 0), ("wipe", 0), ("discount", 0)] + [(a, s) for a in SHUFFLE_ARMS for s in range(seeds)]
    made, new = {}, []
    for arm, seed in wanted:
        name = f"{arm}_s{seed}" if arm in SHUFFLE_ARMS else arm
        dst = bd / name
        if (dst / "ARM.json").exists():
            made[name] = json.loads((dst / "ARM.json").read_text())
            continue
        made[name] = qsnap.make_arm(final, dst, arm, seed=seed, q_start=0.5, lam=0.5)
        new.append(name)
    check_path = bd / "arms_check.json"
    check = json.loads(check_path.read_text()) if check_path.exists() else {}
    verified = check.get("only_q_differs", {})
    for name in made:            # every copy not yet checked (also after an interrupted run)
        if name != "keep" and f"keep_vs_{name}" not in verified and not qsnap.is_slim(bd / name):
            v = qsnap.verify_only_q_differs(bd / "keep", bd / name)
            v.pop("files_checked", None)
            verified[f"keep_vs_{name}"] = v
    check.update({"bank": qsnap.inspect(final), "structure": qsnap.structure(final),
                  "arms": {k: {kk: vv for kk, vv in v.items() if kk != "source_meta"} for k, v in made.items()},
                  "only_q_differs": verified})
    ok = all(v["identical_except_q"] for v in verified.values())
    probed = set((json.loads((bd / "retrieval_probe.json").read_text()).get("vs_keep", {}))
                 if (bd / "retrieval_probe.json").exists() else set())
    if probe and [n for n in made if n != "keep" and n not in probed and not qsnap.is_slim(bd / n)]:
        emb = embed_settings(run.get("embed", embed))
        with local_desk(emb["server"], False, bd / "logs", keys) as port:
            out = bd / "retrieval_probe_new.json"
            r = subprocess.run([str(ENV_PY), str(LEG / "memrl_probe.py"), "--bank-dir", str(bd), "--embed-url",
                                f"http://127.0.0.1:{port}/v1", "--threshold", str(emb["threshold"]), "--out", str(out)]
                               + (["--sim-mean", str(emb["sim_mean"]), "--sim-std", str(emb["sim_std"])] if emb["sim_mean"] is not None else []),
                               capture_output=True, text=True, cwd=str(bd))
            if r.returncode != 0:
                raise SystemExit(f"retrieval probe failed:\n{r.stdout[-2000:]}\n{r.stderr[-3000:]}")
        newp = json.loads(out.read_text())
        merged = json.loads((bd / "retrieval_probe.json").read_text()) if (bd / "retrieval_probe.json").exists() else {}
        vs = {**merged.get("vs_keep", {}), **newp["vs_keep"]}
        newp["vs_keep"] = vs
        newp["copies"] = sorted(set(merged.get("copies", [])) | set(newp["copies"]))
        newp.update(probe_summary(vs))
        newp.pop("selections", None)
        (bd / "retrieval_probe.json").write_text(json.dumps(newp, indent=2))
        out.unlink()
    if (bd / "retrieval_probe.json").exists():
        check["retrieval_probe"] = json.loads((bd / "retrieval_probe.json").read_text())
    for name in made:            # disk: every copy but keep becomes a light record (ARM.json + Q map)
        if name != "keep" and not qsnap.is_slim(bd / name):
            qsnap.slim(bd / name)
    check_path.write_text(json.dumps(check, indent=2))
    msg = f"arms {model}: {len(made)} copies ({len(new)} new); only Q differs: {ok}"
    if "retrieval_probe" in check:
        sc = check["retrieval_probe"]["share_changed"]
        msg += "; tasks whose shown set changes vs keep: " + ", ".join(
            f"{a} {sc[a]:.2f} (sd {check['retrieval_probe']['share_changed_sd'].get(a, 0):.2f})" for a in sorted(sc))
    say(msg)
    if not ok:
        raise SystemExit(f"arm copies differ beyond Q: see {check_path}")
    return bd


def probe_summary(vs: dict) -> dict:
    """share_changed per copy type, mean and SD over its permutations (from memrl_probe's vs_keep)."""
    share, sd, jac = {}, {}, {}
    for typ in ("shuffled", "shuffle_visit", "shuffle_bucket", "wipe", "discount"):
        names = [a for a in vs if a == typ or a.startswith(typ + "_s")]
        xs = [vs[a]["share_changed"] for a in names]
        js = [vs[a]["mean_jaccard_with_keep"] for a in names if vs[a].get("mean_jaccard_with_keep") is not None]
        if xs:
            m = sum(xs) / len(xs)
            share[typ], jac[typ] = m, (sum(js) / len(js) if js else None)
            sd[typ] = (sum((x - m) ** 2 for x in xs) / (len(xs) - 1)) ** 0.5 if len(xs) > 1 else 0.0
    return {"share_changed": share, "share_changed_sd": sd, "mean_jaccard_with_keep": jac}


def stage_relearn(reader: str, bank: str, *, fake: bool, yes: bool, keys: dict) -> Path:
    """'Pay to relearn': the reader runs ONE more MemRL training pass over the 350 training tasks on the
    old bank, with the content frozen (patch 0003: no memory added), so only the Q-values move."""
    dst = bank_dir(bank, fake) / f"relearn_by_{reader}"
    if (dst / "ARM.json").exists():
        say(f"relearn {reader} on {bank}: done")
        return dst
    brun = json.loads((train_dir(bank, fake) / "run.json").read_text())
    rd = relearn_dir(reader, bank, fake)
    check_run_json(rd, {"stage": "relearn", "reader": reader, "bank": bank, "limit_train": brun["limit_train"],
                        "embed": brun["embed"], "fake": fake})
    start_sec = brun["sections"]
    done = snapshots(rd / "ckpt")
    if not (done and done[-1] >= start_sec + 1):
        guard_paid(fake, yes, unit_cost(reader, "relearn"), f"relearn {reader} on {bank}")
        start = rd / "start"
        qsnap.make_arm(bank_dir(bank, fake) / "keep", start, "keep", force=True)
        emb = embed_settings(brun["embed"])
        train_file = subset_file("train", brun["limit_train"], rd)
        with local_desk(emb["server"], fake, rd / "logs", keys) as port:
            cfg = write_config(rd, name=reader, port=port, emb=emb, sections=start_sec + 1, train_file=train_file,
                               val_file=subset_file("val", None, rd), checkpoint=start, trace=False)
            spec = model_spec(reader, rd, port, "fake" if fake else "real", replay_cache=False)
            say(f"relearn {reader} on {bank}: one MemRL pass over {train_file.name}, content frozen")
            run_memrl(rd, cfg, spec, keys, {"MSR_LEG_PHASE": "relearn", "MSR_LEG_CKPT_DIR": rd / "ckpt",
                                            "MSR_LEG_FREEZE_CONTENT": "1", "MSR_LEG_VECTOR_DIM": emb["dim"],
                                            "MSR_LEG_SIM_NORM_MEAN": emb["sim_mean"], "MSR_LEG_SIM_NORM_STD": emb["sim_std"]},
                      eval_only=False)
        done = snapshots(rd / "ckpt")
        if not done or done[-1] < start_sec + 1:
            raise SystemExit(f"relearn {reader} on {bank} did not finish; see {rd / 'stdout.log'}")
    snap = rd / "ckpt" / "snapshot" / str(start_sec + 1)
    same = qsnap.verify_same_content(bank_dir(bank, fake) / "keep", snap)
    if not same["same_content"]:
        raise SystemExit(f"relearn changed the memory content: {same['problems']}")
    qsnap.make_arm(snap, dst, "keep", force=True)
    qsnap.slim(dst)                                  # rebuilt from the relearn snapshot when evaluated
    shutil.rmtree(rd / "start", ignore_errors=True)
    shutil.rmtree(rd / "work" / "results", ignore_errors=True)
    (rd / "DONE.json").write_text(json.dumps({"finished_at": now(), "same_content_as_old_bank": same}, indent=2))
    say(f"relearn {reader} on {bank}: done; same content, {same['memories_with_different_q']} Q-values moved")
    return dst


def eval_records(rd: Path) -> dict:
    """Last good record per task; infra errors do not count as done."""
    best = {}
    p = rd / "episodes.jsonl"
    if p.exists():
        for line in p.read_text().splitlines():
            if not line.strip():
                continue
            r = json.loads(line)
            if r.get("phase") != "eval":
                continue
            if str(r.get("status")) in INFRA_STATUSES:
                best.setdefault(r["sample_index"], None)
            else:
                best[r["sample_index"]] = r
    return best


def stage_eval(reader: str, bank: str, arm: str, rep: int, *, fake: bool, limit_val: int | None, yes: bool,
               keys: dict, embed: str, split: str = "val", max_attempts: int = 3) -> Path:
    if arm == "none":
        bank = "none"
    rd = eval_dir(reader, bank, arm, rep, fake, split)
    if (rd / "DONE.json").exists():
        return rd
    if bank != "none":
        brun = json.loads((train_dir(bank, fake) / "run.json").read_text())
        embed = brun["embed"]          # the reader must use the embedder the bank was built with
        if split == "train":
            limit_val = brun["limit_train"]
    want = {"stage": "eval", "reader": reader, "bank": bank, "arm": arm, "repeat": rep, "split": split,
            "limit_val": limit_val, "embed": embed, "fake": fake}
    check_run_json(rd, want)
    val_file = subset_file(split, limit_val, rd)
    all_ids = sorted(json.loads(val_file.read_text()), key=str)
    emb = embed_settings(embed)
    for attempt in range(1, max_attempts + 1):
        got = eval_records(rd)
        todo = [i for i in all_ids if got.get(i) is None]
        if not todo:
            break
        if attempt == 1:
            guard_paid(fake, yes, unit_cost(reader, "eval") * len(all_ids) / 150, f"eval {rd.name}")
        snap = None
        if bank != "none":
            src = arm_source(bank, arm, rep, reader, fake)
            if not (src / "ARM.json").exists():
                raise SystemExit(f"no bank copy {src}; run: arms --model {bank}" + (" / relearn" if arm == "relearn" else ""))
            snap = rd / "bank"
            if qsnap.is_slim(src):
                qsnap.materialize(src, snap)                    # rebuilt exactly (same Q map, checked)
            else:
                qsnap.make_arm(src, snap, "keep", force=True)   # a private copy: loading writes to its store
            shutil.copy(src / "ARM.json", rd / "ARM_source.json")
        with local_desk(emb["server"], fake, rd / "logs", keys) as port:
            cfg = write_config(rd, name=reader, port=port, emb=emb, sections=1, train_file=val_file, val_file=val_file,
                               checkpoint=snap, trace=True)
            spec = model_spec(reader, rd, port, "fake" if fake else "real", replay_cache=True)
            say(f"eval {rd.name}: {len(todo)} task(s), attempt {attempt}")
            run_memrl(rd, cfg, spec, keys, {"MSR_LEG_PHASE": "eval", "MSR_LEG_ARM": arm, "MSR_LEG_REPEAT": rep,
                                            "MSR_LEG_READER": reader, "MSR_LEG_BANK": bank,
                                            "MSR_LEG_EVAL_SAMPLES": ",".join(todo) if len(todo) < len(all_ids) else None,
                                            "MSR_LEG_EVAL_SUMMARY": rd / f"eval_summary_attempt{attempt}.json",
                                            "MSR_LEG_VECTOR_DIM": emb["dim"], "MSR_LEG_SIM_NORM_MEAN": emb["sim_mean"],
                                            "MSR_LEG_SIM_NORM_STD": emb["sim_std"]}, eval_only=True)
        if any(eval_records(rd).get(i) is None for i in todo):
            kill_leftover_containers()   # only after a failed attempt (never while another stage may run)
    got = eval_records(rd)
    missing = [i for i in all_ids if got.get(i) is None]
    if missing:
        raise SystemExit(f"eval {rd.name}: {len(missing)} task(s) still without a clean result after {max_attempts} "
                         f"attempts: {missing[:10]}; see {rd / 'stdout.log'}")
    succ = sum(1 for i in all_ids if got[i]["success"])
    shutil.rmtree(rd / "bank", ignore_errors=True)            # disk: the private copy is not needed any more
    (rd / "DONE.json").write_text(json.dumps({"finished_at": now(), "tasks": len(all_ids), "successes": succ,
                                              "success_rate": succ / len(all_ids)}, indent=2))
    say(f"eval {rd.name}: {succ}/{len(all_ids)} solved")
    return rd


def run_cells(plan: dict, *, fake: bool, sections: int, limit_train, limit_val, embed: str, keys: dict, seeds: int,
              only_models: set | None = None) -> None:
    """Run a plan in its order: per block, train, make arm copies, primary cells, then secondary cells."""
    trained = set()
    for reader, bank, arm, r, split in plan["cells"]:
        if bank != "none" and bank not in trained:
            stage_train(bank, fake=fake, sections=sections, limit_train=limit_train, embed=embed, yes=True, keys=keys)
            stage_arms(bank, fake=fake, seeds=seeds, keys=keys, embed=embed)
            trained.add(bank)
        if arm == "relearn":
            stage_relearn(reader, bank, fake=fake, yes=True, keys=keys)
        stage_eval(reader, bank, arm, r, fake=fake, limit_val=limit_val, yes=True, keys=keys, embed=embed, split=split)


def pair_plan(old: str, new: str, r_primary: int, r_secondary: int, relearn: bool, r_none: int) -> dict:
    """One pair, both directions, no cross-maker swap (the campaign adds those)."""
    cells, relearns = [], []
    for owner in (old, new):
        for arm in PRIMARY_ARMS:
            cells += [(owner, owner, arm, r, "val") for r in range(r_primary)]
    for bank, reader in ((old, new), (new, old)):
        for arm in PRIMARY_ARMS:
            cells += [(reader, bank, arm, r, "val") for r in range(r_primary)]
    for m in (old, new):
        cells += [(m, "none", "none", r, "val") for r in range(r_none)]
    for owner in (old, new):
        for arm in SECONDARY_ARMS:
            cells += [(owner, owner, arm, r, "val") for r in range(r_secondary)]
    for bank, reader in ((old, new), (new, old)):
        for arm in SECONDARY_ARMS:
            cells += [(reader, bank, arm, r, "val") for r in range(r_secondary)]
        if relearn:
            relearns.append((reader, bank))
            cells += [(reader, bank, "relearn", r, "val") for r in range(r_secondary)]
    return {"cells": cells, "relearns": relearns, "trains": [old, new]}


def stage_status(fake: bool) -> None:
    r = mode_root(fake)
    for d in sorted((r / "train").glob("*")) if (r / "train").exists() else []:
        s = snapshots(d / "ckpt")
        say(f"train {d.name}: sections saved {s[-1] if s else 0}{' DONE' if (d / 'DONE.json').exists() else ''}")
    for d in sorted((r / "banks").glob("*")) if (r / "banks").exists() else []:
        say(f"bank  {d.name}: {len([a for a in d.iterdir() if (a / 'ARM.json').exists()])} copies")
    evals = sorted((r / "eval").glob("*")) if (r / "eval").exists() else []
    done = [d for d in evals if (d / "DONE.json").exists()]
    say(f"eval runs: {len(done)} finished of {len(evals)} started")


# =========================================================================== main
def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("stage", choices=["estimate", "train", "arms", "relearn", "eval", "pair", "campaign", "collect", "status"])
    ap.add_argument("--model")
    ap.add_argument("--reader")
    ap.add_argument("--bank")
    ap.add_argument("--arm", choices=list(PRIMARY_ARMS + SECONDARY_ARMS) + ["relearn", "none"])
    ap.add_argument("--repeat", type=int, default=0)
    ap.add_argument("--split", choices=["val", "train"], default="val",
                    help="train = the 350 training tasks (in-bank evaluation, full design only)")
    ap.add_argument("--old")
    ap.add_argument("--new")
    ap.add_argument("--design", choices=["minimum", "recommended", "full"], default="recommended")
    ap.add_argument("--sections", type=int, default=DEFAULT_SECTIONS)
    ap.add_argument("--repeats", type=int, default=None, help="pair: repeats of the primary arms (default: the design's)")
    ap.add_argument("--repeats-secondary", type=int, default=None, help="pair: repeats of the secondary arms (0 = none)")
    ap.add_argument("--no-relearn", action="store_true")
    ap.add_argument("--seeds", type=int, default=None, help="arms: permutations per shuffle arm (default: max repeats)")
    ap.add_argument("--limit-train", type=int, default=None)
    ap.add_argument("--limit-val", type=int, default=None)
    ap.add_argument("--embed", choices=["te3l", "bge", "hash"], default=None,
                    help="te3l = MemRL's text-embedding-3-large (default for real runs); bge = free local stand-in (default for --fake)")
    ap.add_argument("--m", type=int, default=3, help="collect: min retrievals per memory for the observational rank table")
    ap.add_argument("--fake", action="store_true")
    ap.add_argument("--runs-root", default=None,
                    help="keep this run apart from the study's runs (e.g. legs/memrl/runs/smoke for a smoke test)")
    ap.add_argument("--yes", action="store_true")
    ap.add_argument("--estimate", action="store_true", help="print calls and dollars for this stage and stop")
    a = ap.parse_args()
    if a.runs_root:
        os.environ["MSR_LEG_RUNS_ROOT"] = str(Path(a.runs_root).resolve())
    embed = a.embed or ("bge" if a.fake else "te3l")
    keys = load_dotenv() if not a.fake else ({k: v for k, v in load_dotenv().items() if k == "OPENAI_API_KEY"} if embed == "te3l" else {})
    d = DESIGNS[a.design]
    r_primary = a.repeats if a.repeats is not None else d["r_primary"]
    r_secondary = a.repeats_secondary if a.repeats_secondary is not None else d["r_secondary"]
    seeds = a.seeds or max(r_primary, r_secondary, 1)

    if a.stage == "estimate" or a.estimate:
        out = {}
        for name in (["minimum", "recommended", "full"] if a.stage == "estimate" and not a.estimate else [a.design]):
            e = estimate_design(name, a.sections, a.fake)
            e["by_block_cumulative"] = estimate_pair_blocks(name, a.fake)
            print_design(e)
            for x in e["by_block_cumulative"]:
                say(f"  block {x['blocks']}: {x['block_calls']:,} calls, USD {x['block_usd']:.2f} "
                    f"(range {0.7 * x['block_usd']:.0f}-{2.5 * x['block_usd']:.0f}); blocks 1-{x['blocks']} together USD {x['usd']:.2f}, "
                    f"{x['same_maker_swaps']} same-maker + {x['cross_maker_swaps']} cross-maker swaps")
            out[name] = e
        (LEG / "measured").mkdir(exist_ok=True)
        (LEG / "measured" / "estimate_designs.json").write_text(json.dumps(out, indent=2))
        return
    if a.stage == "train":
        stage_train(a.model, fake=a.fake, sections=a.sections, limit_train=a.limit_train, embed=embed, yes=a.yes, keys=keys)
    elif a.stage == "arms":
        stage_arms(a.model, fake=a.fake, seeds=seeds, keys=keys, embed=embed)
    elif a.stage == "relearn":
        stage_relearn(a.reader, a.bank, fake=a.fake, yes=a.yes, keys=keys)
    elif a.stage == "eval":
        stage_eval(a.reader, a.bank or "none", a.arm, a.repeat, fake=a.fake, limit_val=a.limit_val, yes=a.yes,
                   keys=keys, embed=embed, split=a.split)
    elif a.stage == "pair":
        plan = pair_plan(a.old, a.new, r_primary, r_secondary, not a.no_relearn and r_secondary > 0, d["r_none"])
        if not a.fake:
            cost = sum(unit_cost(m, "train", a.sections) for m in plan["trains"]) + \
                sum(unit_cost(c[0], "eval") for c in plan["cells"]) + sum(unit_cost(r, "relearn") for r, _ in plan["relearns"])
            guard_paid(False, a.yes, cost, f"pair {a.old} <-> {a.new}")
        for m in plan["trains"]:
            stage_train(m, fake=a.fake, sections=a.sections, limit_train=a.limit_train, embed=embed, yes=True, keys=keys)
            stage_arms(m, fake=a.fake, seeds=seeds, keys=keys, embed=embed)
        run_cells(plan, fake=a.fake, sections=a.sections, limit_train=a.limit_train, limit_val=a.limit_val,
                  embed=embed, keys=keys, seeds=seeds)
        say(f"pair {a.old} <-> {a.new}: all {len(plan['cells'])} evaluation runs done")
    elif a.stage == "campaign":
        name = a.design
        if a.repeats is not None or a.repeats_secondary is not None or a.no_relearn:
            # a smaller rehearsal of a design (same blocks and order, fewer repeats); never for the registered run
            DESIGNS["custom"] = {**d, "r_primary": r_primary, "r_secondary": r_secondary,
                                 "relearn": d["relearn"] and not a.no_relearn and r_secondary > 0}
            name = "custom"
        plan = design_cells(name, a.fake)
        if not a.fake:
            guard_paid(False, a.yes, estimate_design(name, a.sections)["usd"], f"campaign {name}")
        run_cells(plan, fake=a.fake, sections=a.sections, limit_train=a.limit_train, limit_val=a.limit_val,
                  embed=embed, keys=keys, seeds=max(DESIGNS[name]["r_primary"], DESIGNS[name]["r_secondary"], 1))
        say(f"campaign {a.design}{' (custom repeats)' if name == 'custom' else ''}: all {len(plan['cells'])} evaluation runs done")
    elif a.stage == "collect":
        from collect import collect
        collect(fake=a.fake, m_min=a.m, design=a.design)
    elif a.stage == "status":
        stage_status(a.fake)


if __name__ == "__main__":
    main()
