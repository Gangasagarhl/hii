#!/usr/bin/env bash
# Build everything the MemRL leg needs, reproducibly, with no model call. Safe to re-run.
#   1. MemRL cloned into legs/memrl/src at the pinned commit (SOURCE_SHA), then our patches applied.
#   2. An isolated Python 3.10 conda environment in legs/memrl/env with MemRL's requirements
#      (requirements.leg.txt = theirs minus the ALFWorld/BrowserGym-only packages; torch 2.8.0 CPU
#      build), wheels only (--only-binary=:all:), so no package runs an install script on this machine.
#   3. The Docker image local-os/default for the OS tasks (docker/Dockerfile: theirs with the base
#      image pinned to Ubuntu 24.04 by digest).
#   4. RoMeRL's released OS bank (MIT) at d3311e2, read as data only, for the measurements.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
PIN="$(head -1 "$HERE/SOURCE_SHA")"
CONDA="${CONDA:-~/anaconda3/bin/conda}"

if [ ! -d "$HERE/src/.git" ]; then
  git -c http.version=HTTP/1.1 clone -q https://github.com/MemTensor/MemRL.git "$HERE/src"
fi
git -C "$HERE/src" checkout -q "$PIN"
[ "$(git -C "$HERE/src" rev-parse HEAD)" = "$PIN" ] || { echo "MemRL is not at $PIN" >&2; exit 1; }
"$HERE/apply_patches.sh"

if [ ! -x "$HERE/env/bin/python" ]; then
  "$CONDA" create -y -p "$HERE/env" python=3.10
fi
if [ ! -f "$HERE/env/.leg_installed" ]; then
  "$HERE/env/bin/python" -m pip install -q --upgrade pip
  "$HERE/env/bin/python" -m pip install --only-binary=:all: --index-url https://download.pytorch.org/whl/cpu torch==2.8.0
  "$HERE/env/bin/python" -m pip install --only-binary=:all: -r "$HERE/requirements.leg.txt" pytest==8.3.3
  "$HERE/env/bin/python" -m pip freeze > "$HERE/env_freeze.txt"
  touch "$HERE/env/.leg_installed"
fi

if ! docker image inspect local-os/default >/dev/null 2>&1; then
  "$HERE/docker/build_image.sh"
fi

if [ ! -d "$HERE/calib/romerl/.git" ]; then
  git -c http.version=HTTP/1.1 clone -q https://github.com/YOUNG-fnxm/RoMeRL.git "$HERE/calib/romerl"
fi
git -C "$HERE/calib/romerl" checkout -q d3311e28abf9328ec5377c640763f79b9df5b9c9
echo "setup done: MemRL $PIN + patches, env $("$HERE/env/bin/python" --version), image $(docker image inspect local-os/default --format '{{.Id}}')"
