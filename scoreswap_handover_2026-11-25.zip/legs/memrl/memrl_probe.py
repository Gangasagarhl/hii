"""Run MemRL's OWN retrieval (MemoryService.retrieve_query) on arm snapshots, with no model call.

Everyday picture: before the new helper starts, ask the filing clerk "which 5 tips would you
hand over for this job?" under each set of score cards, and compare the answers.

It builds a MemoryService without MemOS (no store, no LLM), fills it with MemRL's own cache
loader (_restore_local_caches, memory_service.py:2103-2196) from an arm snapshot's local_cache/,
and calls retrieve_query (memory_service.py:1254-1506) for each validation instruction, with
epsilon set to 0 so the choice is the greedy one. Uses: the claim "a single global discount
changes nothing" (Q enters only through z = (Q - mean)/std over the candidates, :1442-1454, which
is unchanged by Q -> a + bQ for b > 0), and a check that keep / wipe / shuffled really change
which memories are shown.

Run with the leg's Python:
    legs/memrl/env/bin/python legs/memrl/memrl_probe.py --bank-dir runs/fake/banks/fake-old \
        --embed-url http://127.0.0.1:8791/v1 --threshold 0.6877 --sim-mean .. --sim-std .. --out probe.json
"""
from __future__ import annotations

import argparse
import json
import random
import sys
import threading
from pathlib import Path

LEG = Path(__file__).resolve().parent
SRC = LEG / "src"
sys.path.insert(0, str(SRC))
sys.path.insert(0, str(SRC / "3rdparty" / "LifelongAgentBench"))

from memrl.configs.config import RLConfig  # noqa: E402
from memrl.service.memory_service import MemoryService  # noqa: E402

# rl_config of configs/rl_llb_config.yaml:148-169, with epsilon 0 (greedy) for a deterministic probe.
LLB_RL = dict(epsilon=0.0, tau=0.35, alpha=0.3, gamma=0.0, q_init_pos=0.5, q_init_neg=0.5,
              success_reward=1.0, failure_reward=0.0, sim_threshold=0.50, topk=5, novelty_threshold=0.85,
              recency_boost=0.0, reward_merge_gain=0.1, q_min_threshold=-0.8, weight_sim=0.5, weight_q=0.5,
              q_floor=0.0)


class FixedEmbedder:
    """Vectors from a dict, or from an embed function for unseen texts."""

    def __init__(self, fn):
        self.fn = fn

    def embed(self, texts):
        return self.fn(list(texts))


def bare_service(cache_dir: Path, embedder, *, sim_mean: float | None, sim_std: float | None,
                 rl: dict | None = None) -> MemoryService:
    ms = MemoryService.__new__(MemoryService)   # no MemOS: retrieval only reads the local caches
    ms.dict_memory, ms.query_embeddings, ms._mem_cache, ms._q_cache = {}, {}, {}, {}
    ms._mem_cache_max_size, ms._q_cache_max_size = 10000, 1000000
    ms._db_gate = threading.BoundedSemaphore(4)
    ms.mos, ms.default_cube_id, ms.user_id = None, None, "probe"
    ms.embedding_provider = embedder
    ms.rl_config = RLConfig(**(rl or LLB_RL))
    ms.weight_sim, ms.weight_q = ms.rl_config.weight_sim, ms.rl_config.weight_q
    ms.sim_norm_mean = 0.1856827586889267 if sim_mean is None else float(sim_mean)   # memory_service.py:311
    ms.sim_norm_std = 0.09407906234264374 if sim_std is None else float(sim_std)      # memory_service.py:312
    ms.use_z_score_normalization = True
    ms.dedup_by_task_id = False
    assert MemoryService._restore_local_caches(ms, str(cache_dir)), f"nothing restored from {cache_dir}"
    return ms


def selections(ms: MemoryService, queries: list[str], threshold: float, k: int = 10, restrict: int = 24) -> list[list[str]]:
    """MemRL's greedy choice for each query. Speed-up that does not change the answer: before each call
    the service sees only the `restrict` stored queries most similar to the task (numpy cosine);
    retrieve_query keeps the top k = 10 of those above the threshold (memory_service.py:1305-1316),
    which are the same 10 as over all stored queries. restrict = 0 turns this off."""
    import numpy as np
    full_dm, full_qe = ms.dict_memory, ms.query_embeddings
    keys = list(full_dm.keys())
    mat = np.array([full_qe[q] for q in keys], dtype=float) if keys and restrict else None
    if mat is not None:
        mat = mat / np.linalg.norm(mat, axis=1, keepdims=True)
    out = []
    for q in queries:
        if mat is not None and len(keys) > restrict:
            v = np.asarray(ms.embedding_provider.embed([q])[0], dtype=float)
            sims = mat @ (v / np.linalg.norm(v))
            top = [keys[i] for i in np.argsort(-sims)[:restrict]]
            ms.dict_memory = {t: full_dm[t] for t in top}
            ms.query_embeddings = {t: full_qe[t] for t in top}
        try:
            res = ms.retrieve_query(task_description=q, k=k, threshold=threshold)
        finally:
            ms.dict_memory, ms.query_embeddings = full_dm, full_qe
        out.append([s["memory_id"] for s in res[0]["selected"]] if isinstance(res, tuple) else [])
    return out


def compare(base: list[list[str]], other: list[list[str]]) -> dict:
    same_set = sum(1 for a, b in zip(base, other) if set(a) == set(b))
    same_order = sum(1 for a, b in zip(base, other) if a == b)
    with_mem = sum(1 for a in base if a)
    return {"queries": len(base), "queries_with_memory": with_mem, "same_selected_set": same_set,
            "same_selected_order": same_order}


def probe(bank_dir: Path, queries: list[str], embed_fn, threshold: float, sim_mean=None, sim_std=None) -> dict:
    """MemRL's greedy choice on every copy in bank_dir (keep, discount, wipe, shuffled_s*, shuffle_visit_s*,
    shuffle_bucket_s*). share_changed[type] = share of tasks that get memories whose chosen SET differs
    from keep, averaged over the permutations of that type (sd across permutations beside it)."""
    names = sorted(p.name for p in bank_dir.iterdir() if (p / "local_cache" / "dict_memory.json").exists()
                   and (p / "ARM.json").exists() and not (p / "SLIM").exists() and not p.name.startswith("relearn_by_"))
    if "keep" not in names:
        raise SystemExit(f"no keep copy in {bank_dir}")
    vecs = dict(zip(queries, embed_fn(list(queries))))     # embed once, reuse for every copy
    emb = FixedEmbedder(lambda texts: [vecs[t] for t in texts])
    sel = {}
    for a in names:
        ms = bare_service(bank_dir / a / "local_cache", emb, sim_mean=sim_mean, sim_std=sim_std)
        random.seed(0)
        sel[a] = selections(ms, queries, threshold)
    vs = {a: compare(sel["keep"], sel[a]) for a in names if a != "keep"}
    for a in vs:
        both = [(set(k), set(o)) for k, o in zip(sel["keep"], sel[a]) if k]
        vs[a]["mean_jaccard_with_keep"] = (sum(len(k & o) / len(k | o) for k, o in both) / len(both)) if both else None
        vs[a]["share_changed"] = (1 - vs[a]["same_selected_set"] / vs[a]["queries"]) * vs[a]["queries"] / max(1, vs[a]["queries_with_memory"])
    share, sd, jac = {}, {}, {}
    for typ in ("shuffled", "shuffle_visit", "shuffle_bucket", "wipe", "discount"):
        xs = [vs[a]["share_changed"] for a in vs if a == typ or a.startswith(typ + "_s")]
        js = [vs[a]["mean_jaccard_with_keep"] for a in vs if (a == typ or a.startswith(typ + "_s")) and vs[a]["mean_jaccard_with_keep"] is not None]
        if xs:
            m = sum(xs) / len(xs)
            share[typ] = m
            sd[typ] = (sum((x - m) ** 2 for x in xs) / max(1, len(xs) - 1)) ** 0.5 if len(xs) > 1 else 0.0
            jac[typ] = sum(js) / len(js) if js else None
    return {"copies": names, "threshold": threshold, "queries": len(queries),
            "queries_with_memory_under_keep": sum(1 for x in sel["keep"] if x),
            "share_changed": share, "share_changed_sd": sd, "mean_jaccard_with_keep": jac,
            "vs_keep": vs, "selections": sel}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--bank-dir", required=True)
    ap.add_argument("--embed-url", required=True)
    ap.add_argument("--val-file", default=str(SRC / "data" / "llb" / "os_interaction_val.json"))
    ap.add_argument("--threshold", type=float, default=0.50)
    ap.add_argument("--sim-mean", type=float, default=None)
    ap.add_argument("--sim-std", type=float, default=None)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    from memrl.providers.embedding import OpenAIEmbedder
    emb = OpenAIEmbedder(api_key="local-no-key", base_url=args.embed_url, model="served-by-local-desk",
                         token_log_dir=str(Path(args.out).parent / "probe_token_log"))
    val = json.loads(Path(args.val_file).read_text())
    queries = [v["instruction"] for _, v in sorted(val.items())]
    res = probe(Path(args.bank_dir), queries, emb.embed, args.threshold, args.sim_mean, args.sim_std)
    Path(args.out).write_text(json.dumps(res, indent=2))
    print(json.dumps({k: v for k, v in res.items() if k != "selections"}, indent=2))


if __name__ == "__main__":
    main()
