"""The end of a stage: retry the SQL queries that timed out, redo the units they touched, report the rest.

Everyday picture: the examiner could not finish marking a few answers because the marking machine was
jammed. At the end of the day, with the hall empty, he tries those answers once more. Every page with
an unfinished mark is then marked again (the answers are kept, so nothing is asked twice and nothing
is paid twice). Whatever he still cannot mark is written down as "not marked: timeout" and counted;
it is never quietly counted as wrong.

How (msr.grade, run.py): a BIRD query that does not finish is retried once at once (msr.grade); if it
still does not finish the answer is saved with "ungraded": "timeout". When a stage has finished,
run.py calls finish_stage(): it retries every waiting query once, one at a time (msr.grade.retry_pending).
If any now finishes:
  - probe-type rows (probe passes, no-memory passes, extra home repeats, subsets, second wording) are
    graded again IN PLACE from the stored answers (calls.jsonl, by call id; no call at all), and the
    files put together from them are removed so the stage puts them together again;
  - units whose learning used the grade (a build bank or its write / no-memory file, an online cell, a
    relearn cell) lose their "done" mark and the stage runs again: only those units are redone, their
    calls come back from the answer cache (simulated calls are recomputed: free and deterministic).
Rows that are still ungraded are counted per stage and printed; the analysis must treat them as missing,
never as wrong (a note for the statistics worker: rows carry "ungraded": "timeout").
"""
from __future__ import annotations

import json
from pathlib import Path

from msr import grade as G


def _has_ungraded(path: Path) -> int:
    """How many rows of a JSON-lines file carry "ungraded" (0 if the file is missing)."""
    if not path.exists():
        return 0
    n = 0
    with open(path, encoding="utf-8") as f:
        for line in f:
            if '"ungraded"' in line and json.loads(line).get("ungraded"):
                n += 1
    return n


def _units(st, stage: str) -> list:
    """[(ungraded rows, files graded again in place, files to remove)] for every unit of `stage` whose
    saved rows carry "ungraded"."""
    d = st.dir
    out = []
    if stage == "build":
        for bank in sorted(d.glob("banks/*/*/seed*")):
            if not bank.is_dir():
                continue
            n_w = _has_ungraded(bank / "write.jsonl")
            if n_w:
                out.append((n_w, [], [bank / "write.jsonl", bank / "items.jsonl"]))
            n_2 = _has_ungraded(bank / "write2.jsonl")
            if n_2:
                out.append((n_2, [], [bank / "write2.jsonl"]))
            n_0 = _has_ungraded(bank / "build0.jsonl")
            if n_0:   # the credit family read this baseline: its banks are redone too
                out.append((n_0, [], [bank / "build0.jsonl", bank / "build_summary.json"]
                            + list(bank.glob("bank*/build_summary.json"))))
            for b in [bank] + sorted(bank.glob("bank*")):
                if b.is_dir():
                    n_e = _has_ungraded(b / "episodes.jsonl")
                    if n_e:
                        out.append((n_e, [], [b / "build_summary.json"]))
    elif stage == "probe":
        for name in ("probes", "subsets", "variants"):
            for f in sorted(d.glob(f"{name}/**/*.jsonl")):
                if f.name.startswith("repeat") or f.name == "subsets.jsonl":
                    n = _has_ungraded(f)
                    if n:
                        out.append((n, [f], [f.parent / "probe.jsonl", f.parent / "done.json"]))
        for name, cells in (("probes0", "probes"), ("variants0", "variants")):
            for f in sorted(d.glob(f"{name}/**/repeat*.jsonl")):
                n = _has_ungraded(f)
                if n:   # the reader's no-memory rows are copied into each of its cells: put them together again
                    reader, stream, seed = f.parts[-4], f.parts[-3], f.parts[-2]
                    redo = [f.parent / "probe0.jsonl"]
                    for c in d.glob(f"{cells}/**/*__{reader}/{stream}/{seed}"):
                        redo += [c / "probe.jsonl", c / "done.json"]
                    out.append((n, [f], redo))
    elif stage == "probe_extra":
        for f in sorted(d.glob("probes/*/*/seed*/probe_extra.jsonl")):
            n = _has_ungraded(f)
            if n:
                out.append((n, [f], []))
    elif stage == "online":
        for f in sorted(d.glob("online/*/*/seed*/online.jsonl")):
            n = _has_ungraded(f)
            if n:
                out.append((n, [], [f.parent / "done.json"]))
    elif stage == "relearn":
        for f in sorted(d.glob("relearn/*/*/seed*/episodes.jsonl")):
            n = _has_ungraded(f)
            if n:
                out.append((n, [], [f.parent / "build_summary.json"]))
    return out


def regrade_in_place(st, files: list) -> int:
    """Grade the ungraded rows of these files again from their stored answers (calls.jsonl, found by
    call id; no model call) and rewrite the files atomically. Returns how many rows are now graded."""
    from msr import data as D
    from msr.build import read_jsonl, write_jsonl
    want = {}
    rows_by_file = {}
    for f in files:
        rows = read_jsonl(f)
        rows_by_file[f] = rows
        for r in rows:
            if r.get("ungraded"):
                want[r["call_id"]] = None
    if not want:
        return 0
    with open(st.dir / "calls.jsonl", encoding="utf-8") as fh:
        for line in fh:
            if '"call_id"' not in line:
                continue
            rec = json.loads(line)
            if rec.get("call_id") in want:
                want[rec["call_id"]] = (rec.get("meta") or {}).get("stream"), rec.get("answer")
    tasks = {}
    fixed = 0
    for f, rows in rows_by_file.items():
        changed = False
        for r in rows:
            if not r.get("ungraded") or want.get(r["call_id"]) is None:
                continue
            stream, answer = want[r["call_id"]]
            if stream not in tasks:
                tasks[stream] = D.task_index(stream)
            det = G.grade_detail(stream, tasks[stream][r["task_id"]], answer, faithful=st.bird_faithful)
            if not det.get("ungraded"):
                r["correct"] = bool(det["correct"])
                r.pop("ungraded", None)
                fixed += 1
                changed = True
        if changed:
            write_jsonl(f, rows)
    return fixed


def ungraded_report(st, stage: str) -> int:
    """How many saved rows of `stage` are still ungraded (timeout)."""
    return sum(n for n, _f, _r in _units(st, stage))


def finish_stage(st, stage: str, rerun, printer=print) -> dict:
    """After `stage` has run: retry the waiting queries, redo the touched units if any query now
    finishes (rerun() runs the stage again; finished units are skipped), and report what is left."""
    out = {"stage": stage, "retried": 0, "graded": 0, "still_timed_out": 0, "units_redone": 0, "ungraded_rows": 0}
    if G.pending_timeouts():
        printer(f"  [{stage}] {len(G.pending_timeouts())} SQL quer(ies) timed out twice; retrying them now, "
                f"one at a time, with nothing else running ...")
        r = G.retry_pending(printer)
        out.update(retried=r["retried"], graded=r["graded"], still_timed_out=r["still_timed_out"])
        if r["graded"]:
            units = _units(st, stage)
            fixed = regrade_in_place(st, [f for _n, files, _r in units for f in files])
            for _n, _files, remove in units:
                for f in remove:
                    try:
                        Path(f).unlink()
                    except FileNotFoundError:
                        pass
            out["units_redone"] = len(units)
            out["regraded_in_place"] = fixed
            if units:
                printer(f"  [{stage}] {len(units)} unit(s) had an ungraded answer: {fixed} row(s) graded again from "
                        f"the stored answers; units whose learning used a grade are redone (answers come from the "
                        f"cache, grades now from the grade cache)")
                rerun()
    out["ungraded_rows"] = ungraded_report(st, stage)
    if out["ungraded_rows"]:
        printer(f"  [{stage}] {out['ungraded_rows']} saved answer(s) are UNGRADED (timeout): counted as missing, "
                f"never as wrong; rows carry \"ungraded\": \"timeout\"")
    return out
