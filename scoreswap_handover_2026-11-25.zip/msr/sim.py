"""A free, simulated model, so the whole study can run end to end without spending,
and be checked against a truth we wrote down ourselves.

Everyday picture: a driving school tests its scoring sheet on actors who follow a
script. Each actor is a "student" with a known skill; each road has a known
difficulty; each tip on the instructor's card helps or hurts each student by a
known amount. If the scoring sheet is right, the scores it gives should match the
script. Here the "students" are the simulated models, the "roads" are the tasks
and the "tips" are the memory items.

The script (every number is drawn from a hash of strings, never from Python's
hash() or a random generator, so it is the same on every machine and every run):

    p(correct) = sigmoid(skill_m + difficulty(task) + effect_m(items, task))

    difficulty(task)        = DIFFICULTY_SD * z("difficulty", task)
    effect_m(item, task)    = quality_m(item) + rel_bonus(item, task)
    quality_m(item)         = strength * ( sqrt(g)       * z("global", item)
                                         + sqrt(f)       * z("family", family_m, item)
                                         + sqrt(1 - g - f) * z("model", m, item) )
    rel_bonus(item, task)   = rel if the item came from a task with the same answer
                              label (ddxplus) or the same database (bird), else 0
    (optional) correct_effect(item) = +correct_bonus if the item's stored answer was graded
                              correct when it was written, -correct_bonus if wrong. Default 0:
                              the stored answer has no effect (sim-1). A study switches it on with
                              `simulator: {correct_bonus: ...}` (config/sim_construct.yaml).

    z(...) is a standard normal number made from the sha256 of its arguments.
    With several items shown, their effects are averaged; with none, the effect is 0.

So two models of the same family share g + f = 70 % of the item-quality variance
(correlation 0.7) and two models of different families share g = 30 % (0.3), with
the defaults below. Whether one call is right is a Bernoulli draw from a hash of
(model, task, item ids, repeat): the same call always gives the same answer, and a
different repeat is a fresh draw.

Answers grade through msr.grade.grade like a real model's: on success the gold
answer in the exact format the grader accepts, on failure a well-formed wrong one.

Ratings (meta["stage"] == "selfrate" or "judge"): one whole number 1..meta["scale"] (default 10).
"selfrate": the writer rates its own stored item at write time: 5.5 + 1.5 x its own item quality in
standard units + 1 if its stored answer was right, - 1 if wrong, + noise (sd 1), rounded and clipped.
"judge": a reader rates an owner's stored item: 5.5 + 1.5 x the READER's item quality in standard
units (+ the stored-answer term when correct_bonus is on) + noise (sd 1). Same call, same number.

Self-marking (meta["stage"] == "selfmark", or "relearn_tag"): one word, helpful / harmful / neutral.
With probability 0.2 the word is random (noise). Otherwise, for an item whose
effect e >= 0 the model says "helpful" with probability sigmoid(2e), else "neutral";
for e < 0 it says "harmful" with probability sigmoid(-2e), else "neutral".

Item ids: the item's own id is what the draws are keyed on. If the id contains a
task id (for example "ddxplus-0123" or "ddxplus-0123@sim-a-old"), that task is taken
as the item's source task for rel_bonus; otherwise rel_bonus is 0.
"""
from __future__ import annotations

import hashlib
import math
import re
from functools import lru_cache
from statistics import NormalDist

SIM_VERSION = "sim-1"

# Defaults; any of strength, g, f, rel, difficulty_sd can be overridden per model in
# config/models.yaml under that model's params.
STRENGTH = 1.2          # how much items matter, in log-odds
G_SHARE = 0.3           # share of item-quality variance common to ALL models
F_SHARE = 0.4           # extra share common to the models of one family
REL_BONUS = 0.5         # bonus when the item's source task is "the same kind" of task
DIFFICULTY_SD = 1.0     # spread of task difficulty, in log-odds
SELFMARK_NOISE = 0.2    # chance that a self-mark word is random
SELFMARK_WORDS = ("helpful", "harmful", "neutral")
CORRECT_BONUS = 0.0     # log-odds added when an item's stored answer was right, taken off when wrong
RATING_SLOPE = 1.5      # rating points per standard unit of item quality (selfrate, judge)
RATING_NOISE = 1.0      # sd of the rating noise, in rating points
RATING_CORRECT = 1.0    # selfrate: + this when the writer's stored answer was right, - when wrong

_N = NormalDist()
_TASK_ID_RE = re.compile(r"(ddxplus|bird)-\d+")


# --------------------------------------------------------------------------- hashed draws
def _u(*parts) -> float:
    """A number in (0, 1), the same every time for the same parts."""
    key = "\x1f".join(str(p) for p in (SIM_VERSION, *parts))
    d = hashlib.sha256(key.encode("utf-8")).digest()
    return (int.from_bytes(d[:8], "big") + 0.5) / 2.0 ** 64


def _z(*parts) -> float:
    """A standard normal number, the same every time for the same parts."""
    return _N.inv_cdf(_u(*parts))


def sigmoid(x: float) -> float:
    if x >= 0:
        return 1.0 / (1.0 + math.exp(-x))
    e = math.exp(x)
    return e / (1.0 + e)


# --------------------------------------------------------------------------- models and tasks
@lru_cache(maxsize=1)
def _config_models() -> dict:
    from msr.llm import load_config
    return load_config()["models"]


def model_params(model_name: str, model_cfg: dict | None = None) -> dict:
    """The simulated model's settings, with the module defaults filled in."""
    if model_cfg is None:
        model_cfg = _config_models().get(model_name)
        if model_cfg is None:
            raise KeyError(f"{model_name!r} is not in config/models.yaml")
    if model_cfg.get("provider", "sim") != "sim":
        raise ValueError(f"{model_name!r} is not a simulated model (provider "
                         f"{model_cfg.get('provider')!r})")
    p = dict(model_cfg.get("params") or {})
    out = {
        "name": model_name,
        "family": str(p.get("family", model_name)),
        "skill": float(p.get("skill", 0.0)),
        "seed": p.get("seed", 0),
        "strength": float(p.get("strength", STRENGTH)),
        "g": float(p.get("g", G_SHARE)),
        "f": float(p.get("f", F_SHARE)),
        "rel": float(p.get("rel", REL_BONUS)),
        "difficulty_sd": float(p.get("difficulty_sd", DIFFICULTY_SD)),
        "correct_bonus": float(p.get("correct_bonus", CORRECT_BONUS)),
        "api_model": model_cfg.get("api_model", model_name),
    }
    if not (0 <= out["g"] and 0 <= out["f"] and out["g"] + out["f"] <= 1):
        raise ValueError(f"{model_name}: need g >= 0, f >= 0 and g + f <= 1")
    return out


def _model_key(p: dict) -> str:
    return f"{p['name']}#{p['seed']}"


@lru_cache(maxsize=None)
def _tasks(stream: str) -> dict:
    """task_id -> task for one stream, loaded once (msr.data.load_stream)."""
    from msr.data import load_stream
    return {t["task_id"]: t for t in load_stream(stream)}


def _stream_of(task_id: str) -> str:
    m = _TASK_ID_RE.match(str(task_id))
    if not m:
        raise ValueError(f"cannot tell the stream of task {task_id!r}; pass meta['stream']")
    return m.group(1)


def _items_list(items) -> list[str]:
    """None / one id / a list of ids -> a list of id strings."""
    if items is None:
        return []
    if isinstance(items, (list, tuple, set, frozenset)):
        return [str(i) for i in items if i is not None]
    return [str(items)]


def _source_task(item_id: str, stream: str) -> dict | None:
    """The task a memory item was made from, if its id names one of the stream's tasks."""
    for m in _TASK_ID_RE.finditer(item_id):
        if m.group(1) == stream:
            t = _tasks(stream).get(m.group(0))
            if t is not None:
                return t
    return None


# --------------------------------------------------------------------------- the truth
def difficulty(task_id: str, model_name: str | None = None) -> float:
    """How hard a task is (log-odds, shared by all models; higher = easier)."""
    sd = model_params(model_name)["difficulty_sd"] if model_name else DIFFICULTY_SD
    return sd * _z("difficulty", task_id)


def item_quality(model_name: str, item_id: str, model_cfg: dict | None = None) -> float:
    """The part of an item's effect that does not depend on the task."""
    p = model_params(model_name, model_cfg)
    return p["strength"] * (math.sqrt(p["g"]) * _z("global", item_id)
                            + math.sqrt(p["f"]) * _z("family", p["family"], item_id)
                            + math.sqrt(max(0.0, 1 - p["g"] - p["f"])) * _z("model", _model_key(p), item_id))


def rel_bonus(model_name: str, item_id: str, task_id: str, model_cfg: dict | None = None) -> float:
    """rel when the item's source task has the same label (ddxplus) / database (bird)."""
    p = model_params(model_name, model_cfg)
    stream = _stream_of(task_id)
    src = _source_task(str(item_id), stream)
    task = _tasks(stream).get(task_id)
    if src is None or task is None:
        return 0.0
    key = "label" if stream == "ddxplus" else "db_id"
    return p["rel"] if src.get(key) == task.get(key) else 0.0


def stored_correct(item_id: str) -> bool | None:
    """Was the item's stored answer graded correct when it was written? The write call is
    deterministic (no item, repeat 0), so it is recomputed from the id "<task id>@<writer>"."""
    task_id, sep, writer = str(item_id).partition("@")
    if not sep or not _TASK_ID_RE.fullmatch(task_id):
        return None
    try:
        return call_succeeds(writer, task_id, None, 0)
    except (KeyError, ValueError):
        return None


def correct_effect(model_name: str, item_id: str, model_cfg: dict | None = None) -> float:
    """+correct_bonus if the item's stored answer was right, -correct_bonus if wrong, else 0."""
    b = model_params(model_name, model_cfg)["correct_bonus"]
    if b == 0:
        return 0.0
    ok = stored_correct(item_id)
    return 0.0 if ok is None else (b if ok else -b)


def true_effect(model_name: str, item_id, task_id: str, model_cfg: dict | None = None) -> float:
    """The true effect (log-odds) of showing this item (or the mean over a list of items)."""
    items = _items_list(item_id)
    if not items:
        return 0.0
    vals = [item_quality(model_name, i, model_cfg) + rel_bonus(model_name, i, task_id, model_cfg)
            + correct_effect(model_name, i, model_cfg)
            for i in items]
    return sum(vals) / len(vals)


def true_success_prob(model_name: str, stream: str, task_id: str, item_id=None,
                      model_cfg: dict | None = None) -> float:
    """The true chance that this model answers this task right with this item (or items) shown."""
    p = model_params(model_name, model_cfg)
    if stream != _stream_of(task_id):
        raise ValueError(f"task {task_id!r} is not in stream {stream!r}")
    logit = (p["skill"] + p["difficulty_sd"] * _z("difficulty", task_id)
             + true_effect(model_name, item_id, task_id, model_cfg))
    return sigmoid(logit)


def call_succeeds(model_name: str, task_id: str, item_id=None, repeat: int = 0,
                  model_cfg: dict | None = None) -> bool:
    """Whether this exact call is answered right (the same every time it is asked)."""
    p = model_params(model_name, model_cfg)
    items = sorted(_items_list(item_id))
    prob = true_success_prob(model_name, _stream_of(task_id), task_id, items, model_cfg)
    return _u("call", _model_key(p), task_id, ",".join(items), repeat) < prob


def selfmark_probs(model_name: str, task_id: str, item_id, model_cfg: dict | None = None) -> dict:
    """The true chances of each self-mark word for this item (or items) on this task."""
    items = _items_list(item_id)
    noise = SELFMARK_NOISE / 3.0
    if not items:
        return {"helpful": noise, "harmful": noise, "neutral": 1 - 2 * noise}
    e = true_effect(model_name, items, task_id, model_cfg)
    if e >= 0:
        ph, pa = sigmoid(2 * e), 0.0
    else:
        ph, pa = 0.0, sigmoid(-2 * e)
    keep = 1 - SELFMARK_NOISE
    return {"helpful": keep * ph + noise, "harmful": keep * pa + noise,
            "neutral": keep * (1 - ph - pa) + noise}


def selfmark_word(model_name: str, task_id: str, item_id, repeat: int = 0,
                  model_cfg: dict | None = None) -> str:
    """helpful / harmful / neutral, drawn from selfmark_probs by hash (same call, same word)."""
    p = model_params(model_name, model_cfg)
    items = sorted(_items_list(item_id))
    key = (_model_key(p), task_id, ",".join(items), repeat)
    if _u("selfmark-noise", *key) < SELFMARK_NOISE:
        return SELFMARK_WORDS[min(2, int(_u("selfmark-random", *key) * 3))]
    if not items:
        return "neutral"
    e = true_effect(model_name, items, task_id, model_cfg)
    u = _u("selfmark", *key)
    if e >= 0:
        return "helpful" if u < sigmoid(2 * e) else "neutral"
    return "harmful" if u < sigmoid(-2 * e) else "neutral"


def rating(model_name: str, item_id: str, kind: str, scale: int = 10, repeat: int = 0,
           model_cfg: dict | None = None) -> int:
    """The simulated rating 1..scale of one stored item ("selfrate" by its writer, "judge" by a reader)."""
    p = model_params(model_name, model_cfg)
    item_id = str(item_id)
    q = item_quality(model_name, item_id, model_cfg) / max(p["strength"], 1e-9)
    x = (scale + 1) / 2.0 + RATING_SLOPE * q
    if kind == "selfrate":
        ok = stored_correct(item_id)
        if ok is not None:
            x += RATING_CORRECT if ok else -RATING_CORRECT
    elif p["correct_bonus"]:
        x += RATING_SLOPE * correct_effect(model_name, item_id, model_cfg) / max(p["strength"], 1e-9)
    x += RATING_NOISE * _z("rating", kind, _model_key(p), item_id, repeat)
    return int(min(scale, max(1, round(x))))


# --------------------------------------------------------------------------- answer text
def correct_answer(stream: str, task: dict) -> str:
    """The gold answer written so that msr.grade.grade marks it correct."""
    if stream == "ddxplus":
        from msr.data import get_label_text
        return get_label_text(int(task["label"]))          # e.g. "12. Bronchiolitis"
    gold = task["SQL"].strip()
    if gold.startswith("SELECT"):
        return gold
    # StreamBench's parse_sql puts "SELECT " in front of anything not starting with the
    # upper-case word SELECT, which breaks the 7 gold queries that start with WITH.
    # Wrapping keeps the same rows and the same column order.
    return "SELECT * FROM (\n" + gold.rstrip().rstrip(";") + "\n)"


_WRONG_SQL = ("SELECT 1", "SELECT 0", "SELECT -1")


def wrong_answer(stream: str, task: dict, salt: str = "") -> str:
    """A well-formed answer that msr.grade.grade marks wrong."""
    if stream == "ddxplus":
        from msr.data import get_label_text
        gold = int(task["label"])
        wrong = (gold + 1 + int(_u("wrong-label", task["task_id"], salt) * 48)) % 49
        return get_label_text(wrong)                         # a different label, 0-48
    # "SELECT 1", unless the gold result happens to be exactly that one row.
    from msr.grade import KNOWN_SLOW_GOLD, gold_result
    if task.get("task_id") in KNOWN_SLOW_GOLD:
        return _WRONG_SQL[0]                                 # always graded wrong anyway
    g = gold_result(task)                                    # cached; grading needs it too
    gold_set = g.get("set")
    if not gold_set:
        return _WRONG_SQL[0]                                 # gold failed or empty: always wrong
    for sql in _WRONG_SQL:
        value = int(sql.split()[1])
        if gold_set != {(value,)}:
            return sql
    return _WRONG_SQL[0]  # unreachable: a set cannot equal three different one-row sets


# --------------------------------------------------------------------------- the call
def _meta_items(meta: dict) -> list[str]:
    items = meta.get("items")
    if items:
        return _items_list(items)
    return _items_list(meta.get("item_id"))


def sim_call(model_name: str, model_cfg: dict, user: str, system: str | None,
             repeat: int, meta: dict | None) -> tuple[str, int, int, str, str]:
    """Answer one call like a model would: (text, tokens_in, tokens_out, model_id, stop_reason).

    meta needs task_id (and stream, else it is read from the task id); item_id or items
    when memory items are shown; stage == "selfmark" for a self-marking call.
    """
    meta = meta or {}
    task_id = meta.get("task_id")
    if task_id is None:
        raise ValueError(f"simulated model {model_name!r} needs meta['task_id'] "
                         "(and meta['stream']) to know which task it is answering")
    task_id = str(task_id)
    stream = meta.get("stream") or _stream_of(task_id)
    p = model_params(model_name, model_cfg)
    items = _meta_items(meta)
    repeat = int(repeat or 0)

    if meta.get("stage") in ("selfmark", "relearn_tag"):
        text = selfmark_word(model_name, task_id, items, repeat, model_cfg)
    elif meta.get("stage") in ("selfrate", "judge"):
        if not items:
            raise ValueError(f"simulated {meta['stage']} call needs meta['item_id']")
        text = str(rating(model_name, items[0], meta["stage"], int(meta.get("scale") or 10), repeat, model_cfg))
    else:
        task = _tasks(stream).get(task_id)
        if task is None:
            raise KeyError(f"task {task_id!r} is not in stream {stream!r}")
        if call_succeeds(model_name, task_id, items, repeat, model_cfg):
            text = correct_answer(stream, task)
        else:
            salt = f"{_model_key(p)}|{','.join(sorted(items))}|{repeat}"
            text = wrong_answer(stream, task, salt)

    prompt_text = (system or "") + (user or "")
    model_id = f"{p['api_model']}/{SIM_VERSION}"
    return text, len(prompt_text) // 4, len(text) // 4, model_id, "end_turn"
