"""Turn task text into vectors, with one fixed, free, local embedding model.

Everyday picture: a librarian who files every past case by "what it is about".
To find similar cases for a new patient, the librarian compares the new case's
card with the cards already filed. The embedding model writes those cards (a list
of 768 numbers per text). It must be the SAME librarian for every chat model in
the study, otherwise a change of model would also change what gets retrieved.

Choices, and why:
- Model: ``BAAI/bge-base-en-v1.5``. StreamBench (commit cf72f26) uses exactly this
  model for every memory agent (configs/agent/*.yml -> rag.embedding_model), with
  CLS pooling, L2 normalisation, truncation at 512 tokens and no query prefix
  (stream_bench/agents/utils.py, class RAG). We copy all of that.
- Weights: the official fp32 ONNX file that BAAI publishes in the model's own repo
  (onnx/model.onnx), pinned to one revision. fastembed's built-in entry for this
  model points at a quantized copy (Qdrant/bge-base-en-v1.5-onnx-Q), which would not
  be the same model StreamBench ran, so we register the official file ourselves.
- Runner: the ``fastembed`` package (ONNX Runtime on the CPU; no torch, works on
  Windows). If fastembed cannot load, we fall back to sentence-transformers and say
  so in the cache's sidecar file.
- No key and no money: everything runs on this machine. The model files (about
  440 MB) are downloaded once into data/models/.

What is embedded: the task's ``question`` field from msr.data, which is exactly the
text StreamBench embeds (ddxplus: PATIENT_PROFILE.strip(); bird: the question).

Tests use ``model="hash"``: a tiny hashed bag-of-words embedder that needs no download.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
EMBED_DIR = ROOT / "data" / "embeddings"     # cached vectors, one folder per model
MODEL_DIR = ROOT / "data" / "models"         # downloaded model files

DEFAULT_MODEL = "BAAI/bge-base-en-v1.5"
HASH_MODEL = "hash"
HASH_DIM = 512

# Models we pin to an exact file, so the vectors are the same on every machine.
# revision = the commit of the Hugging Face repo, read on 2026-11-23.
PINNED = {
    "BAAI/bge-base-en-v1.5": {
        "repo": "BAAI/bge-base-en-v1.5",
        "revision": "a5beb1e3e68b9ab74eb54cfd186867f64f240e1a",
        "model_file": "onnx/model.onnx",
        # sha256 of onnx/model.onnx as the hub lists it (checked after download)
        "model_file_sha256": "9bc579acdba21c253c62a9bf866891355a63ffa3442b52c8a37d75b2ccb91848",
        "dim": 768,
        "pooling": "CLS",
        "normalize": True,
        "max_tokens": 512,
    },
}
# The files the ONNX runner needs (no PyTorch weights).
_NEEDED_FILES = ("config.json", "tokenizer.json", "tokenizer_config.json",
                 "special_tokens_map.json")


# --------------------------------------------------------------------------- small helpers
def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _normalise_rows(a: np.ndarray) -> np.ndarray:
    """Scale every row to length 1 (an all-zero row stays all zero)."""
    a = np.asarray(a, dtype=np.float32)
    if a.ndim == 1:
        a = a[None, :]
    norms = np.linalg.norm(a.astype(np.float64), axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    return (a / norms).astype(np.float32)


def model_slug(model: str) -> str:
    """A folder-safe name for a model: 'BAAI/bge-base-en-v1.5' -> 'BAAI__bge-base-en-v1.5'."""
    return re.sub(r"[^A-Za-z0-9._-]+", "_", model.replace("/", "__"))


def texts_sha256(ids: list[str], texts: list[str]) -> str:
    """Fingerprint of exactly which texts, under which ids, were embedded (and in what order)."""
    payload = json.dumps([[i, t] for i, t in zip(ids, texts)], ensure_ascii=False)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


# --------------------------------------------------------------------------- hash embedder
class HashEmbedder:
    """A deterministic, download-free stand-in: hashed bag of words.

    Each lower-cased word is hashed (sha1, never Python's hash(), which changes
    between runs) to one of `dim` slots and a sign; counts are damped with log(1+n)
    and the row is scaled to length 1. Texts that share words get similar vectors,
    which is all the tests need.
    """

    name = HASH_MODEL

    def __init__(self, dim: int = HASH_DIM):
        self.dim = dim

    def _slot(self, word: str) -> tuple[int, float]:
        d = hashlib.sha1(word.encode("utf-8")).digest()
        idx = int.from_bytes(d[:8], "big") % self.dim
        sign = 1.0 if d[8] & 1 else -1.0
        return idx, sign

    def embed(self, texts: list[str]) -> np.ndarray:
        out = np.zeros((len(texts), self.dim), dtype=np.float64)
        for row, text in enumerate(texts):
            counts: dict[str, int] = {}
            for w in re.findall(r"\w+", (text or "").lower()):
                counts[w] = counts.get(w, 0) + 1
            for w, n in counts.items():
                idx, sign = self._slot(w)
                out[row, idx] += sign * math.log1p(n)
        return _normalise_rows(out)

    def info(self) -> dict:
        return {"model": HASH_MODEL, "backend": "HashEmbedder (sha1 hashed bag of words)",
                "revision": None, "dim": self.dim}


# --------------------------------------------------------------------------- real embedders
def _pinned_model_dir(spec: dict) -> Path:
    return MODEL_DIR / model_slug(spec["repo"]) / spec["revision"]


def download_pinned(model: str = DEFAULT_MODEL) -> Path:
    """Download the pinned model files once (about 440 MB for bge-base); return their folder."""
    spec = PINNED[model]
    folder = _pinned_model_dir(spec)
    wanted = [spec["model_file"], *_NEEDED_FILES]
    if all((folder / f).is_file() for f in wanted):
        return folder
    from huggingface_hub import snapshot_download
    folder.mkdir(parents=True, exist_ok=True)
    snapshot_download(spec["repo"], revision=spec["revision"], allow_patterns=wanted,
                      local_dir=str(folder))
    missing = [f for f in wanted if not (folder / f).is_file()]
    if missing:
        raise RuntimeError(f"download of {spec['repo']}@{spec['revision']} is missing {missing}")
    return folder


class _FastEmbedder:
    """fastembed (ONNX Runtime, CPU) running either our pinned file or fastembed's own entry."""

    def __init__(self, model: str):
        import fastembed
        from fastembed import TextEmbedding
        self.model = model
        self.spec = PINNED.get(model)
        self.extra: dict = {"fastembed_version": getattr(fastembed, "__version__", None)}
        try:
            import onnxruntime
            self.extra["onnxruntime_version"] = onnxruntime.__version__
        except Exception:
            pass
        if self.spec is None:
            # Any model fastembed knows by name (fastembed picks the files and may quantize).
            self._te = TextEmbedding(model_name=model, cache_dir=str(MODEL_DIR / "fastembed"))
            self.dim = int(self._te.embedding_size) if hasattr(self._te, "embedding_size") else None
            self.revision = None
            self.extra["source"] = "fastembed built-in entry"
            return
        from fastembed.common.model_description import ModelSource, PoolingType
        folder = download_pinned(model)
        sha = _cached_file_sha(folder / self.spec["model_file"])
        if self.spec.get("model_file_sha256") and sha != self.spec["model_file_sha256"]:
            raise RuntimeError(f"{folder / self.spec['model_file']} has sha256 {sha}, expected "
                               f"{self.spec['model_file_sha256']}; delete the folder and re-run")
        # Register the official file under our own name (fastembed's name for this model
        # already points at a quantized copy, and names cannot be registered twice).
        local_name = "msr/" + model_slug(model) + "@" + self.spec["revision"][:12]
        try:
            TextEmbedding.add_custom_model(
                model=local_name,
                pooling=PoolingType.CLS if self.spec["pooling"] == "CLS" else PoolingType.MEAN,
                normalization=self.spec["normalize"],
                sources=ModelSource(hf=self.spec["repo"]),
                dim=self.spec["dim"],
                model_file=self.spec["model_file"],
            )
        except ValueError as e:      # already registered earlier in this process: fine
            if "already registered" not in str(e):
                raise
        self._te = TextEmbedding(model_name=local_name, specific_model_path=str(folder))
        self.dim = self.spec["dim"]
        self.revision = self.spec["revision"]
        self.extra.update({
            "source": f"https://huggingface.co/{self.spec['repo']} @ {self.spec['revision']}",
            "model_file": self.spec["model_file"],
            "model_file_sha256": sha,
            "pooling": self.spec["pooling"], "normalized": self.spec["normalize"],
            "max_tokens": self.spec["max_tokens"], "query_prefix": None,
        })

    def embed(self, texts: list[str]) -> np.ndarray:
        if not texts:
            return np.zeros((0, self.dim or 0), dtype=np.float32)
        # Embed in order of length, so each batch is padded to a similar length
        # (about 17 % faster on ddxplus; the vectors are the same), then restore the order.
        texts = list(texts)
        order = sorted(range(len(texts)), key=lambda i: (len(texts[i]), i))
        vecs = np.vstack(list(self._te.embed([texts[i] for i in order], batch_size=32)))
        out = np.empty_like(vecs)
        out[order] = vecs
        return _normalise_rows(out)

    def info(self) -> dict:
        return {"model": self.model, "backend": "fastembed", "revision": self.revision,
                "dim": self.dim, **self.extra}


class _SentenceTransformerEmbedder:
    """Fallback when fastembed is unavailable: sentence-transformers (needs torch)."""

    def __init__(self, model: str):
        from sentence_transformers import SentenceTransformer
        spec = PINNED.get(model, {})
        self.model = model
        self.revision = spec.get("revision")
        self._st = SentenceTransformer(model, revision=self.revision, device="cpu")
        self.dim = int(self._st.get_sentence_embedding_dimension())

    def embed(self, texts: list[str]) -> np.ndarray:
        if not texts:
            return np.zeros((0, self.dim), dtype=np.float32)
        vecs = self._st.encode(list(texts), batch_size=32, normalize_embeddings=True,
                               convert_to_numpy=True, show_progress_bar=False)
        return _normalise_rows(vecs)

    def info(self) -> dict:
        import sentence_transformers
        return {"model": self.model, "backend": "sentence-transformers (fallback)",
                "sentence_transformers_version": sentence_transformers.__version__,
                "revision": self.revision, "dim": self.dim}


def _cached_file_sha(path: Path) -> str:
    """sha256 of a big model file, remembered in a small side file so it is hashed only once."""
    side = path.with_name(path.name + ".sha256.json")
    stat = path.stat()
    if side.exists():
        try:
            d = json.loads(side.read_text(encoding="utf-8"))
            if d.get("size") == stat.st_size and d.get("mtime") == int(stat.st_mtime):
                return d["sha256"]
        except Exception:
            pass
    sha = _file_sha256(path)
    try:
        side.write_text(json.dumps({"sha256": sha, "size": stat.st_size,
                                    "mtime": int(stat.st_mtime)}), encoding="utf-8")
    except OSError:
        pass
    return sha


_EMBEDDERS: dict[str, object] = {}
_LOCK = threading.Lock()


def get_embedder(model: str = DEFAULT_MODEL):
    """Load an embedder once per process: 'hash' -> HashEmbedder, else fastembed, else
    sentence-transformers. Raises RuntimeError if neither can serve the model."""
    with _LOCK:
        if model in _EMBEDDERS:
            return _EMBEDDERS[model]
        if model == HASH_MODEL:
            emb = HashEmbedder()
        else:
            errors = []
            emb = None
            try:
                emb = _FastEmbedder(model)
            except Exception as e:   # not installed, model unknown, download failed, ...
                errors.append(f"fastembed: {type(e).__name__}: {e}")
            if emb is None:
                try:
                    emb = _SentenceTransformerEmbedder(model)
                    print(f"[msr.embed] fastembed could not serve {model}; using "
                          f"sentence-transformers instead ({errors[0]})")
                except Exception as e:
                    errors.append(f"sentence-transformers: {type(e).__name__}: {e}")
                    raise RuntimeError(f"no embedding backend could load {model!r}: "
                                       + " | ".join(errors)) from e
        _EMBEDDERS[model] = emb
        return emb


# --------------------------------------------------------------------------- public API
def embed_texts(texts: list[str], model: str = DEFAULT_MODEL) -> np.ndarray:
    """Vectors for `texts`, one row each, float32, every row scaled to length 1."""
    return get_embedder(model).embed(list(texts))


def cache_paths(stream: str, model: str = DEFAULT_MODEL,
                cache_dir: Path | None = None) -> tuple[Path, Path]:
    """(vectors .npz, sidecar .json) for one stream and model."""
    folder = Path(cache_dir) if cache_dir else EMBED_DIR / model_slug(model)
    return folder / f"{stream}.npz", folder / f"{stream}.json"


def _stream_texts(stream: str) -> tuple[list[str], list[str]]:
    """(task ids, texts to embed) in the stream file's row order."""
    from msr.data import load_stream
    tasks = load_stream(stream)
    # msr.data 'question' = the text StreamBench embeds: ddxplus PATIENT_PROFILE.strip(),
    # bird row['question'] (FewShotRAGAgent.update -> rag.insert(key=question)).
    return [t["task_id"] for t in tasks], [t["question"] for t in tasks]


def embed_stream(stream: str, model: str = DEFAULT_MODEL, *, cache: bool = True,
                 cache_dir: Path | None = None) -> dict[str, np.ndarray]:
    """task_id -> vector for every task of `stream`, cached on disk.

    Cache: data/embeddings/<model-slug>/<stream>.npz plus a sidecar .json with the model
    name, revision, dimension, date and the sha256 of the ids + texts. A cache is reused
    only when that sha256 and the model match; otherwise it is rebuilt.
    """
    ids, texts = _stream_texts(stream)
    sha = texts_sha256(ids, texts)
    npz_path, json_path = cache_paths(stream, model, cache_dir)
    expected_rev = PINNED.get(model, {}).get("revision")

    if cache and npz_path.exists() and json_path.exists():
        try:
            side = json.loads(json_path.read_text(encoding="utf-8"))
            ok = (side.get("texts_sha256") == sha and side.get("model") == model
                  and (expected_rev is None or side.get("revision") == expected_rev))
            if ok:
                with np.load(npz_path, allow_pickle=False) as z:
                    cached_ids = [str(x) for x in z["ids"]]
                    vecs = np.asarray(z["vectors"], dtype=np.float32)
                if cached_ids == ids and vecs.shape[0] == len(ids):
                    return {i: vecs[n] for n, i in enumerate(ids)}
        except Exception:
            pass  # unreadable cache: rebuild it below

    emb = get_embedder(model)
    t0 = time.time()
    vecs = emb.embed(texts)
    seconds = time.time() - t0

    if cache:
        npz_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = npz_path.with_name(npz_path.stem + ".part.npz")   # np.savez keeps a .npz ending
        np.savez(tmp, ids=np.array(ids), vectors=vecs)
        tmp.replace(npz_path)
        side = {**emb.info(), "model": model, "stream": stream, "n": len(ids),
                "dim": int(vecs.shape[1]), "dtype": "float32", "rows_normalised": True,
                "text_field": "question (ddxplus: PATIENT_PROFILE.strip(); bird: question)",
                "texts_sha256": sha, "created_at": _now(), "seconds": round(seconds, 2)}
        if side.get("revision") is None:
            side["revision"] = expected_rev
        json_path.write_text(json.dumps(side, indent=2), encoding="utf-8")
    return {i: vecs[n] for n, i in enumerate(ids)}


if __name__ == "__main__":
    # Build (or check) the cache for both streams:  python -m msr.embed [model]
    import sys
    from msr.data import STREAMS
    name = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_MODEL
    for s in STREAMS:
        t = time.time()
        vec = embed_stream(s, name)
        npz, side = cache_paths(s, name)
        print(f"{s:8s} {len(vec)} vectors, dim {len(next(iter(vec.values())))}, "
              f"{time.time() - t:.1f} s, cache {npz.stat().st_size / 1e6:.1f} MB -> "
              f"{npz.relative_to(ROOT).as_posix()}")
