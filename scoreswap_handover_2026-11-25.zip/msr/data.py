"""The two task streams and their fixed splits.

Streams come from StreamBench (Hugging Face `appier-ai-research/StreamBench`,
test split, pinned revision; see scripts/get_data.py and data/MANIFEST.json):

* ``ddxplus`` - 1764 patient profiles, answer = one of 49 diagnoses.
  task_id = ``ddxplus-<row>`` (row number in the pinned parquet, 0000-1763;
  the file has no id column, and its sha256 is pinned, so the row is stable).
* ``bird``    - 1534 text-to-SQL questions on 11 SQLite databases.
  task_id = ``bird-<question_id>`` (question_id is unique, 0000-1533).

Every task dict keeps the original columns and adds:
``task_id``, ``stream``, ``row``, ``question`` (the text StreamBench shows as the
question) and ``answer`` (the gold answer written the way a memory item shows it).
ddxplus tasks also get ``label`` (int 0-48); bird tasks get ``db_path``.

Splits: one shuffled order per (stream, seed) made with ``random.Random(seed)``
on the sorted task ids, cut into build / probe / test with no task in two parts.
Saved as JSON in ``data/splits/<stream>_seed<k>.json``.
"""
from __future__ import annotations

import hashlib
import json
import random
from functools import lru_cache
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = REPO_ROOT / "data"
STREAM_DIR = DATA_DIR / "streambench"
SPLIT_DIR = DATA_DIR / "splits"
BIRD_DB_DIR = DATA_DIR / "bird" / "dev_databases"

STREAMS = ("ddxplus", "bird")
EXPECTED_ROWS = {"ddxplus": 1764, "bird": 1534}
DEFAULT_SEEDS = (0, 1, 2)
DEFAULT_SIZES = {"n_build": 600, "n_probe": 200, "n_test": 300}

# StreamBench stream_bench/benchmarks/ddxplus.py (commit cf72f26), DDXPlusBench.LABEL2TEXT
LABEL2TEXT = {
    0: 'Acute COPD exacerbation / infection', 1: 'Acute dystonic reactions',
    2: 'Acute laryngitis', 3: 'Acute otitis media', 4: 'Acute pulmonary edema',
    5: 'Acute rhinosinusitis', 6: 'Allergic sinusitis', 7: 'Anaphylaxis', 8: 'Anemia',
    9: 'Atrial fibrillation', 10: 'Boerhaave', 11: 'Bronchiectasis', 12: 'Bronchiolitis',
    13: 'Bronchitis', 14: 'Bronchospasm / acute asthma exacerbation', 15: 'Chagas',
    16: 'Chronic rhinosinusitis', 17: 'Cluster headache', 18: 'Croup', 19: 'Ebola',
    20: 'Epiglottitis', 21: 'GERD', 22: 'Guillain-Barré syndrome',
    23: 'HIV (initial infection)', 24: 'Influenza', 25: 'Inguinal hernia',
    26: 'Larygospasm', 27: 'Localized edema', 28: 'Myasthenia gravis', 29: 'Myocarditis',
    30: 'PSVT', 31: 'Pancreatic neoplasm', 32: 'Panic attack', 33: 'Pericarditis',
    34: 'Pneumonia', 35: 'Possible NSTEMI / STEMI', 36: 'Pulmonary embolism',
    37: 'Pulmonary neoplasm', 38: 'SLE', 39: 'Sarcoidosis', 40: 'Scombroid food poisoning',
    41: 'Spontaneous pneumothorax', 42: 'Spontaneous rib fracture', 43: 'Stable angina',
    44: 'Tuberculosis', 45: 'URTI', 46: 'Unstable angina', 47: 'Viral pharyngitis',
    48: 'Whooping cough',
}
NOTINLABEL = len(LABEL2TEXT)  # 49: StreamBench's "no valid label" prediction
TEXT2LABEL = {v.lower(): k for k, v in LABEL2TEXT.items()}


def get_label_text(label: int | str) -> str:
    """StreamBench MedicalDiagnosisBench.get_label_text: '<number>. <diagnosis>'."""
    label_int = NOTINLABEL
    label_str = "I'm not confident about the diagnosis."
    if isinstance(label, int) and (label in LABEL2TEXT):
        label_int = label
        label_str = LABEL2TEXT[label_int]
    elif isinstance(label, str) and (label.lower() in TEXT2LABEL):
        label_int = TEXT2LABEL[label.lower()]
        label_str = label
    return f"{label_int}. {label_str}"


def bird_db_path(db_id: str) -> Path:
    return BIRD_DB_DIR / db_id / f"{db_id}.sqlite"


def stream_file(name: str) -> Path:
    _check_name(name)
    return STREAM_DIR / f"{name}.parquet"


def _check_name(name: str) -> None:
    if name not in STREAMS:
        raise ValueError(f"unknown stream {name!r}; expected one of {STREAMS}")


@lru_cache(maxsize=None)
def _load(name: str) -> tuple[dict, ...]:
    path = stream_file(name)
    if not path.exists():
        raise FileNotFoundError(f"{path} is missing; run  python scripts/get_data.py")
    import pyarrow.parquet as pq
    rows = pq.read_table(path).to_pylist()
    if len(rows) != EXPECTED_ROWS[name]:
        raise ValueError(f"{path}: {len(rows)} rows, expected {EXPECTED_ROWS[name]}")
    tasks = []
    for i, r in enumerate(rows):
        t = dict(r)
        t["stream"] = name
        t["row"] = i
        if name == "ddxplus":
            t["task_id"] = f"ddxplus-{i:04d}"
            # StreamBench get_input: question = PATIENT_PROFILE.strip()
            t["question"] = r["PATIENT_PROFILE"].strip()
            # StreamBench get_output: TEXT2LABEL[PATHOLOGY.lower().strip()]
            t["label"] = TEXT2LABEL[r["PATHOLOGY"].lower().strip()]
            t["answer"] = get_label_text(r["PATHOLOGY"])
        else:
            t["task_id"] = f"bird-{int(r['question_id']):04d}"
            t["question"] = r["question"]
            t["answer"] = r["SQL"]
            t["db_path"] = str(bird_db_path(r["db_id"]))
        tasks.append(t)
    ids = [t["task_id"] for t in tasks]
    if len(set(ids)) != len(ids):
        raise ValueError(f"{name}: task ids are not unique")
    return tuple(tasks)


def load_stream(name: str) -> list[dict]:
    """All tasks of one stream, in the file's row order. Each call returns fresh dicts."""
    return [dict(t) for t in _load(name)]


def task_index(name: str) -> dict[str, dict]:
    """task_id -> task (fresh dicts)."""
    return {t["task_id"]: dict(t) for t in _load(name)}


def get_task(name: str, task_id: str) -> dict:
    for t in _load(name):
        if t["task_id"] == task_id:
            return dict(t)
    raise KeyError(task_id)


def task_ids(name: str) -> list[str]:
    return sorted(t["task_id"] for t in _load(name))


def make_order(name: str, seed: int) -> list[str]:
    """A seeded shuffle of the sorted task ids (same on every machine and Python >= 3.2)."""
    ids = task_ids(name)
    random.Random(seed).shuffle(ids)
    return ids


def make_splits(name: str, seed: int, n_build: int = 600, n_probe: int = 200,
                n_test: int = 300) -> dict:
    """Cut make_order(name, seed) into build | probe | test (in stream order, disjoint).

    The build list is in the order the tasks are met during the build phase.
    Tasks after n_build + n_probe + n_test are listed under "unused".
    """
    order = make_order(name, seed)
    total = n_build + n_probe + n_test
    if min(n_build, n_probe, n_test) < 0 or total > len(order):
        raise ValueError(f"{name}: sizes {n_build}+{n_probe}+{n_test} do not fit {len(order)} tasks")
    a, b = n_build, n_build + n_probe
    return {
        "stream": name,
        "seed": seed,
        "sizes": {"n_build": n_build, "n_probe": n_probe, "n_test": n_test},
        "method": "random.Random(seed).shuffle(sorted(task_ids)); build=[:n_build], "
                  "probe=next n_probe, test=next n_test",
        "source_sha256": _file_sha256(stream_file(name)),
        "build": order[:a],
        "probe": order[a:b],
        "test": order[b:total],
        "unused": order[total:],
    }


def split_path(name: str, seed: int) -> Path:
    _check_name(name)
    return SPLIT_DIR / f"{name}_seed{seed}.json"


def save_splits(splits: dict, path: Path | None = None) -> Path:
    path = Path(path) if path else split_path(splits["stream"], splits["seed"])
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".part")
    tmp.write_text(json.dumps(splits, indent=1), encoding="utf-8")
    tmp.replace(path)
    return path


def load_splits(name: str, seed: int, path: Path | None = None) -> dict:
    path = Path(path) if path else split_path(name, seed)
    return json.loads(path.read_text(encoding="utf-8"))


def get_splits(name: str, seed: int, n_build: int = 600, n_probe: int = 200,
               n_test: int = 300, save: bool = True) -> dict:
    """Load the saved split if it exists (checking it equals a fresh one), else make and save it."""
    fresh = make_splits(name, seed, n_build, n_probe, n_test)
    path = split_path(name, seed)
    if path.exists():
        saved = load_splits(name, seed)
        if any(saved.get(k) != fresh[k] for k in ("build", "probe", "test", "sizes")):
            raise ValueError(f"{path} differs from a freshly made split with these sizes; "
                             "delete it or pass the sizes it was made with")
        return saved
    if save:
        save_splits(fresh)
    return fresh


def write_default_splits(seeds=DEFAULT_SEEDS, **sizes) -> list[Path]:
    """Make and save the split files for both streams and the default seeds."""
    out = []
    for name in STREAMS:
        for s in seeds:
            get_splits(name, s, **{**DEFAULT_SIZES, **sizes})
            out.append(split_path(name, s))
    return out


def _file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


if __name__ == "__main__":
    for p in write_default_splits():
        sp = json.loads(p.read_text(encoding="utf-8"))
        print(p.relative_to(REPO_ROOT).as_posix(),
              {k: len(sp[k]) for k in ("build", "probe", "test", "unused")})
