"""The keep-or-drop decision on swap day: error-controlled, stop-when-sure checks (addition 2).

Everyday picture: the garage gets a new helper. The old tip scores say which parts usually fix which
fault. The foreman's FIRST question is the cheap one: "are the old tips still better than no tips at
all?" He hands the new helper one test job at a time, tries the parts in the old tips' order, and keeps
a running bet that the order beats a random order. When the bet has paid 20 to 1 he KEEPS the tips; when
the opposite bet has paid 20 to 1 he WIPES them; the bet is fair, so a wrong call happens at most 5 % of
the time however long he plays and whenever he stops. He needs nothing from the old helper for this.
His SECOND question is the hard one: "did the tips lose at most a quarter of their value?" For that he
must also have, for every test job, how well the tips worked for the OLD helper on that very job (the
logbook entry, written before the old helper left), he may use each entry once, and he may only ask the
question when the logbook shows the tips worked for the old helper at all.

What is new is what is tested; the statistics are classical:
- the per-task statistic is a within-task Somers-type agreement (Kendall 1945; Newson 2006) between the
  old scores and outcomes, scaled to [-1, 1];
- the tests are test martingales by betting (Waudby-Smith and Ramdas 2024, JRSS-B; Ville's inequality).
  The bet is the registered mixture: an equal average of the constant bets eta_d = d/40 (d = 1..20) on
  the [0, 1] scale, boundary 1/2 (a mixture of test martingales is a test martingale); predictable
  plug-in and aGRAPA bets are sensitivity checks;
- the gate is an intersection-union rule (Berger 1982);
- the information lower bound is Wald's (1945) inequality in the form of Kaufmann, Cappe and Garivier
  (2016, JMLR, Lemma 1), which also holds for adaptive sampling; K_inf is Honda and Takemura (2010).

Budgets are counted in fresh-check TASKS; the ranking statistic costs one reader check per candidate (4
checks with the study's 4 candidates); the first-shown statistic 2 checks on a task where keep and wipe
show different items, 0 otherwise. The unit of evidence is one task, never one item pair.

The per-task statistic. For task tau with candidates K(tau) (n of them usable):
    A(tau) = sum_{i<j in K(tau)} sign(x_i - x_j) * (y_i - y_j) / M_n,   M_n = floor(n/2) * ceil(n/2)
           = sum_i c_i(tau) y_i,   c_i(tau) = sum_{j != i} sign(x_i - x_j) / M_n,
x = the owner's old score, y = an outcome (0/1, or the mean of repeats). A lies in [-1, 1]; it is linear
in y, so E[A | tau] = sum_i c_i mu_i. A_s(tau): the reader's single fresh check per candidate; A_h(tau):
the owner's home result on the SAME task (mean of home repeats 1-2). Abar_swap = E_tau[A_s], Abar_home =
E_tau[A_h]; theta = Abar_swap / Abar_home. Which theta: every test here treats the bank (scores, items,
candidate lists) as FIXED and the tasks as i.i.d. draws from the stream given the bank, so its target is
the fixed-bank value theta_bank (and Abar_swap of the bank), not the item-population theta_pop (R6 W9).

=========================================================================================================
PRIMARY QUESTION (margin 0, the operator's break-even): "is keeping the old scores still better than
wiping them?" Two versions; neither needs a home value, a home result or a sign condition, so both work
after the old model has retired.

(a) Ranking version ("margin0_ranking"). KEEP test H0: E[A_s] <= 0 (the old order is no better than a
random order of the task's candidates; E[A] = 0 is exactly the value of the old scores permuted at
random within the task); WIPE test H0: E[A_s] >= 0. xi_t = (A_s(tau_t) + 1)/2 in [0, 1], boundary 1/2.
KEEP when W+_t = (1/20) sum_d prod_{u<=t} (1 + eta_d (xi_u - 1/2)) reaches 1/alpha; WIPE when the mirror
wealth (1 - xi_u in place of xi_u) does; both at the same task: WIPE; neither by the cap: undecided.
Proposition M0-R. Conditions: (i) the bank is fixed and tau_1, tau_2, ... are i.i.d. draws from the
stream's task distribution given the bank, drawn at random by the harness from a fixed held-out pool (not
chosen or ordered by the operator: live traffic in arrival order or checks in topic order break it); (ii) on each drawn task the reader is checked once per
candidate with fresh calls, independently across tasks; (iii) the statistic is bounded (A in [-1, 1]);
(iv) the stopping time may depend on anything observed so far. Then P(KEEP at any stopping time) <= alpha
whenever E[A_s] <= 0, and P(WIPE) <= alpha whenever E[A_s] >= 0.
Proof sketch. By (i)-(ii) the xi_t are i.i.d., so E[xi_t | F_{t-1}] = 1/2 + E[A_s]/2 <= 1/2 under H0.
Every factor 1 + eta_d (xi_t - 1/2) is >= 3/4 > 0 (eta_d <= 1/2, |xi - 1/2| <= 1/2) with conditional mean
<= 1, so each product is a nonnegative supermartingale with value 1 at t = 0, and so is their average;
Ville's inequality gives P(sup_t W+_t >= 1/alpha) <= alpha. WIPE is the mirror. []

(b) First-shown version ("margin0_first_shown"), the operator's own loss. On task tau, k(tau) = the
candidate keep shows first (msr.engine.first_shown: mix w_score * u + (1 - w_score) * relevance with the
old normalised scores u, ties to the higher relevance, then to the candidate listed first) and w(tau) =
the candidate wipe shows first (msr.arms.wipe resets every score to its start value, so the mix is
relevance only). Both depend on the bank and the task, never on an outcome. If k != w, the reader is
checked once on each, d = y_k - y_w in {-1, 0, 1}; if k = w, d = 0 with no check. E[d] = the reader's
first-shown success under keep minus under wipe. KEEP test H0: E[d] <= 0; WIPE test H0: E[d] >= 0; the
same mixture bet on xi = (d + 1)/2. Checks used = 2 x (tasks where the arms differ).
Proposition M0-F. Under (i), (ii') fresh reader checks of k(tau) and w(tau), independent across tasks,
(iii) d in [-1, 1] and (iv): P(KEEP) <= alpha whenever E[d] <= 0 and P(WIPE) <= alpha whenever E[d] >= 0.
Proof: as M0-R; d_t is i.i.d. and bounded, and a task with d = 0 multiplies every bet by 1. []

=========================================================================================================
THE HARD CASE (rule "sequential"): "did the old scores lose at most a quarter of their value?"
- KEEP test, H0: E[D_k] <= 0 with D_k = A_s - RHO_KEEP * A_h (RHO_KEEP = 0.75);
- DROP test, H0: E[D_d] >= 0 with D_d = A_s - RHO_DROP * A_h (RHO_DROP = 0.25);
- each D = A_s - c A_h lies in [-(1+c), 1+c] and is mapped to xi = (D + 1 + c) / (2 + 2c), boundary 1/2,
  the same mixture bet; both at the same task: DROP; neither by the cap: undecided;
- the decision is the INTERSECTION-UNION rule: KEEP (or DROP) only if the paired test rejects AND the
  single home-signal flag (msr.metrics, the owner's CALIBRATION tasks, z >= 2) is positive; otherwise the
  decision is "not testable: home signal not shown positive" (never KEEP);
- the paired rule takes the number S of distinct stored home results and STOPS with the status "home
  table exhausted" when the stream would reuse one (home results are never drawn with replacement).
Proposition 1 (revision 3: the gate covers BOTH decisions, as the code always did; review R7 W6).
Conditions: (i) as above (tasks i.i.d. given the bank, drawn AT RANDOM BY THE HARNESS from a fixed
held-out pool: not chosen or ordered by the operator); (ii) one fresh reader check per candidate,
independent across tasks; (iii) bounded D; (iv) EVERY drawn task has its OWN home result (the owner's
results on that task, never reused): with a store of S tasks the stream visits them in a random order
without replacement and stops at S (a random order of i.i.d. draws is i.i.d., so the pairs
(A_s, A_h)(tau_t), t <= S, are i.i.d.); (v) the flag is computed on the owner's calibration tasks, which
are disjoint from the stream and drawn from the same task distribution. Let alpha_flag be the flag's size
at Abar_home = 0 (asymptotically 1 - Phi(2) = 0.023; measured 0.015-0.032 with 100 and 24 calibration
tasks). Then, at any stopping time:
  if Abar_home > 0:  P(KEEP) <= alpha whenever theta <= 0.75, and P(DROP) <= alpha whenever theta >= 0.25;
  if Abar_home <= 0: P(KEEP or DROP) <= alpha_flag (both decisions need the flag);
so a KEEP is wrong with probability at most max(alpha, alpha_flag) whenever theta <= 0.75 or
Abar_home <= 0, and a DROP likewise whenever theta >= 0.25 or Abar_home <= 0.
Proof sketch. H0_keep = {Abar_home <= 0} U {Abar_home > 0 and theta <= 0.75}. On the second part E[D_k] =
Abar_swap - 0.75 Abar_home <= 0, so the paired KEEP test fires with probability <= alpha (Ville, as
above; any dependence between A_s and A_h within a task is allowed). On the first part KEEP needs the
flag, a one-sided z >= 2 test of Abar_home > 0, whose size is about 0.023 < alpha (asymptotic; the
calibration z of msr.metrics). The decision is the intersection of the two events, so its size is at
most the larger of the two levels (Berger 1982); no split of alpha is needed. DROP is the mirror: on
{Abar_home > 0} theta >= 0.25 is E[D_d] >= 0, so the paired DROP test fires with probability <= alpha;
on {Abar_home <= 0} DROP needs the flag exactly as KEEP does. [] The gate on DROP is not optional: with a
reversed home order and theta = 1 (A_swap = A_home = -0.12), E[D_d] = 0.75 A_home < 0 and the ungated
DROP test drops in 1.000 of 1,000 streams (review R7, W6; sequential_gate.csv part
'drop_counter_example'). "Not testable" means the old scores showed no positive signal even for the old
model, so the 0.75 question has no meaning for this bank: the operator answers the break-even question
instead (keep or wipe, decide_margin0, no old-model call; NOT_TESTABLE_ACTION).
Without (iv) the guarantee fails: re-using a 300-task store with replacement gives false keeps of 0.13
by 3,000 tasks and 0.20 by 6,000 at theta = 0.75 exactly (R6 C5d; sequential_store.csv); without the gate
a negative home signal (Abar_home = -0.10, theta = 0.02) keeps in 0.999 of streams (R6 C5c;
sequential_gate.csv). Without the random order of (i) every guarantee of this module fails: checks taken
in topic blocks (200 tasks with a positive keep-minus-wipe value, then 200 with a negative one) at the
break-even boundary make the break-even test keep falsely in 0.749 of 1,000 streams (review R7, W8;
sequential_order.csv). The replay therefore refuses an order it did not draw itself (NonRandomOrderError)
unless the caller says diagnostic=True.
What this means on a real swap day: the old model's per-candidate results on the check tasks must be
collected BEFORE it retires (the store), and they are charged as calls: 4 home calls per check task per
home repeat (8 with the registered two repeats), plus the owner's calibration tasks for the flag; the
store's size caps the budget of this question. The margin-0 checks need none of this.

Comparison designs, reported beside the paired rule (replay, boundary check, curve):
- "sequential_plugin": a confidence sequence for Abar_swap from the A_s alone, thresholds RHO * A_home_hat.
  HOME TREATED AS KNOWN: NOT VALID WHEN THE HOME VALUE IS ESTIMATED (review R3, S29).
- "sequential_split": alpha split. U_home, L_home fixed-sample betting bounds for Abar_home at alpha/2;
  the swap confidence sequence at alpha/2; KEEP when its lower bound passes 0.75 U_home. Proposition 2
  (split): P(false KEEP) <= alpha for any sign of Abar_home (union of two alpha/2 error events).

=========================================================================================================
INFORMATION LOWER BOUND (sequential_bound.csv, sequential_bound_curve.csv, sequential_adaptive.csv).
Every bound is stated with its four qualifiers, which are columns of every row: the OBSERVATION SCHEME
(scheme: whole tasks drawn uniformly at random, every candidate checked once, 4 checks per task; or the
adaptive scheme below), the MARGIN (theta_0, against theta_1), the SIGNAL (Abar_home and E sigma^2), and
the ERROR LEVELS (alpha, power).
Theorem 2 (Wald 1945; Kaufmann, Cappe and Garivier 2016, Lemma 1). Let P1 (reader table mu1) and P0
(reader table mu0) share the task and home-result distribution, so the per-task divergence is K =
E_tau sum_i kl_Bern(mu1(tau, i) || mu0(tau, i)). For any stopping time N with E_1[N] < infinity and any
event E observed by N, E_1[N] K >= d(P1(E) || P0(E)). So a rule with P0(KEEP) <= alpha for some P0 in H0
(Abar_swap(mu0) <= theta_0 Abar_home) and P1(KEEP) >= 1 - beta needs E_1[N] >= d(1 - beta || alpha) / K;
the least favourable mu0 (smallest K, a convex problem solved per cell by the root of nu c q^2 -
(1 + nu c) q + p = 0, nu by bisection) gives the strongest bound. To second order K ~ (theta_1 - theta_0)^2
Abar_home^2 / (2 E_tau[sigma^2(tau)]), sigma^2(tau) = sum_i c_i^2 mu_i (1 - mu_i) (estimable from two home
repeats: ybar - y1 y2 is unbiased for mu (1 - mu)). Proof sketch: Wald's identity gives E_1[log LR at N] =
E_1[N] K; data processing for the partition {E, not E} gives that this is >= d(P1(E) || P0(E)). []
Theorem 2' (adaptive cell choice). KCG's Lemma 1 holds for adaptive sampling: for any rule that chooses
each next (task, candidate) cell c of the bank's task population from the past observations, observes one
fresh Bernoulli(mu_c) check, and stops at N (CHECKS),
    E_1[N] >= d(1 - beta || alpha) / K_ad,  K_ad = sup_w inf_{mu0 in H0} sum_c w_c kl(mu1_c || mu0_c)
                                                 = inf_{mu0 in H0} max_c kl(mu1_c || mu0_c)
(the objective is linear in the allocation w, so the sup over the simplex is a max over cells; minimax).
Second order: K_ad ~ Delta^2 / (2 (sum_c |a_c| sqrt(v_c))^2), a_c = c_c / (number of tasks), v_c = mu_c
(1 - mu_c), Delta = (theta_1 - theta_0) Abar_home, optimal w_c proportional to |a_c| sqrt(v_c); the
uniform scheme's per-check constant is K/4 ~ Delta^2 / (8 E sigma^2), so adaptive choice lowers the bound
in checks by the factor 4 E sigma^2 / (E_tau sum_i |c_i| sqrt(v_i))^2 >= 1 (Cauchy-Schwarz). It covers
rules that choose tasks and candidates adaptively, weight them, skip tasks and stop early, and that use
the scores, relevance and the owner's stored results (P0 and P1 share them). It does NOT cover rules that
observe more than the cell checks (the new model's self-rating, a judge, log-probabilities, answer
content), a smaller null (a parametric model of the reader, e.g. "the reader is a shrink of the owner"),
repeated checks of one cell that are not fresh Bernoulli draws (deterministic decoding), or a finite
pool's own mean as the target. The bound is on the EXPECTED number of checks under P1: a rule's measured
MEAN stopping time is what it is compared with (ratio_mean_to_bound_*; a mean capped at the horizon is
itself a lower bound on the mean); medians are reported apart and labelled as medians.
Exact against second order (revision 3, review R7 W7). The exact bound d / K_lf is solved numerically
(least_favourable) wherever the alternative's chance table is known (the reviewer model, the worlds, a
simulated study's truth), with a two-way interval (exact_bound_twoway: the per-task Lagrangian is the
influence of K_lf, by the envelope theorem; msr.metrics.robust_variance with task ids and write tasks
within stream). The second-order closed form is an APPROXIMATION: 0.98-1.02 times the exact bound where
chances are spread out, 0.59 (margin 0.75) and 0.28 (margin 0) of it where most cells are near 0 or 1
(review R7's worlds). On real data the exact bound cannot be estimated from a few repeats per cell (it
depends on how close each cell's chance is to 0 or 1; the exact bound computed on the table of
observed home means was about 0.5 times the true exact bound with two repeats (0.75 with four) in R7's
three spread-out worlds, and 2 to 30 times it in his near-deterministic world), so plug-in rows report the second-order value from unbiased moments
and, beside it, a GUARANTEED FLOOR (Result F): for whole random tasks,
    E_1[N] >= d(1 - beta || alpha) / K_lf >= kappa(x) * B_chi2,   kappa(x) = 1 - x - x^2 / 4,
    x = t * c_max, t = |theta_1 - theta_0| Abar_home / E sigma^2, c_max = max |c_i| (3/4 with 4 candidates),
valid whenever x < 2 (sqrt 2 - 1) = 0.83 (else no floor is given). Proof: the null q_i = p_i -/+ t c_i v_i
(v = p (1 - p)) is feasible (t |c_i| <= 1) and meets the constraint exactly; kl(p || q) <= (p - q)^2 /
(2 min over [p, q] of r (1 - r)) and q (1 - q) >= v (1 - x - x^2 / 4), so K_lf <= E sum kl(p || q) <=
K_chi2 / kappa(x). Both Abar_home and E sigma^2 are unbiasedly estimable from two home repeats.

Replay on the frozen probe tables (no model calls; pre-registration 8.4.B2.6): the evaluation tasks of
each stream order are split once into two random halves (a fixed hash, the same split for every pair).
The truth of a pair is read on the TRUTH HALF only (theta = mean A_swap / mean A_home there; for the
margin-0 rules mean A_swap and the first-shown gap there). The home-signal flag is the single flag of
msr.metrics on the owner's CALIBRATION tasks of that cell. The test stream is the OTHER HALF of the
evaluation tasks only (calibration tasks are removed from the stream so that the flag's tasks and the
stream's tasks are disjoint), in an order drawn uniformly at random by the harness (never a given
order, unless diagnostic=True), without replacement, each candidate checked once (one
stored repeat, uniformly; home cells use the extra home repeats 3-4 as the fresh check), paired with the
owner's y_home on the same task; the stream ends when the store (the pool) is exhausted. For a simulated
study the simulator's own success probabilities also give an exact truth (sequential_simtruth.csv).

Synthetic streams never re-use a stored home result: the generative samplers (pool_streams on a table of
success chances, model_streams, bernoulli_pair_streams) draw a fresh home result for every task; the
stored-table sampler store_streams draws without replacement and cannot run past its store.

Outputs (runs/<study>/analysis/): sequential_null.csv, sequential_curve.csv, sequential_curve_compare.csv,
sequential_cells.csv, sequential_rules.csv, sequential_pairs.csv, sequential_simtruth.csv,
sequential_sensitivity.csv, sequential_boundary.csv, sequential_bound.csv, and (new) sequential_margin0.csv,
sequential_bound_curve.csv, sequential_adaptive.csv, sequential_store.csv, sequential_gate.csv,
(revision 3) sequential_order.csv;
figures fig_sequential_stopping and fig_sequential_null under paper/assets/.

Run:  python -m msr.sequential --study sim
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import itertools
import math
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

NAN = float("nan")

# --------------------------------------------------------------------------- pre-stated constants
ALPHA = 0.05                 # error bound for each of the two error types (false keep, false drop)
RHO_KEEP = 0.75              # KEEP needs theta > 0.75: no material loss (the 1/4 margin of PC1, Part 6.1)
RHO_DROP = 0.25              # DROP needs theta < 0.25: at most a quarter of the home signal left
BET = "mixture"              # primary bet; "prpl" (Waudby-Smith and Ramdas' plug-in) and "agrapa": sensitivity
MIX_GRID = tuple(d / 40.0 for d in range(1, 21))   # constant bets 0.025, 0.05, ..., 0.5 (equal weights)
TRUNC_C = 0.5                # bets of prpl / agrapa truncated at c/m (keep side) or c/(1-m) (drop side)
CHECKS_PER_TASK = 4          # one check per candidate: checks = 4 x tasks
CAP_TASKS = 300              # NOT the registered cap: the revision-1 pool (200 evaluation + 100 calibration tasks
                             # outside the truth half of one order); kept only to label old outputs. The registered
                             # replay cap is STORE_TASKS_REAL (200 tasks per order, Part 11.4.6 and 11.5)
STORE_TASKS_REAL = 200       # the real design's store for the paired rule: the evaluation tasks outside the truth
                             # half of one order (calibration tasks now feed the home flag only); a replay's cap
                             # is the size of its own pool (8.4.B2.5-B2.6)
CALIB_TASKS = 100            # one order's calibration pool (the home flag's tasks; also on the curves)
HOME_REPEATS = 2             # the owner's home repeats per cell in the paired statistic (home calls = 4 x this)
FLAG_SIZE_NOMINAL = 0.0228   # 1 - Phi(2): the asymptotic size of the z >= 2 home flag at Abar_home = 0


def swap_day_calls(rule: str, n_tasks: float, store_tasks: float | None = None, home_repeats: int = HOME_REPEATS,
                   calib_tasks: int = CALIB_TASKS, K: int = CHECKS_PER_TASK, share_differ: float = 1.0) -> dict:
    """Model calls of one keep-or-drop decision on one swap day (one bank), by who makes them and when.
    The single cost table (scripts/make_paper_assets.py) reads this function.

    rule: "margin0_ranking", "margin0_first_shown" or "sequential" (the paired 0.75 test).
    n_tasks: tasks the test uses (for a stopping rule: its expected or measured number, or the cap).
    store_tasks: tasks whose OLD-model results are stored before the old model retires (the paired test
    stops with "home table exhausted" when it would need more); default n_tasks.
    share_differ: share of tasks where keep and wipe show different candidates (first-shown version).

    - margin 0, ranking: 0 old-model calls; K new-model checks per task.
    - margin 0, first-shown: 0 old-model calls; 2 new-model checks per task where the arms differ.
    - paired 0.75 test: K x home_repeats OLD-model calls per stored task, all made BEFORE the old model
      retires (the store must be at least as large as the test may need), plus the home flag's
      calibration tasks (calib_tasks x K x 2 old-model calls, the owner's home results on those tasks;
      in the benchmark they are part of the probe table, on a real swap day they are not), plus K
      new-model checks per task used. With the replay's store of 200 tasks and 2 home repeats: 1,600 +
      800 = 2,400 old-model calls; the median stopping time at the practice signal (730.5 tasks,
      sequential_curve.csv theta = 1) needs a store of that size: 8 x 730.5 + 800 = 6,644 old-model calls
      before the swap (about 6,650; revision 2's docstring said 5,850 and left out the 800 flag calls)."""
    store = n_tasks if store_tasks is None else store_tasks
    if rule == "margin0_ranking":
        return {"rule": rule, "old_model_calls_before_retirement": 0, "new_model_calls": K * n_tasks,
                "note": "no home result needed: one-sample test on the reader's checks"}
    if rule == "margin0_first_shown":
        return {"rule": rule, "old_model_calls_before_retirement": 0,
                "new_model_calls": 2 * share_differ * n_tasks,
                "note": "two checks per task where keep and wipe show different candidates, none otherwise"}
    if rule in ("sequential", "paired"):
        old = K * home_repeats * store + calib_tasks * K * 2
        return {"rule": "sequential", "old_model_calls_before_retirement": old, "new_model_calls": K * n_tasks,
                "note": f"the OLD model's results on every stored check task ({K} candidates x {home_repeats} "
                        f"repeats) and on the home flag's {calib_tasks} calibration tasks must be collected "
                        "before it retires"}
    raise ValueError(f"unknown rule {rule!r}")
HOME_TASKS = 400             # one stream order's evaluation tasks: the owner's home sample (plugin, split)
HOME_TASKS_FLOOR = 64        # home sample whose standard error is about Abar_home / 4 (the 4-SE floor)
DEFAULT_AT_CAP = "recalibrate"
REPLAYS = 1000
FIXED_CHECKS = (8, 16, 32, 64)           # the benchmark's fixed budgets in checks (k checks = k/4 tasks)
LONG_CAP = 3000              # horizon (tasks) of the synthetic, curve and known-truth streams
THETA_GRID = (-0.6, -0.4, -0.2, 0.0, 0.1, 0.25, 0.4, 0.5, 0.6, 0.75, 0.9, 1.0)
SENSITIVITY = (               # (rho_drop, rho_keep, alpha, bet)
    (0.25, 0.75, 0.05, "mixture"), (0.0, 0.5, 0.05, "mixture"), (0.25, 0.5, 0.05, "mixture"),
    (0.5, 0.5, 0.05, "mixture"), (0.25, 0.75, 0.10, "mixture"),
    (0.25, 0.75, 0.05, "prpl"), (0.25, 0.75, 0.05, "agrapa"))
# boundary check (generative models with Abar_swap = theta * Abar_home exactly)
BOUNDARY_THETAS_KEEP = (0.60, 0.70, 0.74, 0.75)
BOUNDARY_THETAS_DROP = (0.25, 0.26, 0.30, 0.40)
BOUNDARY_TASKS = (100, 300, 1000, 3000, 6000)
BOUNDARY_REPS = 2000
REVIEWER_BASE, REVIEWER_D = 0.6, 0.12        # mu = 0.6 + d (1, 1/3, -1/3, -1): Abar_home = 5d/3 = 0.20
REVIEWER_V = (1.0, 1.0 / 3.0, -1.0 / 3.0, -1.0)
HETERO_HALF, HETERO_NOISE, HETERO_BASE = 0.25, 0.10, (0.3, 0.7)   # Abar_home about 0.21
# information lower bound
BOUND_POWERS = (0.5, 0.8, 0.9)
BOUND_BUDGETS = (2, 4, 8, 16)            # tasks (8, 16, 32, 64 checks)
BOUND_REPS = 1000
BOUND_HORIZON = 6000
BOUND_MARGINS = tuple(round(0.1 * k, 1) for k in range(10))       # theta_0 of the margin curve
BOUND_SIGNALS = (0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.40, 0.50)   # Abar_home of the signal curve
R6_M2_ES2 = 0.1116           # review R6's model M2 within-task variance (c6_bound.py (c), the "43 checks")
BOUND_BOOT = 2000            # task-bootstrap draws for the plug-in bound's interval
# the margin-0 (break-even) checks
MARGIN0_THETAS = (0.1, 0.25, 0.5, 0.75, 1.0)   # signal = theta x the home signal (E[A_swap] or the keep-wipe gap)
MARGIN0_TASKS = (10, 30, 100, 300, 1000, 3000)  # boundary check-points (tasks)
MARGIN0_REPS = 2000
WORLD_TASKS = 20000          # rows of a generated task table (reviewer / hetero worlds)
R6_WORLD = dict(n_pool=3000, n_eval=2000, n_cal=CALIB_TASKS, bank=250, n_orders=1)   # one bank, one order
SCHEME_UNIFORM = "whole tasks drawn uniformly at random, every candidate checked once (4 checks per task)"
SCHEME_FIRST = "whole tasks drawn uniformly at random, keep's and wipe's first-shown items checked once (2 checks)"
SCHEME_ADAPTIVE = "any adaptive choice of (task, candidate) cells, one fresh Bernoulli check per pick"
# the store (home results) and the sign gate
STORE_REVIEWER = 300         # R6 C5d: a 300-task store of home results
STORE_HORIZONS = (300, 1000, 3000, 6000)
KEEP, DROP, UNDECIDED = 1, -1, 0
NOT_TESTABLE = 2             # the home flag is not positive: no decision (never KEEP)
DECISION_NAME = {KEEP: "keep", DROP: "drop", UNDECIDED: "undecided", NOT_TESTABLE: "not testable"}
STATUS_CAP = "undecided at the cap"
STATUS_EXHAUSTED = "home table exhausted"
STATUS_NOT_TESTABLE = "not testable: home signal not shown positive"
NOT_TESTABLE_ACTION = ("the 0.75 question has no meaning for this bank (no positive home signal shown): answer the "
                       "break-even question instead (keep or wipe, decide_margin0, no old-model call)")
ORDER_HARNESS = "random (drawn by the harness)"
ORDER_GIVEN = "given order (diagnostic: no error guarantee)"
FLOOR_X_MAX = 2.0 * (math.sqrt(2.0) - 1.0)   # kappa(x) = 1 - x - x^2/4 > 0 below this (Result F)
ORDER_BLOCK = 200            # review R7 W8: topic blocks of 200 tasks of one sign, then 200 of the other


class NonRandomOrderError(ValueError):
    """A replay was asked to use a check order it did not draw at random itself. Every guarantee of this
    module needs tasks drawn at random by the harness from a fixed held-out pool (not chosen or ordered by
    the operator); checks in topic order made the break-even test keep falsely in 0.749 of streams (review
    R7, W8). Pass diagnostic=True to replay a given order as a diagnostic (no guarantee)."""
RULES = ("sequential", "sequential_plugin", "sequential_split")
RULE_NOTE = {"sequential": "paired test (home results of the same tasks), gated by the home flag, stops at the "
                           "store; valid with the home value estimated",
             "sequential_plugin": "home treated as known: not valid when the home value is estimated",
             "sequential_drop_ungated": "paired DROP test without the home flag (diagnostic only)",
             "sequential_split": "alpha split: home bound at alpha/2 and swap sequence at alpha/2; valid",
             "margin0_ranking": "margin 0, ranking version: one-sample test of E[A_swap] <= 0 (no home value)",
             "margin0_first_shown": "margin 0, first-shown version: one-sample test of E[keep - wipe first-shown "
                                    "success] <= 0 (no home value)"}


# ===========================================================================
# The per-task statistic
# ===========================================================================


def max_pairs_sum(n) -> np.ndarray:
    """M_n = floor(n/2) * ceil(n/2): the largest value of sum sign(dx) dy over the pairs of n
    candidates with 0/1 outcomes (reached when the top half by score all succeed)."""
    n = np.asarray(n)
    return (n // 2) * (n - n // 2)


def task_stat(x: np.ndarray, y: np.ndarray, present: np.ndarray | None = None) -> tuple:
    """a(tau) for every row: x, y (..., C) scores and outcomes (0/1 or means in [0, 1]; NaN =
    missing). Returns (a, n_used, informative): a in [-1, 1] (NaN with fewer than 2 usable
    candidates), the number of candidates used and whether any pair's outcomes differ.
    Score ties (within 1e-12) count 0. Works on any leading shape."""
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    ok = np.isfinite(y) & np.isfinite(x)
    if present is not None:
        ok &= np.asarray(present, dtype=bool)
    C = x.shape[-1]
    s = np.zeros(x.shape[:-1])
    inf = np.zeros(x.shape[:-1], dtype=bool)
    for i in range(C):
        for j in range(i + 1, C):
            both = ok[..., i] & ok[..., j]
            dx = x[..., i] - x[..., j]
            sg = np.where(np.abs(dx) <= 1e-12, 0.0, np.sign(dx))
            dy = np.where(both, y[..., i] - y[..., j], 0.0)
            s += np.where(both, sg * dy, 0.0)
            inf |= both & (np.abs(dy) > 0)
    n = ok.sum(axis=-1)
    m = max_pairs_sum(n).astype(float)
    with np.errstate(invalid="ignore", divide="ignore"):
        a = np.where(n >= 2, s / np.where(m > 0, m, 1.0), np.nan)
    return a, n, inf


def stat_coefficients(x: np.ndarray, usable: np.ndarray | None = None) -> tuple:
    """(c, n): the coefficients of the per-task statistic, a(tau) = sum_i c_i y_i over the usable
    candidates, c_i = sum_{j != i usable} sign(x_i - x_j) / M_n (0 for unusable candidates and for
    tasks with fewer than 2 usable candidates), and n the number of usable candidates. E[a | tau]
    = sum_i c_i mu_i is linear in the success chances."""
    x = np.asarray(x, dtype=float)
    ok = np.isfinite(x) if usable is None else (np.isfinite(x) & np.asarray(usable, bool))
    C = x.shape[-1]
    c = np.zeros(x.shape)
    xf = np.where(ok, x, 0.0)
    for i in range(C):
        for j in range(C):
            if i == j:
                continue
            dx = xf[..., i] - xf[..., j]
            sg = np.where(np.abs(dx) <= 1e-12, 0.0, np.sign(dx))
            c[..., i] += np.where(ok[..., i] & ok[..., j], sg, 0.0)
    n = ok.sum(-1)
    m = max_pairs_sum(n).astype(float)
    c = np.where((n >= 2)[..., None], c / np.where(m > 0, m, 1.0)[..., None], 0.0)
    return c, n


def to_unit(a):
    """[-1, 1] -> [0, 1]."""
    return (np.asarray(a, dtype=float) + 1.0) / 2.0


def from_unit(u):
    return 2.0 * np.asarray(u, dtype=float) - 1.0


def paired_unit(a_s: np.ndarray, a_h: np.ndarray, c: float) -> np.ndarray:
    """xi = (D + 1 + c) / (2 + 2c) in [0, 1] for D = a_s - c a_h in [-(1+c), 1+c]; E[xi] <= 1/2 exactly
    when E[a_s] <= c E[a_h]. NaN where either statistic is missing (the task then leaves the
    wealth unchanged). Keeps float32 input as float32."""
    a_s = np.asarray(a_s)
    dt = np.float32 if a_s.dtype == np.float32 else float
    c = float(c)
    return ((a_s - dt(c) * np.asarray(a_h, dtype=dt) + dt(1.0 + c)) / dt(2.0 + 2.0 * c)).astype(dt, copy=False)


# ===========================================================================
# Betting test martingales
# ===========================================================================


def _running_moments(x: np.ndarray) -> tuple:
    """Waudby-Smith and Ramdas' predictable estimates: mu_hat_{t-1}, sigma2_hat_{t-1} for t = 1..T,
    mu_hat_t = (1/2 + sum_{i<=t} x_i) / (t + 1), sigma2_hat_t = (1/4 + sum (x_i - mu_hat_i)^2) / (t + 1)."""
    R, T = x.shape
    t = np.arange(1, T + 1)
    mu = (0.5 + np.cumsum(x, axis=1)) / (t + 1)
    s2 = (0.25 + np.cumsum((x - mu) ** 2, axis=1)) / (t + 1)
    mu_prev = np.concatenate([np.full((R, 1), 0.5), mu[:, :-1]], axis=1)
    s2_prev = np.concatenate([np.full((R, 1), 0.25), s2[:, :-1]], axis=1)
    return mu_prev, s2_prev


def bet_sizes(x: np.ndarray, m, side: int, alpha: float, bet: str) -> np.ndarray | None:
    """Predictable bets lambda_t >= 0 for threshold m (a scalar or one per row; None for the
    mixture, whose bets are the fixed grid). side=+1 bets that the mean exceeds m (tests H0:
    mu <= m), side=-1 the reverse."""
    if bet == "mixture":
        return None
    R, T = x.shape
    t = np.arange(1, T + 1)
    cap = TRUNC_C / m if side > 0 else TRUNC_C / (1.0 - m)
    mu_prev, s2_prev = _running_moments(x)
    if bet == "prpl":       # Waudby-Smith and Ramdas (2024), predictable plug-in, one-sided log(1/alpha)
        lam = np.sqrt(2.0 * math.log(1.0 / alpha) / (s2_prev * t * np.log1p(t)))
    elif bet == "agrapa":   # approximate growth-rate adaptive bet, clipped at 0 (one-sided)
        d = side * (mu_prev - m)
        lam = np.clip(d / (s2_prev + d ** 2), 0.0, None)
    else:
        raise ValueError(f"unknown bet {bet!r} (mixture, prpl, agrapa)")
    return np.minimum(lam, cap)


def _mixture_log_wealth(d: np.ndarray) -> np.ndarray:
    """log of the equal-weight average over MIX_GRID of prod (1 + lam d_t), computed in d's dtype
    (float32 for the long synthetic streams). Each factor is >= 1 - 0.5 > 0 because |d| <= 1. The
    per-bet log wealth is clipped (700 in float64, 80 in float32) only to avoid overflow; a clipped
    wealth is far above any 1/alpha."""
    f32 = d.dtype == np.float32
    clip = 80.0 if f32 else 700.0
    acc = np.zeros(d.shape, dtype=d.dtype)
    t = np.empty(d.shape, dtype=d.dtype)
    for lam in MIX_GRID:
        np.multiply(d, d.dtype.type(lam), out=t)
        np.log1p(t, out=t)
        np.cumsum(t, axis=1, out=t)
        np.minimum(t, clip, out=t)
        np.exp(t, out=t)
        acc += t
    with np.errstate(divide="ignore"):
        return np.log(acc / acc.dtype.type(len(MIX_GRID)))


def log_wealth(x: np.ndarray, m, side: int, alpha: float = ALPHA, bet: str = BET) -> np.ndarray:
    """log K_t for t = 1..T of the test of H0: mean <= m (side=+1) or H0: mean >= m (side=-1), for
    observations x (R, T) in [0, 1] and a threshold m in (0, 1) (a scalar or one per row). Under
    H0, K_t is a nonnegative supermartingale with K_0 = 1, so P(sup_t K_t >= 1/alpha) <= alpha
    (Ville's inequality). A NaN observation leaves the wealth unchanged."""
    x = np.asarray(x)
    x = np.atleast_2d(x if x.dtype == np.float32 else np.asarray(x, dtype=float))
    dt = x.dtype
    m = np.asarray(m, dtype=float)
    if np.any(~(m > 0.0)) or np.any(~(m < 1.0)):
        raise ValueError(f"threshold {m} must lie strictly inside (0, 1) on the unit scale")
    mm = m[:, None] if m.ndim == 1 else m
    seen = np.isfinite(x)
    d = np.where(seen, side * (np.where(seen, x, 0.5) - mm.astype(dt)), 0.0).astype(dt, copy=False)
    if bet == "mixture":
        return _mixture_log_wealth(d)
    xf = np.where(seen, x, 0.5).astype(float)
    lam = bet_sizes(xf, mm, side, alpha, bet)
    return np.cumsum(np.log1p(lam * d.astype(float)), axis=1)


_THREADS = max(1, min(4, os.cpu_count() or 1))     # numpy releases the GIL: long streams run in row blocks


def _row_blocks(fn, R: int, min_rows: int = 2):
    """fn(slice) over contiguous row blocks in threads (results concatenated); one call when small."""
    k = min(_THREADS * 2, max(1, R // min_rows))
    if k <= 1:
        return fn(slice(0, R))
    b = np.linspace(0, R, k + 1).astype(int)
    with ThreadPoolExecutor(_THREADS) as ex:
        return np.concatenate(list(ex.map(lambda i: fn(slice(b[i], b[i + 1])), range(k))))


def _crossing_block(x, m, side, alpha, bet):
    lw = log_wealth(x, m, side, alpha, bet)
    hit = lw >= math.log(1.0 / alpha) - 1e-12
    any_ = hit.any(axis=1)
    return np.where(any_, hit.argmax(axis=1) + 1, lw.shape[1] + 1)


def crossing_time(x: np.ndarray, m, side: int, alpha: float = ALPHA, bet: str = BET) -> np.ndarray:
    """First t (1-based) at which the wealth reaches 1/alpha; T + 1 where it never does. Long
    inputs are processed in row blocks on a few threads (the result does not depend on it)."""
    x = np.atleast_2d(np.asarray(x))
    m = np.asarray(m, dtype=float)
    R, T = x.shape
    if R * T < 1_000_000 or R < 2:
        return _crossing_block(x, m, side, alpha, bet)
    return _row_blocks(lambda sl: _crossing_block(x[sl], m[sl] if m.ndim == 1 else m, side, alpha, bet), R)


def _combine(tk: np.ndarray, td: np.ndarray, T: int, valid_len=None) -> tuple:
    """The decision from the two crossing times: KEEP if the keep test fires first, DROP if the
    drop test fires first or at the same task, undecided if neither fires within the stream."""
    R = len(tk)
    L = np.full(R, T) if valid_len is None else np.minimum(np.asarray(valid_len), T)
    tk = np.where(tk <= L, tk, T + 1)
    td = np.where(td <= L, td, T + 1)
    dec = np.full(R, UNDECIDED)
    dec = np.where(tk < td, KEEP, dec)
    dec = np.where((td <= tk) & (td <= L), DROP, dec)        # a tie goes to DROP
    used = np.where(dec == UNDECIDED, L, np.minimum(tk, td))
    return dec, used, tk, td


def _prep(a, cap):
    a = np.asarray(a)
    a = np.atleast_2d(a if a.dtype == np.float32 else np.asarray(a, dtype=float))
    return a[:, :cap] if cap is not None else a


def decide(a: np.ndarray, tau_keep, tau_drop, alpha: float = ALPHA, bet: str = BET,
           cap: int | None = None, valid_len: np.ndarray | None = None) -> tuple:
    """A rule with KNOWN thresholds on streams a (R, T) of single per-task statistics in [-1, 1]:
    KEEP when the test of H0: mean <= tau_keep rejects, DROP when the test of H0: mean >= tau_drop
    rejects (the comparison rule "sequential_plugin" with tau = rho * A_home_hat, and the swap side
    of "sequential_split"). tau_keep, tau_drop: scalars or one per row.
    Returns (decision (R,) in {KEEP, DROP, UNDECIDED}, tasks used (R,), keep time, drop time).
    `cap` truncates the streams; `valid_len` (R,) gives a per-stream length (shorter pools)."""
    a = _prep(a, cap)
    R, T = a.shape
    if np.ndim(tau_keep) == 0 and np.ndim(tau_drop) == 0 and tau_drop > tau_keep:
        raise ValueError("tau_drop must not exceed tau_keep")
    x = to_unit(a).astype(a.dtype, copy=False)
    tk = crossing_time(x, to_unit(tau_keep), +1, alpha, bet)
    td = crossing_time(x, to_unit(tau_drop), -1, alpha, bet)
    return _combine(tk, td, T, valid_len)


def decide_paired(a_s: np.ndarray, a_h: np.ndarray, rho_keep: float = RHO_KEEP, rho_drop: float = RHO_DROP,
                  alpha: float = ALPHA, bet: str = BET, cap: int | None = None,
                  valid_len: np.ndarray | None = None) -> tuple:
    """The primary keep-or-drop decision ("sequential"): the paired tests of Proposition 1 on the
    streams a_s (reader's single checks) and a_h (owner's home results on the same tasks), both
    (R, T). Same return values as decide()."""
    if rho_drop > rho_keep:
        raise ValueError("rho_drop must not exceed rho_keep")
    a_s, a_h = _prep(a_s, cap), _prep(a_h, cap)
    R, T = a_s.shape
    tk = crossing_time(paired_unit(a_s, a_h, rho_keep), 0.5, +1, alpha, bet)
    td = crossing_time(paired_unit(a_s, a_h, rho_drop), 0.5, -1, alpha, bet)
    return _combine(tk, td, T, valid_len)


def decide_margin0(a: np.ndarray, alpha: float = ALPHA, bet: str = BET, cap: int | None = None,
                   valid_len: np.ndarray | None = None) -> tuple:
    """The break-even decision (Propositions M0-R and M0-F): a plain ONE-SAMPLE test on streams a (R, T)
    of a per-task statistic in [-1, 1] (A_swap for the ranking version, d = y_keep - y_wipe for the
    first-shown version), no home value. KEEP when the test of H0: E[a] <= 0 rejects (the old scores beat
    a random order / beat wipe), WIPE (code DROP) when the test of H0: E[a] >= 0 rejects, the registered
    mixture bet on (a + 1)/2 against 1/2; a tie goes to WIPE. Same return values as decide()."""
    return decide(a, 0.0, 0.0, alpha, bet, cap, valid_len)


def first_reuse(home_ids: np.ndarray) -> np.ndarray:
    """(R,) the 0-based position of the first task whose stored home result (id) was already used
    earlier in the same stream; T when no id repeats. The paired rule may use positions < this only."""
    ids = np.atleast_2d(np.asarray(home_ids))
    R, T = ids.shape
    if T < 2:
        return np.full(R, T)
    order = np.argsort(ids, axis=1, kind="stable")
    srt = np.take_along_axis(ids, order, axis=1)
    dup = srt[:, 1:] == srt[:, :-1]                        # a later occurrence of an id (stable: original order)
    pos = np.where(dup, order[:, 1:], T)
    return pos.min(axis=1)


def _flag_from(out, M):
    """Read msr.metrics.home_signal_flag's result whatever its form (bool, status string, z value,
    dict or tuple); None when it cannot be read."""
    if isinstance(out, (bool, np.bool_)):
        return bool(out)
    if isinstance(out, str):
        return out == M.THETA_DEFINED or out.startswith("defined") or out in ("positive", "ok", "pass")
    if isinstance(out, (int, float, np.integer, np.floating)):
        return bool(math.isfinite(float(out)) and float(out) >= M.THETA_CAL_MIN_Z)
    if isinstance(out, dict):
        for k in ("positive", "flag", "ok", "defined", "home_signal_ok", "pass"):
            if k in out:
                return _flag_from(out[k], M) if not isinstance(out[k], (bool, np.bool_)) else bool(out[k])
        if "status" in out:
            return _flag_from(str(out["status"]), M)
        return None
    if isinstance(out, (tuple, list)) and out:
        return _flag_from(out[0], M)
    return None


def home_signal_flag(v_calib) -> tuple:
    """(positive, z): THE single home-signal flag of the study (R6 W3: one function, one rule, used
    everywhere), from the owner's per-CALIBRATION-task signed validities V (its home repeats 1-2).

    The flag lives in msr.metrics; this is only an adapter. When msr.metrics defines the single
    function `home_signal_flag` (the statistics worker's name), it is used; otherwise (or when its
    result cannot be read) the adapter falls back to the registered rule it replaces,
    theta_status_calibration(calibration_z(v)) == THETA_DEFINED, i.e. z >= THETA_CAL_MIN_Z (2).
    Nothing of the rule is re-implemented here. z is calibration_z(v) (NaN with fewer than 3 tasks)."""
    from msr import metrics as M
    v = np.asarray(v_calib, dtype=float).ravel()
    z = M.calibration_z(v) if v.size else NAN
    fn = getattr(M, "home_signal_flag", None)
    if callable(fn):
        try:
            got = _flag_from(fn(v), M)
        except (TypeError, ValueError):            # another signature: the registered fallback below
            got = None
        if got is not None:
            return bool(got), float(z)
    return M.theta_status_calibration(z) == M.THETA_DEFINED, float(z)


def decide_keep_or_drop(a_s: np.ndarray, a_h: np.ndarray, flag_positive, n_home: int | None = None,
                        home_ids: np.ndarray | None = None, rho_keep: float = RHO_KEEP,
                        rho_drop: float = RHO_DROP, alpha: float = ALPHA, bet: str = BET,
                        cap: int | None = None) -> dict:
    """The 0.75 question with its fixed guarantee (Proposition 1, fixed): the paired tests of
    decide_paired, gated by the home flag (intersection-union) and stopped at the home store.

    a_s, a_h (R, T): the reader's checks and the owner's home results on the same tasks, in stream
    order (drawn at random by the harness; a given order voids the guarantee). flag_positive: the single
    home flag (a bool, or one per stream); where it is not positive the decision is NOT_TESTABLE for BOTH
    decisions (never KEEP and never DROP: Proposition 1 as revised; NOT_TESTABLE_ACTION says what the
    operator does then) and no test is run. n_home: the number of distinct stored
    home results available (None = a fresh home result for every task, unlimited); the stream stops
    there. home_ids (R, T): optional ids of the stored home result used at each task; the stream also
    stops at the first re-used id (home results are never drawn with replacement). cap: the budget
    in tasks. Returns {"decision", "status", "used", "keep_time", "drop_time", "store_limit"}: status
    is "keep", "drop", STATUS_CAP (budget reached), STATUS_EXHAUSTED (the store ran out first) or
    STATUS_NOT_TESTABLE."""
    a_s, a_h = _prep(a_s, None), _prep(a_h, None)
    R, T = a_s.shape
    budget = T if cap is None else min(int(cap), T)
    store = np.full(R, np.iinfo(np.int64).max // 4, dtype=np.int64)
    if n_home is not None:
        store = np.minimum(store, int(n_home))
    if home_ids is not None:
        store = np.minimum(store, first_reuse(np.asarray(home_ids)[:, :T]))
    limit = np.minimum(store, budget)
    dec, used, tk, td = decide_paired(a_s, a_h, rho_keep, rho_drop, alpha, bet, cap=budget, valid_len=limit)
    flag = np.broadcast_to(np.asarray(flag_positive, dtype=bool), (R,))
    dec = np.where(flag, dec, NOT_TESTABLE)
    status = np.where(dec == KEEP, "keep", np.where(dec == DROP, "drop", np.where(
        dec == NOT_TESTABLE, STATUS_NOT_TESTABLE, np.where(store <= budget, STATUS_EXHAUSTED, STATUS_CAP))))
    used = np.where(dec == NOT_TESTABLE, 0, np.where(dec == UNDECIDED, limit, used))
    return {"decision": dec, "status": status, "used": used, "keep_time": tk, "drop_time": td,
            "store_limit": np.minimum(store, T)}


def decide_split(a_s: np.ndarray, home_lo, home_hi, rho_keep: float = RHO_KEEP, rho_drop: float = RHO_DROP,
                 alpha: float = ALPHA, bet: str = BET, cap: int | None = None,
                 valid_len: np.ndarray | None = None) -> tuple:
    """The alpha-split comparison rule ("sequential_split", Proposition 2): the swap confidence
    sequence at alpha/2 against rho_keep * home_hi (KEEP) and rho_drop * home_lo (DROP), where
    home_lo, home_hi are level-alpha/2 bounds for Abar_home (scalars or one per row)."""
    a_s = _prep(a_s, cap)
    R, T = a_s.shape
    x = to_unit(a_s).astype(a_s.dtype, copy=False)
    tk = crossing_time(x, to_unit(rho_keep * np.asarray(home_hi, float)), +1, alpha / 2.0, bet)
    td = crossing_time(x, to_unit(rho_drop * np.asarray(home_lo, float)), -1, alpha / 2.0, bet)
    return _combine(tk, td, T, valid_len)


def betting_bound(values: np.ndarray, alpha: float, upper: bool, iters: int = 36, _blocks: bool = True) -> np.ndarray:
    """Fixed-sample level-(1 - alpha) bound for the mean of each row of `values` (R, n) in [-1, 1]
    (NaN ignored), from the registered mixture bet evaluated once, at the end of the sample:
    upper=True: U = inf{m : W_n(m) >= 1/alpha}, W_n the mixture wealth of the bet on 'the mean is
    below m' (it tests H0: mean >= m and increases in m), so P(mean >= U) = P(W_n(mean) >= 1/alpha)
    <= alpha by Markov's inequality (E W_n <= 1 under H0); upper=False: the mirror lower bound.
    Bisection on the [0, 1] scale; the returned value is on the conservative side of the root."""
    v = np.atleast_2d(np.asarray(values, dtype=float))
    if _blocks and v.shape[0] * v.shape[1] >= 200_000 and v.shape[0] >= 2:
        return _row_blocks(lambda sl: betting_bound(v[sl], alpha, upper, iters, False), v.shape[0])
    x = to_unit(v)
    seen = np.isfinite(x)
    cnt = np.maximum(seen.sum(1), 1)
    mean = np.where(seen, x, 0.0).sum(1) / cnt
    side = -1.0 if upper else 1.0
    thr = math.log(1.0 / alpha)
    lams = np.array(MIX_GRID)

    def logw(m):
        d = np.where(seen, side * (np.where(seen, x, 0.0) - m[:, None]), 0.0)
        s = np.stack([np.log1p(lam * d).sum(1) for lam in lams])        # (bets, R)
        mx = s.max(0)
        return mx + np.log(np.exp(s - mx).mean(0))

    if upper:
        lo, hi = mean.copy(), np.full(len(mean), 1.0 - 1e-9)
        never = logw(hi) < thr
        for _ in range(iters):
            mid = (lo + hi) / 2.0
            rej = logw(mid) >= thr
            hi = np.where(rej, mid, hi)
            lo = np.where(rej, lo, mid)
        out = np.where(never, 1.0, hi)
    else:
        lo, hi = np.full(len(mean), 1e-9), mean.copy()
        never = logw(lo) < thr
        for _ in range(iters):
            mid = (lo + hi) / 2.0
            rej = logw(mid) >= thr
            lo = np.where(rej, mid, lo)
            hi = np.where(rej, hi, mid)
        out = np.where(never, 0.0, lo)
    return from_unit(out)


def confidence_sequence(a_path: np.ndarray, alpha: float = ALPHA, bet: str = BET, grid: int = 401) -> tuple:
    """Lower and upper bounds of the one-sided confidence sequences for E[a] along one stream
    (each at level 1 - alpha; the pair covers with probability at least 1 - 2 alpha), on the a
    scale, as running intersections: lower_t = the largest grid value m rejected by the test of
    H0: mean <= m at some s <= t (or -1), upper_t likewise from above. With the mixture and prpl
    bets the wealth is monotone in m, so 'tau_keep < lower_t' is the same event as the KEEP test
    rejecting at tau_keep (checked in tests/test_sequential.py)."""
    a_path = np.asarray(a_path, dtype=float).ravel()
    x = to_unit(a_path)[None, :]
    T = x.shape[1]
    ms = np.linspace(0.0, 1.0, grid)[1:-1]
    lo_t = np.array([crossing_time(x, m, +1, alpha, bet)[0] for m in ms])
    hi_t = np.array([crossing_time(x, m, -1, alpha, bet)[0] for m in ms])
    lower = np.full(T, -1.0)
    upper = np.full(T, 1.0)
    for t in range(1, T + 1):
        rl = ms[lo_t <= t]
        ru = ms[hi_t <= t]
        if rl.size:
            lower[t - 1] = from_unit(rl.max())
        if ru.size:
            upper[t - 1] = from_unit(ru.min())
    return lower, upper


def run_rules(a_s, a_h, rules=RULES, home_hat=None, home_lo=None, home_hi=None, rho_keep=RHO_KEEP,
              rho_drop=RHO_DROP, alpha=ALPHA, bet=BET, cap=None, valid_len=None) -> dict:
    """{rule: (decision, tasks used, keep time, drop time)} for the paired rule and the two
    comparison rules on the same streams. home_hat: the plug-in home value (scalar or per row);
    home_lo, home_hi: the split rule's alpha/2 home bounds."""
    out = {}
    for rule in rules:
        if rule == "sequential":
            out[rule] = decide_paired(a_s, a_h, rho_keep, rho_drop, alpha, bet, cap, valid_len)
        elif rule == "sequential_plugin":
            hh = np.broadcast_to(np.asarray(home_hat, dtype=float), (np.atleast_2d(np.asarray(a_s)).shape[0],))
            out[rule] = decide(a_s, rho_keep * hh, rho_drop * hh, alpha, bet, cap, valid_len)
        elif rule == "sequential_split":
            out[rule] = decide_split(a_s, home_lo, home_hi, rho_keep, rho_drop, alpha, bet, cap, valid_len)
        else:
            raise ValueError(f"unknown rule {rule!r}")
    return out


# ===========================================================================
# Stream generators
# ===========================================================================


def reflect_sampler(values: np.ndarray, mean: float, rng, size) -> np.ndarray:
    """Draws whose mean is EXACTLY `mean`: the empirical distribution F of `values` (mean mu0 > 0)
    mixed with its reflection -F, weight w = (1 + mean/mu0)/2 on F (a check of the betting
    machinery on single streams). Needs |mean| <= mu0."""
    v = np.asarray(values, dtype=float)
    v = v[np.isfinite(v)]
    mu0 = float(v.mean())
    if mu0 <= 0:
        raise ValueError("the source values need a positive mean")
    if abs(mean) > mu0 + 1e-12:
        raise ValueError(f"mean {mean} is outside [-{mu0:.3f}, {mu0:.3f}]")
    w = (1.0 + mean / mu0) / 2.0
    d = rng.choice(v, size=size)
    return np.where(rng.random(size) < w, d, -d)


def two_point_sampler(mean: float, rng, size) -> np.ndarray:
    """a in {-1, +1} with P(+1) = (1 + mean)/2: the largest variance a bounded statistic can have."""
    return np.where(rng.random(size) < (1.0 + mean) / 2.0, 1.0, -1.0)


def beta_sampler(mean: float, rng, size, conc: float = 2.0) -> np.ndarray:
    """a = 2 B - 1, B ~ Beta with mean (1 + mean)/2 and concentration conc: a continuous case."""
    p = (1.0 + mean) / 2.0
    return 2.0 * rng.beta(conc * p, conc * (1 - p), size=size) - 1.0


def _compact(c: np.ndarray, usable: np.ndarray) -> np.ndarray:
    """The coefficients of the usable candidates first (original order), zeros after."""
    order = np.argsort(~usable, axis=-1, kind="stable")
    return np.take_along_axis(c, order, axis=-1)


def _shuffled_stat(c_compact: np.ndarray, usable: np.ndarray, y: np.ndarray, rng) -> np.ndarray:
    """sum_k c_compact[k] y_sh[k], y_sh = the usable outcomes in a uniformly random order: the
    statistic with the old scores permuted at random among the usable candidates (its mean is
    exactly 0 for every outcome vector)."""
    keys = rng.random(y.shape)
    keys = np.where(usable, keys, 2.0)
    order = np.argsort(keys, axis=-1)
    y_sh = np.take_along_axis(np.where(usable, y, 0.0), order, axis=-1)
    return (c_compact * y_sh).sum(-1)


def bernoulli_pair_streams(c: np.ndarray, p_reader: np.ndarray, p_owner: np.ndarray, R: int, T: int, rng,
                           usable: np.ndarray | None = None, shuffled: bool = False, home_reps: int = 2,
                           chunk_tasks: int = 1_000_000, dtype=np.float32) -> tuple:
    """(a_s, a_h), each (R, T): tasks drawn uniformly WITH replacement from the P pool rows of c,
    p_reader, p_owner (P, C); a_s = the statistic of one fresh Bernoulli check per candidate from
    the reader's chances, a_h = that of the mean of `home_reps` fresh home results from the
    owner's chances (home_reps = 0: a_h is not drawn, returned as None). shuffled: a_s with the
    old scores permuted at random within the task (E[a_s] = 0). Exact: E[a_s] = mean_tau sum c p_reader."""
    c = np.asarray(c, float)
    P, C = c.shape
    use = (np.abs(c) > 0) | (np.asarray(usable, bool) if usable is not None else False)
    pr = np.where(use, np.nan_to_num(np.asarray(p_reader, float)), 0.0)
    po = np.where(use, np.nan_to_num(np.asarray(p_owner, float)), 0.0)
    cc = _compact(c, use) if shuffled else None
    a_s = np.empty((R, T), dtype=dtype)
    a_h = np.empty((R, T), dtype=dtype) if home_reps > 0 else None
    rows = max(1, chunk_tasks // max(T, 1))
    for r0 in range(0, R, rows):
        r1 = min(R, r0 + rows)
        j = rng.integers(0, P, size=(r1 - r0, T))
        ys = (rng.random((r1 - r0, T, C), dtype=np.float32) < pr[j]).astype(np.float32)
        if shuffled:
            a_s[r0:r1] = _shuffled_stat(cc[j], use[j], ys, rng)
        else:
            a_s[r0:r1] = (c[j] * ys).sum(-1)
        if home_reps > 0:
            yh = np.zeros((r1 - r0, T, C), dtype=np.float32)
            pj = po[j]
            for _ in range(home_reps):
                yh += rng.random((r1 - r0, T, C), dtype=np.float32) < pj
            a_h[r0:r1] = (c[j] * (yh / home_reps)).sum(-1)
    return a_s, a_h


def home_pool(cells: dict, probs: dict | None = None) -> dict | None:
    """The joint (A_s, A_h) samplers' source: every probe task of the home cells (owner = reader).
    Per task: the statistic's coefficients c from the owner's scores and a table of success CHANCES p,
    from which the generative sampler pool_streams draws fresh checks and fresh home results:
    p = the simulator's true chances when `probs` ({cell key: (p_reader, p_owner)}) is given, else the
    mean of ALL the owner's stored repeats of the cell (home repeats 1-2 and extra repeats 3-4; a
    plug-in table, unbiased for the chance per cell). The stored values are kept too, for the
    without-replacement sampler store_streams: the HOME session's two-repeat statistic (y_home) and
    the CHECK session's single repeats (y_extra, or repeat 2 when there is no y_extra), with the
    session of the larger mean as the check session (so theta = 1 is feasible on the stored table).
    Returns None without a usable home cell."""
    C_, YH, YC, U, PP = [], [], [], [], []
    swapped = []
    for key, c in sorted(cells.items()):
        o, r = key[0], key[1]
        if o != r:
            continue
        yh = _fill_repeats(c["y_home"])
        if c.get("y_extra") is not None:
            s1, s2 = yh, _fill_repeats(c["y_extra"])
        elif yh.shape[-1] >= 2:
            s1, s2 = yh[..., :1], yh[..., 1:2]
        else:
            continue
        x = c["x"]
        usable = (c["items"] != "") & np.isfinite(x) & np.isfinite(s1).all(-1) & np.isfinite(s2).all(-1)
        if probs is not None and key in probs:
            pt = np.asarray(probs[key][1], dtype=float)
            usable &= np.isfinite(pt)
        else:
            pt = _mean_rep(np.concatenate([s1, s2], axis=-1))
        coef, n = stat_coefficients(x, usable)
        ok = n >= 2
        C_.append(coef[ok])
        U.append(usable[ok])
        YH.append(np.where(usable[ok][..., None], s1[ok], 0.0))
        YC.append(np.where(usable[ok][..., None], s2[ok], 0.0))
        PP.append(np.where(usable[ok], pt[ok], 0.0))
    if not C_:
        return None
    c = np.concatenate(C_)
    usable = np.concatenate(U)
    s1 = np.concatenate(YH)
    s2 = np.concatenate(YC)
    p = np.clip(np.concatenate(PP), 0.0, 1.0)
    m1 = float(np.mean((c[..., None] * s1).sum(1)))      # mean single-repeat statistic, session 1
    m2 = float(np.mean((c[..., None] * s2).sum(1)))
    if m2 < m1 and s1.shape[-1] == s2.shape[-1]:
        s1, s2 = s2, s1
        swapped.append(True)
    yH = s1.mean(-1)
    a_home = (c * yH).sum(-1)
    a_check = (c[..., None] * s2).sum(1)                  # (P, R2)
    m_home = float((c * p).sum(-1).mean())                # Abar_home of the chance table
    return {"c": c, "usable": usable, "c_compact": _compact(c, usable), "p": p,
            "p_source": "simulator truth" if probs is not None else "plug-in: mean of the owner's stored repeats",
            "m_home": m_home, "m_check": m_home, "tasks": int(len(c)),
            "y_check": s2, "a_home": a_home, "a_check": a_check, "m_home_stored": float(a_home.mean()),
            "m_check_stored": float(a_check.mean()),
            "check_session": "home repeats 1-2" if swapped else "extra repeats 3-4"}


def pool_streams(pool: dict, theta: float, R: int, T: int, rng, chunk_tasks: int = 2_000_000,
                 dtype=np.float32, home_reps: int = HOME_REPEATS) -> tuple:
    """(a_s, a_h), each (R, T), GENERATIVE: no stored home result is ever re-used. Per draw: a task
    uniformly (with replacement) from the pool's table of success chances p; a_h = the statistic of
    the mean of `home_reps` FRESH home results from p; with probability |theta| a_s = the statistic of
    one FRESH check from p (sign flipped when theta < 0: reversed scores), otherwise a fresh check
    with the candidate scores permuted at random within the task (mean exactly 0). So E[a_s] = theta *
    E[a_h] = theta * m_home EXACTLY, the pairs are i.i.d., and Proposition 1's conditions hold for any
    horizon. (The earlier sampler re-used the stored home statistic of a 640-task pool for 3,000-task
    streams, R6 C5d; store_streams is the stored-table sampler, without replacement.)"""
    if abs(theta) > 1.0 + 1e-12:
        raise ValueError(f"theta {theta} is outside [-1, 1] (the generative pool sampler mixes checks)")
    P, C = pool["c"].shape
    sg = 1.0 if theta >= 0 else -1.0
    p = pool["p"].astype(np.float32)
    c = pool["c"].astype(np.float32)
    a_s = np.empty((R, T), dtype=dtype)
    a_h = np.empty((R, T), dtype=dtype)
    rows = max(1, chunk_tasks // max(T * C, 1))
    for r0 in range(0, R, rows):
        r1 = min(R, r0 + rows)
        j = rng.integers(0, P, size=(r1 - r0, T))
        pj = p[j]
        ys = (rng.random(pj.shape, dtype=np.float32) < pj).astype(np.float32)
        real = rng.random((r1 - r0, T)) < abs(theta)
        out = sg * (c[j] * ys).sum(-1)
        fake = ~real
        if fake.any():
            jj = j[fake]
            out[fake] = _shuffled_stat(pool["c_compact"][jj], pool["usable"][jj], ys[fake], rng)
        a_s[r0:r1] = out
        yh = np.zeros(pj.shape, dtype=np.float32)
        for _ in range(home_reps):
            yh += rng.random(pj.shape, dtype=np.float32) < pj
        a_h[r0:r1] = (c[j] * (yh / home_reps)).sum(-1)
    return a_s, a_h


def store_streams(pool: dict, theta: float, R: int, T: int, rng) -> tuple:
    """(a_s, a_h, ids), each (R, T): the STORED-table sampler, without replacement (Proposition 1 (iv)).
    Each stream visits T <= P distinct pool tasks in a uniformly random order; a_h = the task's STORED
    home statistic (used once), a_s = one uniformly chosen stored repeat of the check session (with
    probability |p|, p = theta * m_home_stored / m_check_stored, else the same check with the scores
    permuted at random), ids = the pool index of each task's stored home result. It refuses to run past
    the store: T > P raises (the paired rule stops there with STATUS_EXHAUSTED)."""
    P = pool["tasks"]
    if T > P:
        raise ValueError(f"the store holds {P} home results; a stream of {T} tasks would re-use them")
    R2 = pool["a_check"].shape[1]
    p = theta * pool["m_home_stored"] / pool["m_check_stored"] if pool["m_check_stored"] != 0 else 0.0
    if abs(p) > 1.0 + 1e-12:
        raise ValueError(f"theta {theta} is not reachable with this stored table (|p| = {abs(p):.3f} > 1)")
    sg = 1.0 if p >= 0 else -1.0
    j = np.argsort(rng.random((R, P)), axis=1)[:, :T]
    rr = rng.integers(0, R2, size=(R, T))
    real = rng.random((R, T)) < abs(p)
    out = sg * pool["a_check"][j, rr]
    fake = ~real
    if fake.any():
        jj, r_ = j[fake], rr[fake]
        out[fake] = _shuffled_stat(pool["c_compact"][jj], pool["usable"][jj], pool["y_check"][jj, :, r_], rng)
    return out.astype(np.float32), pool["a_home"][j].astype(np.float32), j


def pool_home_sample(pool: dict, R: int, n: int, rng) -> np.ndarray:
    """(R, n) home statistics of n tasks drawn from the pool's chance table, each with fresh home
    results (2 repeats): a home sample whose mean estimates m_home without bias."""
    _, a_h = pool_streams(pool, 0.0, R, n, rng)
    return a_h


# ===========================================================================
# The exact null on the paired statistic, and the stopping-time curve
# ===========================================================================


def null_check(pool: dict, n_streams: int = 5000, horizon: int = LONG_CAP, alpha: float = ALPHA,
               bet: str = BET, seed: int = 0, rho_keep: float = RHO_KEEP, rho_drop: float = RHO_DROP,
               checkpoints=(1, 2, 4, 8, 16, 25, 50, 100, 200, 400, 1000, 3000)) -> list:
    """Paired streams exactly on the null boundary, E[A_s] = rho * E[A_h] (E[D] = 0), for three
    joint distributions: 'table' (pool_streams at theta = rho: fresh checks and fresh home results
    from the home cells' chance table, the realistic joint law of the reader's check and the owner's
    home result on the same task), 'two_point' (A_s, A_h in {-1, 1},
    independent: the largest variance) and 'beta' (continuous, independent). The share of streams
    whose KEEP (DROP) test has fired by task t is the false-keep (false-drop) rate if the user
    stopped at t or at any time before; it must stay at or below alpha for every t."""
    rng = np.random.default_rng([seed, 7101])
    rows = []
    m_h = pool["m_home"]
    for dist in ("table", "two_point", "beta"):
        for side_name, side, rho in (("keep", +1, rho_keep), ("drop", -1, rho_drop)):
            size = (n_streams, horizon)
            if dist == "table":
                a_s, a_h = pool_streams(pool, rho, n_streams, horizon, rng)
            elif dist == "two_point":
                a_h = two_point_sampler(m_h, rng, size).astype(np.float32)
                a_s = two_point_sampler(rho * m_h, rng, size).astype(np.float32)
            else:
                a_h = beta_sampler(m_h, rng, size).astype(np.float32)
                a_s = beta_sampler(rho * m_h, rng, size).astype(np.float32)
            t_hit = crossing_time(paired_unit(a_s, a_h, rho), 0.5, side, alpha, bet)
            mc_se = math.sqrt(alpha * (1 - alpha) / n_streams)
            for t in [c for c in checkpoints if c <= horizon] + ([horizon] if horizon not in checkpoints else []):
                rate = float(np.mean(t_hit <= t))
                rows.append({"distribution": dist, "test": side_name, "statistic": "paired D = A_s - rho A_h",
                             "bet": bet, "alpha": alpha, "theta": rho, "true_mean": rho * m_h,
                             "threshold": rho * m_h, "mu_home": m_h, "mean_D": 0.0, "streams": n_streams,
                             "by_task": t, "error_rate": rate, "mc_se": mc_se,
                             "upper_99": min(1.0, rate + 2.326 * math.sqrt(max(rate * (1 - rate), 1e-12) / n_streams)),
                             "within_alpha": bool(rate <= alpha + 2.326 * mc_se)})
    return rows


def _stop_row(dec, used, horizon) -> dict:
    stopped = dec != UNDECIDED
    row = {"keep_share": float(np.mean(dec == KEEP)), "drop_share": float(np.mean(dec == DROP)),
           "undecided_share": float(np.mean(~stopped))}
    for q in (10, 25, 50, 75, 90):
        row[f"tasks_q{q}"] = float(np.percentile(np.where(stopped, used, horizon + 1), q))
    for c in sorted({k // CHECKS_PER_TASK for k in FIXED_CHECKS} | {CALIB_TASKS, STORE_TASKS_REAL, CAP_TASKS}):
        row[f"decided_by_{c}"] = float(np.mean(stopped & (used <= c)))
    row["tasks_median_if_decided"] = float(np.median(used[stopped])) if stopped.any() else NAN
    row["tasks_mean_capped"] = float(np.mean(np.minimum(used, horizon)))
    return row


def stopping_curve(pool: dict, thetas=THETA_GRID, n_streams: int = 2000, horizon: int = LONG_CAP,
                   alpha: float = ALPHA, bet: str = BET, seed: int = 0, rho_keep: float = RHO_KEEP,
                   rho_drop: float = RHO_DROP, rules=("sequential",), n_home: int = HOME_TASKS) -> list:
    """Tasks needed as a function of the true retained share theta, on joint (A_s, A_h) streams from
    pool_streams (E[A_s] = theta * E[A_h] exactly over the pool's chance table; a FRESH home result for
    every task, so a horizon beyond the pool size re-uses no stored home result), up to `horizon`
    tasks; a decision at a smaller cap c is 'decided by c' (decided_by_200 = within the real design's
    store of one order). The paired test here is ungated (the home signal is positive by construction)
    and has no store; on swap day the store caps it. Rows per rule (column source): 'sequential' (the paired
    rule), 'plugin_known_home' (the earlier rule with the pool's exact home value: the old curve,
    valid only because the home value is known here) and 'sequential_split' (home bounds from
    n_home pool tasks per stream)."""
    rng = np.random.default_rng([seed, 7202])
    rows = []
    hs = None
    if "sequential_split" in rules:
        hs = pool_home_sample(pool, n_streams, n_home, np.random.default_rng([seed, 7203]))
        h_hi = betting_bound(hs, alpha / 2.0, upper=True)
        h_lo = betting_bound(hs, alpha / 2.0, upper=False)
    for th in thetas:
        a_s, a_h = pool_streams(pool, th, n_streams, horizon, rng)
        res = run_rules(a_s, a_h, [r if r != "plugin_known_home" else "sequential_plugin" for r in rules],
                        home_hat=pool["m_home"], home_lo=h_lo if hs is not None else None,
                        home_hi=h_hi if hs is not None else None, rho_keep=rho_keep, rho_drop=rho_drop,
                        alpha=alpha, bet=bet)
        for rule in rules:
            dec, used, _, _ = res[rule if rule != "plugin_known_home" else "sequential_plugin"]
            row = {"source": rule, "theta": th, "mu_home": pool["m_home"], "m_check": pool["m_check"],
                   "pool_tasks": pool["tasks"], "alpha": alpha, "bet": bet, "rho_keep": rho_keep,
                   "rho_drop": rho_drop, "streams": n_streams, "horizon": horizon,
                   "n_home": n_home if rule == "sequential_split" else "",
                   **_stop_row(dec, used, horizon)}
            rows.append(row)
    return rows


# ===========================================================================
# The boundary check: generative models with Abar_swap = theta * Abar_home exactly
# ===========================================================================


def model_tasks(model: str, theta: float, shape: tuple, rng, with_x: bool = False) -> tuple:
    """(c, p_owner, p_reader), each shape + (4,), for one of the two generative task models.
    'reviewer' (review R3, check 6): every task alike, scores in a fixed order, owner mu = 0.6 +
    d (1, 1/3, -1/3, -1), reader mu = 0.6 + theta d (...), d = 0.12, so Abar_home = 5d/3 = 0.20.
    'hetero' (task heterogeneity): per task, candidate offsets u_i ~ U(-0.25, 0.25), scores x_i =
    u_i + N(0, 0.1^2), owner mu = m_tau + u_i, reader mu = m'_tau + theta u_i with m_tau, m'_tau ~
    U(0.3, 0.7) independent; all chances stay inside (0.05, 0.95) without clipping, and because the
    coefficients sum to 0 within a task, E[A_s | tau] = theta E[A_h | tau] exactly
    (Abar_home about 0.21). with_x: also return the scores x (reviewer: 4, 3, 2, 1)."""
    if model == "reviewer":
        v = np.array(REVIEWER_V)
        c = np.broadcast_to(np.array([3.0, 1.0, -1.0, -3.0]) / 4.0, shape + (4,))
        po = np.broadcast_to(REVIEWER_BASE + REVIEWER_D * v, shape + (4,))
        pr = np.broadcast_to(REVIEWER_BASE + theta * REVIEWER_D * v, shape + (4,))
        if with_x:
            return c, po, pr, np.broadcast_to(np.array([4.0, 3.0, 2.0, 1.0]), shape + (4,))
        return c, po, pr
    if model == "hetero":
        u = rng.uniform(-HETERO_HALF, HETERO_HALF, size=shape + (4,)).astype(np.float32)
        x = u + HETERO_NOISE * rng.standard_normal(shape + (4,)).astype(np.float32)
        rank = np.argsort(np.argsort(x, axis=-1), axis=-1)
        c = ((2 * rank - 3) / 4.0).astype(np.float32)
        mo = rng.uniform(*HETERO_BASE, size=shape + (1,)).astype(np.float32)
        mr = rng.uniform(*HETERO_BASE, size=shape + (1,)).astype(np.float32)
        if with_x:
            return c, mo + u, mr + np.float32(theta) * u, x
        return c, mo + u, mr + np.float32(theta) * u
    raise ValueError(f"unknown model {model!r} (reviewer, hetero)")


def _exact_law(c: np.ndarray, p: np.ndarray, reps: int) -> tuple:
    """(values, probabilities) of sum_i c_i ybar_i, ybar_i the mean of `reps` Bernoulli(p_i) draws,
    for ONE task (c, p of shape (C,)): exact enumeration."""
    levels = np.arange(reps + 1)
    from math import comb
    pk = np.array([[comb(reps, k) * pi ** k * (1 - pi) ** (reps - k) for k in levels] for pi in p])   # (C, reps+1)
    vals, probs = [], []
    for pat in itertools.product(levels, repeat=len(c)):
        vals.append(float(np.dot(c, np.array(pat) / reps)))
        probs.append(float(np.prod([pk[i, k] for i, k in enumerate(pat)])))
    v = np.round(np.array(vals), 12)
    uv, inv = np.unique(v, return_inverse=True)
    return uv, np.bincount(inv, weights=np.array(probs))


def _draw_law(law: tuple, rng, size) -> np.ndarray:
    vals, probs = law
    cdf = np.cumsum(probs)
    cdf /= cdf[-1]
    return vals[np.minimum(np.searchsorted(cdf, rng.random(size), side="right"), len(vals) - 1)].astype(np.float32)


def model_streams(model: str, theta: float, R: int, T: int, rng, home_reps: int = 2,
                  chunk_tasks: int = 1_500_000) -> tuple:
    """(a_s, a_h) (R, T) float32 from a generative task model: one reader check per candidate and
    the mean of `home_reps` owner home results on the same task (home_reps = 0: a_h None). In the
    'reviewer' model every task is alike, so both statistics are drawn from their exact laws."""
    if model == "reviewer":
        c, po, pr = (np.asarray(v)[0, 0] for v in model_tasks(model, theta, (1, 1), rng))
        a_s = _draw_law(_exact_law(c, pr, 1), rng, (R, T))
        a_h = _draw_law(_exact_law(c, po, home_reps), rng, (R, T)) if home_reps else None
        return a_s, a_h
    a_s = np.empty((R, T), np.float32)
    a_h = np.empty((R, T), np.float32) if home_reps else None
    rows = max(1, chunk_tasks // max(T, 1))
    for r0 in range(0, R, rows):
        r1 = min(R, r0 + rows)
        c, po, pr = model_tasks(model, theta, (r1 - r0, T), rng)
        ys = rng.random(c.shape, dtype=np.float32) < pr
        a_s[r0:r1] = (c * ys).sum(-1)
        if home_reps:
            yh = np.zeros(c.shape, np.float32)
            for _ in range(home_reps):
                yh += rng.random(c.shape, dtype=np.float32) < po
            a_h[r0:r1] = (c * (yh / home_reps)).sum(-1)
    return a_s, a_h


def model_abar_home(model: str, n: int = 2_000_000, seed: int = 0) -> float:
    """Abar_home of a generative model (exact for 'reviewer'; a fixed-seed Monte-Carlo mean of
    E[A_h | tau] = sum c mu_owner for 'hetero')."""
    if model == "reviewer":
        return float(np.dot(np.array([3.0, 1.0, -1.0, -3.0]) / 4.0, REVIEWER_BASE + REVIEWER_D * np.array(REVIEWER_V)))
    rng = np.random.default_rng([seed, 7404])
    c, po, _ = model_tasks(model, 1.0, (n,), rng)
    return float((c.astype(float) * po).sum(-1).mean())


def table_streams(coef: np.ndarray, p: np.ndarray, R: int, T: int, rng, p_home: np.ndarray | None = None,
                  cost: np.ndarray | None = None, home_reps: int = HOME_REPEATS, chunk_cells: int = 24_000_000,
                  idx: np.ndarray | None = None) -> tuple:
    """(a, cost_t, a_h) from a table of tasks (rows of coef, p, (P, C)): tasks drawn uniformly WITH
    replacement (i.i.d. given the table), one FRESH Bernoulli(p) check per cell, a = sum coef * y
    (R, T) float32; cost_t (R, T) = the checks that task costs (cost per row, default the number of
    nonzero coefficients); a_h = the statistic of the mean of `home_reps` FRESH home results from p_home
    on the same task (None when p_home is None). Works for the ranking statistic (coef = c) and the
    first-shown difference (coef = e = keep's item minus wipe's item). idx (R, T): given task rows in a given
    order instead of uniform draws: a DIAGNOSTIC of a non-random order only (topic_block_order)."""
    coef = np.asarray(coef, dtype=np.float32)
    P, C = coef.shape
    pr = np.nan_to_num(np.asarray(p, dtype=np.float32))
    ph = None if p_home is None else np.nan_to_num(np.asarray(p_home, dtype=np.float32))
    cst = (np.abs(coef) > 0).sum(-1) if cost is None else np.asarray(cost)
    cst = cst.astype(np.int16)
    a = np.empty((R, T), np.float32)
    ct = np.empty((R, T), np.int16)
    ah = np.empty((R, T), np.float32) if ph is not None else None
    rows = max(1, chunk_cells // max(T * C, 1))
    for r0 in range(0, R, rows):
        r1 = min(R, r0 + rows)
        j = rng.integers(0, P, size=(r1 - r0, T)) if idx is None else np.asarray(idx)[r0:r1, :T]
        y = rng.random((r1 - r0, T, C), dtype=np.float32) < pr[j]
        a[r0:r1] = (coef[j] * y).sum(-1)
        ct[r0:r1] = cst[j]
        if ph is not None:
            yh = np.zeros((r1 - r0, T, C), np.float32)
            for _ in range(home_reps):
                yh += rng.random((r1 - r0, T, C), dtype=np.float32) < ph[j]
            ah[r0:r1] = (coef[j] * (yh / home_reps)).sum(-1)
    return a, ct, ah


# ===========================================================================
# Worlds for the checks at the boundary: the authors' reviewer model, the hetero model, review R6's
# own simulator (r6_dgp.make_world), and the study's own table
# ===========================================================================


def score_u(kind: str, x: np.ndarray) -> np.ndarray:
    """The normalised score u in [0, 1] of the retrieval mix from the stored ranking score x, by the
    arithmetic of msr.engine.u_of, for the kinds whose u is a function of x alone: value (u = clip(q,
    0, 1), x = q), credit (u = clip((c + 1)/2, 0, 1), x = c), counter with the smoothed ranking (x =
    (h + 1)/(h + g + 2) = u). Visits need the bank's largest count: not supported."""
    from msr import engine as EN
    x = np.asarray(x, dtype=float)
    if kind == "value":
        return EN.u_of("value", {"q": x})
    if kind == "credit":
        return EN.u_of("credit", {"c": x})
    if kind == "counter":
        return x
    raise ValueError(f"the first-shown version needs u from x; kind {kind!r} is not supported")


def shown_pair(u: np.ndarray, rel: np.ndarray, usable: np.ndarray, w_score: float) -> tuple:
    """(k, w), each (E,) int: the candidate shown first under KEEP (the old normalised scores u) and
    under WIPE (every score reset to its start value, so the mix is relevance only), computed by
    msr.engine.first_shown itself (mix w_score * u + (1 - w_score) * relevance; ties to the higher
    relevance, then to the candidate listed first) on a table whose 'outcome' is the candidate's
    position. -1 where a task has no usable candidate."""
    from msr import engine as EN
    u = np.asarray(u, dtype=float)
    usable = np.asarray(usable, dtype=bool) & np.isfinite(u) & np.isfinite(np.asarray(rel, dtype=float))
    E, C = u.shape
    cand = np.where(usable, np.arange(E * C).reshape(E, C), -1)
    pos = np.where(usable, np.broadcast_to(np.arange(C, dtype=float), (E, C)), np.nan)[..., None]
    T = EN.Table(cand, np.where(usable, np.asarray(rel, dtype=float), 0.0), pos)
    k = EN.first_shown(T, np.where(usable, u, 0.0).ravel(), w_score)[0]
    w = EN.first_shown(T, np.full(E * C, 0.5), w_score)[0]
    return (np.where(np.isfinite(k), k, -1).astype(int), np.where(np.isfinite(w), w, -1).astype(int))


def shown_coef(k: np.ndarray, w: np.ndarray, C: int) -> np.ndarray:
    """e (E, C): +1 at keep's first-shown candidate, -1 at wipe's, 0 elsewhere and on tasks where
    both arms show the same candidate; d = sum e y = y_keep - y_wipe is linear in the outcomes."""
    k, w = np.asarray(k), np.asarray(w)
    E = len(k)
    e = np.zeros((E, C))
    on = (k >= 0) & (w >= 0) & (k != w)
    r = np.flatnonzero(on)
    e[r, k[on]] += 1.0
    e[r, w[on]] -= 1.0
    return e


def _r6_module():
    """Review R6's simulator (paper/reviews/round2/r6_checks/r6_dgp.py), read-only; None if absent."""
    path = ROOT / "paper" / "reviews" / "round2" / "r6_checks" / "r6_dgp.py"
    if not path.exists():
        return None
    import importlib.util
    spec = importlib.util.spec_from_file_location("r6_dgp_readonly", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _finish_world(name, c, po, usable, u, rel, w_score, note, extra=None) -> dict:
    c = np.asarray(c, dtype=float)
    po = np.asarray(po, dtype=float)
    usable = np.asarray(usable, dtype=bool)
    k, w = shown_pair(u, rel, usable, w_score)
    e = shown_coef(k, w, c.shape[1])
    pz = np.where(usable, np.nan_to_num(po), 0.0)
    out = {"name": name, "c": c, "e": e, "p_owner": pz, "usable": usable, "note": note,
           "abar_home": float((c * pz).sum(-1).mean()), "gap_home": float((e * pz).sum(-1).mean()),
           "share_differ": float(np.mean(np.abs(e).sum(-1) > 0)), "tasks": int(len(c)),
           "n_usable": float(usable.sum(-1).mean())}
    if extra:
        out.update(extra)
    return out


def world_table(world: str, seed: int = 0, n_tasks: int = WORLD_TASKS, kappa: float = 0.75,
                w_score: float = 0.5) -> dict | None:
    """A task table of one world: {"c" (P, 4), "e" (first-shown coefficients), "p_owner", "usable",
    "abar_home", "gap_home", "share_differ", ...}. Relevance is uniform on (0, 1), independent of
    everything (none of these worlds has one); keep's mix uses u in [0, 1] from the scores.
    'reviewer': the authors' reviewer model (scores 4 > 3 > 2 > 1, u = 1, 2/3, 1/3, 0), n_tasks rows.
    'hetero': the hetero model (u = clip(x + 1/2, 0, 1)), n_tasks rows.
    'r6': review R6's simulator, make_world with one owner, one reader, one bank and one order
      (R6_WORLD); the 2,000 evaluation tasks of the bank are the task population (i.i.d. draws from
      them = tasks i.i.d. given the bank, theta_bank); u = clip((x + 2)/4, 0, 1); p_reader_kappa = the
      reader's chances mu_t with theta_pop = kappa EXACTLY (the item population), while its fixed-bank
      value differs (R6 W9). None when r6_dgp.py is absent."""
    rng = np.random.default_rng([seed, 7801, _seed_of("world", world) % (2 ** 32)])
    if world in ("reviewer", "hetero"):
        c, po, _, x = model_tasks(world, 1.0, (n_tasks,), rng, with_x=True)
        x = np.asarray(x, dtype=float)
        u = (x - 1.0) / 3.0 if world == "reviewer" else np.clip(x + 0.5, 0.0, 1.0)
        rel = rng.random((n_tasks, 4))
        return _finish_world(world, np.array(c), np.array(po), np.ones((n_tasks, 4), bool), u, rel, w_score,
                             "the authors' reviewer model" if world == "reviewer" else "the hetero task model")
    if world == "r6":
        mod = _r6_module()
        if mod is None:
            return None
        wd = mod.make_world(rng, ["o"], {"o": ["r"]}, kappa, **R6_WORLD)
        O = wd["swaps"][0]["orders"][0]
        x = np.asarray(O["x"], dtype=float)
        usable = np.ones(x.shape, bool)
        c, _ = stat_coefficients(x, usable)
        rel = rng.random(x.shape)
        u = np.clip((x + 2.0) / 4.0, 0.0, 1.0)
        pr_k = np.asarray(O["mu_t"], dtype=float)
        return _finish_world("r6", c, O["mu_s"], usable, u, rel, w_score,
                             f"review R6's simulator r6_dgp.make_world (kappa = theta_pop = {kappa:g}; one bank)",
                             {"p_reader_kappa": pr_k, "kappa": kappa,
                              "abar_swap_bank": float((c * pr_k).sum(-1).mean())})
    raise ValueError(f"unknown world {world!r} (reviewer, hetero, r6)")


def study_table(st, cells: dict) -> dict | None:
    """The practice study's own task table, pooled over the home cells (owner = reader): c from the
    headline family's scores, e from keep's and wipe's first-shown items (the study's w_score, the
    family's u), and the owner's chances: the simulator's truth when every model is simulated, else
    the plug-in mean of the owner's stored repeats (y_home and y_extra). None without home cells."""
    C_, E_, P_, U_, S_, R_ = [], [], [], [], [], []
    src = None
    for key, cell in sorted(cells.items()):
        if key[0] != key[1]:
            continue
        probs = sim_true_probs(st, key, cell) if getattr(st, "all_sim", False) else None
        reps = None
        if probs is not None:
            po = probs[1]
            src = "simulator truth"
        else:
            reps = [cell["y_home"]] + ([cell["y_extra"]] if cell.get("y_extra") is not None else [])
            po = _mean_rep(np.concatenate(reps, axis=-1))
            src = "plug-in: mean of the owner's stored repeats"
        usable = (cell["items"] != "") & np.isfinite(cell["x"]) & np.isfinite(po)
        c, n = stat_coefficients(cell["x"], usable)
        ok = n >= 2
        rel = cell.get("relevance")
        if rel is not None and cell.get("score_kind") in ("value", "credit", "counter"):
            k, w = shown_pair(score_u(cell["score_kind"], np.where(usable, cell["x"], 0.5)), rel, usable,
                              cell.get("w_score", 0.5))
            e = shown_coef(k, w, c.shape[1])
        else:
            e = np.zeros(c.shape)
        C_.append(c[ok])
        E_.append(e[ok])
        P_.append(np.where(usable, po, 0.0)[ok])
        U_.append(usable[ok])
        if probs is None:          # plug-in table: successes and repeats per cell, for unbiased moments
            yy = np.concatenate(reps, axis=-1)
            S_.append(np.where(usable[..., None], np.nan_to_num(yy), 0.0).sum(-1)[ok])
            R_.append(np.where(usable, np.isfinite(yy).sum(-1), 0)[ok])
    if not C_:
        return None
    c, e, po, usable = (np.concatenate(v) for v in (C_, E_, P_, U_))
    extra = {"succ": np.concatenate(S_), "nrep": np.concatenate(R_)} if S_ and len(S_) == len(C_) else {}
    return {**extra, "name": "study", "c": c, "e": e, "p_owner": np.clip(po, 0, 1), "usable": usable,
            "note": f"the practice study's home cells ({src})", "source": src,
            "abar_home": float((c * po).sum(-1).mean()), "gap_home": float((e * po).sum(-1).mean()),
            "share_differ": float(np.mean(np.abs(e).sum(-1) > 0)), "tasks": int(len(c)),
            "n_usable": float(usable.sum(-1).mean())}


def unbiased_v_at(W: dict, theta: float) -> np.ndarray | None:
    """(P, C) unbiased estimates of v = p1 (1 - p1) per cell for the reader table p1 = m + theta (p - m) of
    reader_at, from a PLUG-IN table's successes and repeats (W["succ"], W["nrep"]; None for a known table):
    p_j p_k (j != k) by the product of the cells' means (independent repeats), p_j^2 by S (S - 1) / (R (R - 1)).
    The table of observed means itself understates v (by a factor (R - 1) / R on average)."""
    if "succ" not in W:
        return None
    S_, R_ = np.asarray(W["succ"], float), np.asarray(W["nrep"], float)
    use = np.asarray(W["usable"], bool) & (R_ >= 2)
    ph = np.where(use, S_ / np.maximum(R_, 1), 0.0)
    U = np.where(use, S_ * (S_ - 1) / np.maximum(R_ * (R_ - 1), 1), 0.0)
    n = np.maximum(use.sum(-1, keepdims=True), 1)
    w_off = (1.0 - theta) / n                                   # weight of every usable candidate
    mean1 = theta * ph + w_off * ph.sum(-1, keepdims=True)      # E p1, unbiased
    # p1^2 = sum_j sum_k w_j w_k p_j p_k with w = w_off + theta on the cell itself
    tot = (w_off * ph).sum(-1, keepdims=True)                   # sum_j w_off p_j
    lin = theta * ph + tot                                      # sum_j w_j p_hat_j
    sq_hat = (w_off ** 2 * ph ** 2).sum(-1, keepdims=True) + (2 * theta * w_off + theta ** 2) * ph ** 2
    sq_unb = (w_off ** 2 * U).sum(-1, keepdims=True) + (2 * theta * w_off + theta ** 2) * U
    p1sq = lin ** 2 - sq_hat + sq_unb
    return np.where(use, mean1 - p1sq, 0.0)


def reader_at(W: dict, theta: float) -> np.ndarray:
    """The reader table whose ranking value AND first-shown gap are exactly theta times the owner's on
    every task: m_tau + theta (p_owner - m_tau) over the usable candidates (shrink_table; both c and e
    sum to 0 within a task)."""
    return np.nan_to_num(shrink_table(W["p_owner"], W["usable"].astype(float), theta))


def boundary_table(W: dict, coef: np.ndarray, target: float, kind: str) -> tuple:
    """(p0, how): a reader table with mean sum coef * p0 = target EXACTLY. 'reviewer' and 'hetero' at
    target 0: theta = 0 (every candidate at the task's mean chance; E[. | tau] = 0 on every task);
    otherwise the least-favourable table (the null closest in KL to the owner's, or to the R6 world's
    kappa reader), whose tasks are heterogeneous."""
    if W["name"] in ("reviewer", "hetero") and target == 0.0:
        return reader_at(W, 0.0), "theta = 0: every candidate at the task's mean chance"
    base = W.get("p_reader_kappa", W["p_owner"])
    _, q = least_favourable(base, coef, target)
    q = np.where(np.isfinite(q), q, np.nan_to_num(base))
    return q, ("least-favourable projection of the " + ("kappa reader" if "p_reader_kappa" in W else "owner's table")
               + f" onto mean {kind} = {target:g}")


def boundary_check(models=("reviewer", "hetero", "r6"), thetas_keep=BOUNDARY_THETAS_KEEP,
                   thetas_drop=BOUNDARY_THETAS_DROP, n_reps: int = BOUNDARY_REPS,
                   checkpoints=BOUNDARY_TASKS, n_homes=(HOME_TASKS, HOME_TASKS_FLOOR), alpha: float = ALPHA,
                   bet: str = BET, rho_keep: float = RHO_KEEP, rho_drop: float = RHO_DROP, seed: int = 0,
                   rules=RULES, n_cal: int = CALIB_TASKS) -> list:
    """False KEEP (at thetas_keep) and false DROP (at thetas_drop) by 100 ... 6,000 tasks, with the home
    value ESTIMATED and a FRESH home result for every task (no store, so the store never binds).
    'sequential' is the full rule of Proposition 1 (fixed): the paired test gated by the home flag
    computed on n_cal fresh calibration tasks per replication (same task distribution, disjoint from
    the stream); 'sequential_ungated' the paired test alone (its own level, any Abar_home > 0). The
    comparison rules draw a fresh home sample of n_home tasks per replication. Worlds: the authors'
    reviewer and hetero models (exact laws) and review R6's simulator (one bank; the reader table is
    the least-favourable projection of its kappa = theta reader onto Abar_swap = theta Abar_home of the
    bank EXACTLY). error_rate = the share of replications whose KEEP (DROP) has fired by that task, an
    upper bound on the false-keep (false-drop) rate. mc_se = sqrt(r (1 - r) / n) (and at alpha)."""
    horizon = max(checkpoints)
    rows = []
    for mi, model in enumerate(models):
        W = None
        if model == "r6":
            W = world_table("r6", seed=seed, kappa=0.75)
            if W is None:
                continue
            abar = W["abar_home"]
        else:
            abar = model_abar_home(model)

        def streams(th, R, T, rng):
            if W is None:
                return model_streams(model, th, R, T, rng)
            pr, _ = boundary_table(W, W["c"], th * abar, "A")
            a, _, ah = table_streams(W["c"], pr, R, T, rng, p_home=W["p_owner"])
            return a, ah

        def cal_flags(rng):
            if W is None:
                _, hs = model_streams(model, 1.0, n_reps, n_cal, rng)
            else:
                _, _, hs = table_streams(W["c"], W["p_owner"], n_reps, n_cal, rng, p_home=W["p_owner"])
            return np.array([home_signal_flag(h)[0] for h in hs.astype(float)])

        flags = cal_flags(np.random.default_rng([seed, 7407, mi])) if "sequential" in rules else None
        homes = {}
        for n_home in (n_homes if any(r not in ("sequential", "sequential_ungated") for r in rules) else ()):
            hrng = np.random.default_rng([seed, 7405, mi, n_home])
            _, hs = streams(1.0, n_reps, n_home, hrng)
            hs = hs.astype(float)
            homes[n_home] = {"hat": hs.mean(1), "hi": betting_bound(hs, alpha / 2.0, upper=True),
                             "lo": betting_bound(hs, alpha / 2.0, upper=False),
                             "se_over_abar": float(hs.std(ddof=1, axis=1).mean() / math.sqrt(n_home) / abar)}
        for test, thetas in (("keep", thetas_keep), ("drop", thetas_drop)):
            side = +1 if test == "keep" else -1
            rho = rho_keep if test == "keep" else rho_drop
            for th in thetas:
                rng = np.random.default_rng([seed, 7406, mi, int(round(th * 1000)), side + 1])
                a_s, a_h = streams(th, n_reps, horizon, rng)
                x_s = to_unit(a_s).astype(np.float32)
                hits = []
                if "sequential" in rules:
                    t_p = crossing_time(paired_unit(a_s, a_h, rho), 0.5, side, alpha, bet)
                    hits.append(("sequential", "", np.where(flags, t_p, horizon + 1)))
                    hits.append(("sequential_ungated", "", t_p))
                for n_home in homes:
                    h = homes[n_home]
                    if "sequential_plugin" in rules:
                        hits.append(("sequential_plugin", n_home,
                                     crossing_time(x_s, to_unit(np.clip(rho * h["hat"], -0.999, 0.999)), side, alpha, bet)))
                    if "sequential_split" in rules:
                        hb = h["hi"] if test == "keep" else h["lo"]
                        hits.append(("sequential_split", n_home,
                                     crossing_time(x_s, to_unit(np.clip(rho * hb, -0.999, 0.999)), side, alpha / 2.0, bet)))
                for rule, n_home, t_hit in hits:
                    for t in checkpoints:
                        r = float(np.mean(t_hit <= t))
                        rows.append({"model": model, "abar_home": abar, "rule": rule,
                                     "note": RULE_NOTE.get(rule, "paired test without the home flag"),
                                     "n_home": n_home,
                                     "home_se_over_abar": homes[n_home]["se_over_abar"] if n_home else "",
                                     "flag_tasks": n_cal if rule == "sequential" else "",
                                     "flag_positive_share": float(flags.mean()) if rule == "sequential" else "",
                                     "test": test, "theta": th, "rho": rho, "alpha": alpha, "bet": bet,
                                     "replications": n_reps, "by_task": t, "error_rate": r,
                                     "mc_se": math.sqrt(max(r * (1 - r), 1e-12) / n_reps),
                                     "mc_se_at_alpha": math.sqrt(alpha * (1 - alpha) / n_reps),
                                     "within_alpha_3se": bool(r <= alpha + 3 * math.sqrt(alpha * (1 - alpha) / n_reps))})
    return rows


# ===========================================================================
# The margin-0 (break-even) checks, the store and the sign gate
# ===========================================================================


def _cost(W: dict, version: str) -> np.ndarray:
    """Checks per task: ranking = one per usable candidate; first-shown = 2 where keep and wipe show
    different items, 0 where they show the same one."""
    if version == "ranking":
        return W["usable"].sum(-1)
    return 2 * (np.abs(W["e"]).sum(-1) > 0)


def _checks_used(ct: np.ndarray, used: np.ndarray) -> np.ndarray:
    cum = np.cumsum(ct.astype(np.int64), axis=1)
    idx = np.clip(np.asarray(used) - 1, 0, ct.shape[1] - 1)
    return np.where(np.asarray(used) > 0, np.take_along_axis(cum, idx[:, None], axis=1)[:, 0], 0)


def margin0_rows(worlds: dict, n_boundary: int = MARGIN0_REPS, n_needed: int = 1000,
                 checkpoints=MARGIN0_TASKS, thetas=MARGIN0_THETAS, horizon: int = LONG_CAP,
                 alpha: float = ALPHA, bet: str = BET, seed: int = 0, power: float = 0.8) -> list:
    """sequential_margin0.csv. For each world {name: world_table / study_table dict} and both versions
    (ranking: A_swap; first_shown: d = y_keep - y_wipe):
    part 'boundary': the reader table at E = 0 EXACTLY (boundary_table), fresh checks, tasks i.i.d. from
      the table; the share of streams whose KEEP (WIPE) test has fired by each check-point = the
      false-keep (false-wipe) rate if one stopped there or earlier; mc_se = sqrt(r (1 - r) / n).
    part 'needed': the reader at theta times the home signal (reader_at; signal = theta * Abar_home or
      theta * the keep-minus-wipe gap); tasks and checks to a decision (median with undecided counted
      as horizon + 1, mean capped at the horizon), shares; beside them the information lower bound for
      the same signal against the least-favourable reader with E <= 0 (Theorem 2, exact and second
      order; uniform scheme of that version), with its four qualifiers."""
    rows = []
    dkl = float(binary_kl(power, alpha))
    for wi, (name, W) in enumerate(worlds.items()):
        if W is None:
            continue
        for version in ("ranking", "first_shown"):
            coef = W["c"] if version == "ranking" else W["e"]
            if version == "first_shown" and W["share_differ"] <= 0:
                continue
            cost = _cost(W, version)
            scheme = SCHEME_UNIFORM if version == "ranking" else SCHEME_FIRST
            home_sig = W["abar_home"] if version == "ranking" else W["gap_home"]
            base = {"world": name, "world_note": W["note"], "version": version, "rule": f"margin0_{version}",
                    "alpha": alpha, "bet": bet, "scheme": scheme, "home_signal": home_sig,
                    "abar_home": W["abar_home"], "gap_home": W["gap_home"], "share_differ": W["share_differ"],
                    "mean_checks_per_task": float(cost.mean()), "table_tasks": W["tasks"]}
            rng = np.random.default_rng([seed, 7701, wi, version == "ranking"])
            p0, how = boundary_table(W, coef, 0.0, "A" if version == "ranking" else "d")
            true_mean = float((coef * p0).sum(-1).mean())
            a, ct, _ = table_streams(coef, p0, n_boundary, max(checkpoints), rng, cost=cost)
            _, _, tk, td = decide_margin0(a, alpha, bet)
            for test, th in (("keep", tk), ("wipe", td)):
                for t in checkpoints:
                    r = float(np.mean(th <= t))
                    rows.append({**base, "part": "boundary", "null": how, "true_mean": true_mean, "test": test,
                                 "replications": n_boundary, "by_task": t, "error_rate": r,
                                 "mc_se": math.sqrt(max(r * (1 - r), 1e-12) / n_boundary),
                                 "mc_se_at_alpha": math.sqrt(alpha * (1 - alpha) / n_boundary),
                                 "within_alpha_3se": bool(r <= alpha + 3 * math.sqrt(alpha * (1 - alpha) / n_boundary))})
            for th in thetas:
                p1 = reader_at(W, th)
                sig = float((coef * p1).sum(-1).mean())
                a, ct, _ = table_streams(coef, p1, n_needed, horizon, rng, cost=cost)
                dec, used, _, _ = decide_margin0(a, alpha, bet)
                stopped = dec != UNDECIDED
                chk = _checks_used(ct, np.minimum(used, horizon))
                k_lf, _ = least_favourable(p1, coef, 0.0, iters=80)
                e_s2 = float((coef ** 2 * p1 * (1 - p1)).sum(-1).mean())
                k2 = sig ** 2 / (2.0 * e_s2) if e_s2 > 0 else NAN
                keep = float(np.mean(dec == KEEP))
                b = dkl / k_lf if k_lf > 0 else NAN
                b_exact_table = b
                basis = "exact (least-favourable null) at the table's chances (" + str(W.get("source", W["note"])) + ")"
                vu = unbiased_v_at(W, th)
                if vu is not None:         # plug-in table: the exact bound on it is biased; report the second order
                    e_s2 = float((coef ** 2 * vu).sum(-1).mean())
                    k2 = sig ** 2 / (2.0 * e_s2) if e_s2 > 0 else NAN
                    k_lf = k2
                    b = dkl / k2 if k2 > 0 else NAN
                    basis = ("second order from unbiased moments of the owner's repeats (plug-in table: the exact "
                             "bound is not estimable from a few repeats per cell)")
                cm = float(np.abs(coef).max()) if coef.size else NAN
                fl_ = bound_floor(abs(sig), e_s2, 1.0, 0.0, cm, alpha, power) if sig != 0 else {"kappa": NAN}
                med = float(np.median(np.where(stopped, used, horizon + 1)))
                rows.append({**base, "part": "needed", "theta": th, "signal": sig, "e_sigma2": e_s2,
                             "replications": n_needed, "horizon": horizon,
                             "keep_share": keep, "wipe_share": float(np.mean(dec == DROP)),
                             "undecided_share": float(np.mean(~stopped)),
                             "tasks_median": med, "tasks_mean": float(np.mean(np.minimum(used, horizon))),
                             "tasks_q10": float(np.percentile(np.where(stopped, used, horizon + 1), 10)),
                             "tasks_q90": float(np.percentile(np.where(stopped, used, horizon + 1), 90)),
                             "checks_median": float(np.median(np.where(stopped, chk, 10 ** 9))) if stopped.mean() >= 0.5
                             else NAN,
                             "checks_mean": float(np.mean(chk)),
                             "power": power, "kl_least_favourable": k_lf, "kl_chi2": k2,
                             "bound_tasks": b, "bound_checks": b * float(cost.mean()), "bound_basis": basis,
                             "bound_tasks_exact_on_table": b_exact_table,
                             "bound_tasks_floor": fl_["kappa"] * dkl / k2 if k2 > 0 else NAN,
                             "ratio_mean_to_bound": float(np.mean(np.minimum(used, horizon))) / (
                                 float(binary_kl(keep, alpha)) / k_lf) if keep > alpha and k_lf > 0 else NAN,
                             "median_note": "ratio_median_to_bound compares a MEDIAN with a bound on the mean",
                             "bound_tasks_chi2": dkl / k2 if k2 > 0 else NAN,
                             "bound_checks_chi2": dkl / k2 * float(cost.mean()) if k2 > 0 else NAN,
                             "bound_tasks_at_measured_power": float(binary_kl(keep, alpha)) / k_lf
                             if keep > alpha and k_lf > 0 else NAN,
                             "ratio_median_to_bound": med / b if b > 0 else NAN,
                             "qualifiers": _qualifiers(scheme, 0.0, th, W["abar_home"], e_s2, alpha, power)})
    return rows


def r6_pop_rows(n_worlds: int = 40, streams: int = 50, horizon: int = LONG_CAP, alpha: float = ALPHA,
                bet: str = BET, seed: int = 0) -> list:
    """Which theta the margin-0 test targets (R6 W9), in review R6's simulator: kappa = theta_pop = 0
    (the reader keeps nothing of the owner's item effects OVER THE ITEM POPULATION), a fresh bank per
    world. Each bank's own value E[A_swap] (theta_bank) is not 0; the test controls KEEP only where
    it is <= 0. Rows: per world the bank value and the KEEP share; a summary row."""
    rows = []
    vals, keeps = [], []
    for wi in range(n_worlds):
        W = world_table("r6", seed=seed + 1000 + wi, kappa=0.0)
        if W is None:
            return []
        pr = W["p_reader_kappa"]
        ev = float((W["c"] * pr).sum(-1).mean())
        a, _, _ = table_streams(W["c"], pr, streams, horizon, np.random.default_rng([seed, 7702, wi]))
        dec, _, _, _ = decide_margin0(a, alpha, bet)
        k = float(np.mean(dec == KEEP))
        vals.append(ev)
        keeps.append(k)
        rows.append({"part": "theta_pop", "world": "r6", "kappa": 0.0, "bank": wi, "bank_value": ev,
                     "keep_share": k, "streams": streams, "horizon": horizon})
    v, kk = np.array(vals), np.array(keeps)
    rows.append({"part": "theta_pop_summary", "world": "r6", "kappa": 0.0, "banks": n_worlds,
                 "share_banks_positive": float(np.mean(v > 0)), "bank_value_sd": float(v.std(ddof=1)),
                 "keep_share_all": float(kk.mean()),
                 "keep_share_banks_nonpositive": float(kk[v <= 0].mean()) if np.any(v <= 0) else NAN,
                 "note": "the betting test targets theta_bank (tasks i.i.d. given the bank): it keeps where the "
                         "bank's own value is positive even when theta_pop = 0"})
    return rows


def store_rows(store: int = STORE_REVIEWER, n_stores: int = 200, per_store: int = 10,
               horizons=STORE_HORIZONS, theta: float = RHO_KEEP, alpha: float = ALPHA, bet: str = BET,
               seed: int = 0, world: str = "hetero", W: dict | None = None,
               p_reader: np.ndarray | None = None) -> list:
    """sequential_store.csv: why the paired rule must stop at the home store (Proposition 1 (iv)).
    Population: a world table with Abar_swap = theta * Abar_home EXACTLY (theta = 0.75, the KEEP
    boundary). Each store holds `store` tasks drawn from the population, each with ONE stored home
    result (the mean of 2 home repeats); the reader's checks are fresh.
      'reuse': tasks drawn WITH replacement from the store up to max(horizons), the stored result re-used
        (review R6 C5d): the false-keep share by each horizon;
      'stop_at_reuse': the same streams through decide_keep_or_drop with the home ids: it stops at the
        first re-used home result (status 'home table exhausted');
      'without_replacement': the store's tasks in random order, each once, the rule stops at the store;
      'fresh': a fresh home result for every task (no store), the reference.
    p_reader: a reader table to use instead of reader_at(W, theta) (it must sit at the boundary)."""
    W = W if W is not None else world_table(world, seed=seed)
    po = np.asarray(W["p_owner"]).astype(np.float32)
    pr = (reader_at(W, theta) if p_reader is None else np.asarray(p_reader)).astype(np.float32)
    c = W["c"].astype(np.float32)
    P = len(c)
    H = max(horizons)
    R = n_stores * per_store
    rng = np.random.default_rng([seed, 7703, store])
    a_s = np.empty((R, H), np.float32)
    a_h = np.empty((R, H), np.float32)
    ids = np.empty((R, H), np.int32)
    w_s = np.empty((R, store), np.float32)
    w_h = np.empty((R, store), np.float32)
    for k in range(n_stores):
        st_idx = rng.integers(0, P, size=store)
        yh = ((rng.random((store, 4)) < po[st_idx]).astype(np.float32)
              + (rng.random((store, 4)) < po[st_idx]).astype(np.float32)) / 2
        ah_store = (c[st_idx] * yh).sum(-1)
        sl = slice(k * per_store, (k + 1) * per_store)
        j = rng.integers(0, store, size=(per_store, H))
        y = rng.random((per_store, H, 4), dtype=np.float32) < pr[st_idx][j]
        a_s[sl] = (c[st_idx][j] * y).sum(-1)
        a_h[sl] = ah_store[j]
        ids[sl] = j
        perm = np.argsort(rng.random((per_store, store)), axis=1)
        y2 = rng.random((per_store, store, 4), dtype=np.float32) < pr[st_idx][perm]
        w_s[sl] = (c[st_idx][perm] * y2).sum(-1)
        w_h[sl] = ah_store[perm]
    mcse = math.sqrt(alpha * (1 - alpha) / R)
    base = {"world": W["name"], "theta": theta, "abar_home": W["abar_home"], "store_tasks": store,
            "stores": n_stores, "streams": R, "alpha": alpha, "bet": bet, "mc_se_at_alpha": mcse}
    rows = []
    tk = crossing_time(paired_unit(a_s, a_h, RHO_KEEP), 0.5, +1, alpha, bet)
    for t in horizons:
        r = float(np.mean(tk <= t))
        rows.append({**base, "design": "reuse", "by_task": t, "false_keep": r,
                     "mc_se": math.sqrt(max(r * (1 - r), 1e-12) / R),
                     "note": "stored home results re-used (tasks with replacement from the store): NOT valid"})
    res = decide_keep_or_drop(a_s, a_h, True, home_ids=ids)
    r = float(np.mean(res["decision"] == KEEP))
    rows.append({**base, "design": "stop_at_reuse", "by_task": H, "false_keep": r,
                 "mc_se": math.sqrt(max(r * (1 - r), 1e-12) / R),
                 "exhausted_share": float(np.mean(res["status"] == STATUS_EXHAUSTED)),
                 "tasks_median": float(np.median(res["used"])),
                 "note": "the rule given the home ids stops at the first re-used home result"})
    res = decide_keep_or_drop(w_s, w_h, True, n_home=store)
    r = float(np.mean(res["decision"] == KEEP))
    rows.append({**base, "design": "without_replacement", "by_task": store, "false_keep": r,
                 "mc_se": math.sqrt(max(r * (1 - r), 1e-12) / R),
                 "exhausted_share": float(np.mean(res["status"] == STATUS_EXHAUSTED)),
                 "tasks_median": float(np.median(res["used"])),
                 "note": "each stored home result once, random order; the rule stops at the store (valid)"})
    a2, _, h2 = table_streams(W["c"], pr, R, H, np.random.default_rng([seed, 7704, store]), p_home=po)
    tk2 = crossing_time(paired_unit(a2, h2, RHO_KEEP), 0.5, +1, alpha, bet)
    for t in horizons:
        r = float(np.mean(tk2 <= t))
        rows.append({**base, "design": "fresh", "by_task": t, "false_keep": r,
                     "mc_se": math.sqrt(max(r * (1 - r), 1e-12) / R),
                     "note": "a fresh home result for every task (Proposition 1 (iv) holds)"})
    return rows


def r6_c5_population(seed: int = 0, n_tasks: int = 2000, theta: float = RHO_KEEP) -> dict:
    """Review R6's C5 task population (c5_betting.py, population()): levels U(0.15, 0.85), spreads 0 /
    0.1 / 0.3 (many tasks carry no signal), the owner's chances mu_s with a signal in score order, an
    independent model mu_b, and the reader mu_t = w mu_s + (1 - w) mu_b with w set so that Abar_swap =
    theta * Abar_home EXACTLY over the 2,000 tasks. As a world-table dict (c, p_owner, p_reader)."""
    rng = np.random.default_rng([seed, 7708])
    C4 = np.array([0.75, 0.25, -0.25, -0.75])
    lvl = rng.uniform(0.15, 0.85, n_tasks)
    spread = rng.choice([0.0, 0.1, 0.3], size=n_tasks, p=[0.4, 0.4, 0.2])
    item = np.sort(rng.uniform(-1, 1, (n_tasks, 4)), axis=1)[:, ::-1] * 0.6 + rng.uniform(-1, 1, (n_tasks, 4)) * 0.4
    mu_s = np.clip(lvl[:, None] + spread[:, None] * item, 0.02, 0.98)
    mu_b = np.clip(lvl[:, None] + spread[:, None] * rng.uniform(-1, 1, (n_tasks, 4)), 0.02, 0.98)
    ah, ab = (mu_s @ C4).mean(), (mu_b @ C4).mean()
    w = (theta * ah - ab) / (ah - ab)
    mu_t = w * mu_s + (1 - w) * mu_b
    c = np.tile(C4, (n_tasks, 1))
    return {"name": "r6_c5", "c": c, "p_owner": mu_s, "p_reader": mu_t, "abar_home": float(ah),
            "abar_swap": float((mu_t @ C4).mean()), "note": "review R6's C5 population (c5_betting.py)"}


def negative_home_table(seed: int = 0, n: int = 2000) -> dict:
    """Review R6's C5c counter-example population (c5_betting.py part (c)): 2,000 tasks, levels U(0.2,
    0.8), owner mu = clip(level - 0.04 (1.5, 0.5, -0.5, -1.5) + N(0, 0.05^2), 0.02, 0.98) (the old order
    is REVERSED for the owner: Abar_home about -0.10), reader mu = clip(level + N(0, 0.05^2)) (theta
    about +0.02 <= 0.75). Scores in order, coefficients (3, 1, -1, -3)/4."""
    rng = np.random.default_rng([seed, 7705])
    C4 = np.array([0.75, 0.25, -0.25, -0.75])
    lvl = rng.uniform(0.2, 0.8, n)
    mu_s = np.clip(lvl[:, None] - 0.04 * np.array([1.5, 0.5, -0.5, -1.5]) + rng.normal(0, 0.05, (n, 4)), 0.02, 0.98)
    mu_t = np.clip(lvl[:, None] + rng.normal(0, 0.05, (n, 4)), 0.02, 0.98)
    c = np.tile(C4, (n, 1))
    return {"c": c, "p_owner": mu_s, "p_reader": mu_t, "abar_home": float((c * mu_s).sum(-1).mean()),
            "abar_swap": float((c * mu_t).sum(-1).mean())}


def gate_rows(n_streams: int = 1000, horizon: int = 2000, cal_sizes=(24, CALIB_TASKS), alpha: float = ALPHA,
              bet: str = BET, seed: int = 0, n_tasks: int = WORLD_TASKS, n_flag: int = 4000) -> list:
    """sequential_gate.csv: the sign condition. (a) R6 C5c: Abar_home about -0.10, theta about +0.02:
    the ungated paired test keeps in almost every stream; the gated rule (home flag on n_cal fresh
    calibration tasks of the same population, disjoint from the stream) says 'not testable' instead.
    (b) the flag's size at Abar_home = 0 exactly (every candidate at its task's mean chance in the
    hetero world): the share of calibration samples whose flag is positive (nominal 0.023)."""
    T = negative_home_table(seed)
    rng = np.random.default_rng([seed, 7706])
    a_s, _, a_h = table_streams(T["c"], T["p_reader"], n_streams, horizon, rng, p_home=T["p_owner"])
    dec, _, _, _ = decide_paired(a_s, a_h)
    rows = [{"part": "counter_example", "rule": "sequential_ungated", "abar_home": T["abar_home"],
             "abar_swap": T["abar_swap"], "theta": T["abar_swap"] / T["abar_home"], "streams": n_streams,
             "horizon": horizon, "keep_share": float(np.mean(dec == KEEP)), "drop_share": float(np.mean(dec == DROP)),
             "not_testable_share": 0.0}]
    for n_cal in cal_sizes:
        _, _, hs = table_streams(T["c"], T["p_owner"], n_streams, n_cal, rng, p_home=T["p_owner"])
        flags = np.array([home_signal_flag(h)[0] for h in hs.astype(float)])
        res = decide_keep_or_drop(a_s, a_h, flags)
        rows.append({"part": "counter_example", "rule": "sequential", "flag_tasks": n_cal,
                     "abar_home": T["abar_home"], "abar_swap": T["abar_swap"], "theta": T["abar_swap"] / T["abar_home"],
                     "streams": n_streams, "horizon": horizon, "keep_share": float(np.mean(res["decision"] == KEEP)),
                     "drop_share": float(np.mean(res["decision"] == DROP)),
                     "not_testable_share": float(np.mean(res["decision"] == NOT_TESTABLE)),
                     "flag_positive_share": float(flags.mean())})
    # (c) revision 3 (review R7 W6): the reader at theta = 1 relative to the REVERSED home order (A_swap =
    # A_home < 0): E[D_d] = 0.75 A_home < 0, so the ungated DROP test drops almost always; the gate blocks it.
    a_s1, _, a_h1 = table_streams(T["c"], T["p_owner"], n_streams, horizon, rng, p_home=T["p_owner"])
    dec1, _, _, _ = decide_paired(a_s1, a_h1)
    rows.append({"part": "drop_counter_example", "rule": "sequential_drop_ungated", "abar_home": T["abar_home"],
                 "abar_swap": T["abar_home"], "theta": 1.0, "streams": n_streams, "horizon": horizon,
                 "keep_share": float(np.mean(dec1 == KEEP)), "drop_share": float(np.mean(dec1 == DROP)),
                 "not_testable_share": 0.0, "note": RULE_NOTE["sequential_drop_ungated"]})
    for n_cal in cal_sizes:
        _, _, hs = table_streams(T["c"], T["p_owner"], n_streams, n_cal, rng, p_home=T["p_owner"])
        flags = np.array([home_signal_flag(h)[0] for h in hs.astype(float)])
        res = decide_keep_or_drop(a_s1, a_h1, flags)
        rows.append({"part": "drop_counter_example", "rule": "sequential", "flag_tasks": n_cal,
                     "abar_home": T["abar_home"], "abar_swap": T["abar_home"], "theta": 1.0,
                     "streams": n_streams, "horizon": horizon, "keep_share": float(np.mean(res["decision"] == KEEP)),
                     "drop_share": float(np.mean(res["decision"] == DROP)),
                     "not_testable_share": float(np.mean(res["decision"] == NOT_TESTABLE)),
                     "flag_positive_share": float(flags.mean()), "note": NOT_TESTABLE_ACTION})
    Wh = world_table("hetero", seed=seed, n_tasks=n_tasks)
    p0 = reader_at(Wh, 0.0)
    for n_cal in cal_sizes:
        _, _, hs = table_streams(Wh["c"], p0, n_flag, n_cal, np.random.default_rng([seed, 7707, n_cal]), p_home=p0)
        flags = np.array([home_signal_flag(h)[0] for h in hs.astype(float)])
        r = float(flags.mean())
        rows.append({"part": "flag_size", "rule": "home flag (msr.metrics, z >= 2)", "flag_tasks": n_cal,
                     "abar_home": 0.0, "samples": n_flag, "flag_positive_share": r,
                     "mc_se": math.sqrt(max(r * (1 - r), 1e-12) / n_flag), "nominal": FLAG_SIZE_NOMINAL})
    return rows


def topic_block_order(values: np.ndarray, R: int, T: int, rng, block: int = ORDER_BLOCK) -> np.ndarray:
    """(R, T) task rows in TOPIC ORDER (a diagnostic of review R7 W8, never a registered design): blocks of
    `block` tasks drawn from the tasks with a positive value, then `block` from the others, alternating,
    each stream starting with a random side. `values` (P,): the task's true value of the tested statistic."""
    v = np.asarray(values, dtype=float)
    pos, neg = np.flatnonzero(v > 0), np.flatnonzero(v <= 0)
    if not len(pos) or not len(neg):
        raise ValueError("topic order needs tasks of both signs")
    out = np.empty((R, T), dtype=np.int64)
    for r in range(R):
        t, turn = 0, bool(rng.random() < 0.5)
        while t < T:
            n = min(block, T - t)
            out[r, t:t + n] = rng.choice(pos if turn else neg, size=n)
            t += n
            turn = not turn
    return out


def order_rows(n_streams: int = 1000, horizon: int = 2000, seed: int = 0, n_tasks: int = WORLD_TASKS,
               alpha: float = ALPHA, bet: str = BET, block: int = ORDER_BLOCK) -> list:
    """sequential_order.csv (revision 3, review R7 W8): the random-order condition is load-bearing. The hetero
    world's first-shown (decision) form at the break-even boundary EXACTLY (E[d] = 0: the least-favourable
    projection of the owner's table, whose tasks have values of both signs), checks
    of the same reader taken (a) in an order drawn at random by the harness, (b) in topic blocks
    (topic_block_order: `block` tasks with a positive keep-minus-wipe value, then `block` with a non-positive
    one): the share of streams whose KEEP (WIPE) test fires by the horizon."""
    W = world_table("hetero", seed=seed, n_tasks=n_tasks)
    _, q = least_favourable(W["p_owner"], W["e"], 0.0)       # E[d] = 0 exactly; tasks of both signs
    p0 = np.where(np.isfinite(q), q, W["p_owner"])
    how = "least-favourable projection of the owner's table onto E[d] = 0"
    val = (W["e"] * p0).sum(-1)
    rows = []
    for design in ("random", "topic_blocks"):
        rng = np.random.default_rng([seed, 7709, design == "random"])
        idx = None if design == "random" else topic_block_order(val, n_streams, horizon, rng, block)
        a, _, _ = table_streams(W["e"], p0, n_streams, horizon, rng, cost=_cost(W, "first_shown"), idx=idx)
        _, _, tk, td = decide_margin0(a, alpha, bet)
        for test, th in (("keep", tk), ("wipe", td)):
            r = float(np.mean(th <= horizon))
            rows.append({"part": "order", "world": "hetero", "version": "first_shown", "null": how,
                         "true_mean": float(val.mean()), "order": ORDER_HARNESS if design == "random" else
                         f"topic blocks of {block} tasks by the sign of the task's value ({ORDER_GIVEN})",
                         "test": test, "streams": n_streams, "horizon": horizon, "error_rate": r,
                         "mc_se": math.sqrt(max(r * (1 - r), 1e-12) / n_streams), "alpha": alpha})
    return rows


# ===========================================================================
# The information lower bound
# ===========================================================================


def binary_kl(p, q) -> np.ndarray:
    """d(p || q) = p log(p/q) + (1-p) log((1-p)/(1-q)), with 0 log 0 = 0 (elementwise)."""
    p = np.asarray(p, dtype=float)
    q = np.asarray(q, dtype=float)
    with np.errstate(divide="ignore", invalid="ignore"):
        t1 = np.where(p > 0, p * np.log(np.where(p > 0, p, 1.0) / q), 0.0)
        t2 = np.where(p < 1, (1 - p) * np.log(np.where(p < 1, 1 - p, 1.0) / (1 - q)), 0.0)
    return t1 + t2


def kl_tables(p1: np.ndarray, p0: np.ndarray, c: np.ndarray | None = None) -> float:
    """K = mean over tasks of sum_i kl_Bern(p1 || p0): the KL per task of one check per candidate
    (only cells with a nonzero coefficient, or all finite cells when c is None)."""
    p1 = np.asarray(p1, float)
    p0 = np.asarray(p0, float)
    use = np.isfinite(p1) & np.isfinite(p0) if c is None else (np.abs(np.asarray(c)) > 0)
    k = np.where(use, binary_kl(np.where(use, p1, 0.5), np.where(use, p0, 0.5)), 0.0)
    return float(k.sum(-1).mean())


def _lf_q(p: np.ndarray, k: np.ndarray) -> np.ndarray:
    """The root in [0, 1] of k q^2 - (1 + k) q + p = 0 (q = p at k = 0), in its stable form; where that form
    is 0 / 0 (p = 0 and k <= -1, a cell observed at 0 that the null pushes up) the other form,
    ((1 + k) - sqrt(disc)) / (2 k) = 1 + 1/k (revision 3: plug-in tables have such cells)."""
    p = np.asarray(p, dtype=float)
    k = np.asarray(k, dtype=float)
    disc = np.maximum((1.0 + k) ** 2 - 4.0 * k * p, 0.0)
    den = (1.0 + k) + np.sqrt(disc)
    with np.errstate(divide="ignore", invalid="ignore"):
        q1 = 2.0 * p / den
        q2 = np.where(k != 0, ((1.0 + k) - np.sqrt(disc)) / np.where(k != 0, 2.0 * k, 1.0), p)
    return np.where(den > 1e-12, q1, q2)


def least_favourable(p1: np.ndarray, c: np.ndarray, target: float, iters: int = 200) -> tuple:
    """(K, q): the null reader table q closest to p1 in KL, K = mean_tau sum_i kl(p1 || q), under the
    linear constraint mean_tau sum_i c q = target (Abar_swap of the null = theta_0 Abar_home). The
    Lagrange condition is (q - p)/(q (1 - q)) = -nu c per cell; g(nu) = mean sum c q(nu) decreases in
    nu, so nu is found by bisection (nu > 0 when the target is below the alternative's value: the
    KEEP null; nu < 0 for the DROP null)."""
    c = np.asarray(c, float)
    use = np.abs(c) > 0
    p = np.where(use, np.clip(np.nan_to_num(np.asarray(p1, float)), 0.0, 1.0), 0.5)

    def g(nu):
        return float((c * _lf_q(p, nu * c)).sum(-1).mean())

    g0 = g(0.0)
    if abs(g0 - target) < 1e-15:
        return 0.0, p
    if target < g0:
        lo, hi = 0.0, 1.0
        while g(hi) > target:
            hi *= 2.0
            if hi > 1e12:
                raise ValueError("target not reachable")
    else:
        lo, hi = -1.0, 0.0
        while g(lo) < target:
            lo *= 2.0
            if lo < -1e12:
                raise ValueError("target not reachable")
    for _ in range(iters):
        mid = (lo + hi) / 2.0
        if g(mid) > target:
            lo = mid
        else:
            hi = mid
    q = _lf_q(p, ((lo + hi) / 2.0) * c)
    return kl_tables(p, q, c), np.where(use, q, np.nan)


def shrink_table(p_owner: np.ndarray, c: np.ndarray, theta: float) -> np.ndarray:
    """m_tau + theta (p_owner - m_tau), m_tau = the task's mean chance over its usable candidates: a
    reader table whose statistic is exactly theta times the owner's on every task (the coefficients
    sum to 0). theta = 0.75 is review R3's 'shrink' null (0.6 + 0.75 d (...) in its model)."""
    c = np.asarray(c, float)
    use = np.abs(c) > 0
    p = np.where(use, np.nan_to_num(np.asarray(p_owner, float)), 0.0)
    m = p.sum(-1, keepdims=True) / np.maximum(use.sum(-1, keepdims=True), 1)
    return np.where(use, m + theta * (p - m), np.nan)


def a_distribution(c: np.ndarray, p: np.ndarray) -> tuple:
    """(values, probabilities) of the single-check statistic A = sum_i c_i y_i, y_i ~ Bern(p_i)
    independent, for a task drawn uniformly from the P rows of c, p (P, C): exact enumeration of
    the 2^C outcome patterns, merged over equal values."""
    c = np.asarray(c, float)
    P, C = c.shape
    use = np.abs(c) > 0
    p = np.where(use, np.nan_to_num(np.asarray(p, float)), 0.0)
    pats = np.array(list(itertools.product((0.0, 1.0), repeat=C)))      # (2^C, C)
    vals = c @ pats.T                                                     # (P, 2^C)
    pr = np.prod(np.where(pats[None, :, :] > 0, p[:, None, :], 1.0 - p[:, None, :]), axis=-1) / P
    v = np.round(vals.ravel(), 12)
    w = pr.ravel()
    uv, inv = np.unique(v, return_inverse=True)
    return uv, np.bincount(inv, weights=w)


def kinf(values: np.ndarray, probs: np.ndarray, m0: float, side: int = +1, iters: int = 200) -> tuple:
    """(K_inf, lam*): K_inf(P, m0) = inf KL(P || Q) over all Q on [0, 1] with mean <= m0 (side=+1;
    mean >= m0 for side=-1), by its dual (Honda and Takemura 2010)
        K_inf = max_{0 <= lam <= 1/m0} E_P log(1 + lam (X - m0))   (side=+1; mirror for side=-1),
    the best growth rate of a constant bet. values on the [0, 1] scale. Concave in lam: bisection
    on the derivative."""
    x = np.asarray(values, float)
    w = np.asarray(probs, float)
    w = w / w.sum()
    d = side * (x - m0)
    lam_max = 1.0 / m0 if side > 0 else 1.0 / (1.0 - m0)
    if float(np.dot(w, d)) <= 0:
        return 0.0, 0.0

    def deriv(lam):
        return float(np.dot(w, d / (1.0 + lam * d)))

    lo, hi = 0.0, lam_max * (1.0 - 1e-12)
    if deriv(hi) >= 0:
        lam = hi
    else:
        for _ in range(iters):
            mid = (lo + hi) / 2.0
            if deriv(mid) > 0:
                lo = mid
            else:
                hi = mid
        lam = (lo + hi) / 2.0
    with np.errstate(divide="ignore"):
        val = float(np.dot(w, np.log1p(lam * d)))
    return val, lam


def _solve_monotone(f, lo, hi, target, increasing=True, iters=200):
    for _ in range(iters):
        mid = (lo + hi) / 2.0
        if (f(mid) < target) == increasing:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2.0


def max_power(n_tasks: float, K: float, alpha: float = ALPHA) -> float:
    """The largest probability of the right decision at theta_1 that any rule using n tasks (fixed
    budget) with error <= alpha at theta_0 can have: the p > alpha with d(p || alpha) = n K
    (1 when n K >= d(1 || alpha) = log(1/alpha))."""
    b = n_tasks * K
    if b >= math.log(1.0 / alpha):
        return 1.0
    return _solve_monotone(lambda p: float(binary_kl(p, alpha)), alpha, 1.0, b, increasing=True)


def min_error_at_power(n_tasks: float, K: float, power: float = 0.8) -> float:
    """The smallest error at theta_0 that any rule using n tasks must accept to decide right at
    theta_1 with probability `power`: the a < power with d(power || a) = n K."""
    b = n_tasks * K
    return _solve_monotone(lambda a: float(binary_kl(power, a)), 1e-300, power, b, increasing=False)


def _z(p: float) -> float:
    from statistics import NormalDist
    return NormalDist().inv_cdf(p)


def plugin_sigma2(x: np.ndarray, y_home: np.ndarray, present: np.ndarray | None = None) -> dict:
    """Real-data plug-ins from the owner's two home repeats y_home (T, C, >= 2), no truth needed:
    Abar_home_hat = mean A(x, ybar); E[sigma^2] for the KEEP alternative (reader = owner) from the
    unbiased per-cell mu (1 - mu) = ybar - y1 y2; for the DROP alternative (theta_1 = 0: every
    candidate at the task mean m) from the unbiased m (1 - m) = mean_i ybar_i - (mean_i y1_i)(mean_i y2_i)."""
    y = np.asarray(y_home, float)[..., :2]
    usable = np.isfinite(x) & np.isfinite(y).all(-1)
    if present is not None:
        usable &= np.asarray(present, bool)
    c, n = stat_coefficients(x, usable)
    ok = n >= 2
    c, y, usable = c[ok], np.where(usable[ok][..., None], y[ok], 0.0), usable[ok]
    ybar = y.mean(-1)
    abar = float((c * ybar).sum(-1).mean())
    s_keep = float((c ** 2 * (ybar - y[..., 0] * y[..., 1])).sum(-1).mean())
    nu = np.maximum(usable.sum(-1), 1)
    m_hat = ybar.sum(-1) / nu
    mm = m_hat - (y[..., 0].sum(-1) / nu) * (y[..., 1].sum(-1) / nu)
    s_drop = float(((c ** 2).sum(-1) * mm).mean())
    return {"abar_home": abar, "e_sigma2_keep": s_keep, "e_sigma2_drop": s_drop, "tasks": int(ok.sum())}


def _measure(c, p_owner, p_reader, usable, n_streams, horizon, rng, alpha, bet, rho_keep, rho_drop,
             abar, rules=RULES, model: str | None = None, theta1: float | None = None) -> dict:
    """Stopping times of each rule on streams at the alternative (fresh checks, fresh home results),
    plus 'margin0': the one-sample break-even test (decide_margin0) on the same reader checks."""
    if model is not None:
        a_s, a_h = model_streams(model, theta1, n_streams, horizon, rng)
        _, hs = model_streams(model, 1.0, n_streams, HOME_TASKS, rng)
    else:
        a_s, a_h = bernoulli_pair_streams(c, p_reader, p_owner, n_streams, horizon, rng, usable=usable)
        _, hs = bernoulli_pair_streams(c, p_owner, p_owner, n_streams, HOME_TASKS, rng, usable=usable)
    hs = hs.astype(float)
    res = run_rules(a_s, a_h, rules, home_hat=abar, home_lo=betting_bound(hs, alpha / 2, upper=False),
                    home_hi=betting_bound(hs, alpha / 2, upper=True), rho_keep=rho_keep, rho_drop=rho_drop,
                    alpha=alpha, bet=bet)
    res["margin0"] = decide_margin0(a_s, alpha, bet)
    out = {}
    for rule, (dec, used, _, _) in res.items():
        stopped = dec != UNDECIDED
        out[rule] = {"median": float(np.median(np.where(stopped, used, horizon + 1))),
                     "mean_capped": float(np.mean(np.minimum(used, horizon))),
                     "keep": float(np.mean(dec == KEEP)), "drop": float(np.mean(dec == DROP)),
                     "undecided": float(np.mean(~stopped))}
    return out


def _kl_root(p: np.ndarray, kappa: float, down: np.ndarray, iters: int = 12) -> np.ndarray:
    """q on the given side of p (below where `down`, above elsewhere) with kl(p || q) = kappa,
    elementwise: safeguarded Newton steps inside a bisection bracket (f'(q) = (q - p) / (q (1 - q))),
    started at the second-order point p -/+ sqrt(2 kappa p (1 - p)); the end point (0 or 1) where that
    side cannot reach kappa."""
    p = np.clip(np.asarray(p, dtype=float), 0.0, 1.0)
    lo = np.where(down, 0.0, p)
    hi = np.where(down, p, 1.0)
    sgn = np.where(down, -1.0, 1.0)
    q = np.clip(p + sgn * np.sqrt(2.0 * kappa * p * (1 - p)), lo + 1e-15, hi - 1e-15)
    with np.errstate(divide="ignore", invalid="ignore", over="ignore"):
        for _ in range(iters):
            f = binary_kl(p, q) - kappa
            far = f > 0
            lo = np.where(down == far, q, lo)            # down & far: q too low; up & not far: q too low
            hi = np.where(down != far, q, hi)
            step = f * q * (1 - q) / (q - p)
            qn = q - step
            ok = np.isfinite(qn) & (qn > lo) & (qn < hi)
            q = np.where(ok, qn, (lo + hi) / 2.0)
    return q


def adaptive_constants(c: np.ndarray, p1: np.ndarray, target: float, iters: int = 40, exact: bool = True) -> dict:
    """The per-CHECK information constants of Theorem 2 (uniform scheme) and Theorem 2' (adaptive
    choice of cells) for the alternative table p1 against H0: mean_tau sum_i c q = target (on the
    side of target away from the alternative). Cells c = (task, candidate) with a_c = c / P.
      uniform_exact = K_lf / (checks per task), K_lf from least_favourable;
      uniform_chi2  = Delta^2 / (2 E sigma^2) / (checks per task);
      adaptive_exact = inf_{q in H0} max_c kl(p1_c || q_c) (minimax: the sup over allocations of a
        linear function is a max over cells), by equalising every movable cell's kl at kappa and
        bisecting kappa until sum a_c q_c(kappa) = target;
      adaptive_chi2 = Delta^2 / (2 (sum_c |a_c| sqrt(v_c))^2), v = p1 (1 - p1), optimal w_c proportional
        to |a_c| sqrt(v_c);
    factor_* = adaptive / uniform per check = how many times smaller the lower bound in CHECKS is for
    a rule that may choose cells. Delta = sum a p1 - target. exact=False skips the two exact constants
    (NaN; the second-order ones are closed forms)."""
    c = np.asarray(c, dtype=float)
    P = c.shape[0]
    use = np.abs(c) > 0
    p = np.where(use, np.clip(np.nan_to_num(np.asarray(p1, dtype=float)), 0.0, 1.0), 0.5)
    a = (c / P)[use]
    pc = p[use]
    g0 = float((a * pc).sum())
    delta = g0 - float(target)
    checks = float(use.sum(-1).mean())
    v = pc * (1.0 - pc)
    s_abs = float((np.abs(a) * np.sqrt(v)).sum())
    e_s2 = float((c ** 2 * np.where(use, p * (1 - p), 0.0)).sum(-1).mean())
    out = {"delta": delta, "checks_per_task": checks, "e_sigma2": e_s2, "s_abs": s_abs * P}
    if abs(delta) < 1e-15:
        return {**out, "uniform_exact": 0.0, "uniform_chi2": 0.0, "adaptive_exact": 0.0, "adaptive_chi2": 0.0,
                "factor_exact": NAN, "factor_chi2": NAN}
    uni_chi2 = delta ** 2 / (2.0 * e_s2) / checks if e_s2 > 0 else NAN
    ad_chi2 = delta ** 2 / (2.0 * s_abs ** 2) if s_abs > 0 else NAN
    if not exact:
        return {**out, "uniform_exact": NAN, "uniform_chi2": uni_chi2, "adaptive_exact": NAN, "adaptive_chi2": ad_chi2,
                "factor_exact": NAN, "factor_chi2": ad_chi2 / uni_chi2 if uni_chi2 > 0 else NAN}
    k_lf, _ = least_favourable(np.where(use, p, np.nan), c, float(target))
    down = (a > 0) if delta > 0 else (a < 0)

    def g(kappa):
        return float((a * _kl_root(pc, kappa, down)).sum())

    past = (lambda val: val <= target) if delta > 0 else (lambda val: val >= target)
    lo, hi = 0.0, 1.0
    while not past(g(hi)):
        hi *= 2.0
        if hi > 1e3:
            hi = NAN
            break
    if math.isfinite(hi):
        for _ in range(iters):
            mid = (lo + hi) / 2.0
            if past(g(mid)):
                hi = mid
            else:
                lo = mid
        k_ad = (lo + hi) / 2.0
    else:
        k_ad = NAN
    uni = k_lf / checks
    return {**out, "uniform_exact": uni, "uniform_chi2": uni_chi2, "adaptive_exact": k_ad, "adaptive_chi2": ad_chi2,
            "factor_exact": k_ad / uni if uni > 0 else NAN, "factor_chi2": ad_chi2 / uni_chi2 if uni_chi2 > 0 else NAN}


def floor_kappa(x) -> float:
    """kappa(x) = 1 - x - x^2 / 4 of Result F (module docstring) for x = t c_max < FLOOR_X_MAX; NaN beyond (no
    floor). Then the exact bound is at least kappa(x) times the second-order bound."""
    x = float(x)
    return 1.0 - x - x * x / 4.0 if (math.isfinite(x) and 0.0 <= x < FLOOR_X_MAX) else NAN


def bound_floor(abar: float, es2: float, th1: float, th0: float, c_max: float, alpha: float = ALPHA,
                power: float = 0.8) -> dict:
    """Result F: a GUARANTEED lower bound on the expected number of whole random tasks of any rule with error
    alpha at theta_0 and power at theta_1, from Abar_home and E sigma^2 at the alternative only (both
    unbiasedly estimable from two home repeats). {"t", "x", "kappa", "bound_tasks_chi2", "bound_tasks_floor"}."""
    dkl = float(binary_kl(power, alpha))
    delta = abs(th1 - th0) * abar
    if not (es2 > 0 and delta > 0):
        return {"t": NAN, "x": NAN, "kappa": NAN, "bound_tasks_chi2": NAN, "bound_tasks_floor": NAN}
    t = delta / es2
    x = t * c_max
    k = floor_kappa(x)
    b2 = dkl * 2.0 * es2 / delta ** 2
    return {"t": t, "x": x, "kappa": k, "bound_tasks_chi2": b2, "bound_tasks_floor": k * b2}


def lf_task_values(p1: np.ndarray, c: np.ndarray, theta0: float, p_home: np.ndarray | None = None,
                   iters: int = 120) -> dict:
    """The least-favourable problem with its per-task Lagrangian (the influence of K_lf by the envelope
    theorem): K = min_q mean_tau sum_i kl(p1 || q) subject to mean_tau sum_i c q = theta0 mean_tau sum_i c p_home
    (p_home = p1 when None, the KEEP and margin-0 alternatives). l_tau = sum_i kl(p1 || q) + nu (sum_i c q -
    theta0 sum_i c p_home); mean l = K at the optimum, and l - K is task tau's influence on K.
    {"K", "l" (P,), "nu", "q"}."""
    c = np.asarray(c, float)
    use = np.abs(c) > 0
    p = np.where(use, np.clip(np.nan_to_num(np.asarray(p1, float)), 0.0, 1.0), 0.5)
    ph = p if p_home is None else np.where(use, np.clip(np.nan_to_num(np.asarray(p_home, float)), 0.0, 1.0), 0.0)
    home_t = (c * np.where(use, ph, 0.0)).sum(-1)
    target = float(theta0) * float(home_t.mean())

    def g(nu):
        return float((c * _lf_q(p, nu * c)).sum(-1).mean())

    g0 = g(0.0)
    if abs(g0 - target) < 1e-15:
        return {"K": 0.0, "l": np.zeros(len(c)), "nu": 0.0, "q": p}
    if target < g0:
        lo, hi = 0.0, 1.0
        while g(hi) > target:
            hi *= 2.0
            if hi > 1e12:
                raise ValueError("target not reachable")
    else:
        lo, hi = -1.0, 0.0
        while g(lo) < target:
            lo *= 2.0
            if lo < -1e12:
                raise ValueError("target not reachable")
    for _ in range(iters):
        mid = (lo + hi) / 2.0
        if g(mid) > target:
            lo = mid
        else:
            hi = mid
    nu = (lo + hi) / 2.0
    q = _lf_q(p, nu * c)
    kl = np.where(use, binary_kl(p, np.where(use, q, 0.5)), 0.0).sum(-1)
    l_tau = kl + nu * ((c * q).sum(-1) - float(theta0) * home_t)
    return {"K": float(kl.mean()), "l": l_tau, "nu": nu, "q": np.where(use, q, np.nan)}


def _twoway_cov(cols: np.ndarray, task_keys, item_keys) -> np.ndarray:
    """Two-way (task id x write task) covariance of the pooled MEANS of the columns of `cols` (n, q), by THE
    variance of the study (msr.metrics.robust_variance, delete-one-cluster jackknife; one component). Task
    keys: stream|task id (pooled over orders and owners); item keys: stream|write task (manager's ruling E1:
    every statistic that pools more than one owner clusters a write task across owners)."""
    from msr import metrics as M
    X = np.asarray(cols, float).reshape(len(cols), -1)
    n = len(X)
    P = (X - X.mean(0)) / n
    res = M.robust_variance(P, np.asarray(task_keys), None if item_keys is None else np.asarray(item_keys),
                            np.zeros(n, dtype=np.int64))
    return np.atleast_2d(np.asarray(res["V"], float)), res


def exact_bound_twoway(p1: np.ndarray, c: np.ndarray, theta0: float, task_keys, item_keys,
                       p_home: np.ndarray | None = None, alpha: float = ALPHA, power: float = 0.8,
                       level: float = 0.95) -> dict:
    """The EXACT least-favourable bound d(power || alpha) / K_lf in tasks on a KNOWN chance table (a world or a
    simulated study's truth), with a two-way interval: K's influence values (lf_task_values) through
    msr.metrics.robust_variance (task id x write task within stream), a normal interval for log K (delta
    method), inverted for the bound. The interval describes which tasks and write tasks the table holds."""
    from statistics import NormalDist
    dkl = float(binary_kl(power, alpha))
    lf = lf_task_values(p1, c, theta0, p_home)
    K = lf["K"]
    if not K > 0:
        return {"bound_tasks": NAN, "bound_tasks_lo": NAN, "bound_tasks_hi": NAN, "K": K, "se_log": NAN}
    V, res = _twoway_cov(lf["l"][:, None], task_keys, item_keys)
    se = math.sqrt(max(V[0, 0], 0.0)) / K
    z = NormalDist().inv_cdf(0.5 + level / 2.0)
    b = dkl / K
    return {"bound_tasks": b, "bound_tasks_lo": b * math.exp(-z * se), "bound_tasks_hi": b * math.exp(z * se),
            "K": K, "se_log": se, "item_share": float(res["item_share"][0]) if np.ndim(res["item_share"]) else
            float(res["item_share"]), "G_task": res["G_task"], "G_items": res["G_items"]}


def chi2_floor_twoway(a: np.ndarray, s: np.ndarray, task_keys, item_keys, th1: float, th0: float, c_max: float,
                      alpha: float = ALPHA, power: float = 0.8, level: float = 0.95) -> dict:
    """The second-order bound B_chi2 = 2 d S / (Delta_theta^2 A^2) and the guaranteed floor kappa(x) B_chi2 from
    per-row plug-ins a (the home statistic of the two-repeat mean, A = mean a) and s (an unbiased estimate of
    the within-task variance at the alternative, S = mean s), with two-way intervals (task id x write task
    within stream, msr.metrics.robust_variance; delta method on the log scale). Rows of several owners share
    task ids and write tasks; the two-way variance counts that."""
    from statistics import NormalDist
    a = np.asarray(a, float)
    s = np.asarray(s, float)
    A, S = float(a.mean()), float(s.mean())
    out = bound_floor(A, S, th1, th0, c_max, alpha, power)
    V, _ = _twoway_cov(np.column_stack([a, s]), task_keys, item_keys)
    z = NormalDist().inv_cdf(0.5 + level / 2.0)
    nan = {"bound_tasks_chi2_lo": NAN, "bound_tasks_chi2_hi": NAN, "bound_tasks_floor_lo": NAN,
           "bound_tasks_floor_hi": NAN}
    if not (A != 0 and S > 0):
        return {**out, **nan, "abar_home": A, "e_sigma2": S}
    g = np.array([-2.0 / A, 1.0 / S])                         # d log B_chi2 / d (A, S)
    se2 = math.sqrt(max(float(g @ V @ g), 0.0))
    b2 = out["bound_tasks_chi2"]
    res = {**out, "abar_home": A, "e_sigma2": S, "se_log_chi2": se2,
           "bound_tasks_chi2_lo": b2 * math.exp(-z * se2), "bound_tasks_chi2_hi": b2 * math.exp(z * se2),
           "bound_tasks_floor_lo": NAN, "bound_tasks_floor_hi": NAN}
    k, x = out["kappa"], out["x"]
    if math.isfinite(k) and k > 0:
        dk = -(1.0 + x / 2.0) / k * x                          # d log kappa / d log x
        gf = g + dk * np.array([1.0 / A, -1.0 / S])            # x moves with A / S
        sef = math.sqrt(max(float(gf @ V @ gf), 0.0))
        bf = out["bound_tasks_floor"]
        res.update({"se_log_floor": sef, "bound_tasks_floor_lo": bf * math.exp(-z * sef),
                    "bound_tasks_floor_hi": bf * math.exp(z * sef)})
    return res


def _qualifiers(scheme: str, th0: float, th1: float, abar: float, es2: float, alpha: float, power: float) -> str:
    return (f"scheme: {scheme}; margin theta_0 = {th0:g} against theta_1 = {th1:g}; signal Abar_home = "
            f"{abar:.3f}, E sigma^2 = {es2:.3f}; alpha = {alpha:g}, power = {power:g}")


def bound_rows(setting: str, c: np.ndarray, p_owner: np.ndarray, usable: np.ndarray | None = None,
               alpha: float = ALPHA, powers=BOUND_POWERS, budgets=BOUND_BUDGETS, rho_keep: float = RHO_KEEP,
               rho_drop: float = RHO_DROP, measure: bool = True, n_streams: int = BOUND_REPS,
               horizon: int = BOUND_HORIZON, seed: int = 0, bet: str = BET, model: str | None = None,
               adaptive: bool = True) -> list:
    """sequential_bound.csv rows for one signal (tasks given by the coefficients c and the owner's
    true chances p_owner, (P, C)). keep: alternative theta_1 = 1 (reader = owner's table) against
    theta_0 = rho_keep; drop: theta_1 = 0 (reader chance = the task mean of the owner's chances in
    every candidate) against theta_0 = rho_drop; margin0: theta_1 = 1 against theta_0 = 0 (the
    break-even question; the least-favourable reader with E[A] <= 0). Universal bound (tests that see
    every check, the task and the scores, uniform scheme) from the least-favourable null; kl_shrink
    from review R3's shrink null; kl_chi2 the second-order closed form; kinf_A for tests that see only A
    (home known); fixed-z tasks for a one-sided z test on mean A (home known) and on mean D (paired);
    the adaptive constants of Theorem 2' (adaptive_*). Every row carries its four qualifiers (scheme,
    theta_0, the signal Abar_home and e_sigma2, alpha and power) and the measured ratio to the bound."""
    c = np.asarray(c, float)
    p_owner = np.asarray(p_owner, float)
    abar = float((c * np.where(np.abs(c) > 0, p_owner, 0.0)).sum(-1).mean())
    rows = []
    meas_by_th1 = {}
    for decision, th1, th0 in (("keep", 1.0, rho_keep), ("drop", 0.0, rho_drop), ("margin0", 1.0, 0.0)):
        side = -1 if decision == "drop" else +1
        p1 = shrink_table(p_owner, c, th1)
        p0s = shrink_table(p_owner, c, th0)
        k_lf, _ = least_favourable(p1, c, th0 * abar)
        k_sh = kl_tables(p1, p0s, c)
        pz1 = np.where(np.abs(c) > 0, p1, 0.0)
        pzo = np.where(np.abs(c) > 0, p_owner, 0.0)
        s2 = (c ** 2 * pz1 * (1 - pz1)).sum(-1)                 # within-task Bernoulli variance of A_s
        s2h = (c ** 2 * pzo * (1 - pzo)).sum(-1)                # ... of one home repeat
        e_s2 = float(s2.mean())
        k_chi2 = (th1 - th0) ** 2 * abar ** 2 / (2.0 * e_s2)
        vals, probs = a_distribution(c, pz1)
        m0 = (th0 * abar + 1.0) / 2.0
        k_a, _ = kinf(to_unit(vals), probs, m0, side)
        mu_s = (c * pz1).sum(-1)
        mu_h = (c * pzo).sum(-1)
        var_a = float(s2.mean() + mu_s.var())
        var_d = float(s2.mean() + th0 ** 2 * s2h.mean() / 2.0 + np.var(mu_s - th0 * mu_h))
        delta = abs(th1 - th0) * abar
        ad = adaptive_constants(c, pz1, th0 * abar) if adaptive else {}
        c_max = float(np.abs(c).max()) if c.size else NAN
        fl_ = bound_floor(abar, e_s2, th1, th0, c_max, alpha, 0.8)
        if measure and th1 not in meas_by_th1:
            rng = np.random.default_rng([seed, 7501, _seed_of("bound", setting), side + 1])
            meas_by_th1[th1] = _measure(c, p_owner, p1, usable, n_streams, horizon, rng, alpha, bet, rho_keep,
                                        rho_drop, abar, model=model, theta1=th1)
        meas = meas_by_th1.get(th1, {}) if measure else {}
        right = "drop" if decision == "drop" else "keep"
        main_rule = "margin0" if decision == "margin0" else "sequential"
        checks = float((np.abs(c) > 0).sum(-1).mean())
        for pw in powers:
            beta = 1.0 - pw
            dkl = float(binary_kl(pw, alpha))
            zz = _z(1 - alpha) + _z(pw)
            row = {"setting": setting, "decision": decision, "theta_1": th1, "theta_0": th0, "alpha": alpha,
                   "beta": beta, "power": pw, "abar_home": abar, "e_sigma2": e_s2, "scheme": SCHEME_UNIFORM,
                   "qualifiers": _qualifiers(SCHEME_UNIFORM, th0, th1, abar, e_s2, alpha, pw),
                   "sd_A": math.sqrt(var_a),
                   "sd_D": math.sqrt(var_d), "kl_least_favourable": k_lf, "kl_shrink": k_sh, "kl_chi2": k_chi2,
                   "kinf_A": k_a, "d_binary": dkl, "bound_tasks": dkl / k_lf,
                   "bound_tasks_shrink": dkl / k_sh, "bound_tasks_chi2": dkl / k_chi2,
                   "bound_tasks_A_only": dkl / k_a if k_a > 0 else NAN,
                   "bound_checks": CHECKS_PER_TASK * dkl / k_lf,
                   "bound_basis": "exact (least-favourable null, solved numerically) on a known chance table",
                   "exact_over_chi2": (dkl / k_lf) / (dkl / k_chi2) if k_lf > 0 and k_chi2 > 0 else NAN,
                   "floor_x": fl_["x"], "floor_kappa": fl_["kappa"],
                   "bound_tasks_floor": fl_["kappa"] * dkl / k_chi2 if k_chi2 > 0 else NAN,
                   "checks_per_task": checks,
                   "fixed_z_tasks": (zz * math.sqrt(var_a) / delta) ** 2,
                   "fixed_z_tasks_D": (zz * math.sqrt(var_d) / delta) ** 2}
            if ad:
                row.update({"adaptive_scheme": SCHEME_ADAPTIVE,
                            "kl_per_check_uniform": ad["uniform_exact"], "kl_per_check_adaptive": ad["adaptive_exact"],
                            "kl_per_check_uniform_chi2": ad["uniform_chi2"],
                            "kl_per_check_adaptive_chi2": ad["adaptive_chi2"],
                            "bound_checks_adaptive": dkl / ad["adaptive_exact"] if ad["adaptive_exact"] > 0 else NAN,
                            "bound_checks_adaptive_chi2": dkl / ad["adaptive_chi2"] if ad["adaptive_chi2"] > 0 else NAN,
                            "adaptive_factor": ad["factor_exact"], "adaptive_factor_chi2": ad["factor_chi2"]})
            for rule in RULES:
                m = meas.get(rule)
                tag = {"sequential": "paired", "sequential_plugin": "plugin_known_home",
                       "sequential_split": "split"}[rule]
                use_m = m if decision != "margin0" else None
                row[f"measured_{tag}_median"] = use_m["median"] if use_m else NAN
                row[f"measured_{tag}_mean"] = use_m["mean_capped"] if use_m else NAN
                row[f"measured_{tag}_right_share"] = use_m[right] if use_m else NAN
            m0 = meas.get("margin0") if decision == "margin0" else None
            row["measured_margin0_median"] = m0["median"] if m0 else NAN
            row["measured_margin0_mean"] = m0["mean_capped"] if m0 else NAN
            row["measured_margin0_right_share"] = m0["keep"] if m0 else NAN
            row["measured_margin0_median_checks"] = m0["median"] * checks if m0 else NAN
            m = meas.get(main_rule)
            if m and m[right] > alpha:
                b_at = float(binary_kl(m[right], alpha)) / k_lf
                row["bound_tasks_at_measured_power"] = b_at
                row["ratio_paired_mean_to_bound"] = m["mean_capped"] / b_at
            else:
                row["bound_tasks_at_measured_power"] = NAN
                row["ratio_paired_mean_to_bound"] = NAN
            row["ratio_median_to_bound"] = m["median"] / (dkl / k_lf) if m else NAN
            row["ratio_mean_to_bound_at_measured_power"] = row["ratio_paired_mean_to_bound"]
            row["comparison_note"] = ("the theorem bounds the MEAN: compare measured means (capped at the horizon, "
                                      "so themselves lower bounds) with the bound at the measured power; medians "
                                      "are reported apart") if meas else ""
            row["measured_rule"] = {"margin0": "margin0_ranking (one-sample)"}.get(decision, "sequential (paired)") \
                if meas else ""
            row["measured_horizon"] = horizon if meas else ""
            row["measured_streams"] = n_streams if meas else ""
            for n in budgets:
                row[f"max_power_{n}_tasks"] = max_power(n, k_lf, alpha)
            for n in budgets:
                row[f"min_error_at_power80_{n}_tasks"] = min_error_at_power(n, k_lf, 0.8)
            rows.append(row)
    return rows


def plugin_task_parts(x: np.ndarray, y_home: np.ndarray, present: np.ndarray | None = None, tasks=None,
                      items=None, stream: str = "") -> dict:
    """Per-task parts of plugin_sigma2 (owner's two home repeats): a (the statistic of the two-repeat
    mean), s_keep (sum c^2 (ybar - y1 y2), unbiased for the within-task variance at the KEEP and
    margin-0 alternative) and s_drop (sum c^2 times the unbiased m (1 - m), DROP alternative); c_max (the
    largest |c|). With tasks (T,) and items (T, C) (revision 3, ruling E1): "tk" = stream|task id and "ik" =
    stream|write task of every usable candidate (msr.theory.write_task_key), for the two-way interval."""
    y = np.asarray(y_home, float)[..., :2]
    usable = np.isfinite(x) & np.isfinite(y).all(-1)
    if present is not None:
        usable &= np.asarray(present, bool)
    c, n = stat_coefficients(x, usable)
    ok = n >= 2
    c, y, usable = c[ok], np.where(usable[ok][..., None], y[ok], 0.0), usable[ok]
    ybar = y.mean(-1)
    nu = np.maximum(usable.sum(-1), 1)
    mm = ybar.sum(-1) / nu - (y[..., 0].sum(-1) / nu) * (y[..., 1].sum(-1) / nu)
    out = {"a": (c * ybar).sum(-1), "s_keep": (c ** 2 * (ybar - y[..., 0] * y[..., 1])).sum(-1),
           "s_drop": (c ** 2).sum(-1) * mm, "c_max": float(np.abs(c).max()) if c.size else NAN}
    if tasks is not None and items is not None:
        from msr.theory import write_task_key
        tsk = np.asarray(tasks).astype(str)[ok]
        its = np.asarray(items).astype(str)[ok]
        out["tk"] = np.array([f"{stream}|{t}" for t in tsk.tolist()])
        out["ik"] = np.array([[write_task_key(i, stream) if u else "" for i, u in zip(row, urow)]
                              for row, urow in zip(its.tolist(), usable.tolist())])
    return out


def plugin_bound_interval(parts: list, owners: list, which: str = "keep", n_boot: int = BOUND_BOOT,
                          seed: int = 0, level: float = 0.95) -> dict:
    """The second-order plug-in bound B = 2 d E[sigma^2] / ((theta_1 - theta_0)^2 Abar_home^2) per unit
    of d / (theta_1 - theta_0)^2, as an ESTIMATE WITH AN INTERVAL: parts = one plugin_task_parts dict
    per home cell, owners = the cell's owner. Returns the point value g = E sigma^2 / Abar^2 x 2 (so B =
    d g / (theta_1 - theta_0)^2), the bias-corrected point (Abar^2 minus its estimated variance), the
    percentile interval of a task bootstrap stratified by cell (the owners held fixed) and of a
    two-stage bootstrap (owners resampled, then tasks within each cell). Abar_home enters squared,
    so the interval is wide and skewed when the signal is weak."""
    s_key = "s_keep" if which in ("keep", "margin0") else "s_drop"
    rng = np.random.default_rng([seed, 7601, len(parts)])
    n = np.array([len(p["a"]) for p in parts])
    N = n.sum()
    a_all = np.concatenate([p["a"] for p in parts])
    s_all = np.concatenate([p[s_key] for p in parts])
    abar, es2 = float(a_all.mean()), float(s_all.mean())
    var_abar = float(sum(np.var(p["a"], ddof=1) * len(p["a"]) for p in parts if len(p["a"]) > 1)) / N ** 2
    g = 2.0 * es2 / abar ** 2 if abar != 0 else NAN
    a2_bc = abar ** 2 - var_abar
    g_bc = 2.0 * es2 / a2_bc if a2_bc > 0 else NAN
    sa = np.zeros((n_boot, len(parts)))
    ss = np.zeros((n_boot, len(parts)))
    for k, p in enumerate(parts):
        idx = rng.integers(0, len(p["a"]), size=(n_boot, len(p["a"])))
        sa[:, k] = p["a"][idx].sum(1)
        ss[:, k] = p[s_key][idx].sum(1)
    with np.errstate(divide="ignore", invalid="ignore"):
        gb = 2.0 * (ss.sum(1) / N) / (sa.sum(1) / N) ** 2
    uo = sorted(set(owners))
    om = np.array([[1.0 if owners[k] == o else 0.0 for k in range(len(parts))] for o in uo])   # (O, cells)
    pick = rng.integers(0, len(uo), size=(n_boot, len(uo)))
    w = om[pick].sum(1)                                                                       # (B, cells)
    with np.errstate(divide="ignore", invalid="ignore"):
        go = 2.0 * ((w * ss).sum(1) / (w * n).sum(1)) / ((w * sa).sum(1) / (w * n).sum(1)) ** 2
    q = (100 * (1 - level) / 2, 100 * (1 + level) / 2)
    out = {"abar_home": abar, "e_sigma2": es2, "abar_se": math.sqrt(max(var_abar, 0.0)), "g": g, "g_bc": g_bc,
           "g_lo": float(np.nanpercentile(gb, q[0])), "g_hi": float(np.nanpercentile(gb, q[1])),
           "g_owner_lo": float(np.nanpercentile(go, q[0])), "g_owner_hi": float(np.nanpercentile(go, q[1])),
           "tasks": int(N), "cells": len(parts), "owners": len(uo), "n_boot": n_boot,
           "c_max": float(np.nanmax([p.get("c_max", NAN) for p in parts])) if parts else NAN,
           "which": which, "s_key": s_key}
    if parts and all("tk" in p and "ik" in p for p in parts):
        # revision 3 (ruling E1): the REGISTERED interval pools owners, so it is two-way (task id x write task
        # within stream); the bootstrap above (tasks within cells, owners fixed) stays as a cross-check
        out["_rows"] = (a_all, s_all, np.concatenate([p["tk"] for p in parts]),
                        np.concatenate([p["ik"] for p in parts]))
        tw = chi2_floor_twoway(*out["_rows"], 1.0, 0.0, out["c_max"], level=level)
        if math.isfinite(tw.get("se_log_chi2", NAN)):
            from statistics import NormalDist
            zz = NormalDist().inv_cdf(0.5 + level / 2.0)
            out["g_lo_2way"] = g * math.exp(-zz * tw["se_log_chi2"])
            out["g_hi_2way"] = g * math.exp(zz * tw["se_log_chi2"])
            out["se_log_g_2way"] = tw["se_log_chi2"]
    return out


def plugin_bound_rows(setting: str, est: dict, curve_rows: list, alpha: float = ALPHA,
                      powers=BOUND_POWERS, budgets=BOUND_BUDGETS, rho_keep: float = RHO_KEEP,
                      rho_drop: float = RHO_DROP, intervals: dict | None = None, margin0_rows: list | None = None) -> list:
    """Bound rows from real-data plug-ins (no truth): the closed form K ~ (theta_1 - theta_0)^2
    Abar_home^2 / (2 E[sigma^2]) with plugin_sigma2's estimates, now with a 95 % interval
    (plugin_bound_interval: `intervals` = {"keep": ..., "drop": ...}); the measured stopping times are
    the curve's (paired rule at theta = 1 and 0) and, for margin0, the one-sample test's on the study
    table at the home signal (sequential_margin0.csv)."""
    rows = []
    cur = {(r["source"], float(r["theta"])): r for r in curve_rows}
    m0 = {}
    for r in margin0_rows or []:
        if r.get("part") == "needed" and r.get("world") == "study" and r.get("version") == "ranking" \
                and abs(float(r["theta"]) - 1.0) < 1e-9:
            m0 = r
    for decision, th1, th0, s2 in (("keep", 1.0, rho_keep, est["e_sigma2_keep"]),
                                   ("drop", 0.0, rho_drop, est["e_sigma2_drop"]),
                                   ("margin0", 1.0, 0.0, est["e_sigma2_keep"])):
        k = (th1 - th0) ** 2 * est["abar_home"] ** 2 / (2.0 * s2) if s2 > 0 else NAN
        cr = cur.get(("sequential", th1)) if decision != "margin0" else None
        iv = (intervals or {}).get("drop" if decision == "drop" else "keep")
        c_max = (iv or {}).get("c_max", 0.75)
        if not math.isfinite(c_max):
            c_max = 0.75
        for pw in powers:
            dkl = float(binary_kl(pw, alpha))
            fl_ = bound_floor(est["abar_home"], s2, th1, th0, c_max, alpha, pw)
            tw = chi2_floor_twoway(*iv["_rows"], th1, th0, c_max, alpha, pw) if iv and "_rows" in iv else {}
            row = {"setting": setting, "decision": decision, "theta_1": th1, "theta_0": th0, "alpha": alpha,
                   "beta": 1 - pw, "power": pw, "abar_home": est["abar_home"], "e_sigma2": s2,
                   "scheme": SCHEME_UNIFORM, "qualifiers": _qualifiers(SCHEME_UNIFORM, th0, th1, est["abar_home"], s2,
                                                                       alpha, pw) + "; plug-in estimate",
                   "kl_chi2": k, "d_binary": dkl, "bound_tasks_chi2": dkl / k if k > 0 else NAN,
                   "bound_tasks": NAN, "bound_checks": CHECKS_PER_TASK * dkl / k if k > 0 else NAN,
                   "bound_basis": "second order (an approximation) from unbiased plug-ins of the owner's two home "
                                  "repeats; the exact bound is not estimable from a few repeats per cell",
                   "bound_tasks_floor": fl_["bound_tasks_floor"], "floor_kappa": fl_["kappa"], "floor_x": fl_["x"],
                   "floor_note": "guaranteed: the exact bound is at least this (Result F); none when x >= 0.83",
                   "measured_paired_median": float(cr["tasks_q50"]) if cr else NAN,
                   "measured_paired_mean": float(cr["tasks_mean_capped"]) if cr else NAN,
                   "measured_horizon": int(cr["horizon"]) if cr else "", "pool_tasks": est["tasks"]}
            if decision == "margin0" and m0:
                row["measured_margin0_median"] = float(m0["tasks_median"])
                row["measured_margin0_mean"] = float(m0["tasks_mean"])
                row["measured_margin0_median_checks"] = float(m0["checks_median"])
                row["measured_horizon"] = int(float(m0["horizon"]))
            med = row.get("measured_margin0_median") if decision == "margin0" else row["measured_paired_median"]
            row["ratio_median_to_bound"] = med / row["bound_tasks_chi2"] if med and k > 0 else NAN
            # the theorem bounds the MEAN: the measured mean (capped at the horizon, so itself a lower bound on
            # the mean) against the bound at the rule's measured power; the median is reported apart
            right = NAN
            if decision == "margin0" and m0:
                right = _f(m0.get("keep_share"))
                mean_ = row.get("measured_margin0_mean", NAN)
            elif cr:
                right = _f(cr.get("keep_share" if decision == "keep" else "drop_share"))
                mean_ = row["measured_paired_mean"]
            else:
                mean_ = NAN
            row["measured_right_share"] = right
            if math.isfinite(right) and right > alpha and k > 0:
                b_at = float(binary_kl(min(right, 1.0), alpha)) / k
                row["bound_tasks_chi2_at_measured_power"] = b_at
                row["ratio_mean_to_bound_chi2"] = mean_ / b_at if math.isfinite(_f(mean_)) else NAN
                if math.isfinite(fl_["kappa"]):
                    row["ratio_mean_to_floor"] = mean_ / (fl_["kappa"] * b_at) if math.isfinite(_f(mean_)) else NAN
            row["median_note"] = "ratio_median_to_bound compares a MEDIAN with a bound on the mean: descriptive only"
            if iv:
                f = dkl / (th1 - th0) ** 2
                two = math.isfinite(_f(tw.get("bound_tasks_chi2_lo", NAN)))
                lo2 = tw["bound_tasks_chi2_lo"] if two else f * iv["g_lo"]
                hi2 = tw["bound_tasks_chi2_hi"] if two else f * iv["g_hi"]
                row.update({"bound_tasks_chi2_lo": lo2, "bound_tasks_chi2_hi": hi2,
                            "bound_tasks_chi2_boot_lo": f * iv["g_lo"], "bound_tasks_chi2_boot_hi": f * iv["g_hi"],
                            "bound_tasks_chi2_bias_corrected": f * iv["g_bc"],
                            "bound_tasks_chi2_owner_lo": f * iv["g_owner_lo"],
                            "bound_tasks_chi2_owner_hi": f * iv["g_owner_hi"],
                            "bound_checks_lo": CHECKS_PER_TASK * lo2, "bound_checks_hi": CHECKS_PER_TASK * hi2,
                            "bound_tasks_floor_lo": tw.get("bound_tasks_floor_lo", NAN),
                            "bound_tasks_floor_hi": tw.get("bound_tasks_floor_hi", NAN),
                            "interval": ("95 %, two-way jackknife (task id x write task within stream, "
                                         "msr.metrics.robust_variance), delta method on the log scale; it is the "
                                         "interval of the second-order APPROXIMATION, not of the exact bound"
                                         if two else f"95 % percentile, task bootstrap within cells "
                                         f"({iv['n_boot']} draws)") + "; boot_lo/hi: task bootstrap within cells "
                                         "(owners fixed); owner_lo/hi: owners resampled then tasks",
                            "abar_home_se": iv["abar_se"]})
            for n in budgets:
                row[f"max_power_{n}_tasks"] = max_power(n, k, alpha) if k > 0 else NAN
            for n in budgets:
                row[f"min_error_at_power80_{n}_tasks"] = min_error_at_power(n, k, 0.8) if k > 0 else NAN
            rows.append(row)
    return rows


def reviewer_tables() -> tuple:
    """(c, p_owner) of review R3's model as a one-task pool."""
    c = (np.array([3.0, 1.0, -1.0, -3.0]) / 4.0)[None, :]
    p = (REVIEWER_BASE + REVIEWER_D * np.array(REVIEWER_V))[None, :]
    return c, p


def r6_c6_models(seed: int = 6, n: int = 20000) -> dict:
    """Review R6's task models M1 and M2 of c6_bound.py, re-built with the same generator calls in the
    same order (rng = default_rng(6)): M1 levels U(0.2, 0.8) + 0.12 (1.5, 0.5, -0.5, -1.5) + N(0, 0.12^2),
    clipped to [0.01, 0.99], every task informative; M2 the same with 60 % of tasks near-deterministic
    (every candidate 0.97 or 0.03). Coefficients (3, 1, -1, -3)/4 (scores in order)."""
    rng = np.random.default_rng(seed)
    C4 = np.array([0.75, 0.25, -0.25, -0.75])
    lvl = rng.uniform(0.2, 0.8, n)
    p1 = np.clip(lvl[:, None] + 0.12 * np.array([1.5, 0.5, -0.5, -1.5]) + rng.normal(0, 0.12, (n, 4)), 0.01, 0.99)
    det = rng.random(n) < 0.6
    hi = rng.random(n) < 0.5
    p2 = p1.copy()
    p2[det] = np.where(hi[det, None], 0.97, 0.03)
    return {"r6_M1": (np.tile(C4, (n, 1)), p1), "r6_M2": (np.tile(C4, (n, 1)), p2)}


def adaptive_rows(tables: dict, margins=(RHO_KEEP, 0.0), alpha: float = ALPHA, power: float = 0.8) -> list:
    """sequential_adaptive.csv: for each setting {name: (c, p_owner)} and margin theta_0 (alternative
    theta_1 = 1), the bound in CHECKS for the theorem's uniform scheme and for rules that choose cells
    adaptively (Theorem 2'), exact and second order, and the factor between them."""
    rows = []
    dkl = float(binary_kl(power, alpha))
    for name, (c, p) in tables.items():
        c = np.asarray(c, float)
        p = np.asarray(p, float)
        abar = float((c * np.where(np.abs(c) > 0, np.nan_to_num(p), 0.0)).sum(-1).mean())
        for th0 in margins:
            ad = adaptive_constants(c, np.where(np.abs(c) > 0, np.nan_to_num(p), 0.0), th0 * abar)
            rows.append({"setting": name, "theta_1": 1.0, "theta_0": th0, "alpha": alpha, "power": power,
                         "abar_home": abar, "e_sigma2": ad["e_sigma2"], "checks_per_task": ad["checks_per_task"],
                         "scheme_uniform": SCHEME_UNIFORM, "scheme_adaptive": SCHEME_ADAPTIVE,
                         "bound_checks_uniform": dkl / ad["uniform_exact"],
                         "bound_checks_adaptive": dkl / ad["adaptive_exact"],
                         "bound_checks_uniform_chi2": dkl / ad["uniform_chi2"],
                         "bound_checks_adaptive_chi2": dkl / ad["adaptive_chi2"],
                         "factor_exact": ad["factor_exact"], "factor_chi2": ad["factor_chi2"],
                         "optimal_allocation": "w_c proportional to |c_c| sqrt(mu_c (1 - mu_c)) (second order)"})
    return rows


def bound_curve_rows(est: dict, interval: dict | None = None, truth: tuple | None = None, long: dict | None = None,
                     margins=BOUND_MARGINS, signals=BOUND_SIGNALS, alpha: float = ALPHA, power: float = 0.8,
                     truth_keys: tuple | None = None) -> list:
    """sequential_bound_curve.csv: the KEEP-type bound (theta_1 = 1) in tasks and checks, uniform scheme
    (whole tasks, 4 checks each), alpha and power as given, as a function of
      curve 'margin': theta_0 in 0, 0.1, ..., 0.9 at the study's signal: the second-order plug-in (owner's
        two home repeats) with its 95 % task-bootstrap interval, and the exact least-favourable bound at
        the simulator's truth when the study is simulated;
      curve 'signal': Abar_home in BOUND_SIGNALS at theta_0 = 0 and 0.75, second order, with E sigma^2 held
        at the study's plug-in value and at review R6's model M2 value (0.1116);
      curve 'marker': where the study sits: the current scores (truth and plug-in) and a long score
        phase (scores = the owner's true item usefulness, long_phase_tables), exact and second order, at
        theta_0 = 0 and 0.75."""
    dkl = float(binary_kl(power, alpha))
    rows = []
    a_hat, s_hat = est["abar_home"], est["e_sigma2_keep"]
    for th0 in margins:
        f = dkl / (1.0 - th0) ** 2
        g = 2.0 * s_hat / a_hat ** 2 if a_hat != 0 else NAN
        row = {"curve": "margin", "theta_0": th0, "theta_1": 1.0, "abar_home": a_hat, "e_sigma2": s_hat,
               "e_sigma2_source": "study plug-in (owner's two home repeats)", "scheme": SCHEME_UNIFORM,
               "alpha": alpha, "power": power, "bound_tasks_chi2": f * g, "bound_checks_chi2": CHECKS_PER_TASK * f * g}
        c_max = (interval or {}).get("c_max", 0.75)
        fl_ = bound_floor(a_hat, s_hat, 1.0, th0, c_max if math.isfinite(c_max) else 0.75, alpha, power)
        row.update({"bound_basis": "second order (an approximation), study plug-in",
                    "bound_tasks_floor": fl_["bound_tasks_floor"], "floor_kappa": fl_["kappa"],
                    "bound_checks_floor": CHECKS_PER_TASK * fl_["bound_tasks_floor"]})
        if interval:
            tw = chi2_floor_twoway(*interval["_rows"], 1.0, th0, c_max, alpha, power) if "_rows" in interval else {}
            two = math.isfinite(_f(tw.get("bound_tasks_chi2_lo", NAN)))
            lo2 = tw["bound_tasks_chi2_lo"] if two else f * interval["g_lo"]
            hi2 = tw["bound_tasks_chi2_hi"] if two else f * interval["g_hi"]
            row.update({"bound_tasks_chi2_lo": lo2, "bound_tasks_chi2_hi": hi2,
                        "bound_checks_chi2_lo": CHECKS_PER_TASK * lo2, "bound_checks_chi2_hi": CHECKS_PER_TASK * hi2,
                        "bound_tasks_chi2_boot_lo": f * interval["g_lo"], "bound_tasks_chi2_boot_hi": f * interval["g_hi"],
                        "bound_tasks_chi2_owner_lo": f * interval["g_owner_lo"],
                        "bound_tasks_chi2_owner_hi": f * interval["g_owner_hi"],
                        "bound_tasks_floor_lo": tw.get("bound_tasks_floor_lo", NAN),
                        "bound_tasks_floor_hi": tw.get("bound_tasks_floor_hi", NAN),
                        "interval": "two-way jackknife (task id x write task within stream)" if two
                        else "task bootstrap within cells"})
        if truth is not None:
            c, p = truth
            ab = float((c * p).sum(-1).mean())
            if truth_keys is not None:
                ex = exact_bound_twoway(p, c, th0, truth_keys[0], truth_keys[1], alpha=alpha, power=power)
                k = ex["K"]
                row.update({"bound_tasks_exact_truth_lo": ex["bound_tasks_lo"],
                            "bound_tasks_exact_truth_hi": ex["bound_tasks_hi"]})
            else:
                k, _ = least_favourable(p, c, th0 * ab, iters=80)
            row.update({"abar_home_truth": ab, "bound_tasks_exact_truth": dkl / k,
                        "bound_checks_exact_truth": CHECKS_PER_TASK * dkl / k,
                        "exact_truth_over_chi2_truth": (dkl / k) / (dkl * 2.0 * float((c ** 2 * p * (1 - p)).sum(-1)
                                                        .mean()) / ((1.0 - th0) * ab) ** 2)})
        rows.append(row)
    for src, es2 in (("study plug-in (owner's two home repeats)", s_hat), ("review R6 model M2 (c6_bound.py)", R6_M2_ES2)):
        for th0 in (0.0, RHO_KEEP):
            for ab in signals:
                k2 = ((1.0 - th0) * ab) ** 2 / (2.0 * es2)
                rows.append({"curve": "signal", "theta_0": th0, "theta_1": 1.0, "abar_home": ab, "e_sigma2": es2,
                             "e_sigma2_source": src, "scheme": SCHEME_UNIFORM, "alpha": alpha, "power": power,
                             "bound_tasks_chi2": dkl / k2, "bound_checks_chi2": CHECKS_PER_TASK * dkl / k2})
    marks = [("current scores, plug-in", None, a_hat, s_hat)]
    if long is not None:
        for nm, key in (("current scores, simulator truth", "current"), ("long score phase (true item usefulness)", "long")):
            c, p = long[key]
            marks.append((nm, (c, p), float((c * p).sum(-1).mean()), float((c ** 2 * p * (1 - p)).sum(-1).mean())))
    for nm, tab, ab, es2 in marks:
        for th0 in (0.0, RHO_KEEP):
            k2 = ((1.0 - th0) * ab) ** 2 / (2.0 * es2)
            row = {"curve": "marker", "marker": nm, "theta_0": th0, "theta_1": 1.0, "abar_home": ab, "e_sigma2": es2,
                   "scheme": SCHEME_UNIFORM, "alpha": alpha, "power": power,
                   "bound_tasks_chi2": dkl / k2, "bound_checks_chi2": CHECKS_PER_TASK * dkl / k2}
            if tab is not None:
                k, _ = least_favourable(tab[1], tab[0], th0 * ab, iters=80)
                row.update({"bound_tasks_exact_truth": dkl / k, "bound_checks_exact_truth": CHECKS_PER_TASK * dkl / k})
            rows.append(row)
    return rows


def long_phase_tables(st, cells: dict) -> dict | None:
    """Where a longer score phase would sit (simulated studies only): per owner, every candidate's
    score replaced by the item's TRUE usefulness to the owner, x = the mean of the owner's true success
    chance with that item over the item's OTHER appearances among the owner's probe tasks (every order;
    leave-one-out, so a cell's own chance never sets its own score; an item seen once gets the owner's
    overall mean, a tie). This is the limit of a long score phase. Returns {"long": (c, p_owner),
    "current": (c, p_owner)} pooled over the home cells, or None."""
    if not getattr(st, "all_sim", False):
        return None
    by_owner = {}
    for key, cell in sorted(cells.items()):
        if key[0] != key[1]:
            continue
        probs = sim_true_probs(st, key, cell)
        if probs is None:
            continue
        by_owner.setdefault(key[0], []).append((cell, probs[1]))
    if not by_owner:
        return None
    CL, PL, CC = [], [], []
    for o, lst in by_owner.items():
        sums, cnts = {}, {}
        for cell, po in lst:
            for (t, j), it in np.ndenumerate(cell["items"]):
                if it and np.isfinite(po[t, j]):
                    sums[it] = sums.get(it, 0.0) + float(po[t, j])
                    cnts[it] = cnts.get(it, 0) + 1
        overall = sum(sums.values()) / max(sum(cnts.values()), 1)
        for cell, po in lst:
            usable = (cell["items"] != "") & np.isfinite(po) & np.isfinite(cell["x"])
            xl = np.full(po.shape, np.nan)
            for (t, j), it in np.ndenumerate(cell["items"]):
                if usable[t, j]:
                    k = cnts[it]
                    xl[t, j] = (sums[it] - po[t, j]) / (k - 1) if k > 1 else overall
            cl, nl = stat_coefficients(xl, usable)
            cc, nc = stat_coefficients(cell["x"], usable)
            ok = (nl >= 2) & (nc >= 2)
            pz = np.where(usable, po, 0.0)
            CL.append(cl[ok])
            CC.append(cc[ok])
            PL.append(pz[ok])
    p = np.concatenate(PL)
    return {"long": (np.concatenate(CL), p), "current": (np.concatenate(CC), p)}


# ===========================================================================
# Reading a study's frozen probe tables
# ===========================================================================


def _study(study: str):
    from msr.analysis import design_from_study, resolve_study
    st = resolve_study(study)
    return st, design_from_study(st)


def load_cells(st, design, family: str | None = None) -> dict:
    """{(owner, reader, stream, seed): arrays} from results/cells/: the headline family's scores
    x, the reader's results y, the owner's own results y_home, the extra home repeats, item ids,
    and the calibration flags; plus (for the first-shown version) the candidates' relevance, the
    study's retrieval mix weight w_score and the family's score kind."""
    fam = family or design.headline
    d = st.results_dir / "cells"
    out = {}
    w_score = float(getattr(getattr(st, "build", None), "w_score", 0.5))
    try:
        from msr import build as BLD
        from msr import engine as EN
        kind = EN.kind_of(BLD.make_rules(st)[fam])
        if kind == "counter" and getattr(st.scores, "counter_ranking", "smoothed") != "smoothed":
            kind = "counter_net"
    except Exception:          # a study object without the rule settings: no first-shown version
        kind = ""
    for (o, r) in design.cells:
        for b in design.streams:
            for sd in design.seeds:
                p = d / f"{o}__{r}__{b}__seed{sd}.npz"
                if not p.exists():
                    continue
                with np.load(p, allow_pickle=False) as z:
                    if f"score_{fam}" not in z.files:
                        continue
                    out[(o, r, b, sd)] = {
                        "tasks": z["tasks"].astype(str), "is_calib": z["is_calib"].astype(bool),
                        "items": z["items"].astype(str), "x": z[f"score_{fam}"].astype(float),
                        "y": z["y"].astype(float), "y_home": z["y_home"].astype(float),
                        "y_extra": z["y_extra"].astype(float) if "y_extra" in z.files else None,
                        "relevance": z["relevance"].astype(float) if "relevance" in z.files else None,
                        "w_score": w_score, "score_kind": kind}
    return out


def _mean_rep(y: np.ndarray) -> np.ndarray:
    with np.errstate(invalid="ignore"):
        cnt = np.isfinite(y).sum(-1)
        s = np.nansum(y, axis=-1)
        return np.where(cnt > 0, s / np.maximum(cnt, 1), np.nan)


def _fill_repeats(y: np.ndarray) -> np.ndarray:
    """Replace a missing repeat by another repeat of the same cell (so a uniform draw of the
    repeat only ever lands on a stored answer); a cell with no repeat stays NaN."""
    y = y.copy()
    R = y.shape[-1]
    for r in range(R):
        miss = ~np.isfinite(y[..., r])
        if miss.any():
            for r2 in range(R):
                fill = miss & np.isfinite(y[..., r2])
                y[..., r][fill] = y[..., r2][fill]
                miss &= ~fill
    return y


def truth_half(tasks, stream: str, order, seed: int = 0) -> np.ndarray:
    """The pre-registered random half of a stream order's evaluation tasks that defines the truth
    (8.4.B2.6): the tasks sorted by sha256("truth-half|seed|stream|order|task"), first half. The same
    half serves every pair of that stream order; the other half joins the test stream."""
    tasks = [str(t) for t in tasks]
    key = [hashlib.sha256(f"truth-half|{seed}|{stream}|{order}|{t}".encode()).hexdigest() for t in tasks]
    order_ = np.argsort(key, kind="stable")
    m = np.zeros(len(tasks), dtype=bool)
    m[order_[: len(tasks) // 2]] = True
    return m


def home_eval_values(cell: dict) -> np.ndarray:
    """A_home (owner's two-repeat mean) on every evaluation task with a usable statistic: the
    owner's home sample, known before the swap (plugin and split rules)."""
    ev = ~cell["is_calib"]
    a, _, _ = task_stat(cell["x"][ev], _mean_rep(cell["y_home"][ev]), cell["items"][ev] != "")
    return a[np.isfinite(a)]


def cell_home_flag(cell: dict) -> dict:
    """THE home-signal flag of one cell (home_signal_flag, msr.metrics' single rule) on the owner's
    CALIBRATION tasks of that cell: V = sum_{i<j} sgn(x_i - x_j)(ybar_i - ybar_j) per calibration task
    with the owner's home repeats 1-2 (msr.metrics.signed_validity_parts, as msr.evaluate computes the
    flag's input). The calibration tasks are never in the replay stream (stream_pool), so the flag and
    the paired statistic use disjoint tasks. {"ok", "z", "tasks"}."""
    from msr import metrics as M
    cal = cell["is_calib"]
    if not cal.any():
        return {"ok": False, "z": NAN, "tasks": 0}
    pres = cell["items"][cal] != ""
    x = np.where(pres, cell["x"][cal], NAN)
    v, _ = M.signed_validity_parts(x, _mean_rep(cell["y_home"][cal]), pres)
    ok, z = home_signal_flag(v)
    return {"ok": bool(ok), "z": z, "tasks": int(cal.sum())}


def cell_shown(cell: dict) -> tuple | None:
    """(k, w) over ALL probe tasks of the cell: keep's and wipe's first-shown candidate (shown_pair
    with the study's w_score and the family's u); None without relevance or for a score kind whose u
    is not a function of the stored score."""
    if cell.get("relevance") is None or cell.get("score_kind") not in ("value", "credit", "counter"):
        return None
    usable = (cell["items"] != "") & np.isfinite(cell["x"]) & np.isfinite(cell["relevance"])
    return shown_pair(score_u(cell["score_kind"], np.where(usable, cell["x"], 0.5)), cell["relevance"], usable,
                      cell.get("w_score", 0.5))


def cell_truth(cell: dict, n_boot: int = 1000, seed: int = 0, home_cell: bool = False,
               truth_mask: np.ndarray | None = None) -> dict:
    """The truth of one cell from the evaluation tasks in `truth_mask` (a boolean over the
    evaluation tasks; default: all of them): mu_home and mu_swap on the SAME tasks, theta =
    mu_swap / mu_home, a task-bootstrap interval for theta; for the margin-0 rules mu_swap itself and
    fs_gap = the reader's first-shown success under keep minus under wipe (two-repeat means) on those
    tasks. home_signal_ok = THE home flag (cell_home_flag: msr.metrics' single rule on the owner's
    calibration tasks; it replaces the earlier 4-SE rule on the truth half, R6 W3), home_flag_z its z.
    mu_home_all is the owner's home mean on every evaluation task (the plug-in rules' estimate).
    For a home cell the reader is the owner, theta = 1 by definition; theta_est (extra repeats 3-4
    against repeats 1-2) is reported beside it."""
    ev = ~cell["is_calib"]
    pres = cell["items"][ev] != ""
    x = cell["x"][ev]
    a_home, _, _ = task_stat(x, _mean_rep(cell["y_home"][ev]), pres)
    y_sw = cell["y_extra"] if home_cell and cell.get("y_extra") is not None else cell["y"]
    a_swap, _, _ = task_stat(x, _mean_rep(y_sw[ev]), pres)
    tm = np.ones(len(a_home), bool) if truth_mask is None else np.asarray(truth_mask, bool)
    fin_h = np.isfinite(a_home)
    ok = fin_h & np.isfinite(a_swap) & tm
    n = int(ok.sum())
    flag = cell_home_flag(cell)
    out = {"eval_tasks": int(fin_h.sum()), "truth_tasks": n, "mu_home": NAN, "mu_swap": NAN, "theta": NAN,
           "theta_lo": NAN, "theta_hi": NAN, "mu_home_se": NAN, "home_signal_ok": flag["ok"],
           "home_flag_z": flag["z"], "home_flag_tasks": flag["tasks"], "fs_gap": NAN, "fs_gap_home": NAN,
           "mu_home_all": float(a_home[fin_h].mean()) if fin_h.any() else NAN, "home_cell": bool(home_cell)}
    sh = cell_shown(cell)
    if sh is not None:
        k, w = sh[0][ev], sh[1][ev]
        okf = tm & (k >= 0) & (w >= 0)
        if okf.any():
            r_ = np.flatnonzero(okf)
            for key, yy in (("fs_gap", y_sw), ("fs_gap_home", cell["y_home"])):
                yb = _mean_rep(yy[ev])
                out[key] = float(np.nanmean(yb[r_, k[okf]] - yb[r_, w[okf]]))
    if n < 2:
        return out
    ah, as_ = a_home[ok], a_swap[ok]
    mh, ms = float(ah.mean()), float(as_.mean())
    rng = np.random.default_rng([seed, 7303, n])
    idx = rng.integers(0, n, size=(n_boot, n))
    bh = ah[idx].mean(1)
    bs = as_[idx].mean(1)
    with np.errstate(invalid="ignore", divide="ignore"):
        bt = np.where(bh > 0, bs / bh, np.nan)
    se = float(bh.std(ddof=1))
    out.update({"mu_home": mh, "mu_swap": ms, "mu_home_se": se,
                "theta": ms / mh if mh > 0 else NAN,
                "theta_lo": float(np.nanpercentile(bt, 2.5)) if np.isfinite(bt).any() else NAN,
                "theta_hi": float(np.nanpercentile(bt, 97.5)) if np.isfinite(bt).any() else NAN})
    if home_cell:
        out["theta_est"] = out["theta"]
        out["theta"] = 1.0
    return out


def check_order(order, replays: int, n_tasks: int, diagnostic: bool = False) -> np.ndarray | None:
    """The random-order condition of every test here (review R7 W8): None (the harness draws the order) is
    the only registered input. A given order (any array) is refused with NonRandomOrderError unless
    diagnostic=True; then it must be (replays, n_tasks) or (n_tasks,) positions of the pool's tasks."""
    if order is None:
        return None
    if not diagnostic:
        raise NonRandomOrderError("checks must be drawn at random by the harness, not chosen or ordered by the "
                                  "operator (a topic order made the break-even test keep falsely in 0.749 of "
                                  "streams); pass diagnostic=True to replay a given order as a diagnostic")
    o = np.asarray(order, dtype=np.int64)
    o = np.broadcast_to(o, (replays, o.shape[-1])) if o.ndim == 1 else o
    if o.shape != (replays, n_tasks) or o.min() < 0 or o.max() >= n_tasks:
        raise ValueError(f"a given order must be positions 0..{n_tasks - 1} of the pool, shape ({replays}, {n_tasks})")
    return o


def harness_order(replays: int, n_tasks: int, rng) -> np.ndarray:
    """(replays, n_tasks): every replay visits the pool's tasks in an order drawn uniformly at random by the
    harness, without replacement (the registered design; 11.4.6)."""
    return np.argsort(rng.random((replays, n_tasks)), axis=1)


def replay_draws(cell: dict, replays: int, rng, shuffled: bool = False, pool: np.ndarray | None = None,
                 check: str = "y", shown: tuple | None = None, order=None, diagnostic: bool = False) -> dict:
    """replay_streams with everything a replay needs: {"a", "calls", "inf", "a_h", "order"} and, when
    `shown` = (k, w) over all probe tasks is given, "d" = y_keep - y_wipe of the SAME drawn repeats (0
    where both arms show the same candidate) and "d_calls" = 2 where they differ, else 0. The order of the
    tasks is drawn at random by the harness (harness_order); `order` (a given order) is refused unless
    diagnostic=True (check_order)."""
    cal = cell["is_calib"] if pool is None else np.asarray(pool, bool)
    x = cell["x"][cal]
    pres = cell["items"][cal] != ""
    y = _fill_repeats(cell[check][cal])
    a_home, _, _ = task_stat(x, _mean_rep(cell["y_home"][cal]), pres)
    Tq, C, Rr = y.shape
    if Tq == 0:
        check_order(order, replays, 0, diagnostic) if order is not None and not diagnostic else None
        z = np.zeros((replays, 0))
        return {"a": z, "calls": np.zeros((replays, 0), int), "inf": np.zeros((replays, 0), bool), "a_h": z,
                "order": np.zeros((replays, 0), int), "d": z if shown is not None else None,
                "d_calls": np.zeros((replays, 0), int) if shown is not None else None}
    given = check_order(order, replays, Tq, diagnostic)
    order = harness_order(replays, Tq, rng) if given is None else given
    rep = rng.integers(0, Rr, size=(replays, Tq, C))
    yy = np.take_along_axis(y[order], rep[..., None], axis=3)[..., 0]
    xx = x[order]
    pp = pres[order]
    if shuffled:
        perm = np.argsort(rng.random((replays, Tq, C)), axis=2)
        xx = np.take_along_axis(xx, perm, axis=2)
    a, n, inf = task_stat(xx, yy, pp)
    out = {"a": a, "calls": pp.sum(-1), "inf": inf, "a_h": a_home[order], "order": order, "d": None, "d_calls": None}
    if shown is not None:
        k, w = (np.asarray(v)[cal][order] for v in shown)
        valid = (k >= 0) & (w >= 0) & (k != w)
        yk = np.take_along_axis(yy, np.maximum(k, 0)[..., None], axis=2)[..., 0]
        yw = np.take_along_axis(yy, np.maximum(w, 0)[..., None], axis=2)[..., 0]
        out["d"] = np.where(valid, np.nan_to_num(yk) - np.nan_to_num(yw), 0.0)
        out["d_calls"] = 2 * valid.astype(int)
    return out


def replay_streams(cell: dict, replays: int, rng, shuffled: bool = False, pool: np.ndarray | None = None,
                   check: str = "y", order=None, diagnostic: bool = False) -> tuple:
    """Fresh-check streams from the probe tasks in `pool` (a boolean over all probe tasks of the
    cell; default: the calibration tasks): (a_s (replays, Tq), calls per task (replays, Tq),
    informative (replays, Tq), a_h (replays, Tq)). Each replay draws the tasks in a uniformly
    random order without replacement and one stored repeat of cell[check] per candidate, uniformly;
    a_h is the owner's home statistic (two-repeat mean of y_home) on the same task. With
    shuffled=True the old scores are permuted at random among the candidates of each task for a_s
    only (content-only control: E[a_s] = 0; the home statistic is unchanged). A given `order` is refused
    unless diagnostic=True (check_order)."""
    r = replay_draws(cell, replays, rng, shuffled=shuffled, pool=pool, check=check, order=order, diagnostic=diagnostic)
    return r["a"], r["calls"], r["inf"], r["a_h"]


def _audit(a: np.ndarray, inf: np.ndarray, n_tasks) -> np.ndarray:
    """The benchmark's audit_k rule on the first n_tasks tasks of each stream: KEEP if the old
    scores' Cw on the checks is above 0.5 (the same as sum a > 0), WIPE (= DROP) otherwise; no
    informative pair -> KEEP (pre-registration 2.6)."""
    R, T = a.shape
    n_tasks = np.broadcast_to(np.asarray(n_tasks), (R,))
    mask = np.arange(T)[None, :] < n_tasks[:, None]
    s = np.where(mask, np.nan_to_num(a), 0.0).sum(1)
    any_inf = (mask & inf).any(1)
    return np.where(~any_inf | (s > 1e-12), KEEP, DROP)


def _plugin(a: np.ndarray, n_tasks, mu_home: float, rho_keep: float, rho_drop: float) -> np.ndarray:
    """A fixed-budget rule asking the same question without error control: KEEP if the estimated
    retained share mean(a) / mu_home over the first n_tasks tasks is at least the midpoint
    (rho_keep + rho_drop) / 2, DROP otherwise."""
    R, T = a.shape
    n_tasks = np.broadcast_to(np.asarray(n_tasks), (R,))
    mask = np.arange(T)[None, :] < n_tasks[:, None]
    fin = mask & np.isfinite(a)
    m = np.where(fin, a, 0.0).sum(1) / np.maximum(fin.sum(1), 1)
    return np.where(m / mu_home >= (rho_keep + rho_drop) / 2.0, KEEP, DROP)


def _q(v, q):
    v = np.asarray(v, dtype=float)
    return float(np.percentile(v, q)) if v.size else NAN


def _summ(dec, used, calls_per_task, theta, rho_keep, rho_drop, status=None, margin0: bool = False) -> dict:
    """Shares and costs of one rule over the replays. margin0: theta is the truth E (A_swap or the
    first-shown gap) and a KEEP is false when E <= 0, a WIPE (code DROP) when E >= 0. status (the
    paired rule): the not-testable and home-table-exhausted shares (undecided_share counts both
    'undecided at the cap' and 'home table exhausted'; not-testable is separate)."""
    used = np.asarray(used)
    cum_calls = np.cumsum(calls_per_task, axis=1) if calls_per_task.size else np.zeros_like(calls_per_task)
    idx = np.clip(used - 1, 0, max(cum_calls.shape[1] - 1, 0))
    calls = np.take_along_axis(cum_calls, idx[:, None], axis=1)[:, 0] if cum_calls.size else np.zeros(len(used))
    calls = np.where(used > 0, calls, 0)
    keep, drop, und, nt = (float(np.mean(dec == v)) for v in (KEEP, DROP, UNDECIDED, NOT_TESTABLE))
    if margin0:
        below_keep = bool(np.isfinite(theta) and theta <= 0)
        above_drop = bool(np.isfinite(theta) and theta >= 0)
    else:
        below_keep = bool(np.isfinite(theta) and theta < rho_keep)
        above_drop = bool(np.isfinite(theta) and theta > rho_drop)
    out = {"keep_share": keep, "drop_share": drop, "undecided_share": und, "not_testable_share": nt,
           "false_keep": keep if below_keep else NAN, "false_drop": drop if above_drop else NAN,
           "tasks_mean": float(np.mean(used)), "tasks_q10": _q(used, 10), "tasks_median": _q(used, 50),
           "tasks_q90": _q(used, 90), "tasks_max": float(np.max(used)) if len(used) else NAN,
           "calls_mean": float(np.mean(calls)), "calls_median": _q(calls, 50), "calls_q90": _q(calls, 90)}
    if status is not None:
        out["exhausted_share"] = float(np.mean(np.asarray(status) == STATUS_EXHAUSTED))
    return out


def stream_pool(cell: dict, truth_mask: np.ndarray | None, include_calib: bool = False) -> np.ndarray:
    """The test stream's tasks (8.4.B2.6 as revised): the evaluation tasks NOT in the truth half. The
    calibration tasks are NOT in the stream (include_calib=False, the default): they carry the home
    flag (cell_home_flag), so flag and stream use disjoint tasks. include_calib=True gives the earlier
    pool (calibration + other half). With truth_mask None: the calibration tasks only (earliest design)."""
    pool = cell["is_calib"].copy() if (include_calib or truth_mask is None) else np.zeros(len(cell["is_calib"]), bool)
    if truth_mask is not None:
        ev = np.flatnonzero(~cell["is_calib"])
        pool[ev[~np.asarray(truth_mask, bool)]] = True
    return pool


def replay_cell(cell: dict, truth: dict, kind: str, replays: int, rng, rho_keep=RHO_KEEP, rho_drop=RHO_DROP,
                alpha=ALPHA, bet=BET, cap=None, shuffled=False, fixed=True, pool: np.ndarray | None = None,
                order=None, diagnostic: bool = False) -> list:
    """Every rule on the same replays of one cell: the paired keep-or-drop rule "sequential" (cap =
    every task of the stream pool, or `cap`), the comparison rules "sequential_plugin" (thresholds
    from the owner's home mean on the evaluation tasks, treated as known) and "sequential_split"
    (alpha/2 home bounds from the same tasks), the paired rule stopped at the benchmark budgets
    (8-64 checks = 2-16 tasks), the benchmark's audit_k, a fixed-budget plug-in rule plugin_k, and
    both fixed rules at the paired rule's mean cost (equal expected cost); and the two margin-0
    rules (one-sample tests, no home value): "margin0_ranking" on the same reader checks and
    "margin0_first_shown" on d = y_keep - y_wipe of the same drawn repeats (2 checks where keep and
    wipe show different items). The paired rule is the full rule of Proposition 1 (fixed): gated by
    the cell's home flag (truth["home_signal_ok"]: 'not testable' otherwise) and stopped at the store
    (the pool's stored home results, each used once: 'home table exhausted'). The order of the tasks is
    drawn at random by the harness; a given `order` raises NonRandomOrderError unless diagnostic=True, and
    then every row says so in its "order" column (no error guarantee)."""
    check = "y_extra" if truth.get("home_cell") and cell.get("y_extra") is not None else "y"
    shown = None if shuffled else cell_shown(cell)
    R_ = replay_draws(cell, replays, rng, shuffled=shuffled, pool=pool, check=check, shown=shown, order=order,
                      diagnostic=diagnostic)
    a, calls, inf, a_h = R_["a"], R_["calls"], R_["inf"], R_["a_h"]
    Tq = a.shape[1]
    theta = 0.0 if shuffled else truth["theta"]
    mu_hat = truth.get("mu_home_all", truth["mu_home"])
    base = {"kind": "shuffled" if shuffled else kind, "pool_tasks": Tq, "theta_true": theta,
            "theta_lo": NAN if shuffled else truth.get("theta_lo", NAN),
            "theta_hi": NAN if shuffled else truth.get("theta_hi", NAN),
            "mu_home": truth["mu_home"], "mu_home_all": mu_hat, "tau_keep": rho_keep * mu_hat,
            "tau_drop": rho_drop * mu_hat, "rho_keep": rho_keep, "rho_drop": rho_drop,
            "alpha": alpha, "bet": bet, "replays": replays, "home_signal_ok": truth["home_signal_ok"],
            "home_flag_z": truth.get("home_flag_z", NAN), "check": check,
            "order": ORDER_HARNESS if order is None else ORDER_GIVEN}
    if Tq == 0 or not np.isfinite(mu_hat):
        return [{**base, "rule": "sequential", "note": "no stream tasks or no home values"}]
    capn = Tq if cap is None else min(cap, Tq)
    res = decide_keep_or_drop(a, a_h, bool(truth["home_signal_ok"]), n_home=Tq, rho_keep=rho_keep,
                              rho_drop=rho_drop, alpha=alpha, bet=bet, cap=capn)
    dec, used = res["decision"], res["used"]
    rows = [{**base, "rule": "sequential", "cap_tasks": capn, "store_tasks": Tq, "note": RULE_NOTE["sequential"],
             "not_testable_action": NOT_TESTABLE_ACTION,
             **_summ(dec, used, calls, theta, rho_keep, rho_drop, status=res["status"])}]
    if not fixed:
        return rows
    m0 = []
    e_rank = 0.0 if shuffled else truth.get("mu_swap", NAN)
    d0, u0, _, _ = decide_margin0(a, alpha, bet, cap=capn)
    m0.append({**base, "rule": "margin0_ranking", "cap_tasks": capn, "truth_E": e_rank, "theta_true": e_rank,
               "rho_keep": 0.0, "rho_drop": 0.0, "theta_lo": NAN, "theta_hi": NAN, "note": RULE_NOTE["margin0_ranking"],
               **_summ(d0, u0, calls, e_rank, 0.0, 0.0, margin0=True)})
    if R_["d"] is not None and np.isfinite(truth.get("fs_gap", NAN)):
        d1, u1, _, _ = decide_margin0(R_["d"], alpha, bet, cap=capn)
        g = truth["fs_gap"]
        m0.append({**base, "rule": "margin0_first_shown", "cap_tasks": capn, "truth_E": g, "theta_true": g,
                   "rho_keep": 0.0, "rho_drop": 0.0, "theta_lo": NAN, "theta_hi": NAN,
                   "share_differ": float(np.mean(R_["d_calls"] > 0)), "note": RULE_NOTE["margin0_first_shown"],
                   **_summ(d1, u1, R_["d_calls"], g, 0.0, 0.0, margin0=True)})
    rows += m0
    dec_t, used_t, _, _ = decide_paired(a, a_h, rho_keep, rho_drop, alpha, bet, cap=capn)   # ungated test times
    gate = bool(truth["home_signal_ok"])
    hv = home_eval_values(cell)
    h_lo = float(betting_bound(hv[None, :], alpha / 2.0, upper=False)[0])
    h_hi = float(betting_bound(hv[None, :], alpha / 2.0, upper=True)[0])
    res = run_rules(a, a_h, ("sequential_plugin", "sequential_split"), home_hat=mu_hat, home_lo=h_lo,
                    home_hi=h_hi, rho_keep=rho_keep, rho_drop=rho_drop, alpha=alpha, bet=bet, cap=capn)
    for rule in ("sequential_plugin", "sequential_split"):
        d2, u2, _, _ = res[rule]
        rows.append({**base, "rule": rule, "cap_tasks": capn, "home_lo": h_lo, "home_hi": h_hi,
                     "note": RULE_NOTE[rule], **_summ(d2, u2, calls, theta, rho_keep, rho_drop)})
    for k in FIXED_CHECKS:
        kt = k // CHECKS_PER_TASK
        if kt > Tq:
            continue
        d2 = np.where((dec_t != UNDECIDED) & (used_t <= kt), dec_t, UNDECIDED)
        d2 = np.where(gate, d2, NOT_TESTABLE)
        u2 = np.where(d2 == NOT_TESTABLE, 0, np.where(d2 != UNDECIDED, used_t, kt))
        rows.append({**base, "rule": f"sequential_cap{k}", "cap_tasks": kt,
                     **_summ(d2, u2, calls, theta, rho_keep, rho_drop)})
        da = _audit(a, inf, kt)
        sa = _summ(da, np.full(len(da), kt), calls, theta, rho_keep, rho_drop)
        sm = _summ(da, np.full(len(da), kt), calls, e_rank, 0.0, 0.0, margin0=True)
        rows.append({**base, "rule": f"audit_{k}", "cap_tasks": kt, "truth_E": e_rank,
                     "false_keep_margin0": sm["false_keep"], "false_wipe_margin0": sm["false_drop"], **sa})
        dp = _plugin(a, kt, mu_hat, rho_keep, rho_drop)
        rows.append({**base, "rule": f"plugin_{k}", "cap_tasks": kt,
                     **_summ(dp, np.full(len(dp), kt), calls, theta, rho_keep, rho_drop)})
    k_eq = int(max(1, min(Tq, round(float(np.mean(used_t))))))
    da = _audit(a, inf, k_eq)
    sm = _summ(da, np.full(len(da), k_eq), calls, e_rank, 0.0, 0.0, margin0=True)
    rows.append({**base, "rule": "audit_equal_cost", "cap_tasks": k_eq, "truth_E": e_rank,
                 "false_keep_margin0": sm["false_keep"], "false_wipe_margin0": sm["false_drop"],
                 **_summ(da, np.full(len(da), k_eq), calls, theta, rho_keep, rho_drop)})
    if m0:                            # the benchmark's audit at the margin-0 rule's mean cost
        k0 = int(max(1, min(Tq, round(float(m0[0]["tasks_mean"])))))
        da = _audit(a, inf, k0)
        rows.append({**base, "rule": "audit_equal_cost_margin0", "cap_tasks": k0, "truth_E": e_rank,
                     "theta_true": e_rank, "rho_keep": 0.0, "rho_drop": 0.0, "theta_lo": NAN, "theta_hi": NAN,
                     **_summ(da, np.full(len(da), k0), calls, e_rank, 0.0, 0.0, margin0=True)})
    dp = _plugin(a, k_eq, mu_hat, rho_keep, rho_drop)
    rows.append({**base, "rule": "plugin_equal_cost", "cap_tasks": k_eq,
                 **_summ(dp, np.full(len(dp), k_eq), calls, theta, rho_keep, rho_drop)})
    return rows


# ===========================================================================
# Known truth (simulated studies): the simulator's own success probabilities
# ===========================================================================


def sim_true_probs(st, cell_key: tuple, cell: dict) -> tuple | None:
    """(p_reader (T, C), p_owner (T, C)) from msr.sim for every probe task of a cell of a study
    whose models are all simulated; None otherwise."""
    o, r, b, _ = cell_key
    if not st.all_sim:
        return None
    from msr import sim as S
    cfg = st.models_cfg["models"]
    T, C = cell["x"].shape
    pr = np.full((T, C), np.nan)
    po = np.full((T, C), np.nan)
    for t in range(T):
        for c in range(C):
            it = cell["items"][t, c]
            if not it:
                continue
            pr[t, c] = S.true_success_prob(r, b, cell["tasks"][t], it, cfg.get(r))
            po[t, c] = S.true_success_prob(o, b, cell["tasks"][t], it, cfg.get(o))
    return pr, po


def _cell_tables(cell: dict, probs: tuple) -> tuple:
    """(c, p_reader, p_owner, usable) on the cell's tasks with at least 2 usable candidates."""
    pr, po = probs
    usable = (cell["items"] != "") & np.isfinite(cell["x"]) & np.isfinite(pr) & np.isfinite(po)
    c, n = stat_coefficients(cell["x"], usable)
    ok = n >= 2
    return c[ok], pr[ok], po[ok], usable[ok]


def simtruth_cell(cell: dict, probs: tuple, kind: str, replays: int, horizon: int, rng,
                  rho_keep=RHO_KEEP, rho_drop=RHO_DROP, alpha=ALPHA, bet=BET, shuffled=False,
                  n_home: int | None = None) -> dict:
    """Streams with an exactly known truth: tasks drawn WITH replacement from all probe tasks of the
    cell, each candidate's check a fresh Bernoulli draw from the simulator's true probability of the
    reader, and fresh owner home results (2 repeats from the owner's true probabilities) on the same
    task. Abar_swap and Abar_home are exactly the pool means of E[A | tau], so the guarantee is
    checked against the truth itself. false_keep / false_drop are the paired rule's (gated by the
    cell's home flag on its stored calibration results; fresh home results, so no store binds); the
    *_plugin columns are the earlier rule's, with its home value estimated from n_home fresh home tasks
    (default: the cell's number of evaluation tasks), drawn anew for every replay; the m0_rank_* and
    m0_fs_* columns are the margin-0 rules' (ranking on the same fresh checks, truth = mu_swap_true;
    first-shown on fresh checks of keep's and wipe's items, truth = the exact first-shown gap)."""
    c, pr, po, usable = _cell_tables(cell, probs)
    e_swap = (c * np.where(usable, pr, 0.0)).sum(-1)
    e_home = (c * np.where(usable, po, 0.0)).sum(-1)
    mu_home = float(e_home.mean())
    mu_swap = 0.0 if shuffled else float(e_swap.mean())
    theta = mu_swap / mu_home if mu_home > 0 else NAN
    a_s, a_h = bernoulli_pair_streams(c, pr, po, replays, horizon, rng, usable=usable, shuffled=shuffled)
    flag = cell_home_flag(cell)
    res = decide_keep_or_drop(a_s, a_h, flag["ok"], rho_keep=rho_keep, rho_drop=rho_drop, alpha=alpha, bet=bet)
    dec, used = res["decision"], res["used"]
    d0, u0, _, _ = decide_margin0(a_s, alpha, bet)
    m0 = {"m0_rank_truth_E": mu_swap, "m0_rank_keep_share": float(np.mean(d0 == KEEP)),
          "m0_rank_wipe_share": float(np.mean(d0 == DROP)),
          "m0_rank_false_keep": float(np.mean(d0 == KEEP)) if mu_swap <= 0 else NAN,
          "m0_rank_false_wipe": float(np.mean(d0 == DROP)) if mu_swap >= 0 else NAN,
          "m0_rank_tasks_median": _q(np.where(d0 != UNDECIDED, u0, horizon + 1), 50)}
    sh = None if shuffled else cell_shown(cell)
    if sh is not None:
        pr_all, _ = probs
        ok_u = (cell["items"] != "") & np.isfinite(cell["x"]) & np.isfinite(pr_all) & np.isfinite(probs[1])
        _, n_all = stat_coefficients(cell["x"], ok_u)
        rows_ok = n_all >= 2
        e = shown_coef(sh[0], sh[1], cell["x"].shape[1])[rows_ok]
        prz = np.where(ok_u, np.nan_to_num(pr_all), 0.0)[rows_ok]
        gap = float((e * prz).sum(-1).mean())
        d, ct, _ = table_streams(e, prz, replays, horizon, rng, cost=2 * (np.abs(e).sum(-1) > 0))
        d1, u1, _, _ = decide_margin0(d, alpha, bet)
        chk = _checks_used(ct, np.minimum(u1, horizon))
        st1 = d1 != UNDECIDED
        m0.update({"m0_fs_gap_true": gap, "m0_fs_share_differ": float(np.mean(np.abs(e).sum(-1) > 0)),
                   "m0_fs_keep_share": float(np.mean(d1 == KEEP)), "m0_fs_wipe_share": float(np.mean(d1 == DROP)),
                   "m0_fs_false_keep": float(np.mean(d1 == KEEP)) if gap <= 0 else NAN,
                   "m0_fs_false_wipe": float(np.mean(d1 == DROP)) if gap >= 0 else NAN,
                   "m0_fs_tasks_median": _q(np.where(st1, u1, horizon + 1), 50),
                   "m0_fs_checks_mean": float(np.mean(chk))})
    n_home = int(n_home or (~cell["is_calib"]).sum())
    _, hs = bernoulli_pair_streams(c, po, po, replays, n_home, rng, usable=usable)
    home_hat = hs.astype(float).mean(1)
    dp, up, _, _ = decide(a_s, rho_keep * home_hat, rho_drop * home_hat, alpha, bet)
    stopped = (dec == KEEP) | (dec == DROP)
    row = {"kind": "shuffled" if shuffled else kind, "mu_home_true": mu_home, "mu_swap_true": mu_swap,
           "theta_true": theta, "pool_tasks": int(len(c)), "replays": replays, "horizon": horizon,
           "rho_keep": rho_keep, "rho_drop": rho_drop, "alpha": alpha, "bet": bet, "rule": "sequential",
           "home_signal_ok": flag["ok"], "home_flag_z": flag["z"],
           "keep_share": float(np.mean(dec == KEEP)), "drop_share": float(np.mean(dec == DROP)),
           "undecided_share": float(np.mean(dec == UNDECIDED)),
           "not_testable_share": float(np.mean(dec == NOT_TESTABLE)),
           "false_keep": float(np.mean(dec == KEEP)) if theta < rho_keep else NAN,
           "false_drop": float(np.mean(dec == DROP)) if theta > rho_drop else NAN,
           "tasks_median": _q(np.where(stopped, used, horizon + 1), 50),
           "tasks_q10": _q(np.where(stopped, used, horizon + 1), 10),
           "tasks_q90": _q(np.where(stopped, used, horizon + 1), 90),
           "mc_se": math.sqrt(alpha * (1 - alpha) / replays),
           "n_home_plugin": n_home,
           "keep_share_plugin": float(np.mean(dp == KEEP)), "drop_share_plugin": float(np.mean(dp == DROP)),
           "false_keep_plugin": float(np.mean(dp == KEEP)) if theta < rho_keep else NAN,
           "false_drop_plugin": float(np.mean(dp == DROP)) if theta > rho_drop else NAN,
           "tasks_median_plugin": _q(np.where(dp != UNDECIDED, up, horizon + 1), 50), **m0}
    for cc in sorted({k // CHECKS_PER_TASK for k in FIXED_CHECKS} | {CALIB_TASKS, STORE_TASKS_REAL, CAP_TASKS}):
        row[f"decided_by_{cc}"] = float(np.mean(stopped & (used <= cc)))
    return row


# ===========================================================================
# Aggregation and the run
# ===========================================================================


def _kind(design, o, r) -> str:
    g = design.group(o, r)
    return {"home": "home", "upgrade": "same_maker", "downgrade": "same_maker",
            "same_other": "same_maker", "cross": "cross_maker"}.get(g, g)


def aggregate_rules(rows: list) -> list:
    """Replay-weighted rates per rule and kind (home, same_maker, cross_maker, shuffled; 'all';
    and 'all_home_ok', the cells whose home flag (msr.metrics' single rule on the owner's calibration
    tasks) is positive, the headline set): false keep among cells truly below rho_keep, false drop
    among cells truly above rho_drop, plus the cells whose whole truth interval is on that side
    ('clear'). For the margin-0 rules rho = 0, theta_true is the truth E and a keep (wipe) is false
    when E <= 0 (E >= 0)."""
    out = []
    keys = sorted({(r["rule"], r["kind"]) for r in rows if "keep_share" in r})
    extra = sorted({(r["rule"], k) for r in rows if "keep_share" in r for k in ("all", "all_home_ok")})

    def take(r, kind):
        if kind == "all":
            return True
        if kind == "all_home_ok":     # the headline set: THE home flag is positive (one rule, R6 W3)
            return bool(r.get("home_signal_ok"))
        return r["kind"] == kind

    for rule, kind in keys + extra:
        rs = [r for r in rows if r["rule"] == rule and take(r, kind) and "keep_share" in r]
        if not rs:
            continue
        w = np.array([r["replays"] for r in rs], float)

        def wm(col, sel=None):
            v = np.array([r.get(col, NAN) for r in rs], float)
            m = np.isfinite(v) if sel is None else (np.isfinite(v) & sel)
            return float(np.sum(v[m] * w[m]) / np.sum(w[m])) if m.any() else NAN

        th = np.array([r["theta_true"] for r in rs], float)
        hi = np.array([r.get("theta_hi", NAN) for r in rs], float)
        lo = np.array([r.get("theta_lo", NAN) for r in rs], float)
        rk = rs[0]["rho_keep"]
        rd = rs[0]["rho_drop"]
        clear_below = np.where(np.isfinite(hi), hi < rk, th < rk)
        clear_above = np.where(np.isfinite(lo), lo > rd, th > rd)
        out.append({"rule": rule, "kind": kind, "cells": len(rs), "replays_each": int(w[0]),
                    "cells_below_keep": int(np.sum(th < rk)), "cells_above_drop": int(np.sum(th > rd)),
                    "false_keep_rate": wm("false_keep"), "false_drop_rate": wm("false_drop"),
                    "false_keep_rate_clear": wm("keep_share", clear_below),
                    "false_drop_rate_clear": wm("drop_share", clear_above),
                    "keep_share": wm("keep_share"), "drop_share": wm("drop_share"),
                    "undecided_share": wm("undecided_share"), "not_testable_share": wm("not_testable_share"),
                    "exhausted_share": wm("exhausted_share"), "tasks_mean": wm("tasks_mean"),
                    "calls_mean": wm("calls_mean"), "rho_keep": rk, "rho_drop": rd,
                    "alpha": rs[0]["alpha"], "bet": rs[0]["bet"], "note": RULE_NOTE.get(rule, "")})
    return out


def pair_summary(rows: list) -> list:
    """The paired rule per ordered pair (all its streams and orders, shuffled controls apart),
    and the headline 'share undecided within the table': a cell-order counts as undecided when at
    least half of its replays end without a decision (undecided at the store, or not testable).
    Then the same summaries for the two margin-0 rules (kind '<scope> [margin0_ranking]' etc.)."""
    out = []
    for rule in ("sequential", "margin0_ranking", "margin0_first_shown"):
        sel = [r for r in rows if r.get("rule") == rule and "keep_share" in r]
        if not sel:
            continue
        tag = "" if rule == "sequential" else f" [{rule}]"

        def nod(r):
            return float(r["undecided_share"]) + float(r.get("not_testable_share", 0.0) or 0.0)

        if rule == "sequential":
            keys = sorted({(r["owner"], r["reader"], r["kind"]) for r in sel})
            for o, rd, kind in keys:
                rs = [r for r in sel if (r["owner"], r["reader"], r["kind"]) == (o, rd, kind)]
                und = np.array([nod(r) for r in rs], float)
                out.append({"owner": o, "reader": rd, "kind": kind, "rule": rule, "group": rs[0].get("group", ""),
                            "cell_orders": len(rs),
                            "cell_orders_home_ok": int(sum(bool(r["home_signal_ok"]) for r in rs)),
                            "keep_share": float(np.mean([r["keep_share"] for r in rs])),
                            "drop_share": float(np.mean([r["drop_share"] for r in rs])),
                            "undecided_share": float(np.mean([r["undecided_share"] for r in rs])),
                            "not_testable_share": float(np.mean([r.get("not_testable_share", 0.0) for r in rs])),
                            "cell_orders_mostly_undecided": int(np.sum(und >= 0.5)),
                            "theta_true_mean": float(np.nanmean([r["theta_true"] for r in rs])),
                            "pool_tasks_mean": float(np.mean([r["pool_tasks"] for r in rs])),
                            "tasks_mean": float(np.mean([r["tasks_mean"] for r in rs]))})
        for scope, filt in (("all swaps", lambda r: r["kind"] in ("same_maker", "cross_maker")),
                            ("all swaps, home signal ok", lambda r: r["kind"] in ("same_maker", "cross_maker")
                             and bool(r["home_signal_ok"])),
                            ("home cells", lambda r: r["kind"] == "home"),
                            ("shuffled controls", lambda r: r["kind"] == "shuffled")):
            rs = [r for r in sel if filt(r)]
            if not rs:
                continue
            und = np.array([nod(r) for r in rs], float)
            out.append({"owner": "(summary)", "reader": "", "kind": scope + tag, "rule": rule, "cell_orders": len(rs),
                        "keep_share": float(np.mean([r["keep_share"] for r in rs])),
                        "drop_share": float(np.mean([r["drop_share"] for r in rs])),
                        "undecided_share": float(np.mean([r["undecided_share"] for r in rs])),
                        "not_testable_share": float(np.mean([r.get("not_testable_share", 0.0) for r in rs])),
                        "cell_orders_not_testable": int(sum(float(r.get("not_testable_share", 0.0)) >= 0.5 for r in rs)),
                        "cell_orders_mostly_undecided": int(np.sum(und >= 0.5)),
                        "share_cell_orders_undecided_within_table": float(np.mean(und >= 0.5)),
                        "pool_tasks_mean": float(np.mean([r["pool_tasks"] for r in rs])),
                        "tasks_mean": float(np.mean([r["tasks_mean"] for r in rs])),
                        "calls_mean": float(np.mean([r["calls_mean"] for r in rs]))})
    return out


def _seed_of(*parts) -> int:
    return int.from_bytes(hashlib.sha256("|".join(map(str, parts)).encode()).digest()[:8], "big")


def write_csv(path: Path, rows: list) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    cols = []
    for r in rows:
        for k in r:
            if k not in cols:
                cols.append(k)

    def fmt(v):
        if isinstance(v, (bool, np.bool_)):
            return "True" if v else "False"
        if isinstance(v, (float, np.floating)):
            return "" if not math.isfinite(float(v)) else f"{float(v):.6g}"
        return v

    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for r in rows:
            w.writerow({k: fmt(r.get(k, "")) for k in cols})


def sim_signal_keys(st, cells: dict) -> tuple | None:
    """(task keys (P,), write-task keys (P, C)) aligned with the rows of sim_signal_tables: stream|task id and
    stream|write task (msr.theory.write_task_key; ruling E1), for the two-way interval of the exact bound."""
    if not st.all_sim:
        return None
    from msr.theory import write_task_key
    TK, IK = [], []
    for key, cell in sorted(cells.items()):
        if key[0] != key[1]:
            continue
        probs = sim_true_probs(st, key, cell)
        if probs is None:
            continue
        pr, po = probs
        usable = (cell["items"] != "") & np.isfinite(cell["x"]) & np.isfinite(pr) & np.isfinite(po)
        _, n = stat_coefficients(cell["x"], usable)
        ok = n >= 2
        b = key[2]
        TK.append(np.array([f"{b}|{t}" for t in np.asarray(cell["tasks"]).astype(str)[ok].tolist()]))
        IK.append(np.array([[write_task_key(i, b) if u else "" for i, u in zip(row, urow)]
                            for row, urow in zip(np.asarray(cell["items"]).astype(str)[ok].tolist(),
                                                 usable[ok].tolist())]))
    if not TK:
        return None
    return np.concatenate(TK), np.concatenate(IK)


def sim_signal_tables(st, cells: dict) -> tuple | None:
    """(c, p_owner, usable) pooled over the home cells' probe tasks with the simulator's true
    chances (the simulated study's own signal); None unless every model is simulated."""
    if not st.all_sim:
        return None
    C_, P_, U_ = [], [], []
    for key, cell in sorted(cells.items()):
        if key[0] != key[1]:
            continue
        probs = sim_true_probs(st, key, cell)
        if probs is None:
            continue
        c, _, po, u = _cell_tables(cell, probs)
        C_.append(c)
        P_.append(po)
        U_.append(u)
    if not C_:
        return None
    return np.concatenate(C_), np.concatenate(P_), np.concatenate(U_)


def run(study_name: str, replays: int = REPLAYS, seed: int = 0, out_dir=None, figures: bool = True,
        fig_dir=None, n_null: int = 5000, n_curve: int = 2000, horizon: int = LONG_CAP,
        simtruth_replays: int = 1000, sensitivity: bool = True, verbose: bool = True,
        boundary: bool = True, n_boundary: int | None = None, boundary_tasks=BOUNDARY_TASKS,
        bound: bool = True, n_bound: int | None = None, bound_horizon: int = BOUND_HORIZON,
        margin0: bool = True, n_margin0: int | None = None, margin0_tasks=None,
        guarantee: bool = True, n_store_sets: int | None = None, n_bound_boot: int = BOUND_BOOT,
        world_tasks: int | None = None) -> dict:
    """Every table of addition 2 for one study; returns {name: path}. n_boundary defaults to
    min(BOUNDARY_REPS, n_null), n_bound to min(BOUND_REPS, n_curve) and n_margin0 to
    min(MARGIN0_REPS, n_null); margin0_tasks, n_store_sets and world_tasks default to the registered
    MARGIN0_TASKS, 200 stores and WORLD_TASKS, scaled down when n_null < 1000, so quick runs stay quick."""
    t0 = time.time()
    quick = n_null < 1000
    margin0_tasks = margin0_tasks or (tuple(t for t in MARGIN0_TASKS if t <= 300) if quick else MARGIN0_TASKS)
    n_store_sets = n_store_sets or (10 if quick else 200)
    world_tasks = world_tasks or (2000 if quick else WORLD_TASKS)
    st, design = _study(study_name)
    out = Path(out_dir) if out_dir else st.dir / "analysis"
    cells = load_cells(st, design)
    if not cells:
        raise FileNotFoundError(f"no results/cells/*.npz for study {study_name!r}; run the evaluate stage first")
    paths = {}
    probs = {}
    if getattr(st, "all_sim", False):
        for key, c in sorted(cells.items()):
            pr_ = sim_true_probs(st, key, c)
            if pr_ is not None:
                probs[key] = pr_
    pool = home_pool(cells, {k: v for k, v in probs.items() if k[0] == k[1]} or None)
    usable_pool = pool is not None and pool["m_home"] > 0
    # ---- 1. synthetic: exact null on the paired statistic and the stopping-time curve (generative:
    #         fresh home results for every task, from the home cells' chance table)
    null_rows, curve_rows, cmp_rows = [], [], []
    if usable_pool:
        null_rows = null_check(pool, n_streams=n_null, horizon=horizon, seed=seed)
        allc = stopping_curve(pool, n_streams=n_curve, horizon=horizon, seed=seed,
                              rules=("sequential", "plugin_known_home", "sequential_split"))
        curve_rows = [{**r, "chance_table": pool["p_source"]} for r in allc if r["source"] == "sequential"]
        cmp_rows = [r for r in allc if r["source"] != "sequential"]
    paths["null"] = out / "sequential_null.csv"
    write_csv(paths["null"], null_rows)
    paths["curve"] = out / "sequential_curve.csv"
    write_csv(paths["curve"], curve_rows)
    paths["curve_compare"] = out / "sequential_curve_compare.csv"
    write_csv(paths["curve_compare"], cmp_rows)
    if verbose:
        print(f"[sequential] null and curve: {time.time() - t0:.1f} s")
    # ---- 2. frozen-table replay (stream = the evaluation tasks outside the truth half; the home flag
    #         on the calibration tasks)
    truths, pools = {}, {}
    cell_rows = []
    for key, c in sorted(cells.items()):
        o, r, b, sd = key
        tm = truth_half(c["tasks"][~c["is_calib"]], b, sd, seed)      # the same half for every pair
        pools[key] = stream_pool(c, tm)
        tr = cell_truth(c, seed=seed, home_cell=(o == r), truth_mask=tm)
        truths[key] = tr
        kind = _kind(design, o, r)
        for shuf in (False, True):
            rng = np.random.default_rng([seed, _seed_of("replay", o, r, b, sd, shuf)])
            for row in replay_cell(c, tr, kind, replays, rng, shuffled=shuf, pool=pools[key]):
                cell_rows.append({"owner": o, "reader": r, "stream": b, "seed": sd,
                                  "group": design.group(o, r), "eval_tasks": tr["eval_tasks"],
                                  "theta_est_home": tr.get("theta_est", NAN), "fs_gap_home": tr.get("fs_gap_home", NAN),
                                  **row})
    paths["cells"] = out / "sequential_cells.csv"
    write_csv(paths["cells"], cell_rows)
    paths["rules"] = out / "sequential_rules.csv"
    write_csv(paths["rules"], aggregate_rules(cell_rows))
    paths["pairs"] = out / "sequential_pairs.csv"
    write_csv(paths["pairs"], pair_summary(cell_rows))
    if verbose:
        print(f"[sequential] replay: {time.time() - t0:.1f} s")
    # ---- 3. known truth (simulated studies only)
    sim_rows = []
    for key, c in sorted(cells.items()):
        o, r, b, sd = key
        if key not in probs:
            continue
        for shuf in (False, True):
            rng = np.random.default_rng([seed, _seed_of("simtruth", o, r, b, sd, shuf)])
            row = simtruth_cell(c, probs[key], _kind(design, o, r), simtruth_replays, horizon, rng, shuffled=shuf)
            sim_rows.append({"owner": o, "reader": r, "stream": b, "seed": sd, "group": design.group(o, r), **row})
    paths["simtruth"] = out / "sequential_simtruth.csv"
    write_csv(paths["simtruth"], sim_rows)
    if verbose:
        print(f"[sequential] known truth: {time.time() - t0:.1f} s")
    # ---- 4. sensitivity: thresholds, alpha and the bet (paired rule)
    sens = []
    if sensitivity:
        for rd, rk, al, bet in SENSITIVITY:
            rows = []
            for key, c in sorted(cells.items()):
                o, r, b, sd = key
                rng = np.random.default_rng([seed, _seed_of("replay", o, r, b, sd, False)])
                rows += replay_cell(c, truths[key], _kind(design, o, r), replays, rng, rho_keep=rk, rho_drop=rd,
                                    alpha=al, bet=bet, fixed=False, pool=pools[key])
            for agg in aggregate_rules(rows):
                sens.append({"source": "frozen_table", **agg})
            if usable_pool:
                for cr in stopping_curve(pool, thetas=(0.0, 0.5, 1.0), n_streams=max(200, n_curve // 4),
                                         horizon=horizon, alpha=al, bet=bet, seed=seed, rho_keep=rk, rho_drop=rd):
                    sens.append({"source": "synthetic", "rule": "sequential", "kind": f"theta={cr['theta']:g}",
                                 "rho_keep": rk, "rho_drop": rd, "alpha": al, "bet": bet,
                                 "keep_share": cr["keep_share"], "drop_share": cr["drop_share"],
                                 "undecided_share": cr["undecided_share"], "tasks_median": cr["tasks_q50"],
                                 "tasks_q90": cr["tasks_q90"], "horizon": horizon})
    paths["sensitivity"] = out / "sequential_sensitivity.csv"
    write_csv(paths["sensitivity"], sens)
    # ---- 5. boundary check: generative models, home estimated, the gated rule
    bnd = []
    if boundary:
        bnd = boundary_check(n_reps=n_boundary or min(BOUNDARY_REPS, n_null), checkpoints=boundary_tasks, seed=seed)
    paths["boundary"] = out / "sequential_boundary.csv"
    write_csv(paths["boundary"], bnd)
    if verbose:
        print(f"[sequential] boundary check: {time.time() - t0:.1f} s")
    # ---- 6. the margin-0 (break-even) checks in the three worlds and on the study's table
    m0_rows = []
    worlds = {}
    W_study = study_table(st, cells)
    if margin0:
        worlds = {"reviewer": world_table("reviewer", seed=seed, n_tasks=world_tasks),
                  "hetero": world_table("hetero", seed=seed, n_tasks=world_tasks),
                  "r6": world_table("r6", seed=seed), "study": W_study}
        nm0 = n_margin0 or min(MARGIN0_REPS, n_null)
        m0_rows = margin0_rows(worlds, n_boundary=nm0, n_needed=max(200, nm0 // 2), checkpoints=margin0_tasks,
                               horizon=horizon, seed=seed)
        m0_rows += r6_pop_rows(n_worlds=max(10, nm0 // 50), streams=50, horizon=horizon, seed=seed)
    paths["margin0"] = out / "sequential_margin0.csv"
    write_csv(paths["margin0"], m0_rows)
    if verbose:
        print(f"[sequential] margin 0: {time.time() - t0:.1f} s")
    # ---- 7. the fixed guarantee of the 0.75 rule: the store and the sign gate
    store, gate = [], []
    if guarantee:
        pc5 = r6_c5_population(seed)
        store = store_rows(n_stores=n_store_sets, seed=seed, W=pc5, p_reader=pc5["p_reader"])
        store += store_rows(n_stores=n_store_sets, seed=seed,
                            W=worlds.get("hetero") or world_table("hetero", seed=seed, n_tasks=world_tasks))
        gate = gate_rows(n_streams=max(200, min(1000, n_null // 5)), seed=seed, n_tasks=world_tasks,
                         n_flag=1000 if quick else 4000)
    paths["store"] = out / "sequential_store.csv"
    write_csv(paths["store"], store)
    paths["gate"] = out / "sequential_gate.csv"
    write_csv(paths["gate"], gate)
    orows = order_rows(n_streams=max(200, min(1000, n_null // 5)), horizon=2000, seed=seed,
                       n_tasks=world_tasks) if guarantee else []
    paths["order"] = out / "sequential_order.csv"
    write_csv(paths["order"], orows)
    if verbose:
        print(f"[sequential] store and gate: {time.time() - t0:.1f} s")
    # ---- 8. information lower bound, its interval, its curves and the adaptive factor
    brows, crows, arows = [], [], []
    if bound:
        nb = n_bound or min(BOUND_REPS, n_curve)
        c_r, p_r = reviewer_tables()
        brows += bound_rows("reviewer_model", c_r, p_r, n_streams=nb, horizon=bound_horizon, seed=seed,
                            model="reviewer")
        sig = sim_signal_tables(st, cells)
        sig_keys = sim_signal_keys(st, cells) if sig is not None else None
        if sig is not None:
            srows = bound_rows("sim_signal", sig[0], sig[1], usable=sig[2], n_streams=nb, horizon=bound_horizon,
                               seed=seed)
            if sig_keys is not None:       # the exact bound at the simulator's truth, with a two-way interval
                pz = np.where(np.abs(sig[0]) > 0, sig[1], 0.0)
                ivx = {}
                for dec_, th1_, th0_ in (("keep", 1.0, RHO_KEEP), ("drop", 0.0, RHO_DROP), ("margin0", 1.0, 0.0)):
                    p1_ = shrink_table(pz, sig[0], th1_)
                    ivx[dec_] = exact_bound_twoway(np.nan_to_num(p1_), sig[0], th0_, sig_keys[0], sig_keys[1],
                                                   p_home=pz)
                for r_ in srows:
                    ex = ivx[r_["decision"]]
                    scale = float(binary_kl(r_["power"], r_["alpha"])) / float(binary_kl(0.8, ALPHA))
                    r_.update({"bound_tasks_lo": ex["bound_tasks_lo"] * scale, "bound_tasks_hi": ex["bound_tasks_hi"] * scale,
                               "bound_interval": "95 %, two-way jackknife of K_lf (task id x write task within "
                                                 "stream; influence = per-task Lagrangian), log scale"})
            brows += srows
        W6 = worlds.get("r6") if worlds else world_table("r6", seed=seed)
        if W6 is not None:
            brows += bound_rows("r6_world", W6["c"], W6["p_owner"], measure=False, seed=seed)
        hx = [(k, c["x"], c["y_home"], c["items"] != "", c["tasks"], c["items"]) for k, c in sorted(cells.items())
              if k[0] == k[1] and c["y_home"].shape[-1] >= 2]
        est, ivs = None, {}
        if hx:
            est = plugin_sigma2(np.concatenate([h[1] for h in hx]), np.concatenate([h[2] for h in hx]),
                                np.concatenate([h[3] for h in hx]))
            parts = [plugin_task_parts(h[1], h[2], h[3], tasks=h[4], items=h[5], stream=h[0][2]) for h in hx]
            owners = [h[0][0] for h in hx]
            ivs = {w: plugin_bound_interval(parts, owners, w, n_boot=n_bound_boot, seed=seed) for w in ("keep", "drop")}
            brows += plugin_bound_rows("table_plugin", est, curve_rows, intervals=ivs, margin0_rows=m0_rows)
        long = long_phase_tables(st, cells)
        if est is not None:
            crows = bound_curve_rows(est, ivs.get("keep"), (sig[0], np.where(np.abs(sig[0]) > 0, sig[1], 0.0))
                                     if sig is not None else None, long, truth_keys=sig_keys)
        tabs = {"reviewer_model": reviewer_tables(), **r6_c6_models(n=world_tasks)}
        if sig is not None:
            tabs["sim_signal"] = (sig[0], np.where(np.abs(sig[0]) > 0, sig[1], 0.0))
        if long is not None:
            tabs["sim_long_score_phase"] = long["long"]
        arows = adaptive_rows(tabs)
    paths["bound"] = out / "sequential_bound.csv"
    write_csv(paths["bound"], brows)
    paths["bound_curve"] = out / "sequential_bound_curve.csv"
    write_csv(paths["bound_curve"], crows)
    paths["adaptive"] = out / "sequential_adaptive.csv"
    write_csv(paths["adaptive"], arows)
    if figures:
        paths.update(draw_figures(st, out, fig_dir))
    if verbose:
        print(f"[sequential] {study_name}: {len(cells)} cell-orders, {replays} replays each, "
              f"{time.time() - t0:.1f} s; tables in {out}")
    return paths


# ===========================================================================
# Figures
# ===========================================================================

DEC_STYLE = {"keep": {"color": "#0072B2", "marker": "o", "ls": "-", "label": "KEEP"},
             "drop": {"color": "#D55E00", "marker": "^", "ls": "--", "label": "DROP"},
             "undecided": {"color": "#777777", "marker": "s", "ls": ":", "label": "undecided at cap"}}


def _mark_for(st) -> str:
    from msr.analysis import study_kind
    from msr.figures import MARKS
    return MARKS.get(study_kind(st), "")


def _read(path: Path) -> list:
    if not Path(path).exists():
        return []
    with open(path, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def _f(v) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return NAN


def draw_figures(st, adir: Path, fig_dir=None) -> dict:
    """fig_sequential_stopping (tasks needed and decisions against the true retained share theta,
    paired rule; the earlier rule with a known home value dashed for comparison) and
    fig_sequential_null (error rate by stopping time when the null holds exactly, paired statistic)."""
    from msr.figures import COLUMN_W, _mpl, _save, _sim_mark
    plt = _mpl()
    out = Path(fig_dir) if fig_dir else ROOT / "paper" / "assets"
    mark = _mark_for(st)
    paths = {}
    curve = _read(Path(adir) / "sequential_curve.csv")
    cmp_ = [r for r in _read(Path(adir) / "sequential_curve_compare.csv") if r.get("source") == "plugin_known_home"]
    simt = [r for r in _read(Path(adir) / "sequential_simtruth.csv") if r["kind"] != "shuffled"]
    if curve:
        th = np.array([_f(r["theta"]) for r in curve])
        o = np.argsort(th)
        th = th[o]
        horizon = int(_f(curve[0]["horizon"]))
        fig, axes = plt.subplots(1, 2, figsize=(2 * COLUMN_W, 1.9))
        ax = axes[0]
        q50 = np.array([_f(curve[i]["tasks_q50"]) for i in o])
        q10 = np.array([_f(curve[i]["tasks_q10"]) for i in o])
        q90 = np.array([_f(curve[i]["tasks_q90"]) for i in o])
        ax.fill_between(th, np.minimum(q10, horizon), np.minimum(q90, horizon), color="#56B4E9", alpha=0.35,
                        lw=0, label="paired rule, 10-90 %")
        ax.plot(th, np.minimum(q50, horizon), color="#0072B2", marker="o", lw=1.0, label="paired rule, median")
        if cmp_:
            tc = np.array([_f(r["theta"]) for r in cmp_])
            oc = np.argsort(tc)
            ax.plot(tc[oc], np.minimum([_f(cmp_[i]["tasks_q50"]) for i in oc], horizon), color="#777777",
                    ls="--", lw=0.8, label="home known (not valid if estimated), median")
        if simt:
            ax.scatter([_f(r["theta_true"]) for r in simt], [min(_f(r["tasks_median"]), horizon) for r in simt],
                       s=10, marker="D", facecolors="none", edgecolors="#000000", linewidths=0.6,
                       label="simulator cells (known truth)", zorder=3)
        for k, ls in zip(FIXED_CHECKS, ((0, (1, 1)), (0, (2, 1)), (0, (4, 1)), (0, (6, 2)))):
            ax.axhline(k // CHECKS_PER_TASK, color="#999999", lw=0.6, ls=ls)
            ax.text(th.max(), k // CHECKS_PER_TASK * 1.06, f"{k // CHECKS_PER_TASK} tasks = {k} checks", fontsize=5,
                    color="#666666", va="bottom", ha="right")
        ax.axhline(STORE_TASKS_REAL, color="#444444", lw=0.8)
        ax.text(th.max(), STORE_TASKS_REAL * 1.06,
                f"home store of one order: {STORE_TASKS_REAL} tasks = {CHECKS_PER_TASK * STORE_TASKS_REAL} checks",
                fontsize=5, color="#444444", va="bottom", ha="right")
        ax.text(th.min(), horizon * 1.06, f"not decided by {horizon} tasks", fontsize=5, color="#444444", va="bottom")
        ax.set_yscale("log")
        ax.set_ylim(1, horizon * 2.2)
        ax.set_xlabel(r"true retained share $\theta=\bar A_{swap}/\bar A_{home}$")
        ax.set_ylabel("fresh-check tasks until a decision")
        for v in (RHO_DROP, RHO_KEEP):
            ax.axvline(v, color="#BBBBBB", lw=0.6)
        ax.legend(loc="upper center", fontsize=5, bbox_to_anchor=(0.5, -0.28), ncol=2)
        ax2 = axes[1]
        for name in ("keep", "drop", "undecided"):
            s = DEC_STYLE[name]
            ax2.plot(th, [_f(curve[i][f"{name}_share"]) for i in o], color=s["color"], marker=s["marker"],
                     ls=s["ls"], label=s["label"], markersize=3)
        for v in (RHO_DROP, RHO_KEEP):
            ax2.axvline(v, color="#BBBBBB", lw=0.6)
        ax2.axhline(ALPHA, color="#000000", lw=0.5, ls=(0, (1, 2)))
        ax2.text(th.max(), ALPHA + 0.02, rf"$\alpha$={ALPHA:g}", ha="right", fontsize=5)
        ax2.set_ylim(-0.02, 1.02)
        ax2.set_xlabel(r"true retained share $\theta$")
        ax2.set_ylabel(f"share of streams (horizon {horizon} tasks)")
        ax2.legend(loc="upper center", fontsize=5, bbox_to_anchor=(0.5, -0.28), ncol=3)
        _sim_mark(fig, mark)
        fig.tight_layout()
        for p in _save(fig, out, "fig_sequential_stopping"):
            paths[f"fig:{p.name}"] = p
    null = _read(Path(adir) / "sequential_null.csv")
    if null:
        fig, ax = plt.subplots(figsize=(COLUMN_W, 1.8))
        styles = {("table", "keep"): ("#0072B2", "o", "-"), ("table", "drop"): ("#0072B2", "o", "--"),
                  ("two_point", "keep"): ("#D55E00", "^", "-"), ("two_point", "drop"): ("#D55E00", "^", "--"),
                  ("beta", "keep"): ("#009E73", "s", "-"), ("beta", "drop"): ("#009E73", "s", "--")}
        for (dist, test), (col, mk, ls) in styles.items():
            rs = [r for r in null if r["distribution"] == dist and r["test"] == test]
            if not rs:
                continue
            ax.plot([_f(r["by_task"]) for r in rs], [_f(r["error_rate"]) for r in rs], color=col, marker=mk,
                    ls=ls, markersize=3, label=f"{dist.replace('_', '-')}, false {test}")
        ax.axhline(ALPHA, color="#000000", lw=0.8)
        ax.text(1, ALPHA * 1.04, rf"$\alpha$ = {ALPHA:g}", fontsize=5, va="bottom")
        ax.set_xscale("log")
        ax.set_ylim(0, max(0.08, ALPHA * 1.5))
        ax.set_xlabel("stopping time (fresh-check tasks)")
        ax.set_ylabel("error rate, null exactly true")
        ax.legend(fontsize=4.5, ncol=2, loc="upper left")
        _sim_mark(fig, mark)
        fig.tight_layout()
        for p in _save(fig, out, "fig_sequential_null"):
            paths[f"fig:{p.name}"] = p
    return paths


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--study", required=True)
    ap.add_argument("--replays", type=int, default=REPLAYS)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--no-figures", action="store_true")
    ap.add_argument("--out", default=None, help="tables directory (default runs/<study>/analysis)")
    ap.add_argument("--fig-dir", default=None, help="figures directory (default paper/assets)")
    ap.add_argument("--boundary-reps", type=int, default=None)
    a = ap.parse_args(argv)
    run(a.study, replays=a.replays, seed=a.seed, out_dir=a.out, figures=not a.no_figures, fig_dir=a.fig_dir,
        n_boundary=a.boundary_reps)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
