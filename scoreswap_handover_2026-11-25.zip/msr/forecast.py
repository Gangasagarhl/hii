"""A pre-swap forecast of how much validity the old scores keep ("swap readiness", addition 1).

Everyday picture: before the new helper touches the box of repair tips, the garage watches the old
and the new helper do some plain jobs without any tip. If the two get the same jobs right and the
same jobs wrong more often than their skill levels alone would explain, perhaps tips that helped
the old one will help the new one too. This module asks whether such a cheap, tip-free check
predicts how well the old tip scores still rank the tips after the swap, and checks the answer
honestly on models left out of the fit.

Nothing here is a new statistical method: error consistency is Cohen's kappa on right/wrong
patterns (Cohen 1960; used to compare models' errors by Geirhos et al. 2020), the forecasts are
ordinary least squares with pre-stated predictors, validation is leave-one-model-out (and, for the
incremental model, leave-both-models-out), the "20 fresh checks" baseline follows the 20-probe check
of Goyal and Ray (2026), and the test is double semi-partialling over relabelings of the models
(Dekker, Krackhardt and Snijders 2007, Psychometrika 72:563-581). What is new is the forecast target
(the ranking validity of learned per-item memory scores after a model swap) and the requirement
that the predictor uses no memory item at all.

Predictors per ordered pair (owner A, reader B), from runs with NO memory item only: the write-phase
answers and the no-memory run of the score tasks (build), and the no-memory probe runs of the
CALIBRATION tasks. No evaluation task enters a predictor, so predictors and targets share no task.
- ec: error consistency, (c_obs - c_exp) / (1 - c_exp), every repeat of A against every repeat of B
  on the same task; c_exp = pA pB + (1 - pA)(1 - pB) over the same comparisons;
- agree: the raw agreement c_obs;
- gap = X_B - X_A and abs_gap = |gap|, X = no-memory success on the predictor tasks;
- x_owner = X_A, x_reader = X_B; same_maker (1 if A and B come from one maker);
- owner_newer, reader_newer: +0.5 for the newer model of its maker, -0.5 for the older one (from the
  design's upgrade pairs; newer_coding), a design fact used only as a control of F1.

Targets per ordered swap (headline score family, evaluation tasks, pooled over orders, then the
mean over streams, as Part 2.4):
- T = N_swap / N_home (primary): N = mean over evaluation tasks of a(tau), the per-task agreement of
  the old-score order with the outcomes (msr.sequential.task_stat; linear in the outcomes, so its
  expectation does not depend on outcome noise);
- c_swap = Cw after the swap; drop = C_home - C_swap; R = (C_swap - .5)/(C_home - .5).
T and R are reported (and enter F1 and the models) when the swap's OWNER passes THE home-signal flag
of msr.metrics (one rule in all code, R6 W3): the owner's signed validity on its CALIBRATION tasks
(with-item home results, repeats 1-2, the values of msr.theory.calib_parts) at least 2 standard
errors above 0 (calibration_z + theta_status_calibration, or msr.metrics.home_signal_flag once it
exists; owner_home_flag). It replaced a same-task 4-SE rule on N_home and C_home, which selected on
the estimate's own noise. The flag reads the calibration tasks' WITH-item home results; the
predictors read the NO-memory runs of the same calibration tasks: same tasks, no shared outcome.

Models (pre-stated, no tuning; OLS with an intercept; all descriptive): grand mean, same_maker
alone, gap alone and same_gap = the controls of F1 (baselines); ec alone, ec + gap and
ec_same_gap = ec + the controls of F1 (forecasts); every other predictor alone. Validation: leave
one MODEL out: fit on the swaps that do not involve model m, predict every swap that involves it;
each swap is predicted twice (once with its owner and once with its reader left out) and all
predictions count. Out-of-fold R^2 = 1 - MSE / MSE of the leave-one-model-out grand mean.
Differences "a - b" (forecast minus baseline, same folds, bootstrap intervals): ec and ec_gap minus
same_maker and gap, and "ec_same_gap - same_gap", the out-of-fold counterpart of F1. Because leave
one model out still sees the other model of every predicted swap, same_gap and ec_same_gap (target
T) are also validated leaving BOTH models out (rows *_both_out). The post-swap baseline estimates
the target directly from 20 fresh checks per bank (5 calibration tasks x 4 candidates, one stored
repeat each), 200 draws. A study without upgrade pairs drops the (constant) position columns.

Test (one confirmatory-secondary test, one-sided alpha 0.05, no Holm; permutation_tests):
- F1, incremental value: does ec predict T beyond the same-maker flag, capability and the
  newer/older position? Statistic: the partial correlation of T and ec given
  Q = [1, same_maker, x_owner, x_reader, abs_gap, owner_newer, reader_newer] (span: same maker, gap,
  abs gap, the capability level and whether owner / reader is the newer model of its maker) over the
  swaps whose owner passes the flag, H1 > 0 (= the t of ec in OLS T ~ Q + ec). Null by double
  semi-partialling: ec is residualised on Q, the models of the residual ec array are relabelled,
  the statistic is recomputed with T still controlled for Q. Relabelings: models within their maker
  and whole makers among makers of the same size (4 makers x 2 models: 2^4 x 4! = 384, enumerated);
  they keep every pair's same-maker flag. p = share of relabelings with a statistic >= the observed
  (identity included). Smallest attainable p: 1/384 with 8 models; with 4 models from 2 makers only
  2^2 x 2! = 8 relabelings exist (p >= 0.125), so F1 is "not testable"; makers of 2 models need 3
  makers (6 models, 48). Sensitivity columns (never the decision): p over all n! relabelings and p
  with the controls before the position was added (p_one_sided_without_position).
- F0_descriptive: the plain Spearman(ec, T), WITHOUT a p-value. The test it used to carry (the old
  F1: the models of the ec array relabelled, Spearman with T; a Mantel / QAP test of "the two
  arrays are unrelated") rejects whenever both arrays carry the maker structure, even when ec adds
  nothing beyond the flag: 47 % of worlds at p <= 0.025 in null_world_w1 (the reviewer's world;
  1,500 worlds; 45 % in 400 worlds with the code it replaced).
  The old F2 (out-of-fold Spearman of ec + gap) is no longer a test.
- pair_incremental_test: the same test for ANY pair-level predictor and target (P1 of msr.analysis,
  "agreement predicts theta", audit N3, uses it instead of a plain label permutation).
Level and power by simulation (8 models, 4 makers x 2; null_world_w1..w8 and alt_world below; the
reviewer's worlds of paper/reviews/round2/r6_checks/c7_forecast.py; tests/test_forecast.py checks
them with fewer worlds). False rejections at one-sided 0.05, maker-preserving relabelings, Q
before -> now (the position added 24 Nov 2026); 1,500 worlds unless stated, Monte Carlo SE about 0.006:
    W1 the reviewer's world (round 1)               0.047 -> 0.050
    W2 capability, owner/reader and model effects   0.053 -> 0.059 (4,500 worlds)
    W3 maker-pair effects in ec only                0.055 -> 0.053
    W4 model effects in both arrays                 0.047 -> 0.051
    W6 maker-pair effects in both arrays            0.055 -> 0.051
    W5 'max': T on max(Z_s, Z_t)                    0.057 -> 0.061
    W5 'level': both on the capability level        0.049 -> 0.054 (0.139 without the level in Q)
    W5 'square': both curved in the gap             0.106 -> 0.122 (the limit: Q is linear)
    alt_world rho 0 (pair / half-model noise)       0.036 -> 0.037 / 0.043 -> 0.045
    W7 'owner' (R6's R2: theta +0.15 for a newer OWNER; 8,000 worlds, SE 0.0025)      0.060 -> 0.059
       the same worlds without the newer effect                                       0.054 -> 0.059
    W7 'both' (the position in theta AND in ec; 4,000 worlds)                         0.118 -> 0.060
    W7 'both_reader' (a newer READER in theta, the position in ec; 2,000 worlds)      0.106 -> 0.054
    upgrade-vs-downgrade inside a maker only (not in the span; 2,000 worlds)          0.052 -> 0.059
    R6's R0 / R1 (heavy-tailed ratio noise) / R3 / R4 (1,000 worlds each)  0.052 / 0.035 / 0.050 / 0.046
                                                                       -> 0.053 / 0.035 / 0.053 / 0.052
  So the reviewer's 0.064 in W7 'owner' is mostly not the position: on the same worlds without the
  newer effect the test gives 0.054, and adding the position leaves 0.059 (what is left is the
  approximation of double semi-partialling when both arrays carry model effects, as in W2). The
  position matters when BOTH arrays carry it (W7 'both': 0.118 without it); that is the rejection R6
  warns about (an upgrade/downgrade asymmetry read as error consistency), so it is in Q. The price:
  about half a point of level where both arrays carry model effects (W2, W7: 0.053-0.054 -> 0.059).
  The stated limits: double semi-partialling is approximate (up to about 0.06 here) and Q is linear
  (W5 'square' 0.11-0.12).
  Power at one-sided 0.05 (alt_world: ec measured from 0/1 arrays on 2,250 tasks, T noise sd 0.2;
  600 worlds each, SE <= 0.02), before -> now, pair noise and half the noise at the model level:
  rho 0.3: 0.60 -> 0.57 and 0.67 -> 0.68; rho 0.6: 0.99 -> 0.98 and 0.99 -> 0.98; R6's R5 (a mean
  partial correlation of 0.14, 1,000 worlds): 0.26 -> 0.27. Earlier runs (round 1): the all-8!
  group holds the level in W1-W4 but not in W6 (0.072), at about 6 points more power at rho 0.3, so
  the maker-preserving group is the primary.
  Re-run for R7 W11 (24 Nov 2026; model_level_checks; 4,000 worlds per null world, Monte Carlo SE
  about 0.0035 at 0.05; 2,000 per power setting, SE about 0.011 at 0.5; seeds and raw numbers in
  docs/power/forecast_r7_w11.json). Registered Q / Q with owner and reader fixed effects, the same
  worlds for both (same seed):
    W1 0.048 / 0.048     W2 0.051 / 0.050     W3 0.050 / 0.049     W4 0.061 / 0.051    W6 0.050 / 0.046
    W5 'max' 0.055 / 0.047     W5 'level' 0.060 / 0.051     W5 'square' 0.106 / 0.102
    W7 'owner' 0.055 / 0.046   W7 'both' 0.058 / 0.056      W7 'both_reader' 0.058 / 0.046
    W8 (null_world_w8: a property of each MODEL raises its error consistency with every model and
       theta, no pair-level link), the latent's share of the model-level variance of both arrays
       0 / 1/5 / 1/2 / 4/5 (s = 0 / 0.015 / 0.03 / 0.06):
         through the owner    0.063 / 0.085 / 0.170 / 0.446   with fixed effects 0.050 at every size
         through the reader   0.065 / 0.083 / 0.168 / 0.456   with fixed effects 0.055 at every size
         through both         0.059 / 0.116 / 0.284 / 0.699   with fixed effects 0.048 at every size
       (SE 0.003-0.008; with fixed effects the latent drops out exactly, so each row repeats its s = 0 value)
    alt_world rho 0, pair noise / half the noise at the model level   0.047 / 0.051 and 0.052 / 0.045
    power, alt_world rho 0.3: pair noise 0.596 / 0.484; half the noise at the model level 0.672 / 0.690
                      rho 0.6: pair noise 0.989 / 0.942; half the noise at the model level 0.991 / 0.987
    the flag's selection of owners (theta NaN on every swap of the dropped owners, ec kept), registered
    Q; none dropped / 1 or 2 dropped at random / the lowest capability / the lowest mean theta:
         W2           0.055 / 0.054, 0.054 / 0.059, 0.059 / 0.050, 0.050   (fixed effects 0.048-0.052)
         W7 'owner'   0.062 / 0.060, 0.057 / 0.056, 0.053 / 0.060, 0.058   (fixed effects 0.050-0.053)
         W8 'owner', s = 0.03: none 0.171 / at random 0.152, 0.136 / the lowest latent 0.118, 0.092
                               (fixed effects 0.052-0.058)
  Statistics considered and NOT adopted (R6 W10b, his heavy-tailed world R1, 1,000 worlds, and R1
  with a pair-level signal, 2,000 worlds): Spearman partial (ranks of T and ec): level 0.054 / 0.040
  (Q before / now), power 0.19 / 0.20 against 0.15 / 0.16, but it inflates the level where capability
  acts non-linearly in both arrays (R6's R3, R4: 0.075 / 0.086, now 0.080 / 0.092), because the ranks
  are no longer linear in the controls. Precision weights with the TRUE per-pair variances (an upper
  bound on what estimated weights could do): level 0.052, power 0.23 / 0.24; the weights of real
  data would be estimated from the same targets and were not validated, and the flag already drops
  the weakest owners. Owner and reader fixed effects in Q: an earlier run without code in this
  repository gave level 0.035-0.054 except W5 'square' (0.111) and power 0.46 at rho 0.3 with pair
  noise; the re-run with code (controls(..., fixed_effects=True), above) gives 0.046-0.056 except
  W5 'square' (0.102) and power 0.48. Not adopted so far; see the next paragraph.

What F1 and P1 detect (R7 W11 and his question 8; P1 is F1's machinery with theta and kappa). They
detect association at the pair level and at the model level alike. Error consistency is symmetric
and Q treats owner and reader alike, so when every swap is used the test depends on theta only
through (theta_st + theta_ts) / 2 (exactly; tests/test_forecast.py) and cannot tell an owner effect
from a reader effect. The relabelings move whole models, so a property of a MODEL that raises its
error consistency with every other model and also raises theta counts as "incremental value": in
null_world_w8 (no pair-level link; 4,000 worlds per row) F1 rejects in 0.085, 0.17 and 0.45 of
worlds when that property carries 1/5, 1/2 and 4/5 of the model-level variance of both arrays and
acts through the owner (0.083, 0.17, 0.46 through the reader; 0.12, 0.28, 0.70 through both),
against 0.059-0.065 in the same worlds without it. So a pass of F1 or P1 says "error consistency and
theta move together beyond same maker, capability and position"; it may be a property of the
models, and it does not show that a pair's own error consistency predicts that pair's theta. The
second limit is the linear Q: with capability curved in both arrays the level is 0.106 (W5
'square', 4,000 worlds, SE 0.005; 0.122 in the 1,500-world run above), and fixed effects do not
remove it (0.102). The flag's selection of owners (R7's third point) is not what makes the test
fragile: dropping every swap of 1 or 2 owners, at random, the lowest capability or the lowest mean
theta, leaves the level at 0.050-0.059 in W2 and 0.053-0.060 in W7 'owner' (4,000 worlds each, SE
about 0.0036; 0.055 and 0.062 with no owner dropped, the same worlds), and where a model property
is in both arrays (W8 'owner', s = 0.03) dropping owners lowers the false rejections (0.17 to 0.14
for two owners at random, to 0.09 for the two with the lowest latent), because fewer owners carry
less model-level signal. Owner and reader fixed effects (controls(..., fixed_effects=True);
pair_incremental_test(..., fixed_effects=True) for P1) would fix the first point: the test becomes
exactly blind to any additive property of the owner or of the reader in either array and tests the
pair-level part only (level 0.048-0.055 in W8 whatever the property's size, 0.046-0.056 in W1-W7
except W5 'square', 0.048-0.058 under the flag's selection). The cost is power where the signal has
a model-level part: at rho 0.3 with pair noise 0.48 against 0.60 (alt_world, the same 2,000 worlds,
SE 0.011; 0.46 in the earlier 600-world run), at rho 0.6 0.94 against 0.99; with half the noise at
the model level they lose nothing (0.69 against 0.67; 0.99 and 0.99), because they remove that
noise too. With 8 models they also take 10 more of the 56 swaps' degrees of freedom (Q of rank 17
instead of 7). The registered Q is unchanged; whether F1 stays a registered test with the reading
above, moves to fixed effects, or becomes exploratory is the manager's decision.

Capability-gap control (decision D7; capability_rows, capability_regression; descriptive):
forecast_capability.csv, one row per ordered swap: theta = V_swap / V_home (msr.metrics, equal to the
analysis's theta), the retained agreement theta x sqrt(S_owner / S_reader) (a correlation-type
measure; column retained_order, retained_order_value; S =
msr.theory's S_oo2 / S_nn2, the within-session cross-repeat estimate of the item effects' spread on
the same candidate pairs, = theory's R_std), the spreads and S_reader / its bootstrap SE, the gap
(signed reader minus owner and absolute, no-memory success), ec, same_maker, the position and the
owner's flag. forecast_capability_regression.csv: theta and the retained agreement each regressed on
[1, same_maker, gap, abs_gap, ec] (OLS), 95 % task-bootstrap percentile intervals, and for ec the
maker-preserving p beyond the other terms.

Intervals: tasks resampled within each (stream, order), evaluation tasks with the evaluate stage's
own draws (msr.metrics.bootstrap_counts with stratum_seed), predictor tasks with their own draws.
Item clusters (ruling E1: a statistic that pools more than one owner clusters items by WRITE TASK
within stream, item id "<write task id>@<owner>"): nothing here treats the memory items as
sampled. Every target is per swap, so per owner (and the home-signal flag is computed per owner);
the statistics that pool swaps of several owners (the leave-one-model-out models, F1 and its
relabelings, the capability regression) resample tasks only, and F1's relabelings move models, not
items. So the forecast's intervals condition on the write tasks and the items written from them
(items fixed): a write-task component shared by owners is not in them. The write tasks also serve
as predictor tasks; their no-memory answers enter ec and are resampled as tasks in the predictor
draws, independently of the targets' draws.

Outputs (runs/<study>/analysis/): forecast_pairs.csv, forecast_reliability.csv,
forecast_models.csv, forecast_predictions.csv, forecast_tests.csv, forecast_capability.csv,
forecast_capability_regression.csv; figure fig_forecast_readiness (paper/assets, or beside the
tables when the command line names --out).

Run:  python -m msr.forecast --study sim
The R7 W11 numbers: model_level_checks(blocks=(block,)) for each of 'w8', 'nulls', 'select', 'power'
(about 2.5, 4, 5 and 1.5 minutes on one core); raw numbers in docs/power/forecast_r7_w11.json.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import itertools
import json
import math
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from msr.sequential import _mean_rep, load_cells, task_stat, write_csv  # noqa: E402

NAN = float("nan")

# --------------------------------------------------------------------------- pre-stated constants
ALPHA = 0.05                   # one-sided
N_TESTS = 1                    # F1 only (incremental value of ec); a single test, no Holm
PRIMARY_GROUP = "maker"        # relabeling group of F1 (see permutation_tests; "all" = every n! relabeling)
# Controls of F1 (with an intercept): the same-maker flag, both capabilities, the absolute gap and the
# newer/older position of owner and reader (newer_coding: +0.5 the newer model of its maker, -0.5 the
# older, from the design's upgrade pairs). Their span holds same_maker, gap = x_reader - x_owner,
# abs_gap, the capability level x_owner + x_reader and whether the owner / the reader is the newer model
# of its maker (not the upgrade-vs-downgrade contrast inside a maker alone, an interaction with
# same_maker; tests/test_forecast.py checks the span). The level was added to the pre-stated
# [1, same_maker, gap, abs_gap] after simulation (null_world_w5 'level': 0.139 false rejections without
# it, 0.057 with it); the position after the second statistics review (R6 W10; null_world_w7 'both':
# 0.116 without it, 0.059 with it; module docstring for level and power elsewhere).
F1_CONTROLS = ("same_maker", "x_owner", "x_reader", "abs_gap", "owner_newer", "reader_newer")
F1_CONTROLS_WITHOUT_POSITION = ("same_maker", "x_owner", "x_reader", "abs_gap")   # Q before 24 Nov 2026 (sensitivity)
TARGETS = ("T", "c_swap", "drop", "R")
PRIMARY_TARGET = "T"
PREDICTORS = ("ec", "agree", "gap", "abs_gap", "x_owner", "x_reader", "same_maker")
SYMMETRIC = ("ec", "agree", "abs_gap", "same_maker")
MODELS = {                     # name -> (predictors, role); all descriptive, the test is F1
    "grand_mean": ((), "baseline"),
    "same_maker": (("same_maker",), "baseline"),
    "gap": (("gap",), "baseline"),
    "same_gap": (F1_CONTROLS, "baseline: the controls of F1 (same maker, gap, abs gap, capability level, "
                              "newer/older position)"),
    "ec": (("ec",), "descriptive forecast (ec alone)"),
    "ec_gap": (("ec", "gap"), "descriptive forecast (ec + gap)"),
    "ec_same_gap": (("ec",) + F1_CONTROLS, "descriptive forecast: ec beyond the controls of F1"),
    "agree": (("agree",), "descriptive"),
    "abs_gap": (("abs_gap",), "descriptive"),
    "x_owner": (("x_owner",), "descriptive"),
    "x_reader": (("x_reader",), "descriptive"),
}
BOTH_OUT_MODELS = ("same_gap", "ec_same_gap")   # also validated leaving BOTH models out (target T only)
SUBSAMPLE_TASKS = 5            # 5 calibration tasks x 4 candidates = 20 fresh checks per bank


def forecast_calls(n_write: int = 250, n_score: int = 500, n_calib: int = 100, no_memory_repeats: int = 2) -> dict:
    """Model calls of the pre-swap forecast for one swap day (one stream order), read by the single cost
    table. The forecast needs, BEFORE the swap but after the new model is available, the NEW model's
    no-memory answers on the write tasks, the score tasks and the calibration tasks (repeats), and the
    OLD model's no-memory answers on the calibration tasks; the old model's write and score-task no-memory
    answers come free with its build. Main design: 250 + 500 + 200 = 950 new-model calls and 200
    old-model calls: 1,150 calls per swap day (none of them a check of a memory item)."""
    new = n_write + n_score + n_calib * no_memory_repeats
    old = n_calib * no_memory_repeats
    return {"new_model_calls_before_swap": new, "old_model_calls": old, "total_calls": new + old}
SUBSAMPLE_DRAWS = 200
PERM_CAP = 50000
# The capability-gap control (decision D7): theta and retained agreement regressed on these terms (with an
# intercept), descriptive; forecast_capability.csv and forecast_capability_regression.csv.
CAPABILITY_TERMS = ("same_maker", "gap", "abs_gap", "ec")


# ===========================================================================
# Small helpers
# ===========================================================================


def _h(*parts) -> int:
    return int.from_bytes(hashlib.sha256("|".join(map(str, parts)).encode()).digest()[:8], "big")


def _rank(a: np.ndarray) -> np.ndarray:
    from scipy.stats import rankdata
    return rankdata(a, axis=-1)


def spearman(x, y) -> float:
    x, y = np.asarray(x, float), np.asarray(y, float)
    m = np.isfinite(x) & np.isfinite(y)
    if m.sum() < 3:
        return NAN
    rx, ry = _rank(x[m]), _rank(y[m])
    if rx.std() == 0 or ry.std() == 0:
        return NAN
    return float(np.corrcoef(rx, ry)[0, 1])


def spearman_rows(X: np.ndarray, y: np.ndarray) -> np.ndarray:
    """Spearman of every row of X (P, n) with y (n,), average ranks for ties."""
    rx = _rank(X)
    ry = _rank(y)
    rx = rx - rx.mean(1, keepdims=True)
    ry = ry - ry.mean()
    den = np.sqrt((rx ** 2).sum(1) * (ry ** 2).sum())
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(den > 0, (rx @ ry) / den, np.nan)


def kappa(agree, pa, pb):
    pexp = pa * pb + (1 - pa) * (1 - pb)
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(pexp < 1, (agree - pexp) / (1 - pexp), np.nan)


def _ci(d: np.ndarray) -> tuple:
    d = np.asarray(d, float)
    d = d[np.isfinite(d)]
    if d.size < 2:
        return NAN, NAN, NAN
    return float(np.percentile(d, 2.5)), float(np.percentile(d, 97.5)), float(d.std(ddof=1))


# ===========================================================================
# The home-signal flag (one rule in all code: msr.metrics) and the retained agreement (decision D2)
# ===========================================================================


def owner_home_flag(values) -> dict:
    """THE home-signal flag of msr.metrics for one owner, from its per-calibration-task signed
    validities V (owner_calibration_values). {"z", "defined", "status", "rule"}.

    Adapter (24 Nov 2026): the statistics worker may add one function for the flag to msr.metrics
    (named home_signal_flag); when it exists it is used, else the current pair
    msr.metrics.calibration_z + theta_status_calibration (defined when z >= THETA_CAL_MIN_Z = 2).
    The new function may return a dict (keys z / status / defined), a (z, status) pair, a status
    string or a bool; anything else falls back to the pair."""
    from msr import metrics as MM
    fn = getattr(MM, "home_signal_flag", None)
    if callable(fn):
        try:
            r = fn(values)
        except (TypeError, ValueError):           # another signature: fall back to the pair
            r = None
        z = status = defined = None
        if isinstance(r, dict):
            z, status, defined = r.get("z", r.get("z_cal")), r.get("status"), r.get("defined")
        elif isinstance(r, (tuple, list)) and len(r) == 2:
            z, second = r
            if isinstance(second, (bool, np.bool_)):
                defined = bool(second)
            else:
                status = second
        elif isinstance(r, str):
            status = r
        elif isinstance(r, (bool, np.bool_)):
            defined = bool(r)
        if status is not None or defined is not None:
            if z is None:
                z = MM.calibration_z(values)
            if defined is None:
                defined = status == MM.THETA_DEFINED
            if status is None:
                status = MM.THETA_DEFINED if defined else MM.THETA_CAL_UNDEFINED
            return {"z": float(z) if z is not None else NAN, "defined": bool(defined), "status": str(status),
                    "rule": "msr.metrics.home_signal_flag"}
    z = MM.calibration_z(values)
    status = MM.theta_status_calibration(z)
    return {"z": z, "defined": status == MM.THETA_DEFINED, "status": status,
            "rule": f"msr.metrics.calibration_z >= {MM.THETA_CAL_MIN_Z:g} (theta_status_calibration)"}


def owner_calibration_values(cells: dict, owner: str, streams, seeds) -> np.ndarray:
    """The owner's per-calibration-task signed validity V (Part 2.4 as revised): the headline score
    family's scores x against the owner's own home results y_home (repeats 1-2) on the CALIBRATION
    rows of the owner's home cell, every stream and order pooled; the values msr.theory.calib_parts
    builds ("V:<family>") and msr.theory.calib_z / the analysis turn into the flag (equal on the
    simulated study). These are WITH-item home results of the calibration tasks; the forecast's
    predictors use the NO-memory runs of the same calibration tasks (cell "none" arrays): different
    data from the same tasks, so the flag and the predictors share tasks but no outcome."""
    from msr.metrics import signed_validity_parts
    vals = []
    for b in streams:
        for sd in seeds:
            c = cells.get((owner, owner, b, sd))
            if c is None:
                continue
            cal = np.asarray(c["is_calib"], bool)
            if not cal.any():
                continue
            V, _ = signed_validity_parts(c["x"][cal], _mean_rep(c["y_home"][cal]), c["items"][cal] != "")
            vals.append(V)
    return np.concatenate(vals) if vals else np.zeros(0)


RETAINED_METRIC_NAMES = ("retained_agreement", "retained_order")   # msr.metrics' names, the new one first


def _metrics_retained() -> tuple:
    """(name, function) of msr.metrics' retained agreement: `retained_agreement` (the name after the
    ruling on words, E3) or `retained_order` (the earlier name), whichever exists, the new name
    first; (None, None) when neither exists."""
    from msr import metrics as MM
    for name in RETAINED_METRIC_NAMES:
        fn = getattr(MM, name, None)
        if callable(fn):
            return name, fn
    return None, None


def retained_order_value(theta, s_owner, s_reader) -> float:
    """Retained agreement = theta x sqrt(S_owner / S_reader), a correlation-type measure (decision
    D2; = theory's R_std; the function and the CSV column keep the earlier word "order" because other
    code reads them). NaN (not estimated) when a value is missing or a spread is not positive. The
    analysis also reports it as "not estimated (reader's spread below z = 2)" when the reader's spread
    on the calibration tasks is under 2 SE (msr.metrics.ORDER_MIN_Z); this descriptive table does not
    apply that rule and gives S_reader_z (the evaluation-task bootstrap z of S_reader) beside it.
    Adapter: uses msr.metrics.retained_agreement or msr.metrics.retained_order (whichever exists, the
    new name first), called as f(theta, s_owner, s_reader), when the statistics worker has added it,
    else this formula; a dict result gives its "value" entry (or the entry named like the function),
    a tuple its first element, and a call that fails falls back to the formula."""
    name, fn = _metrics_retained()
    if fn is not None:
        try:
            r = fn(theta, s_owner, s_reader)
            if isinstance(r, dict):
                r = r.get("value", r.get(name))
            elif isinstance(r, (tuple, list)):
                r = r[0]
            return float(r)
        except (TypeError, ValueError, IndexError):
            pass
    try:
        t, so, sr = float(theta), float(s_owner), float(s_reader)
    except (TypeError, ValueError):
        return NAN
    if not (math.isfinite(t) and math.isfinite(so) and math.isfinite(sr)) or so <= 0 or sr <= 0:
        return NAN
    return t * math.sqrt(so / sr)


def newer_coding(models, upgrades=(), makers=None) -> np.ndarray:
    """Per model: +0.5 for the newer model of its maker, -0.5 for the older one, 0 otherwise (a
    maker with one model, or a model that is old in one upgrade pair and new in another). From the
    design's upgrade pairs [(old, new)] when given; else (simulated worlds) by position inside the
    maker: with makers of two, the second model of each maker is the newer one."""
    models = list(models)
    if upgrades:
        old = {a for a, _ in upgrades}
        new = {b for _, b in upgrades}
        return np.array([0.5 if (m in new and m not in old) else -0.5 if (m in old and m not in new) else 0.0
                         for m in models])
    if makers is None:
        return np.zeros(len(models))
    out = np.zeros(len(models))
    mem = {}
    for i, g in enumerate(makers):
        mem.setdefault(g, []).append(i)
    for idx in mem.values():
        if len(idx) > 1:
            for p, i in enumerate(idx):
                out[i] = p / (len(idx) - 1) - 0.5
    return out


def min_models_needed(alpha: float = ALPHA, n_tests: int = N_TESTS, models_per_maker: int = 1) -> int:
    """Smallest number of models whose relabeling group can reach the first Holm step alpha/n_tests
    (with N_TESTS = 1: alpha itself), for makers of `models_per_maker` models each. The group of the
    test (models within makers, whole makers among makers of one size) has k! (s!)^k elements for
    k makers of s models, so the rule is the smallest n = k s with 1 / (k! (s!)^k) <= alpha/n_tests:
    s = 1 (every model its own maker, all n! relabelings): 4 models at 0.05 (1/24 = 0.042);
    s = 2: 6 models (3! 2^3 = 48; 2 makers of 2 give only 8 relabelings). For makers of unequal
    sizes see models_needed(makers)."""
    s = max(1, int(models_per_maker))
    k = 1
    while 1.0 / (math.factorial(k) * math.factorial(s) ** k) > alpha / n_tests:
        k += 1
    return max(2, k * s)


# ===========================================================================
# Loading: no-memory outcomes (predictors) and per-task targets
# ===========================================================================


def _read_jsonl(p: Path) -> list:
    if not p.exists():
        return []
    with open(p, encoding="utf-8") as f:
        return [json.loads(x) for x in f if x.strip()]


def load_nomemory(st, design, cells: dict) -> dict:
    """{(stream, seed): {"tasks": [...], "S": (M, n), "N": (M, n), "source": [...]}}: per model and
    predictor task, successes and runs with no memory item: write phase (1 run), the score phase's
    no-memory run (1 run) and the calibration probe tasks' no-memory runs (repeats). Evaluation
    tasks are never used."""
    M = len(design.models)
    out = {}
    for b in design.streams:
        for sd in design.seeds:
            calib, _ev = st.calib_eval(b, sd)
            pred_tasks = list(dict.fromkeys(list(st.write_ids(b, sd)) + list(st.score_ids(b, sd)) + list(calib)))
            pos = {t: j for j, t in enumerate(pred_tasks)}
            src = ["write"] * len(st.write_ids(b, sd)) + ["score"] * len(st.score_ids(b, sd)) + ["calib"] * len(calib)
            S = np.zeros((M, len(pred_tasks)))
            N = np.zeros((M, len(pred_tasks)))
            for mi, m in enumerate(design.models):
                bd = st.bank_dir(m, b, sd)
                for fn in ("write.jsonl", "build0.jsonl"):
                    for r in _read_jsonl(bd / fn):
                        j = pos.get(str(r.get("task_id")))
                        c = r.get("correct")
                        if j is None or c is None:
                            continue
                        S[mi, j] += float(bool(c))
                        N[mi, j] += 1.0
                hc = cells.get((m, m, b, sd))
                none = None
                if hc is not None and hc.get("none") is not None:
                    none = hc["none"]
                if none is not None:
                    for t, row, ic in zip(hc["tasks"], none, hc["is_calib"]):
                        j = pos.get(str(t))
                        if j is None or not ic:
                            continue
                        ok = np.isfinite(row)
                        S[mi, j] += float(np.sum(row[ok]))
                        N[mi, j] += float(ok.sum())
            out[(b, sd)] = {"tasks": pred_tasks, "S": S, "N": N, "source": src[:len(pred_tasks)]}
    return out


def load_cells_with_none(st, design) -> dict:
    cells = load_cells(st, design)
    d = st.results_dir / "cells"
    for (o, r, b, sd), c in cells.items():
        if o == r:
            with np.load(d / f"{o}__{r}__{b}__seed{sd}.npz", allow_pickle=False) as z:
                c["none"] = z["none"].astype(float) if "none" in z.files else None
    return cells


def target_parts(cell: dict, keep: np.ndarray | None = None) -> dict:
    """Per evaluation task: a_home, a_swap (N's per-task parts) and the Cw numerators and weights
    at home and after the swap, plus validity. Uses msr.analysis.cw_parts (Part 2.2). `keep` is the
    evaluate stage's missing-cell rule (results/per_task/*.npz `valid`, Part 1.6) when it exists."""
    from msr.analysis import cw_parts
    ev = ~cell["is_calib"]
    pres = cell["items"][ev] != ""
    x = cell["x"][ev]
    ys, yh = _mean_rep(cell["y"][ev]), _mean_rep(cell["y_home"][ev])
    a_s, _, _ = task_stat(x, ys, pres)
    a_h, _, _ = task_stat(x, yh, pres)
    cs_n, cs_d = cw_parts(x, ys, pres)
    ch_n, ch_d = cw_parts(x, yh, pres)
    valid = np.isfinite(a_s) & np.isfinite(a_h)
    if keep is not None and len(keep) == len(valid):
        valid &= np.asarray(keep, bool)
    z = lambda v: np.where(valid, np.nan_to_num(v), 0.0)  # noqa: E731
    # the spreads of the retained agreement (decision D2): S = sum over candidate pairs of the unbiased
    # within-session estimate of delta^2 from the repeats (msr.theory S_oo2 for the owner's home
    # repeats 1-2 and S_nn2 for the reader's repeats, on the pairs where both have >= 2 repeats)
    from msr.theory import outcome_pairs, pair_index
    ia, ib = pair_index(x.shape[1])
    op = outcome_pairs(cell["y_home"][ev], cell["y"][ev], ia, ib, pres)
    return {"tasks": cell["tasks"][ev], "valid": valid.astype(float), "a_swap": z(a_s), "a_home": z(a_h),
            "cs_num": z(cs_n), "cs_den": z(cs_d), "ch_num": z(ch_n), "ch_den": z(ch_d),
            "s_owner": z(op["S_oo2"].sum(-1)), "s_reader": z(op["S_nn2"].sum(-1))}


# ===========================================================================
# Point estimates and bootstrap draws
# ===========================================================================


def _per_task_valid(st, o, r, b, sd):
    p = st.results_dir / "per_task" / f"{o}__{r}__{b}__seed{sd}.npz"
    if not p.exists():
        return None
    with np.load(p, allow_pickle=False) as z:
        return (np.nan_to_num(z["valid"].astype(float)) > 0) if "valid" in z.files else None


class Data:
    """Everything the forecast needs, as (draw, pair) matrices; draw 0 is the point estimate
    (weights 1), draws 1..B the task bootstrap."""

    def __init__(self, st, design, n_boot: int, seed: int):
        from msr.metrics import bootstrap_counts, stratum_seed
        self.st, self.design = st, design
        self.models = list(design.models)
        self.M = len(self.models)
        self.mi = {m: j for j, m in enumerate(self.models)}
        self.pairs = [(s, t) for (s, t) in design.pairs if s != t and s in self.mi and t in self.mi]
        self.streams = list(design.streams)
        cells = load_cells_with_none(st, design)
        self.cells = cells
        self.nomem = load_nomemory(st, design, cells)
        B = n_boot
        self.B = B
        P = len(self.pairs)
        # ---- predictors: sums per stream over its orders, (B+1, ...)
        pred = {}
        X = {}
        for b in self.streams:
            agree = np.zeros((B + 1, P))
            cmp_ = np.zeros((B + 1, P))
            sa = np.zeros((B + 1, P))
            sb = np.zeros((B + 1, P))
            succ = np.zeros((B + 1, self.M))
            runs = np.zeros((B + 1, self.M))
            for sd in design.seeds:
                nm = self.nomem.get((b, sd))
                if nm is None or not len(nm["tasks"]):
                    continue
                n = len(nm["tasks"])
                W = np.vstack([np.ones((1, n)), bootstrap_counts(n, B, [seed, _h("forecast-pred", b, sd)])
                               if B else np.zeros((0, n))])
                S, N = nm["S"], nm["N"]
                F = N - S
                succ += W @ S.T
                runs += W @ N.T
                for k, (s, t) in enumerate(self.pairs):
                    i, j = self.mi[s], self.mi[t]
                    agree[:, k] += W @ (S[i] * S[j] + F[i] * F[j])
                    cmp_[:, k] += W @ (N[i] * N[j])
                    sa[:, k] += W @ (S[i] * N[j])
                    sb[:, k] += W @ (S[j] * N[i])
            with np.errstate(invalid="ignore", divide="ignore"):
                ag = agree / cmp_
                pa, pb = sa / cmp_, sb / cmp_
                Xm = succ / runs
            pred[b] = {"ec": kappa(ag, pa, pb), "agree": ag, "cmp": cmp_[0]}
            X[b] = Xm
        Xall = np.nanmean(np.stack([X[b] for b in self.streams]), axis=0) if self.streams else np.zeros((B + 1, self.M))
        self.X = Xall
        oi = np.array([self.mi[s] for s, _ in self.pairs], int)
        ti = np.array([self.mi[t] for _, t in self.pairs], int)
        self.oi, self.ti = oi, ti
        same = np.array([float(design.family.get(s) == design.family.get(t)) for s, t in self.pairs])
        self.newer = newer_coding(self.models, getattr(design, "upgrades", ()) or ())
        with np.errstate(invalid="ignore"):
            self.pred = {
                "ec": np.nanmean(np.stack([pred[b]["ec"] for b in self.streams]), axis=0),
                "agree": np.nanmean(np.stack([pred[b]["agree"] for b in self.streams]), axis=0),
                "gap": Xall[:, ti] - Xall[:, oi],
                "abs_gap": np.abs(Xall[:, ti] - Xall[:, oi]),
                "x_owner": Xall[:, oi], "x_reader": Xall[:, ti],
                "same_maker": np.broadcast_to(same, (B + 1, P)).copy(),
                "owner_newer": np.broadcast_to(self.newer[oi], (B + 1, P)).copy(),
                "reader_newer": np.broadcast_to(self.newer[ti], (B + 1, P)).copy(),
            }
        self.pred_comparisons = sum(pred[b]["cmp"] for b in self.streams) if self.streams else np.zeros(P)
        # ---- targets
        tg = {b: {k: np.zeros((B + 1, P)) for k in ("ns", "nh", "nv", "csn", "csd", "chn", "chd", "so", "sn")}
              for b in self.streams}
        self.eval_tasks = {}
        for b in self.streams:
            for sd in design.seeds:
                parts = {}
                for k, (s, t) in enumerate(self.pairs):
                    c = cells.get((s, t, b, sd))
                    if c is not None:
                        parts[k] = target_parts(c, _per_task_valid(st, s, t, b, sd))
                if not parts:
                    continue
                n = len(next(iter(parts.values()))["tasks"])
                self.eval_tasks[(b, sd)] = n
                W = np.vstack([np.ones((1, n)), bootstrap_counts(n, B, stratum_seed(seed, b, sd))
                               if B else np.zeros((0, n))])
                for k, p in parts.items():
                    if len(p["tasks"]) != n:       # cells of one stratum share the evaluation tasks
                        raise ValueError(f"cell {self.pairs[k]} {b} seed {sd}: {len(p['tasks'])} tasks, expected {n}")
                    tg[b]["ns"][:, k] += W @ p["a_swap"]
                    tg[b]["nh"][:, k] += W @ p["a_home"]
                    tg[b]["nv"][:, k] += W @ p["valid"]
                    tg[b]["csn"][:, k] += W @ p["cs_num"]
                    tg[b]["csd"][:, k] += W @ p["cs_den"]
                    tg[b]["chn"][:, k] += W @ p["ch_num"]
                    tg[b]["chd"][:, k] += W @ p["ch_den"]
                    tg[b]["so"][:, k] += W @ p["s_owner"]
                    tg[b]["sn"][:, k] += W @ p["s_reader"]
        with np.errstate(invalid="ignore", divide="ignore"):
            Ns = np.nanmean(np.stack([tg[b]["ns"] / tg[b]["nv"] for b in self.streams]), axis=0)
            Nh = np.nanmean(np.stack([tg[b]["nh"] / tg[b]["nv"] for b in self.streams]), axis=0)
            Cs = np.nanmean(np.stack([tg[b]["csn"] / tg[b]["csd"] for b in self.streams]), axis=0)
            Ch = np.nanmean(np.stack([tg[b]["chn"] / tg[b]["chd"] for b in self.streams]), axis=0)
            T = Ns / Nh
            R = (Cs - 0.5) / (Ch - 0.5)
            # theta = V_swap / V_home (msr.metrics; V = 2 num - W of Cw per task, exact), the per-task
            # mean V pooled over the orders of a stream, equal weight per stream (Part 2.12)
            Vs = np.nanmean(np.stack([(2 * tg[b]["csn"] - tg[b]["csd"]) / tg[b]["nv"] for b in self.streams]), axis=0)
            Vh = np.nanmean(np.stack([(2 * tg[b]["chn"] - tg[b]["chd"]) / tg[b]["nv"] for b in self.streams]), axis=0)
            So = np.nanmean(np.stack([tg[b]["so"] / tg[b]["nv"] for b in self.streams]), axis=0)
            Sn = np.nanmean(np.stack([tg[b]["sn"] / tg[b]["nv"] for b in self.streams]), axis=0)
            theta = np.where(Vh != 0, Vs / Vh, np.nan)
        self.Ns, self.Nh, self.Cs, self.Ch = Ns, Nh, Cs, Ch
        self.Vs, self.Vh, self.S_owner, self.S_reader = Vs, Vh, So, Sn
        order = np.vectorize(retained_order_value, otypes=[float])(theta, So, Sn) if P else np.zeros((B + 1, 0))
        self.theta, self.order = theta, order
        self.target = {"T": T, "c_swap": Cs, "drop": Ch - Cs, "R": R}
        # ONE home-signal flag (msr.metrics, Part 2.4 as revised): the OWNER'S signal on its calibration
        # tasks; it replaced the same-task 4-SE rule on N_home and C_home (R6 W3)
        self.home_flag = {m: owner_home_flag(owner_calibration_values(cells, m, self.streams, design.seeds))
                          for m in self.models}
        flag = np.array([self.home_flag[s]["defined"] for s, _ in self.pairs], bool)
        self.reportable = {"T": flag & np.isfinite(T[0]), "R": flag & np.isfinite(R[0]),
                           "theta": flag & np.isfinite(theta[0]), "order": flag & np.isfinite(order[0]),
                           "c_swap": np.isfinite(Cs[0]), "drop": np.isfinite(Ch[0] - Cs[0])}
        self.se = {"Nh": np.nanstd(Nh[1:], axis=0, ddof=1) if B > 1 else np.full(P, NAN),
                   "Ch": np.nanstd(Ch[1:], axis=0, ddof=1) if B > 1 else np.full(P, NAN),
                   "S_reader": np.nanstd(Sn[1:], axis=0, ddof=1) if B > 1 else np.full(P, NAN)}

    # predictor grid for one draw, with optional model relabeling
    def grids(self, d: int = 0) -> tuple:
        EC = np.full((self.M, self.M), np.nan)
        for k, (s, t) in enumerate(self.pairs):
            EC[self.mi[s], self.mi[t]] = self.pred["ec"][d, k]
        return EC, self.X[d]


# ===========================================================================
# Leave-one-model-out
# ===========================================================================


def _ols_fit_predict(Xtr: np.ndarray, ytr: np.ndarray, Xte: np.ndarray) -> np.ndarray | None:
    """OLS with an intercept; None when the design is rank-deficient or has too few rows."""
    A = np.column_stack([np.ones(len(ytr)), Xtr]) if Xtr.size else np.ones((len(ytr), 1))
    if len(ytr) < A.shape[1] + 1 and A.shape[1] > 1:
        return None
    coef, _res, rank, _sv = np.linalg.lstsq(A, ytr, rcond=None)
    if rank < A.shape[1]:
        return None
    At = np.column_stack([np.ones(len(Xte)), Xte]) if Xte.size else np.ones((len(Xte), 1))
    return At @ coef


def lomo(D: Data, preds: tuple, y: np.ndarray, use: np.ndarray, d: int = 0) -> tuple:
    """Out-of-fold predictions: list of (held_out, pair index, prediction) and the number of folds
    in which the model could not be fitted (a predictor constant or too few training swaps)."""
    out, unfit = [], 0
    X = np.column_stack([D.pred[p][d] for p in preds]) if preds else np.zeros((len(D.pairs), 0))
    for m in D.models:
        j = D.mi[m]
        inv = (D.oi == j) | (D.ti == j)
        tr = use & ~inv & np.isfinite(y) & np.all(np.isfinite(X), axis=1)
        te = use & inv & np.isfinite(y)
        if not te.any():
            continue
        if tr.sum() < 1:
            unfit += 1
            continue
        pr = _ols_fit_predict(X[tr], y[tr], X[te]) if preds else np.full(te.sum(), y[tr].mean())
        if pr is None:
            unfit += 1
            continue
        for k, v in zip(np.flatnonzero(te), pr):
            out.append((m, int(k), float(v)))
    return out, unfit


def lbmo(D, preds: tuple, y: np.ndarray, use: np.ndarray, d: int = 0) -> tuple:
    """Leave BOTH models out: swaps (s, t) and (t, s) are predicted by a fit on the swaps that
    involve neither s nor t (leave-one-model-out still sees the other model of every predicted
    swap). Returns ([("s+t", pair index, prediction)], swaps not predicted)."""
    out, unfit = [], 0
    X = np.column_stack([D.pred[p][d] for p in preds]) if preds else np.zeros((len(D.pairs), 0))
    okx = np.all(np.isfinite(X), axis=1) & np.isfinite(y) & use
    te_all = use & np.isfinite(y)
    lo, hi = np.minimum(D.oi, D.ti), np.maximum(D.oi, D.ti)
    for i, j in sorted({(int(a), int(b)) for a, b in zip(lo[te_all], hi[te_all])}):
        te = te_all & (lo == i) & (hi == j)
        tr = okx & (D.oi != i) & (D.ti != i) & (D.oi != j) & (D.ti != j)
        pr = None
        if tr.sum() >= 1:
            pr = _ols_fit_predict(X[tr], y[tr], X[te]) if preds else np.full(te.sum(), y[tr].mean())
        if pr is None:
            unfit += int(te.sum())
            continue
        for k, v in zip(np.flatnonzero(te), pr):
            out.append((f"{D.models[i]}+{D.models[j]}", int(k), float(v)))
    return out, unfit


def _metrics(pred: list, y: np.ndarray, gm: dict) -> dict:
    """R^2 against the leave-one-model-out grand mean (same fold, same swap), Spearman, MAE."""
    if not pred:
        return {"r2_oof": NAN, "spearman_oof": NAN, "mae_oof": NAN, "n_predictions": 0}
    yy = np.array([y[k] for _, k, _ in pred])
    pp = np.array([v for _, _, v in pred])
    gg = np.array([gm.get((m, k), np.nan) for m, k, _ in pred])
    ok = np.isfinite(yy) & np.isfinite(pp) & np.isfinite(gg)
    if ok.sum() < 2:
        return {"r2_oof": NAN, "spearman_oof": NAN, "mae_oof": NAN, "n_predictions": int(ok.sum())}
    mse = np.mean((yy[ok] - pp[ok]) ** 2)
    mse0 = np.mean((yy[ok] - gg[ok]) ** 2)
    return {"r2_oof": float(1 - mse / mse0) if mse0 > 0 else NAN, "spearman_oof": spearman(pp[ok], yy[ok]),
            "mae_oof": float(np.mean(np.abs(yy[ok] - pp[ok]))), "n_predictions": int(ok.sum())}


def _metrics_direct(est: np.ndarray, y: np.ndarray, gm_pair: np.ndarray, use: np.ndarray) -> dict:
    ok = use & np.isfinite(est) & np.isfinite(y) & np.isfinite(gm_pair)
    if ok.sum() < 2:
        return {"r2_oof": NAN, "spearman_oof": NAN, "mae_oof": NAN, "n_predictions": int(ok.sum())}
    mse = np.mean((y[ok] - est[ok]) ** 2)
    mse0 = np.mean((y[ok] - gm_pair[ok]) ** 2)
    return {"r2_oof": float(1 - mse / mse0) if mse0 > 0 else NAN, "spearman_oof": spearman(est[ok], y[ok]),
            "mae_oof": float(np.mean(np.abs(y[ok] - est[ok]))), "n_predictions": int(ok.sum())}


# ===========================================================================
# The 20-check post-swap baseline (Goyal and Ray style)
# ===========================================================================


def subsample_estimates(D: Data, draws: int = SUBSAMPLE_DRAWS, n_tasks: int = SUBSAMPLE_TASKS, seed: int = 0) -> dict:
    """{target: (draws, pairs)} estimated from n_tasks calibration tasks per bank (all candidates,
    one stored repeat each), pooled like the target; the home values (N_home, C_home) are the
    evaluation-task values known before the swap."""
    from msr.analysis import cw_parts
    from msr.sequential import _fill_repeats
    P = len(D.pairs)
    est_N = {b: np.zeros((draws, P)) for b in D.streams}
    cnt_N = {b: np.zeros((draws, P)) for b in D.streams}
    csn = {b: np.zeros((draws, P)) for b in D.streams}
    csd = {b: np.zeros((draws, P)) for b in D.streams}
    for k, (s, t) in enumerate(D.pairs):
        for b in D.streams:
            for sd in D.design.seeds:
                c = D.cells.get((s, t, b, sd))
                if c is None:
                    continue
                cal = c["is_calib"]
                x, pres = c["x"][cal], c["items"][cal] != ""
                y = _fill_repeats(c["y"][cal])
                Tq, C, Rr = y.shape
                if Tq == 0:
                    continue
                rng = np.random.default_rng([seed, _h("subsample", s, t, b, sd)])
                nt = min(n_tasks, Tq)
                pick = np.argsort(rng.random((draws, Tq)), axis=1)[:, :nt]
                rep = rng.integers(0, Rr, size=(draws, nt, C))
                yy = np.take_along_axis(y[pick], rep[..., None], axis=3)[..., 0]
                a, _, _ = task_stat(x[pick], yy, pres[pick])
                est_N[b][:, k] += np.nansum(a, axis=1)
                cnt_N[b][:, k] += np.isfinite(a).sum(1)
                num, den = cw_parts(x[pick].reshape(-1, C), yy.reshape(-1, C), pres[pick].reshape(-1, C))
                csn[b][:, k] += num.reshape(draws, nt).sum(1)
                csd[b][:, k] += den.reshape(draws, nt).sum(1)
    with np.errstate(invalid="ignore", divide="ignore"):
        Ns = np.nanmean(np.stack([est_N[b] / cnt_N[b] for b in D.streams]), axis=0)
        Cs = np.nanmean(np.stack([np.where(csd[b] > 0, csn[b] / csd[b], 0.5) for b in D.streams]), axis=0)
        T = Ns / D.Nh[0][None, :]
        R = (Cs - 0.5) / (D.Ch[0][None, :] - 0.5)
    return {"T": T, "c_swap": Cs, "drop": D.Ch[0][None, :] - Cs, "R": R}


# ===========================================================================
# The test: incremental value of error consistency beyond maker and gap
# ===========================================================================


def makers_of(D) -> list:
    """Maker of every model (index order of D.models): D.makers, else design.family, else the
    classes of the same-maker flag (one maker per model when no pair is same-maker)."""
    if getattr(D, "makers", None) is not None:
        return list(D.makers)
    des = getattr(D, "design", None)
    if des is not None and getattr(des, "family", None):
        return [des.family.get(m, m) for m in D.models]
    lab = list(range(D.M))
    same = D.pred["same_maker"][0]
    for k in np.flatnonzero(same > 0.5):            # union of same-maker pairs
        a, b = lab[D.oi[k]], lab[D.ti[k]]
        if a != b:
            lab = [a if x == b else x for x in lab]
    return lab


def _blocks(makers) -> dict:
    """{maker size: [member index lists of the makers of that size]}, in a fixed order."""
    mem = {}
    for i, g in enumerate(makers):
        mem.setdefault(g, []).append(i)
    out = {}
    for g in sorted(mem, key=lambda g: (len(mem[g]), mem[g])):
        out.setdefault(len(mem[g]), []).append(mem[g])
    return out


def group_order(makers, kind: str = "maker") -> int:
    """Number of relabelings in the group. kind 'maker': models permuted within their maker and
    whole makers permuted among makers of the same size, so prod over sizes s of k_s! (s!)^k_s
    (k_s makers of size s; 4 makers x 2 models: 4! 2^4 = 384). kind 'all': n!."""
    if kind == "all":
        return math.factorial(len(makers))
    return math.prod(math.factorial(len(v)) * math.factorial(s) ** len(v) for s, v in _blocks(makers).items())


_GROUP_CACHE: dict = {}


def relabelings(makers, kind: str = "maker", cap: int = PERM_CAP, seed: int = 0) -> tuple:
    """(relabelings (G, n) with the identity first, exact). Row g maps model i to model g[i].
    Enumerated when the group has at most `cap` elements, else the identity plus cap - 1 draws."""
    makers = tuple(makers)
    n = len(makers)
    blocks = {n: [list(range(n))]} if kind == "all" else _blocks(makers)
    order = group_order(makers, kind)
    key = (makers, kind, cap, seed if order > cap else None)
    if key in _GROUP_CACHE:
        return _GROUP_CACHE[key]
    if order <= cap and kind == "all":
        out = np.array(list(itertools.permutations(range(n))), dtype=np.int16).reshape(-1, n)
        exact = True
    elif order <= cap:
        per_size = []
        for s, mems in blocks.items():
            opts = []
            for sigma in itertools.permutations(range(len(mems))):
                for taus in itertools.product(list(itertools.permutations(range(s))), repeat=len(mems)):
                    opts.append([(src[j], mems[sigma[a]][taus[a][j]])
                                 for a, src in enumerate(mems) for j in range(s)])
            per_size.append(opts)
        out = np.empty((order, n), np.int16)
        for r, combo in enumerate(itertools.product(*per_size)):
            for mapping in combo:
                for i, j in mapping:
                    out[r, i] = j
        exact = True
    else:
        rng = np.random.default_rng([seed, _h("relabel", kind, makers)])
        out = np.empty((cap, n), np.int16)
        out[0] = np.arange(n)
        for r in range(1, cap):
            for s, mems in blocks.items():
                sigma = rng.permutation(len(mems))
                for a, src in enumerate(mems):
                    dst = mems[sigma[a]]
                    tau = rng.permutation(s)
                    for j in range(s):
                        out[r, src[j]] = dst[tau[j]]
        exact = False
    assert np.array_equal(out[0], np.arange(n))
    _GROUP_CACHE[key] = (out, exact)
    return out, exact


def models_needed(makers, alpha: float = ALPHA, kind: str = "maker") -> int:
    """Fewest models for which the relabeling group can reach alpha (1/|G| <= alpha). kind 'all':
    the smallest n with 1/n! <= alpha (4 at 0.05). kind 'maker': this study's makers plus further
    makers of its most common size until the group is large enough (makers of 2 models: 3 makers,
    6 models, 3! 2^3 = 48; with 2 makers of 2 the group has 8 elements and the test cannot reach
    0.05). The rule in general: the group order prod_s k_s! (s!)^k_s must reach 1/alpha."""
    if kind == "all":
        return min_models_needed(alpha, 1)
    mk = list(makers)
    sizes = [len(v) for vs in _blocks(mk).values() for v in vs]
    s = max(set(sizes), key=lambda x: (sizes.count(x), -x)) if sizes else 1
    k = 0
    while 1.0 / group_order(mk, "maker") > alpha:
        mk = mk + [("added", k)] * s
        k += 1
    return len(mk)


def fixed_effect_columns(oi, ti, M: int) -> np.ndarray:
    """(pairs, 2 (M - 1)) owner and reader fixed effects: one indicator per model for "this model is
    the owner" and one for "this model is the reader" (model 0 is the reference; with an intercept
    the span is every per-owner value plus every per-reader value)."""
    oi, ti = np.asarray(oi, int), np.asarray(ti, int)
    j = np.arange(1, int(M))
    return np.column_stack([oi[:, None] == j[None, :], ti[:, None] == j[None, :]]).astype(float)


def controls(D, d: int = 0, names: tuple = F1_CONTROLS, fixed_effects: bool = False) -> np.ndarray:
    """The controls Q of F1 over the ordered swaps: an intercept and F1_CONTROLS (span: same maker,
    gap, abs gap, the capability level and the newer/older position of owner and reader). A
    position column that is constant (no upgrade pairs, every model its own maker) drops out of the
    test by itself (_basis).

    fixed_effects=True (R7 W11; a sensitivity, NOT the registered Q) adds owner and reader fixed
    effects (fixed_effect_columns). Their span holds x_owner, x_reader, the position and ANY other
    property of the owner or of the reader, so only abs_gap and the same-maker flag remain as
    pair-level columns; the columns they make redundant drop out by themselves (_basis). Level and
    power in the module docstring ("What F1 and P1 detect")."""
    cols = [np.ones(len(D.pairs))] + [D.pred[p][d] for p in names]
    if fixed_effects:
        fe = fixed_effect_columns(D.oi, D.ti, D.M)
        cols += [fe[:, j] for j in range(fe.shape[1])]
    return np.column_stack(cols)


def _basis(Q: np.ndarray) -> np.ndarray:
    """Orthonormal basis (n, rank) of the column space of Q (rank-deficient columns, e.g. a constant
    same-maker flag, drop out by themselves)."""
    if Q.shape[0] == 0:
        return np.zeros((0, 0))
    U, s, _ = np.linalg.svd(Q, full_matrices=False)
    k = int(np.sum(s > s[0] * 1e-10)) if s.size and s[0] > 0 else 0
    return U[:, :k]


def _annihilator(Q: np.ndarray) -> tuple:
    """(I - H, rank of Q): residual maker of the column space of Q."""
    U = _basis(Q)
    return np.eye(Q.shape[0]) - U @ U.T, U.shape[1]


_IDX_CACHE: dict = {}


def _flat_index(perms: np.ndarray, oi: np.ndarray, ti: np.ndarray, M: int) -> np.ndarray:
    """Flat index into an M x M array of every relabelled pair, (G, pairs); cached per group."""
    key = (id(perms), perms.shape, M, oi.tobytes(), ti.tobytes())
    hit = _IDX_CACHE.get(key)
    if hit is not None and hit[0] is perms:
        return hit[1]
    idx = perms[:, oi].astype(np.intp) * M + perms[:, ti]
    if len(_IDX_CACHE) > 16:
        _IDX_CACHE.clear()
    _IDX_CACHE[key] = (perms, idx)
    return idx


def incremental_test(ec, y, Q, oi, ti, M: int, use, perms: np.ndarray, exact: bool = True) -> dict:
    """Double semi-partialling (Dekker, Krackhardt and Snijders 2007) of the partial correlation of
    y and ec given Q, one-sided (> 0). ec is residualised on Q over every ordered pair where both
    exist; the models of that RESIDUAL array are relabelled by each row of `perms` (identity
    first); the relabelled residual is residualised on Q again over the swaps in `use` and
    correlated with y residualised on Q. p = share of relabelings with a statistic >= the observed
    (identity included); min_p = (relabelings that leave the residual array on the used swaps
    unchanged) / (relabelings) when the group is enumerated, 1 / (relabelings) otherwise."""
    ec, y, Q = np.asarray(ec, float), np.asarray(y, float), np.asarray(Q, float)
    oi, ti = np.asarray(oi), np.asarray(ti)
    avail = np.isfinite(ec) & np.all(np.isfinite(Q), axis=1)
    u = np.asarray(use, bool) & avail & np.isfinite(y)
    nu = int(u.sum())
    out = {"value": NAN, "t": NAN, "df": 0, "p": NAN, "min_p": NAN, "n_swaps": nu, "n_relabelings": len(perms),
           "stats": None}
    if nu < 3 or avail.sum() < 3:
        return out
    Ua = _basis(Q[avail])
    ea = ec[avail]
    res = np.full(M * M, np.nan)
    res[oi[avail] * M + ti[avail]] = ea - Ua @ (Ua.T @ ea)
    Uu = _basis(Q[u])
    df = nu - Uu.shape[1] - 1
    yu = y[u]
    ty = yu - Uu @ (Uu.T @ yu)
    V0 = res[_flat_index(perms, oi[u], ti[u], M)]               # (G, used swaps)
    bad = ~np.all(np.isfinite(V0), axis=1)
    V = np.where(np.isfinite(V0), V0, 0.0) if bad.any() else V0
    # residualising V on Q again: |V (I - UU')|^2 = |V|^2 - |VU|^2 and V (I - UU') ty = V ty
    PU = V @ Uu
    vv = np.einsum("ij,ij->i", V, V) - np.einsum("ij,ij->i", PU, PU)
    yy = float(ty @ ty)
    tol = 1e-12 * max(1e-300, float(np.max(np.einsum("ij,ij->i", V, V))))
    with np.errstate(invalid="ignore", divide="ignore"):
        stats = np.where((vv > tol) & (yy > 1e-20), (V @ ty) / np.sqrt(np.maximum(vv, 0) * yy), np.nan)
    stats[bad] = np.nan
    obs = float(stats[0])
    fin = np.isfinite(stats)
    out.update(df=df, stats=stats)
    if not np.isfinite(obs) or df < 1:
        return out
    if exact:
        eq = np.all(np.abs(V0 - V0[0][None, :]) <= 1e-12 + 1e-9 * np.abs(V0[0])[None, :], axis=1) & fin
    else:
        eq = np.zeros(len(perms), bool)
    out.update(value=obs, t=obs * math.sqrt(df / max(1e-300, 1 - obs ** 2)),
               p=float(np.mean(stats[fin] >= obs - 1e-12)),
               min_p=float(max(1, int(eq.sum())) / fin.sum()))
    return out


def pair_controls(owners, readers, capability, newer=None) -> dict:
    """F1's control columns for any set of ordered pairs from per-model values: x_owner, x_reader,
    abs_gap from `capability` (one value per model, e.g. no-memory success), and owner_newer,
    reader_newer from `newer` (newer_coding) when given. owners, readers: integer model indices.
    With the intercept and the same-maker flag that pair_incremental_test adds, the span is F1's Q."""
    o, r = np.asarray(owners, int), np.asarray(readers, int)
    X = np.asarray(capability, float)
    out = {"x_owner": X[o], "x_reader": X[r], "abs_gap": np.abs(X[r] - X[o])}
    if newer is not None:
        nw = np.asarray(newer, float)
        out.update({"owner_newer": nw[o], "reader_newer": nw[r]})
    return out


def pair_incremental_test(x, y, owners, readers, makers, controls=None, one_sided: str = "greater",
                          group: str | None = None, alpha: float = ALPHA, models=None, seed: int = 0,
                          fixed_effects: bool = False) -> dict:
    """F1's test for ANY pair-level predictor x and target y over ordered (owner, reader) pairs:
    does x predict y beyond the controls? Exactly F1's machinery (incremental_test): the partial
    correlation of y and x given Q = [1, same-maker flag, controls] (= the t of x in OLS y ~ Q + x),
    its null by double semi-partialling (Dekker, Krackhardt and Snijders 2007) with the relabelings
    that keep every pair's same-maker flag (models within makers, whole makers among makers of one
    size; PRIMARY_GROUP), p = share of relabelings at least as extreme (identity included), the
    smallest attainable p, and "not testable" when that is above alpha. Written so that P1
    ("agreement predicts theta", msr.analysis) can use the same test as F1 (audit N3).

    x, y      (P,) values per ordered pair, NaN where missing. Pass EVERY ordered pair on which x
              (and the controls) exist, with y NaN where the target is not reported: the residual x
              array that is relabelled lives on all of them, the statistic on the pairs with y.
    owners, readers  (P,) model names (with `makers` a dict, or `models` given) or integer indices.
    makers    the maker of every model: a dict {model: maker}, or a sequence aligned with `models`
              (or with the indices 0..M-1).
    controls  None (the same-maker flag only) or further columns: a dict {name: (P,)} or a (P, k)
              array (e.g. pair_controls(...) for F1's x_owner, x_reader, abs_gap, owner_newer,
              reader_newer). The intercept and the same-maker flag are always added; duplicate or
              constant columns drop out by themselves.
    one_sided "greater" (H1: > 0) or "less" (H1: < 0).
    fixed_effects  True adds owner and reader fixed effects to Q (fixed_effect_columns; R7 W11, a
              sensitivity, not the registered test): then a property of the owner or of the reader
              that raises both x and y no longer counts as "x predicts y" (module docstring, "What F1
              and P1 detect").
    Returns value (partial correlation), t, df, p_one_sided, p_opposite, min_attainable_p,
    testable, result ('pass' / 'fail' / 'not testable ...' / 'not computable ...'), n_swaps,
    n_models, n_makers, group_order, n_relabelings, exact, models_needed_to_be_testable, controls."""
    if one_sided not in ("greater", "less"):
        raise ValueError(f"one_sided must be 'greater' or 'less', not {one_sided!r}")
    group = group or PRIMARY_GROUP
    x, y = np.asarray(x, float).ravel(), np.asarray(y, float).ravel()
    owners, readers = list(owners), list(readers)
    if not (len(x) == len(y) == len(owners) == len(readers)):
        raise ValueError("x, y, owners and readers must have one entry per ordered pair")
    if isinstance(makers, dict):
        models = list(models) if models is not None else list(makers)
        mk = [makers[m] for m in models]
    else:
        mk = list(makers)
        if models is not None:
            models = list(models)
    if models is not None and not all(isinstance(v, (int, np.integer)) for v in owners + readers):
        pos = {m: j for j, m in enumerate(models)}
        oi = np.array([pos[m] for m in owners], int)
        ti = np.array([pos[m] for m in readers], int)
    else:
        oi, ti = np.asarray(owners, int), np.asarray(readers, int)
    M = len(mk)
    if np.any(oi == ti):
        raise ValueError("owner and reader must differ in every pair")
    same = np.array([float(mk[i] == mk[j]) for i, j in zip(oi, ti)])
    cols, names = [np.ones(len(x)), same], ["same_maker"]
    if controls is not None:
        if isinstance(controls, dict):
            for k, v in controls.items():
                cols.append(np.asarray(v, float).ravel())
                names.append(str(k))
        else:
            C = np.asarray(controls, float)
            C = C[:, None] if C.ndim == 1 else C
            cols += [C[:, j] for j in range(C.shape[1])]
            names += [f"control_{j + 1}" for j in range(C.shape[1])]
    if fixed_effects:
        fe = fixed_effect_columns(oi, ti, M)
        cols += [fe[:, j] for j in range(fe.shape[1])]
        names.append("owner and reader fixed effects")
    Q = np.column_stack(cols)
    order = group_order(mk, group)
    need = models_needed(mk, alpha, group)
    perms, exact = relabelings(mk, group, seed=seed)
    use = np.isfinite(y)
    sgn = 1.0 if one_sided == "greater" else -1.0
    res = incremental_test(sgn * x, y, Q, oi, ti, M, use, perms, exact) if M >= 3 else {
        "value": NAN, "t": NAN, "df": 0, "p": NAN, "min_p": NAN, "n_swaps": int(use.sum()), "stats": None}
    stats = res.get("stats")
    p_opp = NAN
    if stats is not None and np.isfinite(res["value"]):
        fin = np.isfinite(stats)
        p_opp = float(np.mean(stats[fin] <= res["value"] + 1e-12))
    # the design decides first: a group too small for alpha reports its floor 1/order (what any data
    # could reach); otherwise the data-based floor (relabelings that leave the residual unchanged)
    min_p = 1.0 / order if (1.0 / order > alpha or not np.isfinite(res["min_p"])) else res["min_p"]
    out = {"value": sgn * res["value"], "t": sgn * res["t"], "df": res["df"], "direction": "> 0" if sgn > 0 else "< 0",
           "p_one_sided": NAN, "p_opposite": p_opp, "min_attainable_p": min_p, "testable": False,
           "n_swaps": res["n_swaps"], "n_models": M, "n_makers": len(set(mk)), "group_order": order,
           "n_relabelings": len(perms), "exact": exact, "models_needed_to_be_testable": need,
           "relabeling_group": GROUP_TEXT[group], "controls": "1 + " + " + ".join(names),
           "null": "double semi-partialling (Dekker et al. 2007)"}
    n_mk = out["n_makers"]
    if min_p > alpha:
        out["result"] = (f"not testable with {M} models from {n_mk} makers: the {order} relabelings "
                         f"({GROUP_TEXT[group]}) give a smallest attainable p of {min_p:.4f}, above "
                         f"alpha = {alpha:g}; needs at least {need} models")
    elif M < 3 or res["n_swaps"] < 3 or not np.isfinite(res["value"]):
        out["result"] = (f"not computable here (needs at least 3 models and more pairs with a target than "
                         f"controls + 1, with the predictor not fixed by the controls; {res['n_swaps']} pairs)")
    else:
        out.update(p_one_sided=res["p"], testable=True,
                   result="pass" if (res["p"] <= alpha and res["value"] > 0) else "fail")
    return out


def plain_qap(ec, y, oi, ti, M: int, use, perms: np.ndarray, exact: bool = True) -> dict:
    """The superseded test, kept only to document why it was replaced: Spearman(ec, y) with the
    models of the whole ec array relabelled (a Mantel / QAP test of the sharp null that the two
    arrays are unrelated). When both arrays carry the maker structure it rejects although ec adds
    nothing beyond the same-maker flag (about 45 % of worlds at p <= 0.025 in null_world_w1)."""
    ec, y = np.asarray(ec, float), np.asarray(y, float)
    oi, ti = np.asarray(oi), np.asarray(ti)
    u = np.asarray(use, bool) & np.isfinite(y) & np.isfinite(ec)
    E = np.full((M, M), np.nan)
    E[oi, ti] = ec
    if u.all() and len(u) == M * (M - 1):       # every ordered pair: relabelled ranks = ranks relabelled
        Rg = np.full((M, M), np.nan)
        Rg[oi, ti] = _rank(ec)
        r = Rg[perms[:, oi], perms[:, ti]]
        ry = _rank(y) - (len(y) + 1) / 2.0
        rc = r - r.mean(1, keepdims=True)
        with np.errstate(invalid="ignore", divide="ignore"):
            stats = (rc @ ry) / np.sqrt(np.einsum("ij,ij->i", rc, rc) * (ry @ ry))
    else:
        r = _rank(E[perms[:, oi[u]], perms[:, ti[u]]])
        stats = spearman_rows(r, y[u])
    obs = float(stats[0])
    if not np.isfinite(obs):
        return {"value": NAN, "p": NAN, "min_p": NAN}
    same = np.all(r == r[0], axis=1) if exact else np.zeros(len(perms), bool)
    return {"value": obs, "p": float(np.mean(stats >= obs - 1e-12)), "min_p": float(max(1, same.sum()) / len(perms))}


GROUP_TEXT = {"maker": "models relabelled within makers and whole makers relabelled among makers of the same size",
              "all": "every relabeling of the models"}


def permutation_tests(D, alpha: float = ALPHA, seed: int = 0) -> list:
    """The forecast's one confirmatory-secondary test (F1) and the plain association (F0, no p).

    F1, incremental value: does error consistency (ec) predict the retained share T beyond the
    same-maker flag, capability and the newer/older position? Statistic: the partial correlation of
    T and ec given Q = [1, same_maker, x_owner, x_reader, abs_gap, owner_newer, reader_newer] (span:
    same maker, gap, abs gap, the capability level and whether the owner and the reader are the
    newer model of their maker; F1_CONTROLS) over the swaps whose owner passes the home-signal flag
    (msr.metrics, the owner's calibration tasks; owner_home_flag), equivalently the t of ec in OLS
    T ~ Q + ec; one-sided H1: > 0, alpha = 0.05, a single test (no Holm). Null distribution by
    double semi-partialling (Dekker, Krackhardt and Snijders 2007): ec is residualised on Q, the
    models of the RESIDUAL ec array are relabelled, the statistic is recomputed with T still
    controlled for Q (incremental_test; pair_incremental_test is the same test for any pair-level
    predictor and target). Relabeling group (PRIMARY_GROUP, chosen by simulation, see the module
    docstring, `null_world_*`, `alt_world` and tests/test_forecast.py): models within makers and
    whole makers among makers of the same size (4 makers x 2 models: 2^4 4! = 384 relabelings,
    enumerated), which keeps the same-maker flag of every pair. Two sensitivity columns, never the
    decision: the p-value over all n! relabelings, and the p-value with the controls used before
    the position was added (F1_CONTROLS_WITHOUT_POSITION). p = share of relabelings with a statistic
    >= the observed (identity included). Testable only when the smallest attainable p
    (relabelings that leave the residual array unchanged / group order, at least 1/order) is
    <= alpha: with 4 models from 2 makers the group has 2^2 2! = 8 elements (p >= 0.125), so the
    test is "not testable".

    The plain association Spearman(ec, T) is reported as F0_descriptive WITHOUT a p-value: its
    label permutation test (QAP) tests "the arrays are unrelated", which fails as soon as both
    carry the maker structure, so it cannot show that ec adds anything (plain_qap)."""
    y = D.target[PRIMARY_TARGET][0]
    use = D.reportable[PRIMARY_TARGET] & np.isfinite(y)
    M = D.M
    makers = makers_of(D)
    n_makers = len(set(makers))
    ec = D.pred["ec"][0]
    Q = controls(D)
    n_use = int((use & np.isfinite(ec)).sum())
    rows = []
    # F0: plain association, descriptive only
    rows.append({"test": "F0_descriptive", "role": "descriptive",
                 "statistic": "Spearman(error consistency, T) over the swaps with T reportable (plain "
                              "association; it carries the same-maker structure that both arrays share)",
                 "value": spearman(ec[use], y[use]), "direction": "", "n_models": M, "n_makers": n_makers,
                 "n_swaps": n_use, "p_one_sided": NAN, "min_attainable_p": NAN, "testable": False,
                 "models_needed_to_be_testable": "", "result": "descriptive only"})
    # F1: incremental value
    order = group_order(makers, PRIMARY_GROUP)
    need = models_needed(makers, alpha, PRIMARY_GROUP)
    perms, exact = relabelings(makers, PRIMARY_GROUP, seed=seed)
    res = incremental_test(ec, y, Q, D.oi, D.ti, M, use, perms, exact) if M >= 3 else {
        "value": NAN, "t": NAN, "df": 0, "p": NAN, "min_p": NAN, "n_swaps": n_use}
    other = "all" if PRIMARY_GROUP == "maker" else "maker"
    p_other = NAN
    # the design decides first: a group too small for alpha reports its floor 1/order (what any data
    # could reach); otherwise the data-based floor (relabelings that leave the residual unchanged)
    min_p = 1.0 / order if (1.0 / order > alpha or not np.isfinite(res["min_p"])) else res["min_p"]
    if M >= 3 and np.isfinite(res["value"]) and min_p <= alpha and group_order(makers, other) >= 1.0 / alpha:
        po, ex_o = relabelings(makers, other, seed=seed)       # sensitivity only, never the decision
        p_other = incremental_test(ec, y, Q, D.oi, D.ti, M, use, po, ex_o)["p"]
    p_nopos = NAN
    if M >= 3 and np.isfinite(res["value"]) and min_p <= alpha:   # sensitivity: Q before the position was added
        p_nopos = incremental_test(ec, y, controls(D, names=F1_CONTROLS_WITHOUT_POSITION), D.oi, D.ti, M, use,
                                   perms, exact)["p"]
    row = {"test": "F1", "role": "confirmatory-secondary (single test, no Holm)",
           "statistic": "partial correlation of T and error consistency given same maker, gap, abs gap, "
                        "capability level and the newer/older position of owner and reader (incremental value "
                        "of ec), over the swaps whose owner passes the home-signal flag",
           "value": res["value"], "t_value": res["t"], "df": res["df"], "direction": "> 0",
           "controls": "1 + " + " + ".join(F1_CONTROLS), "null": "double semi-partialling (Dekker et al. 2007)",
           "swaps_used": "owner passes the home-signal flag (msr.metrics, calibration tasks, z >= 2)",
           "relabeling_group": GROUP_TEXT[PRIMARY_GROUP], "group_order": order,
           "n_models": M, "n_makers": n_makers, "n_swaps": res["n_swaps"], "n_permutations": len(perms),
           "exact": exact, "alpha": alpha, "first_holm_threshold": alpha / N_TESTS,
           "min_attainable_p": min_p,
           "models_needed_to_be_testable": need, f"p_one_sided_{other}_relabelings": p_other,
           "p_one_sided_without_position": p_nopos}
    pmin = row["min_attainable_p"]
    if pmin > alpha:
        row.update({"p_one_sided": NAN, "testable": False,
                    "result": f"not testable with {M} models from {n_makers} makers: the {order} relabelings "
                              f"({GROUP_TEXT[PRIMARY_GROUP]}) give a smallest attainable p of {pmin:.4f}, above "
                              f"alpha = {alpha:g}; needs at least {need} models"})
    elif M < 3 or res["n_swaps"] < 3 or not np.isfinite(res["value"]):
        row.update({"p_one_sided": NAN, "testable": False,
                    "result": f"not computable here (needs at least 3 models and more swaps with a reportable T "
                              f"than controls + 1, with error consistency not fixed by the controls; "
                              f"{res['n_swaps']} swaps)"})
    else:
        row.update({"p_one_sided": res["p"], "testable": True,
                    "result": "pass" if (res["p"] <= alpha and res["value"] > 0) else "fail"})
    rows.append(row)
    return rows


# ===========================================================================
# Simulated worlds for the level and the power of F1 (no study data; fixed seeds by the caller)
# ===========================================================================


class ArrayData:
    """The attributes of Data that the models and the test read, built from plain arrays:
    an M x M error-consistency grid (symmetric), capability X per model, T per ordered pair
    (s != t, row-major), the maker of every model and its newer/older coding (newer_coding; by
    default the second model of a maker of two is the newer one)."""

    def __init__(self, M, ec_grid, X, T, makers=None, B: int = 0, newer=None):
        self.models = [f"m{j}" for j in range(M)]
        self.M = M
        self.mi = {m: j for j, m in enumerate(self.models)}
        self.pairs = [(s, t) for s in self.models for t in self.models if s != t]
        self.oi = np.array([self.mi[s] for s, _ in self.pairs])
        self.ti = np.array([self.mi[t] for _, t in self.pairs])
        self.makers = list(makers) if makers is not None else list(range(M))
        self.newer = (np.asarray(newer, float) if newer is not None
                      else newer_coding(self.models, (), self.makers))
        same = np.array([float(self.makers[i] == self.makers[j]) for i, j in zip(self.oi, self.ti)])
        ec = np.asarray(ec_grid, float)[self.oi, self.ti]
        self.X = np.asarray(X, float)[None, :]
        x = self.X[0]
        self.pred = {"ec": ec[None, :], "agree": ec[None, :], "gap": (x[self.ti] - x[self.oi])[None, :],
                     "abs_gap": np.abs(x[self.ti] - x[self.oi])[None, :],
                     "x_owner": x[self.oi][None, :], "x_reader": x[self.ti][None, :], "same_maker": same[None, :],
                     "owner_newer": self.newer[self.oi][None, :], "reader_newer": self.newer[self.ti][None, :]}
        self.target = {"T": np.asarray(T, float)[None, :]}
        self.reportable = {"T": np.isfinite(self.target["T"][0])}
        self.B = B

    def grids(self, d: int = 0) -> tuple:
        G = np.full((self.M, self.M), np.nan)
        G[self.oi, self.ti] = self.pred["ec"][d]
        return G, self.X[d]


MAKERS_8 = (0, 0, 1, 1, 2, 2, 3, 3)


def _pair_index(M: int) -> tuple:
    oi = np.array([s for s in range(M) for t in range(M) if s != t])
    ti = np.array([t for s in range(M) for t in range(M) if s != t])
    return oi, ti


def _sym(rng, M: int, sd: float) -> np.ndarray:
    """Symmetric pair noise with sd `sd` off the diagonal."""
    A = np.triu(rng.normal(0.0, sd, (M, M)), 1)
    return A + A.T


def _same_grid(makers) -> np.ndarray:
    m = np.asarray(makers)
    return (m[:, None] == m[None, :]).astype(float)


def null_world_w1(rng, makers=MAKERS_8) -> ArrayData:
    """W1, the reviewer's world: ec and T both carry the maker structure, ec adds nothing beyond
    the same-maker flag. ec = 0.10 + 0.08 same + (A + A')/2, A ~ N(0, 0.05); T = 0.30 + 0.45 same
    + N(0, 0.2) per ordered pair. Capability X ~ U(0.3, 0.8) is unrelated to both."""
    M = len(makers)
    S = _same_grid(makers)
    A = rng.normal(0.0, 0.05, (M, M))
    E = 0.10 + 0.08 * S + (A + A.T) / 2
    X = rng.uniform(0.3, 0.8, M)
    oi, ti = _pair_index(M)
    T = 0.30 + 0.45 * S[oi, ti] + rng.normal(0.0, 0.2, len(oi))
    return ArrayData(M, E, X, T, makers)


def null_world_w2(rng, makers=MAKERS_8) -> ArrayData:
    """W2, capability: Z ~ U(0.3, 0.8); ec = 0.10 + 0.08 same - 0.2 |Z_s - Z_t| + u_s + u_t
    (u sd 0.02) + symmetric pair noise 0.05; T = 0.30 + 0.45 same + 0.5 (Z_t - Z_s)
    - 0.3 |Z_t - Z_s| + owner effect (sd 0.1) + reader effect (sd 0.1) + pair noise 0.2; X = Z."""
    M = len(makers)
    S = _same_grid(makers)
    Z = rng.uniform(0.3, 0.8, M)
    G = Z[None, :] - Z[:, None]                     # G[s, t] = Z_t - Z_s
    u = rng.normal(0.0, 0.02, M)
    E = 0.10 + 0.08 * S - 0.2 * np.abs(G) + u[:, None] + u[None, :] + _sym(rng, M, 0.05)
    oi, ti = _pair_index(M)
    a, b = rng.normal(0.0, 0.1, M), rng.normal(0.0, 0.1, M)
    T = (0.30 + 0.45 * S[oi, ti] + 0.5 * G[oi, ti] - 0.3 * np.abs(G[oi, ti]) + a[oi] + b[ti]
         + rng.normal(0.0, 0.2, len(oi)))
    return ArrayData(M, E, Z, T, makers)


def null_world_w3(rng, makers=MAKERS_8) -> ArrayData:
    """W3, maker-pair heterogeneity in ec only: W1 plus a symmetric effect (sd 0.04) per pair of
    different makers, added to ec of every cross-maker swap between them; T as in W1."""
    D = null_world_w1(rng, makers)
    M = len(makers)
    mk = sorted(set(makers))
    c = _sym(rng, len(mk), 0.04)
    idx = np.array([mk.index(g) for g in makers])
    E, X = D.grids(0)
    E = E + c[idx[:, None], idx[None, :]]
    return ArrayData(M, E, X, D.target["T"][0], makers)


def null_world_w4(rng, makers=MAKERS_8) -> ArrayData:
    """W4, model effects in both arrays, independent between them: W1 plus u_s + u_t in ec
    (u sd 0.03) and an owner and a reader effect in T (sd 0.1 each)."""
    D = null_world_w1(rng, makers)
    M = len(makers)
    u = rng.normal(0.0, 0.03, M)
    E, X = D.grids(0)
    E = E + u[:, None] + u[None, :]
    a, b = rng.normal(0.0, 0.1, M), rng.normal(0.0, 0.1, M)
    T = D.target["T"][0] + a[D.oi] + b[D.ti]
    return ArrayData(M, E, X, T, makers)


def null_world_w6(rng, makers=MAKERS_8) -> ArrayData:
    """W6, maker-pair effects in BOTH arrays, independent between them: W3's symmetric effect per
    pair of makers in ec (sd 0.04) plus an independent effect per ordered pair of makers in T
    (sd 0.1) on the cross-maker swaps. The null holds; relabelings that scatter the makers
    (all n!) no longer reproduce the block structure the two arrays share by design."""
    D = null_world_w3(rng, makers)
    mk = sorted(set(makers))
    idx = np.array([mk.index(g) for g in makers])
    c = rng.normal(0.0, 0.1, (len(mk), len(mk)))
    np.fill_diagonal(c, 0.0)
    T = D.target["T"][0] + c[idx[D.oi], idx[D.ti]]
    E, X = D.grids(0)
    return ArrayData(len(makers), E, X, T, makers)


def null_world_w7(rng, makers=MAKERS_8, kind: str = "owner") -> ArrayData:
    """W7, the newer/older position inside a maker (R6 W10 and claim 32; the reviewer's script
    paper/reviews/round2/r6_checks/c7_forecast.py, world R2, reproduced draw for draw with 8 models).
    Base (the reviewer's): X ~ U(0.3, 0.8); ec = 0.10 + 0.08 same + u_s + u_t (sd 0.03) + symmetric
    pair noise (sd 0.04); theta = 0.3 + 0.4 same + 0.3 (X_t - X_s) + owner and reader effects (sd 0.08)
    + N(0, 0.12) per ordered pair; 'newer' = the newer model of its maker (newer_coding > 0).
    kind 'owner' (the reviewer's R2): theta + 0.15 when the OWNER is newer, ec without the position;
    'both': the same, and newer models also agree more with everyone (ec + 0.03 per newer model of
    the pair), so BOTH arrays carry the position (the confounding the reviewer warns about: a
    rejection that is the upgrade/downgrade asymmetry, not error consistency);
    'both_reader': as 'both' with the effect on the READER's position in theta."""
    M = len(makers)
    mk = np.asarray(makers)
    S = (mk[:, None] == mk[None, :]).astype(float)
    newer = (newer_coding([f"m{j}" for j in range(M)], (), list(makers)) > 0).astype(float)
    X = rng.uniform(0.3, 0.8, M)
    u = rng.normal(0, 0.03, M)
    A = np.triu(rng.normal(0, 0.04, (M, M)), 1)
    ec = 0.10 + 0.08 * S + u[:, None] + u[None, :] + A + A.T
    oi, ti = _pair_index(M)
    th = (0.3 + 0.4 * S[oi, ti] + 0.3 * (X[ti] - X[oi]) + rng.normal(0, 0.08, M)[oi]
          + rng.normal(0, 0.08, M)[ti])
    if kind == "owner":
        th = th + 0.15 * newer[oi] + rng.normal(0, 0.12, len(oi))
    elif kind == "both":
        ec = ec + 0.03 * (newer[:, None] + newer[None, :])
        th = th + 0.15 * newer[oi] + rng.normal(0, 0.12, len(oi))
    elif kind == "both_reader":
        ec = ec + 0.03 * (newer[:, None] + newer[None, :])
        th = th + 0.15 * newer[ti] + rng.normal(0, 0.12, len(oi))
    else:
        raise ValueError(kind)
    return ArrayData(M, ec, X, th, makers)


def null_world_w5(rng, makers=MAKERS_8, kind: str = "max") -> ArrayData:
    """W5, Q misspecified (a robustness probe, no incremental value of ec):
    'max': T depends on max(Z_s, Z_t) (not linear in gap and abs gap), ec on abs gap as in W2;
    'square': T depends on gap^2 and ec on exp(-abs gap / 0.1) (both curved in the gap);
    'level': T and ec both rise with the capability level (Z_s + Z_t) / 2, which Q leaves out.
    Owner/reader effects and noise as in W2."""
    M = len(makers)
    S = _same_grid(makers)
    Z = rng.uniform(0.3, 0.8, M)
    G = Z[None, :] - Z[:, None]
    L = (Z[None, :] + Z[:, None]) / 2
    u = rng.normal(0.0, 0.02, M)
    base_e = 0.10 + 0.08 * S + u[:, None] + u[None, :] + _sym(rng, M, 0.05)
    oi, ti = _pair_index(M)
    a, b = rng.normal(0.0, 0.1, M), rng.normal(0.0, 0.1, M)
    base_t = 0.30 + 0.45 * S[oi, ti] + a[oi] + b[ti] + rng.normal(0.0, 0.2, len(oi))
    g = G[oi, ti]
    if kind == "max":
        E = base_e - 0.2 * np.abs(G)
        T = base_t + 0.8 * np.maximum(Z[oi], Z[ti]) + 0.5 * g
    elif kind == "square":
        E = base_e + 0.2 * np.exp(-np.abs(G) / 0.1)
        T = base_t + 3.0 * g ** 2 + 0.5 * g
    elif kind == "level":
        E = base_e - 0.2 * np.abs(G) + 0.3 * L
        T = base_t + 0.8 * L[oi, ti] + 0.5 * g - 0.3 * np.abs(g)
    else:
        raise ValueError(kind)
    return ArrayData(M, E, Z, T, makers)


def alt_world(rng, rho: float, makers=MAKERS_8, model_share: float = 0.0, n_tasks: int = 2250,
              lam: float = 1.0, dim: int = 3, maker_share: float = 0.5) -> ArrayData:
    """A world where ec DOES add to the maker flag (power). Each model has a hidden direction
    z_m (unit vector in R^dim) that shares `maker_share` of its variance with its maker's
    direction. No-memory 0/1 outcomes on n_tasks tasks: logit = difficulty + skill_m
    + lam <w_tau, z_m>; ec is Cohen's kappa measured from these arrays. T = 0.30 + 0.45 same
    + 0.2 [rho h + sqrt(1 - rho^2) noise], h the hidden similarity <z_s, z_t> residualised on the
    same-maker flag and standardised; `model_share` of the noise variance is owner and reader
    effects, the rest independent per ordered pair."""
    M = len(makers)
    mk = sorted(set(makers))
    idx = np.array([mk.index(g) for g in makers])
    c = rng.standard_normal((len(mk), dim))
    c /= np.linalg.norm(c, axis=1, keepdims=True)
    e = rng.standard_normal((M, dim))
    e /= np.linalg.norm(e, axis=1, keepdims=True)
    z = math.sqrt(maker_share) * c[idx] + math.sqrt(1 - maker_share) * e
    z /= np.linalg.norm(z, axis=1, keepdims=True)
    skill = rng.normal(0.0, 0.3, M)
    d = rng.standard_normal(n_tasks)
    w = rng.standard_normal((n_tasks, dim))
    logit = d[None, :] + skill[:, None] + lam * z @ w.T
    Y = (rng.random((M, n_tasks)) < 1.0 / (1.0 + np.exp(-logit))).astype(float)
    pa = Y.mean(1)
    agree = (Y[:, None, :] == Y[None, :, :]).mean(2)
    EC = kappa(agree, pa[:, None], pa[None, :])
    np.fill_diagonal(EC, np.nan)
    oi, ti = _pair_index(M)
    S = _same_grid(makers)
    same = S[oi, ti]
    sim = (z @ z.T)[oi, ti]
    Ra, _ = _annihilator(np.column_stack([np.ones(len(same)), same]))
    h = Ra @ sim
    h = h / h.std() if h.std() > 0 else h
    uo, vr = rng.standard_normal(M), rng.standard_normal(M)
    noise = (math.sqrt(model_share) * (uo[oi] + vr[ti]) / math.sqrt(2)
             + math.sqrt(1 - model_share) * rng.standard_normal(len(oi)))
    T = 0.30 + 0.45 * same + 0.2 * (rho * h + math.sqrt(1 - rho ** 2) * noise)
    D = ArrayData(M, EC, pa, T, makers)
    D.hidden_sim = sim
    D.hidden_resid = h
    return D


W8_THETA_PER_EC = 0.08 / 0.03   # null_world_w8: theta per unit of the latent (in ec units)


def null_world_w8(rng, makers=MAKERS_8, kind: str = "owner", s: float = 0.03) -> ArrayData:
    """W8, one property of each MODEL raises both arrays, with no pair-level link (R7 W11 and his
    question 8). Base: W7's base without the position (X ~ U(0.3, 0.8); ec = 0.10 + 0.08 same
    + u_s + u_t (sd 0.03) + symmetric pair noise (sd 0.04); theta = 0.3 + 0.4 same + 0.3 (X_t - X_s)
    + owner and reader effects (sd 0.08) + N(0, 0.12) per ordered pair). Added: a latent v_m ~ N(0, s)
    per model, independent of X, that raises ec by v_s + v_t and theta by (8/3) v of the OWNER (kind
    'owner'), of the READER ('reader') or of both ('both'). 8/3 = 0.08 / 0.03 gives the latent the
    same share of the model-level variance in both arrays: 1/5 at s = 0.015 (modest), 1/2 at
    s = 0.03 (strong), 4/5 at s = 0.06. Error consistency adds nothing to theta beyond the two models' own
    properties, so a test of PAIR-level incremental value should not reject; the capability columns
    of Q do not hold v, owner and reader fixed effects do. The draws do not depend on `kind` or `s`
    (v = s x a standard normal), so one seed gives the same worlds for every variant. D.latent = v."""
    M = len(makers)
    S = _same_grid(makers)
    X = rng.uniform(0.3, 0.8, M)
    u = rng.normal(0.0, 0.03, M)
    A = np.triu(rng.normal(0.0, 0.04, (M, M)), 1)
    v = float(s) * rng.standard_normal(M)
    ec = 0.10 + 0.08 * S + u[:, None] + u[None, :] + A + A.T + v[:, None] + v[None, :]
    oi, ti = _pair_index(M)
    th = (0.3 + 0.4 * S[oi, ti] + 0.3 * (X[ti] - X[oi]) + rng.normal(0.0, 0.08, M)[oi]
          + rng.normal(0.0, 0.08, M)[ti] + rng.normal(0.0, 0.12, len(oi)))
    if kind == "owner":
        th = th + W8_THETA_PER_EC * v[oi]
    elif kind == "reader":
        th = th + W8_THETA_PER_EC * v[ti]
    elif kind == "both":
        th = th + W8_THETA_PER_EC * (v[oi] + v[ti])
    else:
        raise ValueError(kind)
    D = ArrayData(M, ec, X, th, makers)
    D.latent = v
    return D


def owners_dropped(D, n_drop: int, by: str = "random", rng=None) -> np.ndarray:
    """The n_drop owners whose swaps a home-signal flag drops (R7 W11 (iii), the flag selects owners):
    'random' (drawn with rng), 'capability' (the lowest X, no-memory success; W2's Z, W7's X),
    'latent' (the lowest D.latent of null_world_w8) or 'target' (the lowest mean theta over the
    owner's swaps: a selection on the outcome itself)."""
    n_drop = int(n_drop)
    if n_drop <= 0:
        return np.zeros(0, int)
    if by == "random":
        return np.asarray(rng.choice(D.M, n_drop, replace=False), int)
    if by == "capability":
        val = np.asarray(D.X[0], float)
    elif by == "latent":
        val = np.asarray(D.latent, float)
    elif by == "target":
        y = np.asarray(D.target["T"][0], float)
        val = np.array([np.nanmean(y[np.asarray(D.oi) == j]) for j in range(D.M)])
    else:
        raise ValueError(by)
    return np.argsort(val, kind="stable")[:n_drop]


def rejection_rate(world, n_worlds: int, seed: int, alpha: float = ALPHA, groups=("maker",), plain: bool = False,
                   fixed_effects: bool = False, drop_owners: int = 0, drop_by: str = "random", **kw) -> dict:
    """Share of worlds where F1 rejects at alpha (p <= alpha and statistic > 0), per relabeling
    group (and the plain QAP at alpha / 2 = 0.025 when asked), with its Monte Carlo SE.
    fixed_effects: owner and reader fixed effects in Q (controls; a sensitivity). drop_owners,
    drop_by: theta set to NaN on every swap of `drop_owners` owners chosen by owners_dropped, as the
    home-signal flag drops an owner (ec stays on every pair); a random choice uses its own stream
    (seed, 8), so the worlds are the same as without the drop. The same seed gives the same worlds
    whatever fixed_effects, drop_owners and drop_by are."""
    rng = np.random.default_rng(seed)
    rsel = np.random.default_rng([int(seed), 8])
    hits = {g: 0 for g in groups}
    if plain:
        hits["plain_qap"] = 0
    for _ in range(n_worlds):
        D = world(rng, **kw)
        Q = controls(D, fixed_effects=fixed_effects)
        y, ec = D.target["T"][0], D.pred["ec"][0]
        if drop_owners:
            y = np.where(np.isin(D.oi, owners_dropped(D, drop_owners, drop_by, rsel)), np.nan, y)
        use = np.isfinite(y)
        for g in groups:
            perms, ex = relabelings(D.makers, g)
            r = incremental_test(ec, y, Q, D.oi, D.ti, D.M, use, perms, ex)
            hits[g] += bool(r["p"] <= alpha and r["value"] > 0)
        if plain:
            perms, ex = relabelings(D.makers, "all")
            hits["plain_qap"] += bool(plain_qap(ec, y, D.oi, D.ti, D.M, use, perms, ex)["p"] <= 0.025)
    return {g: (h / n_worlds, math.sqrt(max(h / n_worlds * (1 - h / n_worlds), 1e-12) / n_worlds))
            for g, h in hits.items()}


MODEL_LEVEL_SEED = 20261124
MODEL_LEVEL_BLOCKS = ("w8", "nulls", "select", "power")


def model_level_checks(n_null: int = 4000, n_power: int = 2000, seed: int = MODEL_LEVEL_SEED,
                       blocks: tuple = MODEL_LEVEL_BLOCKS, w8_sizes: tuple = (0.0, 0.015, 0.03, 0.06),
                       verbose: bool = False) -> list:
    """The simulation behind "What F1 and P1 detect" (module docstring; R7 W11). One row per run of
    rejection_rate: F1 at one-sided 0.05, maker-preserving relabelings, with the registered Q
    ("registered") and with owner and reader fixed effects ("fixed effects") on the SAME worlds
    (same seed). Blocks:
      'w8'     null_world_w8, kinds owner / reader / both, s in w8_sizes (0 = the base alone);
      'nulls'  every other null world (W1-W7), n_null worlds each;
      'select' the flag's selection of owners: W2 and W7 'owner' with the swaps of 1 or 2 owners
               dropped, at random, the lowest capability or the lowest mean theta (owners_dropped);
               W8 'owner' (s 0.03) dropping at random or the lowest latent; each beside the same
               worlds with no owner dropped;
      'power'  alt_world at rho 0, 0.3 and 0.6, pair noise and model_share 0.5, n_power worlds each.
    Seeds: seed + 100 + j (w8, kind j), seed + 200 + j (nulls, world j), seed + 300 + j (select, world
    j), seed + 400 + j (power, setting j); each row carries its seed. Rows: dicts with world, kind,
    s, rho, model_share, drop_owners, drop_by, controls, n_worlds, seed, rate, mc_se, seconds."""
    rows = []

    def run_one(world_name, fn, n, sd, wkw, drop=0, by="", fe=False):
        t0 = time.time()
        r = rejection_rate(fn, n, sd, fixed_effects=fe, drop_owners=drop, drop_by=by or "random", **wkw)["maker"]
        row = {"world": world_name, "kind": wkw.get("kind", ""), "s": wkw.get("s"), "rho": wkw.get("rho"),
               "model_share": wkw.get("model_share"), "drop_owners": int(drop), "drop_by": by if drop else "",
               "controls": "fixed effects" if fe else "registered", "n_worlds": int(n), "seed": int(sd),
               "rate": r[0], "mc_se": r[1], "seconds": round(time.time() - t0, 2)}
        rows.append(row)
        if verbose:
            print(json.dumps(row), flush=True)

    both_q = (False, True)
    if "w8" in blocks:
        for j, kind in enumerate(("owner", "reader", "both")):
            for s in w8_sizes:
                for fe in both_q:
                    run_one("null_world_w8", null_world_w8, n_null, seed + 100 + j, {"kind": kind, "s": s}, fe=fe)
    if "nulls" in blocks:
        worlds = [("null_world_w1", null_world_w1, {}), ("null_world_w2", null_world_w2, {}),
                  ("null_world_w3", null_world_w3, {}), ("null_world_w4", null_world_w4, {}),
                  ("null_world_w6", null_world_w6, {}), ("null_world_w5", null_world_w5, {"kind": "max"}),
                  ("null_world_w5", null_world_w5, {"kind": "level"}), ("null_world_w5", null_world_w5, {"kind": "square"}),
                  ("null_world_w7", null_world_w7, {"kind": "owner"}), ("null_world_w7", null_world_w7, {"kind": "both"}),
                  ("null_world_w7", null_world_w7, {"kind": "both_reader"})]
        for j, (name, fn, wkw) in enumerate(worlds):
            for fe in both_q:
                run_one(name, fn, n_null, seed + 200 + j, wkw, fe=fe)
    if "select" in blocks:
        sel = [("null_world_w2", null_world_w2, {}, ("random", "capability", "target")),
               ("null_world_w7", null_world_w7, {"kind": "owner"}, ("random", "capability", "target")),
               ("null_world_w8", null_world_w8, {"kind": "owner", "s": 0.03}, ("random", "latent"))]
        for j, (name, fn, wkw, rules) in enumerate(sel):
            for fe in both_q:
                run_one(name, fn, n_null, seed + 300 + j, wkw, fe=fe)
                for by in rules:
                    for drop in (1, 2):
                        run_one(name, fn, n_null, seed + 300 + j, wkw, drop=drop, by=by, fe=fe)
    if "power" in blocks:
        j = 0
        for rho in (0.0, 0.3, 0.6):
            for share in (0.0, 0.5):
                for fe in both_q:
                    run_one("alt_world", alt_world, n_power, seed + 400 + j, {"rho": rho, "model_share": share}, fe=fe)
                j += 1
    return rows


# ===========================================================================
# The capability-gap control (decision D7): theta and retained agreement against gap and maker
# ===========================================================================

CAPABILITY_TARGETS = (("theta", "theta"), ("retained_order", "order"))   # (CSV name, Data attribute / reportable key)


def capability_rows(D: Data) -> list:
    """forecast_capability.csv: one row per ordered swap with theta (V_swap / V_home, evaluation
    tasks), the retained agreement theta x sqrt(S_owner / S_reader) (column retained_order), the
    spreads, the capability gap (no-memory success, predictor tasks only: signed reader minus owner,
    and absolute), error consistency, the same-maker flag, the newer/older coding and the owner's
    home-signal flag. Intervals: 2.5/97.5 percentiles of the task bootstrap (the evaluate stage's
    own draws)."""
    metric_name, _fn = _metrics_retained()
    order_rule = (f"msr.metrics.{metric_name}" if metric_name else
                  "retained agreement = theta x sqrt(S_owner / S_reader), S = msr.theory S_oo2 / S_nn2 "
                  "(within-session repeats, same pairs); not estimated when a spread is not positive")
    rows = []
    for k, (s, t) in enumerate(D.pairs):
        hf = D.home_flag[s]
        r = {"owner": s, "reader": t, "group": D.design.group(s, t), "same_maker": int(D.pred["same_maker"][0, k]),
             "owner_newer": D.newer[D.mi[s]], "reader_newer": D.newer[D.mi[t]],
             "home_flag": hf["status"], "owner_z_cal": hf["z"], "home_flag_rule": hf["rule"]}
        for name, arr in (("theta", D.theta), ("retained_order", D.order), ("T", D.target["T"])):
            lo, hi, se = _ci(arr[1:, k])
            r.update({name: arr[0, k], f"{name}_lo": lo, f"{name}_hi": hi, f"{name}_se": se})
        r.update({"V_home": D.Vh[0, k], "V_swap": D.Vs[0, k], "S_owner": D.S_owner[0, k],
                  "S_reader": D.S_reader[0, k],
                  "S_reader_z": (D.S_reader[0, k] / D.se["S_reader"][k]) if D.se["S_reader"][k] > 0 else NAN,
                  "retained_order_rule": order_rule})
        for p in ("x_owner", "x_reader", "gap", "abs_gap", "ec"):
            lo, hi, se = _ci(D.pred[p][1:, k])
            r.update({p: D.pred[p][0, k], f"{p}_lo": lo, f"{p}_hi": hi})
        rows.append(r)
    return rows


def _ols_coef(X: np.ndarray, y: np.ndarray) -> tuple:
    """(coefficients with the intercept first, R^2); NaN when rank-deficient or too few rows."""
    A = np.column_stack([np.ones(len(y)), X])
    if len(y) <= A.shape[1]:
        return np.full(A.shape[1], np.nan), NAN
    coef, _res, rank, _sv = np.linalg.lstsq(A, y, rcond=None)
    if rank < A.shape[1]:
        return np.full(A.shape[1], np.nan), NAN
    e = y - A @ coef
    tss = float(np.sum((y - y.mean()) ** 2))
    return coef, (1 - float(e @ e) / tss) if tss > 0 else NAN


def capability_regression(D: Data, terms: tuple = CAPABILITY_TERMS, alpha: float = ALPHA, seed: int = 0) -> list:
    """forecast_capability_regression.csv (descriptive, no decision): theta and the retained agreement
    each regressed by OLS on [1, same_maker, gap, abs_gap, ec] over the swaps whose owner passes the
    home-signal flag (and, for the retained agreement, both spreads > 0). Intervals: 2.5/97.5 percentiles of the
    coefficients refitted in every task-bootstrap draw (predictors and target resampled with the
    study's draws, same swaps). For ec, also the one-sided p of its coefficient (> 0) beyond the
    other terms under the maker-preserving relabelings (pair_incremental_test, F1's machinery);
    the same-maker coefficient has no such p (the relabelings keep the flag)."""
    names = ("intercept",) + tuple(terms)
    owners = [D.mi[s] for s, _ in D.pairs]
    readers = [D.mi[t] for _, t in D.pairs]
    makers = makers_of(D)
    rows = []
    for tname, key in CAPABILITY_TARGETS:
        arr = getattr(D, key)
        Xall = np.stack([D.pred[p] for p in terms], axis=-1)             # (B+1, P, k)
        use = D.reportable[key] & np.all(np.isfinite(Xall[0]), axis=1)
        y0 = arr[0][use]
        coef0, r2 = _ols_coef(Xall[0][use], y0) if use.sum() else (np.full(len(names), np.nan), NAN)
        draws = []
        for d in range(1, arr.shape[0]):
            yd, Xd = arr[d][use], Xall[d][use]
            if not (np.all(np.isfinite(yd)) and np.all(np.isfinite(Xd))):
                continue
            draws.append(_ols_coef(Xd, yd)[0])
        draws = np.array(draws) if draws else np.zeros((0, len(names)))
        perm = {}
        if "ec" in terms and len(D.pairs) and use.sum() >= 3:
            y = np.where(use, arr[0], np.nan)
            ctl = {p: D.pred[p][0] for p in terms if p not in ("ec", "same_maker")}
            perm = pair_incremental_test(D.pred["ec"][0], y, owners, readers, makers, controls=ctl,
                                         alpha=alpha, seed=seed)
        for j, nm in enumerate(names):
            lo, hi, se = _ci(draws[:, j]) if len(draws) else (NAN, NAN, NAN)
            row = {"target": tname, "term": nm, "coef": coef0[j], "lo": lo, "hi": hi, "boot_se": se,
                   "n_swaps": int(use.sum()), "n_models": D.M, "draws_used": int(len(draws)), "r2": r2,
                   "model": f"{tname} ~ 1 + " + " + ".join(terms) + " (OLS)",
                   "interval": "2.5/97.5 percentiles of the task bootstrap (descriptive)",
                   "p_one_sided_maker_relabelings": NAN, "min_attainable_p": NAN,
                   "note": "descriptive; swaps whose owner passes the home-signal flag"
                           + ("; retained agreement needs both spreads > 0" if key == "order" else "")}
            if nm == "ec" and perm:
                row["p_one_sided_maker_relabelings"] = perm["p_one_sided"]
                row["min_attainable_p"] = perm["min_attainable_p"]
                row["note"] += f"; maker-preserving relabelings (F1's test, beyond the other terms): {perm['result']}"
            rows.append(row)
    return rows


# ===========================================================================
# Reliability of the predictors
# ===========================================================================


def reliability(D: Data, seed: int = 0) -> list:
    rows = []
    P = len(D.pairs)
    # split-half by a fixed hash of the task id
    halves = []
    for h in (0, 1):
        sums = {b: {"agree": np.zeros(P), "cmp": np.zeros(P), "sa": np.zeros(P), "sb": np.zeros(P),
                    "succ": np.zeros(D.M), "runs": np.zeros(D.M)} for b in D.streams}
        for (b, sd), nm in D.nomem.items():
            w = np.array([(_h("half", seed, t) % 2) == h for t in nm["tasks"]], float)
            S, N = nm["S"], nm["N"]
            F = N - S
            sums[b]["succ"] += S @ w
            sums[b]["runs"] += N @ w
            for k, (s, t) in enumerate(D.pairs):
                i, j = D.mi[s], D.mi[t]
                sums[b]["agree"][k] += w @ (S[i] * S[j] + F[i] * F[j])
                sums[b]["cmp"][k] += w @ (N[i] * N[j])
                sums[b]["sa"][k] += w @ (S[i] * N[j])
                sums[b]["sb"][k] += w @ (S[j] * N[i])
        with np.errstate(invalid="ignore", divide="ignore"):
            ec = np.nanmean([kappa(sums[b]["agree"] / sums[b]["cmp"], sums[b]["sa"] / sums[b]["cmp"],
                                   sums[b]["sb"] / sums[b]["cmp"]) for b in D.streams], axis=0)
            ag = np.nanmean([sums[b]["agree"] / sums[b]["cmp"] for b in D.streams], axis=0)
            X = np.nanmean([sums[b]["succ"] / sums[b]["runs"] for b in D.streams], axis=0)
        halves.append({"ec": ec, "agree": ag, "gap": X[D.ti] - X[D.oi], "abs_gap": np.abs(X[D.ti] - X[D.oi]),
                       "x_owner": X[D.oi], "x_reader": X[D.ti]})
    for p in PREDICTORS:
        v = D.pred[p][0]
        sym = p in SYMMETRIC
        keep = np.array([(not sym) or D.mi[s] < D.mi[t] for s, t in D.pairs])
        if p in ("x_owner", "x_reader"):
            keep = np.array([True] * len(D.pairs))
        vv = v[keep]
        se = np.nanstd(D.pred[p][1:, keep], axis=0, ddof=1) if D.B > 1 else np.full(keep.sum(), NAN)
        var_b = float(np.nanvar(vv, ddof=1)) if np.isfinite(vv).sum() > 1 else NAN
        rel_se = float(max(0.0, 1 - np.nanmean(se ** 2) / var_b)) if (np.isfinite(var_b) and var_b > 0) else NAN
        r_sh, sb = NAN, NAN
        if p in halves[0]:
            a, b = halves[0][p][keep], halves[1][p][keep]
            ok = np.isfinite(a) & np.isfinite(b)
            if ok.sum() >= 3 and a[ok].std() > 0 and b[ok].std() > 0:
                r_sh = float(np.corrcoef(a[ok], b[ok])[0, 1])
                sb = 2 * r_sh / (1 + r_sh) if r_sh > -1 else NAN
        rows.append({"predictor": p, "kind": "predictor", "distinct_values": int(np.isfinite(vv).sum()),
                     "mean": float(np.nanmean(vv)) if np.isfinite(vv).any() else NAN,
                     "between_pair_sd": math.sqrt(var_b) if np.isfinite(var_b) else NAN,
                     "mean_bootstrap_se": float(np.nanmean(se)) if np.isfinite(se).any() else NAN,
                     "reliability_from_se": rel_se, "split_half_r": r_sh, "spearman_brown": sb,
                     "note": "fixed by design (no sampling error)" if p == "same_maker" else ""})
    # each model's test-retest consistency on the no-memory calibration repeats: a ceiling for ec
    for m in D.models:
        same = cmpn = s1 = s2 = 0.0
        for b in D.streams:
            for sd in D.design.seeds:
                c = D.cells.get((m, m, b, sd))
                if c is None or c.get("none") is None or c["none"].shape[1] < 2:
                    continue
                z = c["none"][c["is_calib"]]
                ok = np.isfinite(z[:, 0]) & np.isfinite(z[:, 1])
                same += float(np.sum(z[ok, 0] == z[ok, 1]))
                cmpn += float(ok.sum())
                s1 += float(z[ok, 0].sum())
                s2 += float(z[ok, 1].sum())
        k = float(kappa(same / cmpn, s1 / cmpn, s2 / cmpn)) if cmpn else NAN
        rows.append({"predictor": f"ec_self:{m}", "kind": "test-retest (repeat 1 vs 2, no memory, calibration tasks)",
                     "distinct_values": int(cmpn), "mean": k, "note": "noise ceiling of ec for this model"})
    return rows


# ===========================================================================
# The run
# ===========================================================================


def _active(D, preds: tuple) -> tuple:
    """The predictors of a model without the newer/older position when the study has none (no
    upgrade pairs: the columns are constant and would leave every fold unfitted)."""
    newer = getattr(D, "newer", None)
    if newer is not None and len(newer) and np.ptp(np.asarray(newer, float)) > 0:
        return tuple(preds)
    return tuple(p for p in preds if p not in ("owner_newer", "reader_newer"))


def run(study_name: str, n_boot: int | None = None, seed: int | None = None, out_dir=None, figures: bool = True,
        fig_dir=None, verbose: bool = True) -> dict:
    from msr.analysis import design_from_study, resolve_study
    t0 = time.time()
    st = resolve_study(study_name)
    design = design_from_study(st)
    ev = (st.raw.get("evaluate") or {}) if isinstance(st.raw, dict) else {}
    n_boot = int(n_boot if n_boot is not None else ev.get("bootstrap", 1000))
    seed = int(seed if seed is not None else ev.get("seed", 0))
    out = Path(out_dir) if out_dir else st.dir / "analysis"
    D = Data(st, design, n_boot, seed)
    P = len(D.pairs)
    paths = {}
    # ---- pairs table
    prow = []
    for k, (s, t) in enumerate(D.pairs):
        r = {"owner": s, "reader": t, "group": design.group(s, t), "same_maker": int(D.pred["same_maker"][0, k]),
             "predictor_comparisons": D.pred_comparisons[k]}
        for p in PREDICTORS:
            if p == "same_maker":
                continue
            lo, hi, se = _ci(D.pred[p][1:, k])
            r.update({p: D.pred[p][0, k], f"{p}_lo": lo, f"{p}_hi": hi, f"{p}_se": se})
        for tname in TARGETS:
            v = D.target[tname]
            lo, hi, _ = _ci(v[1:, k])
            r.update({tname: v[0, k], f"{tname}_lo": lo, f"{tname}_hi": hi})
        hf = D.home_flag[s]
        r.update({"T_status": "reported" if D.reportable["T"][k] else hf["status"],
                  "R_status": "reported" if D.reportable["R"][k] else hf["status"],
                  "owner_z_cal": hf["z"], "home_flag_rule": hf["rule"],
                  "owner_newer": D.newer[D.mi[s]], "reader_newer": D.newer[D.mi[t]],
                  "n_home": D.Nh[0, k], "n_swap": D.Ns[0, k], "c_home": D.Ch[0, k],
                  "eval_tasks": sum(D.eval_tasks.values())})
        prow.append(r)
    paths["pairs"] = out / "forecast_pairs.csv"
    write_csv(paths["pairs"], prow)
    paths["capability"] = out / "forecast_capability.csv"
    write_csv(paths["capability"], capability_rows(D))
    paths["capability_regression"] = out / "forecast_capability_regression.csv"
    write_csv(paths["capability_regression"], capability_regression(D, seed=seed))
    paths["reliability"] = out / "forecast_reliability.csv"
    write_csv(paths["reliability"], reliability(D, seed))
    # ---- models: leave one model out, point and bootstrap
    sub = subsample_estimates(D, seed=seed)
    mrows, predrows = [], []
    for tname in TARGETS:
        y_all = D.target[tname]
        use = D.reportable[tname] & np.isfinite(y_all[0])
        gm_pred, gm_unfit = lomo(D, (), y_all[0], use)
        gm = {(m, k): v for m, k, v in gm_pred}
        gm_pair = np.full(P, np.nan)
        for k in range(P):
            vals = [v for (m, kk), v in gm.items() if kk == k]
            gm_pair[k] = np.mean(vals) if vals else np.nan
        both = tname == PRIMARY_TARGET            # leave-both-models-out rows for the primary target only
        boots = {name: [] for name in MODELS}
        bboots = {name: [] for name in BOTH_OUT_MODELS} if both else {}
        for d in range(1, D.B + 1):
            yd = y_all[d]
            gmd = {(m, k): v for m, k, v in lomo(D, (), yd, use, d)[0]}
            for name, (preds, _role) in MODELS.items():
                boots[name].append(_metrics(lomo(D, _active(D, preds), yd, use, d)[0], yd, gmd))
            if both:
                gmbd = {(m, k): v for m, k, v in lbmo(D, (), yd, use, d)[0]}
                for name in BOTH_OUT_MODELS:
                    bboots[name].append(_metrics(lbmo(D, _active(D, MODELS[name][0]), yd, use, d)[0], yd, gmbd))
        mets = {}
        for name, (preds, role) in MODELS.items():
            preds = _active(D, preds)
            pr, unfit = lomo(D, preds, y_all[0], use)
            met = _metrics(pr, y_all[0], gm)
            mets[name] = met
            boot = boots[name]
            row = {"target": tname, "model": name, "role": role, "predictors": " + ".join(preds) or "(intercept)",
                   "uses": "no-memory runs only (before the swap)", "post_swap_calls_per_bank": 0,
                   "validation": "leave one model out",
                   "n_swaps": int(use.sum()), "n_models": D.M, "folds_not_fitted": unfit, **met}
            for mk in ("r2_oof", "spearman_oof", "mae_oof"):
                lo, hi, _ = _ci([b[mk] for b in boot])
                row[f"{mk}_lo"], row[f"{mk}_hi"] = lo, hi
            ins = [spearman(D.pred[p][0][use], y_all[0][use]) for p in preds]
            row["in_sample_spearman"] = ins[0] if len(ins) == 1 else NAN
            if name == "same_maker" and len(set(D.pred["same_maker"][0][use])) < 2:
                row["note"] = "not available: no same-maker swaps (or only same-maker swaps) in this study"
            elif unfit:
                row["note"] = f"could not be fitted in {unfit} fold(s): a predictor is constant or too few training swaps"
            mrows.append(row)
            for m, k, v in pr:
                predrows.append({"target": tname, "model": name, "held_out": m, "owner": D.pairs[k][0],
                                 "reader": D.pairs[k][1], "prediction": v, "truth": y_all[0][k]})
        # forecast minus baseline (A1.8: the forecast must beat same_maker and gap out of fold)
        def diff_row(name, role, ma, mb, ba, bb, validation):
            row = {"target": tname, "model": name, "role": role, "validation": validation,
                   "n_swaps": int(use.sum()), "n_models": D.M}
            for mk in ("r2_oof", "spearman_oof", "mae_oof"):
                row[mk] = ma[mk] - mb[mk]
                lo, hi, _ = _ci([a[mk] - b[mk] for a, b in zip(ba, bb)])
                row[f"{mk}_lo"], row[f"{mk}_hi"] = lo, hi
            row["note"] = ("R2 and Spearman: > 0 favours the forecast; MAE: < 0 favours it. "
                           "Useful only if the R2 interval excludes 0 (pre-registration 8.4.A1.8)")
            return row
        for fc in ("ec", "ec_gap"):
            for bl in ("same_maker", "gap"):
                mrows.append(diff_row(f"{fc} - {bl}", "difference (forecast minus baseline)", mets[fc], mets[bl],
                                      boots[fc], boots[bl], "leave one model out"))
        inc = "difference: what ec adds to the controls of F1 (descriptive; the test is F1)"
        mrows.append(diff_row("ec_same_gap - same_gap", inc, mets["ec_same_gap"], mets["same_gap"],
                              boots["ec_same_gap"], boots["same_gap"], "leave one model out"))
        if both:
            # leave BOTH models out: leave-one-model-out still sees the other model of each swap
            gmb = {(m, k): v for m, k, v in lbmo(D, (), y_all[0], use)[0]}
            bmets = {}
            for name in BOTH_OUT_MODELS:
                preds, role = MODELS[name]
                preds = _active(D, preds)
                pr, unfit = lbmo(D, preds, y_all[0], use)
                bmets[name] = met = _metrics(pr, y_all[0], gmb)
                row = {"target": tname, "model": f"{name}_both_out", "role": role,
                       "predictors": " + ".join(preds), "uses": "no-memory runs only (before the swap)",
                       "post_swap_calls_per_bank": 0, "validation": "leave both models out",
                       "n_swaps": int(use.sum()), "n_models": D.M, "folds_not_fitted": unfit, **met}
                for mk in ("r2_oof", "spearman_oof", "mae_oof"):
                    lo, hi, _ = _ci([b[mk] for b in bboots[name]])
                    row[f"{mk}_lo"], row[f"{mk}_hi"] = lo, hi
                row["note"] = ("each swap predicted by a fit on the swaps that involve neither of its models; "
                               "R2 against the grand mean of those swaps"
                               + (f"; {unfit} swap(s) not predicted (too few training swaps)" if unfit else ""))
                mrows.append(row)
            mrows.append(diff_row("ec_same_gap_both_out - same_gap_both_out", inc, bmets["ec_same_gap"],
                                  bmets["same_gap"], bboots["ec_same_gap"], bboots["same_gap"],
                                  "leave both models out"))
        # post-swap 20-check baseline: one estimate per draw; metrics per draw
        est = sub[tname]
        per = [_metrics_direct(est[dd], y_all[0], gm_pair, use) for dd in range(est.shape[0])]
        row = {"target": tname, "model": "subsample_20", "role": "post-swap baseline (Goyal and Ray style)",
               "predictors": f"{SUBSAMPLE_TASKS} calibration tasks x all candidates, one repeat each",
               "uses": "fresh checks AFTER the swap", "post_swap_calls_per_bank": 4 * SUBSAMPLE_TASKS,
               "validation": "direct estimate after the swap",
               "n_swaps": int(use.sum()), "n_models": D.M, "folds_not_fitted": 0,
               "n_predictions": int(use.sum()), "draws": est.shape[0]}
        for mk in ("r2_oof", "spearman_oof", "mae_oof"):
            v = np.array([p_[mk] for p_ in per], float)
            row[mk] = float(np.nanmean(v)) if np.isfinite(v).any() else NAN
            row[f"{mk}_lo"] = float(np.nanpercentile(v, 5)) if np.isfinite(v).any() else NAN
            row[f"{mk}_hi"] = float(np.nanpercentile(v, 95)) if np.isfinite(v).any() else NAN
        row["note"] = ("value = mean over draws of one swap day's 20-check estimate; lo/hi = 5th/95th "
                       "percentile over draws (what one swap day may look like)")
        mrows.append(row)
    paths["models"] = out / "forecast_models.csv"
    write_csv(paths["models"], mrows)
    paths["predictions"] = out / "forecast_predictions.csv"
    write_csv(paths["predictions"], predrows)
    paths["tests"] = out / "forecast_tests.csv"
    write_csv(paths["tests"], permutation_tests(D, ALPHA, seed))
    if figures:
        paths.update(draw_figures(st, out, fig_dir))
    if verbose:
        print(f"[forecast] {study_name}: {D.M} models, {P} swaps, {D.B} bootstrap draws, "
              f"{time.time() - t0:.1f} s; tables in {out}")
    return paths


# ===========================================================================
# Figure
# ===========================================================================

GROUP_STYLE = {"upgrade": ("#0072B2", "o", "#0072B2", "same-maker upgrade"),
               "downgrade": ("#E69F00", "s", "white", "same-maker downgrade"),
               "same_other": ("#009E73", "v", "#009E73", "other same-maker swap"),
               "cross": ("#D55E00", "^", "#D55E00", "cross-maker swap")}
MODEL_LABEL = {"grand_mean": "grand mean", "same_maker": "same maker", "gap": "capability gap",
               "same_gap": "same maker + gap", "ec": "error consistency", "ec_gap": "EC + gap",
               "ec_same_gap": "EC + same maker + gap", "subsample_20": "20 fresh checks (after swap)"}
EC_MODELS = ("ec", "ec_gap", "ec_same_gap")


def _read(path: Path) -> list:
    if not Path(path).exists():
        return []
    with open(path, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def _f(v) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return NAN


def draw_figures(st, adir: Path, fig_dir=None) -> dict:
    """fig_forecast_readiness: (a) error consistency before the swap against the retained share T
    after it, one point per ordered swap with its interval; (b) out-of-fold mean absolute error of
    the forecasts and baselines for T (leave one model out; the 20-check baseline after the swap)."""
    from msr.analysis import study_kind
    from msr.figures import COLUMN_W, MARKS, _mpl, _save, _sim_mark
    plt = _mpl()
    out = Path(fig_dir) if fig_dir else ROOT / "paper" / "assets"
    pairs = _read(Path(adir) / "forecast_pairs.csv")
    models = [r for r in _read(Path(adir) / "forecast_models.csv") if r["target"] == PRIMARY_TARGET]
    if not pairs:
        return {}
    fig, axes = plt.subplots(1, 2, figsize=(2 * COLUMN_W, 2.0), gridspec_kw={"width_ratios": [1.0, 1.1]})
    ax = axes[0]
    seen = set()
    for r in pairs:
        if r.get("T_status") != "reported":
            continue
        col, mk, fc, lab = GROUP_STYLE.get(r["group"], ("#000000", "D", "white", r["group"]))
        x, y = _f(r["ec"]), _f(r["T"])
        ax.errorbar(x, y, xerr=[[x - _f(r["ec_lo"])], [_f(r["ec_hi"]) - x]],
                    yerr=[[y - _f(r["T_lo"])], [_f(r["T_hi"]) - y]], fmt="none", ecolor=col, elinewidth=0.5, alpha=0.6)
        ax.scatter([x], [y], marker=mk, s=16, facecolors=fc, edgecolors=col, linewidths=0.8,
                   label=None if lab in seen else lab, zorder=3)
        seen.add(lab)
    ax.axhline(1.0, color="#999999", lw=0.5, ls=(0, (4, 2)))
    ax.axhline(0.0, color="#999999", lw=0.5)
    ax.set_xlabel("error consistency, no memory (before the swap)")
    ax.set_ylabel(r"retained share $T=N_{swap}/N_{home}$ (after)")
    h, l = ax.get_legend_handles_labels()
    rank = {v[3]: j for j, v in enumerate(GROUP_STYLE.values())}
    hl = sorted(zip(h, l), key=lambda z: rank.get(z[1], 9))
    if hl:
        ax.legend([a for a, _ in hl], [b for _, b in hl], fontsize=5, loc="best")
    ax2 = axes[1]
    order = ["grand_mean", "same_maker", "gap", "same_gap", "ec", "ec_same_gap", "subsample_20"]
    rows = [next((r for r in models if r["model"] == m), None) for m in order]
    ys = np.arange(len(order))[::-1]
    for yv, m, r in zip(ys, order, rows):
        if r is None or not math.isfinite(_f(r["mae_oof"])):
            ax2.text(0.0, yv, "  not available", va="center", fontsize=5, color="#777777")
            continue
        v, lo, hi = _f(r["mae_oof"]), _f(r["mae_oof_lo"]), _f(r["mae_oof_hi"])
        col = "#D55E00" if m == "subsample_20" else ("#0072B2" if m in EC_MODELS else "#555555")
        mk = "s" if m == "subsample_20" else ("o" if m in EC_MODELS else "D")
        if math.isfinite(lo) and math.isfinite(hi):
            ax2.plot([lo, hi], [yv, yv], color=col, lw=1.0)
        ax2.plot([v], [yv], marker=mk, color=col, markersize=4, mfc=col if m != "grand_mean" else "white")
    ax2.set_yticks(ys)
    ax2.set_yticklabels([MODEL_LABEL[m] for m in order])
    ax2.set_xlabel("mean absolute error for T, out of fold")
    ax2.set_xlim(left=0)
    _sim_mark(fig, MARKS.get(study_kind(st), ""))
    fig.tight_layout()
    return {f"fig:{p.name}": p for p in _save(fig, out, "fig_forecast_readiness")}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--study", required=True)
    ap.add_argument("--bootstrap", type=int, default=None)
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--no-figures", action="store_true")
    ap.add_argument("--out", default=None, help="tables folder (default runs/<study>/analysis/)")
    ap.add_argument("--fig-dir", default=None,
                    help="figures folder (default: the --out folder when --out is given, else paper/assets)")
    a = ap.parse_args(argv)
    # a run into another folder never writes into the paper: its figure goes beside its tables
    fig_dir = a.fig_dir or a.out
    run(a.study, n_boot=a.bootstrap, seed=a.seed, out_dir=a.out, figures=not a.no_figures, fig_dir=fig_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
