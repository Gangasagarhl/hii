"""Construct checks and free swap-day baselines (revision 2, decision D7). No model call.

Everyday picture: the garage's old tip cards each carry a usefulness grade earned with the old
helper. A sceptic says: "those grades only tell you which cards have the RIGHT repair written on
them; a right repair helps any helper, so of course the grades still work after a new helper
arrives." This module checks that, and a few cheap things a garage owner would try first:
  1. a plain "the written repair was right" score (we know which written answers were graded
     right when the card was written), ranked against the learned grades;
  2. how much of the learned grade's ranking power is that "right or wrong" fact, and how much
     is left once it is taken out;
  3. whether the cards that help are simply cards whose written answer IS the new job's answer,
     or near copies of the new job; and how often each card was tried before it was graded;
  4. free swap-day rules (ask the new helper to answer the card's job himself and keep the cards
     he agrees with; the "written answer was right" score; grades re-weighted by how likely each
     card was to be tried), scored exactly like the paper's rules;
  5. one cost table that charges every rule for every call it uses.

Inputs (all written by the pipeline already): runs/<study>/results/cells/*.npz (the raw probe
cells), results/per_task/*.npz (which evaluation tasks are valid), the banks (items.jsonl with
each stored answer and its write-time grade, the score files, episodes.jsonl with the logged
selection probabilities), and the task embeddings. Outputs: runs/<study>/analysis/construct_*.csv
and CONSTRUCT.md (scripts/make_construct_assets.py).

Every concordance, signed validity, retained value, interval and p-value comes from msr.metrics or
msr.engine: engine.conc_parts (pairs within a task, ties 1/2), metrics.signed_validity_from_conc
(V = 2 num - W), metrics.theta_inference (Fieller interval, two-way task x item variance),
metrics.cluster_variance, metrics.calibration_z; first-shown success, regret and log / Brier scores
from engine.first_shown and engine.log_brier, the level correction from metrics.level_shift and
shift_probs. Which metrics function plays each role is set in MEASURES (one line to switch);
run(measures=...) overrides it for one run. What this module adds is only the pair subsets, the
new static scores and the bookkeeping.

Pair subsets are exact: V, the weights W and the informative-pair counts are sums over the pairs
of a task, so "pairs of mixed grade" = all pairs - correct-correct pairs - wrong-wrong pairs, and
"pairs whose less-visited item has 3-5 visits" = pairs with both >= 3 - pairs with both >= 6.
"""
from __future__ import annotations

import csv
import json
import math
import re
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

from msr import engine as X
from msr import metrics as M

NAN = float("nan")

#: Which msr.metrics function plays each role: switch a role here (one line) or pass
#: run(measures={role: name}). Every role is looked up by name at call time. Since revision 2 the
#: registered variance is metrics.robust_variance (two-way delete-one-cluster jackknife, items by
#: identity across orders, component ids) and the registered tests metrics.theta_tests (home-sign
#: intersection-union, drop beyond the self-swap reference), as in msr.analysis.TwoWay; the round-1
#: pair (theta_inference, cluster_variance) still works: Pool calls either by its signature.
MEASURES = {
    "validity": "signed_validity_from_conc",   # per-task V from the parts of Cw: V = 2 num - W
    "retained": "theta_from_sums",             # theta = V_swap / V_home (point only)
    "inference": "theta_tests",                # theta with its Fieller set and the registered tests
    "variance": "robust_variance",             # two-way variance of a linear statistic
    "p_values": "normal_p",
    "home_flag": "home_signal_flag",           # THE one home-signal rule of the project: (z, status)
    "spread_z": "calibration_z",               # z of the reader's spread on calibration tasks (order's flag input)
    "spread": "cross_repeat_parts",            # noise-free item spread S per task (retained order, stakes)
    "cal_validity": "signed_validity_parts",
    "level_shift": "level_shift",
    "shift_probs": "shift_probs",
}
ACTIVE = dict(MEASURES)


def measure(role: str):
    """The msr.metrics function that plays `role` now (ACTIVE, else MEASURES)."""
    name = ACTIVE.get(role, MEASURES[role])
    fn = getattr(M, name, None)
    if fn is None:
        raise AttributeError(f"msr.metrics has no function {name!r} for role {role!r}: update "
                             "msr.construct.MEASURES")
    return fn


#: The stored-answer-correct reference with ties broken by relevance: x = grade + REL_TIE x relevance
#: (relevance is in [0, 1], so the grade always decides first; any REL_TIE < 1 gives the same order).
REL_TIE = 1e-3
#: Propensity clip of the propensity-weighted scores: pi is raised to at least PI_CLIP (weight at
#: most 20). With epsilon-greedy over 4 candidates the smallest logged pi is epsilon / 4 = 0.075,
#: so the clip does not bind in this design; it guards designs with more candidates or less
#: exploration. The number of clipped propensities is reported.
PI_CLIP = 0.05
#: Near-duplicate threshold: the NEAR_DUP_Q quantile of the similarity of task pairs that cannot be
#: the same case (DDXPlus: different pathology; BIRD: different database). A pair above it is more
#: alike than all but 1 in 1,000 such pairs. NEAR_DUP_SENS are reported beside it.
NEAR_DUP_Q = 0.999
NEAR_DUP_SENS = (0.99, 0.9999)
#: Visit strata of the score phase (showings per item); a pair falls in the stratum of its
#: less-visited item.
VISIT_BINS = ((0, 0), (1, 2), (3, 5), (6, math.inf))
VISIT_LABELS = ("0", "1-2", "3-5", "6+")
#: Residual rankings of point 2 (see residualise).
RESIDUALS = ("ols", "rank")

GROUPS = ("upgrade", "downgrade", "cross", "same_maker", "all_swaps", "home")
GROUP_LABEL = {"upgrade": "same-maker upgrades", "downgrade": "same-maker downgrades",
               "cross": "cross-maker swaps", "same_maker": "all same-maker swaps",
               "all_swaps": "all swaps", "home": "home cells (self-swap: extra repeats 3-4)"}
REFERENCES = ("correct", "correct_rel", "relevance")
STATIC_BASELINES = ("reanswer", "ips", "dr")
FLAGS = ("match", "neardup", "either")
FLAG_LABEL = {"match": "the stored answer is the probe task's gold answer",
              "neardup": "the item's task is a near-duplicate of the probe task",
              "either": "either of the two"}


# ===========================================================================
# Pure helpers (hand-made arrays in the tests)
# ===========================================================================


def table(cand, rel, y, valid=None) -> X.Table:
    """engine.Table of one outcome table: cand (E, C) item index (-1 none), rel (E, C), y (E, C, R)."""
    return X.Table(np.asarray(cand, dtype=np.int64), np.asarray(rel, dtype=float), np.asarray(y, dtype=float),
                   None if valid is None else np.asarray(valid, dtype=bool))


def pair_parts(T: X.Table, x, mask=None) -> dict:
    """Per task: the parts of Cw of score x (E, C) against T's outcomes over the pairs whose two
    candidates are both in `mask` (default every candidate with a result): num, den (= W),
    num_u, den_u (= informative pairs) from engine.conc_parts, and V = 2 num - W (msr.metrics).
    Candidates with a non-finite score are left out. Tasks that are not valid are NaN."""
    x = np.asarray(x, dtype=float)
    fin = np.isfinite(x)
    m = T.cmask & fin
    if mask is not None:
        m = m & np.asarray(mask, dtype=bool)
    num, den, nu, du = X.conc_parts(T, np.where(fin, x, 0.0), mask=m)
    return {"num": num, "den": den, "num_u": nu, "den_u": du, "V": measure("validity")(num, den)}


def _combine(a: dict, b: dict, sign: float = 1.0) -> dict:
    return {k: a[k] + sign * b[k] for k in a}


def grade_split(T: X.Table, x, grade, mask=None) -> dict:
    """{"all", "cc", "ii", "mixed", "same"}: pair_parts over all pairs, pairs of two correct stored
    answers, of two wrong ones, of one of each (all - cc - ii, exact) and of the same grade.
    grade (E, C): 1 / 0 / NaN (NaN candidates are left out of every subset)."""
    g = np.asarray(grade, dtype=float)
    known = np.isfinite(g)
    base = known if mask is None else (known & np.asarray(mask, dtype=bool))
    allp = pair_parts(T, x, base)
    cc = pair_parts(T, x, base & (g == 1))
    ii = pair_parts(T, x, base & (g == 0))
    same = _combine(cc, ii)
    return {"all": allp, "cc": cc, "ii": ii, "same": same, "mixed": _combine(allp, same, -1.0)}


def visit_strata(T: X.Table, x, visits, bins=VISIT_BINS, mask=None) -> list:
    """pair_parts per visit stratum, the stratum of a pair being that of its LESS-visited
    candidate: pairs with both visits >= lo_b minus pairs with both >= lo_{b+1} (exact)."""
    v = np.asarray(visits, dtype=float)
    base = np.isfinite(v) if mask is None else (np.isfinite(v) & np.asarray(mask, dtype=bool))
    ge = [pair_parts(T, x, base & (v >= lo)) for lo, _hi in bins]
    out = []
    for j in range(len(bins)):
        out.append(ge[j] if j == len(bins) - 1 else _combine(ge[j], ge[j + 1], -1.0))
    return out


def residualise(x, grade, how: str = "ols") -> np.ndarray:
    """The learned score with the stored-answer grade taken out, per item (the bank's items):

    ols  : x - mean of x over the bank's items of the same grade. For a 0/1 grade every function of
           the grade is a + b g, so this is the least-squares residual of x on (1, g) (Frisch-Waugh):
           it removes everything the grade can explain linearly, is uncorrelated with the grade over
           the bank, and keeps the order WITHIN each grade, so correct-correct and wrong-wrong pairs
           keep their V and only mixed pairs move (they are then ranked by each item's place
           relative to its own grade's mean).
    rank : the within-grade mid-rank of x divided by the grade's item count, in (0, 1]: the same
           within-grade order, and on mixed pairs the two items are compared by their position in
           their own grade, so a grade-dependent SPREAD of x (which ols leaves in) is removed too.
    Items without a grade are centred on the mean of all items (ols) or ranked among all (rank)."""
    from scipy.stats import rankdata
    x = np.asarray(x, dtype=float)
    g = np.asarray(grade, dtype=float)
    out = np.full(x.shape, NAN)
    groups = [np.isfinite(g) & (g == 1), np.isfinite(g) & (g == 0), ~np.isfinite(g)]
    for k, sel in enumerate(groups):
        sel = sel & np.isfinite(x)
        if not sel.any():
            continue
        if k == 2:
            ref = np.isfinite(x)
            if how == "ols":
                out[sel] = x[sel] - x[ref].mean()
            else:
                r = rankdata(x[ref]) / ref.sum()
                out[sel] = r[sel[ref]]
            continue
        if how == "ols":
            out[sel] = x[sel] - x[sel].mean()
        elif how == "rank":
            out[sel] = rankdata(x[sel]) / sel.sum()
        else:
            raise ValueError(f"unknown residual {how!r}")
    return out


def correctness_auc(x, grade) -> float:
    """How well a score separates the items with a correct stored answer from the others over a
    bank: the weighted concordance of x with the grade over all item pairs (= the AUC; ties 1/2),
    computed by engine.conc_parts on one 'task' whose candidates are all the items."""
    x = np.asarray(x, dtype=float)
    g = np.asarray(grade, dtype=float)
    ok = np.isfinite(x) & np.isfinite(g)
    if ok.sum() < 2 or len(set(g[ok].tolist())) < 2:
        return NAN
    n = int(ok.sum())
    T = X.Table(np.arange(n)[None, :], np.zeros((1, n)), g[ok][None, :, None])
    num, den, _, _ = X.conc_parts(T, x[ok][None, :])
    return float(X.ratio(num, den))


def propensity_scores(episodes: list, index: dict, n_items: int, pi_clip: float = PI_CLIP) -> dict:
    """Propensity-weighted scores of a bank from its logged score phase.

    snips_i = sum_{t: i shown} y_t / pi_t  /  sum_{t: i shown} 1 / pi_t   (self-normalised IPS of the
              success when i is shown; Part 8.3.5's ips_num / ips_den with the clip);
    dr_i    = mean over the episodes t where i was a CANDIDATE of
              b_t + 1{i shown at t} (y_t - b_t) / pi_t                      (doubly robust),
              with b_t the owner's no-memory result on task t (the build's no-memory run; the direct
              model) and pi_t the logged probability that i was picked; only the shown item's pi is
              needed, because the correction term is 0 for the others.
    pi is clipped below at pi_clip. Items never shown get the bank's pooled snips; items never a
    candidate get the bank's mean dr term. With several items shown per task each shown item is
    credited with the task's outcome."""
    num = np.zeros(n_items)
    den = np.zeros(n_items)
    shows = np.zeros(n_items)
    dr_sum = np.zeros(n_items)
    dr_n = np.zeros(n_items)
    pis, clipped, no_base = [], 0, 0
    for e in episodes:
        y = 1.0 if e.get("correct") else 0.0
        b = e.get("no_memory")
        if b is None:
            no_base += 1
            b = 0.0
        b = float(b)
        probs = e.get("probs") or [None] * len(e.get("shown") or [])
        pmap = {i: p for i, p in zip(e.get("shown") or [], probs)}
        for cand in e.get("candidates") or []:
            iid = cand[0] if isinstance(cand, (list, tuple)) else cand
            j = index.get(iid)
            if j is None:
                continue
            term = b
            if iid in pmap and pmap[iid]:
                pi = float(pmap[iid])
                pis.append(pi)
                if pi < pi_clip:
                    clipped += 1
                pi = max(pi, pi_clip)
                term += (y - b) / pi
                num[j] += y / pi
                den[j] += 1.0 / pi
                shows[j] += 1
            dr_sum[j] += term
            dr_n[j] += 1
    pooled = num.sum() / den.sum() if den.sum() > 0 else NAN
    snips = np.where(den > 0, num / np.where(den > 0, den, 1.0), pooled)
    dr_mean = dr_sum.sum() / dr_n.sum() if dr_n.sum() > 0 else NAN
    dr = np.where(dr_n > 0, dr_sum / np.where(dr_n > 0, dr_n, 1.0), dr_mean)
    return {"snips": snips, "dr": dr, "shows": shows, "candidate_episodes": dr_n,
            "min_pi": min(pis) if pis else NAN, "clipped": clipped, "episodes_without_baseline": no_base}


def answers_agree(stream: str, task: dict, owner_answer, reader_answer, faithful: bool = False) -> bool:
    """Does the reader's own no-memory answer to an item's write task agree with the stored answer?
    By the grader's own rule with the stored answer in place of the gold one: DDXPlus, the same valid
    diagnosis label; BIRD, the reader's query returns the same non-empty result set as the stored
    query on the task's database (msr.grade.grade_detail with gold := stored answer)."""
    from msr import grade as G
    from msr.data import LABEL2TEXT
    if owner_answer is None or reader_answer is None:
        return False
    if stream == "ddxplus":
        a = G.parse_answer("ddxplus", owner_answer)
        return a in LABEL2TEXT and a == G.parse_answer("ddxplus", reader_answer)
    pseudo = dict(task)
    pseudo["SQL"] = G.parse_answer("bird", owner_answer, faithful=faithful)
    return bool(G.grade_detail("bird", pseudo, reader_answer, faithful=faithful)["correct"])


def answer_match(stream: str, probe_task: dict, stored_answer, item_task: dict | None = None,
                 faithful: bool = False) -> bool:
    """Is the item's stored answer the probe task's gold answer? The grader decides, as if the
    stored answer were the reader's answer to the probe task (DDXPlus: the same diagnosis; BIRD: the
    stored query returns the probe's gold result on the probe's database; an item written on another
    database never matches)."""
    from msr import grade as G
    if stored_answer is None:
        return False
    if stream == "bird" and item_task is not None and item_task.get("db_id") != probe_task.get("db_id"):
        return False
    return bool(G.grade_detail(stream, probe_task, stored_answer, faithful=faithful)["correct"])


def case_key(stream: str, task: dict):
    """What two tasks must share to possibly be the same case: DDXPlus the pathology, BIRD the database."""
    return task.get("label") if stream == "ddxplus" else task.get("db_id")


def neardup_threshold(sims: np.ndarray, null_mask: np.ndarray, q: float = NEAR_DUP_Q) -> float:
    """The q quantile of the similarities of the pairs that cannot be the same case."""
    s = np.asarray(sims, dtype=float)[np.asarray(null_mask, dtype=bool)]
    s = s[np.isfinite(s)]
    return float(np.quantile(s, q)) if s.size else NAN


def visit_bin_of(v) -> np.ndarray:
    """The stratum index (VISIT_BINS) of each visit count (NaN -> -1)."""
    v = np.asarray(v, dtype=float)
    out = np.full(v.shape, -1, dtype=int)
    for j, (lo, hi) in enumerate(VISIT_BINS):
        out[(v >= lo) & (v <= hi)] = j
    return out


# ===========================================================================
# Pooling over stream orders and groups, with the two-way variance
# ===========================================================================


def _takes(fn, name: str) -> bool:
    """Does fn accept a parameter called name (the revision-2 metrics functions take comp)?"""
    import inspect
    try:
        return name in inspect.signature(fn).parameters
    except (TypeError, ValueError):
        return False


class Pool:
    """Per-task values of every (cell, stream, order), and the statistics over a list of
    (cell, stream) items: the mean of a key per item (pooled over orders, equal weight per swap and
    stream, Part 2.12), ratios such as Cw, theta with msr.metrics.theta_inference, and linear
    statistics with the two-way (task id x item) variance. Mirrors msr.analysis.TwoWay."""

    def __init__(self, streams: list, seeds: list):
        self.streams, self.seeds = list(streams), list(seeds)
        self.store: dict = defaultdict(dict)       # (cell, stream, seed) -> {key: (E,) array}
        self.tcode: dict = {}                      # (stream, seed) -> (E,) task codes
        self.icode: dict = {}                      # (owner, stream, seed) -> (E, C) item codes
        self.cal: dict = {}                        # (score, owner, stream, seed) -> calibration V
        self.rcal: dict = {}                       # (owner, reader, stream, seed) -> reader spread S, calibration
        self._tmap: dict = {}
        self._imap: dict = {}

    def set_codes(self, owner: str, stream: str, seed: int, tasks, items) -> None:
        if (stream, seed) not in self.tcode:
            self.tcode[(stream, seed)] = np.array([self._tmap.setdefault(f"{stream}|{t}", len(self._tmap))
                                                   for t in tasks], dtype=np.int64)
        if (owner, stream, seed) not in self.icode:
            it = np.asarray(items).astype(str)
            codes = np.full(it.shape, -1, dtype=np.int64)
            for (e, c), v in np.ndenumerate(it):
                if v:
                    # identity within (owner, stream): the same cluster in every order (revision 2,
                    # as msr.analysis.TwoWay)
                    codes[e, c] = self._imap.setdefault(f"{owner}|{stream}|{v}", len(self._imap))
            self.icode[(owner, stream, seed)] = codes

    def put(self, cell: tuple, stream: str, seed: int, key: str, value) -> None:
        self.store[(cell, stream, seed)][key] = np.asarray(value, dtype=float)

    def put_parts(self, cell, stream, seed, key: str, parts: dict) -> None:
        for k in ("V", "num", "den", "den_u"):
            self.put(cell, stream, seed, f"{key}#{k}", parts[k])

    def levels(self) -> list:
        """The levels to compute: every stream, and 'all' (the streams pooled) when there are two or
        more; with one stream 'all' equals it and run() copies the rows."""
        return self.streams + (["all"] if len(self.streams) > 1 else [])

    def items(self, cells: list, level: str) -> list:
        bs = self.streams if level == "all" else [level]
        return [(c, b) for c in cells for b in bs]

    def _vals(self, key: str, cell, b) -> list:
        out = []
        for sd in self.seeds:
            v = self.store.get((cell, b, sd), {}).get(key)
            if v is not None:
                out.append((sd, v))
        return out

    def comps_full(self, comps: list) -> tuple:
        """A linear statistic sum_k coef_k x (mean over the valid tasks of stream b_k, all orders, of
        key_k in cell_k): (point, psi, task codes, item codes, component ids), psi centred per
        component (one component = one (key, cell, stream) mean pooled over the orders)."""
        point = 0.0
        P, T, I, Cp = [], [], [], []
        for k, (key, cell, b, coef) in enumerate(comps):
            vals = self._vals(key, cell, b)
            n = sum(int(np.isfinite(v).sum()) for _, v in vals)
            if n == 0:
                return NAN, None, None, None, None
            mu = sum(float(np.nansum(v)) for _, v in vals) / n
            point += coef * mu
            for sd, v in vals:
                ok = np.isfinite(v)
                P.append(coef * (v[ok] - mu) / n)
                T.append(self.tcode[(b, sd)][ok])
                ic = self.icode.get((cell[0], b, sd))
                I.append(ic[ok] if ic is not None and ic.shape[0] == len(v) else np.full((int(ok.sum()), 4), -1))
                Cp.append(np.full(int(ok.sum()), k, dtype=np.int64))
        if not P:
            return NAN, None, None, None, None
        return point, np.concatenate(P), np.concatenate(T), np.vstack(I), np.concatenate(Cp)

    def comps(self, comps: list) -> tuple:
        """comps_full without the component ids: (point, psi, task codes, item codes)."""
        return self.comps_full(comps)[:4]

    def total(self, items: list, key: str) -> float:
        """Sum over the items of the per-item mean (the V totals of theta)."""
        pt, *_ = self.comps([(key, c, b, 1.0) for c, b in items])
        return pt

    def mean(self, items: list, key: str) -> float:
        """Equal-weight mean over the items of the per-item mean over valid tasks (Part 2.12)."""
        vals = []
        for c, b in items:
            pt, psi, *_ = self.comps([(key, c, b, 1.0)])
            if psi is not None and math.isfinite(pt):
                vals.append(pt)
        return float(np.mean(vals)) if vals else NAN

    def sum_all(self, items: list, key: str) -> float:
        """Plain sum over every task of every item (counts such as informative pairs)."""
        tot = 0.0
        for c, b in items:
            for _sd, v in self._vals(key, c, b):
                tot += float(np.nansum(v))
        return tot

    def ratio(self, items: list, num_key: str, den_key: str) -> float:
        """Per item sum(num) / sum(den) over its orders (Cw pooled over orders, Part 2.2), then the
        mean over the items (each C averaged over swaps and streams)."""
        vals = []
        for c, b in items:
            n = d = 0.0
            for _sd, v in self._vals(num_key, c, b):
                n += float(np.nansum(v))
            for _sd, v in self._vals(den_key, c, b):
                d += float(np.nansum(v))
            if d > 0:
                vals.append(n / d)
        return float(np.mean(vals)) if vals else NAN

    def cw(self, items: list, key: str) -> float:
        return self.ratio(items, f"{key}#num", f"{key}#den")

    def theta(self, items: list, key_swap: str, key_home: str, full: bool = True, fresh: bool = False,
              spread: str | None = None) -> dict:
        """theta = sum of mean V(key_swap) / sum of mean V(key_home) over the items; with full=True
        the Fieller set and the registered tests (MEASURES['inference'], msr.metrics.theta_tests: the
        home-sign test is part of every claim, the drop must also exceed the self-swap reference when
        fresh=True and every item is a swap: key_swap in the owner's home cell, its extra repeats),
        else the point only (msr.metrics.theta_from_sums). spread = the pair subset whose noise-free
        spreads S_owner, S_reader ('-|S_owner|<subset>', '-|S_reader|<subset>') give retained order and
        stakes (decision D2; order identifiable when the readers' spread on the calibration tasks has
        z >= 2, as in msr.analysis)."""
        parts = {"swap": self.comps_full([(key_swap, c, b, 1.0) for c, b in items]),
                 "home": self.comps_full([(key_home, c, b, 1.0) for c, b in items])}
        a, b_ = parts["swap"][0], parts["home"][0]
        if parts["swap"][1] is None or parts["home"][1] is None:
            return {"theta": NAN, "V_swap": a, "V_home": b_}
        if not full:
            return {"theta": measure("retained")(a, b_), "V_swap": a, "V_home": b_}
        if fresh and items and all(c[0] != c[1] for c, _ in items):
            fr = self.comps_full([(key_swap, (c[0], c[0]), b, 1.0) for c, b in items])
            if fr[1] is not None and math.isfinite(fr[0]):
                parts["fresh"] = fr
        fn = measure("inference")
        if spread is not None and _takes(fn, "s_owner"):
            so = self.comps_full([(f"-|S_owner|{spread}", c, b, 1.0) for c, b in items])
            sr = self.comps_full([(f"-|S_reader|{spread}", c, b, 1.0) for c, b in items])
            if so[1] is not None and sr[1] is not None and math.isfinite(so[0]) and math.isfinite(sr[0]):
                parts["so"], parts["sr"] = so, sr
        n = sum(len(g[1]) for g in parts.values())
        Pm = np.zeros((n, 5))
        T, I, Cp = [], [], []
        at, off = 0, 0
        for j, (name, (_pt, psi, t, it, cp)) in enumerate(parts.items()):
            Pm[at:at + len(psi), {"swap": 0, "home": 1, "fresh": 2, "so": 3, "sr": 4}[name]] = psi
            T.append(t)
            I.append(it)
            Cp.append(cp + off)
            off += int(cp.max()) + 1
            at += len(psi)
        t, it, cp = np.concatenate(T), np.vstack(I), np.concatenate(Cp)
        if _takes(fn, "comp"):
            kw = {}
            if "fresh" in parts:
                kw.update(v_fresh=parts["fresh"][0], psi_fresh=Pm[:, 2])
            if "so" in parts:
                kw.update(s_owner=parts["so"][0], s_reader=parts["sr"][0], psi_so=Pm[:, 3], psi_sr=Pm[:, 4],
                          z_reader_cal=self.reader_flag_z(items))
            return fn(a, b_, Pm[:, 0], Pm[:, 1], t, it, cp, **kw)
        return fn(a, b_, Pm[:, 0], Pm[:, 1], t, it)

    def linear(self, comps: list, full: bool = True) -> dict:
        """Point, two-way SE, 95 % interval and p-values of a linear statistic (and the task-only SE);
        full=False: the point only."""
        pt, psi, t, it, cp = self.comps_full(comps)
        out = {"est": pt, "se": NAN, "lo": NAN, "hi": NAN, "p_two": NAN, "p_upper": NAN, "se_task": NAN}
        if psi is None or not math.isfinite(pt) or not full:
            return out
        var = measure("variance")
        if _takes(var, "comp"):
            rv = var(psi, t, it, cp)
            v2, vt = rv["V"], rv["V_task"]
        else:
            v2 = var(psi, t, it)["V"]
            vt = var(psi, t, None)["V"]
        se = math.sqrt(v2) if v2 > 0 else NAN
        out["se"] = se
        out["se_task"] = math.sqrt(vt) if vt > 0 else NAN
        if math.isfinite(se):
            out["lo"], out["hi"] = pt - M.Z95 * se, pt + M.Z95 * se
            p = measure("p_values")(pt, se)
            out["p_two"], out["p_upper"] = p["p_two"], p["p_upper"]
        return out

    def reader_flag_z(self, items: list):
        """z of the readers' spread on the calibration tasks of the items (retained order's
        identifiability input, as msr.analysis.TwoWay.reader_calibration); None without calibration data."""
        if not self.rcal:
            return None
        per: dict = {}
        for cell, b in items:
            per.setdefault(cell, set()).add(b)
        vals = []
        for (o, r), bs in per.items():
            arr = [self.rcal[(o, r, b, sd)] for b in sorted(bs) for sd in self.seeds if (o, r, b, sd) in self.rcal]
            if not arr:
                return NAN
            vals.append(np.concatenate(arr))
        return measure("spread_z")(vals, [1.0] * len(vals)) if vals else NAN

    def home_flag(self, items: list, score: str) -> tuple:
        """(z, status) of the owners' home signal of `score` on their calibration tasks, by THE one rule
        msr.metrics.home_signal_flag: per owner its calibration V of every order of the streams involved,
        weighted by its number of cells among the items (as msr.analysis.TwoWay.calibration)."""
        per: dict = {}
        for cell, b in items:
            ent = per.setdefault(cell[0], {"cells": set(), "streams": set()})
            ent["cells"].add(cell)
            ent["streams"].add(b)
        vals, wts = [], []
        for o, ent in per.items():
            arr = [self.cal[(score, o, b, sd)] for b in sorted(ent["streams"]) for sd in self.seeds
                   if (score, o, b, sd) in self.cal]
            if not arr:
                return measure("home_flag")(None)          # no calibration data: z NaN, flag not defined
            vals.append(np.concatenate(arr))
            wts.append(float(len(ent["cells"])))
        if not vals:
            return measure("home_flag")(None)
        z, status = measure("home_flag")(vals, wts)
        return z, status


# ===========================================================================
# Loading the study's tables
# ===========================================================================


@dataclass
class Bank:
    """One owner bank (model, stream, order): its items with their stored answer and write-time
    grade, every family's scores (msr.evaluate.OwnerData), visits and the propensity scores."""
    model: str
    stream: str
    seed: int
    O: object                                   # msr.evaluate.OwnerData
    grade: np.ndarray                           # (N,) 1 / 0 / NaN
    answer: list
    task_id: list
    visits: np.ndarray                          # score-phase showings per item
    prop: dict                                  # propensity_scores()
    resid: dict = field(default_factory=dict)   # family -> {how: (N,)}

    @property
    def items(self) -> list:
        return self.O.items


@dataclass
class CellData:
    """One probe cell (owner, reader, stream, order) on its evaluation tasks."""
    owner: str
    reader: str
    stream: str
    seed: int
    tasks: np.ndarray
    items: np.ndarray        # (E, C) item ids ("" = none)
    cand: np.ndarray         # (E, C) index into the bank's items (-1 = none)
    rel: np.ndarray          # (E, C) relevance (0 where none)
    y_home: np.ndarray       # owner's repeats 1-2
    y_swap: np.ndarray       # reader's repeats (home cell: the extra repeats 3-4)
    y_reader: np.ndarray     # reader's regular repeats (the arms' table; home: = y_home)
    valid: np.ndarray        # (E,) the missing-cell rule (per_task 'valid')
    none: np.ndarray         # (E,) reader's no-memory success (NaN when missing)
    cal_items: np.ndarray    # level correction: item index of every calibration cell with a result
    cal_target: float        # the reader's no-memory success on the calibration tasks
    cal_cand: np.ndarray     # (Ec, C) calibration tasks' candidates (home cell: the calibration flag)
    cal_yhome: np.ndarray    # (Ec, C, R) owner's results on the calibration tasks
    cal_rel: np.ndarray
    cal_yswap: np.ndarray    # (Ec, C, R) the swap side on the calibration tasks (reader; home: extra repeats)


def _nanmean_last(a) -> np.ndarray:
    a = np.asarray(a, dtype=float)
    ok = np.isfinite(a)
    n = ok.sum(-1)
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(n > 0, np.where(ok, a, 0.0).sum(-1) / np.where(n > 0, n, 1), NAN)


def load_bank(st, model: str, stream: str, seed: int) -> Bank:
    from msr import evaluate as EV
    from msr.build import load_items, read_jsonl
    O = EV.OwnerData(st, model, stream, seed, None)
    its = load_items(st, model, stream, seed)
    grade = np.array([float(bool(its[i]["correct"])) if i in its and its[i].get("correct") is not None else NAN
                      for i in O.items])
    answer = [its[i].get("answer") if i in its else None for i in O.items]
    task_id = [its[i].get("task_id") if i in its else None for i in O.items]
    path = st.bank_dir(model, stream, seed) / "episodes.jsonl"
    eps = read_jsonl(path) if path.exists() else []
    prop = propensity_scores(eps, O.index, len(O.items))
    B = Bank(model, stream, seed, O, grade, answer, task_id, np.asarray(O.visits, dtype=float), prop)
    for f, F in O.fams.items():
        B.resid[f] = {how: residualise(F.x, grade, how) for how in RESIDUALS}
    return B


def load_cell(st, owner: str, reader: str, stream: str, seed: int, B: Bank) -> CellData | None:
    from msr import evaluate as EV
    p = EV.cells_path(st, owner, reader, stream, seed)
    if not p.exists():
        return None
    with np.load(p, allow_pickle=False) as z:
        Z = {k: z[k] for k in z.files}
    with np.load(EV.per_task_path(st, owner, reader, stream, seed), allow_pickle=False) as z:
        pt = {"tasks": z["tasks"], "valid": z["valid"]}          # only these two of its many arrays
    is_cal = Z["is_calib"].astype(bool)
    ev = ~is_cal
    tasks = Z["tasks"][ev].astype(str)
    if list(pt["tasks"].astype(str)) != list(tasks):
        raise RuntimeError(f"{p.name}: evaluation tasks differ from the per-task file")
    idx = B.O.index

    def cand_of(items):
        out = np.full(items.shape, -1, dtype=np.int64)
        for (e, c), v in np.ndenumerate(items):
            if v:
                out[e, c] = idx.get(str(v), -1)
        return out

    items_all = Z["items"].astype(str)
    cand_all = cand_of(items_all)
    rel_all = np.where(cand_all >= 0, np.nan_to_num(Z["relevance"].astype(float)), 0.0)
    y_all = Z["y"].astype(float)
    yh_all = Z["y_home"].astype(float)
    if owner == reader:
        ys_all = Z["y_extra"].astype(float) if "y_extra" in Z else np.full(yh_all.shape, NAN)
    else:
        ys_all = y_all
    none_all = Z["none"].astype(float)
    rate = _nanmean_last(none_all)
    # level correction (msr.evaluate.level_target / Scorer): reader's no-memory success on the
    # calibration tasks, and the item of every calibration cell with at least one result
    cal_rates = rate[is_cal]
    cal_rates = cal_rates[np.isfinite(cal_rates)]
    target = float(np.mean(cal_rates)) if cal_rates.size else NAN
    has_res = (cand_all >= 0) & np.isfinite(y_all).any(-1)
    cal_items = cand_all[is_cal][has_res[is_cal]]
    valid = pt["valid"].astype(bool)
    return CellData(owner, reader, stream, seed, tasks, items_all[ev], cand_all[ev], rel_all[ev],
                    yh_all[ev], ys_all[ev], y_all[ev], valid, rate[ev], cal_items.astype(np.int64), target,
                    cand_all[is_cal], yh_all[is_cal], rel_all[is_cal], ys_all[is_cal])


# ===========================================================================
# The study
# ===========================================================================


class Study:
    """Everything this module reads, loaded once."""

    def __init__(self, st, printer=print):
        from msr.analysis import design_from_study
        from msr import data as D
        self.st = st
        self.design = design_from_study(st)
        self.fams = list(st.scores.families)
        self.headline = self.design.headline
        self.streams = list(st.streams)
        self.seeds = list(st.seeds)
        self.faithful = bool(st.bird_faithful)
        self.w_score = float(st.build.w_score)
        self.clip = tuple(getattr(st.evaluate, "prob_clip", (0.01, 0.99)))
        self.tasks = {s: D.task_index(s) for s in self.streams}
        self.print = printer
        self.banks: dict = {}
        for b in self.streams:
            for sd in self.seeds:
                for m in st.models:
                    self.banks[(m, b, sd)] = load_bank(st, m, b, sd)
        self.cells: dict = {}
        for b in self.streams:
            for sd in self.seeds:
                for (o, r) in self.design.cells:
                    c = load_cell(st, o, r, b, sd, self.banks[(o, b, sd)])
                    if c is not None:
                        self.cells[((o, r), b, sd)] = c
        self.present_cells = [c for c in self.design.cells if any((c, b, sd) in self.cells
                                                                  for b in self.streams for sd in self.seeds)]
        self.notes: list = []
        self.reanswer = self._reanswer()
        self.thresholds = self._neardup_thresholds()
        self.flags = self._flags()

    # ---- re-answer agreement ------------------------------------------------
    def _reanswer(self) -> dict:
        """{(owner, reader, stream, seed): (N,) 1 / 0 / NaN}: does the reader's write-phase answer to
        the item's task agree with the owner's stored answer? Needs both banks' items.jsonl with the
        answers of the SAME write tasks (store: all)."""
        from msr.build import load_items
        out, rows = {}, []
        store = getattr(self.st.build, "store", "all")
        for b in self.streams:
            for sd in self.seeds:
                for (o, r) in self.design.cells:
                    B = self.banks[(o, b, sd)]
                    if (o, r) not in self.present_cells:
                        continue
                    rit = {v["task_id"]: v for v in load_items(self.st, r, b, sd).values()}
                    agree = np.full(len(B.items), NAN)
                    for j, (t, a) in enumerate(zip(B.task_id, B.answer)):
                        rv = rit.get(t)
                        if t is None or rv is None:
                            continue
                        if o == r:
                            agree[j] = 1.0
                            continue
                        agree[j] = 1.0 if answers_agree(b, self.tasks[b][t], a, rv.get("answer"), self.faithful) else 0.0
                    out[(o, r, b, sd)] = agree
                    shared = set(B.task_id) & set(rit)
                    g = B.grade
                    ok = np.isfinite(agree)
                    with np.errstate(invalid="ignore"):
                        rows.append({"owner": o, "reader": r, "stream": b, "seed": sd, "store": store,
                                     "owner_items": len(B.items), "reader_items": len(rit),
                                     "write_tasks_shared": len(shared),
                                     "items_with_both_answers": int(ok.sum()),
                                     "agree_rate": float(np.nanmean(agree)) if ok.any() else NAN,
                                     "agree_if_stored_correct": float(np.nanmean(agree[ok & (g == 1)]))
                                     if (ok & (g == 1)).any() else NAN,
                                     "agree_if_stored_wrong": float(np.nanmean(agree[ok & (g == 0)]))
                                     if (ok & (g == 0)).any() else NAN,
                                     "reader_calls_all_items": len(B.items)})
        self.reanswer_rows = rows
        if store != "all":
            self.notes.append("build.store is not 'all': the reader's wrong write answers are not in its items.jsonl, "
                              "so re-answer agreement is missing for them (read the write calls from calls.jsonl)")
        return out

    # ---- near duplicates ------------------------------------------------------
    def _neardup_thresholds(self) -> dict:
        """Per stream: the near-duplicate threshold and the distribution behind it."""
        from msr import retrieval as R
        out, rows = {}, []
        for b in self.streams:
            T = self.tasks[b]
            emb = None
            try:
                from msr.embed import embed_stream
                emb = embed_stream(b, model=self.st.embedding_model)
            except Exception as exc:              # pragma: no cover - only without the embedding model
                self.notes.append(f"{b}: embeddings not available ({exc}); the threshold uses the stored "
                                  "candidate relevance only")
            sims, null, same = [], [], []
            for sd in self.seeds:
                w = self.st.write_ids(b, sd)
                p = list(self.st.splits(b, sd)["probe"])
                if emb is not None:
                    Wm = np.stack([emb[t] for t in w])
                    rel = np.stack([R.relevance(emb[t], Wm) for t in p])
                    key_p = np.array([str(case_key(b, T[t])) for t in p])
                    key_w = np.array([str(case_key(b, T[t])) for t in w])
                    sk = key_p[:, None] == key_w[None, :]
                    sims.append(rel.ravel())
                    null.append(~sk.ravel())
                    same.append(sk.ravel())
                else:
                    for (cell, bb, s2), c in self.cells.items():
                        if bb != b or s2 != sd or cell[0] != cell[1]:
                            continue
                        B = self.banks[(cell[0], b, sd)]
                        for (e, j), ci in np.ndenumerate(c.cand):
                            if ci < 0:
                                continue
                            k1 = str(case_key(b, T[c.tasks[e]]))
                            k2 = str(case_key(b, T[B.task_id[ci]]))
                            sims.append(np.array([c.rel[e, j]]))
                            null.append(np.array([k1 != k2]))
                            same.append(np.array([k1 == k2]))
            sims = np.concatenate(sims) if sims else np.zeros(0)
            null = np.concatenate(null) if null else np.zeros(0, bool)
            same = np.concatenate(same) if same else np.zeros(0, bool)
            thr = neardup_threshold(sims, null, NEAR_DUP_Q)
            out[b] = thr
            cand_rel = np.concatenate([c.rel[c.cand >= 0] for (cell, bb, _), c in self.cells.items() if bb == b]) \
                if self.cells else np.zeros(0)
            q = (0.5, 0.9, 0.99, 0.999, 1.0)
            row = {"stream": b, "source": "all probe x write task pairs (embeddings)" if emb is not None
                   else "probe candidates only (stored relevance)",
                   "pairs": int(sims.size), "null_pairs": int(null.sum()), "same_case_pairs": int(same.sum()),
                   "null_definition": "different pathology" if b == "ddxplus" else "different database",
                   "quantile": NEAR_DUP_Q, "threshold": thr}
            for qq in q:
                row[f"null_q{qq:g}"] = float(np.quantile(sims[null], qq)) if null.any() else NAN
                row[f"same_case_q{qq:g}"] = float(np.quantile(sims[same], qq)) if same.any() else NAN
                row[f"candidates_q{qq:g}"] = float(np.quantile(cand_rel, qq)) if cand_rel.size else NAN
            for qs in NEAR_DUP_SENS:
                row[f"threshold_q{qs:g}"] = neardup_threshold(sims, null, qs)
            row["candidates_above"] = float(np.mean(cand_rel > thr)) if cand_rel.size else NAN
            row["same_case_above"] = float(np.mean(sims[same] > thr)) if same.any() else NAN
            row["null_above"] = float(np.mean(sims[null] > thr)) if null.any() else NAN
            rows.append(row)
        self.threshold_rows = rows
        return out

    # ---- answer match and near-duplicate flags per owner bank -----------------
    def _flags(self) -> dict:
        """{(owner, stream, seed): {"match", "neardup", "either"}: (E, C) bool} on the evaluation
        tasks (the same for every reader of the owner)."""
        out = {}
        for (cell, b, sd), c in self.cells.items():
            o = cell[0]
            if (o, b, sd) in out:
                continue
            B = self.banks[(o, b, sd)]
            T = self.tasks[b]
            match = np.zeros(c.cand.shape, dtype=bool)
            for (e, j), ci in np.ndenumerate(c.cand):
                if ci < 0:
                    continue
                it = B.task_id[ci]
                match[e, j] = answer_match(b, T[str(c.tasks[e])], B.answer[ci], T.get(it), self.faithful)
            near = (c.cand >= 0) & (c.rel > self.thresholds.get(b, math.inf))
            out[(o, b, sd)] = {"match": match, "neardup": near, "either": match | near}
        return out

    def auc(self, owner: str, stream: str, seed: int, family: str) -> float:
        """correctness_auc of a family's score over the owner's bank, computed once."""
        key = (owner, stream, seed, family)
        if not hasattr(self, "_auc"):
            self._auc = {}
        if key not in self._auc:
            B = self.banks[(owner, stream, seed)]
            self._auc[key] = correctness_auc(B.O.fams[family].x, B.grade)
        return self._auc[key]

    # ---- per-cell score arrays --------------------------------------------------
    def scores(self, c: CellData) -> dict:
        """{score: (E, C) x} for every score type of the cell's owner bank (and reader)."""
        B = self.banks[(c.owner, c.stream, c.seed)]
        has = c.cand >= 0
        cj = np.maximum(c.cand, 0)

        def per_item(v):
            return np.where(has, np.asarray(v, dtype=float)[cj], NAN)

        out = {f: per_item(F.x) for f, F in B.O.fams.items()}
        g = per_item(B.grade)
        out["correct"] = g
        out["correct_rel"] = g + REL_TIE * np.where(has, c.rel, 0.0)
        out["relevance"] = np.where(has, c.rel, NAN)
        out["reanswer"] = per_item(self.reanswer.get((c.owner, c.reader, c.stream, c.seed), np.full(len(B.items), NAN)))
        out["ips"] = per_item(B.prop["snips"])
        out["dr"] = per_item(B.prop["dr"])
        return out


# ===========================================================================
# Filling the pool
# ===========================================================================


def fill(S: Study) -> Pool:
    """Every per-task value the tables need."""
    P = Pool(S.streams, S.seeds)
    learned = list(S.fams)
    for (cell, b, sd), c in sorted(S.cells.items(), key=lambda kv: (kv[0][1], kv[0][2], kv[0][0])):
        B = S.banks[(c.owner, b, sd)]
        P.set_codes(c.owner, b, sd, c.tasks, c.items)
        Th = table(c.cand, c.rel, c.y_home, c.valid)
        Ts = table(c.cand, c.rel, c.y_swap, c.valid)
        has = c.cand >= 0
        cj = np.maximum(c.cand, 0)
        grade = np.where(has, B.grade[cj], NAN)
        visits = np.where(has, B.visits[cj], NAN)
        fl = S.flags[(c.owner, b, sd)]
        fill_spreads(S, P, cell, b, sd, c, grade, visits, fl)
        X_ = S.scores(c)
        for sname, x in X_.items():
            for side, T in (("home", Th), ("swap", Ts)):
                gs = grade_split(T, x, grade)
                for sub, parts in gs.items():
                    P.put_parts(cell, b, sd, f"{sname}|{sub}|{side}", parts)
                for flag in FLAGS:
                    P.put_parts(cell, b, sd, f"{sname}|excl_{flag}|{side}", pair_parts(T, x, ~fl[flag]))
                if sname in learned or sname == "correct_rel":
                    for j, parts in enumerate(visit_strata(T, x, visits)):
                        P.put_parts(cell, b, sd, f"{sname}|vis{j}|{side}", parts)
                if sname in learned:
                    for how in RESIDUALS:
                        xr = np.where(has, B.resid[sname][how][cj], NAN)
                        P.put_parts(cell, b, sd, f"{sname}|res_{how}|{side}", pair_parts(T, xr, np.isfinite(grade)))
        # candidate-level descriptive values (point 3)
        yh = _nanmean_last(c.y_home)
        ysw = _nanmean_last(c.y_swap)
        okc = has & c.valid[:, None]
        for flag in ("match", "neardup"):
            f = fl[flag] & okc
            n = okc & ~fl[flag]
            P.put(cell, b, sd, f"cand|{flag}|share", np.where(c.valid, (fl[flag] & okc).sum(1) / np.maximum(okc.sum(1), 1), NAN))
            P.put(cell, b, sd, f"cand|{flag}|task_any", np.where(c.valid, (fl[flag] & okc).any(1).astype(float), NAN))
            for side, yb in (("home", yh), ("swap", ysw)):
                P.put(cell, b, sd, f"cand|{flag}|ysum_{side}", np.where(c.valid, np.nansum(np.where(f, yb, NAN), 1), NAN))
                P.put(cell, b, sd, f"cand|{flag}|n_{side}", np.where(c.valid, (f & np.isfinite(yb)).sum(1), NAN))
                P.put(cell, b, sd, f"cand|not_{flag}|ysum_{side}", np.where(c.valid, np.nansum(np.where(n, yb, NAN), 1), NAN))
                P.put(cell, b, sd, f"cand|not_{flag}|n_{side}", np.where(c.valid, (n & np.isfinite(yb)).sum(1), NAN))
        P.put(cell, b, sd, "cand|correct|share", np.where(c.valid, np.nansum(np.where(okc, grade, NAN), 1) / np.maximum(okc.sum(1), 1), NAN))
        for gv, name in ((1.0, "grade1"), (0.0, "grade0")):
            f = okc & (grade == gv)
            for side, yb in (("home", yh), ("swap", ysw)):
                P.put(cell, b, sd, f"cand|{name}|ysum_{side}", np.where(c.valid, np.nansum(np.where(f, yb, NAN), 1), NAN))
                P.put(cell, b, sd, f"cand|{name}|n_{side}", np.where(c.valid, (f & np.isfinite(yb)).sum(1), NAN))
        fill_arms(S, P, cell, b, sd, c, B)
        # the owner's calibration-task home signal of every score (the headline flag of theta)
        if c.owner == c.reader:
            pres = c.cal_cand >= 0
            cj2 = np.maximum(c.cal_cand, 0)
            yb = _nanmean_last(c.cal_yhome)
            xs = {f: np.where(pres, F.x[cj2], NAN) for f, F in B.O.fams.items()}
            g2 = np.where(pres, B.grade[cj2], NAN)
            xs["correct"] = g2
            xs["correct_rel"] = g2 + REL_TIE * c.cal_rel
            xs["relevance"] = np.where(pres, c.cal_rel, NAN)
            xs["ips"] = np.where(pres, B.prop["snips"][cj2], NAN)
            xs["dr"] = np.where(pres, B.prop["dr"][cj2], NAN)
            for f in learned:
                for how in RESIDUALS:
                    xs[f"{f}|res_{how}"] = np.where(pres, B.resid[f][how][cj2], NAN)
            for name, x in xs.items():
                P.cal[(name, c.owner, b, sd)] = measure("cal_validity")(x, yb, pres & np.isfinite(x))[0]
    return P


def fill_spreads(S: Study, P: Pool, cell, b, sd, c: CellData, grade, visits, fl) -> None:
    """The noise-free item spreads behind retained order and stakes (decision D2), per pair subset:
    S_owner = the owner's home repeats 1-2 (mean) x its later-session repeats 3-4 (mean), from the owner's
    home cell; S_reader = a swap cell's reader repeat 1 x repeat 2 (home cell: extra repeat 3 x 4)
    (msr.metrics.cross_repeat_parts, as msr.analysis.inject_spread_keys). S is a sum over pairs, so the
    subsets split exactly like V. Score-free: one set per cell serves every score type. Also the reader's
    spread on the calibration tasks (order's identifiability flag)."""
    home = S.cells.get(((c.owner, c.owner), b, sd))
    has = c.cand >= 0
    sp = measure("spread")

    def parts(mask):
        out = {}
        if home is not None:
            out["S_owner"] = sp(home.y_home, home.y_swap, has & mask)
        y = c.y_swap
        if y.ndim == 3 and y.shape[2] >= 2:
            out["S_reader"] = sp(y[..., 0], y[..., 1], has & mask)
        return out

    def put(sub, d):
        for k, v in d.items():
            P.put(cell, b, sd, f"-|{k}|{sub}", np.where(c.valid, v, NAN))

    allm = np.ones(has.shape, dtype=bool)
    base = parts(allm)
    put("all", base)
    g = np.asarray(grade, dtype=float)
    cc, ii = parts(np.isfinite(g) & (g == 1)), parts(np.isfinite(g) & (g == 0))
    known = parts(np.isfinite(g))
    put("cc", cc)
    put("ii", ii)
    put("mixed", {k: known[k] - cc[k] - ii[k] for k in known})
    for flag in FLAGS:
        put(f"excl_{flag}", parts(~fl[flag]))
    v = np.asarray(visits, dtype=float)
    ge = [parts(np.isfinite(v) & (v >= lo)) for lo, _hi in VISIT_BINS]
    for j in range(len(VISIT_BINS)):
        put(f"vis{j}", ge[j] if j == len(VISIT_BINS) - 1 else {k: ge[j][k] - ge[j + 1][k] for k in ge[j]})
    y = c.cal_yswap
    if y.ndim == 3 and y.shape[2] >= 2 and len(y):
        P.rcal[(c.owner, c.reader, b, sd)] = sp(y[..., 0], y[..., 1], c.cal_cand >= 0)


def fill_arms(S: Study, P: Pool, cell, b, sd, c: CellData, B: Bank) -> None:
    """First-shown success, regret and (where a probability exists) log and Brier scores, raw and
    level-corrected, of every rule on the reader's table: exactly msr.evaluate's arms (engine
    functions, the build's score weight, the same level correction)."""
    Tr = table(c.cand, c.rel, c.y_reader, c.valid)
    N = len(B.items)
    rules = {}
    for f, F in B.O.fams.items():
        rules[f"keep:{f}"] = (X.u_of(F.kind, F.A), X.p_of(F.kind, F.A, F.r0))
    H = B.O.fams[S.headline]
    wst = H.start()
    rules[f"wipe:{S.headline}"] = (X.u_of(H.kind, wst), X.p_of(H.kind, wst, H.r0))
    g = np.nan_to_num(B.grade, nan=0.0)
    rules["correct"] = (g, None)
    ag = S.reanswer.get((c.owner, c.reader, b, sd))
    if ag is not None:
        rules["reanswer"] = (np.nan_to_num(ag, nan=0.0), None)
    rules["ips"] = (np.clip(B.prop["snips"], 0.0, 1.0), B.prop["snips"])
    rules["dr"] = (np.clip(B.prop["dr"], 0.0, 1.0), B.prop["dr"])
    cal_items = c.cal_items if len(c.cal_items) else None

    def put(rule, metric, v):
        P.put(cell, b, sd, f"arm|{rule}|{metric}", v)

    for rule, (u, p) in rules.items():
        fs, reg = X.first_shown(Tr, np.asarray(u, dtype=float), S.w_score)
        put(rule, "value", fs)
        put(rule, "regret", reg)
        if p is not None:
            p = np.asarray(p, dtype=float)
            lg, br = X.log_brier(Tr, p, S.clip)
            put(rule, "log", lg)
            put(rule, "brier", br)
            if cal_items is not None and math.isfinite(c.cal_target):
                delta = measure("level_shift")(p[..., cal_items], c.cal_target, S.clip)
                pl = measure("shift_probs")(p, delta, S.clip)
                lgl, brl = X.log_brier(Tr, pl, S.clip)
                put(rule, "log_lc", lgl)
                put(rule, "brier_lc", brl)
    rp, rr = X.first_shown(Tr, np.full(N, 0.5), 0.0)
    put("relevance", "value", rp)
    put("relevance", "regret", rr)
    none = np.where(Tr.ok & np.isfinite(c.none), c.none, NAN)
    put("none", "value", none)
    put("none", "regret", Tr.best - none)


# ===========================================================================
# Tables
# ===========================================================================


def scopes(S: Study) -> list:
    """(scope, owner, reader, group, cells) for every cell row and every group row."""
    d = S.design
    out = []
    for g in GROUPS:
        cells = [c for c in d.swaps(g) if c in S.present_cells]
        if cells:
            out.append(("group", "", "", g, cells))
    for c in d.swaps("home") + d.swaps("all_swaps"):
        if c in S.present_cells:
            out.append(("cell", c[0], c[1], d.group(*c), [c]))
    return out


def _base(scope, o, r, g, level, cells) -> dict:
    return {"scope": scope, "owner": o, "reader": r, "group": g, "level": level, "n_swaps": len(cells)}


#: the three measures of decision D2 beside theta (msr.metrics.theta_tests / order_stakes_inference)
ORDER_KEYS = ("order", "order_lo", "order_hi", "order_status", "stakes", "stakes_lo", "stakes_hi")


def _theta_cols(th: dict, prefix: str = "theta", full: bool = True) -> dict:
    """theta (retained value) and, with full=True, its Fieller set, and retained order and stakes when
    the spreads were given (order is 'not identifiable' when the readers' spread flag fails)."""
    out = {prefix: th.get("theta", NAN)}
    if full:
        out.update({f"{prefix}_lo": th.get("lo", NAN), f"{prefix}_hi": th.get("hi", NAN),
                    f"{prefix}_interval": th.get("interval", "")})
        if "order_status" in th:
            stem = prefix.replace("theta", "", 1)
            for k in ORDER_KEYS:
                out[f"{k}{stem}"] = th.get(k, NAN if not k.endswith("_status") else "")
    return out


def reference_rows(S: Study, P: Pool) -> list:
    """Point 1: every score type (learned families, the stored-answer-correct reference with and
    without relevance tie-breaks, relevance alone, and the static baselines): Cw and V at home and
    after the swap, theta with its two-way Fieller interval and tests, the calibration flag."""
    rows = []
    kinds = {**{f: "learned" for f in S.fams}, **{r: "reference" for r in REFERENCES},
             **{r: "baseline score" for r in STATIC_BASELINES}}
    for score, kind in kinds.items():
        for scope, o, r, g, cells in scopes(S):
            for level in P.levels():
                its = P.items(cells, level)
                kh, ks = f"{score}|all|home", f"{score}|all|swap"
                th = P.theta(its, f"{ks}#V", f"{kh}#V", fresh=True, spread="all")
                if not math.isfinite(th.get("V_home", NAN)) and not math.isfinite(th.get("V_swap", NAN)):
                    continue
                z, flag = P.home_flag(its, score)          # THE one rule: msr.metrics.home_signal_flag
                row = {"score": score, "score_kind": kind, **_base(scope, o, r, g, level, cells),
                       "C_home": P.cw(its, kh), "C_swap": P.cw(its, ks),
                       "V_home": th.get("V_home", NAN), "V_swap": th.get("V_swap", NAN),
                       "se_V_home": th.get("se_V_home", NAN), **_theta_cols(th),
                       "p_home": th.get("p_home", NAN), "p_drop": th.get("p_drop", NAN),
                       "p_material_drop": th.get("p_md", NAN), "p_ni": th.get("p_ni", NAN),
                       "pairs_home": P.sum_all(its, f"{kh}#den_u"), "pairs_swap": P.sum_all(its, f"{ks}#den_u"),
                       "z_cal": z, "home_flag": flag}
                rows.append(row)
    return rows


def correctness_rows(S: Study, P: Pool) -> list:
    """Point 2: how much of each score's signal is the stored-answer grade."""
    rows = []
    scores_ = list(S.fams) + ["correct", "relevance"]
    for score in scores_:
        for scope, o, r, g, cells in scopes(S):
            full = scope == "group"
            for level in P.levels():
                its = P.items(cells, level)
                row = {"score": score, **_base(scope, o, r, g, level, cells)}
                ok = False
                for side in ("home", "swap"):
                    for sub in ("all", "cc", "ii", "mixed"):
                        k = f"{score}|{sub}|{side}"
                        row[f"V_{side}_{sub}"] = P.total(its, f"{k}#V")
                        row[f"W_{side}_{sub}"] = P.total(its, f"{k}#den")
                        row[f"pairs_{side}_{sub}"] = P.sum_all(its, f"{k}#den_u")
                    va, vm = row[f"V_{side}_all"], row[f"V_{side}_mixed"]
                    wa, wm = row[f"W_{side}_all"], row[f"W_{side}_mixed"]
                    ok = ok or math.isfinite(va)
                    sh = vm / va if va else NAN
                    wsh = wm / wa if wa else NAN
                    row[f"share_mixed_{side}"] = sh
                    row[f"weight_share_mixed_{side}"] = wsh
                    row[f"excess_mixed_{side}"] = (sh - wsh) / (1.0 - wsh) if math.isfinite(sh) and math.isfinite(wsh) \
                        and wsh < 1 else NAN
                if not ok:
                    continue
                row["z_cal"], row["home_flag"] = P.home_flag(its, score)
                learned = score in S.fams
                # intervals (two-way Fieller) for the learned families' group rows; points elsewhere;
                # theta over all pairs carries its interval in construct_reference.csv
                for sub in ("cc", "ii", "mixed", "same"):
                    fi = full and learned and sub != "same"
                    th = P.theta(its, f"{score}|{sub}|swap#V", f"{score}|{sub}|home#V", fi, fresh=True,
                                 spread=sub if sub != "same" else None)
                    row.update(_theta_cols(th, f"theta_{sub}", fi))
                th = P.theta(its, f"{score}|all|swap#V", f"{score}|all|home#V", False)
                row.update(_theta_cols(th, "theta_all", False))
                if learned:
                    for how in RESIDUALS:
                        fi = full and how == "ols"
                        kh, ks = f"{score}|res_{how}|home", f"{score}|res_{how}|swap"
                        row[f"V_home_res_{how}"] = P.total(its, f"{kh}#V")
                        row[f"V_swap_res_{how}"] = P.total(its, f"{ks}#V")
                        row[f"C_home_res_{how}"] = P.cw(its, kh)
                        row[f"C_swap_res_{how}"] = P.cw(its, ks)
                        # does the residualised score still rank items at home? THE one home-signal rule
                        row[f"z_cal_res_{how}"], row[f"home_flag_res_{how}"] = P.home_flag(its, f"{score}|res_{how}")
                        th = P.theta(its, f"{ks}#V", f"{kh}#V", fi, fresh=True, spread="all")
                        row.update(_theta_cols(th, f"theta_res_{how}", fi))
                        for side in ("home", "swap"):
                            # share of V carried by the grade = 1 - V_resid / V (a ratio on the same
                            # tasks: Fieller interval of V_resid / V from theta_inference)
                            sh = P.theta(its, f"{score}|res_{how}|{side}#V", f"{score}|all|{side}#V", fi)
                            row[f"correct_share_{side}_{how}"] = 1.0 - sh["theta"] if math.isfinite(sh.get("theta", NAN)) else NAN
                            if fi:
                                lo, hi = sh.get("lo", NAN), sh.get("hi", NAN)
                                row[f"correct_share_{side}_{how}_lo"] = 1.0 - hi if math.isfinite(hi) else (-math.inf if hi == math.inf else NAN)
                                row[f"correct_share_{side}_{how}_hi"] = 1.0 - lo if math.isfinite(lo) else (math.inf if lo == -math.inf else NAN)
                    aucs =[S.auc(c[0], b, sd, score) for c, b in its for sd in S.seeds if (c[0], b, sd) in S.banks]
                    row["auc_score_vs_grade"] = float(np.nanmean(aucs)) if aucs else NAN
                rows.append(row)
    return rows


def overlap_rows(S: Study, P: Pool) -> list:
    """Point 3: shares of informative pairs with an answer-matching or near-duplicate candidate, and
    Cw and theta with those pairs excluded; plus candidate-level descriptives."""
    rows = []
    for score in list(S.fams) + ["correct", "correct_rel"]:
        for scope, o, r, g, cells in scopes(S):
            full = scope == "group"
            for level in P.levels():
                its = P.items(cells, level)
                pa_h = P.sum_all(its, f"{score}|all|home#den_u")
                pa_s = P.sum_all(its, f"{score}|all|swap#den_u")
                if not (pa_h or pa_s):
                    continue
                row = {"score": score, **_base(scope, o, r, g, level, cells), "pairs_home": pa_h, "pairs_swap": pa_s,
                       "C_home": P.cw(its, f"{score}|all|home"), "C_swap": P.cw(its, f"{score}|all|swap")}
                row.update(_theta_cols(P.theta(its, f"{score}|all|swap#V", f"{score}|all|home#V", full, fresh=True, spread="all"), "theta", full))
                for flag in FLAGS:
                    kh, ks = f"{score}|excl_{flag}|home", f"{score}|excl_{flag}|swap"
                    eh, es = P.sum_all(its, f"{kh}#den_u"), P.sum_all(its, f"{ks}#den_u")
                    row[f"share_pairs_{flag}_home"] = 1.0 - eh / pa_h if pa_h else NAN
                    row[f"share_pairs_{flag}_swap"] = 1.0 - es / pa_s if pa_s else NAN
                    row[f"C_home_excl_{flag}"] = P.cw(its, kh)
                    row[f"C_swap_excl_{flag}"] = P.cw(its, ks)
                    th = P.theta(its, f"{ks}#V", f"{kh}#V", full, fresh=True, spread=f"excl_{flag}")
                    row[f"V_home_excl_{flag}"] = th.get("V_home", NAN)
                    row[f"V_swap_excl_{flag}"] = th.get("V_swap", NAN)
                    row.update(_theta_cols(th, f"theta_excl_{flag}", full))
                rows.append(row)
    return rows


def candidate_rows(S: Study, P: Pool) -> list:
    """Point 3, descriptive: how often candidates match / are near duplicates, and how the owner and
    the reader do with them."""
    rows = []
    for scope, o, r, g, cells in scopes(S):
        for level in P.levels():
            its = P.items(cells, level)
            row = {**_base(scope, o, r, g, level, cells), "stored_correct_share": P.mean(its, "cand|correct|share")}
            for side in ("home", "swap"):
                for name, lab in (("grade1", "stored_correct"), ("grade0", "stored_wrong")):
                    n = P.sum_all(its, f"cand|{name}|n_{side}")
                    row[f"success_{side}_{lab}"] = P.sum_all(its, f"cand|{name}|ysum_{side}") / n if n else NAN
            for flag in ("match", "neardup"):
                row[f"cand_share_{flag}"] = P.mean(its, f"cand|{flag}|share")
                row[f"tasks_with_{flag}"] = P.mean(its, f"cand|{flag}|task_any")
                for side in ("home", "swap"):
                    for which in (flag, f"not_{flag}"):
                        n = P.sum_all(its, f"cand|{which}|n_{side}")
                        s = P.sum_all(its, f"cand|{which}|ysum_{side}")
                        row[f"success_{side}_{which}"] = s / n if n else NAN
            rows.append(row)
    return rows


def visits_bank_rows(S: Study) -> list:
    """Point 3: showings per item in the score phase, per bank, and among the evaluation candidates."""
    rows = []
    for (m, b, sd), B in sorted(S.banks.items()):
        v = B.visits
        row = {"model": m, "stream": b, "seed": sd, "items": len(v), "mean": float(v.mean()) if len(v) else NAN,
               "median": float(np.median(v)) if len(v) else NAN, "max": float(v.max()) if len(v) else NAN,
               "shows_total": float(v.sum()), "propensity_min": B.prop["min_pi"], "propensity_clipped": B.prop["clipped"]}
        bins = visit_bin_of(v)
        for j, lab in enumerate(VISIT_LABELS):
            row[f"items_{lab}"] = int((bins == j).sum())
            row[f"share_{lab}"] = float((bins == j).mean()) if len(v) else NAN
        # the same over the candidates of the evaluation tasks (home cell of this bank)
        c = S.cells.get(((m, m), b, sd))
        if c is not None:
            cv = np.where(c.cand >= 0, v[np.maximum(c.cand, 0)], NAN)[c.valid]
            cv = cv[np.isfinite(cv)]
            cb = visit_bin_of(cv)
            for j, lab in enumerate(VISIT_LABELS):
                row[f"cand_share_{lab}"] = float((cb == j).mean()) if cv.size else NAN
        row["stored_correct_share"] = float(np.nanmean(B.grade)) if len(v) else NAN
        for f in B.O.fams:
            row[f"auc_{f}_vs_grade"] = S.auc(m, b, sd, f)
        row["auc_ips_vs_grade"] = correctness_auc(B.prop["snips"], B.grade)
        row["auc_dr_vs_grade"] = correctness_auc(B.prop["dr"], B.grade)
        row["auc_visits_vs_grade"] = correctness_auc(v, B.grade)
        rows.append(row)
    return rows


def visits_theta_rows(S: Study, P: Pool) -> list:
    """Point 3: theta and Cw by visit stratum (the pair's less-visited candidate)."""
    rows = []
    for score in list(S.fams):
        for scope, o, r, g, cells in scopes(S):
            full = scope == "group"
            for level in P.levels():
                its = P.items(cells, level)
                for j, lab in enumerate(VISIT_LABELS):
                    kh, ks = f"{score}|vis{j}|home", f"{score}|vis{j}|swap"
                    ph, ps = P.sum_all(its, f"{kh}#den_u"), P.sum_all(its, f"{ks}#den_u")
                    if not (ph or ps):
                        continue
                    th = P.theta(its, f"{ks}#V", f"{kh}#V", full, fresh=True, spread=f"vis{j}")
                    row = {"score": score, **_base(scope, o, r, g, level, cells), "stratum": lab,
                           "pairs_home": ph, "pairs_swap": ps, "C_home": P.cw(its, kh), "C_swap": P.cw(its, ks),
                           "V_home": th.get("V_home", NAN), "V_swap": th.get("V_swap", NAN)}
                    row.update(_theta_cols(th, "theta", full))
                    rows.append(row)
    return rows


def arm_rules(S: Study) -> list:
    return (["none", "relevance"] + [f"keep:{f}" for f in S.fams] + [f"wipe:{S.headline}", "correct",
                                                                     "reanswer", "ips", "dr"])


def baseline_rows(S: Study, P: Pool) -> list:
    """Point 4: every rule scored like the paper's arms, beside keep and wipe of the headline family,
    with two-way intervals of the differences (group rows; cell rows give points). `keep_nolevel` is
    keep's raw log score: no reader call at all."""
    rows = []
    keep, wipe = f"keep:{S.headline}", f"wipe:{S.headline}"
    metrics_ = ("value", "regret", "log", "brier", "log_lc", "brier_lc")

    def diff(its, a, b, metric, full):
        n = len(its)
        return P.linear([(f"arm|{a}|{metric}", c, s, 1.0 / n) for c, s in its]
                        + [(f"arm|{b}|{metric}", c, s, -1.0 / n) for c, s in its], full)

    for rule in arm_rules(S) + ["keep_nolevel"]:
        src = keep if rule == "keep_nolevel" else rule
        for scope, o, r, g, cells in scopes(S):
            full = scope == "group"
            for level in P.levels():
                its = P.items(cells, level)
                row = {"rule": rule, **_base(scope, o, r, g, level, cells)}
                for m in metrics_:
                    if rule == "keep_nolevel" and m in ("log_lc", "brier_lc"):
                        row[m] = NAN
                        continue
                    row[m] = P.mean(its, f"arm|{src}|{m}")
                if not math.isfinite(row["value"]):
                    continue
                for ref_name, ref in (("keep", keep), ("wipe", wipe)):
                    if src == ref:
                        continue
                    lin = diff(its, src, ref, "value", full)
                    row[f"value_minus_{ref_name}"] = lin["est"]
                    if full:
                        row[f"value_minus_{ref_name}_lo"] = lin["lo"]
                        row[f"value_minus_{ref_name}_hi"] = lin["hi"]
                        row[f"value_minus_{ref_name}_p"] = lin["p_two"]
                if math.isfinite(row.get("log", NAN)) and src != keep:
                    for m in ("log", "log_lc"):
                        if not math.isfinite(row.get(m, NAN)):
                            continue
                        lin = diff(its, src, keep, m, full)
                        row[f"{m}_minus_keep"] = lin["est"]
                        if full:
                            row[f"{m}_minus_keep_lo"], row[f"{m}_minus_keep_hi"] = lin["lo"], lin["hi"]
                if rule == "keep_nolevel":
                    # what keep loses on the log score when it does not pay for the level information
                    lin = P.linear([(f"arm|{keep}|log", c, s, 1.0 / len(its)) for c, s in its]
                                   + [(f"arm|{keep}|log_lc", c, s, -1.0 / len(its)) for c, s in its], full)
                    row["log_minus_keep_lc"] = lin["est"]
                    if full:
                        row["log_minus_keep_lc_lo"], row["log_minus_keep_lc_hi"] = lin["lo"], lin["hi"]
                rows.append(row)
    return rows


# ===========================================================================
# Point 5: one cost table that charges every rule for everything it uses
# ===========================================================================


def sizes_of(st) -> dict:
    """The design sizes that decide the calls of one swap day (one owner bank, one reader, one
    stream, one order)."""
    z = st.sizes
    n_probe = int(z.n_probe)
    calib = int(st.evaluate.calib_tasks)
    return {"n_write": int(st.build.n_write), "n_score": int(st.n_score), "epochs": int(st.build.epochs),
            "n_show": int(st.build.n_show), "self_tag": bool(st.build.self_tag),
            "no_memory_run": bool(st.build.no_memory_run), "n_probe": n_probe, "calib": calib,
            "n_eval": n_probe - calib, "K": int(st.probe.candidates), "R": int(st.probe.repeats),
            "Rz": int(st.probe.no_memory_repeats), "k_values": list(st.evaluate.k_values),
            "store": str(st.build.store), "n_streams": len(st.streams), "n_seeds": len(st.seeds),
            "n_models": len(st.models),
            "n_second": sum(1 for m in st.models if m in st.build.second_bank_models)}


def _distinct_tasks(k: int, tasks: int, K: int) -> float:
    """Expected distinct calibration tasks among k cells drawn without replacement from tasks x K."""
    n = tasks * K
    if k <= 0 or n <= 0:
        return 0.0
    k = min(k, n)
    return tasks * (1.0 - math.comb(n - K, k) / math.comb(n, k)) if n - K >= k else float(tasks)


def keep_or_drop_inputs(analysis_dir: Path) -> dict:
    """The measured inputs of the registered keep-or-drop rows, read from the same files as
    paper/assets/table_cost_one.tex (scripts/make_paper_assets.write_table_cost_one): the break-even
    (margin-0) tests' median checks at theta = 1 (sequential_margin0.csv, world 'study', part 'needed')
    and the paired test's median stopping time at theta = 1 (sequential_curve.csv, tasks_q50)."""
    def rd(name):
        p = Path(analysis_dir) / name
        if not p.exists():
            return []
        with open(p, encoding="utf-8") as f:
            return list(csv.DictReader(f))

    def num(v):
        try:
            return float(v)
        except (TypeError, ValueError):
            return NAN

    out = {}
    for version in ("ranking", "first_shown"):
        r = next((x for x in rd("sequential_margin0.csv") if x.get("world") == "study" and x.get("version") == version
                  and x.get("part") == "needed" and math.isfinite(num(x.get("theta")))
                  and abs(num(x["theta"]) - 1.0) < 1e-9), None)
        if r is not None and math.isfinite(num(r.get("checks_median"))):
            out[f"margin0_{version}_checks"] = num(r["checks_median"])
    c = next((x for x in rd("sequential_curve.csv") if math.isfinite(num(x.get("theta")))
              and abs(num(x["theta"]) - 1.0) < 1e-9), None)
    if c is not None and math.isfinite(num(c.get("tasks_q50"))):
        out["paired_median_tasks"] = num(c["tasks_q50"])
    return out


def cost_rules(z: dict, measured: dict | None = None, registered: bool = False) -> list:
    """One row per rule: calls of one swap day (one owner bank, one reader, one stream, one order) by who
    makes them and when, for sizes z. The level information (the reader's no-memory runs of the calibration
    tasks behind every level-corrected log / Brier score, PC3 and PC4) is ONE shared row, bought once per
    swap day and not added to each rule (pre-registration Part 6.4); `uses_level_information` marks the
    rules that read it. The keep-or-drop tests and the forecast come from msr.sequential.swap_day_calls and
    msr.forecast.forecast_calls (the functions the one cost table, paper/assets/table_cost_one.tex, reads),
    for the registered study's sizes only (registered=True), with the measured inputs of
    keep_or_drop_inputs(). measured: {"reanswer_lazy": distinct candidate items per bank} (practice)."""
    from msr import forecast as FC
    from msr import sequential as SQ
    measured = measured or {}
    lvl = z["calib"] * z["Rz"]
    own_build = z["n_write"] + (z["n_score"] if z["no_memory_run"] else 0) + z["epochs"] * z["n_score"] \
        + (z["epochs"] * z["n_score"] * z["n_show"] if z["self_tag"] else 0)
    pool = z["calib"] * z["K"]
    rows = []

    def add(rule, kind, uses, pre_owner=0.0, checks=0.0, level=0.0, other=0.0, free="", note="", fits=True,
            uses_level=False):
        nan = not fits
        rows.append({"rule": rule, "kind": kind, "uses": uses, "uses_level_information": "yes" if uses_level else "no",
                     "pre_swap_owner_calls": NAN if nan else pre_owner, "swap_day_reader_checks": NAN if nan else checks,
                     "swap_day_reader_level": NAN if nan else level, "swap_day_reader_other": NAN if nan else other,
                     "total_calls": NAN if nan else pre_owner + checks + other, "free_information": free, "note": note})

    add("level_information", "shared row (Part 6.4)", "the reader's no-memory runs of the calibration tasks",
        level=lvl, note="bought once per swap day by any rule read on the level-corrected log or Brier score (PC3, "
        "PC4); first-shown success (PC2) needs none; not added to the rules' totals")
    add("none", "reference", "nothing (no item shown)")
    add("relevance", "reference", "retrieval relevance", free="relevance")
    for rule in ("keep", "wipe", "shuffled"):
        add(rule, "paper rule", "the owner's scores" if rule != "wipe" else "the start value",
            free="owner's bank (scores)", uses_level=True)
    add("fixed_lambda", "paper rule", "the owner's scores times lambda", free="owner's bank", uses_level=True)
    add("constant", "reference", "the level information only", uses_level=True,
        note="its whole prediction IS the level information")
    for k in z["k_values"]:
        fits = k <= pool
        dt = _distinct_tasks(k, z["calib"], z["K"])
        for arm in ("powerprior", "powerprior_flat", "recal", "audit", "retest", "pooled", "fresh"):
            note = ""
            if arm in ("retest", "pooled", "fresh"):
                note = (f"the credit family also folds in the reader's no-memory result of each checked task "
                        f"(about {dt * z['Rz']:.0f} reader calls, a subset of the level information's calls)")
            add(f"{arm}_{k}", "paper rule", f"{k} fresh checks + the owner's scores", checks=k, free="owner's bank",
                note=note, fits=fits, uses_level=True)
    add("own", "reference", "the reader's own bank (one full build on this stream and order)", other=own_build)
    add("split_half", "reference", "the reader's full probe table on the evaluation tasks",
        other=z["n_eval"] * z["K"] * z["R"], note="not deployable")
    add("ceiling", "reference", "the reader's full probe table on the evaluation tasks",
        other=z["n_eval"] * z["K"] * z["R"], note="not deployable; the in-sample ceiling")
    add("forecast_20_checks", "pre-swap forecast baseline (App. F)", "20 fresh checks (5 tasks x 4 candidates)",
        pre_owner=5 * z["K"] * 2, checks=20,
        note="the reader's checks AND the owner's stored home results on the same 5 tasks")
    # the keep-or-drop tests and the forecast: the registered study's rows, from the functions
    reg = registered
    for version, per in (("first_shown", 2), ("ranking", z["K"])):
        chk = measured.get(f"margin0_{version}_checks", NAN)
        if reg and math.isfinite(chk):
            c = SQ.swap_day_calls(f"margin0_{version}", chk / per, K=z["K"])
            add(f"break_even_{version}", "keep-or-drop test (Sec. 5)",
                f"margin-0 test, {version.replace('_', '-')} version, median checks at theta = 1",
                pre_owner=c["old_model_calls_before_retirement"], checks=c["new_model_calls"], note=c["note"])
        else:
            add(f"break_even_{version}", "keep-or-drop test (Sec. 5)", f"margin-0 test, {version}", fits=False,
                note="registered study only (msr.sequential.swap_day_calls)")
    n_med = measured.get("paired_median_tasks", NAN)
    for rule, n_t in (("paired_store200", 200.0), ("paired_median", n_med)):
        if reg and math.isfinite(n_t):
            c = SQ.swap_day_calls("sequential", n_t, n_t, calib_tasks=z["calib"], K=z["K"])
            add(rule, "keep-or-drop test (Sec. 5)", f"paired 0.75 test, store of {n_t:,.0f} tasks",
                pre_owner=c["old_model_calls_before_retirement"], checks=c["new_model_calls"], note=c["note"])
        else:
            add(rule, "keep-or-drop test (Sec. 5)", "paired 0.75 test", fits=False,
                note="registered study only (msr.sequential.swap_day_calls)")
    if reg:
        fc = FC.forecast_calls(n_write=z["n_write"], n_score=z["n_score"], n_calib=z["calib"],
                               no_memory_repeats=z["Rz"])
        add("forecast", "pre-swap forecast (App. F)", "no-memory runs of both models (write, score and "
            "calibration tasks)", pre_owner=fc["old_model_calls"], other=fc["new_model_calls_before_swap"],
            free="owner's write and score-task no-memory runs (in the build)", note="msr.forecast.forecast_calls")
    else:
        add("forecast", "pre-swap forecast (App. F)", "no-memory runs of both models", fits=False,
            note="registered study only (msr.forecast.forecast_calls)")
    # the new free baselines
    add("correct", "new baseline", "the write-time grade of each stored answer", free="the grade (gold answers or a "
        "grader at write time)", note="0 calls on swap day; needs a correctness oracle in deployment")
    lazy = measured.get("reanswer_lazy", NAN)
    add("reanswer", "new baseline", "the reader's own no-memory answer to every item's task", other=z["n_write"],
        note=(f"one reader call per item; answering only the items that are ever a candidate needs {lazy:.0f} in the "
              "practice study") if math.isfinite(lazy) else "one reader call per item")
    add("ips", "new baseline", "the logged selection probabilities of the score phase", free="logged probabilities",
        uses_level=True)
    add("dr", "new baseline", "logged probabilities + the owner's no-memory runs of the score tasks",
        free="owner's no-memory runs of the score tasks (paid in the build for the credit family)", uses_level=True)
    add("keep_nolevel", "new baseline", "the owner's scores, raw log score (no level correction)",
        free="owner's bank", note="the version of keep that buys no level information")
    return rows


def cost_table(S: Study, real_st=None, practice_measured: dict | None = None, kod: dict | None = None) -> list:
    """Practice and registered columns side by side; the same rows and numbers as
    paper/assets/table_cost_one.tex, which is made from this file and the same two functions."""
    zp = sizes_of(S.st)
    rows_p = cost_rules(zp, practice_measured, registered=False)
    rows_r = cost_rules(sizes_of(real_st), kod, registered=True) if real_st is not None else None
    real_by_rule = {r["rule"]: r for r in rows_r} if rows_r else {}
    prac_by_rule = {r["rule"]: r for r in rows_p}
    names = [r["rule"] for r in rows_p] + [r for r in real_by_rule if r not in prac_by_rule]
    out = []
    for name in names:
        rp, rr = prac_by_rule.get(name), real_by_rule.get(name)
        any_ = rr or rp
        row = {"rule": name, "kind": any_["kind"], "uses": any_["uses"],
               "uses_level_information": any_["uses_level_information"]}
        for tag, src in (("practice", rp), ("real", rr)):
            for col in ("pre_swap_owner_calls", "swap_day_reader_checks", "swap_day_reader_level",
                        "swap_day_reader_other", "total_calls"):
                row[f"{col}_{tag}"] = src[col] if src else NAN
        row["free_information"] = any_["free_information"]
        notes = [rp["note"]] if rp and rp["note"] else []
        if rr and rr["note"] and (not rp or rr["note"] != rp["note"]):
            notes.append("real: " + rr["note"])
        row["note"] = " | ".join(notes)
        out.append(row)
    return out


def reading(row: dict, how: str = "ols") -> tuple:
    """(label, sentence) for one stream from the correctness row of the headline family over the home
    cells. Whether a score ranks items at home is decided by THE one home-signal rule of the project
    (msr.metrics.home_signal_flag on the calibration tasks: 'home_flag' for the learned score,
    'home_flag_res_<how>' for its residual); the share of V_home carried by the grade by its 95 % Fieller
    interval against 1/2:
      the learned score has no home signal                  -> "cannot tell";
      share interval above 1/2                              -> "mostly a correctness detector";
      share interval covers 1/2                             -> "partly a correctness detector";
      share interval below 1/2                              -> "signal beyond correctness"
                                                               ("mostly beyond correctness, partly correctness"
                                                                when the interval is also above 0);
    each with ", with signal beyond it" when the residual has a home signal, and "inconclusive" when the
    share is below 1/2 but the residual has none."""
    sh = row.get(f"correct_share_home_{how}", NAN)
    lo, hi = row.get(f"correct_share_home_{how}_lo", NAN), row.get(f"correct_share_home_{how}_hi", NAN)
    if row.get("home_flag") != M.THETA_DEFINED:
        return ("cannot tell", "the learned score has no home signal on the calibration tasks (the one home-signal "
                "rule), so its make-up cannot be read")
    beyond = row.get(f"home_flag_res_{how}") == M.THETA_DEFINED
    tail = ", with signal beyond it" if beyond else ""
    what = (f"the grade carries {sh:.2f} of the home signal (95 % {lo:.2f} to {hi:.2f}) and the residualised score "
            + ("still has a home signal" if beyond else "has no home signal") + " on the calibration tasks")
    if math.isfinite(lo) and lo > 0.5:
        return ("mostly a correctness detector" + tail, what)
    if not (math.isfinite(hi) and hi < 0.5):
        return ("partly a correctness detector" + tail, what)
    if not beyond:
        return ("inconclusive", what)
    if math.isfinite(lo) and lo > 0:
        return ("mostly signal beyond correctness, partly correctness", what)
    return ("signal beyond correctness", what)


CLAIMS = {
    "mostly a correctness detector": "the scores transfer mainly because they detect correct stored answers; "
    "say so in the abstract (R5 W1) and do not call theta reader-specific usefulness",
    "mostly a correctness detector, with signal beyond it": "the headline theta mostly measures correctness; a "
    "reader-relevant signal beyond it may be claimed only through theta of the residualised score",
    "partly a correctness detector": "the grade carries a sizeable but unsettled part of the signal; report theta "
    "of the residualised score beside theta and claim neither reading",
    "partly a correctness detector, with signal beyond it": "the grade carries a sizeable part of the signal and "
    "there is signal beyond it; report theta of the residualised score beside theta as the part that is not "
    "correctness",
    "mostly signal beyond correctness, partly correctness": "the learned score is not mainly a correctness "
    "detector, though the grade carries a detectable part; report theta of the residualised score beside theta",
    "signal beyond correctness": "the learned score is not mainly a correctness detector; report theta of the "
    "residualised score as the part that is not correctness",
    "inconclusive": "neither reading may be claimed for this stream",
    "cannot tell": "neither reading may be claimed for this stream",
}


def _find(rows, **kw):
    for r in rows:
        if all(r.get(k) == v for k, v in kw.items()):
            return r
    return None


def _camel(s: str) -> str:
    digits = {"0": "Zero", "1": "One", "2": "Two", "3": "Three", "4": "Four", "5": "Five", "6": "Six",
              "7": "Seven", "8": "Eight", "9": "Nine"}
    s = "".join(digits.get(ch, ch) for ch in str(s))
    return "".join(p[:1].upper() + p[1:] for p in re.split(r"[^A-Za-z]+", s) if p)


def macro_rows(S: Study, T: dict, prefix: str) -> list:
    """Number macros the paper needs (name, value, source, meaning), named as in paper/assets/MACROS.md
    (prefix by study kind, stem Constr, parts CamelCased)."""
    out = []
    H = S.headline

    def add(parts, value, source, meaning):
        if value is None or (isinstance(value, float) and not math.isfinite(value)):
            return
        out.append({"macro": "\\" + prefix + "Constr" + "".join(_camel(p) for p in parts),
                    "value": f"{value:.3f}" if isinstance(value, float) else str(value), "source": source,
                    "meaning": meaning})

    for lvl in S.streams + ["all"]:
        r = _find(T["correctness"], score=H, scope="group", group="home", level=lvl)
        if r:
            for k, mean in (("correct_share_home_ols", "share of the home signal carried by the stored-answer grade"),
                            ("correct_share_home_ols_lo", "its 95 % lower end"),
                            ("correct_share_home_ols_hi", "its 95 % upper end"),
                            ("correct_share_home_rank", "the same with the rank residual")):
                add(["CorrectShare", lvl, k.replace("correct_share_home_", "")], r.get(k, NAN),
                    f"construct_correctness.csv score={H} group=home level={lvl} col={k}", mean)
        for g in ("upgrade", "downgrade", "cross", "all_swaps"):
            r = _find(T["correctness"], score=H, scope="group", group=g, level=lvl)
            if r:
                for k in ("theta_all", "theta_res_ols", "theta_cc", "theta_ii", "theta_mixed"):
                    add(["Theta", k.replace("theta_", ""), g, lvl], r.get(k, NAN),
                        f"construct_correctness.csv score={H} group={g} level={lvl} col={k}",
                        f"theta of the headline score over {k.replace('theta_', '')} pairs, {GROUP_LABEL[g]}")
            rr = _find(T["reference"], score="correct", scope="group", group=g, level=lvl)
            if rr:
                add(["RefTheta", g, lvl], rr.get("theta", NAN), f"construct_reference.csv score=correct group={g} "
                    f"level={lvl}", "theta of the stored-answer-correct reference")
                add(["RefCSwap", g, lvl], rr.get("C_swap", NAN), f"construct_reference.csv score=correct group={g} "
                    f"level={lvl} col=C_swap", "Cw of the stored-answer-correct reference after the swap")
            ro = _find(T["overlap"], score=H, scope="group", group=g, level=lvl)
            if ro:
                for k in ("share_pairs_match_swap", "share_pairs_neardup_swap", "theta_excl_either"):
                    add(["Overlap", k, g, lvl], ro.get(k, NAN), f"construct_overlap.csv score={H} group={g} "
                        f"level={lvl} col={k}", k.replace("_", " "))
        for rule in ("correct", "reanswer", "ips", "dr"):
            rb = _find(T["baselines"], rule=rule, scope="group", group="all_swaps", level=lvl)
            if rb:
                add(["Base", rule, "MinusKeep", lvl], rb.get("value_minus_keep", NAN),
                    f"construct_baselines.csv rule={rule} group=all_swaps level={lvl} col=value_minus_keep",
                    f"first-shown success of {rule} minus keep, all swaps")
    for lvl in S.streams + ["all"]:
        for g in ("upgrade", "downgrade", "cross", "all_swaps"):
            rr = _find(T["reference"], score=H, scope="group", group=g, level=lvl)
            if rr:
                for k in ("order", "stakes"):
                    add([k.capitalize(), g, lvl], rr.get(k, NAN), f"construct_reference.csv score={H} group={g} "
                        f"level={lvl} col={k}", f"retained {k} of the headline score" if k == "order" else
                        "stakes ratio sqrt(S_reader / S_owner)")
    return out


def _fmt(v):
    if v is None:
        return ""
    if isinstance(v, (bool, np.bool_)):
        return str(bool(v))
    if isinstance(v, (int, np.integer)):
        return str(int(v))
    if isinstance(v, (float, np.floating)):
        v = float(v)
        if math.isnan(v):
            return ""
        if math.isinf(v):
            return "inf" if v > 0 else "-inf"
        return f"{v:.6g}"
    return str(v)


def write_csv(path: Path, rows: list) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    cols: list = []
    for r in rows:
        for k in r:
            if k not in cols:
                cols.append(k)
    tmp = path.with_name(path.name + ".part")
    with open(tmp, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(cols)
        for r in rows:
            w.writerow([_fmt(r.get(c)) for c in cols])
    tmp.replace(path)


def practice_measured(S: Study, analysis_dir: Path) -> dict:
    """Measured input of the practice cost column: the distinct candidate items a lazy re-answer needs per bank."""
    out = {}
    per_bank = defaultdict(set)
    for (cell, b, sd), c in S.cells.items():
        per_bank[(cell[0], b, sd)] |= {int(i) for i in c.cand[c.cand >= 0].ravel()}
    if per_bank:
        out["reanswer_lazy"] = float(np.mean([len(v) for v in per_bank.values()]))
    return out


def sim_mechanism(S: Study, P: Pool) -> dict:
    """For a simulated study: does the stored answer's grade matter in THESE data? Judged from the data,
    not from the simulator module this process imports (a run may have used another one), by THE one
    home-signal rule (msr.metrics.home_signal_flag) applied to the stored-answer-correct reference over
    the home cells. The imported simulator's stored-answer setting is reported beside it."""
    if not getattr(S.st, "all_sim", False):
        return {"simulated": False, "uses_stored_answer": None, "detail": ""}
    from msr import sim
    bonus = {}
    for m in S.st.models:
        try:
            bonus[m] = float(sim.model_params(m).get("correct_bonus", 0.0) or 0.0)
        except Exception:                      # pragma: no cover
            pass
    homes = [c for c in S.design.swaps("home") if c in S.present_cells]
    its = [(c, b) for c in homes for b in S.streams]
    z, flag = P.home_flag(its, "correct")
    cw = P.cw(its, "correct|all|home")
    matters = flag == M.THETA_DEFINED
    code = ("the imported msr.sim gives the stored answer no weight for these models (success = sigmoid(skill + "
            "difficulty(task) + quality(model, item id) + rel_bonus), quality a hash of the item id, rel_bonus when "
            "the item's SOURCE task has the probe's label)" if not any(v != 0 for v in bonus.values()) else
            "the imported msr.sim has a stored-answer term (correct_bonus: " +
            ", ".join(f"{m} {v:g}" for m, v in bonus.items()) + ")")
    data = (f"in these data the stored-answer-correct reference ranks the owner's own results with Cw {cw:.3f}; "
            f"its home signal on the calibration tasks has z {z:.2f} ({flag}), so the grade "
            + ("DOES matter here" if matters else "has no detectable effect here"))
    return {"simulated": True, "uses_stored_answer": matters, "detail": code + "; " + data,
            "reference_home_cw": cw, "reference_home_z": z, "reference_home_flag": flag}


def write_markdown(S: Study, T: dict, out: Path, kind: str, mech: dict, real_name: str, patch_path: Path | None) -> Path:
    H = S.headline
    L = [f"# Construct checks and free baselines: study `{S.st.name}` ({kind})", "",
         "Made by `scripts/make_construct_assets.py` (msr/construct.py) from the tables the pipeline wrote; no model "
         "call. Decision D7; reviews R5 W1, W4, W5, W6, R4 4 and 10, AC action 7.", ""]
    if mech.get("simulated"):
        L += ["**Simulated data.** " + mech["detail"] + ". "
              + ("So every number below only shows that the code runs and gives the right answer in a world where "
                 "correctness does not matter (correctness shares near 0, the reference near chance). It says nothing "
                 "about real models." if not mech.get("uses_stored_answer") else
                 "The numbers below show what the code reports in a simulated world where correctness matters; they "
                 "say nothing about real models."), ""]
    L += ["## Files", "",
          "| file | what it holds |", "|---|---|",
          "| construct_reference.csv | point 1: Cw, V and the three measures (retained value theta with its Fieller set and the registered tests; retained order, 'not identifiable' when the readers' spread flag fails; stakes), with the home-signal flag, at home and after the swap for every score type: the 5 learned families, the stored-answer-correct reference (`correct`, ties 1/2; `correct_rel`, ties by relevance), `relevance`, and the static baselines `reanswer`, `ips`, `dr`; per cell and group, per stream and `all` |",
          "| construct_correctness.csv | point 2: V and W split into correct-correct (cc), wrong-wrong (ii) and mixed pairs; share of V in mixed pairs and its null (the weight share); theta within cc, ii, mixed and same-grade pairs; the residualised score (ols and rank) with its Cw, V, theta and the share of V the grade carries (1 - V_resid / V, Fieller interval); the bank-level AUC of the score for the grade |",
          "| construct_overlap.csv | point 3: share of informative pairs with an answer-matching / near-duplicate candidate (or either), and Cw, V, theta with those pairs excluded |",
          "| construct_candidates.csv | point 3: candidate-level shares (matching, near duplicates, stored answer correct) and the owner's and reader's success with and without them |",
          "| construct_neardup.csv | point 3: the near-duplicate threshold and the similarity distributions behind it |",
          "| construct_visits.csv | point 3: showings per item in the score phase per bank (0, 1-2, 3-5, 6+), the same over the evaluation candidates, AUCs of each score for the grade |",
          "| construct_visits_theta.csv | point 3: Cw, V and theta by visit stratum of the pair's less-visited candidate |",
          "| construct_reanswer.csv | point 4a: are the write tasks shared, how often the reader agrees with the stored answer (by grade) |",
          "| construct_baselines.csv | point 4: every rule scored like the paper's arms (first-shown success, regret, log and Brier raw and level-corrected) with two-way intervals of the differences to keep and wipe |",
          "| construct_costs.csv | point 5: calls per swap day by who makes them and when, practice and registered sizes; the level information is one shared row; the source of paper/assets/table_cost_one.tex, the one cost table |",
          "| construct_macros.csv | number macros for the paper (name, value, source, meaning) |", ""]
    L += ["## Definitions", "",
          "- Pairs are the within-task pairs of a probe task's candidates; V = sum sgn(x_i - x_j)(y_i - y_j) "
          "(msr.metrics), Cw = 1/2 + V / 2W. A pair is informative when its outcomes differ. Subsets are exact sums.",
          f"- `correct`: 1 if the stored answer was graded correct at write time, else 0. `correct_rel`: the same with "
          f"ties broken by relevance (x = grade + {REL_TIE:g} x relevance).",
          "- Residual ranking (point 2c), primary `ols`: x - mean of x over the bank's items of the same grade (the "
          "least-squares residual of x on the 0/1 grade). It removes all that the grade explains linearly, keeps the "
          "order inside each grade (cc and ii pairs keep their V), and only re-ranks mixed pairs. `rank`: within-grade "
          "mid-rank / count, which also removes a grade-dependent spread. Share carried by the grade = 1 - V_resid / V.",
          "- Mixed-pair share (2a): V_mixed / V. A score that ranks by grade only has share 1; its null is the weight "
          "share W_mixed / W (what a score blind to the grade would show); `excess_mixed` = (share - null) / (1 - null).",
          f"- Answer match: the grader marks the stored answer correct for the probe task. Near duplicate: relevance above "
          f"the {NEAR_DUP_Q} quantile of the similarity of pairs that cannot be the same case (DDXPlus: different "
          "pathology; BIRD: different database): a false-alarm rate of 1 in 1,000 among sure non-duplicates.",
          "- Visit strata: score-phase showings of the pair's less-visited candidate (0, 1-2, 3-5, 6+).",
          "- `reanswer`: 1 if the reader's own write-phase answer to the item's task agrees with the stored answer "
          "(DDXPlus: the same label; BIRD: the same result set), else 0. `ips`: self-normalised inverse-propensity "
          f"success when shown; `dr`: doubly robust with the owner's no-memory result as the direct model; pi clipped "
          f"at {PI_CLIP}. Both from the logged score phase.",
          "- Groups pool (cell, stream) items with equal weight (Part 2.12); theta = sum V_swap / sum V_home with "
          "msr.metrics.theta_tests (registered variance: two-way delete-one-cluster jackknife, items by identity "
          "across orders; the drop test also beyond the self-swap reference); retained order and stakes from the "
          "noise-free spreads S (msr.metrics.cross_repeat_parts) of the SAME pair subset as the theta beside them. "
          "Whether a score has a home signal is decided only by msr.metrics.home_signal_flag (calibration tasks). "
          "Cell rows give subset thetas as points only.", ""]
    L += ["## Readings per stream (headline family `" + H + "`)", ""]
    for lvl in S.streams + (["all"] if len(S.streams) > 1 else []):
        r = _find(T["correctness"], score=H, scope="group", group="home", level=lvl)
        if not r:
            continue
        lab, sent = reading(r)
        ra = _find(T["correctness"], score=H, scope="group", group="all_swaps", level=lvl) or {}
        ref = _find(T["reference"], score="correct", scope="group", group="home", level=lvl) or {}
        claim = CLAIMS.get(lab, CLAIMS["inconclusive"])
        L += [f"**{lvl}: {lab}.** At home {sent}. The stored-answer-correct reference alone has Cw "
              f"{ref.get('C_home', NAN):.3f} at home; the learned score's mixed pairs carry "
              f"{r.get('share_mixed_home', NAN):.2f} of its V (null {r.get('weight_share_mixed_home', NAN):.2f}). "
              f"After the swap (all swaps) theta = {ra.get('theta_all', NAN):.3f}; within correct-correct pairs "
              f"{ra.get('theta_cc', NAN):.3f}, wrong-wrong {ra.get('theta_ii', NAN):.3f}, mixed "
              f"{ra.get('theta_mixed', NAN):.3f}; residualised {ra.get('theta_res_ols', NAN):.3f} "
              f"(95 % {ra.get('theta_res_ols_lo', NAN):.3f} to {ra.get('theta_res_ols_hi', NAN):.3f}). "
              f"What the paper may claim: {claim}."
              + (" (Simulated, and the stored answer has no effect in these data: by construction.)"
                 if mech.get("simulated") and not mech.get("uses_stored_answer") else ""), ""]
    L += ["## Free baselines beside keep and wipe (all swaps, first-shown success)", "",
          "| rule | value | minus keep (95 %) | minus wipe (95 %) | log | log, level-corrected |", "|---|---|---|---|---|---|"]
    for rule in arm_rules(S) + ["keep_nolevel"]:
        r = _find(T["baselines"], rule=rule, scope="group", group="all_swaps", level="all")
        if not r:
            continue
        mk = (f"{r.get('value_minus_keep', NAN):+.3f} ({r.get('value_minus_keep_lo', NAN):+.3f}, "
              f"{r.get('value_minus_keep_hi', NAN):+.3f})") if math.isfinite(r.get("value_minus_keep", NAN)) else ""
        mw = (f"{r.get('value_minus_wipe', NAN):+.3f} ({r.get('value_minus_wipe_lo', NAN):+.3f}, "
              f"{r.get('value_minus_wipe_hi', NAN):+.3f})") if math.isfinite(r.get("value_minus_wipe", NAN)) else ""
        L.append(f"| {rule} | {r['value']:.3f} | {mk} | {mw} | {_fmt(r.get('log'))} | {_fmt(r.get('log_lc'))} |")
    L += ["", "## Costs: the one cost table", "",
          "The paper's ONE cost table is `paper/assets/table_cost_one.tex` (scripts/make_paper_assets.py), made from "
          "construct_costs.csv and the same two functions this module calls, so the two agree row for row: calls of "
          "one swap day (one owner bank, one reader, one stream, one order) by who makes them and when. The level "
          "information is one shared row (pre-registration Part 6.4), `own` is one reader build, and the "
          "keep-or-drop tests and the forecast come from msr.sequential.swap_day_calls and "
          "msr.forecast.forecast_calls (registered sizes only).", ""]
    by = {r["rule"]: r for r in T["costs"]}
    L += ["| row | old model, before the swap (registered) | reader (registered) | this study's total |",
          "|---|---|---|---|"]
    for rule, label in (("level_information", "level information (shared)"), ("reanswer", "re-answer (new)"),
                        ("own", "own (one build)"), ("forecast_20_checks", "forecast's 20-check baseline"),
                        ("break_even_first_shown", "break-even test, first-shown"),
                        ("paired_store200", "paired 0.75 test, store of 200 tasks"),
                        ("paired_median", "paired 0.75 test, store for its median"), ("forecast", "pre-swap forecast")):
        r = by.get(rule)
        if r is None:
            continue
        reader = sum(r.get(f"swap_day_reader_{c}_real", NAN) for c in ("checks", "level", "other"))
        tot_p = r.get("total_calls_practice", NAN) if rule != "level_information" else r.get("swap_day_reader_level_practice", NAN)
        L.append(f"| {label} | {_fmt(r.get('pre_swap_owner_calls_real'))} | {_fmt(reader)} | {_fmt(tot_p)} |")
    L += [""]
    if S.notes:
        L += ["## Notes", ""] + [f"- {n}" for n in S.notes] + [""]
    L += ["## What the stored data cannot support, and what the real run must log", "",
          "- `build.store` must stay `all`. With `correct_only` every stored grade is 1, so point 2 cannot be "
          "computed at all, and the reader's wrong write answers (re-answer agreement) are only in calls.jsonl.",
          "- Re-answer agreement works because the write tasks are shared by every model of a (stream, order) "
          "(checked: construct_reanswer.csv) and each model's write answer is stored. But it is ONE sample, and the "
          "owner has no second no-memory answer to its own write tasks, so `reanswer` has no home value and no "
          "self-swap reference (at home it agrees with itself by construction). To give it one, log a second "
          "no-memory answer to every write task per model (one repeat: n_write calls per model, stream and order).",
          "- Propensities: only the SHOWN item's selection probability is logged. That is enough for the per-item "
          "IPS and DR scores here, but not for off-policy evaluation of another selection rule from the score-phase "
          "log. Log, per score-phase episode, the selection probability of EVERY candidate and the mixed score used "
          "to choose (no calls).",
          "- The grade is the primary grader's (BIRD: corrected parser). Under the registered BIRD sensitivity "
          "grading the grades change; this analysis is not re-run for it (rerun with the regraded banks).",
          "- The paired keep-or-drop test reads the owner's home results from the probe table; on a real swap day "
          "they are old-model calls that must be made before the old model retires (construct_costs.csv).",
          "- The near-duplicate test uses the cached task embeddings and the grader decides answer match (BIRD: "
          "the stored query is run on the probe's database); both exist for the real study, at the cost of running "
          "every stored query against its probe tasks' gold results offline.", ""]
    if patch_path is not None and patch_path.exists() and mech.get("simulated"):
        L += ["## Proposed change to msr/sim.py (not applied)", "",
              "The smallest additive change that gives the simulator a stored-answer effect: a per-model log-odds "
              "term `correct_bonus` (+ when the item's stored answer was graded correct at write time, - when it was "
              "wrong; 0 = today's world). The write call is deterministic, so the simulator can recompute the "
              "grade from the item id. Patch file: `" + patch_path.as_posix() + "`.", "", "```diff",
              patch_path.read_text(encoding="utf-8").rstrip(), "```", ""]
    p = out / "CONSTRUCT.md"
    p.write_text("\n".join(L) + "\n", encoding="utf-8")
    return p


def run(study: str, out_dir=None, real_study: str = "config/study.yaml", measures: dict | None = None,
        printer=print) -> dict:
    """Everything: load, fill, the tables, the CSV files and CONSTRUCT.md. Returns the tables."""
    import time
    from msr.analysis import KIND_LABEL, resolve_study, study_kind
    t0 = time.time()
    ACTIVE.clear()
    ACTIVE.update(MEASURES)
    if measures:
        ACTIVE.update(measures)
    st = resolve_study(study)
    out = Path(out_dir) if out_dir else st.dir / "analysis"
    out.mkdir(parents=True, exist_ok=True)
    printer(f"construct: loading study {st.name} ...")
    S = Study(st, printer)
    printer(f"construct: {len(S.cells)} cells, {len(S.banks)} banks; filling per-task values ...")
    P = fill(S)
    real_st = None
    try:
        from msr.study import load_study
        rp = Path(real_study)
        if not rp.is_absolute():
            rp = Path(__file__).resolve().parent.parent / rp
        real_st = load_study(rp)
    except Exception as exc:                      # pragma: no cover
        S.notes.append(f"real study sizes not read ({exc})")
    printer("construct: tables ...")
    T = {"reference": reference_rows(S, P), "correctness": correctness_rows(S, P), "overlap": overlap_rows(S, P),
         "candidates": candidate_rows(S, P), "visits": visits_bank_rows(S), "visits_theta": visits_theta_rows(S, P),
         "baselines": baseline_rows(S, P), "reanswer": S.reanswer_rows, "neardup": S.threshold_rows}
    if len(S.streams) == 1:
        # one stream: the level 'all' (the streams pooled) is that stream; copy the rows, as msr.analysis has both
        for k, rows in T.items():
            if rows and isinstance(rows, list) and isinstance(rows[0], dict) and rows[0].get("level") == S.streams[0]:
                T[k] = rows + [{**r, "level": "all"} for r in rows if r.get("level") == S.streams[0]]
    T["costs"] = cost_table(S, real_st, practice_measured(S, st.dir / "analysis"),
                            keep_or_drop_inputs(st.dir / "analysis"))
    kind = study_kind(st)
    T["macros"] = macro_rows(S, T, KIND_LABEL.get(kind, ("", ""))[0])
    names = {"reference": "construct_reference.csv", "correctness": "construct_correctness.csv",
             "overlap": "construct_overlap.csv", "candidates": "construct_candidates.csv",
             "neardup": "construct_neardup.csv", "visits": "construct_visits.csv",
             "visits_theta": "construct_visits_theta.csv", "reanswer": "construct_reanswer.csv",
             "baselines": "construct_baselines.csv", "costs": "construct_costs.csv", "macros": "construct_macros.csv"}
    for k, fn in names.items():
        write_csv(out / fn, T[k])
    mech = sim_mechanism(S, P)
    patch = Path(__file__).resolve().parent.parent / "docs" / "construct_sim_patch.diff"
    md = write_markdown(S, T, out, kind, mech, Path(real_study).name if real_st is not None else "(not read)", patch)
    printer(f"construct: wrote {len(names)} CSV files and {md.name} to {out} in {time.time() - t0:.1f} s")
    T["_study"] = S
    T["_pool"] = P
    T["_mechanism"] = mech
    return T
