"""Swap-day rules ("arms"): what to do with old scores when the model changes.

Everyday picture: the garage hires a new helper. The box of repair tips stays
exactly the same (content never changes). Only the scores on the tips can be
changed. Each function below takes the OLD bank (scores earned with the old
model) and returns the scores to use with the NEW model:

    keep                  trust the old scores fully
    wipe                  forget them; every tip back to its starting score
    fixed_discount        trust them halfway (or any fixed share lam)
    calibrated_discount   try a few cases with the new helper first, then pick
                          how much to trust the old scores
    retest_top            re-try only the old top-k tips with the new helper
                          (HEIRS-style extra rule); the rest start fresh
    rescore               the ceiling: scores earned again with the new model

Added for the master plan (section 2.7); `ARMS_NO_CHECKS` and
`ARMS_WITH_CHECKS` map the base names to these functions:
    shuffled     the content-only control: old scores permuted across all items
    powerprior   old evidence at weight lam, lam chosen from k fresh checks,
                 base prior fitted to the old bank (empirical Bayes)
    recalibrate  level and slope refitted from k fresh checks ("recal")
    retest       re-test the checked items, every other item reset
    audit        check every candidate of k/4 calibration tasks once; keep the
                 old scores if they order those checks better than a coin, else wipe
    pooled       old evidence plus the fresh outcomes, both at full weight
    fresh_only   wipe, then the fresh outcomes only ("fresh")

Every function returns a NEW bank; the input bank is never modified. Records
keep every non-score key untouched, and get a "swap_rule" tag saying which
rule produced them.

About the calibrated rule: the "power prior" is a known statistical method
(Ibrahim and Chen 2000, Statistical Science 15:46-60), and choosing its weight
by maximising the marginal likelihood of new data is the empirical-Bayes
version (Gravestock and Held 2017). Neither is a contribution of this study;
the study only applies them to agent memory scores on swap day.
"""

from __future__ import annotations

import copy
import math
from typing import Dict, Iterable, List, NamedTuple, Optional, Sequence, Tuple

import numpy as np

from .scores import Bank, ScoreRule, SCORE_TIE_TOL, _check_lam
from .scores import (CounterScore, CreditScore, ValueScore, VisitScore, fit_beta_prior, has_counts, has_prob,
                     predicted_prob, standardise, standardised_scores)

#: Grid of trust weights the calibrated rule chooses from: 0, 0.05, ..., 1.
LAM_GRID: Tuple[float, ...] = tuple(float(x) for x in np.round(np.linspace(0.0, 1.0, 21), 2))

#: Offline sweep for the fixed discount: 0.1, 0.2, ..., 0.9.
SWEEP_LAMS: Tuple[float, ...] = tuple(float(x) for x in np.round(np.arange(1, 10) / 10.0, 1))

#: Numbers of fresh checks the study tries for the calibrated rule (evaluate.k_values in the
#: study files; k = 64 is the primary comparison PC4, 128 and 256 are exploratory, 8.3.7).
K_VALUES: Tuple[int, ...] = (8, 16, 32, 64, 128, 256)

#: A fresh check is (item_id, success) with the NEW model on a held-out probe task.
FreshCheck = Tuple[str, bool]


def _tag(bank: Bank, rule_name: str) -> Bank:
    for rec in bank.values():
        rec["swap_rule"] = rule_name
    return bank


def _check_fresh(fresh_checks: Iterable[FreshCheck]) -> List[Tuple[str, bool]]:
    """Validate the fresh checks: a list of (item_id, success True/False)."""
    out = []
    for n, pair in enumerate(fresh_checks):
        try:
            item, ok = pair
        except (TypeError, ValueError):
            raise ValueError(f"fresh check #{n} must be (item_id, success), got {pair!r}") from None
        if not isinstance(ok, (bool, np.bool_)) and ok not in (0, 1):
            raise ValueError(f"fresh check #{n}: success must be True/False, got {ok!r}")
        out.append((item, bool(ok)))
    return out


# ---------------------------------------------------------------------------
# keep / wipe / fixed discount
# ---------------------------------------------------------------------------


def keep(bank: Bank, rule: ScoreRule) -> Bank:
    """Keep every old score unchanged. Everyday meaning: "the new helper will
    find the same tips useful as the old one did"."""
    return _tag(copy.deepcopy(bank), "keep")


def wipe(bank: Bank, rule: ScoreRule) -> Bank:
    """Reset every score to the rule's STARTING value (not to zero):
    value q -> 0.5, counters -> 0 helpful / 0 harmful, visits -> 0.
    Ranking then falls back to relevance alone, because every item ties.
    Everyday meaning: "keep the tips, forget how well they did"."""
    return _tag({i: rule.reset_record(r) for i, r in bank.items()}, "wipe")


def fixed_discount(bank: Bank, rule: ScoreRule, lam: float = 0.5) -> Bank:
    """Trust the old evidence with a fixed weight lam (default 0.5).

    value rule:    q' = Q0 + lam * (q - Q0)      (pulled toward 0.5)
    counter rule:  helpful' = lam * helpful, harmful' = lam * harmful
                   (a power prior with weight lam)
    Visit counts are multiplied by lam too, so lam = 0 is exactly `wipe`
    and lam = 1 is exactly `keep`.
    Everyday meaning: "each old result now counts as half a result".

    Note for analysis: for the value rule this shrink keeps the order of the
    scores unchanged (every q moves toward 0.5 by the same share), so it can
    only change what is shown through the mix with relevance in `rank`.
    """
    lam = _check_lam(lam)
    return _tag({i: rule.discount_record(r, lam) for i, r in bank.items()}, f"fixed_discount({lam:g})")


def sweep_fixed_discount(bank: Bank, rule: ScoreRule, lams: Sequence[float] = SWEEP_LAMS) -> Dict[float, Bank]:
    """{lam: discounted bank} for the offline sweep 0.1 .. 0.9."""
    return {float(l): fixed_discount(bank, rule, l) for l in lams}


# ---------------------------------------------------------------------------
# calibrated discount (empirical-Bayes power prior)
# ---------------------------------------------------------------------------


def _log_beta(a: float, b: float) -> float:
    return math.lgamma(a) + math.lgamma(b) - math.lgamma(a + b)


def _group_fresh(fresh: List[Tuple[str, bool]]) -> Dict[str, Tuple[int, int]]:
    """{item: (successes, checks)} in first-seen order."""
    grouped: Dict[str, List[int]] = {}
    for item, ok in fresh:
        g = grouped.setdefault(item, [0, 0])
        g[0] += int(ok)
        g[1] += 1
    return {i: (s, m) for i, (s, m) in grouped.items()}


def power_prior_loglik(bank: Bank, rule: ScoreRule, fresh_checks: Iterable[FreshCheck], lam: float) -> float:
    """Log marginal likelihood of the fresh outcomes if the old evidence is
    trusted with weight lam.

    For item i with old pseudo-counts (a_i, b_i) the carried belief is
    Beta(1 + lam * a_i, 1 + lam * b_i). If the new model got y_i successes in
    m_i fresh checks of that item, the chance of exactly that sequence is the
    beta-binomial term  B(1 + lam a_i + y_i, 1 + lam b_i + m_i - y_i) /
    B(1 + lam a_i, 1 + lam b_i). The function returns the sum of the logs over
    the checked items. For one check this is P(success) = (1 + lam a) / (2 + lam (a + b)).

    Pseudo-counts come from `rule.pseudo_counts`: counters give
    (helpful, harmful); values give (q * visits, (1 - q) * visits).
    An item that is not in the bank has no old evidence (a = b = 0); it adds
    the same amount for every lam, so it cannot move the choice.
    """
    lam = _check_lam(lam)
    total = 0.0
    for item, (y, m) in _group_fresh(_check_fresh(fresh_checks)).items():
        rec = bank.get(item)
        a, b = rule.pseudo_counts(rec) if rec is not None else (0.0, 0.0)
        alpha, beta = 1.0 + lam * a, 1.0 + lam * b
        total += _log_beta(alpha + y, beta + (m - y)) - _log_beta(alpha, beta)
    return total


class LambdaChoice(NamedTuple):
    lam: float  # the chosen trust weight
    loglik: Dict[float, float]  # log marginal likelihood at every grid point
    k: int  # number of fresh checks used
    n_unknown: int  # fresh checks on items not in the bank (no old evidence)


def choose_lambda(
    bank: Bank, rule: ScoreRule, fresh_checks: Iterable[FreshCheck], grid: Sequence[float] = LAM_GRID
) -> LambdaChoice:
    """Pick the lam on `grid` under which the fresh outcomes were most likely.

    Everyday meaning: "try k cases with the new helper; if the old grades
    predicted those results well, trust the old grades (lam near 1); if they
    predicted badly, forget them (lam near 0)".

    Ties (equal likelihood up to 1e-9, e.g. when no checked item has old
    evidence) go to the SMALLEST lam: when the checks cannot tell, trust less.
    """
    fresh = _check_fresh(fresh_checks)
    if not fresh:
        raise ValueError("calibrated discount needs at least one fresh check")
    grid = [float(g) for g in grid]
    if not grid:
        raise ValueError("empty lam grid")
    ll = {g: power_prior_loglik(bank, rule, fresh, g) for g in grid}
    best = max(ll.values())
    lam = min(g for g in grid if ll[g] >= best - 1e-9)
    n_unknown = sum(1 for item, _ in fresh if item not in bank)
    return LambdaChoice(lam, ll, len(fresh), n_unknown)


def calibrated_discount(
    bank: Bank,
    rule: ScoreRule,
    fresh_checks: Iterable[FreshCheck],
    grid: Sequence[float] = LAM_GRID,
    fold_fresh: bool = False,
    new_model: Optional[str] = None,
    now=None,
) -> Tuple[float, Bank]:
    """Choose lam from k fresh checks (k in 8, 16, 32, 64 in the study), then
    apply `fixed_discount` with that lam. Returns (lam, new_bank).

    `fresh_checks` is a list of (item_id, success) pairs, each one a run of the
    NEW model on a HELD-OUT probe task with that item shown. Those probe tasks
    must then be left out of the evaluation, or the arm is graded on the data
    it was tuned on.

    `fold_fresh=False` (default): the fresh outcomes only choose lam; they do
    not enter any item's score, so the arm measures "how much to trust old
    scores" and nothing else. `fold_fresh=True` also adds each fresh outcome to
    its item's score with the rule's normal update (success = helpful for the
    counter rule), credited to `new_model`.
    """
    fresh = _check_fresh(fresh_checks)
    choice = choose_lambda(bank, rule, fresh, grid)
    out = fixed_discount(bank, rule, choice.lam)
    if fold_fresh:
        for item, ok in fresh:
            if item in out:
                rule.update(out, item, ok, model=new_model, now=now)
    return choice.lam, _tag(out, f"calibrated_discount({choice.lam:g},k={choice.k})")


# ---------------------------------------------------------------------------
# HEIRS-style re-test of the top items
# ---------------------------------------------------------------------------


def top_k_items(bank: Bank, rule: ScoreRule, k: int) -> List[str]:
    """The k items with the highest OLD ranking score. Ties are broken by item
    id (alphabetical), so the list is always the same."""
    if k < 0:
        raise ValueError("k must be >= 0")
    return sorted(bank, key=lambda i: (-rule.score(bank[i]), i))[:k]


def retest_top(
    bank: Bank,
    rule: ScoreRule,
    k: int,
    fresh_checks: Iterable[FreshCheck],
    new_model: Optional[str] = None,
    now=None,
) -> Bank:
    """Re-score only the top-k items (by old score) from fresh outcomes with
    the new model; every other item is reset to the starting value.

    Everyday meaning: "re-try the old favourite tips with the new helper and
    grade them on that alone; treat all other tips as untried".

    For a top-k item the new score starts from the starting value and takes
    the rule's normal update for each of its fresh outcomes, in the order
    given (value: moving average; counters: success = helpful,
    failure = harmful). A top-k item with no fresh check stays at the start.
    Fresh checks on items outside the top k are ignored.
    Use `top_k_items` first to know which items need checks.
    """
    fresh = _check_fresh(fresh_checks)
    top = set(top_k_items(bank, rule, k))
    out = {i: rule.reset_record(r) for i, r in bank.items()}
    for item, ok in fresh:
        if item in top:
            rule.update(out, item, ok, model=new_model, now=now)
    return _tag(out, f"retest_top({k})")


# ---------------------------------------------------------------------------
# ceiling
# ---------------------------------------------------------------------------


def rescore(new_bank: Bank, rule: ScoreRule, item_ids: Optional[Iterable[str]] = None) -> Bank:
    """The ceiling arm: scores earned again with the NEW model on the same
    memory content. It simply takes the bank the new model built.

    If `item_ids` (the old bank's items) is given, the result has exactly
    those items: items the new model never scored get the starting value,
    and items outside the list are dropped. Everyday meaning: "the new helper
    graded every tip himself"."""
    if item_ids is None:
        out = copy.deepcopy(new_bank)
    else:
        out = {}
        for i in item_ids:
            out[i] = copy.deepcopy(new_bank[i]) if i in new_bank else rule.new_record()
    return _tag(out, "rescore")


#: Arms whose only input is the old bank (and rule), by name.
SIMPLE_ARMS = {"keep": keep, "wipe": wipe, "fixed_discount": fixed_discount}


# ===========================================================================
# Master-plan arms (section 2.7), made to match prediction/PREREGISTRATION.md 2.6 (23 Nov 2026)
# ===========================================================================
#
# Same calling style as above: (bank, rule, ...) in, a NEW bank out (or a
# tuple whose last element is the new bank); the input is never changed.
# `fresh_checks` is a list of (item_id, success) measured with the NEW model
# on held-out calibration tasks. The arms that only fold outcomes in (retest,
# pooled, fresh) also accept (item_id, success, baseline) triples, where
# baseline is the new model's no-memory result on the same task; the credit
# rule needs it (a pair means baseline 0, the CreditScore default). The audit
# arm takes (item_id, success, task_id) triples, because it compares items
# WITHIN a task.
#
# Which arm applies to which family (pre-registration 0.4 and 2.6):
#   powerprior   needs Beta pseudo-counts: ema_grade (q n, (1 - q) n), beta_grade, tags_self
#   recal        needs the standardised score x': ema_grade, beta_grade, tags_self, credit
#   audit        needs only the ranking score: every family (visits has no p)
#   the others   every family

#: Arms that do not apply to every family (see `arm_applies`).
PROB_ARMS: Tuple[str, ...] = ("powerprior", "recal")

#: Penalised maximum likelihood of `recal`: level a ~ Normal(0, 1), slope b ~ Normal(0.5, 1)
#: (pre-registration 2.6). b = 1 trusts the old order fully, b = 0 ignores it.
RECAL_LEVEL_SD = 1.0
RECAL_SLOPE_MEAN = 0.5
RECAL_SLOPE_SD = 1.0

#: Kept for callers that read it; the pre-registered recalibration fits from any k >= 1
#: (the priors keep the fit defined), so no minimum applies any more.
RECAL_MIN_CHECKS = 1


def _check_fresh_any(fresh_checks: Iterable) -> List[Tuple[str, bool, Optional[float]]]:
    """Fresh checks as (item, success, baseline or None); accepts pairs or triples."""
    out = []
    for n, chk in enumerate(fresh_checks):
        if isinstance(chk, (tuple, list)) and len(chk) == 3:
            item, ok, base = chk
            (item, ok), = _check_fresh([(item, ok)])
            out.append((item, ok, None if base is None else float(base)))
        else:
            try:
                (item, ok), = _check_fresh([chk])
            except ValueError:
                raise ValueError(f"fresh check #{n} must be (item_id, success[, baseline]), got {chk!r}") from None
            out.append((item, ok, None))
    return out


def _need_counts(rule: ScoreRule, arm: str) -> None:
    if not has_counts(rule):
        raise ValueError(
            f"{arm} needs a rule whose evidence is a Beta count (value or counter); "
            f"the {rule.name!r} rule has none, so skip this arm for it (see arm_applies)"
        )


def arm_applies(name: str, rule: ScoreRule) -> bool:
    """True if arm `name` (a key of ARMS_NO_CHECKS / ARMS_WITH_CHECKS) can run with `rule`.
    powerprior needs Beta pseudo-counts (value, counter); recal needs a standardised
    score x' (value, counter, credit); every other arm applies to every rule."""
    if name in ("powerprior", "powerprior_flat"):
        return has_counts(rule)
    if name == "recal":
        return has_prob(rule)
    return name in ARMS_NO_CHECKS or name in ARMS_WITH_CHECKS


def _fold(rule: ScoreRule, out: Bank, item: str, ok: bool, base: Optional[float], new_model, now) -> None:
    """Add one fresh outcome to an item's score with the rule's normal update."""
    if isinstance(rule, CreditScore):
        rule.update(out, item, ok, model=new_model, now=now, baseline=0.0 if base is None else base)
    else:
        rule.update(out, item, ok, model=new_model, now=now)


def _logit(p: float) -> float:
    return math.log(p / (1.0 - p))


def _sigmoid(x):
    """1 / (1 + e^-x), safe for large |x|, for numbers and numpy arrays."""
    x = np.asarray(x, dtype=float)
    out = np.empty_like(x)
    pos = x >= 0
    out[pos] = 1.0 / (1.0 + np.exp(-x[pos]))
    ex = np.exp(x[~pos])
    out[~pos] = ex / (1.0 + ex)
    return out if out.ndim else float(out)


def _with_beta(rule: ScoreRule, rec: dict, alpha: float, beta: float, lam: float) -> dict:
    """Copy of `rec` holding the belief Beta(alpha, beta) with the old counts
    weighted by lam.

    counter:  helpful = alpha - 1, harmful = beta - 1 (so the smoothed mean is
              alpha / (alpha + beta)); visits * lam.
    value:    q = alpha / (alpha + beta); visits, successes, failures * lam.
    lam = 0 also clears who earned the score (nothing old is left in it).
    """
    out = copy.deepcopy(rec)
    if isinstance(rule, CounterScore):
        out["helpful"] = float(alpha) - 1.0
        out["harmful"] = float(beta) - 1.0
        out["visits"] = lam * rec.get("visits", 0)
    elif isinstance(rule, ValueScore):
        out["q"] = float(alpha) / (float(alpha) + float(beta))
        for f in ("visits", "successes", "failures"):
            out[f] = lam * rec.get(f, 0)
    else:  # pragma: no cover - guarded by _need_counts
        raise ValueError(f"rule {rule.name!r} has no pseudo-counts")
    if lam == 0.0:
        out.update({"model": None, "earned_at": None, "evidence_models": []})
    return out


# ---------------------------------------------------------------------------
# shuffled: the content-only control
# ---------------------------------------------------------------------------


def shuffle_order(n: int, seed) -> np.ndarray:
    """The permutation behind `shuffled`: a uniform random order of 0..n-1 from
    numpy's default generator seeded with `seed` (an int or a list of ints).
    Item i of the sorted bank receives the record of item perm[i]."""
    return np.random.default_rng(seed).permutation(n)


def shuffled(bank: Bank, rule: ScoreRule, seed=0) -> Bank:
    """The content-only control (pre-registration 2.6): "the owner's scores permuted at
    random across the 250 items".

    Everyday meaning: "peel the grade stickers off ALL the tips and stick them back
    on in a random order". If shuffled does as well as keep, the scores carried
    nothing about the particular tip; only the tips' content (or the spread of the
    grades) mattered.

    Every item of the bank (shown or not) takes the score record (the score fields
    plus who earned them and when) of item perm[i], where perm is a uniform random
    permutation of ALL items (`shuffle_order`); an item may keep its own record by
    chance, as a uniform permutation allows. Content stays with its item. Items are
    put in sorted order before the draw, so the result depends only on the bank's
    contents and `seed` (an int or a list of ints).
    """
    out = copy.deepcopy(bank)
    items = sorted(bank, key=str)
    if len(items) >= 2:
        perm = shuffle_order(len(items), seed)
        moved = tuple(rule.score_fields) + ("model", "earned_at", "evidence_models")
        for dst, j in zip(items, perm):
            src = items[int(j)]
            for f in moved:
                if f in bank[src]:
                    out[dst][f] = copy.deepcopy(bank[src][f])
                else:
                    out[dst].pop(f, None)
    return _tag(out, f"shuffled(seed={seed})")


# ---------------------------------------------------------------------------
# powerprior: weight lam chosen from fresh checks, prior fitted to the old bank
# ---------------------------------------------------------------------------


def power_prior_loglik_eb(
    bank: Bank, rule: ScoreRule, fresh_checks: Iterable[FreshCheck], lam: float, a0: float, b0: float
) -> float:
    """Log marginal likelihood of the fresh outcomes when the old evidence is
    weighted by lam on top of a Beta(a0, b0) base prior.

    For an item with old pseudo-counts (s, f) and y successes in m fresh checks:
    log B(a0 + lam s + y, b0 + lam f + m - y) - log B(a0 + lam s, b0 + lam f).
    With a0 = b0 = 1 this is exactly `power_prior_loglik`.
    Items not in the bank have no old evidence and add the same for every lam.
    """
    lam = _check_lam(lam)
    total = 0.0
    for item, (y, m) in _group_fresh(_check_fresh(fresh_checks)).items():
        rec = bank.get(item)
        s, f = rule.pseudo_counts(rec) if rec is not None else (0.0, 0.0)
        alpha, beta = a0 + lam * float(s), b0 + lam * float(f)
        total += _log_beta(alpha + y, beta + (m - y)) - _log_beta(alpha, beta)
    return total


def choose_lambda_eb(
    bank: Bank,
    rule: ScoreRule,
    fresh_checks: Iterable[FreshCheck],
    grid: Optional[Sequence[float]] = None,
    prior: Optional[Tuple[float, float]] = None,
) -> Tuple[LambdaChoice, Tuple[float, float]]:
    """The lam on `grid` under which the fresh outcomes were most likely, with
    the base prior fitted to the OLD bank (or given as `prior` = (a0, b0)).
    Ties (within 1e-9) go to the SMALLER lam (pre-registration 2.6, `powerprior_k`:
    "ties to the smaller lambda"): when the checks cannot tell, trust the old
    evidence less. Returns (LambdaChoice, (a0, b0))."""
    _need_counts(rule, "powerprior")
    fresh = _check_fresh(fresh_checks)
    if not fresh:
        raise ValueError("powerprior needs at least one fresh check")
    grid = [float(g) for g in (LAM_GRID if grid is None else grid)]
    if not grid:
        raise ValueError("empty lam grid")
    a0, b0 = fit_beta_prior(bank, rule) if prior is None else (float(prior[0]), float(prior[1]))
    ll = {g: power_prior_loglik_eb(bank, rule, fresh, g, a0, b0) for g in grid}
    best = max(ll.values())
    lam = min(g for g in grid if ll[g] >= best - 1e-9)
    n_unknown = sum(1 for item, _ in fresh if item not in bank)
    return LambdaChoice(lam, ll, len(fresh), n_unknown), (a0, b0)


def powerprior(
    bank: Bank,
    rule: ScoreRule,
    fresh_checks: Iterable[FreshCheck],
    grid: Optional[Sequence[float]] = None,
    prior: str = "eb",
    base: Optional[Tuple[float, float]] = None,
) -> Tuple[float, Bank]:
    """powerprior_k: old evidence counted at weight lam, lam chosen from k fresh checks.

    Pre-registration 2.6: "base prior Beta(a0, b0) fitted to the owner's bank by
    beta-binomial maximum likelihood over items with n >= 1 (pseudo-counts q n and
    (1 - q) n for ema_grade); weight lam = the grid value that maximises the
    beta-binomial marginal likelihood of the k checks (ties to the smaller lam); never a
    flat Beta(1, 1) base"; p = (a0 + lam s) / (a0 + b0 + lam n).

    Everyday meaning: "first learn what a typical tip in this box is worth;
    then try k cases with the new helper and pick how much each old result
    should still count (lam between 0 and 1) by which lam best predicted
    those k results".

    prior="eb" (default): the base Beta(a0, b0) comes from `fit_beta_prior` on
      the OLD bank (or `base` if given); lam maximises the marginal likelihood of
      the fresh outcomes on `grid` (default 0, 0.05, ..., 1); ties go to the SMALLER
      lam. Each item's belief becomes Beta(a0 + lam s_i, b0 + lam f_i), written back as
        counter: helpful = a0 + lam h - 1, harmful = b0 + lam f - 1, so the
                 rule's smoothed mean equals the posterior mean
                 (a0 + lam h) / (a0 + b0 + lam (h + f)); visits * lam
        value:   pseudo-counts (q n, (1 - q) n) as in `power_prior_loglik`,
                 q = posterior mean; visits, successes, failures * lam.
    prior="flat": the older rule, exactly `calibrated_discount` (Beta(1, 1)
      base, ties to the smaller lam). The statistics note shows it drives lam
      toward 0.2 even when nothing changed; it is kept only as an extra comparison
      (`powerprior_flat_k`), outside the pre-registered arms.
    Power prior: Ibrahim and Chen 2000; lam by marginal likelihood: Gravestock
    and Held 2017. Returns (lam, new_bank).
    """
    if prior == "flat":
        _need_counts(rule, "powerprior")
        lam, out = calibrated_discount(bank, rule, fresh_checks, grid=LAM_GRID if grid is None else grid)
        k = len(_check_fresh(fresh_checks))
        return lam, _tag(out, f"powerprior(flat,{lam:g},k={k})")
    if prior != "eb":
        raise ValueError("prior must be 'eb' or 'flat'")
    choice, (a0, b0) = choose_lambda_eb(bank, rule, fresh_checks, grid, prior=base)
    lam = choice.lam
    out = {}
    for i, rec in bank.items():
        s, f = rule.pseudo_counts(rec)
        out[i] = _with_beta(rule, rec, a0 + lam * float(s), b0 + lam * float(f), lam)
    return lam, _tag(out, f"powerprior(eb,{lam:g},k={choice.k})")


# ---------------------------------------------------------------------------
# recal: level and slope refitted from fresh checks (logistic recalibration)
# ---------------------------------------------------------------------------


def _fit_logistic(
    x: np.ndarray,
    y: np.ndarray,
    fit_slope: bool,
    prior_sd: Tuple[float, float] = (RECAL_LEVEL_SD, RECAL_SLOPE_SD),
    slope_mean: float = RECAL_SLOPE_MEAN,
    max_iter: int = 100,
) -> Tuple[float, float, bool]:
    """Penalised maximum likelihood for logit P(y = 1) = level + slope * x.

    Priors: level ~ Normal(0, prior_sd[0]); slope ~ Normal(slope_mean,
    prior_sd[1]). fit_slope=False keeps slope = slope_mean (x is then an
    offset). Newton steps from (0, slope_mean), halved until the objective rises;
    the objective is strictly concave, so this converges in a handful of steps.
    Returns (level, slope, converged); if it ever fails it returns the prior means.
    """
    s0, s1 = float(prior_sd[0]), float(prior_sd[1])
    theta = np.array([0.0, slope_mean])

    def objective(th):
        eta = th[0] + th[1] * x
        ll = float(np.sum(y * eta - np.logaddexp(0.0, eta)))
        return ll - th[0] ** 2 / (2 * s0 * s0) - ((th[1] - slope_mean) ** 2 / (2 * s1 * s1) if fit_slope else 0.0)

    obj = objective(theta)
    for _ in range(max_iter):
        eta = theta[0] + theta[1] * x
        p = _sigmoid(eta)
        r = y - p
        w = p * (1.0 - p)
        if fit_slope:
            g = np.array([r.sum() - theta[0] / s0 ** 2, (r * x).sum() - (theta[1] - slope_mean) / s1 ** 2])
            H = -np.array([[w.sum() + 1 / s0 ** 2, (w * x).sum()], [(w * x).sum(), (w * x * x).sum() + 1 / s1 ** 2]])
            try:
                step = -np.linalg.solve(H, g)
            except np.linalg.LinAlgError:
                return 0.0, slope_mean, False
        else:
            g0 = r.sum() - theta[0] / s0 ** 2
            step = np.array([g0 / (w.sum() + 1 / s0 ** 2), 0.0])
        if not np.all(np.isfinite(step)):
            return 0.0, slope_mean, False
        t = 1.0
        for _ in range(40):
            cand = theta + t * step
            c_obj = objective(cand)
            if c_obj >= obj - 1e-12:
                break
            t *= 0.5
        else:
            return 0.0, slope_mean, False
        theta, obj = cand, c_obj
        if float(np.max(np.abs(t * step))) < 1e-10:
            return float(theta[0]), float(theta[1]), True
    return 0.0, slope_mean, False


def recal_fit(x: np.ndarray, y: np.ndarray, fit_slope: bool = True) -> Tuple[float, float, bool]:
    """(a, b, converged): the pre-registered penalised fit of p = sigmoid(a + b x') to
    k checks, with a ~ Normal(0, 1) and b ~ Normal(0.5, 1). With no check it returns
    the prior means (0, 0.5). fit_slope=False is the level-only fit used when the
    standardising sd of x' is 0 (pre-registration 2.6, settled 23 Nov 2026): p =
    sigmoid(a), and b is returned as NaN (no slope was fitted)."""
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    if not fit_slope:
        if len(x) == 0:
            return 0.0, float("nan"), True
        a, _b, ok = _fit_logistic(np.zeros_like(x), y, fit_slope=False, prior_sd=(RECAL_LEVEL_SD, RECAL_SLOPE_SD),
                                  slope_mean=0.0)
        return a, float("nan"), ok
    if len(x) == 0:
        return 0.0, RECAL_SLOPE_MEAN, True
    return _fit_logistic(x, y, fit_slope=True, prior_sd=(RECAL_LEVEL_SD, RECAL_SLOPE_SD),
                         slope_mean=RECAL_SLOPE_MEAN)


def start_counts(p: float, n: float) -> dict:
    """The counter record of a probability p for an item with n old visits (pre-registration
    2.10, settled 23 Nov 2026): helpful = p (n + 2) - 1 and harmful = (1 - p)(n + 2) - 1, so
    that helpful + harmful = n and the smoothed mean (1 + helpful) / (2 + n) is exactly p.
    The counts may be fractional or negative; 1 + count stays positive for 0 < p < 1."""
    p, n = float(p), float(n)
    return {"helpful": p * (n + 2.0) - 1.0, "harmful": (1.0 - p) * (n + 2.0) - 1.0}


def recalibrate(
    bank: Bank,
    rule: ScoreRule,
    fresh_checks: Iterable[FreshCheck],
    prior: Optional[Tuple[float, float]] = None,
    r0: Optional[float] = None,
) -> Tuple[float, float, Bank]:
    """recal_k: logistic recalibration of the old scores from k fresh checks
    (pre-registration 2.6, the primary calibrated arm):

        p = sigmoid(a + b x')

    x' is the family score standardised over the owner's bank (`standardise`:
    z-score of q for ema_grade; logit of the fitted-prior posterior mean minus its bank
    mean for beta_grade and tags_self; z-score of c for credit; a z-score is centred on
    the bank mean and divided by the population sd over the items with at least one
    visit). (a, b) by penalised maximum likelihood on the k checks with priors
    a ~ N(0, 1), b ~ N(0.5, 1) (`recal_fit`); if the standardising sd is 0 the slope
    term is dropped and only a is fitted (b is then NaN). b = 0 means the old order
    carries no information, a is the level shift; b is read against the slope fitted the
    same way at home.

    Everyday meaning: "keep the old grades' order but re-read them for the new
    helper: the level says whether the new helper is better or worse overall,
    the slope says how much the old grades still tell".

    The new bank carries p in every record as "p_hat" (msr.scores.predicted_prob
    returns it; it is the arm's p and, inside the retrieval mix, its u). The score
    fields are the starting values of the run after the swap (pre-registration 2.10):
    value q = p; counter p (n + 2) - 1 successes (helpful) and (1 - p)(n + 2) - 1
    failures (harmful) with n the item's old visit count, so that the smoothed mean
    (1 + helpful) / (2 + n) is exactly p (the counts may be fractional or negative; the
    Beta parameters 1 + count stay positive); credit c = p - r0 (so that r0 + c = p)
    when r0 is given, else 2p - 1.
    `prior` = (a0, b0) of the counter families (fitted to the bank when None).
    Cox 1958; Steyerberg et al. 2004; Janssen et al. 2008.
    Returns (a, b, new_bank).
    """
    if not has_prob(rule):
        raise ValueError(f"recal needs a family with a standardised score; the {rule.name!r} rule has none")
    fresh = _check_fresh(fresh_checks)
    xp, slope_applies = standardise(bank, rule, prior)
    x = np.array([xp.get(i, 0.0) for i, _ in fresh], dtype=float)
    y = np.array([1.0 if ok else 0.0 for _, ok in fresh], dtype=float)
    level, slope, _ = recal_fit(x, y, fit_slope=slope_applies)
    out = {}
    for i, rec in bank.items():
        p = float(_sigmoid(level + (slope * xp[i] if slope_applies else 0.0)))
        o = copy.deepcopy(rec)
        if isinstance(rule, ValueScore):
            o["q"] = p
        elif isinstance(rule, CounterScore):
            o.update(start_counts(p, float(rec.get("visits", 0))))
        else:  # credit
            o["credit"] = p - float(r0) if r0 is not None else 2.0 * p - 1.0
        o["p_hat"] = p
        out[i] = o
    return level, slope, _tag(out, f"recal({level:.4g},{slope:.4g},k={len(fresh)})")


# ---------------------------------------------------------------------------
# audit: check k/4 calibration tasks, then choose keep or wipe
# ---------------------------------------------------------------------------


def _check_task_checks(checks: Iterable) -> List[Tuple[str, bool, object]]:
    """(item, success, task) triples; a pair (item, success) has task None."""
    out = []
    for n, chk in enumerate(checks):
        if isinstance(chk, (tuple, list)) and len(chk) == 3:
            item, ok, task = chk
        else:
            try:
                item, ok = chk
            except (TypeError, ValueError):
                raise ValueError(f"audit check #{n} must be (item_id, success, task_id), got {chk!r}") from None
            task = None
        (item, ok), = _check_fresh([(item, ok)])
        out.append((item, ok, task))
    return out


def audit_concordance(bank: Bank, rule: ScoreRule, task_checks: Iterable) -> Tuple[float, float]:
    """(numerator, weight) of the weighted concordance Cw of the OLD ranking scores on
    the audit's checks: within each task, every pair of checked candidates, weight
    |y_i - y_j| (1 when one worked and the other did not), credit 1 if the higher old
    score is the one that worked, 1/2 if the scores tie (within 1e-12), else 0
    (pre-registration 2.2 applied to one check per candidate)."""
    groups: Dict[object, List[Tuple[float, float]]] = {}
    for item, ok, task in _check_task_checks(task_checks):
        rec = bank.get(item)
        x = rule.score(rec if rec is not None else rule.new_record())
        groups.setdefault(task, []).append((float(x), 1.0 if ok else 0.0))
    num = den = 0.0
    for cells in groups.values():
        for a in range(len(cells)):
            for b in range(a + 1, len(cells)):
                (xa, ya), (xb, yb) = cells[a], cells[b]
                w = abs(ya - yb)
                if w <= SCORE_TIE_TOL:
                    continue
                den += w
                if abs(xa - xb) <= SCORE_TIE_TOL:
                    num += 0.5 * w
                elif (xa > xb) == (ya > yb):
                    num += w
    return num, den


def audit(bank: Bank, rule: ScoreRule, task_checks: Iterable) -> Tuple[str, Bank]:
    """audit_k (pre-registration 2.6): "k/4 calibration tasks drawn, all 4 candidates
    checked once; if Cw of the old scores on these checks > 0.5, use keep, otherwise
    wipe; no informative pair -> keep".

    Everyday meaning: "try every tip of a few jobs once with the new helper; if the
    old grades put the tips that worked above the ones that failed more often than a
    coin would, keep the grades, otherwise wipe them".

    `task_checks`: (item, success, task_id) triples (`msr.evaluate.draw_task_checks`
    then `pairs_of`); pairs without a task are compared as one group. Applies to every
    family (it needs only the ranking score). Returns (decision, bank) where bank is
    exactly `keep` or `wipe` of the old bank, tagged "audit(<decision>,k=..)".
    """
    checks = _check_task_checks(task_checks)
    if not checks:
        raise ValueError("audit needs at least one fresh check")
    num, den = audit_concordance(bank, rule, checks)
    decision = "keep" if den <= 0 or num / den > 0.5 else "wipe"
    out = keep(bank, rule) if decision == "keep" else wipe(bank, rule)
    return decision, _tag(out, f"audit({decision},k={len(checks)})")


# ---------------------------------------------------------------------------
# retest / pooled / fresh: fresh outcomes folded into the scores
# ---------------------------------------------------------------------------


def retest(
    bank: Bank,
    rule: ScoreRule,
    fresh_checks: Iterable,
    top: Optional[int] = None,
    new_model: Optional[str] = None,
    now=None,
) -> Bank:
    """retest_k (HEIRS style; pre-registration 2.6: "the k items with the highest old
    score among items that appear on a calibration task get one check each; each is
    re-scored from the start value with that check; all other items at the start value").

    Everyday meaning: "re-try the chosen favourite tips with the new helper
    and grade them on that alone; every other tip starts untried".
    top=None: the re-tested items are exactly the checked ones (the caller
    picked them: `msr.evaluate.draw_top_checks`); top=k: only checked items among the
    old top k by score are re-tested, as `retest_top` does. A re-tested item
    starts from the starting value and takes the rule's normal update for
    each of its fresh outcomes; every other item is reset.
    """
    fresh = _check_fresh_any(fresh_checks)
    chosen = {i for i, _, _ in fresh} if top is None else set(top_k_items(bank, rule, int(top)))
    out = {i: rule.reset_record(r) for i, r in bank.items()}
    for item, ok, base in fresh:
        if item in chosen and item in out:
            _fold(rule, out, item, ok, base, new_model, now)
    return _tag(out, f"retest(k={len(fresh)})")


def pooled(
    bank: Bank, rule: ScoreRule, fresh_checks: Iterable, new_model: Optional[str] = None, now=None
) -> Bank:
    """pooled_k (pre-registration 2.6): "the k checks added to the old scores at full
    weight with the family's own update".

    Everyday meaning: "keep the old grades and add the new helper's k results
    on top, as if they were more of the same".
    Each fresh outcome is added to its item's old score with the rule's
    normal update, in the order drawn (value: moving average; counter: success =
    helpful, failure = harmful; credit: outcome minus baseline; visits: one more
    visit). Checks on items not in the bank are ignored (content is fixed).
    """
    fresh = _check_fresh_any(fresh_checks)
    out = copy.deepcopy(bank)
    for item, ok, base in fresh:
        if item in out:
            _fold(rule, out, item, ok, base, new_model, now)
    return _tag(out, f"pooled(k={len(fresh)})")


def fresh_only(
    bank: Bank, rule: ScoreRule, fresh_checks: Iterable, new_model: Optional[str] = None, now=None
) -> Bank:
    """fresh_k (pre-registration 2.6): "every item at the start value, then the k
    checks added with the family's own update".

    Everyday meaning: "forget the old grades; grade the tips only on the new
    helper's k results". Checks on items not in the bank are ignored."""
    fresh = _check_fresh_any(fresh_checks)
    out = {i: rule.reset_record(r) for i, r in bank.items()}
    for item, ok, base in fresh:
        if item in out:
            _fold(rule, out, item, ok, base, new_model, now)
    return _tag(out, f"fresh(k={len(fresh)})")


#: Arms with no fresh checks, by base name: f(bank, rule, ...) -> bank.
#: fixed takes lam (default 0.5); shuffled takes seed (default 0).
ARMS_NO_CHECKS = {
    "keep": keep,
    "wipe": wipe,
    "fixed": fixed_discount,
    "shuffled": shuffled,
}

#: Arms that use fresh checks, by base name: f(bank, rule, fresh_checks, ...).
#: Returns: powerprior -> (lam, bank); recal -> (a, b, bank);
#: audit -> (decision, bank); retest, pooled, fresh -> bank.
#: So `result[-1] if isinstance(result, tuple) else result` is always the bank.
ARMS_WITH_CHECKS = {
    "powerprior": powerprior,
    "recal": recalibrate,
    "retest": retest,
    "audit": audit,
    "pooled": pooled,
    "fresh": fresh_only,
}
