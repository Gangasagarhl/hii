"""Score rules for memory items: how a tip earns its usefulness score, and how
scores are used to pick which tip to show.

Everyday picture: a mechanic's helper keeps a box of repair tips. Each tip has a
score that says how often it helped. This file holds the two ways of keeping
that score (a "value" and a pair of "counters"), the rule that mixes score with
"how close is this tip to the job at hand" to pick a tip, and saving the box of
scores to a file.

What a "bank" is here
---------------------
A bank is a plain dict:  item_id (a string)  ->  record (a dict).
The record holds the score fields of ONE rule, plus two audit fields:
    "model"            the model whose outcomes last changed this score (None = never)
    "earned_at"        when that happened (UTC time, ISO text; None = never)
    "evidence_models"  every model whose outcomes are inside this score
Any other keys a caller puts in a record (for example the tip's text) are copied
along untouched. Memory content is never changed by anything in this package;
only the score fields move.

The two rules
-------------
ValueScore  (MemRL style)   q starts at 0.5, then q <- q + 0.3 * (reward - q).
CounterScore (ACE style)    count how often the tip was marked helpful / harmful.

Two more families from the master plan (section 2.5):
CreditScore  (MemCredit style) running mean of success WITH the tip minus
                               success WITHOUT it on the same task.
VisitScore   (baseline)        how often the tip was shown; no usefulness signal.

`predicted_prob` gives the success chance p a record implies (pre-registration
Part 0.4: value, counter, and credit given the owner's r0), `standardised_scores`
gives the x' the recalibration arm uses, and `fit_beta_prior` fits the
empirical-Bayes Beta prior that the power-prior swap-day rule in arms.py starts from.

Both are pure Python + numpy and deterministic. The only randomness (the
exploration option in `choose`) comes from a seeded numpy generator.
"""

from __future__ import annotations

import copy
import json
import math
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Dict, List, Mapping, NamedTuple, Optional, Sequence, Tuple, Union

import numpy as np

Bank = Dict[str, dict]

#: Version tag written into every saved bank file, so old files can be recognised.
BANK_FORMAT = "msr-score-bank/1"

#: Exploration rate the study design asks for while BUILDING banks
#: (design note D section 4: "drawn at random from the top similarity candidates
#: with probability 0.3"). It is NOT the default of `choose`; pass it explicitly.
DESIGN_BUILD_EPSILON = 0.3

#: Tolerance used when deciding two scores are "equal" (ties).
SCORE_TIE_TOL = 1e-12


def _now_iso(now: Union[None, str, datetime] = None) -> str:
    """Time stamp as ISO text in UTC. Pass `now` to make output reproducible."""
    if now is None:
        return datetime.now(timezone.utc).isoformat(timespec="seconds")
    if isinstance(now, datetime):
        if now.tzinfo is None:
            now = now.replace(tzinfo=timezone.utc)
        return now.isoformat(timespec="seconds")
    return str(now)


def _mark_earned(rec: dict, model: Optional[str], now) -> None:
    """Write down which model earned this score and when."""
    rec["model"] = model
    rec["earned_at"] = _now_iso(now)
    seen = list(rec.get("evidence_models") or [])
    if model is not None and model not in seen:
        seen.append(model)
    rec["evidence_models"] = seen


# ---------------------------------------------------------------------------
# Base class: what every score rule must offer
# ---------------------------------------------------------------------------


class ScoreRule:
    """Common shape of a score rule.

    Every rule can: make a fresh record, update it after an episode, give the
    score used for ranking, give a score squeezed into [0, 1] for mixing with
    relevance, say how much "evidence" the score carries (pseudo-counts), and
    reset or discount a record on swap day.
    """

    name: str = "base"
    #: The record keys that ARE the score (everything else is left alone).
    score_fields: Tuple[str, ...] = ()

    # --- records -----------------------------------------------------------
    def start_scores(self) -> dict:
        """The score fields at their starting values."""
        raise NotImplementedError

    def new_record(self) -> dict:
        """A brand-new record: starting scores, never earned by any model."""
        rec = dict(self.start_scores())
        rec.update({"model": None, "earned_at": None, "evidence_models": []})
        return rec

    def reset_record(self, rec: dict) -> dict:
        """Copy of `rec` with the score back at its starting value.
        Everyday meaning: forget how well the tip did, keep the tip itself."""
        out = copy.deepcopy(rec)
        out.update(self.start_scores())
        out.update({"model": None, "earned_at": None, "evidence_models": []})
        return out

    def discount_record(self, rec: dict, lam: float) -> dict:
        """Copy of `rec` with its evidence weakened by factor lam (0..1)."""
        raise NotImplementedError

    # --- updating ----------------------------------------------------------
    def update(self, bank: Bank, item_id: str, outcome, model: Optional[str] = None, now=None):
        raise NotImplementedError

    # --- reading -----------------------------------------------------------
    def score(self, rec: dict) -> float:
        """The value used when ranking by score alone."""
        raise NotImplementedError

    def normalised(self, rec: dict) -> float:
        """The score squeezed into [0, 1], used inside the relevance mix."""
        raise NotImplementedError

    def pseudo_counts(self, rec: dict) -> Tuple[float, float]:
        """The score's evidence written as (pseudo-successes, pseudo-failures),
        used by the calibrated power-prior rule in arms.py."""
        raise NotImplementedError

    def scores(self, bank: Bank) -> Dict[str, float]:
        """{item_id: ranking score} for the whole bank."""
        return {i: float(self.score(r)) for i, r in bank.items()}

    def normalised_scores(self, bank: Bank) -> Dict[str, float]:
        """{item_id: score in [0, 1]} for the whole bank (feed this to `rank`)."""
        return {i: float(self.normalised(r)) for i, r in bank.items()}

    def to_dict(self) -> dict:
        """Settings of the rule, written into saved bank files."""
        raise NotImplementedError

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        return f"{type(self).__name__}({self.to_dict()})"


# ---------------------------------------------------------------------------
# Rule 1: MemRL-style value
# ---------------------------------------------------------------------------


class ValueScore(ScoreRule):
    """MemRL-style value: a moving average of success.

    Everyday meaning: the tip's grade starts at "50/50" and, every time the tip
    is shown, moves 30 % of the way toward what just happened (1 = the job was
    solved, 0 = it was not).

        q starts at Q0 = 0.5
        after an episode where the item was shown:  q <- q + alpha * (r - q)
        alpha = 0.3, r = 1 for success, r = 0 for failure

    These numbers match MemRL's released code and configuration:
    `memrl/service/value_driven.py` line 195 (moving average with alpha 0.3,
    gamma 0), `rl_llb_config.yaml` q_init_pos = q_init_neg = 0.5, and
    failure_reward = 0.0 (see docs/checks_2026-11-17/repos_and_data.md 2.2).
    NOTE: the older design note (D section 1.4) says Q_init = 0; the released
    configuration says 0.5, and 0.5 is used here.

    Fields kept per item: q, visits (times shown), successes, failures.
    The raw successes/failures are kept for audit; the calibrated rule uses
    q and visits as instructed (see `pseudo_counts`).
    """

    name = "value"
    score_fields = ("q", "visits", "successes", "failures")

    def __init__(self, alpha: float = 0.3, q0: float = 0.5):
        if not (0.0 < alpha <= 1.0):
            raise ValueError("alpha must be in (0, 1]")
        if not (0.0 <= q0 <= 1.0):
            raise ValueError("q0 must be in [0, 1]")
        self.alpha = float(alpha)
        self.q0 = float(q0)

    def start_scores(self) -> dict:
        return {"q": self.q0, "visits": 0, "successes": 0, "failures": 0}

    def update(self, bank: Bank, item_id: str, outcome, model: Optional[str] = None, now=None) -> float:
        """One episode in which `item_id` was shown. `outcome` True = success.
        Creates the record at the starting value if the item is new.
        Returns the new q."""
        if not isinstance(outcome, (bool, np.bool_)) and outcome not in (0, 1):
            raise ValueError(f"ValueScore.update needs a success True/False, got {outcome!r}")
        rec = bank.get(item_id)
        if rec is None:
            rec = bank[item_id] = self.new_record()
        r = 1.0 if bool(outcome) else 0.0
        rec["q"] = float(rec["q"]) + self.alpha * (r - float(rec["q"]))
        rec["visits"] = rec.get("visits", 0) + 1
        if r == 1.0:
            rec["successes"] = rec.get("successes", 0) + 1
        else:
            rec["failures"] = rec.get("failures", 0) + 1
        _mark_earned(rec, model, now)
        return rec["q"]

    def score(self, rec: dict) -> float:
        return float(rec["q"])

    def normalised(self, rec: dict) -> float:
        # q is already a number between 0 and 1 because rewards are 0 or 1.
        return float(min(1.0, max(0.0, rec["q"])))

    def pseudo_counts(self, rec: dict) -> Tuple[float, float]:
        """Value turned into evidence: q*n pseudo-successes and (1-q)*n
        pseudo-failures, n = visits. Everyday meaning: "a 0.8 tip seen 10 times
        counts like 8 wins and 2 losses"."""
        n = float(rec.get("visits", 0))
        q = float(rec["q"])
        return q * n, (1.0 - q) * n

    def discount_record(self, rec: dict, lam: float) -> dict:
        """q' = Q0 + lam * (q - Q0): pull the grade lam of the way back from
        "50/50". The visit, success and failure counts are multiplied by lam as
        well (they become "effective" counts), so lam = 0 is exactly a wipe and
        lam = 1 is exactly keep."""
        lam = _check_lam(lam)
        out = copy.deepcopy(rec)
        out["q"] = self.q0 + lam * (float(rec["q"]) - self.q0)
        for f in ("visits", "successes", "failures"):
            out[f] = lam * rec.get(f, 0)
        if lam == 0.0:
            out.update({"model": None, "earned_at": None, "evidence_models": []})
        return out

    def to_dict(self) -> dict:
        return {"name": self.name, "alpha": self.alpha, "q0": self.q0}


# ---------------------------------------------------------------------------
# Rule 2: ACE-style counters
# ---------------------------------------------------------------------------


def _net(helpful: float, harmful: float) -> float:
    """helpful minus harmful. Everyday meaning: "votes for minus votes against"."""
    return float(helpful) - float(harmful)


def _smoothed(helpful: float, harmful: float) -> float:
    """(helpful + 1) / (helpful + harmful + 2), the mean of a Beta(1, 1) prior
    updated with the counts. Everyday meaning: "share of good votes, starting
    from one imaginary vote each way, so a tip with no votes sits at 0.5"."""
    return (float(helpful) + 1.0) / (float(helpful) + float(harmful) + 2.0)


#: The named, swappable ways of turning counters into a ranking value.
#: ACE's own code keeps the counts but never ranks by them, so the choice is
#: ours. WHICH ONE IS USED MUST BE FIXED IN THE DATED PREDICTION FILE before
#: the first paid run, because it changes every concordance number.
COUNTER_RANKINGS: Dict[str, Callable[[float, float], float]] = {
    "net": _net,
    "smoothed": _smoothed,
}


class CounterScore(ScoreRule):
    """ACE-style counters: helpful and harmful marks per item.

    Everyday meaning: every time the tip is used, the helper says "this helped"
    or "this misled me", and we keep a tally of both.

    Fields kept per item: helpful, harmful, visits (times shown, including
    "neutral" marks). After a swap-day discount the counts can become
    fractions (for example 0.5 * 3 = 1.5); that is intended.

    Ranking value: chosen by name from COUNTER_RANKINGS, default "net"
    (helpful - harmful). The value used inside the relevance mix is always the
    smoothed mean, because the mix needs a number between 0 and 1.
    """

    name = "counter"
    score_fields = ("helpful", "harmful", "visits")

    def __init__(self, ranking: str = "net"):
        if ranking not in COUNTER_RANKINGS:
            raise ValueError(f"unknown counter ranking {ranking!r}; choose from {sorted(COUNTER_RANKINGS)}")
        self.ranking = ranking
        self._rank_fn = COUNTER_RANKINGS[ranking]

    def start_scores(self) -> dict:
        return {"helpful": 0, "harmful": 0, "visits": 0}

    def update(self, bank: Bank, item_id: str, outcome, model: Optional[str] = None, now=None) -> Tuple[float, float]:
        """One mark for `item_id`. `outcome` may be "helpful", "harmful",
        "neutral", or True (= helpful) / False (= harmful) / None (= neutral).
        Returns (helpful, harmful) after the update."""
        if outcome is True or outcome == "helpful" or (isinstance(outcome, np.bool_) and bool(outcome)):
            mark = "helpful"
        elif outcome is False or outcome == "harmful" or (isinstance(outcome, np.bool_) and not bool(outcome)):
            mark = "harmful"
        elif outcome is None or outcome == "neutral":
            mark = "neutral"
        elif outcome in (0, 1):
            mark = "helpful" if outcome == 1 else "harmful"
        else:
            raise ValueError(f"CounterScore.update needs helpful/harmful/neutral, got {outcome!r}")
        rec = bank.get(item_id)
        if rec is None:
            rec = bank[item_id] = self.new_record()
        if mark != "neutral":
            rec[mark] = rec.get(mark, 0) + 1
        rec["visits"] = rec.get("visits", 0) + 1
        _mark_earned(rec, model, now)
        return rec["helpful"], rec["harmful"]

    def score(self, rec: dict) -> float:
        return float(self._rank_fn(rec.get("helpful", 0), rec.get("harmful", 0)))

    def normalised(self, rec: dict) -> float:
        return _smoothed(rec.get("helpful", 0), rec.get("harmful", 0))

    def pseudo_counts(self, rec: dict) -> Tuple[float, float]:
        """Helpful marks count as pseudo-successes, harmful as pseudo-failures."""
        return float(rec.get("helpful", 0)), float(rec.get("harmful", 0))

    def discount_record(self, rec: dict, lam: float) -> dict:
        """Multiply both counts (and visits) by lam: a power prior with weight
        lam. Everyday meaning: "each old vote now counts as lam of a vote"."""
        lam = _check_lam(lam)
        out = copy.deepcopy(rec)
        for f in ("helpful", "harmful", "visits"):
            out[f] = lam * rec.get(f, 0)
        if lam == 0.0:
            out.update({"model": None, "earned_at": None, "evidence_models": []})
        return out

    def to_dict(self) -> dict:
        return {"name": self.name, "ranking": self.ranking}


def _check_lam(lam: float) -> float:
    lam = float(lam)
    if not (0.0 <= lam <= 1.0) or math.isnan(lam):
        raise ValueError(f"lam must be between 0 and 1, got {lam}")
    return lam


# ---------------------------------------------------------------------------
# Rule 3: "with minus without" credit (added for master plan 2.5)
# ---------------------------------------------------------------------------


def _unit_number(x, what: str) -> float:
    """A number between 0 and 1. True / False count as 1 / 0."""
    if isinstance(x, (bool, np.bool_)):
        return 1.0 if bool(x) else 0.0
    try:
        v = float(x)
    except (TypeError, ValueError):
        raise ValueError(f"{what} must be a number between 0 and 1, got {x!r}") from None
    if math.isnan(v) or not (0.0 <= v <= 1.0):
        raise ValueError(f"{what} must be between 0 and 1, got {x!r}")
    return v


class CreditScore(ScoreRule):
    """Credit: success WITH the tip minus success WITHOUT it, on the same task.

    Everyday meaning: "with the tip the job went right; the same helper, on the
    same job, with no tip, got it right half the time; so the tip earned +0.5".
    The score is the running mean of those differences over every visit.

        credit starts at 0 (no visits = no evidence either way)
        after a visit:  d = outcome - baseline        (both between 0 and 1)
                        credit <- credit + (d - credit) / visits
    `baseline` is the SAME model's no-memory result on the SAME task (0/1, or a
    success rate over repeats). It defaults to 0, which turns the credit into a
    plain success rate; pass the real baseline whenever it is known.

    Stands for MemCredit and the Causal Memory Policy (master plan 2.5).
    Fields kept per item: credit (between -1 and 1), visits.
    Credit has no success probability, so `pseudo_counts` is None and the
    probability-based swap-day rules (power prior, recalibration, audit) do
    not apply to it.
    """

    name = "credit"
    score_fields = ("credit", "visits")

    def start_scores(self) -> dict:
        return {"credit": 0.0, "visits": 0}

    def update(self, bank: Bank, item_id: str, outcome, model: Optional[str] = None, now=None, baseline=0.0) -> float:
        """One visit of `item_id`. `outcome` and `baseline` are 0..1 (True/False
        allowed). Creates the record if the item is new. Returns the new credit."""
        y = _unit_number(outcome, "CreditScore.update outcome")
        b = _unit_number(baseline, "CreditScore.update baseline")
        rec = bank.get(item_id)
        if rec is None:
            rec = bank[item_id] = self.new_record()
        n = float(rec.get("visits", 0)) + 1.0
        c = float(rec.get("credit", 0.0))
        rec["credit"] = c + ((y - b) - c) / n
        rec["visits"] = rec.get("visits", 0) + 1
        _mark_earned(rec, model, now)
        return rec["credit"]

    def score(self, rec: dict) -> float:
        return float(rec.get("credit", 0.0))

    def normalised(self, rec: dict) -> float:
        """(credit + 1) / 2: -1 -> 0, 0 -> 0.5, +1 -> 1."""
        return float(min(1.0, max(0.0, (float(rec.get("credit", 0.0)) + 1.0) / 2.0)))

    def pseudo_counts(self, rec: dict) -> None:
        """None: a difference of two success rates is not a win/loss count."""
        return None

    def discount_record(self, rec: dict, lam: float) -> dict:
        """credit' = lam * credit (pulled toward the start value 0) and
        visits' = lam * visits, so lam = 0 is a wipe and lam = 1 is keep.
        Everyday meaning: "each old visit now counts as lam of a visit"."""
        lam = _check_lam(lam)
        out = copy.deepcopy(rec)
        out["credit"] = lam * float(rec.get("credit", 0.0))
        out["visits"] = lam * rec.get("visits", 0)
        if lam == 0.0:
            out.update({"model": None, "earned_at": None, "evidence_models": []})
        return out

    def to_dict(self) -> dict:
        return {"name": self.name}


# ---------------------------------------------------------------------------
# Rule 4: visits (popularity baseline, no usefulness signal)
# ---------------------------------------------------------------------------


class VisitScore(ScoreRule):
    """Visits: how often the tip was shown. A baseline with no usefulness signal.

    Everyday meaning: "the tip the old helper pulled out most often". It only
    counts; whether the job went right is ignored.
    Ranking score: visits. Value for the relevance mix: visits / the largest
    visit count in the bank (0 for every item when nothing was ever shown).
    That share depends on the whole bank, so use `normalised_scores(bank)`.
    """

    name = "visits"
    score_fields = ("visits",)

    def start_scores(self) -> dict:
        return {"visits": 0}

    def update(self, bank: Bank, item_id: str, outcome=None, model: Optional[str] = None, now=None, baseline=None):
        """Count one visit of `item_id`. `outcome` and `baseline` are accepted
        so every rule can be called the same way, and are ignored.
        Returns the new visit count."""
        rec = bank.get(item_id)
        if rec is None:
            rec = bank[item_id] = self.new_record()
        rec["visits"] = rec.get("visits", 0) + 1
        _mark_earned(rec, model, now)
        return rec["visits"]

    def score(self, rec: dict) -> float:
        return float(rec.get("visits", 0))

    def normalised(self, rec: dict, max_visits: Optional[float] = None) -> float:
        """visits / max_visits. The share needs the bank's largest count, so
        `max_visits` must be given (or use `normalised_scores(bank)`)."""
        if max_visits is None:
            raise ValueError("VisitScore.normalised needs max_visits; use normalised_scores(bank)")
        mx = float(max_visits)
        return float(rec.get("visits", 0)) / mx if mx > 0 else 0.0

    def normalised_scores(self, bank: Bank) -> Dict[str, float]:
        """{item_id: visits / max visits} (0 for all when no item has a visit)."""
        mx = max((float(r.get("visits", 0)) for r in bank.values()), default=0.0)
        return {i: self.normalised(r, mx) for i, r in bank.items()}

    def pseudo_counts(self, rec: dict) -> None:
        """None: a visit count says nothing about success."""
        return None

    def discount_record(self, rec: dict, lam: float) -> dict:
        """visits' = lam * visits. The shares visits / max do not change unless
        lam = 0 (then every item is at 0, exactly a wipe)."""
        lam = _check_lam(lam)
        out = copy.deepcopy(rec)
        out["visits"] = lam * rec.get("visits", 0)
        if lam == 0.0:
            out.update({"model": None, "earned_at": None, "evidence_models": []})
        return out

    def to_dict(self) -> dict:
        return {"name": self.name}


def rule_from_dict(d: Mapping) -> ScoreRule:
    """Rebuild a rule from the settings saved in a bank file."""
    name = d.get("name")
    if name == "value":
        return ValueScore(alpha=d.get("alpha", 0.3), q0=d.get("q0", 0.5))
    if name == "counter":
        return CounterScore(ranking=d.get("ranking", "net"))
    if name == "credit":
        return CreditScore()
    if name == "visits":
        return VisitScore()
    raise ValueError(f"unknown score rule {name!r}")


# ---------------------------------------------------------------------------
# Success probability implied by a record (for log score and Brier)
# ---------------------------------------------------------------------------

#: Probabilities are kept inside [0.01, 0.99] when scored (pre-registration 0.3 and 2.6:
#: "All p are clipped to [0.01, 0.99]"; config key evaluate.prob_clip), so one confident
#: miss cannot send the log score to minus infinity.
PROB_CLIP: Tuple[float, float] = (0.01, 0.99)


def clip_prob(p: float, clip: Optional[Tuple[float, float]] = PROB_CLIP) -> float:
    """p clipped to [clip[0], clip[1]] (no clip when `clip` is None)."""
    p = float(p)
    return p if clip is None else float(min(clip[1], max(clip[0], p)))


def predicted_prob(rule: ScoreRule, rec: Optional[dict], r0: Optional[float] = None,
                   clip: Optional[Tuple[float, float]] = PROB_CLIP) -> Optional[float]:
    """The chance of success p that a rule's record implies (pre-registration Part 0.4), or None.

    Everyday meaning: "if this tip is shown, how likely is the job to go right,
    according to its score?"
        value rule    (ema_grade)  q
        counter rule  (beta_grade, tags_self)  (helpful + 1) / (helpful + harmful + 2)
        credit rule   r0 + c, where r0 is the OWNER's no-memory success over its score
                      tasks; only when r0 is given (None otherwise: c alone is a
                      difference of two success rates, not a chance)
        visits        None (no usefulness signal, never scored by log score or Brier)
    The result is clipped to `clip` (default [0.01, 0.99]; pass clip=None for the raw
    value). A missing record (None) is read as a brand-new record.
    A record that a recalibration wrote carries its probability in "p_hat"; that value
    is returned for every rule (it is the arm's p by definition).
    """
    if rec is None:
        rec = rule.new_record()
    if rec.get("p_hat") is not None:
        return clip_prob(rec["p_hat"], clip)
    if isinstance(rule, ValueScore):
        return clip_prob(rec["q"], clip)
    if isinstance(rule, CounterScore):
        return clip_prob(_smoothed(rec.get("helpful", 0), rec.get("harmful", 0)), clip)
    if isinstance(rule, CreditScore) and r0 is not None:
        return clip_prob(float(r0) + float(rec.get("credit", 0.0)), clip)
    return None


def has_prob(rule: ScoreRule) -> bool:
    """True if the family has a predicted success p (every family but visits; credit
    needs the owner's r0 for it)."""
    return isinstance(rule, (ValueScore, CounterScore, CreditScore))


def has_counts(rule: ScoreRule) -> bool:
    """True if the family's evidence can be written as Beta pseudo-counts (value and
    counter rules): the power prior needs this."""
    return isinstance(rule, (ValueScore, CounterScore))


def _zscore(v: np.ndarray, visited: Optional[np.ndarray] = None) -> Tuple[np.ndarray, float]:
    """((v - bank mean) / sd, sd): centred on the mean over EVERY item of the bank and
    divided by the population sd (ddof = 0) over the items with at least one score-phase
    visit (`visited`; every item when None), as pre-registration 2.6 states (settled
    23 Nov 2026). All 0 when that sd is 0 (or no item was visited)."""
    v = np.asarray(v, dtype=float)
    w = v if visited is None else v[np.asarray(visited, dtype=bool)]
    sd = float(w.std()) if w.size else 0.0
    return ((v - v.mean()) / sd if sd > 0 else np.zeros_like(v)), sd


def standardise(bank: Bank, rule: ScoreRule, prior: Optional[Tuple[float, float]] = None
                ) -> Tuple[Dict[str, float], bool]:
    """({item: x'}, slope_applies): the family score standardised over the owner's bank,
    as the recalibration arm uses it (pre-registration 2.6, `recal_k`):

        value   (ema_grade)               z-score of q
        counter (beta_grade, tags_self)   logit of the fitted-prior posterior mean
                                          (a0 + s) / (a0 + b0 + n), minus its bank mean
        credit                            z-score of c

    A z-score is centred on the bank mean (every item; an item never shown keeps its
    start value and is part of the bank) and divided by the population standard
    deviation over the bank's items with at least one score-phase visit. If that
    standard deviation is 0, x' is 0 for every item and `slope_applies` is False: the
    recalibration then fits the level only (the slope term is dropped). The counter
    families' x' has no standardising sd, so their slope always applies. (a0, b0) is the
    Beta prior fitted to the bank (`fit_beta_prior`), or `prior` if given.
    Raises ValueError for the visits family (no x' is defined for it)."""
    items = list(bank)
    visited = np.array([float(bank[i].get("visits", 0) or 0) > 0 for i in items], dtype=bool)
    slope_applies = True
    if isinstance(rule, ValueScore):
        z, sd = _zscore([float(bank[i]["q"]) for i in items], visited)
        slope_applies = sd > 0
    elif isinstance(rule, CreditScore):
        z, sd = _zscore([float(bank[i].get("credit", 0.0)) for i in items], visited)
        slope_applies = sd > 0
    elif isinstance(rule, CounterScore):
        a0, b0 = fit_beta_prior(bank, rule) if prior is None else (float(prior[0]), float(prior[1]))
        s = np.array([float(bank[i].get("helpful", 0)) for i in items])
        f = np.array([float(bank[i].get("harmful", 0)) for i in items])
        m = (a0 + s) / (a0 + b0 + s + f)
        lg = np.log(m) - np.log1p(-m)
        z = lg - lg.mean()
    else:
        raise ValueError(f"the {rule.name!r} rule has no standardised score x' (recalibration does not apply)")
    return {i: float(v) for i, v in zip(items, z)}, bool(slope_applies)


def standardised_scores(bank: Bank, rule: ScoreRule, prior: Optional[Tuple[float, float]] = None) -> Dict[str, float]:
    """{item: x'} of `standardise` (the flag that says whether the slope applies is
    dropped; use `standardise` when it matters)."""
    return standardise(bank, rule, prior)[0]


# ---------------------------------------------------------------------------
# Empirical-Bayes Beta prior fitted to a bank (Efron-Morris step)
# ---------------------------------------------------------------------------

#: Bounds on the fitted prior's two numbers, a0 and b0.
BETA_PRIOR_BOUNDS: Tuple[float, float] = (0.05, 200.0)

#: Below this many visited items the bank is too small to fit a prior.
MIN_ITEMS_FOR_PRIOR = 5

_HALF_LOG_2PI = 0.5 * math.log(2.0 * math.pi)


def _shift_up(x, until: float = 8.0):
    """Add 1 to every value below `until` until none is left (at most 9 times).
    Returns the shifted values and, for each round, (mask, values before), so
    the recurrences of the gamma-type functions can undo the shift."""
    z = np.array(x, dtype=float, copy=True)
    steps = []
    for _ in range(int(until) + 1):
        small = z < until
        if not small.any():
            break
        steps.append((small, z.copy()))
        z = np.where(small, z + 1.0, z)
    return z, steps


def _lgamma_np(x) -> np.ndarray:
    """log Gamma(x) for x > 0, element-wise (numpy has no lgamma: Stirling's
    series after shifting x to at least 8; error below 1e-11)."""
    z, steps = _shift_up(x)
    acc = np.zeros_like(z)
    for small, before in steps:
        acc = acc + np.where(small, np.log(np.where(small, before, 1.0)), 0.0)
    zi = 1.0 / z
    zi2 = zi * zi
    series = zi * (1.0 / 12 - zi2 * (1.0 / 360 - zi2 * (1.0 / 1260 - zi2 / 1680)))
    return (z - 0.5) * np.log(z) - z + _HALF_LOG_2PI + series - acc


def _digamma_np(x) -> np.ndarray:
    """psi(x) = d/dx log Gamma(x), element-wise, for x > 0."""
    z, steps = _shift_up(x)
    acc = np.zeros_like(z)
    for small, before in steps:
        acc = acc + np.where(small, 1.0 / np.where(small, before, 1.0), 0.0)
    zi = 1.0 / z
    zi2 = zi * zi
    series = zi2 * (1.0 / 12 - zi2 * (1.0 / 120 - zi2 * (1.0 / 252 - zi2 / 240)))
    return np.log(z) - 0.5 * zi - series - acc


def _trigamma_np(x) -> np.ndarray:
    """psi'(x), element-wise, for x > 0."""
    z, steps = _shift_up(x)
    acc = np.zeros_like(z)
    for small, before in steps:
        b = np.where(small, before, 1.0)
        acc = acc + np.where(small, 1.0 / (b * b), 0.0)
    zi = 1.0 / z
    zi2 = zi * zi
    series = zi + 0.5 * zi2 + zi * zi2 * (1.0 / 6 - zi2 * (1.0 / 30 - zi2 * (1.0 / 42 - zi2 / 30)))
    return series + acc


def _bb_loglik(a: float, b: float, s: np.ndarray, f: np.ndarray) -> float:
    """Beta-binomial log likelihood of per-item counts (s_i, f_i) under a
    Beta(a, b) prior, without the binomial coefficients (they do not depend
    on a or b): sum_i [log B(a + s_i, b + f_i) - log B(a, b)]."""
    lb0 = math.lgamma(a) + math.lgamma(b) - math.lgamma(a + b)
    terms = _lgamma_np(a + s) + _lgamma_np(b + f) - _lgamma_np(a + b + s + f)
    return float(terms.sum() - len(s) * lb0)


def _bb_grad_hess(a: float, b: float, s: np.ndarray, f: np.ndarray):
    """Gradient and Hessian of `_bb_loglik` in (log a, log b)."""
    N = len(s)
    n = s + f
    one = lambda fn, v: float(fn(np.array([v]))[0])  # noqa: E731 - scalar call
    d_n = _digamma_np(a + b + n).sum()
    t_n = _trigamma_np(a + b + n).sum()
    g_a = float(_digamma_np(a + s).sum() - d_n - N * (one(_digamma_np, a) - one(_digamma_np, a + b)))
    g_b = float(_digamma_np(b + f).sum() - d_n - N * (one(_digamma_np, b) - one(_digamma_np, a + b)))
    t_ab = one(_trigamma_np, a + b)
    h_aa = float(_trigamma_np(a + s).sum() - t_n - N * (one(_trigamma_np, a) - t_ab))
    h_bb = float(_trigamma_np(b + f).sum() - t_n - N * (one(_trigamma_np, b) - t_ab))
    h_ab = float(-t_n + N * t_ab)
    g = np.array([a * g_a, b * g_b])
    H = np.array([[a * a * h_aa + a * g_a, a * b * h_ab], [a * b * h_ab, b * b * h_bb + b * g_b]])
    return g, H


def _visited_counts(bank: Bank, rule: ScoreRule) -> Tuple[np.ndarray, np.ndarray]:
    """(s, f) arrays of pseudo-counts for the items with any evidence."""
    if rule.pseudo_counts(rule.new_record()) is None:
        raise ValueError(f"the {rule.name!r} rule has no pseudo-counts, so no Beta prior can be fitted to it")
    s_list, f_list = [], []
    for rec in bank.values():
        s, f = rule.pseudo_counts(rec)
        s, f = max(0.0, float(s)), max(0.0, float(f))
        if s + f > 0:
            s_list.append(s)
            f_list.append(f)
    return np.array(s_list, dtype=float), np.array(f_list, dtype=float)


def _moments_start(s: np.ndarray, f: np.ndarray) -> Tuple[float, float]:
    """Method-of-moments starting point for the beta-binomial fit.

    Mean m = total successes / total evidence. The spread of the per-item rates
    is Var = m(1-m) * [rho + (1 - rho) * mean(1/n)], with rho = 1 / (a0 + b0 + 1),
    so rho (and from it a0 + b0) is read off the observed spread."""
    lo, hi = BETA_PRIOR_BOUNDS
    n = s + f
    m = float(min(1 - 1e-3, max(1e-3, s.sum() / n.sum())))
    var = float((s / n).var())
    h = float(np.mean(1.0 / n))
    rho = (var / (m * (1.0 - m)) - h) / (1.0 - h) if h < 1.0 - 1e-12 else float("nan")
    if not math.isfinite(rho):
        M = 2.0
    elif rho <= 1.0 / (hi + 1.0):
        M = hi / max(m, 1.0 - m)  # almost no extra spread: as concentrated as allowed
    elif rho >= 1.0 / (lo + 1.0):
        M = 2.0 * lo / min(m, 1.0 - m)
    else:
        M = 1.0 / rho - 1.0
    a = float(min(hi, max(lo, m * M)))
    b = float(min(hi, max(lo, (1.0 - m) * M)))
    return a, b


def fit_beta_prior(bank: Bank, rule: ScoreRule) -> Tuple[float, float]:
    """Empirical-Bayes Beta(a0, b0) prior fitted to the bank's pseudo-counts.

    Everyday meaning: "before judging any one tip, look at how good tips in
    this box usually are and how much they differ". A tip seen twice is then
    pulled toward the typical tip instead of being taken at face value
    (Efron and Morris 1975; statistics note Q5, step 1). Without this step a
    flat Beta(1, 1) start drives the power-prior weight to about 0.2 even when
    the model did not change.

    Method: beta-binomial maximum likelihood over the items with any evidence
    (pseudo-counts from `rule.pseudo_counts`: counters give (helpful, harmful),
    values give (q * visits, (1 - q) * visits)); started from the method of
    moments and refined by Newton steps in (log a0, log b0) with a line search,
    keeping a0 and b0 inside [0.05, 200]. Items with no evidence add nothing to
    the likelihood. With fewer than 5 visited items it returns (1.0, 1.0).
    Raises ValueError for rules without pseudo-counts (credit, visits).
    """
    s, f = _visited_counts(bank, rule)
    if len(s) < MIN_ITEMS_FOR_PRIOR:
        return 1.0, 1.0
    # The same old bank is refitted for every random draw of fresh checks, so
    # results are remembered by the evidence itself (not by the bank object).
    key = (s.tobytes(), f.tobytes())
    hit = _PRIOR_CACHE.get(key)
    if hit is None:
        hit = _fit_beta_ml(s, f)
        if len(_PRIOR_CACHE) >= 64:
            _PRIOR_CACHE.pop(next(iter(_PRIOR_CACHE)))
        _PRIOR_CACHE[key] = hit
    return hit


_PRIOR_CACHE: Dict[Tuple[bytes, bytes], Tuple[float, float]] = {}


def _fit_beta_ml(s: np.ndarray, f: np.ndarray) -> Tuple[float, float]:
    """The beta-binomial maximum-likelihood fit behind `fit_beta_prior`."""
    lo, hi = math.log(BETA_PRIOR_BOUNDS[0]), math.log(BETA_PRIOR_BOUNDS[1])
    a, b = _moments_start(s, f)
    u = np.array([math.log(a), math.log(b)])
    ll = _bb_loglik(a, b, s, f)
    for _ in range(200):
        g, H = _bb_grad_hess(math.exp(u[0]), math.exp(u[1]), s, f)
        # A number sitting on a bound whose slope points outward stays put.
        pinned = ((u <= lo + 1e-12) & (g < 0)) | ((u >= hi - 1e-12) & (g > 0))
        free = ~pinned
        if not free.any():
            break
        gf, Hf = g[free], H[np.ix_(free, free)]
        d = np.zeros(2)
        try:
            concave = bool(np.all(np.linalg.eigvalsh(Hf) < 0))
        except np.linalg.LinAlgError:
            concave = False
        if concave:
            d[free] = -np.linalg.solve(Hf, gf)  # Newton step
        else:
            d[free] = gf / max(1.0, float(np.linalg.norm(gf)))  # plain uphill step
        t, moved = 1.0, False
        for _ in range(60):
            u_new = np.clip(u + t * d, lo, hi)
            ll_new = _bb_loglik(math.exp(u_new[0]), math.exp(u_new[1]), s, f)
            if ll_new > ll:
                moved = True
                break
            t *= 0.5
        if not moved:
            break
        gain, step = ll_new - ll, float(np.max(np.abs(u_new - u)))
        u, ll = u_new, ll_new
        if gain < 1e-11 and step < 1e-9:
            break
    return float(math.exp(u[0])), float(math.exp(u[1]))


# ---------------------------------------------------------------------------
# Retrieval: mixing relevance with score, plus seeded exploration
# ---------------------------------------------------------------------------


def _relevance_for(candidates: Sequence[str], relevance: Mapping[str, float], relevance_norm: str) -> Dict[str, float]:
    missing = [c for c in candidates if c not in relevance]
    if missing:
        raise KeyError(f"no relevance for candidates {missing[:5]}")
    rel = {c: float(relevance[c]) for c in candidates}
    if relevance_norm == "none":
        return rel
    if relevance_norm == "minmax":
        lo, hi = min(rel.values()), max(rel.values())
        if hi - lo <= 0:
            return {c: 0.5 for c in rel}
        return {c: (v - lo) / (hi - lo) for c, v in rel.items()}
    raise ValueError("relevance_norm must be 'none' or 'minmax'")


def mixed_scores(
    candidates: Sequence[str],
    relevance: Mapping[str, float],
    score: Mapping[str, float],
    w: float = 0.5,
    default_score: float = 0.5,
    relevance_norm: str = "none",
) -> Dict[str, float]:
    """{candidate: w * relevance + (1 - w) * normalised score}.

    Everyday meaning: "how close is the tip to this job" and "how good has the
    tip been" are weighed half and half (w = 0.5, MemRL's weight_sim = weight_q
    = 0.5).

    `score` must already be normalised to [0, 1] (use rule.normalised_scores).
    An item missing from `score` gets `default_score` (0.5 = the starting value
    of both rules, i.e. "no evidence yet").
    `relevance` is used as given ("none", which assumes it is already on a 0..1
    scale such as cosine similarity) or rescaled over the candidates of this
    one task ("minmax").
    """
    if not (0.0 <= w <= 1.0):
        raise ValueError("w must be between 0 and 1")
    rel = _relevance_for(candidates, relevance, relevance_norm)
    return {c: w * rel[c] + (1.0 - w) * float(score.get(c, default_score)) for c in candidates}


def rank(
    candidates: Sequence[str],
    relevance: Mapping[str, float],
    score: Mapping[str, float],
    w: float = 0.5,
    default_score: float = 0.5,
    relevance_norm: str = "none",
) -> List[str]:
    """Candidates ordered best first by w * relevance + (1 - w) * score.

    Ties are broken by higher relevance, then by the order the candidates
    were given in, so the result is always the same for the same input.
    Everyday meaning of the tie rule: "if the grades can't separate two tips,
    show the one closer to the job".
    """
    cands = list(dict.fromkeys(candidates))  # drop duplicates, keep order
    mix = mixed_scores(cands, relevance, score, w, default_score, relevance_norm)
    rel = _relevance_for(cands, relevance, relevance_norm)
    pos = {c: k for k, c in enumerate(cands)}
    return sorted(cands, key=lambda c: (-mix[c], -rel[c], pos[c]))


class Choice(NamedTuple):
    """What `choose` picked and how likely that pick was (for logging)."""

    item_id: str
    prob: float  # probability this item was the one shown, given the inputs
    explored: bool  # True if the random draw (not the best item) decided
    ranked: List[str]  # all candidates, best first


def _as_rng(rng) -> np.random.Generator:
    if isinstance(rng, np.random.Generator):
        return rng
    if rng is None:
        raise ValueError("exploration needs a seeded rng (an int seed or numpy Generator)")
    return np.random.default_rng(rng)


def choose(
    candidates: Sequence[str],
    relevance: Mapping[str, float],
    score: Mapping[str, float],
    w: float = 0.5,
    epsilon: float = 0.0,
    top_k: int = 4,
    rng=None,
    explore_pool: str = "relevance",
    default_score: float = 0.5,
    relevance_norm: str = "none",
) -> Choice:
    """Pick ONE item to show, with optional epsilon-greedy exploration.

    Everyday meaning: usually show the best tip; but with chance `epsilon`
    pick at random among the top few, so that more tips get tried and earn a
    score (the pilot gate needs 150 items seen 5 or more times).

    - With probability 1 - epsilon: the best item by `rank`.
    - With probability epsilon: a uniform draw from a pool of `top_k` items.
      explore_pool="relevance" (default) takes the top_k by relevance alone,
      as the design note words it ("top similarity candidates");
      explore_pool="mixed" takes the top_k of the mixed ranking.
    The returned `prob` is the chance the shown item had of being shown, which
    the design asks to log.

    Determinism: one uniform number is drawn per call when epsilon > 0, and a
    second only if exploring, from the generator given. Same seed and same
    sequence of calls -> same picks. With epsilon == 0 no randomness is used.
    """
    if not candidates:
        raise ValueError("no candidates to choose from")
    if not (0.0 <= epsilon <= 1.0):
        raise ValueError("epsilon must be between 0 and 1")
    ranked = rank(candidates, relevance, score, w, default_score, relevance_norm)
    best = ranked[0]
    if epsilon == 0.0:
        return Choice(best, 1.0, False, ranked)
    gen = _as_rng(rng)
    if explore_pool == "relevance":
        rel = _relevance_for(ranked, relevance, relevance_norm)
        pos = {c: k for k, c in enumerate(ranked)}
        pool = sorted(ranked, key=lambda c: (-rel[c], pos[c]))[: max(1, top_k)]
    elif explore_pool == "mixed":
        pool = ranked[: max(1, top_k)]
    else:
        raise ValueError("explore_pool must be 'relevance' or 'mixed'")
    explore = bool(gen.random() < epsilon)
    pick = pool[int(gen.integers(len(pool)))] if explore else best
    # Probability that `pick` is shown under this policy.
    p = epsilon / len(pool) if pick in pool else 0.0
    if pick == best:
        p += 1.0 - epsilon
    return Choice(pick, float(p), explore, ranked)


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------


def count_visited(bank: Bank, min_visits: float = 5) -> int:
    """Number of items shown at least `min_visits` times.
    Pilot gate condition 4 needs at least 150 items with 5 or more visits."""
    return sum(1 for r in bank.values() if r.get("visits", 0) >= min_visits)


# ---------------------------------------------------------------------------
# Saving and loading banks
# ---------------------------------------------------------------------------


def save_bank(path: Union[str, Path], bank: Bank, rule: ScoreRule, note: Optional[str] = None, now=None) -> Path:
    """Write the bank to a JSON file (UTF-8). Each record keeps the model and
    time its score was earned with. The file is written to a temporary name
    first and then renamed, so a crash never leaves half a file (works on
    Windows too). Item ids must be strings, because JSON keys are strings."""
    bad = [k for k in bank if not isinstance(k, str)]
    if bad:
        raise TypeError(f"item ids must be strings for JSON; got {bad[:3]!r}")
    payload = {
        "format": BANK_FORMAT,
        "rule": rule.to_dict(),
        "saved_at": _now_iso(now),
        "note": note,
        "items": bank,
    }
    text = json.dumps(payload, indent=1, sort_keys=True, ensure_ascii=False, allow_nan=False)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(text)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
    return path


def load_bank(path: Union[str, Path]) -> Tuple[Bank, ScoreRule]:
    """Read a bank written by `save_bank`. Returns (bank, rule)."""
    with open(path, "r", encoding="utf-8") as fh:
        payload = json.load(fh)
    if payload.get("format") != BANK_FORMAT:
        raise ValueError(f"{path}: not a score bank file (format {payload.get('format')!r})")
    return payload["items"], rule_from_dict(payload["rule"])
