"""Stage D, THE RUN AFTER THE SWAP: the new model carries on over the test tasks, and the
scores keep learning.

Everyday picture: swap day is over and the new helper starts real work. He starts from the
tip scores a swap-day rule gave him (kept, wiped, discounted, recalibrated, ... or his own
tip box), and every job he does updates the score of the tip he read, exactly as during the
build. The tip box itself stays closed: no tip is added or changed. How fast does each
starting point get him to the level of his own tip box?

Pre-registration 2.10: one item shown, one repeat, exploration 0 by default, content frozen,
every arm starts from its own scores and learns with its family's own update rule;
"relevance" ranks by relevance alone and does not learn; "none" shows nothing. Arms with
fresh checks use the first random draw (d = 0) of Stage C.

reexplore_m (decision D7): starts from the old scores and learns exactly as keep does, but for
the first m test tasks after the swap the pick explores with chance online.reexplore_epsilon
(pool build.explore_pool, the same select_items call as the build); after that it uses
online.epsilon. Each of its rows says which picks explored ("explored").

How the stage runs: one run = one (pair, stream, seed, arm, family), a chain of calls one test
task after another. Every run of every unfinished cell goes into ONE pool of `workers` runs, so
the stage makes about `workers` calls at once. Runs start cell by cell; a run of the credit
family waits for its cell's `none` run (its no-memory results are the baseline). Each run is the
same chain of calls whatever runs beside it, so the files are the same as one run after another.
A cell's files are written only when all its runs are done; a stopped stage redoes only the
unfinished cells (paid answers come back from the cache).

The family is `online.families` (`headline` = evaluate.headline_family, settled point 22):
ema_grade q <- q + 0.3 (y - q); beta_grade counts successes and failures; tags_self asks the
reader to tag every shown item without the grade (one extra call, logged as stage
"selfmark" with phase "online"); credit compares with the `none` arm's no-memory result on
the same test task. Starting values (settled 23 Nov 2026): an arm whose swap-day output is a
probability p (recal_k) starts the moving average at q = p, a count family at
helpful = p (n + 2) - 1 and harmful = (1 - p)(n + 2) - 1 (n = the item's old visits, so the
smoothed mean is p) and credit at c = p - r0; every other arm starts from its own record.

Metrics (results/online.csv): mean success over the test tasks; success over the first
`online.first_n` tasks; tasks needed until the success over the last `online.window` tasks
(averaged over the stream orders) reaches `online.target_share` of the own arm's mean
success. results/online_curves.csv holds the learning curves.
"""
from __future__ import annotations

import heapq
import threading
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait

import numpy as np

from msr import arms as A
from msr import data as D
from msr import scores as S
from msr.build import (Progress, grade_detail, load_items, make_rules, messages, parse_mark, read_jsonl,
                       run_jobs, select_items, selftag_prompt, shown_order_for_prompt, stable_int,
                       update_families, write_json, write_jsonl)
from msr.evaluate import (draw_random_checks, draw_rng, draw_task_checks, draw_top_checks, fresh_pool,
                          load_cell, owner_r0, pairs_of, read_csv, write_csv, write_summary)
from msr.probe import candidates_for
from msr.study import Study, plan_calls


#: Changes whenever the starting values or the learning rules of this stage change, so a cell
#: made under older rules is run again (paid answers come back from the cache).
#: 2026-11-24: recal starts count families at p (n + 2) - 1, credit at p - r0; tags_self learns.
ONLINE_RULES = "2026-11-24"

#: Families whose update reads the `none` arm's no-memory result on the same test task. Their
#: runs wait for the cell's `none` run; every other run can start at once.
BASELINE_FAMILIES = ("credit",)


class _Stopped(Exception):
    """Raised inside a run when another run of the stage failed: the stage stops soon."""


def reexplore_tasks(arm: str) -> int:
    """m of reexplore_m: the number of test tasks that explore after the swap (0 for other arms)."""
    return int(arm.rsplit("_", 1)[1]) if arm.startswith("reexplore_") else 0


def _done_record(st: Study) -> dict:
    """What done.json must say for a cell to count as done now: the arms, families and rules,
    and the re-exploration chance when a reexplore_m arm runs."""
    O = st.online
    rec = {"arms": list(O.arms), "families": list(O.families), "rules": ONLINE_RULES}
    if any(a.startswith("reexplore_") for a in O.arms):
        rec["reexplore_epsilon"] = O.reexplore_epsilon
    return rec


def online_done(st: Study, owner: str, reader: str, stream: str, seed: int) -> bool:
    """Done when the saved run used the arms, families and rules the study file and this code
    ask for now (if they changed, the cell is run again; paid answers come back from the cache)."""
    import json
    p = st.online_dir(owner, reader, stream, seed) / "done.json"
    if not p.exists():
        return False
    d = json.loads(p.read_text(encoding="utf-8"))
    return all(d.get(k) == v for k, v in _done_record(st).items())


def initial_bank(st: Study, arm: str, fam: str, bank: dict, rule, pool: list, key: tuple,
                 r0: float | None = None) -> dict:
    """The scores an arm starts the run with (the owner's bank transformed on swap day).
    recal_k turns its probability p into the family's record (msr.arms.recalibrate:
    q = p; helpful = p (n + 2) - 1, harmful = (1 - p)(n + 2) - 1; c = p - r0, with r0 the
    owner's no-memory success over its score tasks); every other arm returns the record it
    makes on swap day."""
    stream, seed, owner, reader = key
    if arm == "keep" or arm.startswith("reexplore_"):      # reexplore_m starts from the old scores, as keep
        return A.keep(bank, rule)
    if arm == "wipe":
        return A.wipe(bank, rule)
    if arm.startswith("fixed_"):
        return A.fixed_discount(bank, rule, float(arm.split("_", 1)[1]))
    name, k = arm.rsplit("_", 1)
    k = int(k)
    rng = draw_rng(st, stream, seed, owner, reader, name, k, 0)          # draw 0, as Stage C
    if not A.arm_applies(name, rule):
        raise ValueError(f"online arm {arm} does not apply to family {fam}")
    if name == "powerprior":
        return A.powerprior(bank, rule, pairs_of(draw_random_checks(pool, k, rng)), grid=st.evaluate.lambda_grid)[1]
    if name == "powerprior_flat":
        return A.powerprior(bank, rule, pairs_of(draw_random_checks(pool, k, rng)), grid=st.evaluate.lambda_grid,
                            prior="flat")[1]
    if name == "recal":
        return A.recalibrate(bank, rule, pairs_of(draw_random_checks(pool, k, rng)), r0=r0)[2]
    if name == "audit":
        return A.audit(bank, rule, pairs_of(draw_task_checks(pool, k, rng)))[1]
    if name == "retest":
        return A.retest(bank, rule, draw_top_checks(pool, bank, rule, k, rng), new_model=reader)
    if name == "pooled":
        return A.pooled(bank, rule, draw_random_checks(pool, k, rng), new_model=reader)
    if name == "fresh":
        return A.fresh_only(bank, rule, draw_random_checks(pool, k, rng), new_model=reader)
    raise ValueError(f"unknown online arm {arm!r}")


def _one_run(st, llm, reader, stream, seed, tasks, test_ids, items, cands, arm, fam, rule, state,
             baseline, base_meta, progress, stop: threading.Event | None = None) -> list:
    """One sequential run over the test tasks; returns its rows. If `stop` is set (another run
    of the stage failed), it stops before its next task."""
    O = st.online
    rows = []
    learn = O.learn and arm not in ("none", "relevance")
    rules = {fam: rule} if rule is not None else {}
    banks = {fam: state} if state is not None else {}
    m_explore = reexplore_tasks(arm)
    for pos, tid in enumerate(test_ids):
        if stop is not None and stop.is_set():
            raise _Stopped(f"online run {arm}/{fam} stopped at task {pos}: another run failed")
        explored = []
        if arm == "none":
            shown, probs = [], []
        else:
            c = cands[tid]
            if arm == "relevance":
                sc, drive = {}, "relevance"
            else:
                sc, drive = rule.normalised_scores(state), fam
            rng = np.random.default_rng([int(seed), 7, stable_int(f"online|{tid}")])
            # reexplore_m explores during its first m tasks, then goes back to online.epsilon
            eps = O.reexplore_epsilon if pos < m_explore else O.epsilon
            shown, probs, explored = select_items(c, sc, O.n_show, st.build.w_score, eps, st.build.explore_pool,
                                                  rng, drive)
        texts = [items[i]["text"] for i in shown_order_for_prompt(shown)]
        system, user = messages(stream, tasks[tid], texts, st.prompt_variant)
        r = llm.call(model=reader, user=user, system=system, repeat=0, max_tokens=st.max_tokens,
                     meta={**base_meta, "arm": arm, "family": fam, "task_id": tid, "position": pos,
                           "item_id": shown[0] if shown else None, "items": list(shown), "repeat": 0})
        det = grade_detail(st, stream, tasks[tid], r.answer)
        ok = bool(det["correct"])
        tags, tag_calls = {}, []
        if learn and fam == "tags_self":
            # the reader tags each shown item; it sees the task, the item and its own answer,
            # never the grade (build.self_tag_sees_grade: false; pre-registration 2.10)
            parsed = det["parsed_text"] if stream == "ddxplus" else det["parsed"]
            for iid in shown:
                tu = selftag_prompt(stream, tasks[tid], items[iid]["text"], str(parsed), ok,
                                    st.build.self_tag_sees_grade)
                t = llm.call(model=reader, user=tu, system=None, repeat=0, max_tokens=st.max_tokens,
                             meta={**base_meta, "stage": "selfmark", "phase": "online", "arm": arm, "family": fam,
                                   "task_id": tid, "position": pos, "item_id": iid, "items": [iid],
                                   "shown": list(shown), "correct": ok,
                                   "sees_grade": st.build.self_tag_sees_grade, "repeat": 0})
                tags[iid] = parse_mark(t.answer)
                tag_calls.append(t.call_id)
                if progress:
                    progress.add()
        if learn:
            for iid in shown:
                update_families(rules, banks, iid, ok, tags.get(iid), baseline.get(tid), reader)
        row = {"arm": arm, "family": fam, "position": pos, "task_id": tid, "shown": shown,
               "probs": probs, "correct": ok, "call_id": r.call_id}
        if tag_calls:
            row.update(tags=tags, tag_call_ids=tag_calls)
        if arm.startswith("reexplore_"):
            row["explored"] = explored              # one flag per shown item, as in the build's episodes
        if det.get("ungraded") is not None:         # for example a BIRD query that timed out
            row["ungraded"] = det["ungraded"]
        rows.append(row)
        if progress:
            progress.add()
    return rows


def _prepare_cell(st: Study, owner: str, reader: str, stream: str, seed: int, emb: dict) -> dict:
    """What one cell needs before its runs start: the test tasks, the candidates and the starting
    scores of every run. The `none` run comes first, then every other arm and family in the study
    file's order (the order of the rows in online.jsonl). Called from one thread only, because
    candidates_for writes a file in the owner's bank folder."""
    O = st.online
    test_ids = list(st.splits(stream, seed)["test"])
    k_c = st.build.candidates
    o_items = load_items(st, owner, stream, seed)
    o_cands = candidates_for(st, owner, stream, seed, emb, test_ids, k_c, "test_candidates")
    r_items = load_items(st, reader, stream, seed)
    r_cands = candidates_for(st, reader, stream, seed, emb, test_ids, k_c, "test_candidates")
    pool = []
    if (st.probe_dir(owner, reader, stream, seed) / "done.json").exists():
        calib, _ = st.calib_eval(stream, seed)
        cell = load_cell(st, owner, reader, stream, seed)
        none_rate = {t: float(np.mean(v)) for t, v in cell["none"].items() if v}
        pool = fresh_pool(cell["reg"], calib, none_rate)
    rules = make_rules(st)
    key = (stream, seed, owner, reader)
    r0 = owner_r0(st, owner, stream, seed)
    base_meta = {"study": st.name, "stage": "online", "model": reader, "owner": owner, "reader": reader,
                 "stream": stream, "seed": seed}
    runs = []
    if "none" in O.arms:          # first: its results are the no-memory baseline of the credit family
        runs.append(("none", "-", None, None, o_items, o_cands))
    for arm in O.arms:
        if arm == "none":
            continue
        if arm == "relevance":
            runs.append((arm, "-", None, None, o_items, o_cands))
            continue
        for fam in O.families:
            rule = rules[fam]
            if arm == "own":
                bank, _ = S.load_bank(st.bank_dir(reader, stream, seed) / f"bank_{fam}.json")
                runs.append((arm, fam, rule, A.keep(bank, rule), r_items, r_cands))
            else:
                bank, _ = S.load_bank(st.bank_dir(owner, stream, seed) / f"bank_{fam}.json")
                runs.append((arm, fam, rule, initial_bank(st, arm, fam, bank, rule, pool, key, r0), o_items, o_cands))
    has_none = bool(runs) and runs[0][0] == "none"
    return {"key": (owner, reader, stream, seed), "out": st.online_dir(owner, reader, stream, seed),
            "test_ids": test_ids, "base_meta": base_meta, "runs": runs, "rows": [None] * len(runs),
            "baseline": {} if has_none else None,
            "waits": [has_none and fam in BASELINE_FAMILIES for _a, fam, *_ in runs]}


def _write_cell(st: Study, cell: dict) -> None:
    """Write a finished cell: online.jsonl first, then done.json (each through a temporary file)."""
    rows = [r for rs in cell["rows"] for r in rs]
    write_jsonl(cell["out"] / "online.jsonl", rows)
    write_json(cell["out"] / "done.json", {"complete": True, "rows": len(rows), **_done_record(st)})


def _run_cells(st: Study, llm, todo: list, embeddings: dict, tasks_by_stream: dict, workers: int,
               progress: Progress | None = None) -> None:
    """Run the online cells in `todo` [(owner, reader, stream, seed)] with ONE pool of `workers` runs.

    Everyday picture: one kitchen with `workers` cooks. Each dish (one run) is cooked step by
    step by one cook, so `workers` cooks make about `workers` calls at once. Dishes are taken
    table by table (cell by cell, in the order of `todo`); a credit dish waits for its table's
    `none` dish. A table is served (its files written) as soon as all its dishes are done.

    A failure in any run (or a stop) stops the other runs before their next task; the cells
    already finished stay written, and the first failure is raised again here."""
    workers = max(1, int(workers))
    stop = threading.Event()
    ready: list = []            # heap of (cell number, run number): earlier cells first
    live: dict = {}             # cell number -> cell (prepared, not yet written)
    running: dict = {}          # future -> (cell number, run number)
    queue = iter(enumerate(todo))
    error: BaseException | None = None

    def go(cell: dict, i: int) -> list:
        arm, fam, rule, state, items, cands = cell["runs"][i]
        owner, reader, stream, seed = cell["key"]
        baseline = cell["baseline"] if cell["waits"][i] else {}
        return _one_run(st, llm, reader, stream, seed, tasks_by_stream[stream], cell["test_ids"], items, cands,
                        arm, fam, rule, state, baseline, cell["base_meta"], progress, stop)

    with ThreadPoolExecutor(max_workers=workers) as ex:
        try:
            while True:
                while error is None and len(running) < workers:
                    if ready:
                        n, i = heapq.heappop(ready)
                        running[ex.submit(go, live[n], i)] = (n, i)
                        continue
                    nxt = next(queue, None)
                    if nxt is None:
                        break
                    n, (o, r, s, k) = nxt
                    if online_done(st, o, r, s, k):
                        continue
                    cell = _prepare_cell(st, o, r, s, k, embeddings[s])
                    if not cell["runs"]:
                        _write_cell(st, cell)
                        continue
                    live[n] = cell
                    for i, waits in enumerate(cell["waits"]):
                        if not waits:
                            heapq.heappush(ready, (n, i))
                if not running:
                    break
                done, _ = wait(running, return_when=FIRST_COMPLETED)
                for f in done:
                    n, i = running.pop(f)
                    try:
                        rows = f.result()
                    except BaseException as e:            # noqa: BLE001 - raised again below
                        if error is None or (isinstance(error, _Stopped) and not isinstance(e, _Stopped)):
                            error = e
                        stop.set()
                        continue
                    cell = live[n]
                    cell["rows"][i] = rows
                    if cell["runs"][i][0] == "none":
                        cell["baseline"] = {x["task_id"]: float(x["correct"]) for x in rows}
                        for j, waits in enumerate(cell["waits"]):
                            if waits:
                                heapq.heappush(ready, (n, j))
                    if all(x is not None for x in cell["rows"]):   # complete: saved even after a failure
                        _write_cell(st, cell)
                        del live[n]
        except BaseException:
            stop.set()                                    # a stop here: the runs end at their next task
            raise
    if error is not None:
        raise error


def run_online_cell(st: Study, llm, owner: str, reader: str, stream: str, seed: int, emb: dict,
                    tasks: dict, workers: int, progress: Progress | None = None) -> None:
    """One cell on its own (run_stage runs all unfinished cells in one pool)."""
    _run_cells(st, llm, [(owner, reader, stream, seed)], {stream: emb}, {stream: tasks}, workers, progress)


def run_stage(st: Study, llm, embeddings: dict, workers: int = 8, printer=print) -> None:
    """Every unfinished online cell, with `workers` runs (so about `workers` calls) at once."""
    if not st.online.enabled:
        printer("  [online] switched off in the study file (online.enabled: false)")
        return
    todo = [(o, r, s, k) for s in st.streams for k in st.seeds for (o, r) in st.online.pairs
            if not online_done(st, o, r, s, k)]
    if todo:
        per = sum(plan_calls(st)["calls"]["online"].values()) // max(1, len(st.online.pairs) * len(st.streams) * len(st.seeds))
        if st.online.learn and "tags_self" in st.online.families:      # the reader's tag calls
            per += st.sizes.n_test * st.online.n_show * sum(1 for a in st.online.arms if a not in ("none", "relevance"))
        prog = Progress("after the swap", per * len(todo), printer)
        tasks_by_stream = {s: D.task_index(s) for s in st.streams}
        _run_cells(st, llm, todo, embeddings, tasks_by_stream, workers, prog)
    write_online_results(st)


def _trailing(xs: np.ndarray, window: int) -> np.ndarray:
    """Mean of the last `window` results at every position (NaN before the window is full)."""
    out = np.full(len(xs), np.nan)
    if len(xs) >= window:
        c = np.cumsum(np.insert(xs.astype(float), 0, 0.0))
        out[window - 1:] = (c[window:] - c[:-window]) / window
    return out


def write_online_results(st: Study) -> None:
    """results/online.csv (per seed and pooled over seeds) and results/online_curves.csv."""
    O = st.online
    rows, curves = [], []
    for owner, reader in O.pairs:
        for stream in st.streams:
            runs: dict = {}
            for seed in st.seeds:
                p = st.online_dir(owner, reader, stream, seed) / "online.jsonl"
                if not p.exists():
                    continue
                for r in read_jsonl(p):
                    runs.setdefault((r["arm"], r["family"]), {}).setdefault(seed, []).append(r)
            if not runs:
                continue
            fams = list(O.families) or ["-"]
            own_level = {f: np.mean([np.mean([x["correct"] for x in rs]) for rs in runs.get(("own", f), {}).values()])
                         if ("own", f) in runs else np.nan for f in fams}
            base = {"owner": owner, "reader": reader, "kind": st.kind(owner, reader), "stream": stream}
            for (arm, fam), by_seed in runs.items():
                target_fam = fam if fam in own_level else fams[0]
                target = O.target_share * own_level.get(target_fam, np.nan)
                trails = []
                for seed, rs in sorted(by_seed.items()):
                    xs = np.array([x["correct"] for x in sorted(rs, key=lambda x: x["position"])], dtype=float)
                    tr = _trailing(xs, O.window)
                    trails.append(tr)
                    hit = np.flatnonzero(tr >= target) if not np.isnan(target) else []
                    rows.append({**base, "seed": seed, "family": fam, "arm": arm, "n": len(xs),
                                 "success": float(xs.mean()), "success_first": float(xs[: O.first_n].mean()),
                                 "target": target, "tasks_to_target": int(hit[0] + 1) if len(hit) else ""})
                n_min = min(len(t) for t in trails)
                with np.errstate(all="ignore"), __import__("warnings").catch_warnings():
                    __import__("warnings").simplefilter("ignore", category=RuntimeWarning)
                    avg = np.nanmean(np.vstack([t[:n_min] for t in trails]), axis=0) if n_min else np.array([])
                hit = np.flatnonzero(avg >= target) if not np.isnan(target) else []
                seeds_rows = [r for r in rows if r["owner"] == owner and r["reader"] == reader and r["stream"] == stream
                              and r["arm"] == arm and r["family"] == fam and r["seed"] != "all"]
                rows.append({**base, "seed": "all", "family": fam, "arm": arm, "n": sum(r["n"] for r in seeds_rows),
                             "success": float(np.mean([r["success"] for r in seeds_rows])),
                             "success_first": float(np.mean([r["success_first"] for r in seeds_rows])),
                             "target": target, "tasks_to_target": int(hit[0] + 1) if len(hit) else ""})
                for pos in range(n_min):
                    if not np.isnan(avg[pos]):
                        curves.append({**base, "family": fam, "arm": arm, "position": pos + 1,
                                       "trailing_success": float(avg[pos])})
    write_csv(st.results_dir / "online.csv", rows)
    write_csv(st.results_dir / "online_curves.csv", curves)
    if (st.results_dir / "gate.json").exists():
        write_summary(st)


__all__ = ["run_stage", "write_online_results", "read_csv"]
