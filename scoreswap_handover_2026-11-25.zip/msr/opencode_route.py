"""Free models through the opencode command-line tool: a route for PRELIMINARY runs only.

Everyday picture: a borrowed phone line. The opencode tool offers some models for free,
but every call goes through opencode's own switchboard. So we (1) ring from an empty,
private room, so nothing of ours is overheard, (2) ask the switchboard to say nothing of
its own before our question, and (3) check every time that it kept quiet.

What the model receives (checked with a local stand-in endpoint; the full record is in
runs/prelim_opencode/ROUTE_NOTES.md):
  system message : one fixed neutral sentence (providers.opencode_cli.system_sentence)
  user message   : our prompt, byte for byte
  request fields : stream, max_tokens = opencode's own answer cap (32000 unless
                   providers.opencode_cli.output_token_max sets it), reasoning_effort only
                   when the model sets `opencode_variant`; for models that opencode reaches
                   in the Anthropic format it also marks both texts "cache_control".
  No temperature, no seed and no tools are sent.

How a call works:
- One long-lived `opencode serve` per Python process (measured 23 Nov 2026: about 0.05 s
  of overhead per call, against about 3.2 s for one `opencode run` process per call), bound
  to 127.0.0.1 with a random password, started in runs/_opencode_home/work/. That folder
  holds only:
    opencode.json                     agent "plain": every tool off, the sentence as prompt
    .opencode/plugins/plain_system.js replaces the system prompt that opencode assembles
                                      (agent prompt + "You are powered by the model named ..."
                                      + an <env> block with the folder, platform and date) by
                                      the sentence alone, and logs one line per call
  Environment flags switch off Claude Code files, outside skills, auto-update, language
  servers, model-list downloads, default plugins and auto-compaction. Sessions go to a
  private database (runs/_opencode_home/opencode.db), not the owner's.
- Each call: a new session WITH a title (so opencode makes no extra title call) ->
  prompt_async -> poll the session status -> read the answer -> delete the session.
- After every call the plugin's log must show this session: proof that the clean system
  prompt was used. If it does not, the call fails.

Failures RAISE and are never returned as an answer (so they never reach the answer cache):
  OpencodeLimitReached  the free allowance is used up (opencode's retry state
                        "free_tier_limit", or a "Free usage limit" text). Raised at once: it
                        resets at a fixed time (00:00 UTC, as seen on 23 Nov 2026), so retrying is useless.
  OpencodeCallFailed    non-zero exit / server gone, an error in the answer, an empty answer,
                        a server-error or rate-limit text, opencode retrying (rate limits) for
                        longer than retry_wait_s, a timeout, or a missing plugin line.
                        Retried `retries` times with backoff first.
A per-provider cap (providers.opencode_cli.max_parallel) bounds the calls in flight, so the
pipeline's worker threads cannot overload the free service.

Hard rules kept here: only model ids that end in "-free" are accepted (no money can be
spent); no key file is read; prompts go over HTTP to the local server, never through a shell.
"""
from __future__ import annotations

import base64
import json
import os
import re
import secrets
import shutil
import signal
import socket
import subprocess
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_HOME = ROOT / "runs" / "_opencode_home"
DEFAULT_SENTENCE = "You are a helpful assistant."
AGENT = "plain"

#: Environment flags for the opencode server (see the module text).
FLAGS = {
    "OPENCODE_DISABLE_CLAUDE_CODE": "1",          # no CLAUDE.md, no ~/.claude skills
    "OPENCODE_DISABLE_EXTERNAL_SKILLS": "1",
    "OPENCODE_DISABLE_AUTOUPDATE": "1",
    "OPENCODE_DISABLE_LSP_DOWNLOAD": "1",
    "OPENCODE_DISABLE_MODELS_FETCH": "1",         # use the cached model list; no download mid-run
    "OPENCODE_DISABLE_DEFAULT_PLUGINS": "1",
    "OPENCODE_DISABLE_AUTOCOMPACT": "1",
}
#: Variables that could change what opencode loads; removed from the server's environment.
_DROP_ENV = ("OPENCODE_CONFIG", "OPENCODE_CONFIG_CONTENT", "OPENCODE_CONFIG_DIR", "OPENCODE_PURE",
             "OPENCODE_PERMISSION", "OPENCODE_EXPERIMENTAL_OUTPUT_TOKEN_MAX")

#: Texts that mean "the free allowance is used up" (also the quiet failure, where the message
#: comes back as the answer text). Stops the run at once: it resets only at a fixed time.
ALLOWANCE_RE = re.compile(r"free usage|free[ _-]tier|subscribe to opencode go|opencode\.ai/go|usage limit|"
                          r"quota (exceeded|reached)", re.I)
#: Texts that mean "a passing limit" (too many calls just now): retried with backoff.
LIMIT_RE = re.compile(r"rate[ _-]?limit|too many requests|limit (reached|exceeded)", re.I)
#: Texts that mean "no answer, the service failed" (checked on short answers only).
SERVER_ERR_RE = re.compile(r"unexpected server error|upstream request failed|endpoint is unavailable|"
                           r"internal server error|service unavailable|bad gateway|provider returned error",
                           re.I)


class OpencodeError(RuntimeError):
    """Base of every failure of this route."""


class OpencodeLimitReached(OpencodeError):
    """The free allowance is used up. `resets_at` is opencode's next-try time (ms since 1970), if given."""

    def __init__(self, msg: str, resets_at: int | None = None):
        super().__init__(msg)
        self.resets_at = resets_at


class OpencodeCallFailed(OpencodeError):
    """One call gave no usable answer."""


# ---------------------------------------------------------------------------
# The private folder
# ---------------------------------------------------------------------------

def _plugin_js(sentence: str) -> str:
    return (
        "// Written by msr/opencode_route.py. Replaces the system prompt that opencode assembles\n"
        "// (agent prompt + model name + <env> block with folder and date) by ONE fixed sentence,\n"
        "// and appends one line per call to the file named in MSR_OC_PLUGIN_LOG, so the caller\n"
        "// can check that the replacement happened. No tools, no files read, no network.\n"
        "import { appendFileSync } from \"fs\"\n"
        f"const SENTENCE = {json.dumps(sentence)}\n"
        "export const PlainSystem = async () => ({\n"
        "  \"experimental.chat.system.transform\": async (input, output) => {\n"
        "    output.system.length = 0\n"
        "    output.system.push(SENTENCE)\n"
        "    const log = process.env.MSR_OC_PLUGIN_LOG\n"
        "    if (log) appendFileSync(log, `${input.sessionID}\\t${SENTENCE.length}\\n`)\n"
        "  },\n"
        "})\n"
    )


def _agent_config(sentence: str) -> dict:
    return {
        "$schema": "https://opencode.ai/config.json",
        "share": "disabled",
        "autoupdate": False,
        "snapshot": False,
        "instructions": [],
        "agent": {
            AGENT: {
                "description": "Single-turn answerer: no tools, one neutral sentence as system prompt.",
                "mode": "primary",
                "prompt": sentence,
                "tools": {"*": False},
                "permission": {"*": "deny"},
            }
        },
    }


def prepare_home(home: Path, sentence: str) -> Path:
    """Write the private working folder (idempotent). Returns the folder opencode runs in.

    The folder is made a stop point for opencode's upward search for AGENTS.md / CLAUDE.md
    by being empty of such files; OPENCODE_DISABLE_CLAUDE_CODE stops the CLAUDE.md search,
    and the plugin replaces the whole system prompt anyway."""
    work = home / "work"
    plugins = work / ".opencode" / "plugins"
    plugins.mkdir(parents=True, exist_ok=True)
    for name, text in (("opencode.json", json.dumps(_agent_config(sentence), indent=2) + "\n"),
                       (".opencode/plugins/plain_system.js", _plugin_js(sentence))):
        p = work / name
        if not p.exists() or p.read_text(encoding="utf-8") != text:
            p.write_text(text, encoding="utf-8")
    for stray in ("AGENTS.md", "CLAUDE.md", "CONTEXT.md"):
        if (work / stray).exists():
            raise OpencodeError(f"{work / stray} must not exist: opencode would put it in the system prompt")
    return work


def find_command(cmd: str | None) -> str:
    """The opencode program: the configured path, else PATH, else the nvm install."""
    if cmd and (os.sep in cmd):
        if not Path(cmd).exists():
            raise OpencodeError(f"opencode command {cmd} not found")
        return cmd
    found = shutil.which(cmd or "opencode")
    if found:
        return found
    for p in sorted((Path.home() / ".nvm" / "versions" / "node").glob("*/bin/opencode"), reverse=True):
        return str(p)
    raise OpencodeError("the opencode command was not found (set providers.opencode_cli.command)")


# ---------------------------------------------------------------------------
# The local server
# ---------------------------------------------------------------------------

class Server:
    """One `opencode serve` process, started lazily, restarted if it dies."""

    def __init__(self, command: str, home: Path, sentence: str, output_token_max: int | None,
                 start_timeout_s: float = 120.0, inspect_base_url: str | None = None):
        self.command, self.home, self.sentence = command, home, sentence
        self.output_token_max = output_token_max
        # Only for checking what opencode sends (runs/prelim_opencode/route_check/): every
        # request of the 'opencode' provider goes to this local stand-in instead. Never set
        # it in config/models.yaml.
        self.inspect_base_url = inspect_base_url
        self.start_timeout_s = start_timeout_s
        self.proc: subprocess.Popen | None = None
        self.url: str | None = None
        self._auth = ""
        self._lock = threading.Lock()
        self.version: str | None = None
        self.plugin_log = home / "plugin_calls.log"
        self.server_log = home / "serve.log"
        self._plugin_seen: set[str] = set()
        self._plugin_offset = 0
        self._plugin_lock = threading.Lock()

    # -- start / stop --
    def get_version(self) -> str:
        if self.version is None:
            out = subprocess.run([self.command, "--version"], capture_output=True, text=True, timeout=60,
                                 stdin=subprocess.DEVNULL)
            v = (out.stdout or "").strip().splitlines()
            if out.returncode != 0 or not v:
                raise OpencodeError(f"`{self.command} --version` failed (exit {out.returncode})")
            self.version = v[-1].strip()
        return self.version

    def alive(self) -> bool:
        return self.proc is not None and self.proc.poll() is None

    def ensure(self) -> str:
        with self._lock:
            if self.alive() and self.url:
                return self.url
            self._start()
            return self.url  # type: ignore[return-value]

    def _start(self) -> None:
        self.get_version()
        work = prepare_home(self.home, self.sentence)
        _clean_stale_servers(self.home)
        password = secrets.token_urlsafe(24)
        env = {k: v for k, v in os.environ.items() if k not in _DROP_ENV}
        env.update(FLAGS)
        env["OPENCODE_DB"] = str(self.home / "opencode.db")
        env["OPENCODE_SERVER_PASSWORD"] = password
        env["MSR_OC_PLUGIN_LOG"] = str(self.plugin_log)
        if self.output_token_max:
            env["OPENCODE_EXPERIMENTAL_OUTPUT_TOKEN_MAX"] = str(int(self.output_token_max))
        if self.inspect_base_url:
            if not re.match(r"^http://127\.0\.0\.1:\d+(/|$)", self.inspect_base_url):
                raise OpencodeError("inspect_base_url must be a local address (http://127.0.0.1:<port>/...)")
            env["OPENCODE_CONFIG_CONTENT"] = json.dumps(
                {"provider": {"opencode": {"options": {"baseURL": self.inspect_base_url}}}})
        self.plugin_log.touch()
        with self._plugin_lock:
            self._plugin_offset = self.plugin_log.stat().st_size
        log = open(self.server_log, "ab")
        start_at = log.tell()
        # A random free port of our own: with --port 0 opencode takes its well-known port 4096,
        # which other opencode use on this computer may expect to have.
        self.proc = subprocess.Popen(
            [self.command, "serve", "--hostname", "127.0.0.1", "--port", str(_free_port()), "--log-level", "WARN"],
            cwd=str(work), env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
        log.close()
        (self.home / "servers").mkdir(exist_ok=True)
        (self.home / "servers" / f"{self.proc.pid}.pid").write_text(f"{os.getpid()} {self.proc.pid}\n")
        t0 = time.time()
        url = None
        while time.time() - t0 < self.start_timeout_s:
            if self.proc.poll() is not None:
                raise OpencodeCallFailed(f"opencode serve exited with code {self.proc.returncode}: "
                                         f"{_tail(self.server_log, start_at)}")
            m = re.search(r"listening on (http://127\.0\.0\.1:\d+)", _tail(self.server_log, start_at, 20000))
            if m:
                url = m.group(1)
                break
            time.sleep(0.2)
        if not url:
            self.stop()
            raise OpencodeCallFailed("opencode serve did not start in time")
        self.url = url
        self._auth = "Basic " + base64.b64encode(f"opencode:{password}".encode()).decode()
        # the agent must exist, with every tool off
        agents = self.request("GET", "/agent") or []
        plain = next((a for a in agents if a.get("name") == AGENT), None)
        if plain is None:
            self.stop()
            raise OpencodeError(f"opencode did not load the agent '{AGENT}' from {work}/opencode.json")
        if any(bool(v) for v in (plain.get("tools") or {}).values()):
            self.stop()
            raise OpencodeError(f"agent '{AGENT}' has a tool switched on: {plain.get('tools')}")

    def stop(self) -> None:
        p = self.proc
        if p is not None and p.poll() is None:
            p.terminate()
            try:
                p.wait(timeout=10)
            except subprocess.TimeoutExpired:
                p.kill()
        if p is not None:
            try:
                (self.home / "servers" / f"{p.pid}.pid").unlink()
            except OSError:
                pass
        self.proc, self.url = None, None

    # -- HTTP --
    def request(self, method: str, path: str, body: Any = None, timeout: float = 30.0) -> Any:
        if not self.url:
            raise OpencodeCallFailed("opencode serve is not running")
        data = json.dumps(body).encode("utf-8") if body is not None else None
        req = urllib.request.Request(self.url + path, data=data, method=method,
                                     headers={"content-type": "application/json", "authorization": self._auth})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                raw = r.read()
        except urllib.error.HTTPError as e:
            raise OpencodeCallFailed(f"opencode serve answered HTTP {e.code} to {method} {path.split('?')[0]}")
        except (urllib.error.URLError, ConnectionError, TimeoutError, OSError) as e:
            raise OpencodeCallFailed(f"opencode serve unreachable ({type(e).__name__})")
        if not raw:
            return None
        try:
            return json.loads(raw)
        except ValueError:
            return None

    # -- the plugin's proof --
    def plugin_fired(self, session_id: str, wait_s: float = 3.0) -> bool:
        t0 = time.time()
        while True:
            with self._plugin_lock:
                if session_id in self._plugin_seen:
                    self._plugin_seen.discard(session_id)
                    return True
                try:
                    with open(self.plugin_log, encoding="utf-8") as f:
                        f.seek(self._plugin_offset)
                        chunk = f.read()
                        # keep a partial last line for the next read
                        cut = chunk.rfind("\n") + 1
                        self._plugin_offset += len(chunk[:cut].encode("utf-8"))
                    for line in chunk[:cut].splitlines():
                        sid = line.split("\t", 1)[0].strip()
                        if sid:
                            self._plugin_seen.add(sid)
                except OSError:
                    pass
                if session_id in self._plugin_seen:
                    self._plugin_seen.discard(session_id)
                    return True
            if time.time() - t0 > wait_s:
                return False
            time.sleep(0.1)


def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _tail(path: Path, start: int = 0, n: int = 600) -> str:
    try:
        with open(path, "rb") as f:
            f.seek(start)
            return f.read()[-n:].decode("utf-8", "replace")
    except OSError:
        return ""


def _clean_stale_servers(home: Path) -> None:
    """Stop opencode servers left behind by a Python process that no longer exists."""
    d = home / "servers"
    if not d.is_dir():
        return
    for f in d.glob("*.pid"):
        try:
            owner, server = (int(x) for x in f.read_text().split())
        except (OSError, ValueError):
            f.unlink(missing_ok=True)
            continue
        if _pid_alive(owner) and owner != os.getpid():
            continue   # its owner still runs it
        if _pid_alive(server):
            try:
                cmdline = Path(f"/proc/{server}/cmdline").read_bytes().replace(b"\0", b" ").decode("utf-8", "replace")
                cwd = os.readlink(f"/proc/{server}/cwd")
            except OSError:
                cmdline, cwd = "", ""
            if "serve" in cmdline and cwd == str(home / "work"):
                try:
                    os.kill(server, signal.SIGTERM)
                except OSError:
                    pass
        f.unlink(missing_ok=True)


def _pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True


# ---------------------------------------------------------------------------
# The route
# ---------------------------------------------------------------------------

class OpencodeRoute:
    """Calls free opencode models through one local `opencode serve`. One per process and
    configuration (see get_route), so every LLM object shares the server and the cap."""

    def __init__(self, pcfg: dict):
        self.pcfg = dict(pcfg or {})
        home = Path(self.pcfg.get("home") or DEFAULT_HOME)
        self.home = home if home.is_absolute() else ROOT / home
        self.home.mkdir(parents=True, exist_ok=True)
        self.sentence = str(self.pcfg.get("system_sentence") or DEFAULT_SENTENCE)
        self.max_parallel = int(self.pcfg.get("max_parallel", 4))
        if self.max_parallel < 1:
            raise ValueError("providers.opencode_cli.max_parallel must be at least 1")
        self.timeout_s = float(self.pcfg.get("timeout_s", 300))
        self.retries = int(self.pcfg.get("retries", 3))
        self.backoff_s = [float(x) for x in (self.pcfg.get("backoff_s") or [10, 30, 90])]
        self.retry_wait_s = float(self.pcfg.get("retry_wait_s", 120))
        self.poll_s = float(self.pcfg.get("poll_s", 0.1))
        self.idle_grace_s = float(self.pcfg.get("idle_grace_s", 30))
        self.sem = threading.BoundedSemaphore(self.max_parallel)
        self.server = Server(find_command(self.pcfg.get("command")), self.home, self.sentence,
                             self.pcfg.get("output_token_max"),
                             float(self.pcfg.get("start_timeout_s", 120)),
                             self.pcfg.get("inspect_base_url"))

    # -- what to write in model_settings.json --
    def describe(self, m: dict) -> dict:
        return {"route": "opencode serve (local HTTP), agent 'plain', tools off",
                "opencode_version": self.server.get_version(),
                "system_sentence": self.sentence,
                "variant": m.get("opencode_variant"),
                "output_token_max": self.pcfg.get("output_token_max") or "opencode default (32000)",
                "temperature": "not sent (host default)",
                "max_parallel": self.max_parallel}

    def served_by(self) -> str:
        return f"opencode-cli {self.server.get_version()}"

    # -- one call, with retries --
    def call(self, m: dict, user: str, system: str | None) -> dict:
        if system:
            raise ValueError("the opencode_cli route sends one fixed neutral system sentence; a custom "
                             "system prompt is not supported (every study call has system=None)")
        provider_id, model_id = split_model(m["api_model"])
        last: Exception | None = None
        for attempt in range(self.retries + 1):
            try:
                with self.sem:
                    return self._attempt(provider_id, model_id, m.get("opencode_variant"), user)
            except OpencodeLimitReached:
                raise
            except OpencodeCallFailed as e:
                last = e
                if attempt < self.retries:
                    time.sleep(self.backoff_s[min(attempt, len(self.backoff_s) - 1)])
        raise OpencodeCallFailed(f"{provider_id}/{model_id}: no usable answer after "
                                 f"{self.retries + 1} attempts; last problem: {last}")

    def _attempt(self, provider_id: str, model_id: str, variant: str | None, user: str) -> dict:
        srv = self.server
        srv.ensure()
        s = srv.request("POST", "/session", {"title": "msr"})
        sid = (s or {}).get("id")
        if not sid:
            raise OpencodeCallFailed("opencode serve did not create a session")
        done = False
        try:
            body: dict[str, Any] = {"agent": AGENT, "model": {"providerID": provider_id, "modelID": model_id},
                                    "parts": [{"type": "text", "text": user}]}
            if variant:
                body["variant"] = variant
            t0 = time.time()
            srv.request("POST", f"/session/{sid}/prompt_async", body)
            retry_since = None
            msg = None
            while True:
                if time.time() - t0 > self.timeout_s:
                    raise OpencodeCallFailed(f"timeout after {self.timeout_s:.0f} s")
                st = (srv.request("GET", "/session/status") or {}).get(sid)
                if st and st.get("type") == "retry":
                    text = str(st.get("message") or "")
                    reason = str((st.get("action") or {}).get("reason") or "")
                    if reason == "free_tier_limit" or ALLOWANCE_RE.search(text):
                        raise OpencodeLimitReached(f"free allowance used up: {text} ({reason or 'limit'})",
                                                   st.get("next"))
                    retry_since = retry_since or time.time()
                    if time.time() - retry_since > self.retry_wait_s:
                        raise OpencodeCallFailed(f"opencode kept retrying for {self.retry_wait_s:.0f} s: {text[:200]}")
                elif not st:   # idle: finished, failed, or not started yet
                    msg = _last_assistant(srv.request("GET", f"/session/{sid}/message") or [])
                    if msg is not None and ((msg["info"].get("time") or {}).get("completed") or msg["info"].get("error")):
                        break
                    if time.time() - t0 > self.idle_grace_s:
                        raise OpencodeCallFailed("the session went idle with no answer")
                time.sleep(self.poll_s)
            done = True
            latency = time.time() - t0
            out = parse_answer(msg, provider_id, model_id)
            if out["tokens_in"] + out["cache_read"] + out["cache_write"] == 0:
                out["tokens_in"] = max(1, (len(user) + len(self.sentence)) // 4)
            if not srv.plugin_fired(sid):
                raise OpencodeCallFailed("the system-prompt plugin did not run for this call, so opencode's "
                                         "own system text may have been sent; answer discarded")
            out["latency_s"] = latency
            out["session"] = sid
            return out
        finally:
            try:
                if not done:
                    srv.request("POST", f"/session/{sid}/abort", {})
                srv.request("DELETE", f"/session/{sid}")
            except OpencodeError:
                pass

    def close(self) -> None:
        self.server.stop()


def split_model(api_model: str) -> tuple[str, str]:
    """'opencode/deepseek-v4.1-flash-free' -> ('opencode', 'deepseek-v4.1-flash-free').
    Refuses any model id that does not end in '-free' (no money may be spent)."""
    if "/" not in api_model:
        raise ValueError(f"opencode_cli api_model must be 'provider/model', got {api_model!r}")
    provider_id, model_id = api_model.split("/", 1)
    if not model_id.endswith("-free"):
        raise ValueError(f"opencode_cli: only free models (id ending in '-free') are allowed, got {api_model!r}")
    return provider_id, model_id


def _last_assistant(msgs: list) -> dict | None:
    a = [m for m in msgs if (m.get("info") or {}).get("role") == "assistant"]
    return a[-1] if a else None


def parse_answer(msg: dict | None, provider_id: str, model_id: str) -> dict:
    """The answer and its token counts from opencode's assistant message; raises on anything
    that is not a real answer."""
    if msg is None:
        raise OpencodeCallFailed("no answer message")
    info, parts = msg.get("info") or {}, msg.get("parts") or []
    err = info.get("error")
    if err:
        data = err.get("data") if isinstance(err, dict) else None
        text = (data or {}).get("message") if isinstance(data, dict) else None
        text = str(text or err)[:300]
        if ALLOWANCE_RE.search(text):
            raise OpencodeLimitReached(f"free allowance used up: {text}")
        name = err.get("name") if isinstance(err, dict) else "error"
        raise OpencodeCallFailed(f"opencode reported {name}: {text}")
    if any(p.get("type") == "tool" for p in parts):
        raise OpencodeCallFailed("the model tried to use a tool (tools should be off)")
    text = "".join(p.get("text") or "" for p in parts if p.get("type") == "text" and not p.get("synthetic"))
    if not text.strip():
        raise OpencodeCallFailed(f"empty answer (finish: {info.get('finish')})")
    if ALLOWANCE_RE.search(text) and len(text) < 600:
        raise OpencodeLimitReached(f"free allowance used up (said as text): {text[:200]}")
    if LIMIT_RE.search(text) and len(text) < 300:
        raise OpencodeCallFailed(f"limit text instead of an answer: {text[:200]}")
    if SERVER_ERR_RE.search(text) and len(text) < 300:
        raise OpencodeCallFailed(f"server error text instead of an answer: {text[:200]}")
    tok = info.get("tokens") or {}
    tin = int(tok.get("input") or 0)
    tout = int(tok.get("output") or 0)
    reasoning = int(tok.get("reasoning") or 0)
    cache = tok.get("cache") or {}
    cr, cw = int(cache.get("read") or 0), int(cache.get("write") or 0)
    estimated = False
    if tin + cr + cw == 0 or tout + reasoning == 0:
        # No counts reported: the answer is estimated here by length (about 4 characters a
        # token); the prompt (not part of this message) is estimated by the caller.
        estimated = True
        if tout + reasoning == 0:
            tout = max(1, len(text) // 4)
    return {"text": text, "tokens_in": tin, "tokens_out": tout + reasoning, "reasoning_tokens": reasoning,
            "cache_read": cr, "cache_write": cw, "finish": info.get("finish"),
            "model_id": f"{provider_id}/{model_id}", "tokens_estimated": estimated}


_ROUTES: dict[str, OpencodeRoute] = {}
_ROUTES_LOCK = threading.Lock()


def get_route(pcfg: dict) -> OpencodeRoute:
    """The shared route for this provider configuration (one server and one cap per process)."""
    key = json.dumps(pcfg or {}, sort_keys=True, default=str)
    with _ROUTES_LOCK:
        r = _ROUTES.get(key)
        if r is None:
            r = _ROUTES[key] = OpencodeRoute(pcfg)
        return r


def close_all() -> None:
    with _ROUTES_LOCK:
        for r in _ROUTES.values():
            r.close()
        _ROUTES.clear()


import atexit  # noqa: E402

atexit.register(close_all)
