"""Measures for the study: is the old score still right, and is a difference real?

Everyday picture: we had the old helper's grades on every tip. Now the new
helper tries tips on test jobs. These functions answer:
  - concordance: "when two tips differ in how well they worked for the new
    helper, does the higher-graded one win?" (0.5 = coin toss, 1 = always)
  - first_shown_success: "if we show the tip each rule ranks first, how often
    is the job solved?"
  - paired_bootstrap / cluster_bootstrap: "how sure are we about a difference
    between two rules?" (re-draw the test jobs many times)
  - equivalence_tost: "may we say there is NO drop?" (only if the whole 90 %
    interval sits inside a small margin)
  - holm: "we ran several tests; adjust the p-values so luck does not fool us"
Added for the master plan (sections 2.8 and 2.9):
  - concordance(weighted=True): pairs weighted by how much the outcomes differ
  - topk_agreement: "is the tip ranked first one of the tips that worked best?"
  - log_score / brier: "how good were the predicted chances of success?"
  - shapley_values: "how much of the success does each tip shown together earn?"
  - bootstrap_within_orders / paired_within_orders: intervals that redraw
    tasks inside each stream order (the orders stay fixed)
  - noninferiority: "is the drop surely smaller than the margin?"
  - retained_validity: the drop and the share of validity kept

The probe table
---------------
    probe_table = {task_id: {item_id or None: [success, success, ...]}}
For each probe task, each candidate item was shown alone (and None = no item
shown) a few times; the list holds the True/False result of each repeat.
`build_probe_table` makes it from call records.

All randomness comes from seeded numpy generators, so results repeat exactly.
"""

from __future__ import annotations

import math
from itertools import combinations
from typing import Callable, Dict, Hashable, Iterable, List, Mapping, NamedTuple, Optional, Sequence, Tuple, Union

import numpy as np

from .scores import PROB_CLIP, SCORE_TIE_TOL, mixed_scores, rank

ProbeTable = Dict[Hashable, Dict[Optional[str], List[bool]]]


# ---------------------------------------------------------------------------
# Probe table helpers
# ---------------------------------------------------------------------------


def _as_bool(v, where: str) -> bool:
    if isinstance(v, (bool, np.bool_)):
        return bool(v)
    if v in (0, 1):
        return bool(v)
    raise ValueError(f"{where}: correct must be True/False or 0/1, got {v!r}")


def build_probe_table(
    records: Iterable[Mapping],
    task_key: str = "task_id",
    item_key: str = "item_shown",
    correct_key: str = "correct",
) -> ProbeTable:
    """Build the probe table from call records.

    Each record is a dict with at least task_id, item_shown and correct.
    item_shown None (or "") means no memory item was shown. Repeats keep the
    order in which the records arrive. Filter the records to ONE model (and
    one bank) before calling this.
    """
    table: ProbeTable = {}
    for n, rec in enumerate(records):
        task = rec[task_key]
        item = rec.get(item_key)
        if item == "":
            item = None
        ok = _as_bool(rec[correct_key], f"record #{n}")
        table.setdefault(task, {}).setdefault(item, []).append(ok)
    return table


def probe_outcomes(probe_table: ProbeTable, include_no_memory: bool = False) -> Dict[Hashable, Dict[Optional[str], float]]:
    """{task: {item: success rate over repeats}}. With 2 repeats the rate is
    0, 0.5 or 1. The no-memory cell (None) is left out unless asked for."""
    out: Dict[Hashable, Dict[Optional[str], float]] = {}
    for task, cells in probe_table.items():
        row = {}
        for item, results in cells.items():
            if item is None and not include_no_memory:
                continue
            if results:
                row[item] = float(np.mean([bool(x) for x in results]))
        out[task] = row
    return out


def candidate_sets(probe_table: ProbeTable) -> Dict[Hashable, List[str]]:
    """{task: [candidate items]} (the no-memory cell excluded), table order."""
    return {t: [i for i in cells if i is not None] for t, cells in probe_table.items()}


def differing_task_fraction(probe_table: ProbeTable) -> float:
    """Share of probe tasks whose candidates do not all have the same success
    rate. Pilot gate condition 4 needs at least 0.30."""
    outs = probe_outcomes(probe_table)
    if not outs:
        return float("nan")
    differ = sum(1 for row in outs.values() if len(set(row.values())) > 1)
    return differ / len(outs)


# ---------------------------------------------------------------------------
# Concordance (retained validity)
# ---------------------------------------------------------------------------


def _is_nested(d: Mapping) -> bool:
    """True if d looks like {task: {item: value}} rather than {item: value}."""
    for v in d.values():
        return isinstance(v, Mapping)
    return False


def _lookup(d: Mapping, nested: bool, task, item, what: str) -> float:
    try:
        return float(d[task][item]) if nested else float(d[item])
    except KeyError:
        raise KeyError(f"no {what} for item {item!r} in task {task!r}") from None


class ConcordanceResult(NamedTuple):
    value: float  # fraction of judged pairs ordered correctly (NaN if no pairs)
    n_pairs: int  # number of candidate pairs whose outcomes differ


def _concordance_parts(
    scores: Mapping,
    outcomes: Mapping,
    candidate_sets: Optional[Mapping[Hashable, Sequence[str]]],
    tie_credit: float,
) -> Dict[Hashable, Tuple[float, int, float, float]]:
    """{task: (credit, n_pairs, weighted credit, total weight)}.

    The weight of an informative pair is |outcome_a - outcome_b| (see
    `concordance`, weighted=True)."""
    s_nested = _is_nested(scores)
    o_nested = _is_nested(outcomes)
    if candidate_sets is None:
        if not o_nested:
            raise ValueError("give candidate_sets, or outcomes as {task: {item: rate}}")
        candidate_sets = {t: [i for i in row if i is not None] for t, row in outcomes.items()}
    out: Dict[Hashable, Tuple[float, int, float, float]] = {}
    for task, cands in candidate_sets.items():
        items = [c for c in dict.fromkeys(cands) if c is not None]
        # Candidates without an outcome cannot be judged; leave them out.
        if o_nested:
            row = outcomes.get(task, {})
            items = [c for c in items if c in row]
        else:
            items = [c for c in items if c in outcomes]
        credit, pairs = 0.0, 0
        wcredit, wsum = 0.0, 0.0
        for a in range(len(items)):
            for b in range(a + 1, len(items)):
                ia, ib = items[a], items[b]
                oa = _lookup(outcomes, o_nested, task, ia, "outcome")
                ob = _lookup(outcomes, o_nested, task, ib, "outcome")
                if abs(oa - ob) <= SCORE_TIE_TOL:
                    continue  # outcomes equal: this pair says nothing
                pairs += 1
                wt = abs(oa - ob)
                wsum += wt
                sa = _lookup(scores, s_nested, task, ia, "score")
                sb = _lookup(scores, s_nested, task, ib, "score")
                if abs(sa - sb) <= SCORE_TIE_TOL:
                    credit += tie_credit
                    wcredit += tie_credit * wt
                elif (sa > sb) == (oa > ob):
                    credit += 1.0
                    wcredit += wt
        out[task] = (credit, pairs, wcredit, wsum)
    return out


def concordance_per_task(
    scores: Mapping,
    outcomes: Mapping,
    candidate_sets: Optional[Mapping[Hashable, Sequence[str]]] = None,
    tie_credit: float = 0.5,
    weighted: bool = False,
) -> Dict[Hashable, Tuple[float, float]]:
    """{task: (numerator, denominator)}; the concordance is the sum of the
    numerators over the sum of the denominators.

    weighted=False (default): (credit, n_pairs), n_pairs an int.
    weighted=True: (weighted credit, total weight), each informative pair
    weighted by |outcome_a - outcome_b|.
    See `concordance` for the rule. Kept separate so a bootstrap can resample
    tasks (weight each task by its denominator).
    """
    parts = _concordance_parts(scores, outcomes, candidate_sets, tie_credit)
    if weighted:
        return {t: (wc, ws) for t, (_, _, wc, ws) in parts.items()}
    return {t: (c, p) for t, (c, p, _, _) in parts.items()}


def concordance(
    scores: Mapping,
    outcomes: Mapping,
    candidate_sets: Optional[Mapping[Hashable, Sequence[str]]] = None,
    tie_credit: float = 0.5,
    weighted: bool = False,
) -> ConcordanceResult:
    """Retained validity: pairwise concordance of scores with outcomes.

    Rule: inside each task, take every pair of candidates whose outcomes
    DIFFER (different success rates). The pair counts 1 if the item with the
    higher score has the better outcome, 0 if the lower-scored one does, and
    0.5 if the two scores are TIED (equal to 12 decimal places).
    Concordance = total credit / number of such pairs.
    Everyday meaning: "of the tip pairs where one really worked better, how
    often did the grades point to the right one?" 0.5 = coin toss.

    Why ties count 0.5: a tied pair is a coin toss for the ranker, so it earns
    what a coin earns. Dropping ties instead would reward a rule (such as wipe)
    for refusing to rank. Pairs never cross tasks.

    scores:   {item: score} or {task: {item: score}} (task-specific, e.g. the
              mixed relevance + score values from `mixed_by_task`)
    outcomes: {item: rate} or {task: {item: rate}} (use `probe_outcomes`)
    candidate_sets: {task: [items]}; may be omitted when outcomes are per task.

    weighted=True (the master plan's primary Cw): each informative pair counts
    with weight |outcome_a - outcome_b|, so a 1-versus-0 pair counts twice as
    much as a 1-versus-0.5 pair; a score tie still earns half its weight.
    value = weighted credit / total weight; n_pairs is still the plain count.
    Everyday meaning: "a clear win should count more than a narrow one".
    With all outcome gaps equal (e.g. one repeat, outcomes 0 or 1) it equals
    the unweighted value.

    Note: concordance depends only on the ORDER of scores inside a task. A
    rule that moves every score the same monotone way (for example the value
    rule's fixed discount, which pulls every q toward 0.5 by the same share)
    gives the same concordance as keep unless scores are mixed with relevance.
    """
    parts = _concordance_parts(scores, outcomes, candidate_sets, tie_credit)
    pairs = sum(p for _, p, _, _ in parts.values())
    if weighted:
        num = sum(wc for _, _, wc, _ in parts.values())
        den = sum(ws for _, _, _, ws in parts.values())
        return ConcordanceResult(num / den if den > 0 else float("nan"), int(pairs))
    credit = sum(c for c, _, _, _ in parts.values())
    return ConcordanceResult(credit / pairs if pairs else float("nan"), int(pairs))


def mixed_by_task(
    arm_scores: Mapping[str, float],
    relevance: Mapping[Hashable, Mapping[str, float]],
    candidate_sets: Mapping[Hashable, Sequence[str]],
    w: float = 0.5,
    default_score: float = 0.5,
    relevance_norm: str = "none",
) -> Dict[Hashable, Dict[str, float]]:
    """{task: {item: w * relevance + (1 - w) * score}}: the value each arm
    actually ranks by at retrieval. Feed it to `concordance` as `scores`."""
    return {
        t: mixed_scores(list(c), relevance[t], arm_scores, w, default_score, relevance_norm)
        for t, c in candidate_sets.items()
        if c
    }


def retained_validity_ratio(home, swapped) -> float:
    """(swapped - 0.5) / (home - 0.5): the share of the home model's
    above-chance ranking skill that survives the swap. 1 = all of it,
    0 = none (coin toss), negative = worse than a coin.
    Accepts numbers or ConcordanceResult. Returns NaN when home is exactly 0.5
    (nothing to retain). The ratio is unstable when home is near 0.5, so
    bootstrap it jointly and respect the gate's home >= 0.60 floor."""
    h = float(getattr(home, "value", home))
    s = float(getattr(swapped, "value", swapped))
    if math.isnan(h) or math.isnan(s) or abs(h - 0.5) <= SCORE_TIE_TOL:
        return float("nan")
    return (s - 0.5) / (h - 0.5)


# ---------------------------------------------------------------------------
# First-shown success (top-1 quality)
# ---------------------------------------------------------------------------


class FirstShownResult(NamedTuple):
    mean: float  # average success of the first-shown item over tasks
    per_task: Dict[Hashable, float]  # success rate of the shown item, per task
    mean_regret: float  # average (best candidate - shown item)
    per_task_regret: Dict[Hashable, float]
    shown: Dict[Hashable, str]  # which item each task would show


def first_shown_success(
    arm_scores: Mapping[str, float],
    relevance: Mapping[Hashable, Mapping[str, float]],
    probe_table: ProbeTable,
    w: float = 0.5,
    default_score: float = 0.5,
    relevance_norm: str = "none",
) -> FirstShownResult:
    """For every probe task, find the item the arm would show first (by
    `scores.rank`, among that task's probed candidates only, because only
    those have outcomes) and look up its success rate in the probe table.

    arm_scores: {item: normalised score in [0, 1]} (rule.normalised_scores(bank))
    relevance:  {task: {item: relevance}}
    Regret = best candidate's success rate minus the shown item's.
    Tasks with no candidates are skipped. No new model calls are made.
    """
    per, reg, shown = {}, {}, {}
    outs = probe_outcomes(probe_table)
    for task, row in outs.items():
        cands = list(row)
        if not cands:
            continue
        top = rank(cands, relevance[task], arm_scores, w, default_score, relevance_norm)[0]
        per[task] = row[top]
        reg[task] = max(row.values()) - row[top]
        shown[task] = top
    mean = float(np.mean(list(per.values()))) if per else float("nan")
    mreg = float(np.mean(list(reg.values()))) if reg else float("nan")
    return FirstShownResult(mean, per, mreg, reg, shown)


# ---------------------------------------------------------------------------
# Bootstrap intervals
# ---------------------------------------------------------------------------


class BootstrapResult(NamedTuple):
    mean_diff: float  # statistic(a) - statistic(b) on the real data
    ci_low: float  # lower end of the interval (percentile method)
    ci_high: float  # upper end
    samples: np.ndarray  # every resampled difference (feed to equivalence_tost)
    n_units: int  # number of paired tasks used


def _align(values_a, values_b, weights_a=None, weights_b=None):
    """Line up two per-task value sets. Dicts are paired by key (sorted keys,
    tasks missing from either side dropped); sequences by position. Pairs
    with a NaN value are dropped."""
    if isinstance(values_a, Mapping) != isinstance(values_b, Mapping):
        raise TypeError("give both value sets as dicts or both as sequences")
    if isinstance(values_a, Mapping):
        keys = sorted(set(values_a) & set(values_b), key=repr)
        a = np.array([values_a[k] for k in keys], dtype=float)
        b = np.array([values_b[k] for k in keys], dtype=float)
        wa = np.array([weights_a[k] for k in keys], dtype=float) if weights_a is not None else None
        wb = np.array([weights_b[k] for k in keys], dtype=float) if weights_b is not None else None
    else:
        a = np.asarray(values_a, dtype=float)
        b = np.asarray(values_b, dtype=float)
        if a.shape != b.shape:
            raise ValueError("paired sequences must have the same length")
        keys = list(range(len(a)))
        wa = np.asarray(weights_a, dtype=float) if weights_a is not None else None
        wb = np.asarray(weights_b, dtype=float) if weights_b is not None else None
    if wa is None:
        wa = np.ones_like(a)
    if wb is None:
        wb = wa.copy()
    keep = ~(np.isnan(a) | np.isnan(b))
    a, b, wa, wb = np.where(keep, a, 0.0), np.where(keep, b, 0.0), np.where(keep, wa, 0.0), np.where(keep, wb, 0.0)
    idx = np.flatnonzero(keep)
    return [keys[i] for i in idx], a[idx], b[idx], wa[idx], wb[idx]


def _wmean_diff(a, b, wa, wb) -> float:
    sa, sb = wa.sum(), wb.sum()
    if sa <= 0 or sb <= 0:
        return float("nan")
    return float((wa * a).sum() / sa - (wb * b).sum() / sb)


def paired_bootstrap(
    values_a,
    values_b,
    n: int = 10000,
    seed: int = 0,
    weights_a=None,
    weights_b=None,
    ci: float = 0.95,
) -> BootstrapResult:
    """Mean difference a - b over paired tasks, with a percentile bootstrap
    interval (default 95 %).

    Everyday meaning: "draw the same number of test jobs again, with
    replacement, 10,000 times, and see how much the difference wobbles".

    values_a, values_b: {task: value} (paired by task) or equal-length lists.
    weights (optional): per-task weights, e.g. n_pairs from
    `concordance_per_task`, which turns per-task concordances into the pooled
    concordance. weights_b defaults to weights_a. Resamples whose total weight
    is zero give NaN and are ignored in the interval.
    """
    keys, a, b, wa, wb = _align(values_a, values_b, weights_a, weights_b)
    m = len(a)
    if m == 0:
        raise ValueError("no paired tasks")
    point = _wmean_diff(a, b, wa, wb)
    rng = np.random.default_rng(seed)
    out = np.empty(n, dtype=float)
    chunk = max(1, min(n, 2_000_000 // max(m, 1)))
    done = 0
    while done < n:
        c = min(chunk, n - done)
        idx = rng.integers(0, m, size=(c, m))
        swa, swb = wa[idx].sum(axis=1), wb[idx].sum(axis=1)
        with np.errstate(invalid="ignore", divide="ignore"):
            out[done : done + c] = (wa[idx] * a[idx]).sum(axis=1) / swa - (wb[idx] * b[idx]).sum(axis=1) / swb
        done += c
    tail = (1.0 - ci) / 2.0 * 100.0
    lo, hi = np.nanpercentile(out, [tail, 100.0 - tail])
    return BootstrapResult(point, float(lo), float(hi), out, m)


def _split_orders(values) -> Dict[Hashable, Dict[Hashable, float]]:
    """Accept {(order, task): v} or {order: {task: v}}; return the nested form."""
    if _is_nested(values):
        return {o: dict(row) for o, row in values.items()}
    nested: Dict[Hashable, Dict[Hashable, float]] = {}
    for key, v in values.items():
        try:
            order, task = key
        except (TypeError, ValueError):
            raise ValueError("cluster bootstrap keys must be (order, task) pairs") from None
        nested.setdefault(order, {})[task] = v
    return nested


def cluster_bootstrap(
    values_a,
    values_b,
    n: int = 10000,
    seed: int = 0,
    weights_a=None,
    weights_b=None,
    ci: float = 0.95,
    resample_orders: bool = True,
) -> BootstrapResult:
    """Paired bootstrap that respects stream orders (tasks sit inside orders).

    values: {(order, task): value} or {order: {task: value}}; weights alike.
    resample_orders=True (two-stage cluster bootstrap): each resample first
    draws stream orders with replacement, then draws tasks with replacement
    inside each drawn order. resample_orders=False: orders stay fixed and
    tasks are redrawn inside each order (stratified).
    Everyday meaning: "a different shuffle of the stream could have given
    different results; let the interval show that too".
    With only 3 orders, the order-level draw dominates the width.
    """
    va, vb = _split_orders(values_a), _split_orders(values_b)
    wa_n = _split_orders(weights_a) if weights_a is not None else None
    wb_n = _split_orders(weights_b) if weights_b is not None else None
    groups = []  # per order: arrays a, b, wa, wb
    all_a, all_b, all_wa, all_wb = [], [], [], []
    for order in sorted(set(va) & set(vb), key=repr):
        # weights_b missing -> _align reuses weights_a for b.
        _, a, b, wa, wb = _align(
            va[order], vb[order], wa_n.get(order) if wa_n else None, wb_n.get(order) if wb_n else None
        )
        if len(a):
            groups.append((a, b, wa, wb))
            all_a.append(a)
            all_b.append(b)
            all_wa.append(wa)
            all_wb.append(wb)
    if not groups:
        raise ValueError("no paired (order, task) units")
    point = _wmean_diff(np.concatenate(all_a), np.concatenate(all_b), np.concatenate(all_wa), np.concatenate(all_wb))
    rng = np.random.default_rng(seed)
    g = len(groups)
    out = np.empty(n, dtype=float)
    for r in range(n):
        picks = rng.integers(0, g, size=g) if resample_orders else np.arange(g)
        swa = swb = sa = sb = 0.0
        for p in picks:
            a, b, wa, wb = groups[p]
            idx = rng.integers(0, len(a), size=len(a))
            swa += wa[idx].sum()
            swb += wb[idx].sum()
            sa += (wa[idx] * a[idx]).sum()
            sb += (wb[idx] * b[idx]).sum()
        out[r] = sa / swa - sb / swb if swa > 0 and swb > 0 else np.nan
    tail = (1.0 - ci) / 2.0 * 100.0
    lo, hi = np.nanpercentile(out, [tail, 100.0 - tail])
    return BootstrapResult(point, float(lo), float(hi), out, int(sum(len(x[0]) for x in groups)))


# ---------------------------------------------------------------------------
# Equivalence ("no drop") and tests
# ---------------------------------------------------------------------------


class EquivalenceResult(NamedTuple):
    no_drop: bool  # True only if the whole 90 % interval is inside +-margin
    ci_low: float
    ci_high: float
    margin: float


def equivalence_tost(diff_samples=None, ci: Optional[Tuple[float, float]] = None, margin: float = 0.03, alpha: float = 0.05) -> EquivalenceResult:
    """Two one-sided tests (TOST) in interval form.

    Claim "no drop" only if the 90 % interval of the difference lies strictly
    inside (-margin, +margin). (Two one-sided tests at 5 % each are the same
    as checking the 90 % interval.) A failed difference test is NEVER evidence
    of no drop; only this check is.
    Everyday meaning: "we may say the two are the same only if even the
    worst plausible gap is smaller than the margin".

    Give either `diff_samples` (bootstrap differences, or a BootstrapResult)
    from which the 5th and 95th percentiles are taken, or `ci` = (low, high),
    which must already be a 90 % interval (1 - 2 * alpha).
    margin = 0.03: in the units of the difference (0.03 of concordance, or
    3 percentage points of success when values are 0..1 rates).
    """
    if diff_samples is not None:
        samples = getattr(diff_samples, "samples", diff_samples)
        lo, hi = np.nanpercentile(np.asarray(samples, dtype=float), [100.0 * alpha, 100.0 * (1.0 - alpha)])
    elif ci is not None:
        lo, hi = ci
    else:
        raise ValueError("give diff_samples or ci")
    lo, hi = float(lo), float(hi)
    return EquivalenceResult(bool(lo > -margin and hi < margin), lo, hi, float(margin))


def paired_permutation_test(values_a, values_b, n: int = 10000, seed: int = 0) -> float:
    """Two-sided p-value for "a and b have the same mean" by random sign flips
    of the paired differences (the study's planned paired permutation test).
    Everyday meaning: "if the two rules were really the same, swapping their
    labels on each task would make no difference; how often does chance alone
    give a gap this big?" p = (1 + count of |flipped| >= |observed|) / (n + 1)."""
    _, a, b, _, _ = _align(values_a, values_b)
    d = a - b
    if len(d) == 0:
        raise ValueError("no paired tasks")
    obs = abs(d.mean())
    rng = np.random.default_rng(seed)
    hits = 0
    chunk = max(1, min(n, 2_000_000 // len(d)))
    done = 0
    while done < n:
        c = min(chunk, n - done)
        signs = rng.integers(0, 2, size=(c, len(d))) * 2 - 1
        hits += int((np.abs((signs * d).mean(axis=1)) >= obs - 1e-12).sum())
        done += c
    return (1 + hits) / (n + 1)


class HolmResult(NamedTuple):
    adjusted: List[float]  # Holm-adjusted p-values, in the input order
    reject: List[bool]  # True where adjusted p <= alpha


def holm(pvalues: Sequence[float], alpha: float = 0.05) -> HolmResult:
    """Holm step-down correction for several tests (the 4 primary contrasts).
    Sort p-values smallest first; multiply the j-th smallest by (m - j + 1);
    make the results non-decreasing; cap at 1.
    Everyday meaning: "the more questions we ask, the stronger each answer
    must be before we believe it"."""
    p = np.asarray(pvalues, dtype=float)
    m = len(p)
    if m == 0:
        return HolmResult([], [])
    order = np.argsort(p, kind="stable")
    adj_sorted = np.minimum(1.0, np.maximum.accumulate((m - np.arange(m)) * p[order]))
    adj = np.empty(m)
    adj[order] = adj_sorted
    return HolmResult([float(x) for x in adj], [bool(x <= alpha) for x in adj])


# ===========================================================================
# Master-plan measures (sections 2.8 and 2.9), added 23 Nov 2026
# ===========================================================================


# ---------------------------------------------------------------------------
# Agreement on the top item (and the top k)
# ---------------------------------------------------------------------------


class TopKResult(NamedTuple):
    value: float  # share of judged tasks where the top k by score hit the best k by outcome
    n_tasks: int  # number of judged tasks


def _task_rows(scores: Mapping, outcomes: Mapping, cand_sets) -> Iterable[Tuple[Hashable, List[str], List[float], List[float]]]:
    """(task, items, scores, outcomes) per task, candidates without an
    outcome left out, in the candidates' given order."""
    s_nested = _is_nested(scores)
    o_nested = _is_nested(outcomes)
    if cand_sets is None:
        if not o_nested:
            raise ValueError("give cand_sets, or outcomes as {task: {item: rate}}")
        cand_sets = {t: [i for i in row if i is not None] for t, row in outcomes.items()}
    for task, cands in cand_sets.items():
        items = [c for c in dict.fromkeys(cands) if c is not None]
        if o_nested:
            row = outcomes.get(task, {})
            items = [c for c in items if c in row]
        else:
            items = [c for c in items if c in outcomes]
        o = [_lookup(outcomes, o_nested, task, i, "outcome") for i in items]
        s = [_lookup(scores, s_nested, task, i, "score") for i in items]
        yield task, items, s, o


def _topk_hit(s: List[float], o: List[float], k: int, tie_break: str) -> float:
    """Chance that the k items with the highest score include at least one of
    the best k items by outcome (see `topk_agreement`)."""
    tol = SCORE_TIE_TOL
    kth_o = sorted(o, reverse=True)[k - 1]
    good = [x >= kth_o - tol for x in o]
    if tie_break == "order":
        order = sorted(range(len(s)), key=lambda j: (-s[j], j))[:k]
        return 1.0 if any(good[j] for j in order) else 0.0
    cut = sorted(s, reverse=True)[k - 1]
    above = [x > cut + tol for x in s]
    at = [abs(x - cut) <= tol for x in s]
    if any(a and g for a, g in zip(above, good)):
        return 1.0
    r = k - sum(above)  # places left for the items tied at the cut
    t = sum(at)
    g_t = sum(1 for a, g in zip(at, good) if a and g)
    return 1.0 - math.comb(t - g_t, r) / math.comb(t, r)


def topk_agreement_per_task(
    scores: Mapping, outcomes: Mapping, cand_sets: Optional[Mapping] = None, k: int = 1, tie_break: str = "expected"
) -> Dict[Hashable, float]:
    """{task: agreement between 0 and 1} for every judged task (see
    `topk_agreement`); feed the values to `bootstrap_within_orders`."""
    if int(k) < 1:
        raise ValueError("k must be at least 1")
    if tie_break not in ("expected", "order"):
        raise ValueError("tie_break must be 'expected' or 'order'")
    k = int(k)
    out: Dict[Hashable, float] = {}
    for task, items, s, o in _task_rows(scores, outcomes, cand_sets):
        if not items:
            continue
        kth_o = sorted(o, reverse=True)[min(k, len(o)) - 1]
        outside = sum(1 for x in o if x < kth_o - SCORE_TIE_TOL)
        if outside < k:
            continue  # any k items would hit: the task cannot tell rankings apart
        out[task] = _topk_hit(s, o, k, tie_break)
    return out


def topk_agreement(
    scores: Mapping, outcomes: Mapping, cand_sets: Optional[Mapping] = None, k: int = 1, tie_break: str = "expected"
) -> TopKResult:
    """Share of tasks where the top k items by score overlap the top k by outcome.

    Everyday meaning: "does the tip the grades put first (or one of the first
    k) belong to the tips that really worked best on this job?"

    Rules, per task (pairs never cross tasks):
    - The best k by outcome include ties: an item counts if fewer than k
      candidates did strictly better. (With 2 repeats outcomes are 0, 0.5 or 1
      and ties are common; picking one tied item at random would add noise.)
    - The top k by score are exactly k items. Score ties at the cut are broken
      at random and the task earns the CHANCE of a hit
      (tie_break="expected", default; a fully tied ranking such as wipe earns
      what a coin earns, as in `concordance`). tie_break="order" breaks
      them by the candidates' given order instead (the retrieval order).
    - A hit = at least one item in both sets. Value = mean over judged tasks.
    - Skipped: tasks where ANY k items would hit, because fewer than k
      candidates fall outside the best k. That covers tasks whose candidates
      all have the same outcome and tasks with no more than k candidates; with
      k = 2 it also skips a task with one success and three tied failures.
    scores: {item: s} or {task: {item: s}}; outcomes: {task: {item: rate}} or
    {item: rate} with cand_sets {task: [items]}.
    Note: with 4 candidates and k = 2 a random ranking already hits 5 times in 6.
    """
    per = topk_agreement_per_task(scores, outcomes, cand_sets, k, tie_break)
    return TopKResult(float(np.mean(list(per.values()))) if per else float("nan"), len(per))


# ---------------------------------------------------------------------------
# Log score and Brier score of predicted success
# ---------------------------------------------------------------------------


def _outcome_mean(v, where: str) -> Optional[float]:
    """An outcome as a share of successes: bool, 0/1, a rate in [0, 1], or a
    list of True/False repeats (empty list -> None, the cell is skipped)."""
    if isinstance(v, (list, tuple, np.ndarray)):
        if len(v) == 0:
            return None
        return float(np.mean([_as_bool(x, where) for x in v]))
    if isinstance(v, (bool, np.bool_)):
        return 1.0 if bool(v) else 0.0
    y = float(v)
    if math.isnan(y) or not (0.0 <= y <= 1.0):
        raise ValueError(f"{where}: outcome must be between 0 and 1, got {v!r}")
    return y


def _prob_cells(probs, outcomes, clip: Tuple[float, float] = PROB_CLIP) -> List[Tuple[Hashable, float, float]]:
    """[(task or None, clipped p, outcome share)] for every scored cell."""
    cells: List[Tuple[Hashable, float, float]] = []
    lo, hi = float(clip[0]), float(clip[1])

    def add(task, p, v, where):
        y = _outcome_mean(v, where)
        if y is None:
            return
        if p is None:
            raise ValueError(f"{where}: no probability (the rule gives none)")
        cells.append((task, float(min(hi, max(lo, float(p)))), y))

    if not isinstance(outcomes, Mapping):
        ys = list(outcomes)
        ps = list(probs)
        if len(ys) != len(ps):
            raise ValueError("probs and outcomes must have the same length")
        for n, (p, v) in enumerate(zip(ps, ys)):
            add(None, p, v, f"cell #{n}")
        return cells
    if _is_nested(outcomes):
        p_nested = _is_nested(probs)
        for task, row in outcomes.items():
            for item, v in row.items():
                if item is None:
                    continue  # the no-memory cell has no item to score
                add(task, _lookup(probs, p_nested, task, item, "probability"), v, f"task {task!r} item {item!r}")
        return cells
    for key, v in outcomes.items():
        if key not in probs:
            raise KeyError(f"no probability for cell {key!r}")
        add(None, probs[key], v, f"cell {key!r}")
    return cells


def _cell_log(p: float, y: float) -> float:
    return y * math.log(p) + (1.0 - y) * math.log(1.0 - p)


def _cell_brier(p: float, y: float) -> float:
    # mean of (p - outcome)^2 over the repeats behind the share y
    return (p - y) ** 2 + y * (1.0 - y)


def log_score(probs, outcomes, clip: Tuple[float, float] = PROB_CLIP) -> float:
    """Mean log score of predicted success over cells (HIGHER is better; 0 is perfect).

    Everyday meaning: "how surprised were we, on average, by what actually
    happened?" A confident wrong forecast costs a lot.
    Per cell: y log p + (1 - y) log(1 - p), where y is the share of successes
    over the cell's repeats (so a cell with 2 repeats is the mean of its two
    binary log scores) and p is clipped to `clip` (default [0.01, 0.99], pre-registration
    2.8; the study passes evaluate.prob_clip). Every cell counts once.
    probs/outcomes: equal-length sequences; or {cell: p} and {cell: outcome};
    or outcomes {task: {item: outcome}} with probs {item: p} or {task: {item: p}}
    (the no-memory cell None is skipped). An outcome is True/False, 0/1, a
    rate, or a list of True/False repeats. NaN if there are no cells.
    """
    cells = _prob_cells(probs, outcomes, clip)
    return float(np.mean([_cell_log(p, y) for _, p, y in cells])) if cells else float("nan")


def brier(probs, outcomes, clip: Tuple[float, float] = PROB_CLIP) -> float:
    """Mean Brier score over cells (LOWER is better; 0 is perfect).

    Everyday meaning: "average squared gap between the forecast and what
    happened". Per cell: the mean of (p - outcome)^2 over the cell's binary
    repeats, which is (p - y)^2 + y(1 - y) for a success share y; p clipped to
    `clip` (default [0.01, 0.99]). Same input forms as `log_score`.
    """
    cells = _prob_cells(probs, outcomes, clip)
    return float(np.mean([_cell_brier(p, y) for _, p, y in cells])) if cells else float("nan")


def _per_task(cells, fn) -> Dict[Hashable, float]:
    acc: Dict[Hashable, List[float]] = {}
    for task, p, y in cells:
        acc.setdefault(task, []).append(fn(p, y))
    return {t: float(np.mean(v)) for t, v in acc.items()}


def log_score_per_task(probs, outcomes: Mapping, clip: Tuple[float, float] = PROB_CLIP) -> Dict[Hashable, float]:
    """{task: mean log score over that task's cells}; outcomes must be
    {task: {item: outcome}}. For resampling tasks (`bootstrap_within_orders`)."""
    if not _is_nested(outcomes):
        raise ValueError("per-task scores need outcomes as {task: {item: outcome}}")
    return _per_task(_prob_cells(probs, outcomes, clip), _cell_log)


def brier_per_task(probs, outcomes: Mapping, clip: Tuple[float, float] = PROB_CLIP) -> Dict[Hashable, float]:
    """{task: mean Brier score over that task's cells}; outcomes per task."""
    if not _is_nested(outcomes):
        raise ValueError("per-task scores need outcomes as {task: {item: outcome}}")
    return _per_task(_prob_cells(probs, outcomes, clip), _cell_brier)


# ---------------------------------------------------------------------------
# Exact Shapley values (realism check: items shown together)
# ---------------------------------------------------------------------------

#: The realism check runs all 16 subsets of 4 candidates; 6 is the cap.
MAX_SHAPLEY_ITEMS = 6


def shapley_values(subset_value: Mapping, items: Sequence[str]) -> Dict[str, float]:
    """Exact Shapley value of each item from the value of every subset.

    Everyday meaning: "four tips were shown in every possible combination;
    how much of the success does each tip deserve?" Each tip gets its extra
    success when added to a group, averaged over every order in which the
    tips could have been added.
        phi_i = sum over S without i of |S|! (n - |S| - 1)! / n! * (v(S + i) - v(S))
    The values add up to v(all items) - v(no item).
    subset_value: {frozenset of items: value} for all 2^n subsets, including
    the empty set (the no-memory result); sets or tuples as keys are accepted.
    Keys with other items are ignored. n is at most 6.
    Raises KeyError naming a missing subset.
    """
    items = list(items)
    if len(set(items)) != len(items):
        raise ValueError("items must be distinct")
    n = len(items)
    if n > MAX_SHAPLEY_ITEMS:
        raise ValueError(f"at most {MAX_SHAPLEY_ITEMS} items (2^n subsets); got {n}")
    v: Dict[frozenset, float] = {}
    for key, val in subset_value.items():
        v[frozenset(key)] = float(val)
    for r in range(n + 1):
        for combo in combinations(items, r):
            if frozenset(combo) not in v:
                raise KeyError(f"no value for the subset {sorted(combo)!r}; all {2 ** n} subsets are needed")
    fact = [math.factorial(j) for j in range(n + 1)]
    out: Dict[str, float] = {}
    for i in items:
        others = [x for x in items if x != i]
        phi = 0.0
        for r in range(n):
            wgt = fact[r] * fact[n - r - 1] / fact[n]
            for combo in combinations(others, r):
                s = frozenset(combo)
                phi += wgt * (v[s | {i}] - v[s])
        out[i] = phi
    return out


# ---------------------------------------------------------------------------
# Intervals by resampling tasks WITHIN each stream order
# ---------------------------------------------------------------------------


def _order_arrays(values_by_order: Mapping, what: str) -> Dict[Hashable, np.ndarray]:
    """{order: array} in sorted order, rows with a NaN dropped."""
    if not values_by_order:
        raise ValueError(f"{what}: no stream orders")
    out: Dict[Hashable, np.ndarray] = {}
    for key in sorted(values_by_order, key=repr):
        arr = np.asarray(values_by_order[key], dtype=float)
        if arr.ndim == 1:
            arr = arr[~np.isnan(arr)]
        elif arr.ndim == 2:
            arr = arr[~np.isnan(arr).any(axis=1)]
        else:
            raise ValueError(f"{what}: order {key!r} must be a 1-D array (or 2-D for stat='ratio')")
        if len(arr) == 0:
            raise ValueError(f"{what}: order {key!r} has no tasks")
        out[key] = arr
    return out


def _stat_rows(stat: Union[str, Callable]) -> Callable[[np.ndarray], np.ndarray]:
    """The statistic applied to every resample (rows of a (c, m[, 2]) array).

    "mean": mean of the task values.
    "ratio": sum of column 0 / sum of column 1 (e.g. concordance numerators
             and denominators from `concordance_per_task`).
    a function: called on each resampled array, must return a number."""
    if stat == "mean":
        def mean(x):
            if x.ndim != 2:
                raise ValueError("stat='mean' needs one value per task (a 1-D array per order)")
            return x.mean(axis=1)
        return mean
    if stat == "ratio":
        def ratio(x):
            if x.ndim != 3 or x.shape[2] != 2:
                raise ValueError("stat='ratio' needs (numerator, denominator) pairs, shape (tasks, 2)")
            den = x[:, :, 1].sum(axis=1)
            with np.errstate(invalid="ignore", divide="ignore"):
                return np.where(den != 0, x[:, :, 0].sum(axis=1) / np.where(den != 0, den, 1.0), np.nan)
        return ratio
    if callable(stat):
        return lambda x: np.array([float(stat(row)) for row in x])
    raise ValueError("stat must be 'mean', 'ratio' or a function")


def _within_orders(arrays_a, arrays_b, n: int, seed: int, stat, ci: float, pool: bool = True) -> dict:
    if pool:
        return _within_orders_pooled(arrays_a, arrays_b, n, seed, stat, ci)
    fn = _stat_rows(stat)
    rng = np.random.default_rng(seed)
    total = np.zeros(n, dtype=float)
    per_order: Dict[Hashable, float] = {}
    for key, a in arrays_a.items():
        b = arrays_b[key] if arrays_b is not None else None
        m = len(a)
        point = float(fn(a[None, ...])[0]) - (float(fn(b[None, ...])[0]) if b is not None else 0.0)
        per_order[key] = point
        chunk = max(1, min(n, 2_000_000 // max(m, 1)))
        done = 0
        while done < n:
            c = min(chunk, n - done)
            idx = rng.integers(0, m, size=(c, m))
            vals = fn(a[idx])
            if b is not None:
                vals = vals - fn(b[idx])  # same tasks drawn for both sides
            total[done : done + c] += vals
            done += c
    g = len(arrays_a)
    samples = total / g
    tail = (1.0 - ci) / 2.0 * 100.0
    if np.all(np.isnan(samples)):
        lo = hi = float("nan")
    else:
        lo, hi = (float(x) for x in np.nanpercentile(samples, [tail, 100.0 - tail]))
    return {"mean": float(np.mean(list(per_order.values()))), "lo": lo, "hi": hi,
            "samples": samples, "per_order": per_order}


def _within_orders_pooled(arrays_a, arrays_b, n: int, seed: int, stat, ci: float) -> dict:
    """Stratified bootstrap with the statistic POOLED over the orders (pre-registration
    2.2, 2.12 and 4.1): every order's tasks are resampled with replacement inside that
    order, then the statistic is computed on all resampled tasks together: the mean
    over all tasks ("mean"), or the sum of numerators over the sum of denominators
    ("ratio", e.g. Cw pooled over the three orders)."""
    rng = np.random.default_rng(seed)
    keys = list(arrays_a)
    if stat not in ("mean", "ratio") and not callable(stat):
        raise ValueError("stat must be 'mean', 'ratio' or a function")
    for key in keys:
        a = arrays_a[key]
        if stat == "mean" and a.ndim != 1:
            raise ValueError("stat='mean' needs one value per task (a 1-D array per order)")
        if stat == "ratio" and (a.ndim != 2 or a.shape[1] != 2):
            raise ValueError("stat='ratio' needs (numerator, denominator) pairs, shape (tasks, 2)")

    def point(arrs):
        allv = np.concatenate([arrs[k] for k in keys], axis=0)
        if stat == "mean":
            return float(allv.mean())
        if stat == "ratio":
            den = allv[:, 1].sum()
            return float(allv[:, 0].sum() / den) if den != 0 else float("nan")
        return float(stat(allv))

    per_order = {}
    for key in keys:
        one = {key: arrays_a[key]}
        pa = _pooled_point(one, stat)
        pb = _pooled_point({key: arrays_b[key]}, stat) if arrays_b is not None else 0.0
        per_order[key] = pa - pb
    est = point(arrays_a) - (point(arrays_b) if arrays_b is not None else 0.0)
    samples = np.empty(n, dtype=float)
    if callable(stat) and stat not in ("mean", "ratio"):
        for r in range(n):
            ra, rb = [], []
            for key in keys:
                m = len(arrays_a[key])
                idx = rng.integers(0, m, size=m)
                ra.append(arrays_a[key][idx])
                if arrays_b is not None:
                    rb.append(arrays_b[key][idx])
            va = float(stat(np.concatenate(ra, axis=0)))
            samples[r] = va - (float(stat(np.concatenate(rb, axis=0))) if arrays_b is not None else 0.0)
    else:
        sums = {"a": [np.zeros(n), np.zeros(n)], "b": [np.zeros(n), np.zeros(n)]}
        for key in keys:
            a = arrays_a[key]
            b = arrays_b[key] if arrays_b is not None else None
            m = len(a)
            chunk = max(1, min(n, 2_000_000 // max(m, 1)))
            done = 0
            while done < n:
                c = min(chunk, n - done)
                idx = rng.integers(0, m, size=(c, m))
                for side, arr in (("a", a), ("b", b)):
                    if arr is None:
                        continue
                    if stat == "mean":
                        sums[side][0][done:done + c] += arr[idx].sum(axis=1)
                        sums[side][1][done:done + c] += m
                    else:
                        g = arr[idx]
                        sums[side][0][done:done + c] += g[:, :, 0].sum(axis=1)
                        sums[side][1][done:done + c] += g[:, :, 1].sum(axis=1)
                done += c
        with np.errstate(invalid="ignore", divide="ignore"):
            va = np.where(sums["a"][1] != 0, sums["a"][0] / np.where(sums["a"][1] != 0, sums["a"][1], 1.0), np.nan)
            vb = (np.where(sums["b"][1] != 0, sums["b"][0] / np.where(sums["b"][1] != 0, sums["b"][1], 1.0), np.nan)
                  if arrays_b is not None else 0.0)
        samples = va - vb
    tail = (1.0 - ci) / 2.0 * 100.0
    if np.all(np.isnan(samples)):
        lo = hi = float("nan")
    else:
        lo, hi = (float(x) for x in np.nanpercentile(samples, [tail, 100.0 - tail]))
    return {"mean": est, "lo": lo, "hi": hi, "samples": samples, "per_order": per_order}


def _pooled_point(arrs: Mapping, stat) -> float:
    allv = np.concatenate([arrs[k] for k in arrs], axis=0)
    if stat == "mean":
        return float(allv.mean())
    if stat == "ratio":
        den = allv[:, 1].sum()
        return float(allv[:, 0].sum() / den) if den != 0 else float("nan")
    return float(stat(allv))


def bootstrap_within_orders(
    values_by_order: Mapping, n: int = 10000, seed: int = 0, stat: Union[str, Callable] = "mean", ci: float = 0.95,
    pool: bool = False,
) -> dict:
    """Interval for a per-task measure, resampling tasks WITHIN each stream order.

    Everyday meaning: "redraw the jobs of each stream order with replacement,
    10,000 times, and see how much the result wobbles". The three stream
    orders stay fixed (strata): with only three of them, redrawing the orders
    themselves is not valid (statistics note Q2, point 3).

    values_by_order: {order: per-task values (1-D array)}; for stat="ratio",
    {order: (tasks, 2) array of (numerator, denominator)}. NaN rows dropped.
    pool=True (the pre-registered form, Parts 2.2, 2.12 and 4.1; msr.evaluate uses it):
    the statistic is computed on the tasks of all orders together, every task with equal
    weight (a mean over all tasks; a ratio of summed numerators over summed denominators,
    so Cw is pooled through its pair weights). pool=False (default, kept for older
    callers): the statistic is computed in every order and the plain average over
    orders is taken.
    Returns {"mean": the statistic on the real data, "lo", "hi": percentile interval
    (default 95 %), "samples": every resampled value, "per_order": {order: statistic
    on the real data}}.
    """
    arrays = _order_arrays(values_by_order, "bootstrap_within_orders")
    return _within_orders(arrays, None, int(n), seed, stat, ci, pool)


def paired_within_orders(
    a_by_order: Mapping,
    b_by_order: Mapping,
    n: int = 10000,
    seed: int = 0,
    stat: Union[str, Callable] = "mean",
    ci: float = 0.95,
    pool: bool = False,
) -> dict:
    """Interval for the paired difference stat(a) - stat(b), resampling tasks
    within each stream order and drawing the SAME tasks for both sides.

    Everyday meaning: "both rules were tried on the same jobs; redraw the jobs
    and see how much the gap between the rules wobbles".
    a_by_order, b_by_order: {order: array}, the same orders, and within an
    order the same tasks in the same positions. A task with a NaN on either
    side is dropped from both. Returns the same dict as
    `bootstrap_within_orders` (for the difference a - b); `pool` as there.
    """
    if set(a_by_order) != set(b_by_order):
        raise ValueError("a and b must have the same stream orders")
    a_raw, b_raw = {}, {}
    for key in a_by_order:
        a = np.asarray(a_by_order[key], dtype=float)
        b = np.asarray(b_by_order[key], dtype=float)
        if a.shape != b.shape:
            raise ValueError(f"order {key!r}: a and b must have the same shape (paired by position)")
        bad = np.isnan(a) | np.isnan(b)
        if bad.ndim == 2:
            bad = bad.any(axis=1)
        a_raw[key], b_raw[key] = a[~bad], b[~bad]
    arrays_a = _order_arrays(a_raw, "paired_within_orders")
    arrays_b = {k: b_raw[k] for k in arrays_a}
    return _within_orders(arrays_a, arrays_b, int(n), seed, stat, ci, pool)


# ---------------------------------------------------------------------------
# Non-inferiority ("no drop") and retained validity
# ---------------------------------------------------------------------------


def noninferiority(diff_samples, margin: float, alpha: float = 0.05) -> dict:
    """One-sided test that a DROP is smaller than the margin.

    Everyday meaning: "we may say the old scores lost less than the margin
    only if even a pessimistic reading of the drop stays below it".
    diff_samples: resampled values of the drop, home minus swap (positive =
    worse after the swap); an array, a BootstrapResult, or the dict from
    `bootstrap_within_orders` / `paired_within_orders`.
    upper = the one-sided (1 - alpha) upper bound (the 95th percentile).
    pass = upper < margin. A gain after the swap is never a failure.
    The master plan's margin is a quarter of the home signal above chance:
    margin = 0.25 * (C_home - 0.5).
    Returns {"pass", "upper", "margin"}.
    """
    samples = diff_samples["samples"] if isinstance(diff_samples, Mapping) else getattr(diff_samples, "samples", diff_samples)
    arr = np.asarray(samples, dtype=float)
    if arr.size == 0 or np.all(np.isnan(arr)):
        raise ValueError("no samples of the drop")
    upper = float(np.nanpercentile(arr, 100.0 * (1.0 - alpha)))
    return {"pass": bool(upper < float(margin)), "upper": upper, "margin": float(margin)}


def retained_validity(c_home, c_swap, min_signal: float = 0.05) -> dict:
    """The drop and the share of validity kept after the swap.

    drop  = C_home - C_swap (positive = the old scores rank worse now).
    ratio = (C_swap - 0.5) / (C_home - 0.5): 1 = all of the above-chance skill
            survived, 0 = none (coin toss). None when the home signal above
            chance, C_home - 0.5, is below `min_signal` (the ratio would be
            noise divided by almost nothing).
    Everyday meaning: "how much of the old helper's knack for picking tips
    still works for the new helper?" Accepts numbers or ConcordanceResult.
    """
    h = float(getattr(c_home, "value", c_home))
    s = float(getattr(c_swap, "value", c_swap))
    drop = h - s
    ratio = None
    if not (math.isnan(h) or math.isnan(s)) and (h - 0.5) >= float(min_signal):
        ratio = (s - 0.5) / (h - 0.5)
    return {"drop": drop, "ratio": ratio}


# ===========================================================================
# Pre-registration rules (Parts 2.4, 2.9, 4.1, 4.2 and 4.4), added 23 Nov 2026
# ===========================================================================


# ---------------------------------------------------------------------------
# p-values from bootstrap draws (Part 4.2)
# ---------------------------------------------------------------------------


def _finite(samples) -> np.ndarray:
    arr = np.asarray(getattr(samples, "samples", samples), dtype=float)
    return arr[~np.isnan(arr)]


def p_upper(samples) -> float:
    """Evidence that theta > 0: (1 + #{theta*_b <= 0}) / (B + 1) (Part 4.2)."""
    arr = _finite(samples)
    return float((1 + np.count_nonzero(arr <= 0)) / (len(arr) + 1))


def p_lower(samples) -> float:
    """Evidence that theta < 0: (1 + #{theta*_b >= 0}) / (B + 1) (Part 4.2)."""
    arr = _finite(samples)
    return float((1 + np.count_nonzero(arr >= 0)) / (len(arr) + 1))


def p_two_sided(samples) -> float:
    """min(1, 2 min(p_upper, p_lower)) (Part 4.2)."""
    return float(min(1.0, 2.0 * min(p_upper(samples), p_lower(samples))))


# ---------------------------------------------------------------------------
# The joint stratified bootstrap as count matrices (Part 4.1)
# ---------------------------------------------------------------------------


def stratum_seed(seed: int, stream: str, order) -> list:
    """The generator seed of one task stratum (stream, order): numpy's default generator
    seeded with [evaluate.seed, a stable hash of "boot|stream|order"]. Every owner,
    reader, arm and family uses the SAME resampled task lists (Part 4.1)."""
    import hashlib
    h = int.from_bytes(hashlib.sha256(f"boot|{stream}|{order}".encode()).digest()[:8], "big")
    return [int(seed), h]


def bootstrap_counts(n_tasks: int, n_draws: int, seed) -> np.ndarray:
    """(n_draws, n_tasks) int32 matrix: how often each task is drawn in each resample of
    n_tasks tasks with replacement. Sums over a resample are then `counts @ values`, so
    every per-task array of a stratum is resampled with the same task lists at the cost
    of one matrix product."""
    rng = np.random.default_rng(seed)
    out = np.empty((n_draws, n_tasks), dtype=np.int32)
    chunk = max(1, min(n_draws, 4_000_000 // max(n_tasks, 1)))
    for start in range(0, n_draws, chunk):
        c = min(chunk, n_draws - start)
        idx = rng.integers(0, n_tasks, size=(c, n_tasks))
        flat = (np.arange(c)[:, None] * n_tasks + idx).ravel()
        out[start:start + c] = np.bincount(flat, minlength=c * n_tasks).reshape(c, n_tasks)
    return out


# ---------------------------------------------------------------------------
# Retained validity: when the ratio is defined (Part 2.4)
# ---------------------------------------------------------------------------

RATIO_DEFINED = "defined"
RATIO_UNDEFINED = "undefined: home signal too weak"
RATIO_UNBOUNDED = "defined; interval unbounded"


def ratio_rule(c_home: float, c_swap: float, home_samples, swap_samples, min_z: float = 4.0,
               max_bad_share: float = 0.005, ci: float = 0.95) -> dict:
    """The retained-validity ratio R = (C_swap - 0.5) / (C_home - 0.5) with the
    pre-registered rule (Part 2.4):

    - R is reported only if (C_home - 0.5) >= min_z x SE(C_home), SE = the standard
      deviation of C_home over the bootstrap draws (same pooling level). Otherwise
      status = "undefined: home signal too weak" and R is NaN (only D is shown).
    - If more than max_bad_share (0.5 %) of the draws have a denominator <= 0, the
      interval of R is reported as unbounded (lo = -inf, hi = +inf).
    - Otherwise the interval is the percentile interval of R over the draws.
    home_samples / swap_samples: the paired bootstrap draws of C_home and C_swap.
    Returns {"ratio", "lo", "hi", "status", "se_home", "bad_share"}."""
    hs = np.asarray(home_samples, dtype=float)
    ss = np.asarray(swap_samples, dtype=float)
    ok = ~(np.isnan(hs) | np.isnan(ss))
    se = float(np.std(hs[ok], ddof=1)) if ok.sum() > 1 else float("nan")
    out = {"ratio": float("nan"), "lo": float("nan"), "hi": float("nan"), "status": RATIO_UNDEFINED,
           "se_home": se, "bad_share": float("nan")}
    if any(math.isnan(v) for v in (c_home, c_swap, se)) or not (c_home - 0.5 >= min_z * se):
        return out
    den = hs[ok] - 0.5
    bad = float(np.mean(den <= 0)) if len(den) else float("nan")
    out.update(ratio=(c_swap - 0.5) / (c_home - 0.5), status=RATIO_DEFINED, bad_share=bad)
    if bad > max_bad_share:
        out.update(lo=float("-inf"), hi=float("inf"), status=RATIO_UNBOUNDED)
        return out
    with np.errstate(divide="ignore", invalid="ignore"):
        r = (ss[ok] - 0.5) / den
    tail = (1.0 - ci) / 2.0 * 100.0
    lo, hi = np.nanpercentile(r, [tail, 100.0 - tail])
    out.update(lo=float(lo), hi=float(hi))
    return out


def noninferiority_stat(c_home: float, c_swap: float, fraction: float = 0.25) -> float:
    """N = (1 - fraction) (C_home - 0.5) - (C_swap - 0.5) (Part 3, PC1; Part 4.3).
    N < 0 is the same as R > 1 - fraction."""
    return (1.0 - fraction) * (c_home - 0.5) - (c_swap - 0.5)


# ---------------------------------------------------------------------------
# The self-swap noise-floor rule (Part 4.4)
# ---------------------------------------------------------------------------


def noise_floor_rule(drop: float, drop_samples, self_drop_samples, alpha: float = 0.05,
                     ci: float = 0.95) -> dict:
    """A drop counts only if the drop test rejects AND the point estimate of D exceeds
    U_self, the upper end of the 95 % bootstrap interval of the matching self-swap drop
    (Part 4.4). The drop test is one-sided: p_upper(D) <= alpha (unadjusted here; the
    confirmatory tests use the Holm threshold instead of alpha).
    Returns {"p_drop", "u_self", "self_drop_lo", "drop_rejects", "beyond_floor", "counts"}."""
    p = p_upper(drop_samples)
    sd = _finite(self_drop_samples)
    tail = (1.0 - ci) / 2.0 * 100.0
    if len(sd):
        lo, hi = (float(x) for x in np.percentile(sd, [tail, 100.0 - tail]))
    else:
        lo = hi = float("nan")
    rejects = bool(p <= alpha)
    beyond = bool(not math.isnan(hi) and not math.isnan(drop) and drop > hi)
    return {"p_drop": p, "u_self": hi, "self_drop_lo": lo, "drop_rejects": rejects,
            "beyond_floor": beyond, "counts": bool(rejects and beyond)}


# ---------------------------------------------------------------------------
# Top-1 and top-2 agreement as pre-registered (Part 2.9)
# ---------------------------------------------------------------------------


class TopAgreement(NamedTuple):
    value: float      # share of judged tasks where the owner's top k contain a best candidate
    chance: float     # mean over the same tasks of the per-task chance value
    n_tasks: int      # tasks with at least one informative pair


def top_agreement_per_task(scores: Mapping, outcomes: Mapping, cand_sets: Mapping, relevance: Mapping,
                           k: int = 1) -> Dict[Hashable, Tuple[float, float]]:
    """{task: (hit 0/1, chance value)} on the tasks with at least one informative pair
    (Part 2.9): Best(tau) = the candidates with the highest outcome (ties within 1e-12
    all count); candidates ranked by the owner's score x alone, ties to the higher
    relevance, then to the candidate listed first; a hit = the owner's top k contain a
    member of Best(tau). Chance per task: |Best| / |K| for k = 1 and
    1 - C(|K| - |Best|, 2) / C(|K|, 2) for k = 2 (in general 1 - C(|K| - |Best|, k) / C(|K|, k)).
    scores: {item: x} or {task: {item: x}}; outcomes {task: {item: rate}};
    relevance {task: {item: relevance}}."""
    k = int(k)
    if k < 1:
        raise ValueError("k must be at least 1")
    out: Dict[Hashable, Tuple[float, float]] = {}
    for task, items, s, o in _task_rows(scores, outcomes, cand_sets):
        n = len(items)
        if n < 2:
            continue
        top_o = max(o)
        best = [x >= top_o - SCORE_TIE_TOL for x in o]
        nb = sum(best)
        if nb == n:
            continue                      # every candidate tied: no informative pair
        rel = [float(relevance[task][i]) for i in items]
        order = sorted(range(n), key=lambda j: (-s[j], -rel[j], j))[: min(k, n)]
        hit = 1.0 if any(best[j] for j in order) else 0.0
        kk = min(k, n)
        chance = 1.0 - math.comb(n - nb, kk) / math.comb(n, kk)
        out[task] = (hit, chance)
    return out


def top_agreement(scores: Mapping, outcomes: Mapping, cand_sets: Mapping, relevance: Mapping,
                  k: int = 1) -> TopAgreement:
    """A1 (k = 1) or A2 (k = 2) of Part 2.9 with its chance value; see
    `top_agreement_per_task`."""
    per = top_agreement_per_task(scores, outcomes, cand_sets, relevance, k)
    if not per:
        return TopAgreement(float("nan"), float("nan"), 0)
    hits = [h for h, _ in per.values()]
    ch = [c for _, c in per.values()]
    return TopAgreement(float(np.mean(hits)), float(np.mean(ch)), len(per))


# ---------------------------------------------------------------------------
# Cohen's kappa from pooled counts (Part 2.11)
# ---------------------------------------------------------------------------


def kappa_from_counts(same: float, total: float, succ_a: float, n_a: float, succ_b: float, n_b: float) -> float:
    """Cohen's kappa from counts that add over stream orders: p_obs = same / total
    (every repeat of A against every repeat of B on the same cell); p_exp = p_a p_b +
    (1 - p_a)(1 - p_b) with p_a = succ_a / n_a and p_b = succ_b / n_b."""
    if not total or not n_a or not n_b:
        return float("nan")
    pa, pb = succ_a / n_a, succ_b / n_b
    pe = pa * pb + (1 - pa) * (1 - pb)
    return (same / total - pe) / (1 - pe) if pe < 1 else float("nan")


# ---------------------------------------------------------------------------
# The headline after the round-1 revision (23 Nov 2026): the noise-free retained share theta
# ---------------------------------------------------------------------------
#
# Everyday picture: the old helper's scores point at some tips. "Signed validity" V adds up,
# over every pair of tips on a job, how much better the higher-scored tip did (minus how much
# worse, when the order was wrong). Measured with the old helper's own results it is V_home;
# with the new helper's results it is V_swap. theta = V_swap / V_home is the share of the old
# order's usefulness that still holds for the new helper. Outcome noise does not move it
# (V is linear in the results), unlike the concordance ratio R, whose weights W are noise.
#
# This block is THE implementation of theta (pre-registration Part 2.4 as revised); msr.theory
# (its R_V) and the analysis must agree with it to rounding (tests/test_theta_canonical.py).

THETA_MIN_Z = 4.0                    # the SECONDARY same-task rule: V_home >= 4 standard errors on the same tasks
THETA_CAL_MIN_Z = 2.0                # the HEADLINE flag: the owner's V on its CALIBRATION tasks >= 2 SEs
THETA_NI = 0.75                      # "no material drop": theta > 0.75 (a quarter of the home signal lost)
THETA_DEFINED = "defined"
THETA_UNDEFINED = "undefined: home signal too weak"
THETA_CAL_UNDEFINED = "undefined: home signal too weak on the calibration tasks"
Z95 = 1.959963984540054
#: WITHDRAWN in revision 2 (24 Nov 2026), kept at 1.0 so importers do not break. It was a fixed
#: inflation of the two-way standard error (the same as testing at 0.045 instead of 0.05), not a
#: small-sample correction (R6 W2): in the authors' worlds the null z had SD 0.98-1.02 and the factor
#: only pulled the largest of 20 noisy size estimates under 0.05, while in item-dominated worlds the
#: two-way CRVE itself is biased down. The registered variance is now robust_variance (the two-way
#: delete-one-cluster jackknife), which holds size in both sets of worlds without a factor
#: (docs/power/variance_items.md).
TWOWAY_SE_FACTOR = 1.0


def signed_validity_parts(x, ybar, present=None, tol: float = SCORE_TIE_TOL) -> Tuple[np.ndarray, np.ndarray]:
    """Per task: V = sum_{i<j} sgn(x_i - x_j) (ybar_i - ybar_j) and W = sum_{i<j} |ybar_i - ybar_j|.

    x (E, C) ranking scores; ybar (E, C) mean results of the outcome model; present (E, C) marks
    the candidates that exist (default: all). A pair counts when both candidates are present and
    have a finite score and a finite mean result. A score tie (|x_i - x_j| <= tol) has sign 0.
    Cw = 1/2 + sum V / (2 sum W) (the identity of the theory note), so V = 2 num - W of Cw."""
    x = np.asarray(x, dtype=float)
    y = np.asarray(ybar, dtype=float)
    if x.ndim == 1:
        x, y = x[None, :], y[None, :]
    pres = np.ones(x.shape, dtype=bool) if present is None else np.asarray(present, dtype=bool)
    E, C = x.shape
    V = np.zeros(E)
    W = np.zeros(E)
    for i in range(C):
        for j in range(i + 1, C):
            ok = pres[:, i] & pres[:, j] & np.isfinite(x[:, i]) & np.isfinite(x[:, j]) \
                & np.isfinite(y[:, i]) & np.isfinite(y[:, j])
            dx = np.where(ok, x[:, i] - x[:, j], 0.0)
            dy = np.where(ok, y[:, i] - y[:, j], 0.0)
            s = np.where(np.abs(dx) <= tol, 0.0, np.sign(dx))
            V += s * dy
            W += np.abs(dy)
    return V, W


def signed_validity_from_conc(num, den) -> np.ndarray:
    """V per task from the stored parts of Cw (numerator, weight): V = 2 num - W (exact)."""
    return 2.0 * np.asarray(num, dtype=float) - np.asarray(den, dtype=float)


def theta_from_sums(v_swap: float, v_home: float) -> float:
    """theta = V_swap / V_home (sums, or means with equal weights, over the same tasks). NaN when
    V_home is 0 or not finite. For a group of swaps and streams the sums are the plain sums of the
    per-cell mean V (equal weight per swap and stream, Part 2.12)."""
    try:
        a, b = float(v_swap), float(v_home)
    except (TypeError, ValueError):
        return float("nan")
    if not (math.isfinite(a) and math.isfinite(b)) or b == 0:
        return float("nan")
    return a / b


def theta_status(v_home: float, se_v_home: float, min_z: float = THETA_MIN_Z) -> str:
    """The SECONDARY, same-task status of theta: V_home > 0 and V_home >= min_z x SE(V_home) on the
    same evaluation tasks that give theta. It selects on the estimate's own noise (a draw whose V_home
    came out high by chance is admitted more often), so it is reported but no longer decides anything;
    the headline flag is theta_status_calibration (Part 2.4 as revised, 24 Nov 2026)."""
    try:
        v, s = float(v_home), float(se_v_home)
    except (TypeError, ValueError):
        return THETA_UNDEFINED
    if not (math.isfinite(v) and math.isfinite(s)) or v <= 0 or v < min_z * s:
        return THETA_UNDEFINED
    return THETA_DEFINED


def calibration_z(values, weights=None) -> float:
    """The owner's home ranking signal measured on its CALIBRATION tasks, as a z value (Part 2.4 as
    revised): no theta, test or interval uses these tasks, so a flag built on them cannot select on
    the estimate's own noise.

    values: one array of per-calibration-task signed validities V (the owner's repeats 1-2; the
    tasks of every order and stream pooled), or a list of such arrays, one per owner of a group of
    swaps, with weights = how many of the group's swaps each owner has (default 1).
    One array: z = sum V / (sd(V) sqrt(n)); NaN with fewer than 3 tasks or no spread. A list:
    z = sum_k w_k sum V_k / sqrt(sum_k w_k^2 n_k sd_k^2) (owners independent)."""
    if values is None:
        return float("nan")
    if isinstance(values, np.ndarray) or (len(values) and np.ndim(values[0]) == 0):
        values, weights = [values], [1.0]
    weights = [1.0] * len(values) if weights is None else list(weights)
    num = var = 0.0
    for v, w in zip(values, weights):
        v = np.asarray(v, dtype=float)
        v = v[np.isfinite(v)]
        if v.size < 3:
            return float("nan")
        sd = float(v.std(ddof=1))
        if sd == 0:
            return float("nan")
        num += w * float(v.sum())
        var += w * w * v.size * sd * sd
    return num / math.sqrt(var) if var > 0 else float("nan")


def theta_status_calibration(z: float, min_z: float = THETA_CAL_MIN_Z) -> str:
    """The HEADLINE reporting flag of theta (Part 2.4 as revised, 24 Nov 2026): 'defined' when the
    owner's home signal on its calibration tasks is at least min_z (2) standard errors above 0
    (calibration_z). It only labels the result: theta, its Fieller set and both tests are always
    computed and written, whatever the flag says."""
    try:
        zz = float(z)
    except (TypeError, ValueError):
        return THETA_CAL_UNDEFINED
    return THETA_DEFINED if math.isfinite(zz) and zz >= min_z else THETA_CAL_UNDEFINED


def theta_cell(x, y_home, y_swap, present=None) -> dict:
    """theta of one cell from raw arrays: x (E, C); y_home, y_swap (E, C, R) or (E, C) with NaN for a
    missing repeat. Tasks count only where both outcome arrays have a value for the pair (the
    missing-cell rule drops whole tasks before this; here a pair needs both)."""
    yh = np.asarray(y_home, dtype=float)
    ys = np.asarray(y_swap, dtype=float)
    with np.errstate(invalid="ignore"):
        import warnings as _w
        with _w.catch_warnings():
            _w.simplefilter("ignore", RuntimeWarning)
            bh = np.nanmean(yh, axis=-1) if yh.ndim == 3 else yh
            bs = np.nanmean(ys, axis=-1) if ys.ndim == 3 else ys
    vh, wh = signed_validity_parts(x, bh, present)
    vs, ws = signed_validity_parts(x, bs, present)
    return {"V_home": float(vh.sum()), "V_swap": float(vs.sum()), "W_home": float(wh.sum()),
            "W_swap": float(ws.sum()), "theta": theta_from_sums(vs.sum(), vh.sum()),
            "R": theta_from_sums(vs.sum(), vh.sum()) * (wh.sum() / ws.sum()) if ws.sum() > 0 else float("nan")}


# ---------------------------------------------------------------------------
# Two-way (task x item) cluster-robust variance (pre-registration Part 4.1 as revised)
# ---------------------------------------------------------------------------
#
# Everyday picture: two jobs are "related" if they are the same job (a job can appear in more
# than one stream order) or if they share a tip (the same tip is a candidate on several jobs).
# The variance of an average adds the products of the deviations of every related pair of
# observations. Counting pairs related by job, plus pairs related by tip, counts the pairs related
# both ways twice; they are taken off once (Cameron, Gelbach and Miller 2011). An observation is
# one (bank, task): a task's value depends on all of its candidate tips, so two observations are
# related through tips when their candidate sets overlap (multiple membership; the dyadic case of
# Aronow, Samii and Assenova 2015 is the two-tip version).


def _codes(values) -> np.ndarray:
    arr = np.asarray(values)
    if arr.dtype.kind in "iu":
        return arr.astype(np.int64)
    _, inv = np.unique(arr.astype(str), return_inverse=True)
    return inv.reshape(arr.shape).astype(np.int64)


def _aggregate(psi: np.ndarray, task: np.ndarray, items: Optional[np.ndarray]):
    """Sum influence values of observations with the same task and the same item set."""
    if items is None:
        key = task[:, None]
    else:
        key = np.concatenate([task[:, None], np.sort(items, axis=1)], axis=1)
    uk, inv = np.unique(key, axis=0, return_inverse=True)
    inv = inv.ravel()
    agg = np.bincount(inv, weights=psi, minlength=len(uk))
    return agg, uk[:, 0], (uk[:, 1:] if items is not None else None)


def _twoway_forms(P: np.ndarray, task, items=None) -> dict:
    """Bilinear forms of the two-way variance for every pair of columns of P (n, q): returns the
    (q, q) matrices task, item, both and twoway = task + item - both."""
    from scipy import sparse
    P = np.atleast_2d(np.asarray(P, dtype=float))
    if P.shape[0] == 1 and P.shape[1] != 1 and np.ndim(task) and len(np.atleast_1d(task)) == P.shape[1]:
        P = P.T
    n, q = P.shape
    t = _codes(task).ravel()
    it = None
    if items is not None:
        raw = np.asarray(items).reshape(n, -1)
        none = (raw.astype(str) == "") if raw.dtype.kind in "USO" else (raw < 0)
        it = np.where(none, -1, _codes(raw.astype(str) if raw.dtype.kind == "O" else raw))
    ok = np.isfinite(P).all(axis=1)
    P, t = P[ok], t[ok]
    it = it[ok] if it is not None else None
    if not len(P):
        nanm = np.full((q, q), np.nan)
        return {"task": nanm, "item": nanm, "both": nanm, "twoway": nanm}
    # aggregate observations that share task and candidate set (one row per (bank, task))
    rows = []
    for c in range(q):
        a, tt, ii = _aggregate(P[:, c], t, it)
        rows.append(a)
    A = np.column_stack(rows)
    nt = int(tt.max()) + 1
    Tsum = np.zeros((nt, q))
    np.add.at(Tsum, tt, A)
    F_task = Tsum.T @ Tsum
    if ii is None:
        z = np.zeros((q, q))
        return {"task": F_task, "item": z, "both": z, "twoway": F_task.copy()}
    m = len(A)
    valid = ii >= 0
    r = np.repeat(np.arange(m), ii.shape[1])[valid.ravel()]
    cidx = ii.ravel()[valid.ravel()]
    if not len(cidx):
        z = np.zeros((q, q))
        return {"task": F_task, "item": z, "both": z, "twoway": F_task.copy()}
    n_items = int(cidx.max()) + 1
    Inc = sparse.csr_matrix((np.ones(len(r)), (r, cidx)), shape=(m, n_items))
    S = (Inc @ Inc.T).tocoo()
    S.data[:] = 1.0                                      # related through at least one shared item
    Ssp = S.tocsr()
    F_item = A.T @ (Ssp @ A)
    same = tt[S.row] == tt[S.col]
    F_both = (A[S.row[same]].T @ A[S.col[same]]) if same.any() else np.zeros((q, q))
    return {"task": F_task, "item": F_item, "both": F_both, "twoway": F_task + F_item - F_both}


def cluster_variance(psi, task, items=None) -> dict:
    """Variance of sum(psi) for observations that are dependent when they share a task or share an
    item: V = V_task + V_item - V_both (Cameron, Gelbach and Miller 2011), items as multiple
    membership (an observation depends on every item in its row of `items`).

    psi (n,): influence values (each statistic's own centring is done by the caller); task (n,):
    the task cluster of each observation (a task id within a stream, pooled over the stream
    orders); items (n, C): the items each observation depends on (codes per bank; -1 or '' =
    none), or None for task clustering only.
    Returns V_task, V_item, V_both, V_twoway = V_task + V_item - V_both (all raw), and V = the larger
    of V_twoway, V_task and V_item (never below either one-way variance: the non-negativity fix)
    times TWOWAY_SE_FACTOR ** 2, the registered small-sample factor: V is the variance every test
    and interval uses."""
    f = _twoway_forms(np.asarray(psi, dtype=float).reshape(-1, 1), task, items)
    vt, vi, vb, v2 = (float(f[k][0, 0]) for k in ("task", "item", "both", "twoway"))
    c2 = TWOWAY_SE_FACTOR ** 2
    if items is None:
        return {"V_task": vt, "V_item": float("nan"), "V_both": float("nan"), "V_twoway": vt, "V": vt * c2}
    return {"V_task": vt, "V_item": vi, "V_both": vb, "V_twoway": v2, "V": max(v2, vt, vi) * c2}


def cluster_cov(psi_a, psi_b, task, items=None) -> np.ndarray:
    """The 2 x 2 two-way covariance matrix of (sum psi_a, sum psi_b) (the bilinear form behind
    cluster_variance, without the non-negativity fix)."""
    f = _twoway_forms(np.column_stack([np.asarray(psi_a, float), np.asarray(psi_b, float)]), task, items)
    return f["twoway"] if items is not None else f["task"]


def normal_p(est: float, se: float) -> dict:
    """One- and two-sided normal p-values of est / se: p_upper (evidence est > 0), p_lower
    (evidence est < 0) and two-sided."""
    nan = float("nan")
    try:
        e, s = float(est), float(se)
    except (TypeError, ValueError):
        return {"p_upper": nan, "p_lower": nan, "p_two": nan}
    if not (math.isfinite(e) and math.isfinite(s)) or s <= 0:
        return {"p_upper": nan, "p_lower": nan, "p_two": nan}
    z = e / s
    pu = 0.5 * math.erfc(z / math.sqrt(2.0))
    pl = 0.5 * math.erfc(-z / math.sqrt(2.0))
    return {"p_upper": pu, "p_lower": pl, "p_two": min(1.0, 2.0 * min(pu, pl))}


def fieller_interval(a: float, b: float, cov: np.ndarray, level: float = 0.95) -> Tuple[float, float, str]:
    """Fieller interval for the ratio a / b with the covariance matrix cov of (a, b) (Fieller
    1954): every theta0 with |a - theta0 b| <= z se(a - theta0 b). Returns (lo, hi, status):
    status 'bounded', 'unbounded' (b not clearly away from 0) or 'empty'."""
    from statistics import NormalDist
    z = NormalDist().inv_cdf(0.5 + level / 2.0)
    vaa, vab, vbb = float(cov[0, 0]), float(cov[0, 1]), float(cov[1, 1])
    if not all(math.isfinite(v) for v in (a, b, vaa, vab, vbb)):
        return float("nan"), float("nan"), "not computable"
    A2 = b * b - z * z * vbb
    A1 = a * b - z * z * vab
    A0 = a * a - z * z * vaa
    if A2 <= 0:
        return float("-inf"), float("inf"), "unbounded"
    disc = A1 * A1 - A2 * A0
    if disc < 0:
        return float("nan"), float("nan"), "empty"
    r = math.sqrt(disc)
    return (A1 - r) / A2, (A1 + r) / A2, "bounded"


def theta_inference(v_swap: float, v_home: float, psi_swap, psi_home, task, items=None,
                    margin: float = THETA_NI, min_z: float = THETA_MIN_Z, level: float = 0.95) -> dict:
    """Point, Fieller interval and the two pre-registered one-sided tests of theta for one swap
    or a group of swaps (Part 3, PC1 as revised), from the totals and their influence values.

    v_swap, v_home: the statistic's numerator and denominator (sums or equal-weight means of V);
    psi_swap, psi_home: per-observation influence values of those two totals (centred);
    task, items: the clusters (see cluster_variance; items=None gives task clustering only).
    - drop test: H0 theta >= 1 against H1 theta < 1, as the linear statistic V_home - V_swap > 0;
    - no-material-drop test: H1 V_swap - margin V_home > 0 (theta > margin when V_home > 0).
    Both are normal tests of LINEAR contrasts with the two-way variance (with its non-negativity
    fix and the registered small-sample factor), so no ratio is ever divided by a noisy denominator
    inside a test, and neither test takes a definedness gate (Part 2.4 as revised): p_drop and p_ni
    are always computed. `status` is the secondary same-task rule; the headline flag is
    theta_status_calibration, computed by the caller from the calibration tasks."""
    ps = np.asarray(psi_swap, dtype=float)
    ph = np.asarray(psi_home, dtype=float)
    out = {"theta": theta_from_sums(v_swap, v_home), "V_swap": float(v_swap), "V_home": float(v_home)}
    vh = cluster_variance(ph, task, items)
    se_h = math.sqrt(vh["V"]) if vh["V"] > 0 else float("nan")
    out["se_V_home"] = se_h
    out["status"] = theta_status(v_home, se_h, min_z)
    drop = cluster_variance(ph - ps, task, items)
    se_d = math.sqrt(drop["V"]) if drop["V"] > 0 else float("nan")
    out["drop_V"] = float(v_home) - float(v_swap)
    out["drop_se"] = se_d
    out["p_drop"] = normal_p(out["drop_V"], se_d)["p_upper"]
    ni = cluster_variance(ps - margin * ph, task, items)
    se_n = math.sqrt(ni["V"]) if ni["V"] > 0 else float("nan")
    out["ni_V"] = float(v_swap) - margin * float(v_home)
    out["ni_se"] = se_n
    out["p_ni"] = normal_p(out["ni_V"], se_n)["p_upper"]        # no definedness gate (ruling of 24 Nov 2026)
    # Fieller interval that inverts the SAME variance the tests use (with the non-negativity fix):
    # se(theta0)^2 = max of the task, item and two-way forms of var(V_swap - theta0 V_home), so the
    # acceptance set is the union of the three Fieller sets (each contains theta-hat).
    F = _twoway_forms(np.column_stack([ps, ph]), task, items)
    forms = [F["task"]] if items is None else [F["twoway"], F["task"], F["item"]]
    c2 = TWOWAY_SE_FACTOR ** 2                   # the same small-sample factor as the tests
    ivs = [fieller_interval(float(v_swap), float(v_home), Q * c2, level) for Q in forms]
    if any(iv[2] == "unbounded" for iv in ivs):
        lo, hi, st = float("-inf"), float("inf"), "unbounded"
    elif all(iv[2] == "bounded" for iv in ivs):
        lo, hi, st = min(iv[0] for iv in ivs), max(iv[1] for iv in ivs), "bounded"
    else:
        lo, hi, st = float("nan"), float("nan"), "not computable"
    out.update(lo=lo, hi=hi, interval=st)
    th = out["theta"]
    vt = cluster_variance((ps - th * ph) / float(v_home), task, items)["V"] if v_home and math.isfinite(th) else float("nan")
    out["se"] = math.sqrt(vt) if math.isfinite(vt) and vt > 0 else float("nan")
    return out


# ---------------------------------------------------------------------------
# Task-id cluster bootstrap (the secondary, task-only interval; Part 4.1 as revised)
# ---------------------------------------------------------------------------


def task_cluster_seed(seed: int, stream: str) -> list:
    """The generator seed of one stream's task-id resampling: [evaluate.seed, hash of "taskboot|stream"]."""
    import hashlib
    h = int.from_bytes(hashlib.sha256(f"taskboot|{stream}".encode()).digest()[:8], "big")
    return [int(seed), h]


def task_cluster_counts(task_ids: Mapping, n_draws: int, seed: int) -> Dict[Hashable, np.ndarray]:
    """Count matrices of the task-id cluster bootstrap: per stream, the distinct task ids of all its
    orders are resampled with replacement (one draw carries every appearance of a task, in every
    order), so a task that sits in two orders' evaluation sets is one cluster.

    task_ids: {(stream, order): [task id, ...]} (the order of each list is kept).
    Returns {(stream, order): (n_draws, n_tasks) float64 counts}: counts[s][b, j] = how often the
    task id of position j was drawn in draw b."""
    by_stream: Dict[str, list] = {}
    for key in sorted(task_ids, key=lambda k: (str(k[0]), str(k[1]))):
        u = by_stream.setdefault(str(key[0]), [])
        seen = set(u)
        for t in task_ids[key]:
            t = str(t)
            if t not in seen:
                seen.add(t)
                u.append(t)
    out = {}
    for stream, ids in by_stream.items():
        pos = {t: j for j, t in enumerate(ids)}
        cnt = bootstrap_counts(len(ids), n_draws, task_cluster_seed(seed, stream)).astype(np.float64)
        for key, lst in task_ids.items():
            if str(key[0]) != stream:
                continue
            idx = np.array([pos[str(t)] for t in lst], dtype=np.int64)
            out[key] = cnt[:, idx] if len(idx) else np.zeros((n_draws, 0))
    return out


def task_overlap(task_ids: Mapping) -> Dict[str, dict]:
    """Per stream: evaluation-task appearances, distinct task ids, and the share of appearances
    whose task also sits in another order of the same stream (reported with the intervals)."""
    out: Dict[str, dict] = {}
    by: Dict[str, Dict[str, int]] = {}
    for key, lst in task_ids.items():
        d = by.setdefault(str(key[0]), {})
        for t in set(map(str, lst)):
            d[t] = d.get(t, 0) + 1
    for stream, d in by.items():
        app = sum(d.values())
        out[stream] = {"appearances": app, "distinct": len(d),
                       "share_in_more_than_one_order": (sum(v for v in d.values() if v > 1) / app) if app else float("nan")}
    return out


# ---------------------------------------------------------------------------
# The level correction of predicted probabilities (Part 2.8 as revised: PC3, PC4)
# ---------------------------------------------------------------------------


def logit(p) -> np.ndarray:
    p = np.asarray(p, dtype=float)
    with np.errstate(divide="ignore", invalid="ignore"):
        return np.log(p) - np.log1p(-p)


def level_shift(p_cal, target, clip: Tuple[float, float] = PROB_CLIP, iters: int = 80) -> np.ndarray:
    """The single logit shift delta that makes the mean of sigmoid(logit p + delta) over the
    calibration cells equal the target (the reader's no-memory success rate on the calibration
    tasks): the level correction every arm gets without any item check.

    p_cal (..., m): the arm's predicted probabilities on the candidate cells of the calibration
    tasks (clipped to `clip` first); target: scalar or (...,), clipped to `clip`. Bisection on
    [-30, 30] (the mean is increasing in delta). Returns delta (...)."""
    p = np.clip(np.asarray(p_cal, dtype=float), clip[0], clip[1])
    tgt = np.clip(np.asarray(target, dtype=float), clip[0], clip[1])
    L = logit(p)
    lo = np.full(L.shape[:-1], -30.0)
    hi = np.full(L.shape[:-1], 30.0)
    for _ in range(iters):
        mid = 0.5 * (lo + hi)
        m = np.mean(np.clip(1.0 / (1.0 + np.exp(-(L + mid[..., None]))), clip[0], clip[1]), axis=-1)
        up = m < tgt
        lo = np.where(up, mid, lo)
        hi = np.where(up, hi, mid)
    return 0.5 * (lo + hi)


def shift_probs(p, delta, clip: Tuple[float, float] = PROB_CLIP) -> np.ndarray:
    """sigmoid(logit p + delta), with p clipped before and the result clipped after. delta
    broadcasts against the leading axes of p (p (..., n), delta (...))."""
    pc = np.clip(np.asarray(p, dtype=float), clip[0], clip[1])
    d = np.asarray(delta, dtype=float)
    if d.ndim:
        d = d[..., None]
    out = 1.0 / (1.0 + np.exp(-(logit(pc) + d)))
    return np.clip(out, clip[0], clip[1])


# ---------------------------------------------------------------------------
# Revision 2 (24 Nov 2026): the registered variance, the three numbers of the measure, and the tests
# ---------------------------------------------------------------------------
#
# Everyday picture: (1) the error bars must stay honest even when a handful of popular tips carry most
# of the variation, so each tip (and each job) is left out in turn and the answer recomputed (the
# jackknife); (2) what the operator keeps (value, theta) splits exactly into whether the old order
# still fits the new helper (order) and how much the new helper cares which tip it gets (stakes);
# (3) no claim is made unless the old helper's own ranking signal is shown to be positive first.

def _rv_codes(x) -> np.ndarray:
    """0..k-1 codes of any 1-d or 2-d array; '' (strings) or negative numbers become -1."""
    a = np.asarray(x)
    if a.dtype.kind in "USO":
        s = a.astype(str)
        none = s == ""
        _, inv = np.unique(s, return_inverse=True)
    else:
        none = a < 0
        _, inv = np.unique(a, return_inverse=True)
    inv = inv.reshape(a.shape).astype(np.int64)
    if none.any():
        inv = np.where(none, -1, inv)
        ok = inv >= 0
        _, inv2 = np.unique(inv[ok], return_inverse=True)
        inv[ok] = inv2
    return inv


def _rv_jackknife(row: np.ndarray, cl: np.ndarray, P: np.ndarray, comp: np.ndarray, n_c: np.ndarray):
    """Delete-one-cluster jackknife of L = sum_c mean_c(v), for clusters given as (row, cluster)
    membership pairs (a row may belong to several clusters of the dimension; each pair once).
    Deleting cluster g changes the mean of component c by -n_c / (n_c - k_gc) x (sum of psi over the
    k_gc rows of g in c), with psi = (v - mean_c) / n_c. Returns (J (q, q), deviations (G, q), G)."""
    q = P.shape[1]
    if not len(row):
        return np.zeros((q, q)), np.zeros((0, q)), 0
    nC = int(comp.max()) + 1
    key = cl.astype(np.int64) * nC + comp[row]
    u, inv = np.unique(key, return_inverse=True)
    k = np.bincount(inv, minlength=len(u)).astype(float)
    cc = u % nC
    fac = n_c[cc] / np.maximum(n_c[cc] - k, 1.0)          # a cluster that fills a whole component: capped
    _, g = np.unique(u // nC, return_inverse=True)
    G = int(g.max()) + 1
    D = np.empty((G, q))
    for j in range(q):
        s = np.bincount(inv, weights=P[row, j], minlength=len(u))
        D[:, j] = -np.bincount(g, weights=fac * s, minlength=G)
    D -= D.mean(axis=0)
    J = (G - 1) / G * (D.T @ D) if G > 1 else np.zeros((q, q))
    return J, D, G


def robust_variance(psi, task, items=None, comp=None, row_n=None) -> dict:
    """Variance of the linear statistic L = sum_c coef_c x mean_c(v) whose influence values are psi,
    by the two-way delete-one-cluster jackknife: V = J_task + J_item - J_both (CV3 in each dimension,
    MacKinnon, Nielsen and Webb 2023; two-way inclusion-exclusion as Cameron, Gelbach and Miller 2011),
    items as multiple membership (deleting item i deletes every row that lists i).

    psi (n,) or (n, q): influence values, psi = coef_c (v - mean_c) / n_c, centred per component.
    task (n,): task cluster (task id within its stream, pooled over the orders).
    items (n, C) or None: the candidate items each row depends on, coded by item IDENTITY within
        (owner, stream) and NOT by order, so an item that recurs across orders is one cluster
        ('' or -1 = none). None = task clustering only.
    comp (n,): component id of each row (one component = one (key, cell, stream) mean pooled over
        orders; the swap part and the home part of theta are different components). Needed for the
        leverage term n_c / (n_c - k); None = every row its own component's (factor 1).
    row_n (n,) or None: rows in the row's component (n_c); None = the number of rows passed with that
        component id.

    Returns V (float, or (q, q) matrix), V_task, V_item, V_both, item_share = 1 - V_task / V,
    eff_items = min(G_items, 3 (sum_i D_i^2)^2 / sum_i D_i^4) over the item-deletion deviations D_i
    (the effective number of item clusters: the Satterthwaite degrees of freedom of the item part,
    about G_items when the items carry the variance evenly, a handful when a few items carry it;
    the role of Carter, Schnepel and Steigerwald's G*), eff_tasks (the same for tasks), df_satt =
    V^2 / (V_task^2 / eff_tasks + (V - V_task)^2 / eff_items) (a diagnostic: below 100 the normal
    reference is outside the tested range, see docs/power/variance_items.md), G_task, G_items and
    df = None (the normal reference is used).
    The non-negativity fix keeps V >= V_task: for one column V = max(J_task + J_item - J_both, J_task);
    for several columns V = J_task + the non-negative part of (J_item - J_both) (positive
    semi-definite) and V_raw = J_task + J_item - J_both; contrast_variance(res, c) gives the
    one-column number for any combination c."""
    P = np.asarray(psi, dtype=float)
    one = P.ndim == 1
    P = P.reshape(len(P), -1)
    n, q = P.shape
    ok = np.isfinite(P).all(axis=1)
    t = _rv_codes(np.asarray(task).ravel())
    cp = np.arange(n, dtype=np.int64) if comp is None else _rv_codes(np.asarray(comp).ravel())
    if row_n is None:
        n_c = np.bincount(cp[ok], minlength=int(cp.max()) + 1).astype(float)
    else:
        rn = np.asarray(row_n, dtype=float).ravel()
        n_c = np.zeros(int(cp.max()) + 1)
        n_c[cp] = rn
    P, t, cp = P[ok], t[ok], cp[ok]
    rows = np.arange(len(P))
    Jt, Dt, Gt = _rv_jackknife(rows, t, P, cp, n_c)
    Ji = Jb = np.zeros((q, q))
    Di = np.zeros((0, q))
    Db = np.zeros((0, q))
    Gi = Gb = 0
    if items is not None:
        it = _rv_codes(np.asarray(items).reshape(n, -1))[ok]
        r = np.repeat(rows, it.shape[1])
        c = it.ravel()
        keep = c >= 0
        r, c = r[keep], c[keep]
        if len(c):
            nI = int(c.max()) + 1
            pair = np.unique(r.astype(np.int64) * nI + c)          # each (row, item) once
            r, c = pair // nI, pair % nI
            Ji, Di, Gi = _rv_jackknife(r, c, P, cp, n_c)
            Jb, Db, Gb = _rv_jackknife(r, t[r].astype(np.int64) * nI + c, P, cp, n_c)
    V_raw = Jt + Ji - Jb
    M2 = (Ji - Jb + (Ji - Jb).T) / 2
    w, U = np.linalg.eigh(M2)
    V = V_raw if w.min() >= 0 else Jt + (U * np.clip(w, 0.0, None)) @ U.T
    dV = np.diag(V)
    share = np.where(dV > 0, 1.0 - np.diag(Jt) / np.where(dV > 0, dV, 1.0), np.nan)
    d2, d4 = (Di ** 2).sum(axis=0), (Di ** 4).sum(axis=0)
    # Satterthwaite degrees of freedom of the item part, plug-in under normal deviations
    # (E D^4 = 3 sigma^4): 3 (sum D^2)^2 / sum D^4, at most the number of items
    eff = np.where(d4 > 0, np.minimum(3.0 * d2 ** 2 / np.where(d4 > 0, d4, 1.0), Gi), np.nan)
    t2, t4 = (Dt ** 2).sum(axis=0), (Dt ** 4).sum(axis=0)
    eff_t = np.where(t4 > 0, np.minimum(3.0 * t2 ** 2 / np.where(t4 > 0, t4, 1.0), Gt), np.nan)
    vt_, vi_ = np.diag(Jt), np.clip(dV - np.diag(Jt), 0.0, None)
    with np.errstate(divide="ignore", invalid="ignore"):
        den = vt_ ** 2 / eff_t + np.where(vi_ > 0, vi_ ** 2 / np.where(np.isfinite(eff), eff, np.inf), 0.0)
        df_satt = np.where(den > 0, dV ** 2 / den, np.nan)
    if one:
        return {"V": float(V[0, 0]), "V_raw": float(V_raw[0, 0]), "V_task": float(Jt[0, 0]),
                "V_item": float(Ji[0, 0]), "V_both": float(Jb[0, 0]), "item_share": float(share[0]),
                "eff_items": float(eff[0]), "eff_tasks": float(eff_t[0]), "df_satt": float(df_satt[0]),
                "G_task": Gt, "G_items": Gi, "df": None}
    return {"V": V, "V_raw": V_raw, "V_task": Jt, "V_item": Ji, "V_both": Jb, "item_share": share,
            "eff_items": eff, "eff_tasks": eff_t, "df_satt": df_satt, "G_task": Gt, "G_items": Gi, "df": None,
            # the centred deletion deviations of each dimension: any combination c of the columns has the
            # deviations D @ c, so contrast_stats(res, c) gives its variance and diagnostics without a re-run
            "D_task": Dt, "D_item": Di, "D_both": Db, "G_both": Gb}


def contrast_stats(res: dict, c) -> dict:
    """Everything robust_variance(psi @ c, ...) returns for one combination c of the columns of a matrix
    result (V, V_task, V_item, V_both, item_share, eff_items, eff_tasks, df_satt), from the stored deletion
    deviations, so a family of contrasts costs one jackknife (the deviations are linear in psi). Identical
    to the one-column call up to rounding."""
    c = np.asarray(c, dtype=float)

    def J(D, G):
        if G <= 1 or not len(D):
            return 0.0, np.zeros(0)
        d = D @ c
        return (G - 1) / G * float(d @ d), d

    vt, dt = J(res["D_task"], res["G_task"])
    vi, di = J(res["D_item"], res["G_items"])
    vb, _ = J(res["D_both"], res["G_both"])
    V = max(vt + vi - vb, vt)
    nan = float("nan")
    share = 1.0 - vt / V if V > 0 else nan

    def eff(d, G):
        d4 = float((d ** 4).sum()) if len(d) else 0.0
        return min(3.0 * float((d ** 2).sum()) ** 2 / d4, G) if d4 > 0 else nan

    ei, et = eff(di, res["G_items"]), eff(dt, res["G_task"])
    vi_ = max(V - vt, 0.0)
    den = (vt ** 2 / et if math.isfinite(et) and et > 0 else (0.0 if vt == 0 else float("inf"))) \
        + (vi_ ** 2 / (ei if math.isfinite(ei) else float("inf")) if vi_ > 0 else 0.0)
    df = V ** 2 / den if den > 0 and math.isfinite(den) else nan
    return {"V": V, "V_task": vt, "V_item": vi, "V_both": vb, "item_share": share, "eff_items": ei,
            "eff_tasks": et, "df_satt": df}


def contrast_variance(res: dict, c) -> float:
    """Variance of c' L from a matrix result of robust_variance: max(c' V_raw c, c' V_task c), the
    same number robust_variance gives for the single column psi @ c (the matrix V is the
    conservative positive semi-definite version, for intervals that need a whole matrix)."""
    c = np.asarray(c, dtype=float)
    return float(max(c @ res["V_raw"] @ c, c @ res["V_task"] @ c))


ORDER_MIN_Z = 2.0          # order identifiable when the reader's spread z (calibration tasks) >= 2
ORDER_DEFINED = "defined"
ORDER_UNIDENTIFIED = "not identifiable: the reader's item spread cannot be told from zero"


def cross_repeat_parts(y_a, y_b, present=None) -> np.ndarray:
    """Per task S = sum_{i<j} dy_a(i, j) * dy_b(i, j): the cross-repeat product estimate of the
    noise-free second moment sum_{i<j} (mu_i - mu_j)^2 of one model's within-task differences.

    y_a, y_b: two INDEPENDENT measurements of the same (task, candidate) cells, each (E, C) (one
    repeat) or (E, C, R) (the mean over its repeats is used): for the owner the mean of home repeats
    1-2 and the mean of the later-session repeats 3-4; for a reader repeat 1 and repeat 2. A pair
    counts when both candidates are present and finite in both measurements. Unbiased when a and b
    are independent given the success chances (a cached repeat breaks this: see docs/power/order_stakes.md)."""
    import warnings as _w

    def _m(y):
        y = np.asarray(y, dtype=float)
        if y.ndim == 3:
            with _w.catch_warnings():
                _w.simplefilter("ignore", RuntimeWarning)
                y = np.nanmean(y, axis=-1)
        return y if y.ndim == 2 else y[None, :]

    a, b = _m(y_a), _m(y_b)
    pres = np.ones(a.shape, dtype=bool) if present is None else np.asarray(present, dtype=bool)
    E, C = a.shape
    S = np.zeros(E)
    for i in range(C):
        for j in range(i + 1, C):
            ok = pres[:, i] & pres[:, j] & np.isfinite(a[:, i]) & np.isfinite(a[:, j]) \
                & np.isfinite(b[:, i]) & np.isfinite(b[:, j])
            S += np.where(ok, (a[:, i] - a[:, j]) * (b[:, i] - b[:, j]), 0.0)
    return S


def _fieller_set(a: float, b: float, vaa: float, vab: float, vbb: float, z: float = Z95):
    """The Fieller set {r : (a - r b)^2 <= z^2 (vaa - 2 r vab + r^2 vbb)}: (lo, hi, status)."""
    A2 = b * b - z * z * vbb
    A1 = a * b - z * z * vab
    A0 = a * a - z * z * vaa
    if not all(math.isfinite(v) for v in (A2, A1, A0)):
        return float("nan"), float("nan"), "not computable"
    if A2 <= 0:
        return float("-inf"), float("inf"), "unbounded"
    disc = A1 * A1 - A2 * A0
    if disc < 0:
        return float("nan"), float("nan"), "empty"
    r = math.sqrt(disc)
    return (A1 - r) / A2, (A1 + r) / A2, "bounded"


def order_stakes_inference(v_swap: float, v_home: float, s_owner: float, s_reader: float, quad,
                           z_reader_cal: float | None = None, level: float = 0.95,
                           min_z: float = ORDER_MIN_Z) -> dict:
    """Retained order and stakes for one swap or a group (decision D2; Part 2.4 as revised).

    v_swap, v_home, s_owner, s_reader: the pooled totals (sums of per-(swap, stream) means, exactly
    as theta's); quad: a callable quad(c1, c2) -> covariance of the linear combinations c1 . psi and
    c2 . psi of the influence columns psi = [V_swap, V_home, S_owner, S_reader] (the two-way variance;
    quad(c, c) is the variance the tests use). It is the ONE place the variance enters, so a new
    variance estimator is swapped there.
    z_reader_cal: the reader's spread z on the swap cell's CALIBRATION tasks (cross-repeat S over the
    calibration tasks, z = sum / (sd sqrt(n))); the identifiability flag. None: the same-task z is
    used (it selects on the estimate's own noise; reported, not recommended).
    Returns theta, stakes (+ Fieller interval of the ratio, square-rooted), order (+ Fieller interval
    with a linearised denominator), z of both spreads, the identifiability status and the identity
    check order * stakes - theta (0 to rounding)."""
    from statistics import NormalDist
    z = NormalDist().inv_cdf(0.5 + level / 2.0)
    nan = float("nan")
    e = np.eye(4)
    out = {"theta": v_swap / v_home if v_home else nan, "s_owner": float(s_owner), "s_reader": float(s_reader)}
    vso, vsr = quad(e[2], e[2]), quad(e[3], e[3])
    out["z_s_owner"] = s_owner / math.sqrt(vso) if vso > 0 else nan
    out["z_s_reader"] = s_reader / math.sqrt(vsr) if vsr > 0 else nan
    zr = out["z_s_reader"] if z_reader_cal is None else float(z_reader_cal)
    out["z_s_reader_flag"] = zr
    out["order_status"] = ORDER_DEFINED if (math.isfinite(zr) and zr >= min_z and s_reader > 0 and s_owner > 0) \
        else ORDER_UNIDENTIFIED
    # stakes: Fieller for q = S_reader / S_owner, then sqrt (point always written when both > 0)
    out["stakes"] = math.sqrt(s_reader / s_owner) if (s_owner > 0 and s_reader >= 0) else nan
    lo, hi, st = _fieller_set(s_reader, s_owner, vsr, quad(e[3], e[2]), vso, z)
    if st == "bounded":
        out["stakes_lo"], out["stakes_hi"] = math.sqrt(max(lo, 0.0)), math.sqrt(max(hi, 0.0))
    elif st == "unbounded":
        out["stakes_lo"], out["stakes_hi"] = 0.0, float("inf")
    else:
        out["stakes_lo"] = out["stakes_hi"] = nan
    out["stakes_interval"] = st
    # order = a / b, a = V_swap, b = V_home * stakes (linearised)
    if s_owner > 0 and s_reader > 0 and v_home:
        stk = out["stakes"]
        b = v_home * stk
        cb = np.array([0.0, stk, -0.5 * b / s_owner, 0.5 * b / s_reader])
        ca = e[0]
        out["order"] = v_swap / b
        lo, hi, st = _fieller_set(v_swap, b, quad(ca, ca), quad(ca, cb), quad(cb, cb), z)
        out.update(order_lo=lo, order_hi=hi, order_interval=st)
        out["identity_gap"] = out["order"] * stk - out["theta"]
    elif s_owner > 0 and v_home:
        # the reader's spread estimate is <= 0: no point, and the honest set is the whole line
        out.update(order=nan, order_lo=float("-inf"), order_hi=float("inf"), order_interval="unbounded",
                   identity_gap=nan)
    else:
        out.update(order=nan, order_lo=nan, order_hi=nan, order_interval="not computable", identity_gap=nan)
    return out



def quad_from_robust(res: dict):
    """quad(c1, c2) for order_stakes_inference / theta_tests from a matrix result of robust_variance:
    variances by contrast_variance (the registered rule), covariances from V_raw."""
    def quad(c1, c2):
        c1, c2 = np.asarray(c1, float), np.asarray(c2, float)
        if np.array_equal(c1, c2):
            return contrast_variance(res, c1)
        return float(c1 @ res["V_raw"] @ c2)
    return quad


def home_signal_flag(v_cal, weights=None) -> tuple:
    """THE one 'home signal too weak' rule of the whole code base (R6 W3; Part 2.4): z of the owner's
    signed validity on its CALIBRATION tasks (calibration_z) and its status (theta_status_calibration,
    'defined' when z >= 2). Every module that needs the flag (analysis, forecast, sequential, scorer)
    calls this function; none keeps a rule of its own. Returns (z, status)."""
    z = calibration_z(v_cal, weights)
    return z, theta_status_calibration(z)


#: Decision words of PC1, each a function of registered test outcomes only (R6 W6)
PC1_LABELS = ("material drop shown", "drop shown", "small drop shown", "no material drop shown", "inconclusive")


def pc1_label(drop: bool, material: bool, no_material: bool) -> str:
    """The PC1 reading of a group (or pair) from its three intersection-union decisions (each already
    includes the positive-home-signal test). Coherent by construction: 'material drop' (theta < 0.75)
    and 'no material drop' (theta > 0.75) are one statistic with opposite signs and cannot both reject;
    theta < 0.75 implies theta < 1, so a material drop is also a drop. Labels:
      material drop shown     the test of theta < 0.75 rejected
      small drop shown        theta < 1 and theta > 0.75 both rejected
      drop shown              only theta < 1 rejected
      no material drop shown  only theta > 0.75 rejected
      inconclusive            nothing rejected (never read as 'no drop')"""
    if material:
        return "material drop shown"
    if drop and no_material:
        return "small drop shown"
    if drop:
        return "drop shown"
    if no_material:
        return "no material drop shown"
    return "inconclusive"


def theta_tests(v_swap: float, v_home: float, psi_swap, psi_home, task, items=None, comp=None,
                margin: float = THETA_NI, level: float = 0.95, v_fresh: float | None = None,
                psi_fresh=None, s_owner: float | None = None, s_reader: float | None = None,
                psi_so=None, psi_sr=None, z_reader_cal: float | None = None) -> dict:
    """The registered PC1 tests of revision 2 for one swap or a group, with the registered variance
    (robust_variance: two-way delete-one-cluster jackknife; comp = component id per row).

    Members (each an intersection-union test, p = the largest of its parts; Berger 1982):
      home   H1 V_home > 0                         (part of every claim: a non-positive home signal
                                                    never yields 'drop' or 'no material drop')
      drop   H1 theta < 1:     home AND V_home - V_swap > 0 [AND V_fresh - V_swap > 0, the self-swap
             reference, when v_fresh / psi_fresh are given: the drop must also exceed what a second
             home session shows]
      md     H1 theta < m:     home AND m V_home - V_swap > 0      (material drop)
      ni     H1 theta > m:     home AND V_swap - m V_home > 0      (no material drop)
    The contrasts are linear, so no ratio enters a test. theta's Fieller set inverts the same
    variance (union over the raw two-way and the task-only forms, so it is never narrower than the
    tests). Diagnostics per contrast: item share of the variance, effective item clusters,
    Satterthwaite df. With s_owner/s_reader (and their psi), retained order and stakes are added
    (order_stakes_inference). Rows of psi_* are aligned (zeros where a row is not in a part)."""
    cols = [np.asarray(psi_swap, float), np.asarray(psi_home, float)]
    has_fresh = v_fresh is not None and psi_fresh is not None
    has_s = s_owner is not None and s_reader is not None and psi_so is not None and psi_sr is not None
    cols.append(np.asarray(psi_fresh, float) if has_fresh else np.zeros(len(cols[0])))
    cols.append(np.asarray(psi_so, float) if has_s else np.zeros(len(cols[0])))
    cols.append(np.asarray(psi_sr, float) if has_s else np.zeros(len(cols[0])))
    P = np.column_stack(cols)
    res = robust_variance(P, task, items, comp)
    A, B = float(v_swap), float(v_home)
    Fr = float(v_fresh) if has_fresh else float("nan")
    out = {"theta": theta_from_sums(A, B), "V_swap": A, "V_home": B, "variance": "two-way jackknife"}
    contrasts = {"home": ([0, 1, 0, 0, 0], B), "drop_c": ([-1, 1, 0, 0, 0], B - A),
                 "md_c": ([-1, margin, 0, 0, 0], margin * B - A), "ni_c": ([1, -margin, 0, 0, 0], A - margin * B)}
    if has_fresh:
        contrasts["self_c"] = ([-1, 0, 1, 0, 0], Fr - A)
    for name, (c, est) in contrasts.items():
        v = contrast_variance(res, c)
        se = math.sqrt(v) if v > 0 else float("nan")
        out[f"{name}_est"], out[f"{name}_se"] = est, se
        out[f"p_{name}"] = normal_p(est, se)["p_upper"]
        sub = contrast_stats(res, c)          # = robust_variance(P @ c, ...) without a second jackknife
        out[f"{name}_item_share"], out[f"{name}_eff_items"] = sub["item_share"], sub["eff_items"]
        out[f"{name}_df_satt"] = sub["df_satt"]
    ph = out["p_home"]
    out["p_drop"] = max(ph, out["p_drop_c"], out.get("p_self_c", 0.0))
    out["p_md"] = max(ph, out["p_md_c"])
    out["p_ni"] = max(ph, out["p_ni_c"])
    out["se_V_home"] = out["home_se"]
    # theta's Fieller set from the same variance
    vt = res["V_task"][:2, :2]
    vr = res["V_raw"][:2, :2]
    from statistics import NormalDist
    zc = NormalDist().inv_cdf(0.5 + level / 2.0)
    # The test of H0 theta = r uses the variance max(c' V_raw c, c' V_task c) of c = (1, -r), so the set of r
    # it does not reject is exactly the UNION of the raw and the task-only Fieller sets. A raw set can be
    # empty (V_raw is not always positive semi-definite); the union is then the task-only set, which always
    # holds the point estimate.
    ivs = [_fieller_set(A, B, Q[0, 0], Q[0, 1], Q[1, 1], zc) for Q in (vr, vt)]
    got = [iv for iv in ivs if iv[2] in ("bounded", "unbounded")]
    if any(iv[2] == "unbounded" for iv in got):
        lo, hi, st = float("-inf"), float("inf"), "unbounded"
    elif got:
        lo, hi, st = min(iv[0] for iv in got), max(iv[1] for iv in got), "bounded"
    else:
        lo, hi, st = float("nan"), float("nan"), "not computable"
    out.update(lo=lo, hi=hi, interval=st)
    th = out["theta"]
    if B and math.isfinite(th):
        vth = contrast_variance(res, [1.0 / B, -th / B, 0, 0, 0])
        out["se"] = math.sqrt(vth) if vth > 0 else float("nan")
    else:
        out["se"] = float("nan")
    out["status"] = theta_status(B, out["se_V_home"])          # the secondary same-task rule (reported only)
    if has_s:
        quad5 = quad_from_robust(res)
        quad = lambda c1, c2: quad5(np.r_[np.asarray(c1, float)[:2], 0.0, np.asarray(c1, float)[2:]],  # noqa: E731
                                    np.r_[np.asarray(c2, float)[:2], 0.0, np.asarray(c2, float)[2:]])
        os_ = order_stakes_inference(A, B, float(s_owner), float(s_reader), quad, z_reader_cal, level)
        for k, v in os_.items():
            if k != "theta":
                out[k] = v
    return out
