"""Stage C, EVALUATE: score every swap-day rule by look-up in the probe tables. No calls.

Everyday picture: we now have, for each probe job, the results of the new helper with each
of the 4 closest tips. Every rule ("keep the old grades", "wipe them", "trust them halfway",
"try a few fresh cases, then decide") picks one tip per job; we simply look up how that tip
did. We also ask the most direct question: when two tips really differ for the new helper,
does the tip with the higher OLD grade win? (0.5 = coin toss.)

Probe tasks are split once, by a fixed hash, into calibration tasks (used ONLY to draw fresh
checks) and evaluation tasks (every reported number). No rule is graded on its own checks.
Every definition follows prediction/PREREGISTRATION.md: Part 0.4 (families), 1.4-1.6
(exclusions, missing cells), 2.2 (weighted concordance Cw), 2.4 (retained validity and when
it is defined), 2.5 (noise references), 2.6 (the arms), 2.7 (first-shown success), 2.8 (log
and Brier scores), 2.9 (top-1/top-2 agreement), 2.11 (agreement), 4.1-4.5 (bootstrap,
p-values, noise floor, draws), 9.3 (the gate).

Speed: the arithmetic runs in msr/engine.py on numpy arrays, all random draws of an arm at
once, and the work is spread over processes by (owner, stream, order): each job reads the
owner's bank and home table once and then scores every reader. The processes are started
with "spawn", so this runs the same on Windows and Linux.

Outputs in runs/<study>/results/:
  validity.csv      Cw (weighted) and C (unweighted): home, after the swap, noise floor, noise
                    references, drop, retained ratio (per order, with its rule), top-1/top-2
                    agreement with chance values, shuffled control, per family
  retained.csv      per swap, per stream and pooled over the streams: C_home, C_swap, the drop
                    with its interval and p-value, the noise-floor rule, the retained ratio
                    with the 4-standard-error rule, the non-inferiority statistic
  arms.csv          every swap-day rule: first-shown success, regret, w sensitivity, log and
                    Brier score, the spread over draws and the fitted values
  per_task/*.npz    per-task values of everything above (msr.evaluate.load_per_task)
  draws/*.jsonl     the chosen lambda / level / slope / audit decision of every random draw
  agreement.csv     owner vs reader on the same cells (calibration tasks; Cohen's kappa, for
                    P1), with the counts that add up over stream orders
  repeatability.csv second bank vs first bank (score repeatability)
  subsets.csv, shapley.csv   realism check: items shown together, exact Shapley values
  variants.csv      validity under the second prompt wording, with the drop and the retained
                    ratio under each wording; variants_retained.csv pools them over orders
  costs.csv         calls, tokens, dollars, token-limit hits, refusals and unparseable answers
                    per model and stage, from the call log
  cells/*.npz       the raw cells of every probe table (candidates, scores, visits, selection
                    probabilities, results per repeat)
  SCHEMA.md         every file and column
  gate.json         the five pilot gate lines (Part 9.3), PASS / FAIL
  sensitivity.json  and sensitivity/<name>/: token-limit and refusal cells as missing,
                    available-case analysis, BIRD's original grading (Parts 1.4-1.6, 8.2.14)
  SUMMARY.md
"""
from __future__ import annotations

import csv
import json
import math
import os
import time
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from msr import arms as A
from msr import engine as X
from msr import llm as L
from msr import metrics as M
from msr import scores as S
from msr.build import read_jsonl, stable_int, write_json, write_jsonl
from msr.study import Study, load_study, plan_calls, total_calls, total_usd

NAN = float("nan")
#: The four families that carry a usefulness signal (visits is the no-signal baseline).
USEFUL_FAMILIES = ("ema_grade", "beta_grade", "tags_self", "credit")
#: Part 9.2: if ema_grade fails its gate-2 test, the first family that passes, in this order.
HEADLINE_ORDER = ("ema_grade", "beta_grade", "credit", "tags_self")
CHECK_ARMS = ("powerprior", "powerprior_flat", "recal", "retest", "audit", "pooled", "fresh")
NO_FAMILY = "-"            # family column for arms that ignore scores (none, relevance, split_half, ceiling)
#: The kind of a cell in every output file (round-1 revision, 23 Nov 2026): swap groups are named by
#: MAKER; "score family" is kept for the five score types only.
MAKER_KIND = {"home": "home", "same_family": "same_maker", "cross_family": "cross_maker"}
#: The per-task probability metrics: raw (Part 2.8) and level-corrected (Part 2.8 as revised: every
#: arm's p shifted on the logit scale so that its mean over the calibration tasks' candidates equals
#: the reader's no-memory success there; the same correction for every rule, no item check needed).
#: Revision 2 (R6 W7, base-rate sensitivity of PC3/PC4): "_lcw" = the same shift to the reader's mean
#: success WITH an item on the calibration (task, candidate) cells (the cells recal_k uses).
PROB_KEYS = ("log", "brier", "log_lc", "brier_lc", "log_lcw", "brier_lcw")


def maker_kind(st, owner: str, reader: str) -> str:
    """home, same_maker or cross_maker (Study.kind says same_family / cross_family)."""
    k = st.kind(owner, reader)
    return MAKER_KIND.get(k, k)
#: Kept for older callers; the study's value is evaluate.ratio_min_z (pre-registration 2.4).
RATIO_MIN_Z = 4.0
#: Stop reasons of an answer cut at the token limit, and of an API-level refusal (Part 1.4).
LIMIT_STOPS = ("max_tokens", "length")
REFUSAL_STOPS = ("refusal", "content_filter")
#: Changes whenever a rule of this stage changes, so results made under older rules are not
#: taken as up to date. 2026-11-24: z-scored mix within the task's candidates; recal's
#: standardising sd over the visited items (level only when it is 0); k that do not fit the
#: calibration pool skipped; second-wording drop and ratio in variants.csv. 2026-11-24b (round-1
#: revision): maker kinds, split_half / ceiling / constant arms, level-corrected log and Brier
#: scores, task-id cluster bootstrap, theta columns with the calibration-task flag, model_identity.csv.
#: 2026-11-24c (revision 2): base-rate sensitivity target (log_lcw / brier_lcw); the one home-signal
#: flag through msr.metrics.home_signal_flag.
EVAL_RULES = "2026-11-24c"
#: Stages whose answers are task answers (graded); "selfmark" answers are tags.
ANSWER_STAGES = ("write", "build0", "build", "probe", "probe0", "probe_extra", "subset", "variant",
                 "variant0", "online")


def _setting(st: Study, name: str, default):
    return getattr(st.evaluate, name, default)


def headline_family(st: Study) -> str:
    fam = _setting(st, "headline_family", "ema_grade")
    if fam in st.scores.families:
        return fam
    return st.build.drive if st.build.drive in st.scores.families else st.scores.families[0]


# ---------------------------------------------------------------------------
# Reading what Stages A and B saved
# ---------------------------------------------------------------------------


def tables_from_rows(rows: list) -> tuple:
    """(regular, extra, none): {task: {item: [results in repeat order]}} for the regular
    repeats, the same for the extra home repeats, and {task: [results]} with no item."""
    reg: dict = defaultdict(lambda: defaultdict(list))
    ext: dict = defaultdict(lambda: defaultdict(list))
    none: dict = defaultdict(list)
    for r in sorted(rows, key=lambda r: (r["task_id"], str(r["item_id"]), r["repeat"])):
        if r["item_id"] is None:
            none[r["task_id"]].append(bool(r["correct"]))
        elif r.get("extra"):
            ext[r["task_id"]][r["item_id"]].append(bool(r["correct"]))
        else:
            reg[r["task_id"]][r["item_id"]].append(bool(r["correct"]))
    freeze = lambda d: {t: dict(v) for t, v in d.items()}  # noqa: E731
    return freeze(reg), freeze(ext), dict(none)


def restrict(table: dict, tasks) -> dict:
    keep = set(tasks)
    return {t: v for t, v in table.items() if t in keep}


_VARIANT_CACHE: dict = {}


def _variant_data(variant: dict | None) -> tuple:
    """(flagged call ids, regrade map) of a sensitivity variant, read once per process."""
    if not variant:
        return frozenset(), {}
    key = (variant.get("flagged"), variant.get("regrade"))
    if key not in _VARIANT_CACHE:
        flagged = frozenset(json.loads(Path(key[0]).read_text(encoding="utf-8"))) if key[0] else frozenset()
        regrade = json.loads(Path(key[1]).read_text(encoding="utf-8")) if key[1] else {}
        _VARIANT_CACHE[key] = (flagged, regrade)
    return _VARIANT_CACHE[key]


def _apply_variant(rows: list, variant: dict | None) -> list:
    """Probe rows under a sensitivity rule: flagged calls dropped (they become missing
    cells), regraded calls given their new grade."""
    flagged, regrade = _variant_data(variant)
    if not flagged and not regrade:
        return rows
    out = []
    for r in rows:
        cid = r.get("call_id")
        if cid in flagged:
            continue
        if cid in regrade:
            r = dict(r, correct=bool(regrade[cid]))
        out.append(r)
    return out


def load_cell(st: Study, owner: str, reader: str, stream: str, seed: int, variant: dict | None = None) -> dict:
    from msr.probe import load_probe
    reg, ext, none = tables_from_rows(_apply_variant(load_probe(st, owner, reader, stream, seed), variant))
    return {"reg": reg, "extra": ext, "none": none}


def _bank_dir(st: Study, model: str, stream: str, seed: int, bank: int, variant: dict | None) -> Path:
    if variant and variant.get("banks") and stream in (variant.get("bank_streams") or ()):
        d = Path(variant["banks"]) / model / stream / f"seed{seed}"
        return d if bank == 1 else d / f"bank{bank}"
    return st.bank_dir(model, stream, seed, bank)


def load_bankset(st: Study, model: str, stream: str, seed: int, bank: int = 1, variant: dict | None = None) -> dict:
    """{family: (bank, rule)} of one bank."""
    d = _bank_dir(st, model, stream, seed, bank, variant)
    return {f: S.load_bank(d / f"bank_{f}.json") for f in st.scores.families}


def owner_r0(st: Study, model: str, stream: str, seed: int, variant: dict | None = None) -> float:
    """r0: the owner's no-memory success over its score tasks (Part 0.4, credit's p)."""
    d = _bank_dir(st, model, stream, seed, 1, variant)
    if (d / "r0.json").exists():
        return float(json.loads((d / "r0.json").read_text(encoding="utf-8"))["r0"])
    b0 = st.bank_dir(model, stream, seed) / "build0.jsonl"
    return float(np.mean([r["correct"] for r in read_jsonl(b0)])) if b0.exists() else 0.5


def load_owner(st: Study, model: str, stream: str, seed: int, variant: dict | None = None) -> dict:
    """The owner's final scores, its probe candidates and r0 (its no-memory success on the
    score tasks, used to turn credit into a probability)."""
    from msr.probe import load_candidates
    return {"banks": load_bankset(st, model, stream, seed, 1, variant),
            "cands": load_candidates(st, model, stream, seed), "r0": owner_r0(st, model, stream, seed, variant)}


# ---------------------------------------------------------------------------
# Small dict-based measures (second bank, realism check, wording; and the reference)
# ---------------------------------------------------------------------------


def outcomes_of(table: dict) -> dict:
    return M.probe_outcomes(table)


def conc(scores_: dict, table: dict, cands: dict, weighted: bool = True) -> M.ConcordanceResult:
    if not table:
        return M.ConcordanceResult(NAN, 0)
    return M.concordance(scores_, outcomes_of(table), cands, weighted=weighted)


def split_half_tables(ta: dict, tb: dict, cands: dict, weighted: bool = True) -> float:
    """Noise reference: one measurement as the "score", another as the outcome, both ways."""
    a, b = outcomes_of(ta), outcomes_of(tb)
    common = {t: [i for i in c if i in a.get(t, {}) and i in b.get(t, {})] for t, c in cands.items()
              if t in a and t in b}
    if not common:
        return NAN
    vals = [M.concordance(a, b, common, weighted=weighted).value, M.concordance(b, a, common, weighted=weighted).value]
    vals = [v for v in vals if not math.isnan(v)]
    return float(np.mean(vals)) if vals else NAN


def split_half(table: dict, cands: dict, weighted: bool = True) -> float:
    """Repeat 1 against repeat 2 (pre-registration 2.5, first version)."""
    ta = {t: {i: v[0::2] for i, v in row.items() if len(v) >= 2} for t, row in table.items()}
    tb = {t: {i: v[1::2] for i, v in row.items() if len(v) >= 2} for t, row in table.items()}
    return split_half_tables(ta, tb, cands, weighted)


def agreement(tab_a: dict, tab_b: dict) -> dict:
    """Every run of A compared with every run of B on the same (task, item) cell; the
    agreement two coins with the same success rates would reach, and Cohen's kappa
    (pre-registration 2.11). The counts add up over stream orders."""
    same = total = 0
    sa = na = sb = nb = 0
    cells = 0
    for t, row in tab_a.items():
        for i, va in row.items():
            vb = tab_b.get(t, {}).get(i)
            if not vb or not va:
                continue
            cells += 1
            for x in va:
                for y in vb:
                    same += int(x == y)
                    total += 1
            sa += sum(va); na += len(va)
            sb += sum(vb); nb += len(vb)
    counts = {"same": same, "pairs": total, "succ_a": sa, "n_a": na, "succ_b": sb, "n_b": nb}
    if not total:
        return {"cells": 0, "agree": NAN, "chance": NAN, "kappa": NAN, "rate_a": NAN, "rate_b": NAN, **counts}
    pa, pb = sa / na, sb / nb
    chance = pa * pb + (1 - pa) * (1 - pb)
    agree = same / total
    kappa = (agree - chance) / (1 - chance) if chance < 1 else NAN
    return {"cells": cells, "agree": agree, "chance": chance, "kappa": kappa, "rate_a": pa, "rate_b": pb, **counts}


def spearman(x: list, y: list) -> float:
    """Rank correlation with average ranks for ties."""
    if len(x) < 3:
        return NAN

    def ranks(v):
        v = np.asarray(v, dtype=float)
        order = np.argsort(v, kind="mergesort")
        r = np.empty(len(v))
        r[order] = np.arange(len(v), dtype=float)
        for val in np.unique(v):
            m = v == val
            if m.sum() > 1:
                r[m] = r[m].mean()
        return r

    rx, ry = ranks(x), ranks(y)
    if rx.std() == 0 or ry.std() == 0:
        return NAN
    return float(np.corrcoef(rx, ry)[0, 1])


class FirstShown:
    """msr.metrics.first_shown_success for many score maps on ONE fixed probe table (the
    dict reference of msr.engine.first_shown: w * relevance + (1 - w) * score, then higher
    relevance, then table order)."""

    def __init__(self, table: dict, relevance: dict, w: float, default_score: float = 0.5):
        self.w, self.default = float(w), float(default_score)
        self.tasks = []
        for task, row in M.probe_outcomes(table).items():
            cands = list(dict.fromkeys(row))
            if not cands:
                continue
            rel = [float(relevance[task][c]) for c in cands]
            rates = [row[c] for c in cands]
            self.tasks.append((task, cands, rel, rates, max(row.values())))

    def __call__(self, scores_: dict) -> tuple:
        per, reg = {}, {}
        w, w1, d = self.w, 1.0 - self.w, self.default
        for task, cands, rel, rates, best in self.tasks:
            bkey, bi = None, 0
            for j, c in enumerate(cands):
                key = (-(w * rel[j] + w1 * float(scores_.get(c, d))), -rel[j], j)
                if bkey is None or key < bkey:
                    bkey, bi = key, j
            per[task] = rates[bi]
            reg[task] = best - rates[bi]
        return per, reg


# ---------------------------------------------------------------------------
# Fresh checks (pre-registration 2.6). The index-level draws below are THE definition;
# the list-returning functions (used by the run after the swap and the reference tests)
# and the array engine both call them, so they see exactly the same checks.
# ---------------------------------------------------------------------------


def fresh_pool(table: dict, calib_tasks: list, none_rate: dict) -> list:
    """Every (task, item, results, no-memory rate) cell of the reader on the calibration tasks."""
    return [(t, i, v, none_rate.get(t, 0.0)) for t in calib_tasks for i, v in sorted(table.get(t, {}).items()) if v]


def pool_nrep(pool: list) -> np.ndarray:
    return np.array([len(v) for _, _, v, _ in pool], dtype=np.int64)


def draw_cells(n_pool: int, nrep: np.ndarray, k: int, rng: np.random.Generator) -> tuple:
    """"pick k distinct cells uniformly without replacement; use one of the repeats, chosen
    uniformly" (Part 2.6): (cell indices, repeat indices), min(k, n_pool) of each."""
    m = min(int(k), int(n_pool))
    if m <= 0:
        return np.zeros(0, dtype=np.int64), np.zeros(0, dtype=np.int64)
    idx = rng.choice(int(n_pool), size=m, replace=False)
    return idx, rng.integers(0, nrep[idx])


def draw_random_checks(pool: list, k: int, rng: np.random.Generator) -> list:
    """k distinct cells uniformly without replacement, one random repeat each:
    [(item, success, no-memory baseline)]."""
    idx, rep = draw_cells(len(pool), pool_nrep(pool), k, rng)
    return [(pool[j][1], bool(pool[j][2][r]), pool[j][3]) for j, r in zip(idx.tolist(), rep.tolist())]


def task_groups(pool: list) -> dict:
    """{calibration task: array of its pool cells (pool order)}, tasks sorted."""
    by: dict = defaultdict(list)
    for j, (t, _i, _v, _b) in enumerate(pool):
        by[t].append(j)
    return {t: np.array(by[t], dtype=np.int64) for t in sorted(by)}


def n_audit_tasks(k: int, n_cands: int) -> int:
    """k / 4 calibration tasks for audit_k (4 = the candidates per task)."""
    return max(1, int(round(k / max(1, n_cands))))


def draw_task_cells(groups: dict, nrep: np.ndarray, k: int, n_cands: int, rng: np.random.Generator) -> tuple:
    """audit_k's draw (Part 2.6): k/4 calibration tasks uniformly without replacement,
    every candidate of each checked once with a uniformly chosen repeat.
    Returns (cells, repeats, task label of each cell)."""
    tasks = list(groups)
    if not tasks:
        z = np.zeros(0, dtype=np.int64)
        return z, z, z
    n_t = min(len(tasks), n_audit_tasks(k, n_cands))
    pick = rng.choice(len(tasks), size=n_t, replace=False)
    cells = np.concatenate([groups[tasks[j]] for j in pick])
    labels = np.concatenate([np.full(len(groups[tasks[j]]), n, dtype=np.int64) for n, j in enumerate(pick)])
    return cells, rng.integers(0, nrep[cells]), labels


def draw_task_checks(pool: list, k: int, rng: np.random.Generator, n_cands: int = 4) -> list:
    """For audit: k/4 calibration tasks, every candidate of each checked once:
    [(item, success, no-memory baseline, task)]."""
    cells, rep, _ = draw_task_cells(task_groups(pool), pool_nrep(pool), k, n_cands, rng)
    return [(pool[j][1], bool(pool[j][2][r]), pool[j][3], pool[j][0]) for j, r in zip(cells.tolist(), rep.tolist())]


def item_cells(pool: list) -> dict:
    """{item: array of its pool cells (pool order)}."""
    by: dict = defaultdict(list)
    for j, (_t, i, _v, _b) in enumerate(pool):
        by[i].append(j)
    return {i: np.array(v, dtype=np.int64) for i, v in by.items()}


def retest_items(pool: list, bank: dict, rule, k: int) -> list:
    """The k items with the highest OLD ranking score among the items that appear on a
    calibration task (ties by item id), best first (Part 2.6, retest_k)."""
    by = item_cells(pool)
    return A.top_k_items({i: bank[i] for i in by if i in bank}, rule, k)


def draw_top_cells(cell_lists: list, nrep: np.ndarray, rng: np.random.Generator) -> tuple:
    """One check per re-tested item: a uniformly chosen calibration cell of that item and
    a uniformly chosen repeat. Returns (cells, repeats)."""
    if not cell_lists:
        z = np.zeros(0, dtype=np.int64)
        return z, z
    nc = np.array([len(c) for c in cell_lists], dtype=np.int64)
    j = rng.integers(0, nc)
    cells = np.array([c[x] for c, x in zip(cell_lists, j.tolist())], dtype=np.int64)
    return cells, rng.integers(0, nrep[cells])


def draw_top_checks(pool: list, bank: dict, rule, k: int, rng: np.random.Generator) -> list:
    """HEIRS-style re-test: the k items with the highest OLD score among the items that appear
    on a calibration task, one check each: [(item, success, no-memory baseline)]."""
    by = item_cells(pool)
    top = retest_items(pool, bank, rule, k)
    cells, rep = draw_top_cells([by[i] for i in top], pool_nrep(pool), rng)
    return [(pool[j][1], bool(pool[j][2][r]), pool[j][3]) for j, r in zip(cells.tolist(), rep.tolist())]


def pairs_of(checks: list) -> list:
    """(item, success) of each check; audit's checks keep their task: (item, success, task)."""
    return [(c[0], c[1]) if len(c) < 4 else (c[0], c[1], c[3]) for c in checks]


def draw_hash(stream: str, seed: int, owner: str, reader: str, arm: str, k: int) -> int:
    return stable_int(f"{stream}|{seed}|{owner}|{reader}|{arm}|{k}")


def draw_rng(st: Study, stream: str, seed: int, owner: str, reader: str, arm: str, k: int, d: int):
    """One generator per (pair, order, arm, k, draw), the same for every family (Part 2.6)."""
    return np.random.default_rng([st.evaluate.seed, draw_hash(stream, seed, owner, reader, arm, k), d])


def shuffle_seed(st: Study, stream: str, seed: int, owner: str, j: int) -> list:
    """Seed of the j-th permutation of the shuffled arm (one set per owner bank, so the home
    and swap cells of an owner see the same permutations)."""
    return [st.evaluate.seed, stable_int(f"shuffled|{stream}|{seed}|{owner}"), int(j)]


# ---------------------------------------------------------------------------
# Arrays of one owner bank and one reader table
# ---------------------------------------------------------------------------


class OwnerData:
    """One bank (owner, stream, order) as arrays: items in sorted order, every family as an
    engine.Fam, the probe candidates of every probe task."""

    def __init__(self, st: Study, model: str, stream: str, seed: int, variant: dict | None):
        d = load_owner(st, model, stream, seed, variant)
        self.model = model
        self.banks = d["banks"]
        self.cands = d["cands"]
        self.r0 = d["r0"]
        first = next(iter(self.banks.values()))[0]
        self.items = sorted(first, key=str)
        self.index = {i: n for n, i in enumerate(self.items)}
        self.fams = {f: X.Fam(f, rule, bank, self.items, self.r0) for f, (bank, rule) in self.banks.items()}
        # score-phase visits of every item (the visits family; else the first family that counts them)
        if "visits" in self.banks:
            vb = self.banks["visits"][0]
            self.visits = np.array([float(vb[i].get("visits", 0)) for i in self.items])
        else:
            self.visits = next((F.A["n"] for F in self.fams.values() if "n" in F.A), np.zeros(len(self.items)))
        # thirds of the bank's visit counts (Part 8.2.7): 0 low, 1 mid, 2 high
        q1, q2 = np.percentile(self.visits, [100 / 3, 200 / 3]) if len(self.items) else (0.0, 0.0)
        self.thirds = np.where(self.visits <= q1, 0, np.where(self.visits <= q2, 1, 2))
        # the second bank's ranking scores (same items, other exploration seed), when it exists
        self.x2 = {}
        if 2 in st.banks_of(model) and not (variant or {}).get("banks") \
                and (st.bank_dir(model, stream, seed, 2) / "build_summary.json").exists():
            for f, (bank2, rule2) in load_bankset(st, model, stream, seed, 2).items():
                self.x2[f] = np.array([float(rule2.score(bank2.get(i) or rule2.new_record())) for i in self.items])
        self._ips = None
        self._where = (st, model, stream, seed)

    def ips(self) -> dict:
        """Per item, over the score phase of bank 1: shows, the sum of the logged selection
        probabilities, and the self-normalised inverse-propensity parts sum(y / pi) and
        sum(1 / pi) (Part 8.3.5)."""
        if self._ips is None:
            st, model, stream, seed = self._where
            n = len(self.items)
            out = {k: np.zeros(n) for k in ("shows", "prob_sum", "ips_num", "ips_den")}
            path = st.bank_dir(model, stream, seed) / "episodes.jsonl"
            for e in (read_jsonl(path) if path.exists() else []):
                probs = e.get("probs") or [None] * len(e["shown"])
                for iid, pi in zip(e["shown"], probs):
                    j = self.index.get(iid)
                    if j is None:
                        continue
                    out["shows"][j] += 1
                    if pi:
                        out["prob_sum"][j] += float(pi)
                        out["ips_num"][j] += float(bool(e["correct"])) / float(pi)
                        out["ips_den"][j] += 1.0 / float(pi)
            self._ips = out
        return self._ips


def table_arrays(dtable: dict, tasks: list, cands: dict, index: dict, n_cands: int) -> tuple:
    """(cand (E, C), rel (E, C), y (E, C, R)) from a dict table {task: {item: [results]}},
    candidates in the owner's retrieval order."""
    E = len(tasks)
    C = max([n_cands] + [len(cands.get(t, [])) for t in tasks])
    R = max([1] + [len(v) for t in tasks for v in dtable.get(t, {}).values()])
    cand = np.full((E, C), -1, dtype=np.int64)
    rel = np.zeros((E, C))
    y = np.full((E, C, R), NAN)
    for e, t in enumerate(tasks):
        row = dtable.get(t, {})
        for c, (i, r) in enumerate(cands.get(t, [])):
            cand[e, c] = index[i]
            rel[e, c] = r
            for j, ok in enumerate(row.get(i, [])):
                y[e, c, j] = 1.0 if ok else 0.0
    return cand, rel, y


def level_target(none_rate: dict, calib: list) -> float:
    """The level every arm is corrected to (Part 2.8 as revised, decision S4a): the reader's
    no-memory success on the calibration tasks, the one level every rule knows without an item
    check. It is NOT the reader's success with an item shown (that needs item checks), so the
    corrected scores share a common level error; the correction makes arm differences reflect
    ranking and spread rather than each arm's own level. NaN without calibration tasks."""
    z = [none_rate[t] for t in calib if t in none_rate]
    return float(np.mean(z)) if z else NAN


def level_target_with_item(pool: list) -> float:
    """The base-rate sensitivity target (revision 2, R6 W7): the reader's mean success WITH an item
    shown over the calibration (task, candidate) cells of the cell's fresh-check pool (fresh_pool:
    the cells recal_k draws its checks from), each cell the mean of its repeats. It differs from
    level_target (the reader's no-memory success) by the average memory effect, so the "_lcw"
    scores show whether the PC3/PC4 contrasts depend on which level is chosen. NaN without cells."""
    vals = [float(np.mean([1.0 if x else 0.0 for x in v])) for _t, _i, v, _b in pool if v]
    return float(np.mean(vals)) if vals else NAN


def none_rates(none: dict) -> dict:
    return {t: float(np.mean(v)) for t, v in none.items() if v}


def _all_valid(cand: np.ndarray, y: np.ndarray) -> np.ndarray:
    """Per task: it has candidates, and every candidate cell has at least one valid repeat."""
    has = cand >= 0
    valid = (~np.isnan(y)).any(-1)
    return has.any(1) & np.all(~has | valid, axis=1)


# ---------------------------------------------------------------------------
# Scoring one bank (or a batch of banks) on one table
# ---------------------------------------------------------------------------


class Scorer:
    """First-shown success, regret, w sensitivity, log and Brier of score arrays on one
    reader table, with the study's settings."""

    def __init__(self, st: Study, T: X.Table, cal_items: np.ndarray | None = None, target: float = NAN,
                 target_w: float = NAN):
        self.T = T
        self.w_main = st.build.w_score
        self.w_sens = tuple(st.evaluate.w_sensitivity)
        self.clip = tuple(_setting(st, "prob_clip", S.PROB_CLIP))
        # level correction (Part 2.8 as revised): the item index of every (calibration task,
        # candidate) cell of this reader, and the reader's no-memory success on those tasks
        self.cal_items = None if cal_items is None or not len(cal_items) else np.asarray(cal_items, dtype=np.int64)
        self.target = float(target)
        # base-rate sensitivity (revision 2): the reader's success with an item on the same cells
        self.target_w = float(target_w)

    def level_corrected(self, p, target: float | None = None) -> np.ndarray | None:
        """p shifted on the logit scale so that its mean over the calibration cells equals the
        reader's no-memory success on the calibration tasks (one shift per draw); with `target`,
        that level instead (the base-rate sensitivity passes the with-item success)."""
        tg = self.target if target is None else float(target)
        if self.cal_items is None or not math.isfinite(tg):
            return None
        p = np.asarray(p, dtype=float)
        delta = M.level_shift(p[..., self.cal_items], tg, self.clip)
        return M.shift_probs(p, delta, self.clip)

    def __call__(self, u: np.ndarray, p) -> dict:
        fs, reg = X.first_shown(self.T, u, self.w_main)
        out = {"fs": fs, "reg": reg, "w": {}, "wt": {}}
        for w in self.w_sens:
            if w == self.w_main:
                continue
            out["wt"][w] = X.first_shown(self.T, u, w)[0]
        out["wt"]["z"] = X.first_shown_z(self.T, u)[0]
        for w, v in out["wt"].items():
            out["w"][w] = _nanmean_last(v)
        if p is not None:
            p = np.asarray(p, dtype=float)
            out["log"], out["brier"] = X.log_brier(self.T, p, self.clip)
            pl = self.level_corrected(p)
            if pl is not None:
                out["log_lc"], out["brier_lc"] = X.log_brier(self.T, pl, self.clip)
            if math.isfinite(self.target_w):
                pw = self.level_corrected(p, self.target_w)
                if pw is not None:
                    out["log_lcw"], out["brier_lcw"] = X.log_brier(self.T, pw, self.clip)
        return out


def _nanmean_last(a: np.ndarray) -> np.ndarray:
    ok = ~np.isnan(a)
    n = ok.sum(-1)
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(n > 0, np.where(ok, a, 0.0).sum(-1) / np.where(n > 0, n, 1), NAN)


def _single(ev: dict) -> dict:
    """An arm with one bank: per-task values as they are."""
    out = {"per": ev["fs"], "reg": ev["reg"], "w": {w: float(v) for w, v in ev["w"].items()},
           "wt": dict(ev.get("wt", {}))}
    for key in PROB_KEYS:
        if key in ev:
            out[key] = ev[key]
    return out


def _over_draws(ev: dict, params: dict | None = None) -> dict:
    """An arm with B draws (or permutations): per-task means over the draws (Part 4.5),
    the per-draw pooled values and their spread."""
    out = {"per": ev["fs"].mean(0), "reg": ev["reg"].mean(0),
           "w": {w: float(np.mean(v)) for w, v in ev["w"].items()},
           "wt": {w: v.mean(0) for w, v in ev.get("wt", {}).items()}}
    vals = _nanmean_last(ev["fs"])
    out["draw_values"] = vals
    for key in PROB_KEYS:
        if key in ev:
            out[key] = ev[key].mean(0)
    if "log" in ev:
        out["draw_logs"] = _nanmean_last(ev["log"])
    if "log_lc" in ev:
        out["draw_logs_lc"] = _nanmean_last(ev["log_lc"])
    info = {"draws": int(len(vals)), "draw_sd": float(np.std(vals)) if len(vals) > 1 else 0.0}
    if np.any(~np.isnan(vals)):
        info["value_p05"], info["value_p95"] = (float(x) for x in np.nanpercentile(vals, [5, 95]))
    if "draw_logs" in out and np.any(~np.isnan(out["draw_logs"])):
        info["log_p05"], info["log_p95"] = (float(x) for x in np.nanpercentile(out["draw_logs"], [5, 95]))
    for name, arr in (params or {}).items():
        arr = np.asarray(arr, dtype=float)
        if name == "lam":
            info.update(lam=float(np.mean(arr)), lam_sd=float(np.std(arr)), lam_median=float(np.median(arr)),
                        lam_q25=float(np.percentile(arr, 25)), lam_q75=float(np.percentile(arr, 75)))
        elif name == "level":
            info.update(level=float(np.mean(arr)), level_sd=float(np.std(arr)))
        elif name == "slope":
            info.update(slope=float(np.mean(arr)), slope_sd=float(np.std(arr)),
                        slope_q25=float(np.percentile(arr, 25)), slope_q75=float(np.percentile(arr, 75)))
        elif name == "keep":
            info.update(keep_share=float(np.mean(arr)))
        elif name == "checks":
            info.update(checks=float(np.mean(arr)))
    out["info"] = info
    return out


def _stack(ev_list: list, which: np.ndarray) -> dict:
    """Per-draw evaluations from a few distinct banks: ev_list[j] for draw d with which[d] == j."""
    out = {"fs": np.stack([e["fs"] for e in ev_list])[which], "reg": np.stack([e["reg"] for e in ev_list])[which],
           "w": {w: np.array([e["w"][w] for e in ev_list])[which] for w in ev_list[0]["w"]},
           "wt": {w: np.stack([e["wt"][w] for e in ev_list])[which] for w in ev_list[0].get("wt", {})}}
    for key in PROB_KEYS:
        if key in ev_list[0]:
            out[key] = np.stack([e[key] for e in ev_list])[which]
    return out


class Pool:
    """The fresh-check pool of one cell as arrays (pool order = fresh_pool's order)."""

    def __init__(self, pool: list, index: dict, n_cands: int):
        self.pool = pool
        self.n = len(pool)
        self.nrep = pool_nrep(pool) if pool else np.zeros(0, dtype=np.int64)
        R = int(self.nrep.max()) if self.n else 1
        self.item = np.array([index[i] for _, i, _, _ in pool], dtype=np.int64)
        self.y = np.zeros((self.n, R))
        for j, (_t, _i, v, _b) in enumerate(pool):
            self.y[j, :len(v)] = [1.0 if x else 0.0 for x in v]
        self.base = np.array([float(b) for _, _, _, b in pool], dtype=float)
        self.groups = task_groups(pool)
        self.by_item = item_cells(pool)
        self.n_cands = n_cands


class CellDraws:
    """The random checks of one cell, drawn once and shared by every family ("every family
    sees the same checks", Part 2.6)."""

    def __init__(self, st: Study, key: tuple, P: Pool):
        self.st, self.key, self.P = st, key, P
        self.D = st.evaluate.calib_draws
        self._random: dict = {}
        self._audit: dict = {}

    def _rngs(self, arm: str, k: int):
        stream, seed, owner, reader = self.key
        h = draw_hash(stream, seed, owner, reader, arm, k)
        e = self.st.evaluate.seed
        return (np.random.default_rng([e, h, d]) for d in range(self.D))

    def random(self, arm: str, k: int) -> tuple:
        """(ci, cy, cb), each (D, m): item, outcome and no-memory baseline of every check."""
        if (arm, k) not in self._random:
            P = self.P
            got = [draw_cells(P.n, P.nrep, k, rng) for rng in self._rngs(arm, k)]
            cells = np.array([c for c, _ in got], dtype=np.int64)
            reps = np.array([r for _, r in got], dtype=np.int64)
            self._random[(arm, k)] = (P.item[cells], P.y[cells, reps], P.base[cells])
        return self._random[(arm, k)]

    def top(self, k: int, lists: list) -> tuple:
        """(cells, reps), each (D, m): one check per re-tested item (lists: its pool cells)."""
        got = [draw_top_cells(lists, self.P.nrep, rng) for rng in self._rngs("retest", k)]
        return (np.array([c for c, _ in got], dtype=np.int64), np.array([r for _, r in got], dtype=np.int64))

    def audit(self, k: int) -> tuple:
        """(items, outcomes, pair_a, pair_b, pair_draw, checks per draw) of audit_k's draws."""
        if k not in self._audit:
            P = self.P
            items, ys, pa, pb, pd, n_checks = [], [], [], [], [], []
            off = 0
            for d, rng in enumerate(self._rngs("audit", k)):
                cells, reps, labels = draw_task_cells(P.groups, P.nrep, k, P.n_cands, rng)
                items.append(P.item[cells])
                ys.append(P.y[cells, reps])
                start = 0
                while start < len(labels):
                    end = start
                    while end < len(labels) and labels[end] == labels[start]:
                        end += 1
                    for i1 in range(start, end):
                        for i2 in range(i1 + 1, end):
                            pa.append(off + i1); pb.append(off + i2); pd.append(d)
                    start = end
                off += len(cells)
                n_checks.append(len(cells))
            cat = lambda v, dt: np.concatenate(v).astype(dt) if v else np.zeros(0, dtype=dt)  # noqa: E731
            self._audit[k] = (cat(items, np.int64), cat(ys, float), np.array(pa, dtype=np.int64),
                              np.array(pb, dtype=np.int64), np.array(pd, dtype=np.int64), np.array(n_checks))
        return self._audit[k]


def family_arms(st: Study, key: tuple, fam: X.Fam, bank: dict, sc: Scorer, CD: CellDraws, perms: np.ndarray,
                draws_out: list) -> dict:
    """{arm: evaluation} for every arm that uses the owner's scores, one family."""
    D = st.evaluate.calib_draws
    P = CD.P
    res = {"keep": _single(sc(X.u_of(fam.kind, fam.A), X.p_of(fam.kind, fam.A, fam.r0)))}
    wst = fam.start()
    res["wipe"] = _single(sc(X.u_of(fam.kind, wst), X.p_of(fam.kind, wst, fam.r0)))
    if fam.has_p and math.isfinite(sc.target):
        # constant: every item predicted at the reader's no-memory success on the calibration
        # tasks (the level every rule may know without an item check); ranks like wipe
        res["constant"] = _single(sc(X.u_of(fam.kind, wst), np.full(len(fam.x), sc.target)))
    for lam in st.evaluate.fixed_lambdas:
        dst = X.discount(fam, lam)
        res[f"fixed_{lam:g}"] = _single(sc(X.u_of(fam.kind, dst), X.p_of(fam.kind, dst, fam.r0)))
    pst = X.permute(fam, perms)
    res["shuffled"] = _over_draws(sc(X.u_of(fam.kind, pst), X.p_of(fam.kind, pst, fam.r0)))
    if P.n == 0:
        return res
    grid = st.evaluate.lambda_grid
    stream, seed, owner, reader = key

    def note(arm, k, ev, params):
        info_vals = ev["draw_values"]
        logs = ev.get("draw_logs")
        for d in range(len(info_vals)):
            rec = {"family": fam.name, "arm": f"{arm}_{k}", "k": k, "draw": d}
            for name, arr in params.items():
                v = arr[d]
                rec[name] = (("keep" if v else "wipe") if name == "keep" else
                             (int(v) if name == "checks" else float(v)))
            if "keep" in rec:
                rec["decision"] = rec.pop("keep")
            rec["value"] = None if math.isnan(info_vals[d]) else float(info_vals[d])
            rec["log"] = None if logs is None or math.isnan(logs[d]) else float(logs[d])
            draws_out.append(rec)

    for k in st.evaluate.k_values:
        if fam.has_counts:
            # powerprior: lam by marginal likelihood, base prior fitted to the owner's bank
            ci, cy, _ = CD.random("powerprior", k)
            a0, b0 = fam.prior
            lams = X.powerprior_lambda(fam, ci, cy, grid, a0, b0)
            uniq, which = np.unique(lams, return_inverse=True)
            evs = []
            for lam in uniq:
                stt = X.powerprior_state(fam, float(lam), a0, b0)
                evs.append(sc(X.u_of(fam.kind, stt), X.p_of(fam.kind, stt, fam.r0)))
            ev = _over_draws(_stack(evs, which), {"lam": lams, "checks": np.full(D, ci.shape[1])})
            res[f"powerprior_{k}"] = ev
            note("powerprior", k, ev, {"lam": lams})
            # powerprior_flat: the Beta(1, 1) base (an extra comparison, not pre-registered)
            ci, cy, _ = CD.random("powerprior_flat", k)
            lams = X.flat_lambda(fam, ci, cy, grid)
            uniq, which = np.unique(lams, return_inverse=True)
            evs = []
            for lam in uniq:
                stt = X.discount(fam, float(lam))
                evs.append(sc(X.u_of(fam.kind, stt), X.p_of(fam.kind, stt, fam.r0)))
            ev = _over_draws(_stack(evs, which), {"lam": lams, "checks": np.full(D, ci.shape[1])})
            res[f"powerprior_flat_{k}"] = ev
            note("powerprior_flat", k, ev, {"lam": lams})
        if fam.has_p:
            # recal: p = sigmoid(a + b x'), a ~ N(0, 1), b ~ N(0.5, 1); u = p
            ci, cy, _ = CD.random("recal", k)
            a, b, _conv = X.recal_batch(fam.xprime[ci], cy, fit_slope=fam.slope_ok)
            p = X.recal_probs(fam, a, b)
            ev = _over_draws(sc(p, p), {"level": a, "slope": b, "checks": np.full(D, ci.shape[1])})
            res[f"recal_{k}"] = ev
            note("recal", k, ev, {"level": a, "slope": b})
        # retest: the top-k old-score items among the calibration items, one check each
        top = retest_items(P.pool, bank, fam.rule, k)
        if top:
            cells, reps = CD.top(k, [P.by_item[i] for i in top])
            stt = X.fold(fam, fam.start((D,)), P.item[cells], P.y[cells, reps], P.base[cells])
            ev = _over_draws(sc(X.u_of(fam.kind, stt), X.p_of(fam.kind, stt, fam.r0)),
                             {"checks": np.full(D, cells.shape[1])})
            res[f"retest_{k}"] = ev
            note("retest", k, ev, {})
        # audit: k/4 calibration tasks, every candidate once; keep if Cw of the old scores > 0.5
        items_all, y_all, pa, pb, pd, n_checks = CD.audit(k)
        keep_d, _num, _den = X.audit_keep(fam.x, items_all, y_all, pa, pb, pd, D)
        which = np.where(keep_d, 0, 1)
        ev = _over_draws(_stack([_ev_of(res["keep"]), _ev_of(res["wipe"])], which),
                         {"keep": keep_d, "checks": np.array(n_checks)})
        res[f"audit_{k}"] = ev
        note("audit", k, ev, {"keep": keep_d})
        # pooled and fresh: the k checks folded in with the family's own update
        for arm in ("pooled", "fresh"):
            ci, cy, cb = CD.random(arm, k)
            stt = fam.batch(D) if arm == "pooled" else fam.start((D,))
            stt = X.fold(fam, stt, ci, cy, cb)
            ev = _over_draws(sc(X.u_of(fam.kind, stt), X.p_of(fam.kind, stt, fam.r0)),
                             {"checks": np.full(D, ci.shape[1])})
            res[f"{arm}_{k}"] = ev
            note(arm, k, ev, {})
    return res


def _ev_of(single: dict) -> dict:
    """An arm's single-bank result back in the scorer's form (for audit's mixture)."""
    out = {"fs": single["per"], "reg": single["reg"], "w": dict(single["w"]), "wt": dict(single.get("wt", {}))}
    for key in PROB_KEYS:
        if key in single:
            out[key] = single[key]
    return out


# ---------------------------------------------------------------------------
# One owner job: (owner, stream, order) against every reader
# ---------------------------------------------------------------------------


def results_dir_for(st: Study, variant: dict | None) -> Path:
    if variant and variant.get("name") not in (None, "", "primary"):
        return st.results_dir / "sensitivity" / variant["name"]
    return st.results_dir


def per_task_path(st: Study, owner: str, reader: str, stream: str, seed: int, variant: dict | None = None) -> Path:
    return results_dir_for(st, variant) / "per_task" / f"{owner}__{reader}__{stream}__seed{seed}.npz"


def load_per_task(st: Study, owner: str, reader: str, stream: str, seed: int, variant: dict | None = None) -> dict:
    with np.load(per_task_path(st, owner, reader, stream, seed, variant), allow_pickle=False) as z:
        return {k: z[k] for k in z.files}


def _readers_of(st: Study, owner: str) -> list:
    return [r for (o, r) in st.cells if o == owner]


def _drop_rule(variant: dict | None) -> str:
    return (variant or {}).get("drop", "task")


def evaluate_owner(st: Study, owner: str, stream: str, seed: int, variant: dict | None = None,
                   readers: list | None = None) -> dict:
    """Everything for one owner bank (owner, stream, order) against each of its readers.
    Writes every cell's per-task arrays and random draws; returns the rows."""
    variant = variant or {}
    calib, evals = st.calib_eval(stream, seed)
    probe_all = list(st.splits(stream, seed)["probe"])
    n_c = st.probe.candidates
    drop = _drop_rule(variant)
    O = OwnerData(st, owner, stream, seed, variant)
    home = load_cell(st, owner, owner, stream, seed, variant)
    readers = _readers_of(st, owner) if readers is None else readers
    cand_e, rel_e, yh = table_arrays(home["reg"], evals, O.cands, O.index, n_c)
    _, _, yx = table_arrays(home["extra"], evals, O.cands, O.index, n_c)
    home_ok = _all_valid(cand_e, yh)
    eseed_perms = np.array([A.shuffle_order(len(O.items), shuffle_seed(st, stream, seed, owner, j))
                            for j in range(st.evaluate.shuffled_seeds)], dtype=np.int64)
    reader_cache: dict = {}
    out_cells = []
    for reader in readers:
        key = (stream, seed, owner, reader)
        cell = home if reader == owner else load_cell(st, owner, reader, stream, seed, variant)
        nr = none_rates(cell["none"])
        _, _, yr = table_arrays(cell["reg"], evals, O.cands, O.index, n_c)
        none_ok = np.array([t in nr for t in evals], dtype=bool)
        if drop == "available":
            task_ok = None
        else:
            task_ok = _all_valid(cand_e, yr) & home_ok & none_ok
        Th = X.Table(cand_e, rel_e, yh, task_ok)
        Tr = X.Table(cand_e, rel_e, yr, task_ok)
        Tx = X.Table(cand_e, rel_e, yx, task_ok)
        Ts = Tx if reader == owner else Tr
        pool = fresh_pool(cell["reg"], calib, nr)
        PP = Pool(pool, O.index, n_c)
        cal_target = level_target(nr, calib)
        sc = Scorer(st, Tr, PP.item, cal_target, level_target_with_item(pool))
        CD = CellDraws(st, key, PP)
        base = {"owner": owner, "reader": reader, "kind": maker_kind(st, owner, reader), "stream": stream, "seed": seed}
        n_valid = int(Tr.ok.sum())
        dropped = len(evals) - n_valid
        arrays: dict = {"tasks": np.array(evals), "valid": Tr.ok.copy()}
        draws: list = []
        ag = agreement(restrict(home["reg"], calib),
                       restrict(cell["reg"] if owner != reader else home["extra"], calib))

        # arms that ignore the scores
        none_per = np.array([nr.get(t, NAN) for t in evals], dtype=float)
        none_per = np.where(Tr.ok & none_ok, none_per, NAN)
        fixed_arms = {"none": {"per": none_per, "reg": Tr.best - none_per, "w": {}}}
        rp, rr = X.first_shown(Tr, np.full(len(O.items), 0.5), 0.0)
        fixed_arms["relevance"] = {"per": rp, "reg": rr, "w": {}}
        op, orr = X.split_half_pick(Tr)
        fixed_arms["split_half"] = {"per": op, "reg": orr, "w": {}}
        # ceiling: the best candidate by the mean of both repeats, scored on the same repeats (an
        # in-sample upper reference for any rule that shows one of the four candidates)
        fixed_arms["ceiling"] = {"per": np.where(Tr.ok, Tr.best, NAN), "reg": np.where(Tr.ok, 0.0, NAN), "w": {}}
        no_memory = _nanmean_last(none_per)

        # noise references (Part 2.5)
        ceil_swap = X.split_half(Tr, Tr.y[..., 0], Tr.y[..., 1]) if Tr.y.shape[-1] >= 2 else NAN
        ceil_home = X.split_half(Th, Th.y[..., 0], Th.y[..., 1]) if Th.y.shape[-1] >= 2 else NAN
        ceil_home_extra = X.split_half(Th, Th.ybar, Tx.ybar) if home["extra"] else NAN

        validity_rows, arm_rows, parts = [], [], {}
        families_results = {}
        for fname, fam in O.fams.items():
            bank, rule = O.banks[fname]
            Sx = fam.x[cand_e]
            row = dict(base, family=fname)
            got = {}
            for name, T in (("home", Th), ("swap", Ts), ("floor", Tx)):
                num, den, nu, du = X.conc_parts(T, Sx)
                got[name] = (num, den, nu, du)
                row[name] = float(X.ratio(num, den))
                row[f"{name}_u"] = float(X.ratio(nu, du))
                arrays[f"{fname}|conc_{name}"] = np.stack([num, den], axis=1)
                arrays[f"{fname}|conc_{name}_u"] = np.stack([nu, du], axis=1)
            row["home_pairs"] = int(np.nansum(got["home"][3]))
            row["swap_pairs"] = int(np.nansum(got["swap"][3]))
            row["home_weight"] = float(np.nansum(got["home"][1]))     # sum of pair weights: pools Cw over orders
            row["swap_weight"] = float(np.nansum(got["swap"][1]))
            parts[fname] = {n: np.stack([got[n][0], got[n][1]], axis=1) for n in ("home", "swap", "floor")}
            row.update(drop=row["home"] - row["swap"], ratio=NAN, ratio_status="", home_se=NAN,
                       floor_drop=row["home"] - row["floor"],
                       ceiling_home=ceil_home, ceiling_swap=ceil_swap, ceiling_home_extra=ceil_home_extra)
            for kk in (1, 2):
                for name, T in (("home", Th), ("swap", Ts)):
                    hits, chances = X.top_agreement_tasks(T, fam.x, kk)
                    okh = ~np.isnan(hits)
                    row[f"top{kk}_{name}"] = float(hits[okh].mean()) if okh.any() else NAN
                    row[f"top{kk}_{name}_chance"] = float(chances[okh].mean()) if okh.any() else NAN
                    arrays[f"{fname}|top{kk}_{name}"] = hits
                    arrays[f"{fname}|top{kk}_{name}_chance"] = chances
            # concordance variants (Part 8.2.7): tau-b, score ties, C without ties, visit thirds;
            # the second bank's scores; counters ranked by helpful - harmful (Part 8.2.14)
            extra_x = {}
            if fname in O.x2:
                extra_x["bank2"] = O.x2[fname]
            if fam.kind == "counter":
                extra_x["net"] = fam.A["h"] - fam.A["g"]
            for name, T in (("home", Th), ("swap", Ts), ("floor", Tx)):
                ps = X.pair_stats(T, fam.x, O.thirds)
                for part, arr in ps.items():
                    arrays[f"{fname}|{part}_{name}" if part in ("tau", "ties") else f"{fname}|conc_{name}_{part}"] = arr
                row[f"tau_b_{name}"] = X.tau_b(ps["tau"])
                row[f"tie_share_{name}"] = float(X.ratio(ps["ties"][:, 0], ps["ties"][:, 1]))
                row[f"{name}_noties"] = float(X.ratio(ps["noties"][:, 0], ps["noties"][:, 1]))
                for g in ("low", "mid", "high"):
                    a_ = ps[f"visits_{g}"]
                    row[f"{name}_visits_{g}"] = float(X.ratio(a_[:, 0], a_[:, 1]))
                for tag, xx in extra_x.items():
                    num, den, _, _ = X.conc_parts(T, xx[cand_e])
                    arrays[f"{fname}|conc_{name}_{tag}"] = np.stack([num, den], axis=1)
                    row[f"{name}_{tag}"] = float(X.ratio(num, den))
            # shuffled control: the owner's scores permuted across all items (Part 2.6)
            xs = fam.x[eseed_perms][:, cand_e]
            sh = {}
            for name, T in (("home", Th), ("swap", Ts)):
                num, den, _, _ = X.conc_parts(T, xs)
                vals = X.ratio(num, den)
                sh[name] = float(np.nanmean(vals)) if np.any(~np.isnan(vals)) else NAN
                arrays[f"{fname}|conc_{name}_shuffled"] = np.stack([num.mean(0), den[0]], axis=1)
            row.update(home_shuffled=sh["home"], swap_shuffled=sh["swap"], eval_tasks=len(evals),
                       valid_tasks=n_valid, dropped_tasks=dropped)
            validity_rows.append(row)
            families_results[fname] = family_arms(st, key, fam, bank, sc, CD, eseed_perms, draws)

        # own: the reader's own bank, candidates and home results (Part 2.6)
        if reader not in reader_cache:
            RD = O if reader == owner else OwnerData(st, reader, stream, seed, variant)
            rhome = home if reader == owner else load_cell(st, reader, reader, stream, seed, variant)
            rc, rrel, ry = table_arrays(rhome["reg"], evals, RD.cands, RD.index, n_c)
            rnone = none_rates(rhome["none"])
            r_ok = None if drop == "available" else \
                _all_valid(rc, ry) & np.array([t in rnone for t in evals], dtype=bool)
            rpool_l = fresh_pool(rhome["reg"], calib, rnone)
            rpool = Pool(rpool_l, RD.index, n_c)
            r_target = level_target(rnone, calib)
            reader_cache[reader] = (RD, Scorer(st, X.Table(rc, rrel, ry, r_ok), rpool.item, r_target,
                                               level_target_with_item(rpool_l)))
        RD, rsc = reader_cache[reader]
        for fname, rfam in RD.fams.items():
            if fname in families_results:
                own = _single(rsc(X.u_of(rfam.kind, rfam.A), X.p_of(rfam.kind, rfam.A, rfam.r0)))
                if task_ok is not None:          # a task dropped in this cell is dropped for every arm
                    for m_ in ("per", "reg") + PROB_KEYS:
                        if m_ in own:
                            own[m_] = np.where(task_ok, own[m_], NAN)
                    own["wt"] = {w: np.where(task_ok, v, NAN) for w, v in own["wt"].items()}
                    own["w"] = {w: float(_nanmean_last(v)) for w, v in own["wt"].items()}
                families_results[fname]["own"] = own

        def add_rows(fam_name, arm, ev):
            info = ev.get("info", {})
            per = ev["per"]
            row = dict(base, family=fam_name, arm=arm, value=float(_nanmean_last(per)),
                       regret=float(_nanmean_last(ev["reg"])), n_tasks=int(np.count_nonzero(~np.isnan(per))),
                       no_memory=float(no_memory),
                       log_score=float(_nanmean_last(ev["log"])) if "log" in ev else NAN,
                       brier=float(_nanmean_last(ev["brier"])) if "brier" in ev else NAN,
                       log_score_lc=float(_nanmean_last(ev["log_lc"])) if "log_lc" in ev else NAN,
                       brier_lc=float(_nanmean_last(ev["brier_lc"])) if "brier_lc" in ev else NAN,
                       log_score_lcw=float(_nanmean_last(ev["log_lcw"])) if "log_lcw" in ev else NAN,
                       brier_lcw=float(_nanmean_last(ev["brier_lcw"])) if "brier_lcw" in ev else NAN)
            for w in st.evaluate.w_sensitivity:
                row[f"value_w{w:g}"] = ev["w"].get(w, NAN)
            row["value_wz"] = ev["w"].get("z", NAN)
            for k_ in ("lam", "lam_sd", "lam_median", "level", "slope", "keep_share", "draws", "draw_sd",
                       "value_p05", "value_p95", "log_p05", "log_p95", "lam_q25", "lam_q75", "level_sd",
                       "slope_sd", "slope_q25", "slope_q75", "checks"):
                row[k_] = info.get(k_, "")
            row["dropped_tasks"] = dropped
            arm_rows.append(row)
            for metric in ("per", "reg") + PROB_KEYS:
                if metric in ev:
                    arrays[f"{fam_name}|{arm}|{ {'per': 'value', 'reg': 'regret'}.get(metric, metric) }"] = \
                        np.asarray(ev[metric], dtype=float)
            for w, v in ev.get("wt", {}).items():
                arrays[f"{fam_name}|{arm}|value_w{'z' if w == 'z' else format(w, 'g')}"] = np.asarray(v, dtype=float)

        for arm, ev in fixed_arms.items():
            add_rows(NO_FAMILY, arm, ev)
        for fname, res in families_results.items():
            for arm, ev in res.items():
                add_rows(fname, arm, ev)

        if variant.get("name") in (None, "", "primary"):
            _write_cells(st, O, cell, home, owner, reader, stream, seed, probe_all, set(calib), n_c)
        p = per_task_path(st, owner, reader, stream, seed, variant)
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_name(p.stem + ".part.npz")
        np.savez_compressed(tmp, **arrays)
        tmp.replace(p)
        if variant.get("draws_log", True):
            write_jsonl(results_dir_for(st, variant) / "draws" / f"{owner}__{reader}__{stream}__seed{seed}.jsonl",
                        draws)
        out_cells.append({"key": (owner, reader, stream, seed), "validity": validity_rows, "arms": arm_rows,
                          "agreement": {**base, **ag}, "parts": parts, "dropped": dropped, "n_tasks": len(evals)})

    gate = None
    if owner in readers:
        gate = _gate_arrays(st, O, home, probe_all, n_c, drop)
    # the owner's home signal on its CALIBRATION tasks, per family: the input of theta's headline
    # reporting flag (msr.metrics.home_signal_flag, Part 2.4 as revised)
    cal_v = {}
    if calib:
        cc, _, ycal = table_arrays(home["reg"], calib, O.cands, O.index, n_c)
        pres = cc >= 0
        ybc = _nanmean_last(ycal)
        for fname, fam in O.fams.items():
            xc = np.where(pres, fam.x[np.maximum(cc, 0)], NAN)
            cal_v[fname] = M.signed_validity_parts(xc, ybc, pres)[0]
    return {"owner": owner, "stream": stream, "seed": seed, "cells": out_cells, "gate": gate, "cal_v": cal_v}


def cells_path(st: Study, owner: str, reader: str, stream: str, seed: int) -> Path:
    return st.results_dir / "cells" / f"{owner}__{reader}__{stream}__seed{seed}.npz"


def _write_cells(st: Study, O: OwnerData, cell: dict, home: dict, owner: str, reader: str, stream: str,
                 seed: int, probe_all: list, calib: set, n_c: int) -> None:
    """results/cells/<owner>__<reader>__<stream>__seed<k>.npz: the raw cells of one probe
    table, every probe task (results/SCHEMA.md lists the arrays)."""
    ca, ra, ya = table_arrays(cell["reg"], probe_all, O.cands, O.index, n_c)
    _, _, yha = table_arrays(home["reg"], probe_all, O.cands, O.index, n_c)
    has = ca >= 0
    cj = np.maximum(ca, 0)
    items = np.array(O.items, dtype=str)
    out = {"tasks": np.array(probe_all, dtype=str), "is_calib": np.array([t in calib for t in probe_all]),
           "items": np.where(has, items[cj], ""), "relevance": np.where(has, ra, np.nan),
           "visits": np.where(has, O.visits[cj], np.nan), "visit_third": np.where(has, O.thirds[cj], -1),
           "y": ya, "y_home": yha}
    ips = O.ips()
    for k, v in ips.items():
        out[k] = np.where(has, v[cj], np.nan)
    rz = max([1] + [len(v) for v in cell["none"].values()])
    none = np.full((len(probe_all), rz), np.nan)
    for e, t in enumerate(probe_all):
        for j, ok in enumerate(cell["none"].get(t, [])):
            none[e, j] = 1.0 if ok else 0.0
    out["none"] = none
    if owner == reader and home["extra"]:
        out["y_extra"] = table_arrays(home["extra"], probe_all, O.cands, O.index, n_c)[2]
    for f, F in O.fams.items():
        out[f"score_{f}"] = np.where(has, F.x[cj], np.nan)
        if F.kind == "counter":
            out[f"score_{f}_net"] = np.where(has, (F.A["h"] - F.A["g"])[cj], np.nan)
        if f in O.x2:
            out[f"score_{f}_bank2"] = np.where(has, O.x2[f][cj], np.nan)
    p = cells_path(st, owner, reader, stream, seed)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_name(p.stem + ".part.npz")
    np.savez_compressed(tmp, **out)
    tmp.replace(p)


def _gate_arrays(st: Study, O: OwnerData, home: dict, probe_all: list, n_c: int, drop: str) -> dict:
    """Per-task home values over ALL probe tasks (calibration + evaluation), for the gate:
    "The gate and every rule of 9.2 use all 200 probe tasks, because they read home cells
    only" (Part 9.1)."""
    cand, rel, y = table_arrays(home["reg"], probe_all, O.cands, O.index, n_c)
    nr = none_rates(home["none"])
    none_ok = np.array([t in nr for t in probe_all], dtype=bool)
    ok = None if drop == "available" else (_all_valid(cand, y) & none_ok)
    T = X.Table(cand, rel, y, ok)
    out = {"tasks": len(probe_all), "none": np.where(T.ok & none_ok, [nr.get(t, NAN) for t in probe_all], NAN),
           "keep": {}, "conc": {}}
    for f, fam in O.fams.items():
        out["keep"][f] = X.first_shown(T, X.u_of(fam.kind, fam.A), st.build.w_score)[0]
        num, den, _, _ = X.conc_parts(T, fam.x[cand])
        out["conc"][f] = np.stack([num, den], axis=1)
    both = T.has & ~np.isnan(y[..., 0]) & (~np.isnan(y[..., 1]) if y.shape[-1] > 1 else False)
    out["cells_both"] = int(both.sum())
    out["cells_differ"] = int((both & (y[..., 0] != y[..., -1])).sum()) if y.shape[-1] > 1 else 0
    valid = T.cmask & T.ok[:, None]
    yb = np.where(valid, T.ybar, np.nan)
    with np.errstate(invalid="ignore"):
        spread = (np.nanmax(yb, 1) - np.nanmin(yb, 1)) > 1e-12
    out["tasks_judged"] = int(T.ok.sum())
    out["tasks_differ"] = int((spread & T.ok).sum())
    return out


# ---- worker processes (spawn: works the same on Windows and Linux) ----------------------

_WORKER: dict = {}


def _init_worker(runs_root: str, study_path: str) -> None:
    L.RUNS = Path(runs_root)
    L.SPEND_PATH = L.RUNS / "spend.json"
    _WORKER["st"] = load_study(study_path)


def _owner_job(args: tuple) -> dict:
    owner, stream, seed, variant = args
    return evaluate_owner(_WORKER["st"], owner, stream, seed, variant)


def _processes(st: Study, n_jobs: int) -> int:
    p = st.evaluate.processes or min(8, os.cpu_count() or 1)
    return max(1, min(p, n_jobs))


def run_jobs(st: Study, variant: dict | None, printer=print, streams=None) -> list:
    """Every owner job of a variant, in parallel processes; results in a fixed order."""
    streams = tuple(streams or st.streams)
    owners = list(dict.fromkeys(o for o, _ in st.cells))
    work = [(o, s, k, variant) for s in streams for k in st.seeds for o in owners]
    n_proc = _processes(st, len(work))
    out = {}
    tag = f" [{variant['name']}]" if variant and variant.get("name") not in (None, "primary") else ""
    n_cells = sum(len(_readers_of(st, o)) for o in owners) * len(streams) * len(st.seeds)
    done_cells = 0

    def collect(n, res, w):
        nonlocal done_cells
        out[w[:3]] = res
        done_cells += len(res["cells"])
        printer(f"  [evaluate{tag}] {100 * n / len(work):5.1f}%  ({done_cells}/{n_cells} cells)  owner {w[0]} "
                f"{w[1]} seed {w[2]}")

    if n_proc <= 1:
        for n, w in enumerate(work, 1):
            collect(n, evaluate_owner(st, *w), w)
    else:
        import multiprocessing as mp
        from concurrent.futures import ProcessPoolExecutor, as_completed
        ctx = mp.get_context("spawn")
        with ProcessPoolExecutor(max_workers=n_proc, mp_context=ctx, initializer=_init_worker,
                                 initargs=(str(L.RUNS), str(st.path))) as ex:
            futs = {ex.submit(_owner_job, w): w for w in work}
            for n, fut in enumerate(as_completed(futs), 1):
                collect(n, fut.result(), futs[fut])
    return [out[w[:3]] for w in work]


# ---------------------------------------------------------------------------
# Retained validity, the drop and the noise floor, with the joint bootstrap (Parts 2.3-2.4, 4)
# ---------------------------------------------------------------------------


def _ratio_samples(sums: np.ndarray) -> np.ndarray:
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(sums[:, 1] > 0, sums[:, 0] / np.where(sums[:, 1] > 0, sums[:, 1], 1.0), NAN)


def retained(st: Study, jobs: list) -> tuple:
    """retained.csv rows, per-order ratio rows, and pooled numbers for the summary.

    For every (owner, reader, family): C_home, C_swap and C_fresh of the owner, pooled over
    the orders of a stream (ratio of summed numerators and weights, Part 2.2), and over the
    streams as the mean of the per-stream values (Part 2.4). Bootstrap (the task-only interval,
    secondary after the round-1 revision): task IDS resampled per stream, pooled over its orders
    (a task that sits in two orders is one cluster; metrics.task_cluster_counts), the same draws
    for every cell (Part 4.1). The headline theta = V_swap / V_home (metrics, Part 2.4 as revised)
    is added with the same draws; its primary two-way interval is msr.analysis's."""
    B = st.evaluate.bootstrap
    eseed = st.evaluate.seed
    min_z = _setting(st, "ratio_min_z", RATIO_MIN_Z)
    nif = _setting(st, "ni_fraction", 0.25)
    fams = list(st.scores.families)
    by = {}
    for j in jobs:
        for c in j["cells"]:
            by[c["key"]] = c
    present = {(k[0], k[1]) for k in by}
    cells = [c for c in st.cells if c in present]
    streams = [s for s in st.streams if any(k[2] == s for k in by)]
    quantities = ("home", "swap", "floor")
    cols = [(o, r, f, q) for (o, r) in cells for f in fams for q in quantities]
    col_index = {c: n for n, c in enumerate(cols)}
    per_stream = {}          # stream -> {"point": (K, 2) sums, "boot": (B, K, 2) sums}
    order_rows = {}
    counts = M.task_cluster_counts({(s_, o_): list(st.calib_eval(s_, o_)[1]) for s_ in streams for o_ in st.seeds
                                    if any(k[2] == s_ and k[3] == o_ for k in by)}, B, eseed)

    def c_of(level: dict, o, r, f, q):
        ci = col_index[(o, r, f, q)]
        pt = level["point"][ci]
        point = pt[0] / pt[1] if pt[1] > 0 else NAN
        return point, _ratio_samples(level["boot"][:, ci, :])

    def stats(levels: list, o, r, f) -> dict:
        """C_home, C_swap, C_fresh (point, samples): mean over the given levels."""
        out = {}
        for q, (oo, rr, qq) in (("home", (o, r, "home")), ("swap", (o, r, "swap")),
                                ("self_home", (o, o, "home")), ("fresh", (o, o, "floor"))):
            pts, sms = [], []
            for lv in levels:
                if (oo, rr, f, qq) not in col_index:
                    continue
                pt, sm = c_of(lv, oo, rr, f, qq)
                pts.append(pt)
                sms.append(sm)
            out[q] = (float(np.mean(pts)) if pts else NAN, np.mean(sms, axis=0) if sms else np.full(B, NAN))
        return out

    for stream in streams:
        tot_p = np.zeros((len(cols), 2))
        tot_b = np.zeros((B, len(cols), 2))
        tot_vp = tot_vb = None
        for seed in st.seeds:
            any_cell = next((by[k] for k in by if k[2] == stream and k[3] == seed), None)
            if any_cell is None:
                continue
            n = any_cell["n_tasks"]
            Mx = np.zeros((n, len(cols), 2))
            for (o, r, f, q), ci in col_index.items():
                c = by.get((o, r, stream, seed))
                if c is None or f not in c["parts"]:
                    continue
                Mx[:, ci, :] = np.nan_to_num(c["parts"][f][q], nan=0.0)
            W = counts[(stream, seed)]
            Vx = 2.0 * Mx[:, :, 0] - Mx[:, :, 1]          # signed validity V per task (metrics)
            Nx = np.zeros((n, len(cols)))
            for (o, r, f, q), ci in col_index.items():
                c = by.get((o, r, stream, seed))
                if c is not None and f in c["parts"]:
                    Nx[:, ci] = np.isfinite(c["parts"][f][q][:, 1]).astype(float)
            lv = {"point": Mx.sum(0), "boot": (W @ Mx.reshape(n, -1)).reshape(B, len(cols), 2),
                  "vpoint": np.stack([Vx.sum(0), Nx.sum(0)], axis=1),
                  "vboot": np.stack([W @ Vx, W @ Nx], axis=2)}
            for (o, r) in cells:
                if (o, r, stream, seed) not in by:
                    continue
                for f in fams:
                    ph, sh_ = c_of(lv, o, r, f, "home")
                    ps, ss_ = c_of(lv, o, r, f, "swap")
                    order_rows[(o, r, stream, seed, f)] = M.ratio_rule(ph, ps, sh_, ss_, min_z=min_z)
            tot_p += lv["point"]
            tot_b += lv["boot"]
            tot_vp = lv["vpoint"] if tot_vp is None else tot_vp + lv["vpoint"]
            tot_vb = lv["vboot"] if tot_vb is None else tot_vb + lv["vboot"]
            del lv
        per_stream[stream] = {"point": tot_p, "boot": tot_b, "vpoint": tot_vp, "vboot": tot_vb}

    def vmean(levels: list, o, r, f, q) -> tuple:
        """Sum over the levels (streams) of the mean V per valid task: point and draws."""
        if (o, r, f, q) not in col_index:
            return NAN, np.full(B, NAN)
        ci = col_index[(o, r, f, q)]
        pt, dr = 0.0, np.zeros(B)
        for lv in levels:
            if lv.get("vpoint") is None:
                return NAN, np.full(B, NAN)
            a, n_ = lv["vpoint"][ci]
            if n_ <= 0:
                return NAN, np.full(B, NAN)
            pt += a / n_
            with np.errstate(invalid="ignore", divide="ignore"):
                dr = dr + np.where(lv["vboot"][:, ci, 1] > 0, lv["vboot"][:, ci, 0] / lv["vboot"][:, ci, 1], NAN)
        return pt, dr

    cal = {}
    for j in jobs:
        for f, v in (j.get("cal_v") or {}).items():
            cal.setdefault((f, j["owner"], j["stream"]), []).append(np.asarray(v, dtype=float))

    def cal_status(o, f, lvl):
        arr = [a for b in (streams if lvl == "all" else [lvl]) for a in cal.get((f, o, b), [])]
        # THE one home-signal flag of the code base (msr.metrics.home_signal_flag, revision 2)
        if arr:
            return M.home_signal_flag(np.concatenate(arr))
        return NAN, M.theta_status_calibration(NAN)

    rows = []
    for (o, r) in cells:
        for f in fams:
            levels = [(s, [per_stream[s]]) for s in streams] + [("all", [per_stream[s] for s in streams])]
            for lvl_name, lvls in levels:
                q = stats(lvls, o, r, f)
                (ch, chs), (cs, css) = q["home"], q["swap"]
                (sh, shs), (cf, cfs) = q["self_home"], q["fresh"]
                d, ds = ch - cs, chs - css
                dself, dselfs = sh - cf, shs - cfs
                rr = M.ratio_rule(ch, cs, chs, css, min_z=min_z)
                nf = M.noise_floor_rule(d, ds, dselfs)
                N = M.noninferiority_stat(ch, cs, nif)
                Ns = M.noninferiority_stat(chs, css, nif)
                okd = ds[~np.isnan(ds)]
                d_lo, d_hi = (float(x) for x in np.percentile(okd, [2.5, 97.5])) if len(okd) else (NAN, NAN)
                rows.append({"owner": o, "reader": r, "kind": maker_kind(st, o, r), "stream": lvl_name, "family": f,
                             "c_home": ch, "c_swap": cs, "se_home": rr["se_home"],
                             "drop": d, "drop_lo": d_lo, "drop_hi": d_hi, "p_drop": nf["p_drop"],
                             "self_drop": dself, "self_drop_hi": nf["u_self"],
                             "drop_beyond_floor": nf["counts"],
                             "ratio": rr["ratio"], "ratio_lo": rr["lo"], "ratio_hi": rr["hi"],
                             "ratio_status": rr["status"], "ratio_bad_draws": rr["bad_share"],
                             "ni_stat": N, "p_ni": M.p_lower(Ns) if rr["status"] != M.RATIO_UNDEFINED else NAN,
                             "bootstrap": B})
                # the headline: theta = V_swap / V_home on the same tasks (for a home cell the
                # "swap" is the self-swap, repeats 3-4); task-only interval here
                vh, vhs = vmean(lvls, o, r, f, "home")
                vs, vss = vmean(lvls, o, r, f, "swap")
                se_vh = float(np.nanstd(vhs, ddof=1)) if np.isfinite(vhs).sum() > 1 else NAN
                with np.errstate(invalid="ignore", divide="ignore"):
                    ths = vss / vhs
                ok_ = np.isfinite(ths)
                status = M.theta_status(vh, se_vh)
                t_lo, t_hi = ((float(x) for x in np.percentile(ths[ok_], [2.5, 97.5]))
                              if ok_.sum() > 1 else (NAN, NAN))          # always written (24 Nov 2026)
                z_cal, st_cal = cal_status(o, f, lvl_name)
                rows[-1].update({"v_home": vh, "v_swap": vs, "theta": M.theta_from_sums(vs, vh),
                                 "theta_status": status, "theta_lo_task": t_lo, "theta_hi_task": t_hi,
                                 "se_v_home_task": se_vh, "z_cal": z_cal, "theta_status_calibration": st_cal})
    return rows, order_rows


# ---------------------------------------------------------------------------
# The pilot gate (Part 9.3)
# ---------------------------------------------------------------------------


def gate_numbers(st: Study, jobs: list, costs: list, plan: dict) -> list:
    """The five gate lines per (model, stream) (Part 9.3). Gates 1, 2 and 4 read the model's
    home cell over ALL probe tasks; gate 3 pools the home cells of every model of the study
    (the pilot's two models); gate 5 pools every call of the study."""
    old_models = {a for a, _ in st.upgrade_pairs}
    B = st.evaluate.bootstrap
    eseed = st.evaluate.seed
    fam1 = "ema_grade" if "ema_grade" in st.scores.families else headline_family(st)
    gates = {(j["owner"], j["stream"], j["seed"]): j["gate"] for j in jobs if j.get("gate")}
    # gate 5: every call of the study
    fresh = sum(c["fresh_calls"] for c in costs)
    usd = sum(c["usd"] for c in costs)
    est_calls = sum(sum(d.values()) for d in plan["calls"].values())
    est_usd = sum(sum(d.values()) for d in plan["usd"].values())
    meas = 1000 * usd / fresh if fresh else NAN
    est = 1000 * est_usd / est_calls if est_calls else NAN
    pass5 = bool((not math.isnan(meas) and not math.isnan(est) and meas <= 2 * est + 1e-12)
                 or (math.isnan(meas) and (math.isnan(est) or est == 0)))
    out = []
    for stream in st.streams:
        both = differ = 0
        for (m, s, k), g in gates.items():
            if s == stream:
                both += g["cells_both"]
                differ += g["cells_differ"]
        dis_all = differ / both if both else NAN
        for m in st.models:
            row = {"model": m, "stream": stream, "old_model": m in old_models or not st.upgrade_pairs,
                   "gate1_family": fam1}
            gs = {k: gates[(m, stream, k)] for k in st.seeds if (m, stream, k) in gates}
            if not gs:
                continue
            # 1) memory helps: FS_keep - FS_none, paired over all probe tasks
            Ws = {k: M.bootstrap_counts(g["tasks"], B, M.stratum_seed(eseed, f"gate|{stream}", k)).astype(float)
                  for k, g in gs.items()}
            diff_num = np.zeros(B)
            diff_den = np.zeros(B)
            pn = pd_ = 0.0
            for k, g in gs.items():
                dlt = g["keep"][fam1] - g["none"]
                ok = ~np.isnan(dlt)
                diff_num += Ws[k] @ np.where(ok, dlt, 0.0)
                diff_den += Ws[k] @ ok.astype(float)
                pn += float(np.nansum(dlt))
                pd_ += float(ok.sum())
            with np.errstate(invalid="ignore", divide="ignore"):
                ds = diff_num / diff_den
            gain = pn / pd_ if pd_ else NAN
            lo, hi = (float(x) for x in np.nanpercentile(ds, [2.5, 97.5])) if pd_ else (NAN, NAN)
            row.update(memory_gain_pts=100 * gain, memory_gain_lo=100 * lo, memory_gain_hi=100 * hi,
                       probe_tasks=int(sum(g["tasks"] for g in gs.values())))
            # 2) home Cw per family, all probe tasks, 95 % interval
            best = []
            for fam in st.scores.families:
                num = np.zeros(B)
                den = np.zeros(B)
                pnum = pden = 0.0
                for k, g in gs.items():
                    part = np.nan_to_num(g["conc"][fam], nan=0.0)
                    num += Ws[k] @ part[:, 0]
                    den += Ws[k] @ part[:, 1]
                    pnum += part[:, 0].sum()
                    pden += part[:, 1].sum()
                with np.errstate(invalid="ignore", divide="ignore"):
                    cs = np.where(den > 0, num / np.where(den > 0, den, 1.0), NAN)
                cw = pnum / pden if pden > 0 else NAN
                clo, chi = (float(x) for x in np.nanpercentile(cs, [2.5, 97.5])) if pden > 0 else (NAN, NAN)
                row[f"home_cw_{fam}"], row[f"home_cw_{fam}_lo"], row[f"home_cw_{fam}_hi"] = cw, clo, chi
                if fam in USEFUL_FAMILIES and cw >= 0.58 and clo > 0.5:
                    best.append(fam)
            row["gate2_families"] = ",".join(best)
            row["gate2_family"] = next((f for f in HEADLINE_ORDER if f in best), "")
            row["headline_rule_family"] = row["gate2_family"]
            # 3) repeat disagreement (settings check): this model, and pooled over the models
            cb = sum(g["cells_both"] for g in gs.values())
            row["repeat_disagreement"] = sum(g["cells_differ"] for g in gs.values()) / cb if cb else NAN
            row["repeat_disagreement_all_models"] = dis_all
            # 4) items with 5+ visits; probe tasks whose candidates differ
            visits5 = []
            for k in gs:
                sp = st.bank_dir(m, stream, k) / "build_summary.json"
                if sp.exists():
                    visits5.append(json.loads(sp.read_text(encoding="utf-8"))["items_with_5plus_visits"])
            judged = sum(g["tasks_judged"] for g in gs.values())
            row["differing_task_share"] = sum(g["tasks_differ"] for g in gs.values()) / judged if judged else NAN
            row["items_5plus_visits"] = float(np.mean(visits5)) if visits5 else NAN
            # 5) cost per 1,000 paid calls, every call of the study
            row["usd_per_1000_measured"] = meas
            row["usd_per_1000_estimated"] = est
            row["pass_1"] = bool(row["memory_gain_pts"] >= 3 and row["memory_gain_lo"] > 0)
            row["pass_2"] = bool(best)
            row["pass_3"] = bool(not (dis_all > 0.40))
            row["pass_4"] = bool(row["items_5plus_visits"] >= 150 and row["differing_task_share"] >= 0.30)
            row["pass_5"] = pass5
            out.append(row)
    return out


def gate_lines(g: dict) -> list:
    """The five gate lines of one (model, stream), PASS / FAIL each (Part 9.3)."""
    fam2 = g.get("gate2_families") or "none"
    best_fam = max(USEFUL_FAMILIES, key=lambda f: _num(g.get(f"home_cw_{f}", NAN)) if f"home_cw_{f}" in g else -1)
    return [
        f"1. {'PASS' if g['pass_1'] else 'FAIL'}: memory helps: FS_keep - FS_none at home ({g.get('gate1_family')}, "
        f"all {g.get('probe_tasks', '?')} probe tasks) {_num(g['memory_gain_pts']):+.1f} points "
        f"[{_num(g['memory_gain_lo']):+.1f}, {_num(g['memory_gain_hi']):+.1f}] (needs >= 3 with the interval above 0).",
        f"2. {'PASS' if g['pass_2'] else 'FAIL'}: scores valid at home: best usefulness family `{best_fam}` Cw "
        f"{_c(_num(g.get(f'home_cw_{best_fam}')))} [{_c(_num(g.get(f'home_cw_{best_fam}_lo')))}, "
        f"{_c(_num(g.get(f'home_cw_{best_fam}_hi')))}]; families that pass: {fam2} (needs >= 0.58 with lower end > 0.5).",
        f"3. {'PASS' if g['pass_3'] else 'FAIL'}: repeats agree: home cells whose repeats 1 and 2 differ "
        f"{_pct(_num(g['repeat_disagreement_all_models']))} % over all models "
        f"({_pct(_num(g['repeat_disagreement']))} % for this model) (fails only above 40 %).",
        f"4. {'PASS' if g['pass_4'] else 'FAIL'}: enough visits and spread: items with 5+ visits "
        f"{_c(_num(g['items_5plus_visits']), 0)} (needs >= 150); probe tasks whose candidates differ "
        f"{_pct(_num(g['differing_task_share']))} % (needs >= 30 %).",
        f"5. {'PASS' if g['pass_5'] else 'FAIL'}: cost as estimated: USD per 1,000 paid calls, all calls, measured "
        f"{_c(_num(g['usd_per_1000_measured']), 3)} vs estimated {_c(_num(g['usd_per_1000_estimated']), 3)} "
        f"(needs at most 2x the estimate).",
    ]


# ---------------------------------------------------------------------------
# Second bank, realism check, second wording
# ---------------------------------------------------------------------------


def repeatability_rows(st: Study) -> list:
    """Score repeatability: the second bank (same content, other exploration seed, fresh
    repeats) against the first, per family: rank correlation over the items, and how often
    the two banks order a pair of probe candidates the same way."""
    rows = []
    for m in st.build.second_bank_models:
        for stream in st.streams:
            for seed in st.seeds:
                b1 = load_bankset(st, m, stream, seed, 1)
                b2 = load_bankset(st, m, stream, seed, 2)
                O = load_owner(st, m, stream, seed)
                _, evals = st.calib_eval(stream, seed)
                cands = {t: [i for i, _ in O["cands"].get(t, [])] for t in evals}
                home = restrict(load_cell(st, m, m, stream, seed)["reg"], evals)
                for fam in st.scores.families:
                    (bank1, rule), (bank2, _) = b1[fam], b2[fam]
                    s1, s2 = rule.scores(bank1), rule.scores(bank2)
                    items = sorted(set(s1) & set(s2))
                    rows.append({"model": m, "stream": stream, "seed": seed, "family": fam,
                                 "spearman": spearman([s1[i] for i in items], [s2[i] for i in items]),
                                 "pair_agreement": M.concordance(s2, {t: {i: s1[i] for i in c} for t, c in cands.items()},
                                                                 cands).value,
                                 "home_validity_bank1": conc(s1, home, cands).value,
                                 "home_validity_bank2": conc(s2, home, cands).value})
    return rows


def subset_rows(st: Study) -> tuple:
    """Realism check: exact Shapley values from every subset of the 4 candidates, compared
    with the one-item-at-a-time results, and validity recomputed against Shapley values."""
    rows, shap_rows = [], []
    for owner, reader in st.probe.subset_cells:
        for stream in st.streams:
            for seed in st.seeds:
                sp = st.subset_dir(owner, reader, stream, seed) / "subsets.jsonl"
                if not sp.exists():
                    continue
                O = load_owner(st, owner, stream, seed)
                cell = load_cell(st, owner, reader, stream, seed)
                groups: dict = defaultdict(dict)
                for r in read_jsonl(sp):
                    groups[r["task_id"]][frozenset(r["items"])] = float(r["correct"])
                single, shap = {}, {}
                for t, v in groups.items():
                    items = [i for i, _ in O["cands"][t]]
                    if t not in cell["none"] or any(i not in cell["reg"].get(t, {}) for i in items):
                        continue
                    v[frozenset()] = float(np.mean(cell["none"][t]))
                    for i in items:
                        v[frozenset([i])] = float(np.mean(cell["reg"][t][i]))
                    phi = M.shapley_values(v, items)
                    single[t] = {i: v[frozenset([i])] for i in items}
                    shap[t] = phi
                    for i in items:
                        shap_rows.append({"owner": owner, "reader": reader, "stream": stream, "seed": seed,
                                          "task_id": t, "item_id": i, "single": single[t][i], "shapley": phi[i]})
                cs = {t: list(r) for t, r in single.items()}
                base = {"owner": owner, "reader": reader, "kind": maker_kind(st, owner, reader), "stream": stream,
                        "seed": seed, "tasks": len(single)}
                agree_w = M.concordance(single, shap, cs, weighted=True).value if cs else NAN
                agree_u = M.concordance(single, shap, cs).value if cs else NAN
                for fam in st.scores.families:
                    bank, rule = O["banks"][fam]
                    raw = rule.scores(bank)
                    rows.append({**base, "family": fam, "single_vs_shapley": agree_w, "single_vs_shapley_u": agree_u,
                                 "validity_single": M.concordance(raw, single, cs, weighted=True).value if cs else NAN,
                                 "validity_shapley": M.concordance(raw, shap, cs, weighted=True).value if cs else NAN})
    return rows, shap_rows


def _variant_parts(st: Study) -> dict:
    """The second wording (8.3.3) as per-task concordance parts, on the variant tasks.

    {(owner, reader, stream, seed): {"tasks": n, "agree": agreement(v1, variant),
    "parts": {family: {"v1": (n, 2), "variant": (n, 2)}}}}: numerator and weight of Cw per
    task (Part 2.2) of the OWNER's ranking scores x against the reader's results under the
    first wording (the ordinary probe table, repeats 1-2) and under the second wording,
    candidates in the owner's retrieval order. Home cells (owner = reader) give C_home under
    each wording, so the drop D exists under both."""
    out: dict = {}
    if not st.variants.enabled:
        return out
    n_c = st.probe.candidates
    owners: dict = {}
    for owner, reader in st.variants.cells:
        for stream in st.streams:
            for seed in st.seeds:
                vp = st.variant_dir(owner, reader, stream, seed) / "probe.jsonl"
                if not vp.exists():
                    continue
                ids = st.variant_task_ids(stream, seed)
                v2, _, _ = tables_from_rows(read_jsonl(vp))
                v1 = restrict(load_cell(st, owner, reader, stream, seed)["reg"], ids)
                v2 = restrict(v2, ids)
                okey = (owner, stream, seed)
                if okey not in owners:
                    O = load_owner(st, owner, stream, seed)
                    items = sorted(next(iter(O["banks"].values()))[0], key=str)
                    index = {i: n for n, i in enumerate(items)}
                    fams = {f: X.Fam(f, rule, bank, items, O["r0"]) for f, (bank, rule) in O["banks"].items()}
                    owners[okey] = (O, index, fams)
                O, index, fams = owners[okey]
                cand, rel, y1 = table_arrays(v1, ids, O["cands"], index, n_c)
                _, _, y2 = table_arrays(v2, ids, O["cands"], index, n_c)
                T1, T2 = X.Table(cand, rel, y1), X.Table(cand, rel, y2)
                parts = {}
                for f, F in fams.items():
                    Sx = F.x[cand]
                    got = {}
                    for name, T in (("v1", T1), ("variant", T2)):
                        num, den, _, _ = X.conc_parts(T, Sx)
                        got[name] = np.nan_to_num(np.stack([num, den], axis=1), nan=0.0)
                    parts[f] = got
                out[(owner, reader, stream, seed)] = {"tasks": len(ids), "agree": agreement(v1, v2), "parts": parts}
    return out


def _cw(sums: np.ndarray) -> float:
    return float(sums[0] / sums[1]) if sums[1] > 0 else NAN


def variant_rows(st: Study, vparts: dict | None = None) -> tuple:
    """(variants.csv rows, variants_retained.csv rows): the second wording (8.3.3).

    variants.csv, one row per cell, stream, order and family (the first columns as before):
    validity_v1 / validity_variant = Cw of the owner's scores against the reader's results
    under each wording on the same variant tasks; for a swap cell also the owner's home Cw
    under each wording (home_v1, home_variant), the drop D = home - swap and the retained
    ratio R with the 4-standard-error rule of 2.4 (per order: descriptive), under each
    wording side by side.

    variants_retained.csv, one row per swap, level (a stream with its orders pooled by
    summed numerators and weights, or `all` = each C averaged over the streams, 2.4) and
    family: C_home, C_swap, D with its 95 % interval and R with its rule under each wording,
    and the difference of the drops (variant - v1) with its interval. Bootstrap: the variant
    tasks resampled within each (stream, order), the same draws for every cell and both
    wordings (4.1)."""
    vparts = _variant_parts(st) if vparts is None else vparts
    rows, pooled = [], []
    if not vparts:
        return rows, pooled
    B = st.evaluate.bootstrap
    eseed = st.evaluate.seed
    min_z = _setting(st, "ratio_min_z", RATIO_MIN_Z)
    W_by: dict = {}

    def counts(stream, seed, n):
        key = (stream, seed, n)
        if key not in W_by:
            W_by[key] = M.bootstrap_counts(n, B, M.stratum_seed(eseed, f"variant|{stream}", seed)).astype(float)
        return W_by[key]

    # per order: point sums and bootstrap sums of every (cell, family, wording)
    point: dict = {}
    boot: dict = {}
    for (o, r, stream, seed), c in vparts.items():
        W = counts(stream, seed, c["tasks"])
        for f, got in c["parts"].items():
            for w, arr in got.items():
                point[(o, r, stream, seed, f, w)] = arr.sum(0)
                boot[(o, r, stream, seed, f, w)] = W @ arr

    def samples(b: np.ndarray) -> np.ndarray:
        return _ratio_samples(b)

    for (o, r, stream, seed), c in vparts.items():
        for f in c["parts"]:
            row = {"owner": o, "reader": r, "kind": maker_kind(st, o, r), "stream": stream, "seed": seed, "family": f,
                   "variant": st.variants.variant, "tasks": c["tasks"],
                   "validity_v1": _cw(point[(o, r, stream, seed, f, "v1")]),
                   "validity_variant": _cw(point[(o, r, stream, seed, f, "variant")]),
                   "outcome_agreement": c["agree"]["agree"], "outcome_kappa": c["agree"]["kappa"],
                   "weight_v1": float(point[(o, r, stream, seed, f, "v1")][1]),
                   "weight_variant": float(point[(o, r, stream, seed, f, "variant")][1])}
            hk = (o, o, stream, seed, f)
            if o != r and hk + ("v1",) in point:
                for w in ("v1", "variant"):
                    ch, cs = _cw(point[hk + (w,)]), _cw(point[(o, r, stream, seed, f, w)])
                    rr = M.ratio_rule(ch, cs, samples(boot[hk + (w,)]), samples(boot[(o, r, stream, seed, f, w)]),
                                      min_z=min_z)
                    row.update({f"home_{w}": ch, f"drop_{w}": ch - cs, f"ratio_{w}": rr["ratio"],
                                f"ratio_status_{w}": rr["status"], f"home_se_{w}": rr["se_home"]})
            rows.append(row)

    # pooled over the orders of a stream, and over the streams
    cells = list(dict.fromkeys((o, r) for (o, r, _s, _k) in vparts if o != r))
    fams = list(dict.fromkeys(f for c in vparts.values() for f in c["parts"]))
    streams = [s for s in st.streams if any(k[2] == s for k in vparts)]

    def level_c(o_, r_, f, w, s_list):
        """(point, samples) of Cw at one level: per stream pooled over orders; then the mean
        over the streams in s_list."""
        pts, sms = [], []
        for s in s_list:
            keys = [(o_, r_, s, k, f, w) for k in st.seeds if (o_, r_, s, k, f, w) in point]
            if not keys:
                continue
            pts.append(_cw(sum(point[k] for k in keys)))
            sms.append(samples(sum(boot[k] for k in keys)))
        if not pts:
            return NAN, np.full(B, NAN)
        return float(np.mean(pts)), np.mean(sms, axis=0)

    for (o, r) in cells:
        for f in fams:
            for lvl, s_list in [(s, [s]) for s in streams] + [("all", streams)]:
                row = {"owner": o, "reader": r, "kind": maker_kind(st, o, r), "stream": lvl, "family": f,
                       "variant": st.variants.variant, "bootstrap": B}
                drops = {}
                for w in ("v1", "variant"):
                    ch, chs = level_c(o, o, f, w, s_list)
                    cs, css = level_c(o, r, f, w, s_list)
                    ds = chs - css
                    okd = ds[~np.isnan(ds)]
                    lo, hi = (float(x) for x in np.percentile(okd, [2.5, 97.5])) if len(okd) else (NAN, NAN)
                    rr = M.ratio_rule(ch, cs, chs, css, min_z=min_z)
                    drops[w] = (ch - cs, ds)
                    row.update({f"c_home_{w}": ch, f"c_swap_{w}": cs, f"drop_{w}": ch - cs, f"drop_{w}_lo": lo,
                                f"drop_{w}_hi": hi, f"ratio_{w}": rr["ratio"], f"ratio_{w}_lo": rr["lo"],
                                f"ratio_{w}_hi": rr["hi"], f"ratio_status_{w}": rr["status"],
                                f"se_home_{w}": rr["se_home"]})
                dd = drops["variant"][1] - drops["v1"][1]
                okd = dd[~np.isnan(dd)]
                lo, hi = (float(x) for x in np.percentile(okd, [2.5, 97.5])) if len(okd) else (NAN, NAN)
                row.update(drop_difference=drops["variant"][0] - drops["v1"][0], drop_difference_lo=lo,
                           drop_difference_hi=hi)
                pooled.append(row)
    return rows, pooled


# ---------------------------------------------------------------------------
# The call log: costs, token-limit hits, refusals, BIRD answers to grade again
# ---------------------------------------------------------------------------


def _unparseable(stream: str, answer) -> bool:
    """An answer with no parseable diagnosis (DDXPlus) or no SQL (BIRD) (Part 1.4, item 3)."""
    from msr import grade as G
    if stream == "ddxplus":
        return G.parse_ddxplus(answer) == G.NOTINLABEL
    if stream == "bird":
        return not (answer or "").strip() or G.parse_sql(answer, faithful=False).strip().upper() in ("SELECT", "")
    return False


def scan_call_log(st: Study, bird_regrade: bool = False) -> dict:
    """One pass over runs/<study>/calls.jsonl: costs per model and stage (with token-limit
    hits, API-level refusals and unparseable answers), the ids of calls that hit the limit
    or were refused (Part 1.4), and, when asked, the BIRD answers whose parse differs
    between the two SQL parsers (Part 1.5): only those can change grade.
    A call served from the answer cache is counted as a call but costs nothing."""
    from msr import grade as G
    path = st.dir / "calls.jsonl"
    agg: dict = defaultdict(lambda: {"calls": 0, "cached_calls": 0, "fresh_calls": 0, "tokens_in": 0,
                                     "tokens_out": 0, "usd": 0.0, "hit_limit": 0, "refusals": 0, "unparseable": 0})
    flagged = {"limit": [], "refusal": []}
    bird: dict = {}
    if path.exists():
        with open(path, encoding="utf-8") as f:
            for line in f:
                if not line.strip():
                    continue
                r = json.loads(line)
                meta = r.get("meta") or {}
                stage = meta.get("stage", "other")
                a = agg[(r["model"], stage)]
                a["calls"] += 1
                stop = r.get("stop_reason")
                if stop in LIMIT_STOPS:
                    a["hit_limit"] += 1
                    flagged["limit"].append(r["call_id"])
                elif stop in REFUSAL_STOPS:
                    a["refusals"] += 1
                    flagged["refusal"].append(r["call_id"])
                stream = meta.get("stream")
                if stage in ANSWER_STAGES and stream in ("ddxplus", "bird") and _unparseable(stream, r.get("answer")):
                    a["unparseable"] += 1
                if r.get("cached"):
                    a["cached_calls"] += 1
                else:
                    a["fresh_calls"] += 1
                    a["tokens_in"] += int(r.get("tokens_in") or 0)
                    a["tokens_out"] += int(r.get("tokens_out") or 0)
                    a["usd"] += float(r.get("cost_usd") or 0.0)
                if bird_regrade and stream == "bird" and stage in ("build0", "build", "probe", "probe0", "probe_extra"):
                    ans = r.get("answer")
                    if G.parse_sql(ans, faithful=True) != G.parse_sql(ans, faithful=False):
                        bird[r["call_id"]] = (meta.get("task_id"), ans)
    costs = [{"model": m, "stage": s, **v, "usd": round(v["usd"], 6)} for (m, s), v in sorted(agg.items())]
    return {"costs": costs, "flagged": flagged, "bird": bird}


def costs_from_log(st: Study) -> list:
    """Calls, tokens and dollars per model and stage, read from runs/<study>/calls.jsonl."""
    return scan_call_log(st)["costs"]


# ---------------------------------------------------------------------------
# Sensitivity analyses (Parts 1.4-1.6, 8.2.14)
# ---------------------------------------------------------------------------


def bird_regrade_map(st: Study, candidates: dict) -> dict:
    """{call_id: correct} under the OTHER SQL parser (StreamBench's original when the study
    grades with the corrected one), for the answers whose parse differs. Offline: the stored
    raw answers are graded again by running their SQL read-only; no model is called."""
    from msr import data as D
    from msr import grade as G
    if not candidates:
        return {}
    tasks = D.task_index("bird")
    faithful = not st.bird_faithful
    return {cid: bool(G.grade_detail("bird", tasks[tid], ans, faithful=faithful)["correct"])
            for cid, (tid, ans) in candidates.items() if tid in tasks}


def replay_banks(st: Study, regrade: dict, out_dir: Path, streams=("bird",)) -> int:
    """The score-phase updates replayed from the logged episodes with the regraded outcomes
    (the same items shown, as logged; Part 1.5): every family of every model's first bank,
    saved under out_dir/<model>/<stream>/seed<k>/, with r0 from the regraded no-memory run.
    Returns the number of episodes whose grade changed."""
    from msr.build import make_rules, update_families
    changed = 0
    for stream in streams:
        for m in st.models:
            for seed in st.seeds:
                src = st.bank_dir(m, stream, seed)
                if not (src / "episodes.jsonl").exists():
                    continue
                b0 = read_jsonl(src / "build0.jsonl") if (src / "build0.jsonl").exists() else []
                base = {r["task_id"]: float(regrade.get(r["call_id"], r["correct"])) for r in b0}
                rules = make_rules(st)
                saved = {f: S.load_bank(src / f"bank_{f}.json")[0] for f in rules}
                banks = {f: {i: rules[f].new_record() for i in saved[f]} for f in rules}
                for e in read_jsonl(src / "episodes.jsonl"):
                    ok = bool(regrade.get(e["call_id"], e["correct"]))
                    changed += int(ok != bool(e["correct"]))
                    for iid in e["shown"]:
                        update_families(rules, banks, iid, ok, (e.get("tags") or {}).get(iid),
                                        base.get(e["task_id"]), m)
                d = out_dir / m / stream / f"seed{seed}"
                for f, bank in banks.items():
                    S.save_bank(d / f"bank_{f}.json", bank, rules[f], note=f"replayed with regraded outcomes ({f})")
                r0 = float(np.mean(list(base.values()))) if base else 0.5
                write_json(d / "r0.json", {"r0": r0})
    return changed


# ---------------------------------------------------------------------------
# Writing tidy files
# ---------------------------------------------------------------------------

#: results/SCHEMA.md, written by every run of the stage.
SCHEMA_MD = r'''# results/: files and columns (written by msr/evaluate.py, Stage C)

Every number follows prediction/PREREGISTRATION.md; the part is named where it helps. A
"cell" is one (owner, reader, stream, order); "order" is the stream order, the `seed`
column. Missing values are empty in CSV files and NaN in npz files. Columns are only ever
added, never removed or renamed; read them by name.

## validity.csv: one row per cell and family

| column | meaning |
|---|---|
| owner, reader, kind, stream, seed, family | the cell; kind = home, same_maker or cross_maker (swap groups are named by maker; "family" is the score family) |
| home, swap, floor | weighted concordance Cw (2.2) of the owner's ranking score x on the evaluation tasks of this order: with the owner's own results (repeats 1-2), with the reader's results (for a home cell: the extra repeats 3-4), and with the extra home repeats (the self-swap) |
| home_u, swap_u, floor_u | the same, unweighted (Harrell's C, 8.2.7) |
| home_pairs, swap_pairs | informative pairs (outcomes differ) |
| home_weight, swap_weight | the sum of pair weights: Cw pooled over orders = sum(Cw x weight) / sum(weight) |
| drop, floor_drop | home - swap; home - floor (this order) |
| ratio, ratio_status, home_se | retained ratio (swap - 0.5) / (home - 0.5) for this order, with the 4-standard-error rule of 2.4 (home_se = SD of C_home over the bootstrap draws of this order); status `defined`, `undefined: home signal too weak` or `defined; interval unbounded`. Per-order ratios are descriptive only; the pooled ones are in retained.csv |
| ceiling_home, ceiling_swap, ceiling_home_extra | split-half noise references (2.5): repeat 1 vs repeat 2 of the owner's / reader's results; repeats 1-2 vs 3-4 at home. Not upper bounds |
| top1_home, top1_swap, top2_home, top2_swap | top-1 / top-2 agreement (2.9) on tasks with an informative pair; `_chance` columns: their chance values |
| tau_b_home, tau_b_swap, tau_b_floor | Kendall's tau-b between x and the outcomes, pairs within tasks pooled over tasks (8.2.7) |
| tie_share_home/_swap/_floor | share of informative pairs tied in x |
| home_noties, swap_noties, floor_noties | Cw over the pairs not tied in x |
| home_visits_low/_mid/_high (and swap_, floor_) | Cw over the pairs whose less-visited item is in that third of the bank's visit counts (cut at the 1/3 and 2/3 percentiles of the score-phase visits of all items of the bank) |
| home_bank2, swap_bank2, floor_bank2 | Cw with the SECOND bank's scores (same items, other exploration seed), where a second bank exists |
| home_net, swap_net, floor_net | counter families (beta_grade, tags_self): Cw with x = helpful - harmful (the sensitivity ranking of 0.4 and 8.2.14) |
| home_shuffled, swap_shuffled | mean Cw over the permutations of the content-only control (`shuffled`, 2.6) |
| eval_tasks, valid_tasks, dropped_tasks | evaluation tasks of the order; those kept and dropped by the missing-cell rule (1.6) |

## retained.csv: one row per (owner, reader), stream level and family

`stream` is a stream (Cw pooled over its orders by summing numerators and weights, 2.2) or
`all` (each C averaged over the streams, 2.4). Bootstrap (the secondary, task-only interval):
task IDS resampled per stream with all their appearances in every order (a task in two orders is
one cluster; `msr.metrics.task_cluster_counts`), the same draws for every cell (4.1), `bootstrap`
draws. The primary two-way (task x item) intervals are in runs/<study>/analysis/.

| column | meaning |
|---|---|
| c_home, c_swap, se_home | C_home, C_swap (for a home cell: C_fresh) and SD of C_home over the draws |
| drop, drop_lo, drop_hi, p_drop | D = C_home - C_swap, its 95 % interval, p_upper of 4.2 (unadjusted) |
| self_drop, self_drop_hi | the owner's self-swap drop Dself and U_self, the upper end of its 95 % interval (4.4) |
| drop_beyond_floor | True when the unadjusted drop test rejects at 0.05 AND D > U_self (4.4) |
| ratio, ratio_lo, ratio_hi, ratio_status, ratio_bad_draws | R with the 4-SE rule (2.4); the interval is unbounded (-inf, inf) when more than 0.5 % of draws have C_home - 0.5 <= 0 (ratio_bad_draws = that share) |
| ni_stat, p_ni | N = 0.75 (C_home - 0.5) - (C_swap - 0.5) and p_lower(N) (secondary since the round-1 revision); p_ni only where R is defined |
| v_home, v_swap | mean signed validity V per valid task (V = 2 x numerator - weight of Cw; `msr.metrics`), summed over the streams for `all` |
| theta, theta_lo_task, theta_hi_task, se_v_home_task | the HEADLINE retained share theta = v_swap / v_home (2.4 as revised), always written, with its task-only percentile interval and SE of v_home (secondary; the primary interval is two-way, in the analysis) |
| z_cal, theta_status_calibration | theta's HEADLINE reporting flag (2.4 as revised, 24 Nov 2026): the owner's signed validity on its CALIBRATION tasks (no estimate uses them), z = sum / (sd sqrt(n)); `defined` when z >= 2 |
| theta_status | the former same-task rule (V_home >= 4 SE on the same tasks), SECONDARY: it selects on the estimate's own noise and decides nothing |

## arms.csv: one row per cell, family and arm

Arms: `none`, `relevance`, `split_half` (pick on one repeat, score on the other: a one-repeat
reference, NOT an upper bound; called `oracle` before the round-1 revision), `ceiling` (the best
candidate by the mean of both repeats, scored on the same repeats: an in-sample ceiling) (family
`-`); `keep`, `wipe`, `constant` (every item at the reader's no-memory success on the calibration
tasks; ranks like wipe), `fixed_<lambda>`, `shuffled`, `own`, and `<arm>_<k>` for powerprior,
powerprior_flat (an extra comparison, Beta(1, 1) base, not pre-registered), recal, retest, audit,
pooled, fresh. k runs over
evaluate.k_values; a k larger than the calibration pool (calibration tasks x candidates)
is skipped with a one-line note (printed, and in plan.json's notes).

| column | meaning |
|---|---|
| value, regret, n_tasks | first-shown success and regret (2.7), mean over the valid evaluation tasks of the order; drawn arms: per-task means over the draws (4.5) |
| no_memory | the reader's no-memory success on the same tasks |
| log_score, brier | held-out log and Brier scores (2.8), p clipped to evaluate.prob_clip |
| log_score_lc, brier_lc | the same after the level correction (2.8 as revised): the arm's p shifted by one logit constant so that its mean over the (calibration task, candidate) cells equals the reader's no-memory success on the calibration tasks |
| log_score_lcw, brier_lcw | base-rate sensitivity (revision 2, R6 W7): the same shift with the target set to the reader's mean success WITH an item on those (calibration task, candidate) cells (the cells recal_k draws from), each cell the mean of its repeats; the gap to log_score_lc is the average memory effect's share of the level |
| value_w0.25, value_w0.75, value_wz | first-shown success at score weight 0.25 / 0.75 and under the z-scored mix (8.3.1): 0.5 z(relevance) + 0.5 z(u), relevance and u both z-scored within each task's candidates (population sd; a constant gives 0) |
| draws, draw_sd, value_p05, value_p95, log_p05, log_p95 | number of draws (or permutations), SD and 5th/95th percentiles over draws of the pooled value and log score ("what a single swap day may look like", 4.5) |
| lam, lam_sd, lam_median, lam_q25, lam_q75 | powerprior: the chosen weight over draws |
| level, level_sd, slope, slope_sd, slope_q25, slope_q75 | recal: the fitted a and b over draws (8.2.10); x' is centred on the bank mean and divided by the population sd over the items with at least one visit (2.6); when that sd is 0 only the level is fitted and the slope is empty (NaN) |
| keep_share | audit: share of draws that kept the old scores |
| checks | fresh checks per draw |
| dropped_tasks | tasks dropped in this cell by the missing-cell rule |

## agreement.csv: one row per cell (calibration tasks only, 2.11)

cells, agree, chance, kappa, rate_a (owner at home), rate_b (reader; for a home cell the
extra repeats), and the counts that add over orders: same, pairs, succ_a, n_a, succ_b, n_b
(`msr.metrics.kappa_from_counts` pools them).

## costs.csv: one row per model and stage, from calls.jsonl

calls, cached_calls, fresh_calls, tokens_in, tokens_out, usd, hit_limit (stop reason
max_tokens / length), refusals (refusal / content_filter), unparseable (no parseable
diagnosis or SQL) (1.4).

## gate.json: one entry per (model, stream), the pilot gate (9.3)

memory_gain_pts/_lo/_hi (gate 1, FS_keep - FS_none at home over ALL probe tasks, gate1_family,
probe_tasks), home_cw_<family>/_lo/_hi (gate 2, all probe tasks), gate2_families, gate2_family
and headline_rule_family (the first passing family in the order of 9.2), repeat_disagreement
(this model) and repeat_disagreement_all_models (gate 3), items_5plus_visits and
differing_task_share (gate 4), usd_per_1000_measured / _estimated (gate 5, all calls), pass_1
... pass_5, old_model.

## per_task/<owner>__<reader>__<stream>__seed<k>.npz: per evaluation task of the order

`tasks` (E,), `valid` (E,) the missing-cell rule. NaN marks a dropped task (or, for top-k, a
task without an informative pair). Keys `<family>|...`:

- `conc_home`, `conc_swap`, `conc_floor` (E, 2): numerator and weight of Cw per task; `_u`:
  unweighted; `_shuffled` (home, swap): mean numerator over the permutations and the weight;
  `_noties`, `_visits_low/_mid/_high`, `_bank2`, `_net` (counters): as in validity.csv.
- `tau_home`, `tau_swap`, `tau_floor` (E, 4): concordant, discordant, tied in x only, tied in
  outcome only (`msr.engine.tau_b` turns summed parts into tau-b).
- `ties_home/_swap/_floor` (E, 2): informative pairs tied in x, informative pairs.
- `top1_home`, `top1_swap`, `top2_home`, `top2_swap` (E,): hit 1/0; `_chance`: chance value.
- `<family>|<arm>|value`, `|regret`, `|log`, `|brier`, `|value_w0.25`, `|value_w0.75`,
  `|value_wz` (E,): the arm's per-task values (drawn arms: means over the draws).
- `<family>|<arm>|log_lc`, `|brier_lc` (E,): the level-corrected log and Brier scores.
- `<family>|<arm>|log_lcw`, `|brier_lcw` (E,): the same with the with-item level target (base-rate
  sensitivity of PC3/PC4, revision 2).
- `-|none|value`, `-|relevance|value`, `-|split_half|value`, `-|ceiling|value` and their `|regret`.

## cells/<owner>__<reader>__<stream>__seed<k>.npz: the raw cells, every probe task

| array | meaning |
|---|---|
| tasks (T,), is_calib (T,) | every probe task of the order; calibration tasks marked |
| items (T, C) | item ids of the owner's candidates in retrieval order ("" = none) |
| relevance, visits, visit_third (T, C) | raw relevance; score-phase visits; third 0/1/2 as above |
| shows, prob_sum, ips_num, ips_den (T, C) | over the build's score phase: shows, the sum of the logged selection probabilities, sum(y / pi) and sum(1 / pi) (the self-normalised IPS score is ips_num / ips_den, 8.3.5) |
| score_<family> (T, C) | the owner's ranking score x; `_net` for counters (helpful - harmful); `_bank2` with the second bank |
| y (T, C, R) | the reader's results per repeat (1 / 0 / NaN missing) |
| y_home (T, C, R) | the owner's own results per repeat |
| y_extra (T, C, R2) | home cells only: the extra home repeats 3-4 |
| none (T, Rz) | the reader's no-memory results per repeat |

## draws/<cell>.jsonl: one line per random draw of a drawn arm

family, arm (`<arm>_<k>`), k, draw, then lam (powerprior), level and slope (recal) or
decision (audit), and value and log (the draw's pooled first-shown success and log score).

## Other files

- repeatability.csv: second bank against the first (spearman, pair_agreement,
  home_validity_bank1, home_validity_bank2) per model, stream, seed, family.
- subsets.csv, shapley.csv: the realism check (8.3.2).
- variants.csv: the second wording (8.3.3), one row per cell, stream, order and family, on
  the first `variants.tasks` evaluation tasks of the order. validity_v1 / validity_variant:
  Cw of the owner's scores against the reader's results under each wording; weight_v1 /
  weight_variant: the sums of pair weights (Cw over orders = sum(Cw x weight) / sum(weight));
  outcome_agreement, outcome_kappa: the reader's results under the two wordings compared.
  Swap cells also carry, side by side for `v1` and `variant`: home_<w> (the owner's home Cw
  under that wording on the same tasks), drop_<w> = home_<w> - validity_<w>, ratio_<w>,
  ratio_status_<w> and home_se_<w> (the retained ratio with the 4-standard-error rule of
  2.4; per order, descriptive). The home cells of every model in `variants.pairs` are run
  under the second wording, so D exists under it; the raw results are kept in
  runs/<study>/variants/<variant>/.
- variants_retained.csv: per swap of `variants.pairs`, level (`stream` = a stream with its
  orders pooled, or `all` = each C averaged over the streams) and family, side by side for
  `v1` and `variant`: c_home_<w>, c_swap_<w>, drop_<w> with drop_<w>_lo / _hi (95 %),
  ratio_<w> with ratio_<w>_lo / _hi, ratio_status_<w> and se_home_<w> (2.4); and
  drop_difference = drop_variant - drop_v1 with its 95 % interval. Bootstrap: the variant
  tasks resampled within each (stream, order), the same draws for both wordings
  (`bootstrap` draws).
- online.csv, online_curves.csv: written by Stage D (msr/online.py).
- sensitivity.json and sensitivity/<name>/: limit_refusal_missing (token-limit and refused
  cells treated as missing), *_available_case (when a cell drops more than 2 % of its tasks),
  bird_original (BIRD graded with StreamBench's original parser, offline: regrade.json, the
  replayed banks/, and the same CSV and per_task files). An analysis that changes no input is
  recorded as identical to the primary one and not re-run.
- model_identity.csv: one row per model with the settings that are part of its identity (route,
  host, precision, reasoning, temperature, top_p, top_k or "provider default", answer limit) and
  the model strings the API returned (round-1 revision, S6).
- inputs.json: fingerprint of the inputs and the seconds Stage C took. SUMMARY.md: the summary.
'''



def _fmt(v):
    if isinstance(v, (float, np.floating)):
        v = float(v)
        return "" if math.isnan(v) else (v if math.isinf(v) else round(v, 6))
    if isinstance(v, (np.integer,)):
        return int(v)
    if isinstance(v, (np.bool_,)):
        return bool(v)
    if v is None:
        return ""
    return v


def write_csv(path: Path, rows: list) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".part")
    cols: list = []
    for r in rows:
        for k in r:
            if k not in cols:
                cols.append(k)
    with open(tmp, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for r in rows:
            w.writerow({k: _fmt(r.get(k, "")) for k in cols})
    tmp.replace(path)


def read_csv(path: Path) -> list:
    if not path.exists():
        return []
    with open(path, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def _jsonable(obj):
    if isinstance(obj, dict):
        return {k: _jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_jsonable(v) for v in obj]
    if isinstance(obj, (np.floating, float)):
        v = float(obj)
        return None if math.isnan(v) else v
    if isinstance(obj, np.integer):
        return int(obj)
    if isinstance(obj, np.bool_):
        return bool(obj)
    return obj


# ---------------------------------------------------------------------------
# Stage runner
# ---------------------------------------------------------------------------


def inputs_fingerprint(st: Study) -> str:
    """A fingerprint of everything Stage C reads; if unchanged, the results are up to date."""
    parts = [json.dumps(st.raw, sort_keys=True, default=str), f"rules:{EVAL_RULES}"]
    for stream in st.streams:
        for seed in st.seeds:
            for m in st.models:
                for b in st.banks_of(m):
                    f = st.bank_dir(m, stream, seed, b) / "build_summary.json"
                    parts.append(f.read_text(encoding="utf-8") if f.exists() else "missing")
            dirs = [st.probe_dir(o, r, stream, seed) for o, r in st.cells]
            dirs += [st.subset_dir(o, r, stream, seed) for o, r in st.probe.subset_cells]
            if st.variants.enabled:
                dirs += [st.variant_dir(o, r, stream, seed) for o, r in st.variants.cells]
            for d in dirs:
                for name in ("probe.jsonl", "probe_extra.jsonl", "subsets.jsonl"):
                    f = d / name
                    parts.append(f"{d.name}/{name}:{f.stat().st_size if f.exists() else -1}")
    return L.sha256("\n".join(parts))


def up_to_date(st: Study) -> bool:
    f = st.results_dir / "inputs.json"
    if not f.exists() or not (st.results_dir / "SUMMARY.md").exists():
        return False
    try:
        return json.loads(f.read_text(encoding="utf-8")).get("fingerprint") == inputs_fingerprint(st)
    except ValueError:
        return False


def _collect(st: Study, jobs: list) -> dict:
    order = {}
    for n, (o, r) in enumerate(st.cells):
        order[(o, r)] = n
    cells = sorted((c for j in jobs for c in j["cells"]),
                   key=lambda c: (st.streams.index(c["key"][2]), st.seeds.index(c["key"][3]), order[c["key"][:2]]))
    validity = [r for c in cells for r in c["validity"]]
    arm_rows = [r for c in cells for r in c["arms"]]
    agree = [c["agreement"] for c in cells]
    worst = max((c["dropped"] / c["n_tasks"] for c in cells if c["n_tasks"]), default=0.0)
    return {"validity": validity, "arms": arm_rows, "agreement": agree, "worst_drop_share": worst,
            "dropped": sum(c["dropped"] for c in cells)}


def _write_variant(st: Study, variant: dict | None, jobs: list) -> dict:
    """validity.csv, arms.csv, agreement.csv and retained.csv of one analysis."""
    d = results_dir_for(st, variant)
    col = _collect(st, jobs)
    ret_rows, order_ratio = retained(st, jobs)
    for row in col["validity"]:
        rr = order_ratio.get((row["owner"], row["reader"], row["stream"], row["seed"], row["family"]))
        if rr is not None:
            row.update(ratio=rr["ratio"], ratio_status=rr["status"], home_se=rr["se_home"])
    write_csv(d / "validity.csv", col["validity"])
    write_csv(d / "arms.csv", col["arms"])
    write_csv(d / "agreement.csv", col["agreement"])
    write_csv(d / "retained.csv", ret_rows)
    col["retained"] = ret_rows
    return col


def model_identity_rows(st: Study) -> list:
    """results/model_identity.csv: one row per model with every setting that makes the model what it
    is, sampling included (round-1 revision, decision S6): provider and route, host and precision,
    thinking / reasoning setting, temperature, top_p, top_k (or "host default not sent" for a closed
    model, whose fixed default sampling applies), the answer limit, and the model strings that the
    API returned (from calls.jsonl, through runs/<run>/model_settings.json where present)."""
    settings = {}
    ms = st.dir / "model_settings.json"
    if ms.exists():
        try:
            settings = json.loads(ms.read_text(encoding="utf-8"))
        except ValueError:
            settings = {}
    returned: dict = defaultdict(set)
    log = st.dir / "calls.jsonl"
    if log.exists() and log.stat().st_size < 2_000_000_000:
        with open(log, encoding="utf-8") as f:
            for line in f:
                if '"model_id"' not in line:
                    continue
                try:
                    r = json.loads(line)
                except ValueError:
                    continue
                if r.get("model") in st.models and r.get("model_id"):
                    returned[r["model"]].add(str(r["model_id"]))
    rows = []
    for m in st.models:
        c = st.models_cfg["models"].get(m, {})
        eb = c.get("extra_body") or {}
        prov = eb.get("provider") or {}
        closed = c.get("provider") in ("anthropic", "openai")
        samp = {k: eb.get(k) for k in ("temperature", "top_p", "top_k", "min_p", "repetition_penalty") if k in eb}
        reasoning = (c.get("anthropic_thinking") or c.get("reasoning_effort") or eb.get("reasoning")
                     or eb.get("enable_thinking") if (c.get("anthropic_thinking") or c.get("reasoning_effort")
                                                      or "reasoning" in eb or "enable_thinking" in eb) else "none sent")
        sampling = ("provider default (no sampling value is accepted or sent)" if closed and not samp
                    else ", ".join(f"{k}={v}" for k, v in samp.items()) or "host default (nothing sent)")
        rows.append({"model": m, "maker": st.family(m), "provider": c.get("provider", ""),
                     "api_model": c.get("api_model", ""), "host": " ".join(map(str, prov.get("only") or [])),
                     "quantization": " ".join(map(str, prov.get("quantizations") or [])),
                     "fallbacks": prov.get("allow_fallbacks", ""), "reasoning": json.dumps(reasoning) if
                     isinstance(reasoning, (dict, list)) else str(reasoning),
                     "temperature": samp.get("temperature", "not sent"), "top_p": samp.get("top_p", "not sent"),
                     "top_k": samp.get("top_k", "not sent"), "sampling": sampling,
                     "max_tokens": st.raw.get("llm", {}).get("max_tokens", "") if isinstance(st.raw, dict) else "",
                     "settings_recorded": "yes" if m in settings else "no",
                     "model_ids_returned": " ".join(sorted(returned.get(m, set())))})
    return rows


def run_variant(st: Study, variant: dict | None, printer=print, streams=None) -> tuple:
    jobs = run_jobs(st, variant, printer, streams)
    return jobs, _write_variant(st, variant, jobs)


def run_stage(st: Study, printer=print, force: bool = False) -> dict | None:
    """Score everything offline. Skipped when the results already match the inputs on disk
    (unless force=True, which run.py sets when you ask for --stage evaluate)."""
    res_dir = st.results_dir
    if not force and up_to_date(st):
        printer("  [evaluate] results are up to date with the banks and probe tables; skipped")
        return None
    t0 = time.time()
    for note in st.notes:
        printer(f"  [evaluate] note: {note}")
    res_dir.mkdir(parents=True, exist_ok=True)
    for sub in ("per_task", "draws"):
        (res_dir / sub).mkdir(exist_ok=True)
    scan = scan_call_log(st, bird_regrade="bird" in st.streams)
    costs = scan["costs"]
    jobs, primary = run_variant(st, None, printer)
    plan = plan_calls(st)
    write_csv(res_dir / "costs.csv", costs)
    write_csv(res_dir / "model_identity.csv", model_identity_rows(st))
    if st.build.second_bank_models:
        write_csv(res_dir / "repeatability.csv", repeatability_rows(st))
    if st.probe.subsets_enabled:
        srows, shap = subset_rows(st)
        write_csv(res_dir / "subsets.csv", srows)
        write_csv(res_dir / "shapley.csv", shap)
    if st.variants.enabled:
        vrows, vpooled = variant_rows(st)
        write_csv(res_dir / "variants.csv", vrows)
        write_csv(res_dir / "variants_retained.csv", vpooled)
    gate = gate_numbers(st, jobs, costs, plan)
    write_json(res_dir / "gate.json", _jsonable(gate))
    sens = run_sensitivity(st, scan, primary, printer)
    write_json(res_dir / "sensitivity.json", _jsonable(sens))
    write_summary(st, costs=costs)
    (res_dir / "SCHEMA.md").write_text(SCHEMA_MD, encoding="utf-8")
    write_json(res_dir / "inputs.json", {"fingerprint": inputs_fingerprint(st),
                                         "written": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                                         "seconds": round(time.time() - t0, 1)})
    for g in gate:
        if g.get("old_model"):
            printer(f"  [gate] {g['model']}, {g['stream']}:")
            for line in gate_lines(g):
                printer(f"    {line}")
    printer(f"  [evaluate] done in {time.time() - t0:.0f} s")
    return {"validity": primary["validity"], "arms": primary["arms"]}


def run_sensitivity(st: Study, scan: dict, primary: dict, printer=print) -> dict:
    """The sensitivity analyses named in Parts 1.4-1.6 and 8.2.14. Each one that changes any
    input is run in full into results/sensitivity/<name>/; one that changes nothing is
    recorded as identical to the primary analysis."""
    sens_dir = st.results_dir / "sensitivity"
    out = {}
    # 1) token-limit and refusal cells treated as missing (Part 1.4 items 2 and 3)
    ids = sorted(set(scan["flagged"]["limit"]) | set(scan["flagged"]["refusal"]))
    entry = {"limit_calls": len(scan["flagged"]["limit"]), "refusal_calls": len(scan["flagged"]["refusal"])}
    if ids:
        d = sens_dir / "limit_refusal_missing"
        d.mkdir(parents=True, exist_ok=True)
        write_json(d / "flagged_calls.json", ids)
        var = {"name": "limit_refusal_missing", "flagged": str(d / "flagged_calls.json"), "drop": "task",
               "draws_log": False}
        _, col = run_variant(st, var, printer)
        entry.update(status="run", folder=str(d.relative_to(st.results_dir)), dropped_tasks=col["dropped"],
                     worst_cell_drop_share=col["worst_drop_share"])
        if col["worst_drop_share"] > 0.02:
            var2 = dict(var, name="limit_refusal_available_case", drop="available")
            run_variant(st, var2, printer)
            entry["available_case"] = "sensitivity/limit_refusal_available_case"
    else:
        entry["status"] = "identical to the primary analysis: no call hit the token limit or was refused"
    out["limit_refusal_missing"] = entry
    # 2) available-case analysis when the primary drops more than 2 % of a cell's tasks (Part 1.6)
    if primary["worst_drop_share"] > 0.02:
        run_variant(st, {"name": "available_case", "drop": "available", "draws_log": False}, printer)
        out["available_case"] = {"status": "run", "folder": "sensitivity/available_case",
                                 "worst_cell_drop_share": primary["worst_drop_share"]}
    else:
        out["available_case"] = {"status": "not needed: no cell dropped more than 2 % of its tasks",
                                 "worst_cell_drop_share": primary["worst_drop_share"],
                                 "dropped_tasks": primary["dropped"]}
    # 3) BIRD graded with the other SQL parser, offline from the stored answers (Part 1.5)
    name = "bird_original" if not st.bird_faithful else "bird_corrected"
    if "bird" not in st.streams:
        out[name] = {"status": "not applicable: no BIRD stream in this study"}
    else:
        d = sens_dir / name
        d.mkdir(parents=True, exist_ok=True)
        regrade = bird_regrade_map(st, scan["bird"])
        flips = {cid: ok for cid, ok in regrade.items()}
        write_json(d / "regrade.json", flips)
        if not flips:
            # no BIRD answer is graded differently under the other parser: the analysis would be the
            # primary one again (FAULTS.md 6 of the dress rehearsal), so it is recorded, not re-run
            out[name] = {"status": "identical to the primary analysis: no BIRD answer is graded differently "
                                   "under the other SQL parser", "folder": f"sensitivity/{name}",
                         "answers_parsed_differently": len(scan["bird"]), "regraded_calls": 0,
                         "score_episodes_changed": 0}
            return out
        changed = replay_banks(st, flips, d / "banks")
        var = {"name": name, "regrade": str(d / "regrade.json"), "banks": str(d / "banks"),
               "bank_streams": ["bird"], "drop": "task", "draws_log": False}
        run_variant(st, var, printer, streams=("bird",))
        out[name] = {"status": "run", "folder": f"sensitivity/{name}", "answers_parsed_differently": len(scan["bird"]),
                     "regraded_calls": len(flips), "score_episodes_changed": changed,
                     "note": "item selection during the build followed the primary grades, so the replay is "
                             "not a full counterfactual build (Part 1.5)"}
    return out


# ---------------------------------------------------------------------------
# Intervals over the stream orders (pre-registration 4.1), kept for callers
# ---------------------------------------------------------------------------


def _by_seed(st, owner, reader, stream, key) -> dict:
    out = {}
    for seed in st.seeds:
        p = per_task_path(st, owner, reader, stream, seed)
        if p.exists():
            z = load_per_task(st, owner, reader, stream, seed)
            if key in z:
                out[seed] = z[key]
    return out


def interval(st: Study, by_seed: dict, stat: str = "mean") -> dict:
    try:
        return M.bootstrap_within_orders(by_seed, n=st.evaluate.bootstrap, seed=st.evaluate.seed, stat=stat,
                                         pool=True)
    except ValueError:
        return {"mean": NAN, "lo": NAN, "hi": NAN, "samples": np.array([NAN])}


def paired_interval(st: Study, a: dict, b: dict, stat: str = "mean") -> dict:
    common = sorted(set(a) & set(b))
    try:
        return M.paired_within_orders({k: a[k] for k in common}, {k: b[k] for k in common},
                                      n=st.evaluate.bootstrap, seed=st.evaluate.seed, stat=stat, pool=True)
    except ValueError:
        return {"mean": NAN, "lo": NAN, "hi": NAN, "samples": np.array([NAN])}


# ---------------------------------------------------------------------------
# SUMMARY.md
# ---------------------------------------------------------------------------


def _num(v) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return NAN


def _c(v, digits=2) -> str:
    return "–" if v is None or math.isnan(v) else f"{v:.{digits}f}"


def _pct(v) -> str:
    return "–" if v is None or math.isnan(v) else f"{100 * v:.1f}"


def _ci(d: dict, digits=2, pct=False) -> str:
    f = _pct if pct else (lambda x: _c(x, digits))
    if math.isnan(d.get("mean", NAN)):
        return "–"
    return f"{f(d['mean'])} [{f(d['lo'])}, {f(d['hi'])}]"


def _rows(rows, **kw):
    return [r for r in rows if all(str(r.get(k)) == str(v) for k, v in kw.items())]


def _mean(vals) -> float:
    vals = [v for v in vals if v is not None and not (isinstance(v, float) and math.isnan(v))]
    return float(np.mean(vals)) if vals else NAN


def _wpooled(rows: list, col: str, weight: str) -> float:
    """A per-order Cw pooled over orders and cells through its pair weights (Part 2.2)."""
    num = den = 0.0
    for r in rows:
        v, n = _num(r.get(col)), _num(r.get(weight))
        if not (math.isnan(v) or math.isnan(n)) and n > 0:
            num += v * n
            den += n
    return num / den if den else NAN


def _pooled(rows: list, col: str) -> float:
    """A per-order mean pooled over the orders with equal weight per task (Part 2.12):
    sum(value x n_tasks) / sum(n_tasks)."""
    num = den = 0.0
    for r in rows:
        v, n = _num(r.get(col)), _num(r.get("n_tasks"))
        if not (math.isnan(v) or math.isnan(n)) and n > 0:
            num += v * n
            den += n
    return num / den if den else NAN


def write_summary(st: Study, costs: list | None = None) -> Path:
    """The plain-words summary, from the files in results/."""
    rd = st.results_dir
    validity = read_csv(rd / "validity.csv")
    arms_rows = read_csv(rd / "arms.csv")
    ret = read_csv(rd / "retained.csv")
    if costs is None:
        costs = costs_from_log(st)          # refresh: later stages add calls
        write_csv(rd / "costs.csv", costs)
    costs = [{k: (str(v) if not isinstance(v, str) else v) for k, v in c.items()} for c in costs]
    gate = json.loads((rd / "gate.json").read_text(encoding="utf-8")) if (rd / "gate.json").exists() else []
    sens = json.loads((rd / "sensitivity.json").read_text(encoding="utf-8")) if (rd / "sensitivity.json").exists() else {}
    online = read_csv(rd / "online.csv")
    plan = plan_calls(st)
    head = headline_family(st)
    ks = st.evaluate.k_values
    k = st.evaluate.summary_k if st.evaluate.summary_k in ks else (ks[0] if ks else None)
    out: list = []
    w = out.append
    w(f"# Study `{st.name}`: summary")
    w("")
    w(f"Written {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')} from the files in `results/`. "
      "No model was called to make this page. Intervals are 95 % intervals from resampling tasks within each "
      f"stream order, the same draws for every cell ({st.evaluate.bootstrap:,} draws).")
    w("")
    w("## What was run")
    w("")
    sim = " (all simulated: free, with a known truth)" if st.all_sim else ""
    w(f"- Models{sim}: " + ", ".join(f"`{m}` ({st.family(m)})" for m in st.models))
    w(f"- Swaps: {len(st.pairs)} ordered pairs, plus each model with itself (home and self-swap).")
    w(f"- Streams: {', '.join(st.streams)}; stream orders (seeds): {', '.join(map(str, st.seeds))}"
      + (f"; excluded tasks: {', '.join(st.exclude_tasks)}" if st.exclude_tasks else "") + ".")
    B = st.build
    w(f"- Build: {B.n_write} write tasks (no memory; one {B.item_style} item each, then frozen), "
      f"{st.n_score} score tasks x {B.epochs} passes; {B.candidates} candidates, {B.n_show} shown, "
      f"exploration {B.epsilon}, mix {B.w_score} x score + {1 - B.w_score:g} x relevance, driven by `{B.drive}`; "
      f"self tags {'with' if B.self_tag_sees_grade else 'without'} the grade"
      + (f"; second bank for {', '.join(B.second_bank_models)}" if B.second_bank_models else "") + ".")
    w(f"- Probe: {st.sizes.n_probe} tasks ({st.evaluate.calib_tasks} for fresh checks, "
      f"{st.sizes.n_probe - st.evaluate.calib_tasks} evaluated), top {st.probe.candidates} owner items each shown "
      f"alone {st.probe.repeats} times, {st.probe.no_memory_repeats} runs with no item, "
      f"{st.probe.home_extra_repeats} extra home repeats (self-swap reference)"
      + (f"; realism check on {st.probe.subset_tasks} tasks" if st.probe.subsets_enabled else "")
      + (f"; wording {st.variants.variant} on {st.variants.tasks} tasks" if st.variants.enabled else "") + ".")
    w(f"- Evaluate: headline family `{head}`; {st.evaluate.calib_draws} random draws of the k checks, "
      f"{st.evaluate.shuffled_seeds} shuffles, k = {', '.join(map(str, ks))}; probabilities clipped to "
      f"{list(_setting(st, 'prob_clip', S.PROB_CLIP))}.")
    w(f"- Calls made: {sum(int(c['calls']) for c in costs):,} (planned {total_calls(plan):,}); "
      f"answered fresh {sum(int(c['fresh_calls']) for c in costs):,}; dollars {sum(_num(c['usd']) for c in costs):.2f} "
      f"(estimated {total_usd(plan):.2f}); answers cut at the token limit "
      f"{sum(int(c.get('hit_limit') or 0) for c in costs):,}, refused {sum(int(c.get('refusals') or 0) for c in costs):,}, "
      f"unparseable {sum(int(c.get('unparseable') or 0) for c in costs):,}.")
    w("")
    w("How to read: *Cw* is the weighted concordance (0.5 = coin toss): of two candidates whose results differ, "
      "how often the one with the higher OLD score did better, each pair weighted by how much the results differ. "
      "*Home*: the owner's own results. *After swap*: the reader's results (for a model with itself: fresh repeats, "
      "the self-swap reference). *Drop* = home - after; *beyond floor* = the drop test rejects (unadjusted) and "
      "the drop exceeds the upper end of the owner's self-swap interval. *Kept* = (after - 0.5) / (home - 0.5), "
      f"shown only when the home signal is at least {_setting(st, 'ratio_min_z', RATIO_MIN_Z):g} standard errors "
      "above 0.5. Rules are scored by the percent of evaluation tasks solved with the item each rule shows first.")
    w("")
    w("## Pilot gate (pre-registration 9.3): PASS / FAIL per line")
    w("")
    for g in gate:
        if not g.get("old_model"):
            continue
        w(f"**{g['model']}, {g['stream']}**")
        w("")
        for line in gate_lines(g):
            w(line)
        w("")
    if gate:
        w("Home Cw per family (all models, all probe tasks): " + "; ".join(
            f"{g['model']} " + ", ".join(f"{f} {_c(_num(g.get(f'home_cw_{f}')))}" for f in st.scores.families)
            for g in gate) + ".")
        w("")
    for stream in st.streams:
        w(f"## Validity of the old scores per swap: {stream}, family `{head}` (pooled over the stream orders)")
        w("")
        w("| owner -> reader | kind | Cw home | Cw after swap | drop [CI] | owner's self-swap drop (upper end) | "
          "beyond floor | kept [CI] | noise ref. |")
        w("|---|---|---|---|---|---|---|---:|---:|")
        for owner, reader in st.cells:
            rr = _rows(ret, owner=owner, reader=reader, stream=stream, family=head)
            if not rr:
                continue
            r = rr[0]
            if r["ratio_status"] == M.RATIO_UNDEFINED:
                kept = "undefined"
            elif r["ratio_status"] == M.RATIO_UNBOUNDED:
                kept = f"{_c(_num(r['ratio']))} [unbounded]"
            else:
                kept = f"{_c(_num(r['ratio']))} [{_c(_num(r['ratio_lo']))}, {_c(_num(r['ratio_hi']))}]"
            ceil = _mean([_num(x["ceiling_swap"]) for x in _rows(validity, owner=owner, reader=reader, stream=stream,
                                                                  family=head)])
            w(f"| {owner} -> {reader} | {maker_kind(st, owner, reader)} | {_c(_num(r['c_home']))} | {_c(_num(r['c_swap']))} | "
              f"{_c(_num(r['drop']))} [{_c(_num(r['drop_lo']))}, {_c(_num(r['drop_hi']))}] | "
              f"{_c(_num(r['self_drop']))} ({_c(_num(r['self_drop_hi']))}) | "
              f"{'yes' if str(r['drop_beyond_floor']) == 'True' else 'no'} | {kept} | {_c(ceil)} |")
        w("")
        cols = ["none", "relevance", "keep", "wipe", "shuffled"]
        if 0.5 in st.evaluate.fixed_lambdas:
            cols.append("fixed_0.5")
        if k is not None:
            cols += [f"{a}_{k}" for a in CHECK_ARMS]
        cols += ["split_half", "ceiling", "own"]
        w(f"### Decision quality: {stream}, family `{head}` (percent solved with the first-shown item, pooled over "
          "the orders)")
        w("")
        w("| owner -> reader | " + " | ".join(cols) + " |")
        w("|---|" + "---:|" * len(cols))
        for owner, reader in st.cells:
            ar = _rows(arms_rows, owner=owner, reader=reader, stream=stream)
            vals = []
            for c in cols:
                fam = NO_FAMILY if c in ("none", "relevance", "split_half", "ceiling") else head
                vals.append(_pct(_pooled([r for r in ar if r["arm"] == c and r["family"] == fam], "value")))
            w(f"| {owner} -> {reader} | " + " | ".join(vals) + " |")
        w("")
        lcols = ["keep", "wipe"] + (["fixed_0.5"] if 0.5 in st.evaluate.fixed_lambdas else []) + \
                ([f"{a}_{k}" for a in ("powerprior", "powerprior_flat", "recal", "audit", "pooled", "fresh")] if k else [])
        w(f"### Held-out log score: {stream}, family `{head}` (higher is better; 0 is perfect)")
        w("")
        w("| owner -> reader | " + " | ".join(lcols) + " |")
        w("|---|" + "---:|" * len(lcols))
        for owner, reader in st.cells:
            ar = _rows(arms_rows, owner=owner, reader=reader, stream=stream, family=head)
            w(f"| {owner} -> {reader} | " + " | ".join(
                _c(_pooled([r for r in ar if r["arm"] == c], "log_score"), 3) for c in lcols) + " |")
        w("")
        w(f"### Every score family: {stream} (Cw home / after swap, pooled over orders)")
        w("")
        w("| owner -> reader | " + " | ".join(st.scores.families) + " |")
        w("|---|" + "---|" * len(st.scores.families))
        for owner, reader in st.cells:
            txt = []
            for f in st.scores.families:
                rr = _rows(ret, owner=owner, reader=reader, stream=stream, family=f)
                txt.append(f"{_c(_num(rr[0]['c_home']))} / {_c(_num(rr[0]['c_swap']))}" if rr else "–")
            w(f"| {owner} -> {reader} | " + " | ".join(txt) + " |")
        w("")
        w("By kind of swap (mean Cw after the swap; home rows are the self-swap): " + "; ".join(
            f"{f}: " + ", ".join(
                f"{kd.replace('_', ' ')} "
                f"{_c(_mean([_num(r['c_swap']) for r in ret if r['kind'] == kd and r['family'] == f and r['stream'] == stream]))}"
                for kd in ("home", "same_maker", "cross_maker"))
            for f in st.scores.families) + ".")
        w("")
        w("Content-only control (old scores permuted across all items, mean Cw after the swap): " + ", ".join(
            f"{f} {_c(_wpooled([r for r in validity if r['family'] == f and r['stream'] == stream], 'swap_shuffled', 'swap_weight'))}"
            for f in st.scores.families) + ".")
        w("")
    rep = read_csv(rd / "repeatability.csv")
    if rep:
        w("## Score repeatability (second bank: same items, other exploration seed)")
        w("")
        w("| model | family | rank correlation | same order on probe pairs | home Cw bank 1 | home Cw bank 2 |")
        w("|---|---|---:|---:|---:|---:|")
        for m in st.build.second_bank_models:
            for f in st.scores.families:
                rr = _rows(rep, model=m, family=f)
                w(f"| {m} | {f} | {_c(_mean([_num(r['spearman']) for r in rr]))} | "
                  f"{_c(_mean([_num(r['pair_agreement']) for r in rr]))} | "
                  f"{_c(_mean([_num(r['home_validity_bank1']) for r in rr]))} | "
                  f"{_c(_mean([_num(r['home_validity_bank2']) for r in rr]))} |")
        w("")
    sub = read_csv(rd / "subsets.csv")
    if sub:
        w("## Realism check: items shown together (exact Shapley values)")
        w("")
        w(f"| owner -> reader | one-at-a-time vs Shapley (Cw) | validity vs one-at-a-time ({head}) | validity vs Shapley ({head}) |")
        w("|---|---:|---:|---:|")
        for owner, reader in st.probe.subset_cells:
            rr = _rows(sub, owner=owner, reader=reader, family=head)
            w(f"| {owner} -> {reader} | {_c(_mean([_num(r['single_vs_shapley']) for r in rr]))} | "
              f"{_c(_mean([_num(r['validity_single']) for r in rr]))} | {_c(_mean([_num(r['validity_shapley']) for r in rr]))} |")
        w("")
    var = read_csv(rd / "variants.csv")
    if var:
        w(f"## Second prompt wording ({st.variants.variant})")
        w("")
        w(f"| owner -> reader | validity v1 ({head}) | validity {st.variants.variant} | outcome agreement v1 vs {st.variants.variant} |")
        w("|---|---:|---:|---:|")
        for owner, reader in st.variants.cells:
            rr = _rows(var, owner=owner, reader=reader, family=head)
            w(f"| {owner} -> {reader} | {_c(_mean([_num(r['validity_v1']) for r in rr]))} | "
              f"{_c(_mean([_num(r['validity_variant']) for r in rr]))} | {_pct(_mean([_num(r['outcome_agreement']) for r in rr]))} % |")
        w("")
        vret = [r for r in read_csv(rd / "variants_retained.csv") if r["family"] == head and r["stream"] == "all"]
        if vret:
            v2 = st.variants.variant
            w(f"Drop D = C_home - C_swap and retained ratio R under each wording ({head}, streams averaged; "
              f"`variants_retained.csv`):")
            w("")
            w(f"| owner -> reader | D v1 [95 %] | D {v2} [95 %] | {v2} - v1 [95 %] | R v1 | R {v2} |")
            w("|---|---:|---:|---:|---:|---:|")
            for r in vret:
                def iv(key):
                    return f"{_c(_num(r[key]))} [{_c(_num(r[key + '_lo']))}, {_c(_num(r[key + '_hi']))}]"
                def rv(wording):
                    if r[f"ratio_status_{wording}"] == M.RATIO_UNDEFINED:
                        return "undefined"
                    return _c(_num(r[f"ratio_{wording}"]))
                w(f"| {r['owner']} -> {r['reader']} | {iv('drop_v1')} | {iv('drop_variant')} | "
                  f"{iv('drop_difference')} | {rv('v1')} | {rv('variant')} |")
            w("")
    if online:
        w("## The run after the swap (test tasks, scores keep learning)")
        w("")
        w(f"| owner -> reader | stream | family | rule | success % | first {st.online.first_n} % | tasks to "
          f"{100 * st.online.target_share:g} % of own |")
        w("|---|---|---|---|---:|---:|---:|")
        for r in [x for x in online if x.get("seed") == "all"]:
            w(f"| {r['owner']} -> {r['reader']} | {r['stream']} | {r['family']} | {r['arm']} | {_pct(_num(r['success']))} | "
              f"{_pct(_num(r['success_first']))} | {r['tasks_to_target'] or 'not reached'} |")
        w("")
    if sens:
        w("## Sensitivity analyses (pre-registration 1.4-1.6, 8.2.14)")
        w("")
        for name, entry in sens.items():
            w(f"- `{name}`: {entry.get('status')}" + (f" (`{entry['folder']}`)" if entry.get("folder") else "") + ".")
        w("")
    w("## Files")
    w("")
    w("- `validity.csv`, `retained.csv`, `arms.csv`, `agreement.csv`, `costs.csv`, `gate.json`, `sensitivity.json`"
      + (", `repeatability.csv`" if rep else "") + (", `subsets.csv`, `shapley.csv`" if sub else "")
      + (", `variants.csv`, `variants_retained.csv`" if var else "") + (", `online.csv`, `online_curves.csv`" if online else "")
      + "; per-task values in `per_task/*.npz` (msr.evaluate.load_per_task), raw cells in `cells/*.npz`, "
      "random draws in `draws/`; every file and column is listed in `SCHEMA.md`.")
    path = rd / "SUMMARY.md"
    tmp = path.with_name(path.name + ".part")
    tmp.write_text("\n".join(out) + "\n", encoding="utf-8")
    tmp.replace(path)
    return path
