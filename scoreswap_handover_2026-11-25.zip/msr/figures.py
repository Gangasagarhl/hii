"""Publication figures from the analysis CSVs (runs/<study>/analysis/ -> paper/assets/).

Everyday picture: the analysis wrote the numbers on sheets; this module only draws them. Every
figure reads its CSV with a `load_*` function and draws it with a `draw_*` function, so the data
side can be checked without drawing and the drawing can be tried on hand-made data.

Style (ICML two-column page): one column is 3.25 in wide, the full text width 6.75 in. Vector PDF
with TrueType fonts embedded (fonttype 42) and a 300 dpi PNG. No titles inside the figures (the
caption carries them). Colours are the Okabe-Ito colour-blind-safe set, and every colour is paired
with a marker or line style so the figure still reads in greyscale. A study whose models are all
simulated gets a small "SIMULATED DATA" mark in the corner of every figure.

Run:  python -m msr.figures --analysis runs/sim/analysis --out paper/assets
"""
from __future__ import annotations

import argparse
import csv
import math
from collections import defaultdict
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent

COLUMN_W = 3.25        # inches, one ICML column
TEXT_W = 6.75          # inches, both columns
GROUPS = ("upgrade", "downgrade", "cross")
GROUP_LABEL = {"upgrade": "Same-maker upgrades", "downgrade": "Same-maker downgrades",
               "cross": "Cross-maker swaps", "home": "Home (self-swap reference)"}
# Okabe-Ito; dark / light / medium so the three groups also differ in grey
GROUP_STYLE = {"upgrade": {"color": "#0072B2", "marker": "o", "mfc": "#0072B2"},
               "downgrade": {"color": "#E69F00", "marker": "s", "mfc": "white"},
               "cross": {"color": "#D55E00", "marker": "^", "mfc": "#D55E00"},
               "home": {"color": "#000000", "marker": "D", "mfc": "white"}}
ARM_STYLE = {   # check arms on the k-curves and the post-swap run: colour + marker + line style
    "recal": {"color": "#0072B2", "marker": "o", "ls": "-", "label": "recalibrate (level + slope)"},
    "powerprior": {"color": "#D55E00", "marker": "s", "ls": "--", "label": "power prior"},
    "retest": {"color": "#009E73", "marker": "^", "ls": "-.", "label": "re-test top k"},
    "audit": {"color": "#CC79A7", "marker": "D", "ls": ":", "label": "audit, then keep or wipe"},
    "pooled": {"color": "#E69F00", "marker": "v", "ls": "-", "label": "pooled evidence"},
    "fresh": {"color": "#56B4E9", "marker": "P", "ls": "--", "label": "fresh checks only"},
}
REF_STYLE = {"keep": {"color": "#000000", "ls": "-", "lw": 1.1, "label": "keep"},
             "wipe": {"color": "#777777", "ls": (0, (4, 2)), "lw": 1.1, "label": "wipe"},
             "fixed": {"color": "#444444", "ls": (0, (1, 1.5)), "lw": 1.1, "label": r"fixed discount $\lambda$=0.5"},
             "own": {"color": "#009E73", "ls": "-", "lw": 1.0, "label": "reader's own bank"},
             "none": {"color": "#999999", "ls": (0, (6, 2, 1, 2)), "lw": 1.0, "label": "no memory"}}


def _mpl():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({
        "pdf.fonttype": 42, "ps.fonttype": 42, "font.family": "DejaVu Sans", "font.size": 7,
        "axes.labelsize": 7, "axes.titlesize": 7, "xtick.labelsize": 6, "ytick.labelsize": 6,
        "legend.fontsize": 6, "axes.linewidth": 0.6, "xtick.major.width": 0.6, "ytick.major.width": 0.6,
        "xtick.major.size": 2.5, "ytick.major.size": 2.5, "lines.linewidth": 1.0, "lines.markersize": 3.5,
        "axes.spines.top": False, "axes.spines.right": False, "legend.frameon": False,
        "savefig.dpi": 300, "figure.dpi": 150, "hatch.linewidth": 0.5, "svg.fonttype": "none",
    })
    return plt


# ---------------------------------------------------------------------------
# Loading (no drawing here)
# ---------------------------------------------------------------------------


def read_csv(path: Path) -> list:
    path = Path(path)
    if not path.exists():
        return []
    with open(path, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def num(v) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return float("nan")


def load_meta(adir: Path) -> dict:
    return {r["key"]: r["value"] for r in read_csv(Path(adir) / "meta.csv")}


def is_sim(meta: dict) -> bool:
    return str(meta.get("all_models_simulated", "")).lower() in ("true", "1", "yes")


MARKS = {"simulated": "SIMULATED DATA", "preliminary": "PRELIMINARY: free models through a wrapper", "real": ""}


def mark_text(meta: dict) -> str:
    """The corner mark of every figure: by the study kind written in meta.csv."""
    kind = meta.get("study_kind") or ("simulated" if is_sim(meta) else "real")
    return MARKS.get(kind, "")


def load_grid(adir: Path) -> dict:
    """Retained validity R per (owner, reader), headline family, pooled over streams. The home
    diagonal holds the self-swap ratio (fresh home repeats as the 'reader')."""
    meta = load_meta(adir)
    fam = meta.get("headline_family", "ema_grade")
    models = meta.get("models", "").split()
    cells = {}
    for r in read_csv(Path(adir) / "validity_pairs.csv"):
        if r["family"] == fam and r["level"] == "all":
            cells[(r["owner"], r["reader"])] = {"R": num(r["R"]), "status": r["R_status"], "D": num(r["D"])}
    return {"models": models, "cells": cells, "family": fam, "sim": mark_text(meta),
            "family_of": dict(x.split(":", 1) for x in meta.get("families_of_models", "").split() if ":" in x)}


def _flag_ok(r: dict) -> bool:
    """theta's headline flag (msr.analysis.flag_ok): the calibration-task rule, or the same-task
    status where the result files carry no calibration tasks."""
    st = r.get("theta_status_calibration", "")
    if not st or st.startswith("not available"):
        return r.get("theta_status") == "defined"
    return st == "defined"


#: revision 2 (decision D2): theta = order x stakes. order = how well the owner's order still fits the
#: reader; stakes = how much the reader's success depends on which item it gets, relative to the owner's.
ORDER_STAKES_KEYS = ("order", "order_lo", "order_hi", "stakes", "stakes_lo", "stakes_hi")


def _order_stakes(r: dict) -> dict:
    """order, stakes (+ interval ends) and order's identifiability status of one theta row; NaN / ''
    where the analysis did not write them (result files without the cross-repeat parts)."""
    out = {k: num(r.get(k)) for k in ORDER_STAKES_KEYS}
    out["order_status"] = r.get("order_status", "") or ""
    return out


def load_theta_grid(adir: Path) -> dict:
    """Figure 1 (round-1 revision): theta, the retained ranking signal, per (owner, reader),
    headline family, pooled over streams; the home diagonal holds the self-swap theta (extra
    repeats 3-4 as the 'reader'); where theta is not reportable the cell shows the drop D."""
    meta = load_meta(adir)
    fam = meta.get("headline_family", "ema_grade")
    models = meta.get("models", "").split()
    cells = {}
    for r in read_csv(Path(adir) / "theta_pairs.csv"):
        if r["family"] == fam and r["level"] == "all":
            cells[(r["owner"], r["reader"])] = {"R": num(r["theta"]),
                                                "status": "reported" if _flag_ok(r) else "undefined",
                                                "D": num(r.get("D")), **_order_stakes(r)}
    return {"models": models, "cells": cells, "family": fam, "sim": mark_text(meta),
            "family_of": dict(x.split(":", 1) for x in meta.get("families_of_models", "").split() if ":" in x),
            "cbar_label": "Retained ranking signal θ (colour clipped to 0-1)",
            "show_flagged": True,
            "note": "dashed box: home cell (self-swap reference, θ ≈ 1)\n"
                    "hatched, italic: θ flagged 'home signal too weak'\n(owner's calibration tasks under 2 SE)"}


def load_forest_theta(adir: Path) -> dict:
    """Forest of theta per ordered pair with its two-way Fieller interval, grouped by swap group,
    with the group estimate (diamond)."""
    meta = load_meta(adir)
    fam = meta.get("headline_family", "ema_grade")
    pairs = [r for r in read_csv(Path(adir) / "theta_pairs.csv")
             if r["family"] == fam and r["level"] == "all" and r["owner"] != r["reader"]]
    groups = {r["group"]: r for r in read_csv(Path(adir) / "theta_groups.csv")
              if r["family"] == fam and r["level"] == "all"}
    out = {"sim": mark_text(meta), "groups": {}, "xlabel": "Retained ranking signal θ = V(after swap) / V(home)",
           "vlines": ((1.0, "-", 0.6), (0.75, (0, (3, 2)), 0.6), (0.0, ":", 0.6)), "ref_label": None}
    for g in GROUPS:
        rows = sorted([r for r in pairs if r["group"] == g], key=lambda r: num(r["theta"]))
        if not rows:
            continue
        out["groups"][g] = {
            "pairs": [{"label": f"{r['owner']} → {r['reader']}", "v": num(r["theta"]), "lo": num(r["theta_lo"]),
                       "hi": num(r["theta_hi"]), "U_self": float("nan"), **_order_stakes(r)} for r in rows],
            "pooled": ({"v": num(groups[g]["theta"]), "lo": num(groups[g]["theta_lo"]),
                        "hi": num(groups[g]["theta_hi"]), "U_self": float("nan"), **_order_stakes(groups[g])}
                       if g in groups else None)}
    return out


def load_order_stakes(adir: Path) -> dict:
    """Companion of Figure 1 (revision 2): every swap's theta split as order x stakes, one point per
    ordered pair (x = stakes, y = order) with its two-way intervals, by swap group; the curves
    order = theta / stakes for theta = 1, 0.75 and 0.5 show where a point's theta lies. Pairs whose
    order is 'not identifiable' (the reader's item spread cannot be told from zero) are drawn hollow."""
    meta = load_meta(adir)
    fam = meta.get("headline_family", "ema_grade")
    pts = []
    for r in read_csv(Path(adir) / "theta_pairs.csv"):
        if r["family"] != fam or r["level"] != "all" or r["owner"] == r["reader"]:
            continue
        os_ = _order_stakes(r)
        if not (math.isfinite(os_["order"]) and math.isfinite(os_["stakes"])):
            continue
        pts.append({"group": r["group"] if r["group"] in GROUPS else "cross", "theta": num(r["theta"]),
                    "label": f"{r['owner']} → {r['reader']}", **os_,
                    "identified": os_["order_status"] in ("", "defined")})
    return {"sim": mark_text(meta), "points": pts, "family": fam}


def load_forest(adir: Path) -> dict:
    meta = load_meta(adir)
    fam = meta.get("headline_family", "ema_grade")
    pairs = [r for r in read_csv(Path(adir) / "validity_pairs.csv")
             if r["family"] == fam and r["level"] == "all" and r["owner"] != r["reader"]]
    groups = {r["group"]: r for r in read_csv(Path(adir) / "group_validity.csv")
              if r["family"] == fam and r["level"] == "all"}
    out = {"sim": mark_text(meta), "groups": {}}
    for g in GROUPS:
        rows = sorted([r for r in pairs if r["group"] == g], key=lambda r: num(r["D"]))
        if not rows:
            continue
        out["groups"][g] = {
            "pairs": [{"label": f"{r['owner']} → {r['reader']}", "v": num(r["D"]), "lo": num(r["D_lo"]),
                       "hi": num(r["D_hi"]), "U_self": num(r["U_self"])} for r in rows],
            "pooled": ({"v": num(groups[g]["D"]), "lo": num(groups[g]["D_lo"]), "hi": num(groups[g]["D_hi"]),
                        "U_self": num(groups[g]["U_self"])} if g in groups else None)}
    return out


def load_kcurves(adir: Path) -> dict:
    meta = load_meta(adir)
    fam = meta.get("headline_family", "ema_grade")
    lam = meta.get("primary_lambda", "0.5")
    rows = [r for r in read_csv(Path(adir) / "arms_groups.csv") if r["level"] == "all" and r["group"] in GROUPS
            and r["family"] in (fam, "-")]
    out = {"sim": mark_text(meta), "curves": defaultdict(list), "refs": {}}
    for r in rows:
        m = r["metric"]
        if m not in ("value", "log"):
            continue
        base = r.get("arm_base") or r["arm"]
        if base in ARM_STYLE and r["k"] not in ("", None):
            out["curves"][(m, r["group"], base)].append((int(float(r["k"])), num(r["est"]), num(r["lo"]), num(r["hi"])))
        elif r["arm"] in ("keep", "wipe") and r["family"] == fam:
            out["refs"][(m, r["group"], r["arm"])] = num(r["est"])
        elif r["arm"] == f"fixed_{float(lam):g}" and r["family"] == fam:
            out["refs"][(m, r["group"], "fixed")] = num(r["est"])
    for k in out["curves"]:
        out["curves"][k].sort()
    return out


def load_online(adir: Path) -> dict:
    meta = load_meta(adir)
    rows = read_csv(Path(adir) / "online_curves.csv")
    acc = defaultdict(list)
    for r in rows:
        acc[(r["owner"], r["reader"], r["group"], r["arm"], int(r["position"]))].append(num(r["trailing_success"]))
    curves = defaultdict(dict)
    for (o, rd, g, arm, pos), v in acc.items():      # mean over streams
        curves[(o, rd, g)].setdefault(arm, []).append((pos, float(np.mean(v))))
    for key in curves:
        for arm in curves[key]:
            curves[key][arm].sort()
    order = {g: j for j, g in enumerate(GROUPS)}
    swaps = sorted(curves, key=lambda k: (order.get(k[2], 9), k[0], k[1]))
    window = next((int(float(r["window"])) for r in rows if r.get("window")), None)
    return {"sim": mark_text(meta), "curves": curves, "swaps": swaps, "window": window}


def load_p1(adir: Path) -> dict:
    meta = load_meta(adir)
    pts = [r for r in read_csv(Path(adir) / "prediction_points.csv")
           if str(r.get("theta_defined", r.get("R_defined", ""))).lower() == "true" and math.isfinite(num(r["kappa"]))]
    return {"sim": mark_text(meta),
            "points": [{"group": r["group"], "kappa": num(r["kappa"]), "R": num(r.get("theta", r.get("R"))),
                        "label": f"{r['owner']} → {r['reader']}"} for r in pts]}


def load_shapley(adir: Path) -> dict:
    meta = load_meta(adir)
    pts = read_csv(Path(adir) / "shapley_points.csv")
    return {"sim": mark_text(meta),
            "points": [{"kind": "home" if r["owner"] == r["reader"] else r["group"], "single": num(r["single"]),
                        "shapley": num(r["shapley"])} for r in pts]}


# ---------------------------------------------------------------------------
# Drawing
# ---------------------------------------------------------------------------


def _sim_mark(fig, mark) -> None:
    """Flag the figure; _save() puts the study kind's mark (e.g. "SIMULATED DATA") below everything."""
    fig._msr_mark = mark if isinstance(mark, str) else ("SIMULATED DATA" if mark else "")


def _place_sim_mark(fig) -> None:
    mark = getattr(fig, "_msr_mark", "")
    if not mark:
        return
    fig.canvas.draw()
    bb = fig.get_tightbbox(fig.canvas.get_renderer())          # inches
    w, h = fig.get_size_inches()
    fig.text(bb.x1 / w, (bb.y0 - 0.03) / h, mark, ha="right", va="top", fontsize=5, color="#888888")


def _save(fig, out_dir: Path, name: str) -> list:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    paths = []
    _place_sim_mark(fig)
    for ext, kw in (("pdf", {"metadata": {"CreationDate": None, "ModDate": None}}),
                    ("png", {"dpi": 300, "metadata": {"Software": None}})):
        p = out_dir / f"{name}.{ext}"
        fig.savefig(p, bbox_inches="tight", pad_inches=0.02, **kw)
        paths.append(p)
    import matplotlib.pyplot as plt
    plt.close(fig)
    return paths


def draw_grid(d: dict):
    """Figure 1: owner-by-reader grid of retained validity R. The colour scale is clipped to 0-1 but
    every value is printed as it is; the home diagonal (self-swap, the noise floor) is outlined;
    where R is not reportable the cell is hatched and shows the drop D in italics. Cell and font
    sizes follow the number of models (readable up to 8 or more)."""
    plt = _mpl()
    from matplotlib.colors import Normalize
    from matplotlib.patches import Rectangle
    models = d["models"]
    M = len(models)
    width = COLUMN_W if M <= 8 else TEXT_W * 0.62
    grid_in = width - 1.35                       # room for the row labels and the colour bar
    cell = grid_in / max(M, 1)
    fs = float(np.clip(0.30 * cell * 72, 4.2, 6.5))       # value font, points
    lab = float(np.clip(0.36 * cell * 72, 4.8, 6.5))      # tick labels
    fig, ax = plt.subplots(figsize=(width, grid_in + 1.25))
    cmap = plt.get_cmap("cividis")
    norm = Normalize(vmin=0.0, vmax=1.0)
    A = np.full((M, M), np.nan)
    for i, o in enumerate(models):
        for j, r in enumerate(models):
            c = d["cells"].get((o, r))
            if c and c["status"] == "reported" and math.isfinite(c["R"]):
                A[i, j] = c["R"]
    im = ax.imshow(np.clip(A, 0.0, 1.0), cmap=cmap, norm=norm, aspect="equal")
    for i, o in enumerate(models):
        for j, r in enumerate(models):
            c = d["cells"].get((o, r))
            if c is None:
                ax.add_patch(Rectangle((j - 0.5, i - 0.5), 1, 1, facecolor="white", edgecolor="#bbbbbb", lw=0.3))
                continue
            if c["status"] != "reported" or not math.isfinite(c["R"]):
                ax.add_patch(Rectangle((j - 0.5, i - 0.5), 1, 1, facecolor="#e6e6e6", edgecolor="#555555",
                                       hatch="////", lw=0.3))
                if d.get("show_flagged") and math.isfinite(c["R"]):     # theta is always shown; only flagged
                    txt = f"{c['R']:.2f}"
                else:
                    txt = f"{c['D']:.2f}" if math.isfinite(c.get("D", float("nan"))) else "n/r"
                ax.text(j, i, txt, ha="center", va="center", fontsize=fs, color="#111111", fontstyle="italic",
                        bbox={"facecolor": "#e6e6e6", "edgecolor": "none", "pad": 0.3})
                continue
            v = c["R"]
            rgba = cmap(norm(min(max(v, 0.0), 1.0)))
            lum = 0.2126 * rgba[0] + 0.7152 * rgba[1] + 0.0722 * rgba[2]
            ax.text(j, i, f"{v:.2f}", ha="center", va="center", fontsize=fs, color="black" if lum > 0.5 else "white")
    for i in range(M):       # the home diagonal: the self-swap reference
        ax.add_patch(Rectangle((i - 0.5, i - 0.5), 1, 1, fill=False, edgecolor="black", lw=1.0, ls=(0, (2, 1))))
    fam_of = d.get("family_of", {})
    for i in range(1, M):    # thin white lines between makers
        if fam_of and fam_of.get(models[i]) != fam_of.get(models[i - 1]):
            ax.axhline(i - 0.5, color="white", lw=1.2)
            ax.axvline(i - 0.5, color="white", lw=1.2)
    ax.set_xticks(range(M))
    ax.set_yticks(range(M))
    ax.set_xticklabels(models, rotation=40, ha="right", rotation_mode="anchor", fontsize=lab)
    ax.set_yticklabels(models, fontsize=lab)
    # revision 2: a downgrade's reader is the OLDER model, so the axes name the roles, not the ages
    ax.set_xlabel(d.get("xlabel", "Reader (model after the swap)"))
    ax.set_ylabel(d.get("ylabel", "Bank owner (model whose scores are kept)"))
    for sp in ax.spines.values():
        sp.set_visible(False)
    ax.tick_params(length=0)
    cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.03, extend="both")
    cb.set_label(d.get("cbar_label", "Retained validity R (colour clipped to 0-1)"), fontsize=5.5)
    cb.ax.tick_params(labelsize=5.5, width=0.5, length=2)
    cb.outline.set_linewidth(0.5)
    ax.text(0.0, 1.015, d.get("note", "dashed box: home cell (self-swap reference)\n"
            "hatched, italic: R not reportable (home signal under 4 SE);\nthe number shown there is the drop D"),
            transform=ax.transAxes, fontsize=5, color="#333333", ha="left", va="bottom", linespacing=1.2)
    _sim_mark(fig, d["sim"])
    return fig


def draw_forest(d: dict):
    """Forest plot of the drop D per ordered pair, grouped by swap stratum, with the group
    estimate (diamond) and each owner's self-swap noise-floor upper end (grey tick)."""
    plt = _mpl()
    rows = []       # (kind, label, payload)
    for g in GROUPS:
        if g not in d["groups"]:
            continue
        rows.append(("head", GROUP_LABEL[g], g))
        for p in d["groups"][g]["pairs"]:
            rows.append(("pair", p["label"], (g, p)))
        if d["groups"][g]["pooled"]:
            rows.append(("pool", "group estimate", (g, d["groups"][g]["pooled"])))
    n = len(rows)
    many = n > 30
    h = max(1.6, 0.35 + (0.105 if many else 0.15) * n)
    fig, ax = plt.subplots(figsize=(COLUMN_W, h))
    ys = list(range(n, 0, -1))
    labels, ticks = [], []
    for y, (kind, label, payload) in zip(ys, rows):
        if kind == "head":
            ax.text(-0.02, y, label, transform=ax.get_yaxis_transform(), ha="right", va="center",
                    fontsize=6, fontweight="bold")
            continue
        g, p = payload
        st = GROUP_STYLE[g]
        if kind == "pair":
            ax.plot([p["lo"], p["hi"]], [y, y], color=st["color"], lw=0.8, solid_capstyle="butt")
            ax.plot(p["v"], y, marker=st["marker"], color=st["color"], mfc=st["mfc"], ms=3.0, mew=0.7, ls="none")
            if math.isfinite(p.get("U_self", float("nan"))):
                ax.plot(p["U_self"], y, marker="|", color="#8c8c8c", ms=4.5, mew=0.8, ls="none")
        else:
            xs = [p["lo"], p["v"], p["hi"], p["v"]]
            yy = [y, y + 0.32, y, y - 0.32]
            ax.fill(xs, yy, facecolor=st["color"], edgecolor="black", lw=0.5)
        labels.append(label)
        ticks.append(y)
    for x0, ls, lw in d.get("vlines", ((0.0, "-", 0.6),)):
        ax.axvline(x0, color="black", lw=lw, ls=ls)
    ax.set_yticks(ticks)
    ax.set_yticklabels(labels, fontsize=5 if many else 6)
    for t, (kind, _l, _p) in zip(ax.get_yticklabels(), [r for r in rows if r[0] != "head"]):
        if kind == "pool":
            t.set_fontstyle("italic")
    ax.set_ylim(0.3, n + 0.7)
    ax.set_xlabel(d.get("xlabel", "Drop in concordance D = Cw(home) − Cw(after swap)"))
    ax.tick_params(axis="y", length=0)
    ax.spines["left"].set_visible(False)
    from matplotlib.lines import Line2D
    handles = [Line2D([], [], color="black", marker="D", mfc="#bbbbbb", ls="none", ms=4, label="group estimate")]
    if any(math.isfinite(p.get("U_self", float("nan"))) for g in d["groups"].values() for p in g["pairs"]):
        handles.insert(0, Line2D([], [], color="#8c8c8c", marker="|", ls="none", ms=5, mew=0.8,
                                 label="owner's self-swap upper end"))
    else:
        handles.append(Line2D([], [], color="black", ls=(0, (3, 2)), lw=0.6, label="margin θ = 0.75"))
    ax.legend(handles=handles, loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=2, fontsize=5.5,
              handletextpad=0.3, borderaxespad=0.1, columnspacing=1.0)
    _sim_mark(fig, d["sim"])
    return fig


def draw_kcurves(d: dict):
    """Decision quality and log score against the number of fresh checks k, per swap stratum; keep,
    wipe and the fixed discount as horizontal references."""
    plt = _mpl()
    groups = [g for g in GROUPS if any(k[1] == g for k in d["curves"])]
    if not groups:
        groups = list(GROUPS)
    fig, axes = plt.subplots(2, len(groups), figsize=(TEXT_W, 3.5), sharex=True, squeeze=False)
    metrics = (("value", "First-shown success"), ("log", "Held-out log score"))
    allk = sorted({p[0] for v in d["curves"].values() for p in v})
    for i, (m, ylab) in enumerate(metrics):
        for j, g in enumerate(groups):
            ax = axes[i][j]
            for ref in ("keep", "wipe", "fixed"):
                v = d["refs"].get((m, g, ref))
                if v is not None and math.isfinite(v):
                    st = REF_STYLE[ref]
                    ax.axhline(v, color=st["color"], ls=st["ls"], lw=st["lw"], zorder=1)
            for base, st in ARM_STYLE.items():
                pts = d["curves"].get((m, g, base))
                if not pts:
                    continue
                ks = np.array([p[0] for p in pts], float)
                off = 1.0 + 0.035 * (list(ARM_STYLE).index(base) - 2.5)       # dodge the error bars
                est = np.array([p[1] for p in pts])
                lo = np.array([p[2] for p in pts])
                hi = np.array([p[3] for p in pts])
                ax.errorbar(ks * off, est, yerr=[est - lo, hi - est], color=st["color"], ls=st["ls"], marker=st["marker"],
                            ms=3, mfc="white" if st["marker"] in ("s", "D") else st["color"], mew=0.7, lw=0.9,
                            elinewidth=0.5, capsize=0, zorder=3)
            ax.set_xscale("log", base=2)
            if allk:
                ax.set_xticks(allk)
                ax.set_xticklabels([str(k) for k in allk])
                ax.minorticks_off()
            if i == 0:
                ax.text(0.5, 1.02, GROUP_LABEL[g], transform=ax.transAxes, ha="center", va="bottom", fontsize=6.5)
            if j == 0:
                ax.set_ylabel(ylab)
            if i == 1:
                ax.set_xlabel("Fresh checks k")
    from matplotlib.lines import Line2D
    handles = [Line2D([], [], color=st["color"], ls=st["ls"], marker=st["marker"], ms=3,
                      mfc="white" if st["marker"] in ("s", "D") else st["color"], label=st["label"])
               for st in ARM_STYLE.values()]
    handles += [Line2D([], [], color=REF_STYLE[r]["color"], ls=REF_STYLE[r]["ls"], lw=REF_STYLE[r]["lw"],
                       label=REF_STYLE[r]["label"]) for r in ("keep", "wipe", "fixed")]
    fig.legend(handles=handles, loc="upper center", ncol=5, bbox_to_anchor=(0.5, 1.07), fontsize=6,
               handlelength=2.6, columnspacing=1.2)
    fig.tight_layout(h_pad=0.6, w_pad=0.8)
    _sim_mark(fig, d["sim"])
    return fig


def draw_online(d: dict, arms=("none", "keep", "wipe", "fixed_0.5", "recal", "own")):
    """Run-after-swap learning curves: trailing success against position in the test stream, one
    panel per swap, one line per swap-day rule."""
    plt = _mpl()
    swaps = d["swaps"]
    if not swaps:
        fig, ax = plt.subplots(figsize=(COLUMN_W, 1.5))
        ax.text(0.5, 0.5, "no post-swap run in this study", ha="center", va="center")
        ax.axis("off")
        return fig
    ncol = 4 if len(swaps) > 6 else 3
    nrow = math.ceil(len(swaps) / ncol)
    fig, axes = plt.subplots(nrow, ncol, figsize=(TEXT_W, 1.45 * nrow + 0.45), sharex=True, sharey=True,
                             squeeze=False)
    style = {"none": REF_STYLE["none"], "keep": REF_STYLE["keep"], "wipe": REF_STYLE["wipe"],
             "fixed_0.5": {**REF_STYLE["fixed"], "color": "#D55E00"},
             "recal": {"color": "#0072B2", "ls": (0, (5, 1.5)), "lw": 1.0, "label": "recalibrate (k checks)"},
             "own": REF_STYLE["own"]}
    used = {}
    for n, key in enumerate(swaps):
        ax = axes[n // ncol][n % ncol]
        cur = d["curves"][key]
        for a in arms:
            name = a
            if a == "recal":
                name = next((x for x in cur if x.startswith("recal_")), None)
            if not name or name not in cur:
                continue
            st = style[a]
            xs = [p[0] for p in cur[name]]
            ys = [p[1] for p in cur[name]]
            lbl = st["label"] if a != "recal" else f"recalibrate ({name.split('_')[1]} checks)"
            ax.plot(xs, ys, color=st["color"], ls=st["ls"], lw=st["lw"])
            used[a] = (st, lbl)
        ax.text(0.03, 0.04, f"{key[0]} → {key[1]}", transform=ax.transAxes, fontsize=5.5, va="bottom",
                bbox={"facecolor": "white", "edgecolor": "none", "pad": 0.6, "alpha": 0.85})
        ax.text(0.97, 0.04, {"upgrade": "upgrade", "downgrade": "downgrade", "cross": "cross-maker"}.get(key[2], ""),
                transform=ax.transAxes, fontsize=5, ha="right", va="bottom", color="#555555")
        if n % ncol == 0:
            ax.set_ylabel("Trailing success")
        if n // ncol == nrow - 1:
            ax.set_xlabel("Test task")
    for n in range(len(swaps), nrow * ncol):
        axes[n // ncol][n % ncol].axis("off")
    from matplotlib.lines import Line2D
    handles = [Line2D([], [], color=st["color"], ls=st["ls"], lw=st["lw"], label=lbl) for st, lbl in used.values()]
    fig.legend(handles=handles, loc="upper center", ncol=len(handles), bbox_to_anchor=(0.5, 1.04), fontsize=6,
               handlelength=2.8)
    fig.tight_layout(h_pad=0.4, w_pad=0.4)
    _sim_mark(fig, d["sim"])
    return fig


def draw_order_stakes(d: dict):
    """theta = order x stakes per ordered pair (decision D2): x = stakes, y = order, both with their
    two-way 95 % intervals (thin lines; an unbounded end is clipped to the axes); dashed curves are
    order = theta / stakes for theta = 1, 0.75 (the margin) and 0.5. Hollow, grey: order not
    identifiable (the reader's spread on its calibration tasks under 2 SE)."""
    plt = _mpl()
    fig, ax = plt.subplots(figsize=(COLUMN_W, 2.5))
    xs = [p["stakes"] for p in d["points"]]
    ys = [p["order"] for p in d["points"]]
    x_hi = max([1.6] + [x * 1.15 for x in xs])
    y_lo = min([0.0] + [y * 1.1 for y in ys])
    y_hi = max([1.4] + [y * 1.1 for y in ys])
    grid = np.linspace(max(0.05, 0.02 * x_hi), x_hi, 200)
    for th, ls in ((1.0, "-"), (0.75, (0, (3, 2))), (0.5, (0, (1, 2)))):
        y = th / grid
        ok = (y >= y_lo) & (y <= y_hi)
        ax.plot(grid[ok], y[ok], color="#888888", lw=0.6, ls=ls, zorder=0)
        j = int(np.flatnonzero(ok)[-1]) if ok.any() else None
        if j is not None:
            ax.text(grid[j], y[j] + 0.02 * (y_hi - y_lo), f"θ = {th:g}", fontsize=5, color="#444444", va="bottom",
                    ha="right", bbox={"facecolor": "white", "edgecolor": "none", "pad": 0.4, "alpha": 0.85}, zorder=1)
    for g in GROUPS:
        st = GROUP_STYLE[g]
        for p in [q for q in d["points"] if q["group"] == g]:
            col = st["color"] if p["identified"] else "#999999"
            if math.isfinite(p["stakes_lo"]) and math.isfinite(p["stakes_hi"]):
                ax.plot([p["stakes_lo"], min(p["stakes_hi"], x_hi)], [p["order"]] * 2, color=col, lw=0.5, alpha=0.6)
            if not (math.isnan(p["order_lo"]) or math.isnan(p["order_hi"])):     # unbounded set: whole axis
                lo = p["order_lo"] if math.isfinite(p["order_lo"]) else y_lo
                hi = p["order_hi"] if math.isfinite(p["order_hi"]) else y_hi
                ax.plot([p["stakes"]] * 2, [max(lo, y_lo), min(hi, y_hi)], color=col, lw=0.5, alpha=0.6)
            ax.plot(p["stakes"], p["order"], marker=st["marker"], color=col,
                    mfc=(st["mfc"] if p["identified"] else "white"), mew=0.8, ms=4.0, ls="none", zorder=3)
    ax.set_xlim(0.0, x_hi)
    ax.set_ylim(y_lo, y_hi)
    ax.set_xlabel("Stakes: how much the reader's success depends on the item, relative to the owner's")
    ax.set_ylabel("Order: how well the owner's order fits the reader")
    from matplotlib.lines import Line2D
    handles = [Line2D([], [], marker=GROUP_STYLE[g]["marker"], color=GROUP_STYLE[g]["color"],
                      mfc=GROUP_STYLE[g]["mfc"], ls="none", ms=4, label=GROUP_LABEL[g])
               for g in GROUPS if any(p["group"] == g for p in d["points"])]
    if any(not p["identified"] for p in d["points"]):
        handles.append(Line2D([], [], marker="o", color="#999999", mfc="white", ls="none", ms=4,
                              label="order not identifiable"))
    ax.legend(handles=handles, loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=2, fontsize=5.5,
              handletextpad=0.3, borderaxespad=0.1, columnspacing=1.0)
    ax.xaxis.label.set_size(6)
    ax.yaxis.label.set_size(6)
    _sim_mark(fig, d["sim"])
    return fig


def draw_p1(d: dict):
    """Validity against cross-model agreement (P1): one point per ordered pair."""
    plt = _mpl()
    fig, ax = plt.subplots(figsize=(COLUMN_W, 2.35))
    for g in GROUPS:
        pts = [p for p in d["points"] if p["group"] == g]
        if not pts:
            continue
        st = GROUP_STYLE[g]
        ax.plot([p["kappa"] for p in pts], [p["R"] for p in pts], ls="none", marker=st["marker"], color=st["color"],
                mfc=st["mfc"], mew=0.8, ms=4.2, label=GROUP_LABEL[g])
    ax.axhline(1.0, color="#999999", lw=0.6, ls=(0, (2, 2)))
    ax.axhline(0.0, color="#999999", lw=0.6, ls=(0, (1, 2)))
    ax.set_xlabel("Agreement of owner and reader on the same cells (Cohen's κ)")
    ax.set_ylabel("Retained ranking signal θ")
    ax.legend(loc="best", fontsize=6, handletextpad=0.3)
    _sim_mark(fig, d["sim"])
    return fig


def draw_shapley(d: dict):
    """Realism check: one-item-at-a-time results against exact Shapley values of the same item."""
    plt = _mpl()
    fig, ax = plt.subplots(figsize=(COLUMN_W, 2.35))
    rng = np.random.default_rng(0)
    kinds = [k for k in ("home", "upgrade", "downgrade", "cross") if any(p["kind"] == k for p in d["points"])]
    width = 0.32 / max(1, len(kinds))
    for n, k in enumerate(kinds):
        pts = [p for p in d["points"] if p["kind"] == k and math.isfinite(p["single"]) and math.isfinite(p["shapley"])]
        if not pts:
            continue
        st = GROUP_STYLE.get(k, GROUP_STYLE["cross"])
        x = np.array([p["single"] for p in pts])
        y = np.array([p["shapley"] for p in pts])
        off = (n - (len(kinds) - 1) / 2) * width * 1.6
        xj = x + off + rng.uniform(-width / 2, width / 2, size=len(x))
        ax.scatter(xj, y, s=3, marker=st["marker"], facecolors=st["mfc"] if st["mfc"] != "white" else "none",
                   edgecolors=st["color"], linewidths=0.4, alpha=0.55, label=GROUP_LABEL.get(k, k), rasterized=True)
        for v in np.unique(x):
            sel = y[x == v]
            if sel.size:
                ax.plot([v + off - width * 0.8, v + off + width * 0.8], [np.median(sel)] * 2, color="black", lw=1.0)
    ax.axhline(0.0, color="#999999", lw=0.5)
    ax.set_xticks([0.0, 0.5, 1.0])
    ax.set_xticklabels(["0", "0.5", "1"])
    ax.set_xlabel("Success with the item shown alone (mean of 2 repeats)")
    ax.set_ylabel("Exact Shapley value of the item")
    leg = ax.legend(loc="upper left", fontsize=6, markerscale=2.5, handletextpad=0.2)
    for h in leg.legend_handles:
        h.set_alpha(1)
    _sim_mark(fig, d["sim"])
    return fig


# ---------------------------------------------------------------------------
# One call per figure, and all of them
# ---------------------------------------------------------------------------


def fig_theta_grid(adir, out_dir) -> list:
    d = load_theta_grid(adir)
    if not d["cells"]:
        return []
    return _save(draw_grid(d), out_dir, "fig1_theta_grid")


def fig_forest_theta(adir, out_dir) -> list:
    d = load_forest_theta(adir)
    if not d["groups"]:
        return []
    return _save(draw_forest(d), out_dir, "fig_forest_theta")


def fig_order_stakes(adir, out_dir) -> list:
    d = load_order_stakes(adir)
    if not d["points"]:
        return []
    return _save(draw_order_stakes(d), out_dir, "fig1b_order_stakes")


def fig_retained_grid(adir, out_dir) -> list:
    d = load_grid(adir)
    if not d["cells"]:
        return []
    return _save(draw_grid(d), out_dir, "fig1_retained_validity_grid")


def fig_forest_drop(adir, out_dir) -> list:
    d = load_forest(adir)
    if not d["groups"]:
        return []
    return _save(draw_forest(d), out_dir, "fig_forest_drop")


def fig_arms_k(adir, out_dir) -> list:
    d = load_kcurves(adir)
    if not d["curves"]:
        return []
    return _save(draw_kcurves(d), out_dir, "fig_arms_vs_checks")


def fig_online(adir, out_dir) -> list:
    d = load_online(adir)
    if not d["swaps"]:
        return []
    lam = load_meta(adir).get("primary_lambda", "0.5")
    return _save(draw_online(d, arms=("none", "keep", "wipe", f"fixed_{float(lam):g}", "recal", "own")), out_dir,
                 "fig_run_after_swap")


def fig_p1(adir, out_dir) -> list:
    d = load_p1(adir)
    if not d["points"]:
        return []
    return _save(draw_p1(d), out_dir, "fig_p1_validity_vs_agreement")


def fig_shapley(adir, out_dir) -> list:
    d = load_shapley(adir)
    if not d["points"]:
        return []
    return _save(draw_shapley(d), out_dir, "fig_shapley_realism")


#: fig1_theta_grid and fig_forest_theta carry the headline (round-1 revision); the R grid and the D forest
#: stay as secondary figures under their old file names.
#: fig1b_order_stakes (revision 2) supports Figure 1's caption theta = order x stakes.
FIGURES = (fig_theta_grid, fig_forest_theta, fig_order_stakes, fig_retained_grid, fig_forest_drop, fig_arms_k,
           fig_online, fig_p1, fig_shapley)


def make_all(adir, out_dir, printer=print) -> list:
    """Every figure whose data exist; a figure without data is skipped with a one-line note."""
    paths = []
    for f in FIGURES:
        got = f(Path(adir), Path(out_dir))
        if not got and printer:
            printer(f"  [figures] {f.__name__}: no data in this study, skipped")
        paths += got
    return paths


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Draw the paper's figures from an analysis folder.")
    ap.add_argument("--analysis", required=True, help="runs/<study>/analysis")
    ap.add_argument("--out", default=str(ROOT / "paper" / "assets"))
    a = ap.parse_args(argv)
    for p in make_all(a.analysis, a.out):
        print(p)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
