"""Prompts exactly as StreamBench (commit cf72f26) builds them.

Sources copied (stream-bench/stream_bench/...):
  benchmarks/ddxplus.py      get_zeroshot_prompt, get_fewshot_template, get_shot_template,
                             get_memprompt_template, option_text (all 49 labels, "0. ..."-"48. ...")
  benchmarks/text_to_sql.py  get_zeroshot_prompt, get_fewshot_template, get_shot_template,
                             get_memprompt_template
  benchmarks/text2sql_utils/string_formatter.py  generate_schema_prompt (CREATE statements only)
  agents/fewshot_rag.py      how retrieved memory is put in the prompt (FewShotRAGAgent.__call__)
                             and how a solved task becomes a memory item (FewShotRAGAgent.update)
  benchmarks/utils.py        strip_all_lines

StreamBench sends ONE user message and no system prompt (llms/claude.py, llms/oai_chat.py),
so ``build_prompt`` returns that user text, and ``build_messages`` returns (None, user).

Memory: with no items the agent uses the zero-shot prompt; with k items it fills the
few-shot template, items joined by a blank-line gap ("\\n\\n\\n"), in the order given
(StreamBench's configs retrieve top-16 and put the MOST similar item LAST).
A memory item ("shot") is the past task's question plus the agent's own parsed answer:
  ddxplus: "<patient profile>\\nDiagnosis: <n>. <diagnosis>"
  bird:    "Question: <question>\\n<SQL>"   (no database name and no schema)
self_stream_icl stores only answers graded correct; mem_prompt (style="memprompt") stores
every answer with "Your answer is correct" / "Your answer is not correct".
The bird ``evidence`` column is never used, as in StreamBench.
"""
from __future__ import annotations

import json
import random
import re
import textwrap
from functools import lru_cache
from pathlib import Path

from msr.data import DATA_DIR, LABEL2TEXT, bird_db_path, get_label_text, load_stream
from msr.grade import connect_readonly, parse_ddxplus, parse_sql


def strip_all_lines(s: str) -> str:
    """Remove all leading and trailing spaces of each line in the string."""
    return '\n'.join([line.strip() for line in s.splitlines()])


# MedicalDiagnosisBench.__init__
OPTION_TEXT = '\n'.join([f"{str(k)}. {v}" for k, v in LABEL2TEXT.items()])


# ----------------------------------------------------------------------------- ddxplus
def ddxplus_zeroshot_prompt(profile: str, option_text: str = OPTION_TEXT) -> str:
    prompt = textwrap.dedent(f"""\
    Act as a medical doctor and diagnose the patient based on the following patient profile:

    {profile}

    All possible diagnoses for you to choose from are as follows (one diagnosis per line, in the format of <number>. <diagnosis>):
    {option_text}

    Now, directly provide the diagnosis for the patient in the following format: <number>. <diagnosis>""")
    return strip_all_lines(prompt)


def ddxplus_fewshot_template(profile: str, option_text: str = OPTION_TEXT) -> str:
    prompt = textwrap.dedent(f"""\
    Act as a medical doctor and diagnose the patient based on the provided patient profile.

    All possible diagnoses for you to choose from are as follows (one diagnosis per line, in the format of <number>. <diagnosis>):
    {option_text}

    Here are some example cases.

    {{fewshot_text}}

    Now it's your turn.

    {profile}

    Now provide the diagnosis for the patient in the following format: <number>. <diagnosis>""")
    return strip_all_lines(prompt)


def ddxplus_shot_template() -> str:
    prompt = textwrap.dedent(f"""\
    {{question}}
    Diagnosis: {{answer}}""")
    return strip_all_lines(prompt)


def ddxplus_memprompt_template() -> str:
    prompt = textwrap.dedent(f"""\
    {{question}}
    Your answer: {{answer}}
    User Feedback: {{correctness}}""")
    return strip_all_lines(prompt)


# ----------------------------------------------------------------------------- bird
@lru_cache(maxsize=None)
def bird_schema(db_id: str) -> str:
    """generate_schema_prompt(db_path) with num_rows=None, on a read-only connection.

    Faithful detail: StreamBench's `if table == 'sqlite_sequence'` compares a tuple with a
    string, so it never skips; the sqlite_sequence CREATE statement is included when present.
    """
    full_schema_prompt_list = []
    conn = connect_readonly(bird_db_path(db_id))
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = cursor.fetchall()
        schemas = {}
        for table in tables:
            cursor.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name=?;", (table[0],))
            schemas[table[0]] = cursor.fetchone()[0]
    finally:
        conn.close()
    for v in schemas.values():
        full_schema_prompt_list.append(v)
    return "\n\n".join(full_schema_prompt_list)


def bird_zeroshot_prompt(schema: str, question: str) -> str:
    prompt = textwrap.dedent(f"""\
    {schema}

    -- Using valid SQLite, answer the following question for the tables provided above.
    -- Question: {question}

    Now, generate the correct SQL code directly (Do NOT generate other text except the SQL code):""")
    return strip_all_lines(prompt)


def bird_fewshot_template(schema: str, question: str) -> str:
    prompt = textwrap.dedent(f"""\
    You are performing the text-to-SQL task. Here are some examples:

    {{fewshot_text}}

    Now it's your turn.

    -- SQL schema: {schema}
    -- Using valid SQLite, answer the following question for the SQL schema provided above.
    -- Question: {question}

    Now, generate the correct SQL code directly (Do NOT generate other text except the SQL code):""")
    return strip_all_lines(prompt)


def bird_shot_template() -> str:
    prompt = textwrap.dedent(f"""\
    Question: {{question}}
    {{answer}}""")
    return prompt


def bird_memprompt_template() -> str:
    prompt = textwrap.dedent(f"""\
    Question: {{question}}
    Your SQL code: {{answer}}
    User Feedback: {{correctness}}""")
    return prompt


# ----------------------------------------------------------------------------- public API
def _templates(stream: str, task: dict) -> tuple[str, str]:
    """(zero-shot prompt, few-shot template with the {fewshot_text} slot) for one task."""
    if stream == "ddxplus":
        profile = task["question"] if "question" in task else task["PATIENT_PROFILE"].strip()
        return ddxplus_zeroshot_prompt(profile), ddxplus_fewshot_template(profile)
    if stream == "bird":
        schema = bird_schema(task["db_id"])
        return (bird_zeroshot_prompt(schema=schema, question=task["question"]),
                bird_fewshot_template(schema=schema, question=task["question"]))
    raise ValueError(f"unknown stream {stream!r}")


def _item_text(item) -> str:
    return item if isinstance(item, str) else item["text"]


def build_prompt(stream: str, task: dict, memory_items: list | None = None) -> str:
    """The user message StreamBench sends for `task` with these memory items shown.

    memory_items: [] -> zero-shot prompt; otherwise items from memory_item_from (or their
    text strings), placed in the given order.
    """
    zeroshot, fewshot_template = _templates(stream, task)
    shots = [_item_text(m) for m in (memory_items or [])]
    if not shots:
        return zeroshot
    # FewShotRAGAgent.__call__ (backslashes doubled because re.sub reads the replacement)
    fewshot_text = "\n\n\n".join(shots).replace("\\", "\\\\")
    return re.sub(pattern=r"\{fewshot_text\}", repl=fewshot_text, string=fewshot_template)


def build_messages(stream: str, task: dict, memory_items: list | None = None) -> tuple[None, str]:
    """(system, user) for an LLM call. StreamBench has no system prompt, so system is None."""
    return None, build_prompt(stream, task, memory_items)


def normalize_answer(stream: str, answer, faithful: bool = True) -> str:
    """The answer the way StreamBench stores it (give_feedback 'self_output')."""
    if stream == "ddxplus":
        return get_label_text(answer if isinstance(answer, int) else parse_ddxplus(answer))
    if stream == "bird":
        return parse_sql(answer, faithful=faithful)
    raise ValueError(f"unknown stream {stream!r}")


def memory_item_from(stream: str, task: dict, answer, *, style: str = "shot",
                     correct: bool | None = None, parse: bool = True,
                     faithful: bool = True) -> dict:
    """The stored memory item for a solved task.

    answer : the model's raw answer (parsed the StreamBench way when parse=True), or a
             ddxplus label int. Pass parse=False to store `answer` verbatim (e.g. a gold SQL
             that starts with WITH, which StreamBench's parse_sql would break).
    style  : "shot" = self_stream_icl item (question + answer; StreamBench keeps only correct ones)
             "memprompt" = mem_prompt item (also says whether the answer was correct; needs `correct`).
    """
    if stream not in ("ddxplus", "bird"):
        raise ValueError(f"unknown stream {stream!r}")
    if parse:
        ans = normalize_answer(stream, answer, faithful=faithful)
    else:
        ans = get_label_text(answer) if (stream == "ddxplus" and isinstance(answer, int)) else str(answer)
    question = task["question"]
    if style == "shot":
        tmpl = ddxplus_shot_template() if stream == "ddxplus" else bird_shot_template()
        text = tmpl.format(question=question, answer=ans)
    elif style == "memprompt":
        if correct is None:
            raise ValueError("style='memprompt' needs correct=True/False")
        tmpl = ddxplus_memprompt_template() if stream == "ddxplus" else bird_memprompt_template()
        corr_verb = "correct" if correct else "not correct"
        text = tmpl.format(question=question, answer=ans, correctness=f"Your answer is {corr_verb}")
    else:
        raise ValueError(f"unknown style {style!r}")
    return {"stream": stream, "task_id": task.get("task_id"), "question": question,
            "answer": ans, "style": style, "correct": correct, "text": text}


# ----------------------------------------------------------------------------- sizes
def _stats(values: list[float]) -> dict:
    import numpy as np
    a = np.asarray(values, dtype=float)
    return {"n": int(a.size), "mean": round(float(a.mean()), 1), "median": round(float(np.median(a)), 1),
            "p90": round(float(np.percentile(a, 90)), 1), "max": round(float(a.max()), 1)}


def measure_prompt_sizes(save: bool = True, seed: int = 0) -> dict:
    """Token estimates (chars/4) over every test task: zero-shot and with one memory item.

    The one item is a different, randomly chosen task of the same stream with its gold
    answer (style "shot", stored verbatim), standing in for a solved build task.
    """
    out = {"method": "tokens = len(prompt) / 4 over all tasks of each stream; one memory item = "
                     "a random other task of the same stream with its gold answer, self_stream_icl "
                     f"'shot' format; random.Random({seed})",
           "streams": {}}
    for stream in ("ddxplus", "bird"):
        tasks = load_stream(stream)
        rng = random.Random(seed)
        zs, one, item = [], [], []
        for i, t in enumerate(tasks):
            j = rng.randrange(len(tasks) - 1)
            j = j + 1 if j >= i else j
            m = memory_item_from(stream, tasks[j], tasks[j]["answer"], parse=False)
            zs.append(len(build_prompt(stream, t, [])) / 4)
            one.append(len(build_prompt(stream, t, [m])) / 4)
            item.append(len(m["text"]) / 4)
        out["streams"][stream] = {"zero_shot": _stats(zs), "one_memory_item": _stats(one),
                                  "memory_item_alone": _stats(item)}
    if save:
        path = DATA_DIR / "prompt_sizes.json"
        path.write_text(json.dumps(out, indent=2), encoding="utf-8")
        out["saved_to"] = str(path)
    return out


if __name__ == "__main__":
    res = measure_prompt_sizes()
    for stream, d in res["streams"].items():
        for k, s in d.items():
            print(f"{stream:8s} {k:18s} mean {s['mean']:7.1f}  median {s['median']:7.1f}  "
                  f"p90 {s['p90']:7.1f}  max {s['max']:7.1f}  (n={s['n']})")
    print("saved:", res.get("saved_to"))
