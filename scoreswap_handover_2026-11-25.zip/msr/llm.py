"""One way to call every model in the study, with a record of every call.

Everyday picture: a lab notebook at the counter. Every time we ask a model
something, we write down what we asked (the prompt, stored once by its
fingerprint), what came back (the raw answer, unchanged), which exact model
answered, when, how many tokens it used and what it cost. The paper needs
this because the closed models will retire and the runs cannot be repeated.

Rules this file keeps:
- Anthropic models are called with the official Anthropic SDK; OpenAI,
  OpenRouter and the Qwen hosts with the OpenAI SDK (they are OpenAI-compatible).
- No temperature is sent to the closed models: current Claude models reject
  it. The open-weight models carry explicit sampling values in their
  extra_body (config/models.yaml), the same on both models of a pair. No seed
  is sent to anyone: repeats come from asking again.
- The request settings that make each model what it is (route, exact API
  name, thinking, sampling, host pin) are written once per run to
  runs/<run>/model_settings.json. Keys and headers are never written.
- When the route says which company actually ran the model (OpenRouter can
  say "DeepInfra"), that name is kept in CallResult.served_by.
- A rejected request (bad parameter, unknown model) raises an error. It is
  never turned into a fake "answer" that silently grades as wrong.
- A spending cap (config/models.yaml -> budget.hard_cap_usd) stops calls
  before they would pass it.
- Answers are cached by (model, prompt, repeat number), so re-running a
  script never pays twice for the same call.
- dry_run=True (or env MSR_DRY_RUN=1) answers with a fixed fake reply and
  calls nothing, for testing the pipeline without spending.
- Models with provider "sim" (config/models.yaml) are answered by msr/sim.py,
  a free simulated model with a known truth: no key, cost 0, not cached, logged.
- Models with provider "opencode_cli" are free promotional models reached through the
  opencode command-line tool (msr/opencode_route.py), for PRELIMINARY runs only: no key,
  price 0, served_by "opencode-cli <version>", cached like other real calls. A failed
  call raises; it is never stored as an answer.
- Every paid answer is checked against the request (check_served): the model that answered
  must be the one asked for, and on OpenRouter the host must be the pinned one. A mismatch
  stops the run (ServedModelMismatch) and the answer is never cached. Answers read back from
  the cache are checked too, so a run resumed from an old cache also stops. Like a pharmacist
  reading the box before handing it over: DeepInfra silently forwards a retired model to its
  successor, and the label is the only way to see it. Simulated, dry-run and opencode calls
  are not checked.
- The answer cache, the prompt store and the spend file are written to a temporary file in
  the same folder first and then swapped in (os.replace), so a stop halfway never leaves a
  cut file. A cache file that cannot be read counts as missing (the call is asked again and
  the file rewritten); a prompt file of the wrong size is rewritten. The spend file keeps a
  backup copy (spend.json.bak, written first, so it never holds less than spend.json); if
  spend.json cannot be read, the larger readable copy is used, and if neither can be read
  every paid call stops (SpendFileUnreadable): a lost spend file never resets the count to 0.
- Reasoning: CallResult.reasoning_tokens is what the host reported (OpenAI-style
  usage.completion_tokens_details.reasoning_tokens, OpenRouter's usage), else None;
  CallResult.reasoning_fields names the reasoning or thinking parts the reply carried
  (scripts/smoke_test.py fails when a model with reasoning switched off returns any).
"""
from __future__ import annotations

import hashlib
import json
import locale
import os
import re
import sys
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict, dataclass, field, fields
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterable

import yaml

ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = ROOT / "config" / "models.yaml"
RUNS = ROOT / "runs"
SPEND_PATH = RUNS / "spend.json"


def load_config(path: Path = CONFIG_PATH) -> dict:
    with open(path, encoding="utf-8") as f:
        return yaml.safe_load(f)


def load_env() -> None:
    """Read keys from .env in this folder into the process (never printed)."""
    env = ROOT / ".env"
    if not env.exists():
        return
    for line in env.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        k, v = k.strip(), v.strip().strip('"').strip("'")
        if k and v and not os.environ.get(k):
            os.environ[k] = v


def opencode_key(provider: str) -> str | None:
    """The API key that the opencode tool already holds for a provider, if any.

    The owner allowed this on 23 Nov 2026 ("use the Anthropic key that is in opencode").
    It is read into memory only when a provider in config/models.yaml says
    `key_from_opencode: true` and no key is set in .env. It is never printed, logged,
    cached or written to any file by this code. Returns None when there is no such key.
    """
    base = os.environ.get("XDG_DATA_HOME") or str(Path.home() / ".local" / "share")
    path = Path(base) / "opencode" / "auth.json"
    try:
        entry = json.loads(path.read_text(encoding="utf-8")).get(provider) or {}
    except (OSError, ValueError):
        return None
    if entry.get("type") == "api" and isinstance(entry.get("key"), str) and entry["key"]:
        return entry["key"]
    return None


def provider_key(cfg: dict, provider: str) -> str | None:
    """The key for a provider: .env or the environment first, then opencode if allowed."""
    p = cfg["providers"].get(provider) or {}
    key = os.environ.get(p["key_env"]) if p.get("key_env") else None
    if not key and p.get("key_from_opencode"):
        key = opencode_key(provider)
    return key


def sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


@dataclass
class CallResult:
    call_id: str
    model: str            # our name, e.g. "haiku-5.5"
    model_id: str         # what the API says answered (exact version)
    called_at: str
    prompt_sha256: str
    answer: str
    tokens_in: int
    tokens_out: int
    cost_usd: float
    stop_reason: str | None
    latency_s: float
    fingerprint: str | None = None
    cached: bool = False
    meta: dict = field(default_factory=dict)
    # Which company actually ran the model, when the route tells us (OpenRouter
    # can say "DeepInfra"). None for Anthropic, dry runs and simulated models.
    # Old cache files do not have this field; they still load (it defaults to None).
    served_by: str | None = None
    # Reasoning (thinking) tokens the host reported: OpenAI-style
    # usage.completion_tokens_details.reasoning_tokens or OpenRouter's usage. None when the
    # route does not say (Anthropic, simulated, dry runs, old cache files).
    reasoning_tokens: int | None = None
    # The reasoning or thinking parts the reply carried, by name ("reasoning",
    # "reasoning_content", "thinking block", ...): [] when the reply was looked at and had
    # none, None when it was not looked at (simulated, dry runs, opencode, old cache files).
    reasoning_fields: list | None = None
    # Prompt-cache indicators the host reported (input tokens read from / written to its prompt
    # cache). Logged for every call because a provider-side cache could make two repeats of one
    # prompt agree more often (pre-registration Parts 3-4: repeat 2 runs in a later session).
    # None when the route does not say (simulated, dry runs, old cache files).
    cache_read_tokens: int | None = None
    cache_write_tokens: int | None = None
    # When the request was sent (UTC); called_at is when the answer came back. Logged so a later
    # session's first call can be checked against the earlier session's last one (Part 2.4).
    started_at: str | None = None


class BudgetExceeded(RuntimeError):
    pass


class SpendFileUnreadable(BudgetExceeded):
    """runs/spend.json and its backup copy both exist but neither can be read. Every paid call
    stops (a lost count must never read as $0 spent). A kind of BudgetExceeded, so a run that
    stops cleanly at the cap also stops cleanly here."""


class ServedModelMismatch(RuntimeError):
    """The model (or the host) that answered is not the one the request named. The run stops;
    the answer is never cached."""


def _write_atomic(path: Path, text: str) -> None:
    """Write text to a temporary file in the same folder, then swap it in (os.replace), so a
    stop halfway leaves either the old file or the new one, never a cut one."""
    tmp = path.with_name(f"{path.name}.{uuid.uuid4().hex[:12]}.tmp")
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(text)
        os.replace(tmp, path)
    except BaseException:
        try:
            tmp.unlink()
        except OSError:
            pass
        raise


def _read_text_any(path: Path) -> str:
    """A file written as UTF-8 (or, by older code, in the system's own encoding)."""
    raw = path.read_bytes()
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        return raw.decode(locale.getpreferredencoding(False))


# ---------- the spend file ----------
_SPEND_LOCK = threading.Lock()        # one writer at a time in this process (all LLM objects)
_spend_warned: set = set()


def _spend_backup(path: Path) -> Path:
    return path.with_name(path.name + ".bak")


def _read_spend_file(path: Path) -> dict | None:
    """The spend record in one file, or None when it cannot be read (cut, empty, not JSON)."""
    try:
        data = json.loads(_read_text_any(path))
        total = float(data["total_usd"])
        if total != total or not isinstance(data.get("by_model", {}), dict):   # NaN or a bad shape
            return None
        return data
    except (OSError, ValueError, TypeError, KeyError, UnicodeDecodeError):
        return None


def read_spend(path: Path | None = None) -> dict:
    """What has been spent: {"total_usd", "by_model", ...} from runs/spend.json and its backup
    runs/spend.json.bak. The backup is written first, so it never holds less than the main file;
    of the copies that can be read, the one with the larger total wins (overstating the spend is
    safe for the cap, understating it is not). No file at all means nothing spent yet. Files that
    exist but cannot be read raise SpendFileUnreadable, naming them. (To reset the count on
    purpose, delete both files.)"""
    path = SPEND_PATH if path is None else path
    good, bad = [], []
    for p in (path, _spend_backup(path)):
        if not p.exists():
            continue
        d = _read_spend_file(p)
        (good if d is not None else bad).append((p, d))
    if not good and bad:
        raise SpendFileUnreadable(
            f"Stopping: the spend record cannot be read ({', '.join(str(p) for p, _ in bad)}), so the "
            f"spending cap cannot be checked. Every paid call stops until it is repaired: restore the "
            f"file from a copy, or rebuild the total from the cost_usd of the calls in runs/*/calls.jsonl "
            f"that are not cached. It is never treated as $0 spent.")
    if not good:
        return {"total_usd": 0.0, "by_model": {}}
    chosen_path, chosen = max(good, key=lambda pd: float(pd[1]["total_usd"]))
    if bad and str(path) not in _spend_warned:
        _spend_warned.add(str(path))
        print(f"Warning: {', '.join(str(p) for p, _ in bad)} could not be read; using {chosen_path} "
              f"(${float(chosen['total_usd']):.4f}). The next paid call rewrites both copies.", file=sys.stderr)
    return chosen


# ---------- the served-model check ----------
# A date or version after the asked name: "-20261001", "-2026-11-01", "-v3-0324", ":2", "@001".
_VERSION_SUFFIX = re.compile(r"[-_.:@]v?\d[\w.:@-]*")
# Routes whose answers are not checked: simulated models and the opencode wrapper.
_UNCHECKED_PROVIDERS = {"sim", "opencode_cli"}


def _host_word(name) -> str:
    """A host name in one form for comparing: lower case, letters and digits only."""
    return re.sub(r"[^a-z0-9]", "", str(name).lower())


def pinned_hosts(m: dict) -> list:
    """The hosts a model is pinned to on OpenRouter (extra_body.provider.only), as bare host
    names: "deepinfra/fp8" -> "deepinfra". [] when there is no pin."""
    only = ((m.get("extra_body") or {}).get("provider") or {}).get("only") or []
    if isinstance(only, str):
        only = [only]
    return [str(s).split("/", 1)[0] for s in only]


def _same_model_name(served: str, asked: str, any_suffix: bool) -> bool:
    """served == asked, or asked followed by a date/version suffix (any suffix when any_suffix)."""
    if served == asked:
        return True
    if not served.startswith(asked):
        return False
    return any_suffix or bool(_VERSION_SUFFIX.fullmatch(served[len(asked):]))


def check_served(cfg: dict, model: str, model_id: str | None, served_by: str | None) -> list:
    """Check that an answer came from the model (and host) the request named.

    Raises ServedModelMismatch when it did not. Returns notes on what could not be checked
    ([] when everything was checked and fine). The rules:
    - Anthropic and OpenAI: the reported model must be the configured api_model or start with
      it (a dated name such as claude-haiku-5-5-20261001).
    - OpenRouter and the other OpenAI-compatible hosts: the reported model must be api_model,
      or api_model followed only by a date or version suffix (qwen/qwen3.8-27b-20261101).
    - On every route: a reported name that is (or extends) the api_model of ANOTHER configured
      model, longer than this one, is that other model. This catches a retired model forwarded to
      its successor whose name extends it (deepseek-v4.1-flash -> deepseek-v4.1-flash-1017).
    - OpenRouter with a host pin (extra_body.provider.only): the host OpenRouter names
      (served_by, e.g. "DeepInfra") must be one of the pinned hosts ("deepinfra/fp8" ->
      deepinfra), compared in lower case with letters and digits only. When OpenRouter names
      no host, nothing stops: a note says the pin was not checked.
    - A reply that names no model at all cannot be checked, and stops.
    Simulated and opencode models are not checked (they return [])."""
    m = cfg["models"][model]
    provider = m.get("provider")
    if provider in _UNCHECKED_PROVIDERS:
        return []
    asked = str(m.get("api_model") or "").lower()
    served = str(model_id or "").strip().lower()
    if not served:
        raise ServedModelMismatch(
            f"{model}: the reply did not say which model answered (asked for {m.get('api_model')}); "
            f"the run stops because the answer cannot be checked.")
    any_suffix = provider in ("anthropic", "openai")
    if not _same_model_name(served, asked, any_suffix):
        raise ServedModelMismatch(
            f"{model}: asked for {m.get('api_model')} but {model_id} answered. The host may have "
            f"retired the model and forwarded the call to another one. The run stops; this answer "
            f"is not cached.")
    for other, om in (cfg.get("models") or {}).items():
        other_name = str((om or {}).get("api_model") or "").lower()
        if (len(other_name) > len(asked) and other_name.startswith(asked)
                and _same_model_name(served, other_name, False)):
            raise ServedModelMismatch(
                f"{model}: asked for {m.get('api_model')} but {model_id} answered, which is the "
                f"name of another model ({other}: {om.get('api_model')}). The host may have forwarded "
                f"a retired model to its successor. The run stops; this answer is not cached.")
    notes = []
    hosts = pinned_hosts(m) if provider == "openrouter" else []
    if hosts:
        if served_by is None or not str(served_by).strip():
            notes.append(f"host pin {'/'.join(hosts)} not checked: the reply did not name the host")
        elif _host_word(served_by) not in {_host_word(h) for h in hosts}:
            only = ((m.get("extra_body") or {}).get("provider") or {}).get("only")
            raise ServedModelMismatch(
                f"{model}: pinned to {only} but {served_by} served it. The run stops; this answer "
                f"is not cached.")
    return notes


def _field(obj, name: str):
    """obj.name, obj[name] or obj.model_extra[name] (the OpenAI SDK keeps fields it does not
    know, such as OpenRouter's, in model_extra); None when absent."""
    if obj is None:
        return None
    if isinstance(obj, dict):
        return obj.get(name)
    v = getattr(obj, name, None)
    if v is None:
        v = (getattr(obj, "model_extra", None) or {}).get(name)
    return v


def _reasoning_tokens(usage) -> int | None:
    """Reasoning tokens from an answer's usage, or None when the host does not report them."""
    for holder in ("completion_tokens_details", "output_tokens_details"):
        n = _field(_field(usage, holder), "reasoning_tokens")
        if n is not None:
            return int(n)
    n = _field(usage, "reasoning_tokens")
    return int(n) if n is not None else None


def _has_content(v) -> bool:
    if v is None:
        return False
    if isinstance(v, str):
        return bool(v.strip())
    if isinstance(v, (list, tuple, dict)):
        return len(v) > 0
    return True


# Reasoning parts an OpenAI-compatible reply can carry in its message.
_REASONING_FIELDS = ("reasoning", "reasoning_content", "reasoning_details", "thinking")


# Field names that could hold a secret. They are dropped before any settings are
# written to disk, in case someone ever puts one inside extra_body by mistake.
_SECRET_NAMES = {"api_key", "apikey", "key", "secret", "token", "access_token",
                 "authorization", "headers", "extra_headers", "x-api-key"}


def _without_secrets(obj: Any) -> Any:
    """A copy of obj with every secret-looking field removed, at any depth."""
    if isinstance(obj, dict):
        return {k: _without_secrets(v) for k, v in obj.items()
                if str(k).lower() not in _SECRET_NAMES}
    if isinstance(obj, (list, tuple)):
        return [_without_secrets(v) for v in obj]
    return obj


class LLM:
    """Call any configured model and log it.

    llm = LLM(run_name="pilot_ddx")
    r = llm.call("haiku-5.5", user="...", system="...", meta={"task_id": ..., "arm": ...})
    """

    def __init__(self, run_name: str, dry_run: bool | None = None,
                 config: dict | None = None, max_tokens: int = 1024):
        load_env()
        self.cfg = config or load_config()
        self.run_dir = RUNS / run_name
        (self.run_dir / "prompts").mkdir(parents=True, exist_ok=True)
        self.calls_path = self.run_dir / "calls.jsonl"
        self.cache_path = RUNS / "_cache"
        self.cache_path.mkdir(parents=True, exist_ok=True)
        self.dry_run = (os.environ.get("MSR_DRY_RUN") == "1") if dry_run is None else dry_run
        self.max_tokens = max_tokens
        self._lock = threading.Lock()
        self._clients: dict[str, Any] = {}
        self._settings_recorded: set[str] = set()   # models already in model_settings.json

    # ---------- clients ----------
    def _client(self, provider: str):
        if provider in self._clients:
            return self._clients[provider]
        p = self.cfg["providers"][provider]
        key = provider_key(self.cfg, provider)
        if not key:
            raise RuntimeError(
                f"No key for provider '{provider}': put {p['key_env']}=... in .env "
                f"(see .env.example). Keys are never printed or logged.")
        if provider == "anthropic":
            import anthropic
            client = anthropic.Anthropic(api_key=key, max_retries=5)
        else:
            import openai
            client = openai.OpenAI(api_key=key, base_url=p.get("base_url"), max_retries=5)
        self._clients[provider] = client
        return client

    # ---------- money ----------
    def spent(self) -> float:
        """Dollars spent so far in this folder (read_spend: never 0 for a file it cannot read)."""
        return float(read_spend()["total_usd"])

    def _add_spend(self, usd: float, model: str) -> None:
        """Add a call's cost to runs/spend.json. The backup copy is written first, then the main
        file, each through a temporary file; the MemRL leg's lock file (spend.json.lock) is held
        where the system has file locks, so the two writers never lose each other's cost."""
        path = SPEND_PATH
        path.parent.mkdir(parents=True, exist_ok=True)
        with _SPEND_LOCK:
            lock_file = None
            try:
                try:
                    import fcntl
                    lock_file = open(str(path) + ".lock", "a")
                    fcntl.flock(lock_file, fcntl.LOCK_EX)
                except ImportError:   # Windows: no fcntl; the in-process lock still holds
                    lock_file = None
                data = read_spend(path)
                data.setdefault("by_model", {})
                data["total_usd"] = round(float(data["total_usd"]) + usd, 6)
                data["by_model"][model] = round(data["by_model"].get(model, 0.0) + usd, 6)
                data["updated_at"] = now()
                text = json.dumps(data, indent=2)
                _write_atomic(_spend_backup(path), text)
                _write_atomic(path, text)
            finally:
                if lock_file is not None:
                    lock_file.close()   # closing releases the lock

    def worst_case_cost(self, model: str, user: str, system: str | None, max_tokens: int) -> float:
        m = self.cfg["models"][model]
        est_in = (len(user) + len(system or "")) / 3.0   # generous chars-per-token
        return (est_in * m["price_in"] + max_tokens * m["price_out"]) / 1e6

    def _cost(self, model: str, tin: int, tout: int, cache_read: int = 0, cache_write: int = 0) -> float:
        m = self.cfg["models"][model]
        return (tin * m["price_in"] + cache_read * m["price_in"] * 0.1
                + cache_write * m["price_in"] * 1.25 + tout * m["price_out"]) / 1e6

    # ---------- the call ----------
    def call(self, model: str, user: str, system: str | None = None,
             repeat: int = 0, max_tokens: int | None = None, meta: dict | None = None) -> CallResult:
        max_tokens = max_tokens or self.max_tokens
        meta = dict(meta or {})
        m = self.cfg["models"][model]
        self._record_settings(model, m, max_tokens)
        full_prompt = (system or "") + "\n\n<<USER>>\n" + user
        psha = sha256(full_prompt)
        self._store_prompt(psha, system, user)

        if m.get("provider") == "sim":   # simulated model: free, no key, not cached
            return self._call_sim(model, m, user, system, repeat, meta, psha)

        cache_key =sha256(f"{model}|{m['api_model']}|{psha}|{repeat}|{max_tokens}|{json.dumps(m, sort_keys=True)}")
        cache_file = self.cache_path / f"{cache_key}.json"
        if not self.dry_run:
            r = _read_cached(cache_file)   # None when missing or unreadable (then asked again)
            if r is not None:
                try:
                    notes = check_served(self.cfg, model, r.model_id, r.served_by)
                except ServedModelMismatch as e:
                    raise ServedModelMismatch(f"{e} (cached answer {cache_file})") from None
                r.cached, r.meta = True, meta
                if notes:
                    r.meta["served_check"] = notes
                r.call_id = meta.get("call_id") or f"{model}-{uuid.uuid4().hex[:12]}"
                self._log(r, cost_counted=False)
                return r

        if not self.dry_run:
            with self._lock:
                worst = self.worst_case_cost(model, user, system, max_tokens)
                cap = self.cfg["budget"]["hard_cap_usd"]
                if self.spent() + worst > cap:
                    raise BudgetExceeded(
                        f"Stopping: spent ${self.spent():.2f}, this call could add ${worst:.4f}, "
                        f"cap is ${cap:.2f} (config/models.yaml -> budget.hard_cap_usd).")

        t0 = time.time()
        if self.dry_run:
            out = dict(text="DRY-RUN ANSWER", tin=len(full_prompt) // 4, tout=3, mid=m["api_model"] + "(dry-run)",
                       stop="end_turn", fp=None, cr=0, cw=0, served=None)
        elif m["provider"] == "anthropic":
            out = self._call_anthropic(m, user, system, max_tokens)
        elif m["provider"] == "opencode_cli":
            out = self._call_opencode(m, user, system, meta)
        else:
            out = self._call_openai(m, user, system, max_tokens)
        latency = time.time() - t0
        cost = 0.0 if self.dry_run else self._cost(model, out["tin"], out["tout"], out["cr"], out["cw"])

        r = CallResult(
            call_id=meta.get("call_id") or f"{model}-{uuid.uuid4().hex[:12]}",
            model=model, model_id=out["mid"], called_at=now(), prompt_sha256=psha,
            started_at=datetime.fromtimestamp(t0, timezone.utc).isoformat(timespec="milliseconds"),
            answer=out["text"], tokens_in=out["tin"] + out["cr"] + out["cw"], tokens_out=out["tout"],
            cost_usd=round(cost, 8), stop_reason=out["stop"], latency_s=round(latency, 3),
            fingerprint=out["fp"], meta=meta, served_by=out["served"],
            reasoning_tokens=out.get("reasoning_tokens"), reasoning_fields=out.get("reasoning_fields"),
            cache_read_tokens=None if self.dry_run else out.get("cr"),
            cache_write_tokens=None if self.dry_run else out.get("cw"))
        if not self.dry_run:
            try:
                notes = check_served(self.cfg, model, r.model_id, r.served_by)
            except ServedModelMismatch as e:
                self._record_mismatch(r, str(e))   # paid for, so counted; never cached or logged as an answer
                raise
            if notes:
                r.meta["served_check"] = notes
            _write_atomic(cache_file, json.dumps(asdict(r), ensure_ascii=False))
        self._log(r, cost_counted=not self.dry_run)
        return r

    def _store_prompt(self, psha: str, system: str | None, user: str) -> None:
        """Keep the prompt once by its fingerprint in runs/<run>/prompts/. A file of the wrong
        size (cut short by a stop under older code) is written again."""
        prompt_file = self.run_dir / "prompts" / f"{psha}.json"
        blob = json.dumps({"system": system, "user": user}, ensure_ascii=False)
        try:
            good = prompt_file.stat().st_size == len(blob.encode("utf-8"))
        except OSError:
            good = False
        if not good:
            _write_atomic(prompt_file, blob)

    def _record_mismatch(self, r: CallResult, why: str) -> None:
        """An answer that failed the served-model check: its cost is added to the spend file
        (it was paid for) and the record is kept in runs/<run>/served_mismatch.jsonl, not in
        calls.jsonl and not in the answer cache."""
        rec = {**asdict(r), "error": why, "recorded_at": now()}
        with self._lock:
            with open(self.run_dir / "served_mismatch.jsonl", "a", encoding="utf-8") as f:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
            if r.cost_usd:
                self._add_spend(r.cost_usd, r.model)

    def _call_sim(self, model, m, user, system, repeat, meta, psha) -> CallResult:
        """A simulated model (msr/sim.py): costs nothing, needs no key, skips the budget
        guard and the answer cache (it is cheap and deterministic), and is logged to
        calls.jsonl like every other call. It answers the same way with or without dry_run."""
        from msr.sim import sim_call
        t0 = time.time()
        text, tin, tout, mid, stop = sim_call(model, m, user, system, repeat, meta)
        r = CallResult(
            call_id=meta.get("call_id") or f"{model}-{uuid.uuid4().hex[:12]}",
            model=model, model_id=mid, called_at=now(), prompt_sha256=psha,
            answer=text, tokens_in=tin, tokens_out=tout, cost_usd=0.0,
            stop_reason=stop, latency_s=round(time.time() - t0, 3), fingerprint=None, meta=meta)
        self._log(r, cost_counted=False)
        return r

    def _call_anthropic(self, m, user, system, max_tokens):
        client = self._client("anthropic")
        kwargs: dict[str, Any] = dict(model=m["api_model"], max_tokens=max_tokens,
                                      messages=[{"role": "user", "content": user}])
        if system:
            kwargs["system"] = system
        if m.get("anthropic_thinking"):
            kwargs["thinking"] = m["anthropic_thinking"]
        if m.get("effort"):
            kwargs["output_config"] = {"effort": m["effort"]}
        resp = client.messages.create(**kwargs)   # BadRequestError etc. propagate on purpose
        text = "".join(b.text for b in resp.content if b.type == "text")
        u = resp.usage
        cr = getattr(u, "cache_read_input_tokens", 0) or 0
        cw = getattr(u, "cache_creation_input_tokens", 0) or 0
        thinking = sorted({f"{b.type} block" for b in resp.content
                           if getattr(b, "type", None) in ("thinking", "redacted_thinking")})
        return dict(text=text, tin=u.input_tokens, tout=u.output_tokens, mid=resp.model, stop=resp.stop_reason,
                    fp=None, cr=cr, cw=cw, served=None, reasoning_tokens=_reasoning_tokens(u),
                    reasoning_fields=thinking)

    def _opencode_route(self):
        from msr.opencode_route import get_route
        return get_route(self.cfg["providers"].get("opencode_cli") or {})

    def _call_opencode(self, m, user, system, meta):
        """A free model through the opencode tool (msr/opencode_route.py). It raises on any
        failure (limit, empty answer, server error, timeout), so nothing false is cached.
        The answer cap is opencode's (providers.opencode_cli.output_token_max), not max_tokens."""
        route = self._opencode_route()
        out = route.call(m, user, system)
        meta["route_info"] = {"reasoning_tokens": out["reasoning_tokens"], "variant": m.get("opencode_variant"),
                              "tokens_estimated": out["tokens_estimated"], "model_latency_s": round(out["latency_s"], 3)}
        rt = out.get("reasoning_tokens")
        return dict(text=out["text"], tin=out["tokens_in"], tout=out["tokens_out"], mid=out["model_id"],
                    stop=out["finish"], fp=None, cr=out["cache_read"], cw=out["cache_write"],
                    served=route.served_by(), reasoning_tokens=int(rt) if rt is not None else None,
                    reasoning_fields=None)

    def _call_openai(self, m, user, system, max_tokens):
        client = self._client(m["provider"])
        messages = ([{"role": "system", "content": system}] if system else []) + \
                   [{"role": "user", "content": user}]
        kwargs: dict[str, Any] = dict(model=m["api_model"], messages=messages)
        # The name of the answer-length cap: OpenAI wants max_completion_tokens,
        # OpenRouter documents max_tokens (set per model in config/models.yaml).
        kwargs[m.get("max_tokens_field") or "max_completion_tokens"] = max_tokens
        if m.get("reasoning_effort"):
            kwargs["reasoning_effort"] = m["reasoning_effort"]
        if m.get("extra_body"):
            kwargs["extra_body"] = m["extra_body"]
        resp = client.chat.completions.create(**kwargs)
        choice = resp.choices[0]
        text = choice.message.content or ""
        u = resp.usage
        cached = 0
        details = getattr(u, "prompt_tokens_details", None)
        if details is not None:
            cached = getattr(details, "cached_tokens", 0) or 0
        # Which company ran the model, if the answer says so. The OpenAI SDK keeps
        # fields it does not know (like OpenRouter's "provider") in model_extra.
        served = getattr(resp, "provider", None)
        if served is None:
            served = (getattr(resp, "model_extra", None) or {}).get("provider")
        served = str(served) if served is not None else None
        reasoning = [name for name in _REASONING_FIELDS if _has_content(_field(choice.message, name))]
        return dict(text=text, tin=u.prompt_tokens - cached, tout=u.completion_tokens, mid=resp.model,
                    stop=choice.finish_reason, fp=getattr(resp, "system_fingerprint", None), cr=cached, cw=0,
                    served=served, reasoning_tokens=_reasoning_tokens(u), reasoning_fields=reasoning)

    # ---------- what settings each model was called with ----------
    def _record_settings(self, model: str, m: dict, max_tokens: int) -> None:
        """Write down, once per model per run, the request settings that make the
        model what it is, in runs/<run>/model_settings.json.

        Like the label on a sample jar: written once when the jar is filled, read
        by anyone later. The paper needs it because "qwen3.8-27b" means nothing
        without the host, precision, sampling and thinking setting behind it.
        Keys and headers are never written. Simulated models are recorded too,
        so the file exists after every run."""
        if model in self._settings_recorded:   # quick check; the real one is under the lock
            return
        with self._lock:
            if model in self._settings_recorded:
                return
            entry = {
                "provider": m.get("provider"),
                "api_model": m.get("api_model"),
                "anthropic_thinking": m.get("anthropic_thinking"),
                "effort": m.get("effort"),
                "reasoning_effort": m.get("reasoning_effort"),
                "extra_body": _without_secrets(m.get("extra_body")),
                "max_tokens_field": m.get("max_tokens_field"),
                "max_tokens": max_tokens,
            }
            if m.get("provider") == "opencode_cli":   # the wrapper route: say what it sends
                entry["opencode"] = self._opencode_route().describe(m)
            entry = json.loads(json.dumps(entry, default=str))   # plain JSON values only
            path = self.run_dir / "model_settings.json"
            data: dict = {}
            if path.exists():
                try:
                    data = json.loads(path.read_text(encoding="utf-8"))
                except ValueError:
                    # A file we cannot read is kept aside, never silently thrown away.
                    path.replace(path.with_name(f"model_settings.unreadable-{uuid.uuid4().hex[:8]}.json"))
                    data = {}
            old = data.get(model)

            def settings_only(e: dict) -> dict:
                return {k: v for k, v in e.items() if k not in ("recorded_at", "earlier")}

            if old is not None and settings_only(old) == entry:
                # The same settings were already written (an earlier pass of this run).
                self._settings_recorded.add(model)
                return
            entry["recorded_at"] = now()
            if old is not None:
                # The settings changed since the last pass of this run: keep the old
                # ones under "earlier", so the record shows both.
                entry["earlier"] = list(old.get("earlier") or []) + [
                    {**settings_only(old), "recorded_at": old.get("recorded_at")}]
            data[model] = entry
            # Write to a temporary file first, then swap it in, so a crash halfway
            # never leaves a half-written file.
            _write_atomic(path, json.dumps(data, indent=2, ensure_ascii=False, sort_keys=True))
            self._settings_recorded.add(model)

    def _log(self, r: CallResult, cost_counted: bool) -> None:
        with self._lock:
            with open(self.calls_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(asdict(r), ensure_ascii=False) + "\n")
            if cost_counted and r.cost_usd:
                self._add_spend(r.cost_usd, r.model)

    # ---------- many calls at once ----------
    def map(self, jobs: Iterable[dict], workers: int = 8,
            on_done: Callable[[CallResult], None] | None = None) -> list[CallResult]:
        """Run many calls in parallel. Each job is a dict of call() arguments.
        Results come back in the same order as the jobs."""
        jobs = list(jobs)
        out: list[CallResult | None] = [None] * len(jobs)

        def run(i_job):
            i, job = i_job
            r = self.call(**job)
            out[i] = r
            if on_done:
                on_done(r)

        with ThreadPoolExecutor(max_workers=workers) as ex:
            list(ex.map(run, enumerate(jobs)))
        return out  # type: ignore[return-value]


def _read_cached(cache_file: Path) -> CallResult | None:
    """A cached answer, or None when the file is missing or cannot be read (cut short by a stop,
    empty, not JSON, missing a field): the call is then asked again and the file rewritten.
    Fields a newer version added are ignored; fields an older version lacked take their defaults."""
    try:
        data = json.loads(_read_text_any(cache_file))
        if not isinstance(data, dict):
            return None
        known = {f.name for f in fields(CallResult)}
        return CallResult(**{k: v for k, v in data.items() if k in known})
    except (OSError, ValueError, TypeError, UnicodeDecodeError):
        return None


def now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
