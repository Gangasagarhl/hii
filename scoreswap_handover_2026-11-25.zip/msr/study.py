"""Read a study file (config/*.yaml), check it, and work out every call it will make.

Everyday picture: before a big cooking day, the chef writes the menu, checks that
every ingredient is in the pantry, and counts how many plates each cook will make.
Nothing is cooked here. This file:
  - reads a study YAML into plain dataclasses (all design numbers come from the YAML),
  - refuses models that are not in config/models.yaml,
  - turns pair lists ("all", "upgrades", "upgrades_and_reverse", "upgrades_and_home",
    or [[old, new], ...]) into the list of swaps,
  - counts the planned calls per stage and model, and prices them with
    data/prompt_sizes.json and the prices in config/models.yaml.

Where things are saved (runs/<study>/...):
  splits/<stream>_seed<k>.json                    the frozen build / probe / test cut
  banks/<model>/<stream>/seed<k>/                 Stage A: items, score files, episodes
  banks/<model>/<stream>/seed<k>/bank2/           Stage A: the second bank (other exploration seed)
  probes/<owner>__<reader>/<stream>/seed<k>/      Stage B: one probe table per swap cell
  probes0/<reader>/<stream>/seed<k>/              Stage B: the no-memory runs of a reader
  subsets/<owner>__<reader>/<stream>/seed<k>/     Stage B: several items shown together
  variants/<variant>/...                          Stage B: probes again under the second wording
  results/                                        Stage C: tidy CSV files and SUMMARY.md
  online/<owner>__<reader>/<stream>/seed<k>/      Stage D: the run after the swap
  judge/<owner>__<reader>/<stream>/seed<k>/       the reader rates each of the owner's stored items
  relearn/<owner>__<reader>/<stream>/seed<k>/     the reader re-earns scores on the owner's frozen items
  banks/<model>/<stream>/seed<k>/write2.jsonl     a second no-memory answer to each write task
  banks/<model>/<stream>/seed<k>/selfrate.jsonl   the writer's own rating of each stored item

Extension pairs (study section `extension:`, decision D9) add same-maker cells only: each model of a
pair gets its own bank and home cell, plus the two swaps between them; never a cross-maker cell and
never the "all" grid. They ARE same-maker upgrades: st.upgrade_pairs = the main pairs + the extension
pairs (so the same-maker groups have 6 pairs, as D9 rules, and online / subsets that name `upgrades`
include them); st.main_upgrade_pairs and st.main_models give the main grid alone.
"""
from __future__ import annotations

import json
import math
import re
import threading
from dataclasses import dataclass, field
from itertools import combinations
from pathlib import Path

import yaml

from msr import data as D
from msr import llm as L

ROOT = Path(__file__).resolve().parent.parent

#: The five score families kept on every memory item (all fed by the same episodes).
FAMILIES = ("ema_grade", "beta_grade", "tags_self", "credit", "visits")
#: Families that need the model's own helpful / harmful tag (an extra call per shown item).
SELF_FAMILIES = ("tags_self",)
#: Families that can keep learning in the run after the swap (pre-registration 2.10): tags_self
#: makes one extra tag call per shown item (the reader tags without seeing the grade), credit
#: reads the no-memory results of the `none` arm. `online.families` may also name `headline`,
#: which stands for evaluate.headline_family (settled points 13 and 22).
ONLINE_FAMILIES = ("ema_grade", "beta_grade", "tags_self", "credit", "visits")

#: Stage names used in the call log (meta["stage"]) and in the plan. The self-tag call is
#: logged as "selfmark" (the simulated models answer a tag word for that stage name).
STAGES = ("write", "write2", "selfrate", "build0", "build", "selfmark", "probe", "probe0", "probe_extra",
          "subset", "variant", "variant0", "judge", "relearn", "relearn_tag", "check_store", "online")

PROMPT_VARIANTS = ("v1", "v2")

_SPLIT_LOCK = threading.Lock()
_SPLIT_CACHE: dict = {}

_NAME_OK = re.compile(r"^[A-Za-z0-9_.-]+$")
_ARM_RE = re.compile(r"^(none|relevance|keep|wipe|shuffled|own|oracle|fixed_[0-9.]+|"
                     r"(powerprior|powerprior_flat|recal|retest|audit|pooled|fresh|reexplore)_\d+)$")
#: Online arms that need no fresh checks (so no probe table of their cell): reexplore_m keeps the
#: old scores and re-opens exploration for the first m tasks after the swap (decision D7).
_NO_CHECK_ARMS = ("none", "relevance", "own", "keep", "wipe", "fixed_", "reexplore_")


class StudyError(ValueError):
    """The study file is wrong; the message says what to fix."""


# ---------------------------------------------------------------------------
# The settings, one small dataclass per part of the study file
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Sizes:
    n_build: int             # write tasks + score tasks
    n_probe: int
    n_test: int


@dataclass(frozen=True)
class BuildSettings:
    n_write: int             # WRITE phase: these first build tasks are answered with no memory
    epochs: int              # SCORE phase: passes over the remaining build tasks
    candidates: int          # stored items looked up per task (by relevance)
    n_show: int              # how many of them are shown
    epsilon: float           # chance of showing a random candidate instead of the best one
    explore_pool: str        # "relevance" or "mixed": where the random pick comes from
    w_score: float           # retrieval mix: w_score * score + (1 - w_score) * relevance
    drive: str               # the score family that decides what is shown (or "relevance")
    store: str               # "all" or "correct_only": which write-phase answers become items
    item_style: str          # "shot" (unlabelled) or "memprompt" (says right / wrong)
    self_tag: bool           # ask the model "was the shown item helpful?" after each task
    self_tag_sees_grade: bool
    batch: int               # tasks per group; calls in a group run at once, scores update after
    no_memory_run: bool      # run every score-phase task once with no memory (stage build0)
    second_bank_models: tuple  # models that get a second bank (other exploration seed)
    second_bank_seed_offset: int
    second_bank_repeat_offset: int
    write_repeat: bool = False   # a SECOND no-memory answer to each write task (stage write2, repeat 1)
    self_rating: bool = False    # the writer rates each stored item at write time (stage selfrate)
    rating_scale: int = 10       # self-rating and judge answers are a whole number 1..rating_scale


@dataclass(frozen=True)
class ScoreSettings:
    ema_alpha: float         # moving-average step (MemRL: 0.3)
    ema_q0: float            # moving-average start (MemRL released config: 0.5)
    counter_ranking: str     # counters rank by "net" (helpful - harmful) or "smoothed"
    families: tuple          # which of FAMILIES are kept and evaluated


@dataclass(frozen=True)
class ProbeSettings:
    candidates: int
    repeats: int
    no_memory_repeats: int
    home_extra_repeats: int
    home_extra_offset: int
    subsets_enabled: bool
    subset_tasks: int
    subset_cells: tuple      # (owner, reader) cells, home cells allowed
    check_store_extra_tasks: int = 0   # OPTION (not built): extend same-maker home and swap cells to more tasks
    repeat_gap_hours: float = 6.0      # repeat 2 of a cell runs at least this long after its repeat 1 (a later session)


@dataclass(frozen=True)
class EvalSettings:
    calib_tasks: int
    calib_draws: int
    fixed_lambdas: tuple
    k_values: tuple          # the k that fit the calibration pool (calib_tasks x probe.candidates)
    lambda_grid: tuple
    shuffled_seeds: int
    w_sensitivity: tuple     # extra values of w_score for the decision-quality check
    bootstrap: int
    seed: int
    summary_k: int
    processes: int           # parallel worker processes for Stage C (0 = one per CPU, max 8)
    headline_family: str = "ema_grade"   # PC1-PC4, P1, P2, P4 (pre-registration 0.3, 9.2)
    prob_clip: tuple = (0.01, 0.99)      # p clipped to this range for log score and Brier
    ni_fraction: float = 0.25            # non-inferiority: a quarter of the home signal above chance
    min_difference: float = 0.05         # the 5-point difference threshold
    ratio_min_z: float = 4.0             # R only when C_home - 0.5 >= this many SE(C_home)
    k_skipped: tuple = ()                # k values of the study file that do not fit the pool


@dataclass(frozen=True)
class OnlineSettings:
    enabled: bool
    pairs: tuple
    arms: tuple
    families: tuple
    n_show: int
    epsilon: float           # exploration in the run after the swap (pre-registration: 0)
    learn: bool              # scores keep learning during the run
    window: int
    first_n: int
    target_share: float
    reexplore_epsilon: float = 0.3   # exploration of reexplore_m during its first m tasks (default build.epsilon)


@dataclass(frozen=True)
class VariantSettings:
    enabled: bool
    variant: str
    cells: tuple             # (owner, reader) cells re-probed under the variant (home cells added)
    tasks: int


@dataclass(frozen=True)
class EstimateSettings:
    out_tokens: dict
    selfmark_out_tokens: float
    token_factor: dict


@dataclass(frozen=True)
class JudgeSettings:
    enabled: bool
    cells: tuple             # (owner, reader): the reader rates each of the owner's stored items
    scale: int               # a whole number 1..scale


@dataclass(frozen=True)
class RelearnSettings:
    enabled: bool
    pairs: tuple             # (owner, reader): the reader re-runs the score phase on the owner's items
    self_tag: bool           # also the reader's own helpful / harmful tags (doubles the calls)
    repeat_offset: int       # repeat numbers start here, so these are fresh runs


@dataclass(frozen=True)
class SimSettings:
    correct_bonus: float = 0.0   # simulated models only: stored-answer correctness helps (0 = off)


@dataclass
class Study:
    name: str
    path: Path
    models: tuple
    pairs: tuple
    upgrade_pairs: tuple
    streams: tuple
    seeds: tuple
    sizes: Sizes
    exclude_tasks: tuple     # task ids removed before the splits are drawn (e.g. bird-0701)
    bird_faithful: bool      # False = the corrected SQL parser (primary grading)
    prompt_variant: str
    embedding_model: str
    max_tokens: int
    grade_cache: bool
    workers: int
    build: BuildSettings
    scores: ScoreSettings
    probe: ProbeSettings
    evaluate: EvalSettings
    online: OnlineSettings
    variants: VariantSettings
    estimate: EstimateSettings
    models_cfg: dict = field(repr=False, default_factory=dict)
    raw: dict = field(repr=False, default_factory=dict)
    notes: tuple = ()        # one-line notes about the study file (e.g. a k that was skipped)
    judge: JudgeSettings = JudgeSettings(False, (), 10)
    relearn: RelearnSettings = RelearnSettings(False, (), False, 200)
    extension_pairs: tuple = ()   # (old, new) of each extension pair (same-maker cells only)
    simulator: SimSettings = SimSettings()

    @property
    def main_upgrade_pairs(self) -> tuple:
        """The main grid's old -> new pairs, without the extension pairs."""
        return tuple(p for p in self.upgrade_pairs if p not in self.extension_pairs)

    @property
    def main_models(self) -> tuple:
        """The models of the main grid (`models:`), without the extension pairs."""
        ext = {m for p in self.extension_pairs for m in p}
        return tuple(m for m in self.models if m not in ext)

    # ---- the swap cells -------------------------------------------------
    @property
    def cells(self) -> list:
        """The explicit list of (owner, reader) probe cells: each model with itself (home; the
        extension models too) plus every pair (the main grid's swaps, then each extension pair's two
        swaps). Build, probe, judge, Stage C and the analysis all follow this list, so the grid does
        not need to be square."""
        home = [(m, m) for m in self.models]
        return home + [p for p in self.pairs if p not in home]

    @property
    def n_score(self) -> int:
        return self.sizes.n_build - self.build.n_write

    def family(self, model: str) -> str:
        """The maker family of a model (config/models.yaml `family`, else params.family,
        else the old -> new pair it sits in, else the model itself)."""
        m = self.models_cfg["models"].get(model, {})
        fam = m.get("family") or (m.get("params") or {}).get("family")
        if fam:
            return str(fam)
        for a, b in self.models_cfg.get("pairs") or []:
            if model in (a, b):
                return f"{a}+{b}"
        return model

    def kind(self, owner: str, reader: str) -> str:
        if owner == reader:
            return "home"
        return "same_family" if self.family(owner) == self.family(reader) else "cross_family"

    def is_sim(self, model: str) -> bool:
        return self.models_cfg["models"][model].get("provider") == "sim"

    @property
    def all_sim(self) -> bool:
        return all(self.is_sim(m) for m in self.models)

    def banks_of(self, model: str) -> list:
        """Bank numbers built for a model: 1, plus 2 if it gets a second bank."""
        return [1, 2] if model in self.build.second_bank_models else [1]

    # ---- folders ----------------------------------------------------------
    @property
    def dir(self) -> Path:
        return Path(L.RUNS) / self.name        # read at call time (tests and --runs-dir move it)

    def split_path(self, stream: str, seed: int) -> Path:
        return self.dir / "splits" / f"{stream}_seed{seed}.json"

    def bank_dir(self, model: str, stream: str, seed: int, bank: int = 1) -> Path:
        d = self.dir / "banks" / model / stream / f"seed{seed}"
        return d if bank == 1 else d / f"bank{bank}"

    def probe_dir(self, owner: str, reader: str, stream: str, seed: int) -> Path:
        return self.dir / "probes" / f"{owner}__{reader}" / stream / f"seed{seed}"

    def probe0_dir(self, reader: str, stream: str, seed: int) -> Path:
        return self.dir / "probes0" / reader / stream / f"seed{seed}"

    def subset_dir(self, owner: str, reader: str, stream: str, seed: int) -> Path:
        return self.dir / "subsets" / f"{owner}__{reader}" / stream / f"seed{seed}"

    def variant_dir(self, owner: str, reader: str, stream: str, seed: int) -> Path:
        return self.dir / "variants" / self.variants.variant / f"{owner}__{reader}" / stream / f"seed{seed}"

    def variant0_dir(self, reader: str, stream: str, seed: int) -> Path:
        return self.dir / "variants0" / self.variants.variant / reader / stream / f"seed{seed}"

    def online_dir(self, owner: str, reader: str, stream: str, seed: int) -> Path:
        return self.dir / "online" / f"{owner}__{reader}" / stream / f"seed{seed}"

    @property
    def results_dir(self) -> Path:
        return self.dir / "results"

    # ---- splits -------------------------------------------------------------
    def splits(self, stream: str, seed: int) -> dict:
        """The build / probe / test cut (made once, then read from disk). The build list
        starts with the n_write write-phase tasks; the rest are score-phase tasks."""
        key = (str(self.dir), stream, seed)
        with _SPLIT_LOCK:                      # parallel builds ask for the same split at once
            if key in _SPLIT_CACHE:
                return _SPLIT_CACHE[key]
            p = self.split_path(stream, seed)
            fresh = self._make_splits(stream, seed)
            if p.exists():
                saved = json.loads(p.read_text(encoding="utf-8"))
                if any(saved.get(k) != fresh[k] for k in ("build", "probe", "test", "sizes", "n_write", "excluded")):
                    raise StudyError(f"{p} was made with other sizes; delete the study folder "
                                     f"or use a new study name")
                fresh = saved
            else:
                D.save_splits(fresh, p)
            _SPLIT_CACHE[key] = fresh
            return fresh

    def _make_splits(self, stream: str, seed: int) -> dict:
        """msr.data's seeded shuffle with the excluded tasks taken out BEFORE the cut
        (pre-registration 1.4), then build | probe | test | unused. With nothing excluded
        the lists are exactly msr.data.make_splits'."""
        excl = sorted(t for t in self.exclude_tasks if t.startswith(stream + "-"))
        order = [t for t in D.make_order(stream, seed) if t not in set(excl)]
        z = self.sizes
        total = z.n_build + z.n_probe + z.n_test
        if total > len(order):
            raise StudyError(f"{stream}: sizes {total} do not fit the {len(order)} usable tasks")
        a, b = z.n_build, z.n_build + z.n_probe
        out = {"stream": stream, "seed": seed, "sizes": dict(z.__dict__), "n_write": self.build.n_write,
               "excluded": excl,
               "method": "random.Random(seed).shuffle(sorted(task_ids)), excluded tasks removed, then "
                         "build=[:n_build] (first n_write = write tasks), probe=next n_probe, test=next n_test",
               "build": order[:a], "probe": order[a:b], "test": order[b:total], "unused": order[total:]}
        out["sha256"] = L.sha256(json.dumps([out["build"], out["probe"], out["test"]]))
        return out

    def write_ids(self, stream: str, seed: int) -> list:
        return list(self.splits(stream, seed)["build"][: self.build.n_write])

    def score_ids(self, stream: str, seed: int) -> list:
        return list(self.splits(stream, seed)["build"][self.build.n_write:])

    def calib_eval(self, stream: str, seed: int) -> tuple:
        """Split the probe tasks into (calibration tasks, evaluation tasks), fixed by a hash
        of (stream, seed, task id). Calibration tasks are used ONLY to draw fresh checks."""
        probe = list(self.splits(stream, seed)["probe"])
        order = sorted(probe, key=lambda t: L.sha256(f"calib|{stream}|{seed}|{t}"))
        calib = set(order[: self.evaluate.calib_tasks])
        return ([t for t in probe if t in calib], [t for t in probe if t not in calib])

    def subset_task_ids(self, stream: str, seed: int) -> list:
        """The first probe.subsets.tasks evaluation tasks (in stream order)."""
        return self.calib_eval(stream, seed)[1][: self.probe.subset_tasks]

    def variant_task_ids(self, stream: str, seed: int) -> list:
        return self.calib_eval(stream, seed)[1][: self.variants.tasks]


# ---------------------------------------------------------------------------
# Loading and checking
# ---------------------------------------------------------------------------


def _need(d: dict, key: str, where: str):
    if not isinstance(d, dict) or key not in d:
        raise StudyError(f"missing '{key}' in {where} of the study file")
    return d[key]


def _section(raw: dict, name: str) -> dict:
    sec = raw.get(name)
    if not isinstance(sec, dict):
        raise StudyError(f"missing section '{name}:' in the study file")
    return sec


def _int(v, what: str, lo: int | None = None) -> int:
    if isinstance(v, bool) or not isinstance(v, int):
        raise StudyError(f"{what} must be a whole number, got {v!r}")
    if lo is not None and v < lo:
        raise StudyError(f"{what} must be at least {lo}, got {v}")
    return v


def _float(v, what: str, lo: float = 0.0, hi: float = 1.0) -> float:
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        raise StudyError(f"{what} must be a number, got {v!r}")
    v = float(v)
    if not (lo <= v <= hi) or math.isnan(v):
        raise StudyError(f"{what} must be between {lo} and {hi}, got {v}")
    return v


def _bool(v, what: str) -> bool:
    if not isinstance(v, bool):
        raise StudyError(f"{what} must be true or false, got {v!r}")
    return v


def expand_pairs(spec, models: list, upgrades: tuple, what: str = "pairs", allow_home: bool = False,
                 cycle: tuple | None = None) -> tuple:
    """Turn a pair spec into ordered (owner, reader) tuples.

    all                  every ordered pair of different study models
    cross_cycle          each old model -> the next pair's new model (wrapping around)
    cross_cycle_back     each new model -> the previous pair's old model (wrapping around)
    [spec, spec, ...]    several named specs joined
    upgrades             the old -> new pairs (study `upgrade_pairs`, else config/models.yaml pairs)
    upgrades_and_reverse those and their downgrades
    upgrades_and_home    the upgrades plus every model of them with itself
    (cross_cycle and cross_cycle_back go round the main grid's pairs only, `cycle` when given: an
    extension pair never gets a cross-maker cell)
    home                 every study model with itself
    [[old, new], ...]    an explicit list ([m, m] only where home cells are allowed)
    """
    def check_upgrades():
        if not upgrades:
            raise StudyError(f"{what}: no old -> new pair has both models in this study "
                             f"(set upgrade_pairs: in the study file)")
        return upgrades

    if spec == "all":
        return tuple((a, b) for a in models for b in models if a != b)
    if spec == "upgrades":
        return tuple(check_upgrades())
    if spec == "upgrades_and_reverse":
        up = check_upgrades()
        return tuple(up) + tuple((b, a) for a, b in up)
    if spec == "upgrades_and_home":
        up = check_upgrades()
        homes = []
        for a, b in up:
            for m in (a, b):
                if (m, m) not in homes:
                    homes.append((m, m))
        return tuple(up) + tuple(homes)
    if spec == "home":
        return tuple((m, m) for m in models)
    if spec == "cross_cycle_back":
        # each maker's NEW model -> the PREVIOUS maker's OLD model (the cycle the other way round)
        up = tuple(cycle) if cycle is not None else check_upgrades()
        if len(up) < 2:
            raise StudyError(f"{what}: cross_cycle_back needs at least two upgrade pairs")
        return tuple((up[i][1], up[(i - 1) % len(up)][0]) for i in range(len(up)))
    if spec == "cross_cycle":
        # each maker's OLD model -> the NEXT maker's NEW model, in the order of the upgrade
        # pairs (anthropic -> openai -> qwen -> gemma -> anthropic for the real study)
        up = tuple(cycle) if cycle is not None else check_upgrades()
        if len(up) < 2:
            raise StudyError(f"{what}: cross_cycle needs at least two upgrade pairs")
        return tuple((up[i][0], up[(i + 1) % len(up)][1]) for i in range(len(up)))
    if isinstance(spec, list) and spec and all(isinstance(x, str) for x in spec):
        out = []                                  # a list of named specs, joined in order
        for name in spec:
            for pr in expand_pairs(name, models, upgrades, what, allow_home, cycle):
                if pr not in out:
                    out.append(pr)
        return tuple(out)
    if not isinstance(spec, list):
        raise StudyError(f"{what} must be all, upgrades, upgrades_and_reverse, upgrades_and_home, "
                         f"home or a list of [old, new]")
    out = []
    for p in spec:
        if not (isinstance(p, (list, tuple)) and len(p) == 2):
            raise StudyError(f"{what}: each pair must be [old, new], got {p!r}")
        a, b = str(p[0]), str(p[1])
        for m in (a, b):
            if m not in models:
                raise StudyError(f"{what}: model {m!r} is not in this study's models list")
        if a == b and not allow_home:
            raise StudyError(f"{what}: a model paired with itself is the home cell, which is always run")
        out.append((a, b))
    if len(set(out)) != len(out):
        raise StudyError(f"{what}: a pair is listed twice")
    return tuple(out)


def _check_arm(a: str, what: str) -> None:
    if not _ARM_RE.match(a):
        raise StudyError(f"{what}: unknown arm {a!r}")


def load_study(path, models_cfg: dict | None = None) -> Study:
    """Read and check a study YAML. Raises StudyError with a plain message if anything is wrong."""
    path = Path(path)
    if not path.is_absolute() and not path.exists():
        path = ROOT / path
    if not path.exists():
        raise StudyError(f"study file {path} not found")
    raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    mcfg = models_cfg or L.load_config()

    name = str(_need(raw, "name", "the top level"))
    if not _NAME_OK.match(name) or name.startswith("_"):
        raise StudyError(f"name {name!r}: use letters, digits, '-', '_' or '.' (not starting with _)")

    models = _need(raw, "models", "the top level")
    if not isinstance(models, list) or not models:
        raise StudyError("models must be a non-empty list")
    models = [str(m) for m in models]
    if len(set(models)) != len(models):
        raise StudyError("a model is listed twice in models")
    unknown = [m for m in models if m not in mcfg["models"]]
    if unknown:
        raise StudyError(f"unknown model(s) {unknown}: they are not in config/models.yaml "
                         f"(known: {sorted(mcfg['models'])})")

    if raw.get("upgrade_pairs") is not None:
        upgrades = expand_pairs(raw["upgrade_pairs"], models, (), "upgrade_pairs")
    else:
        upgrades = tuple((a, b) for a, b in (mcfg.get("pairs") or []) if a in models and b in models)
    pairs = expand_pairs(_need(raw, "pairs", "the top level"), models, upgrades)

    # extension pairs (decision D9): same-maker cells only, outside the main grid
    ext_sec = raw.get("extension") or {}
    if ext_sec and not isinstance(ext_sec, dict):
        raise StudyError("extension must be a section with `pairs: [[old, new], ...]`")
    ext_pairs = []
    for pr in ext_sec.get("pairs") or []:
        if not (isinstance(pr, (list, tuple)) and len(pr) == 2):
            raise StudyError(f"extension.pairs: each pair must be [old, new], got {pr!r}")
        a, b = str(pr[0]), str(pr[1])
        for m in (a, b):
            if m not in mcfg["models"]:
                raise StudyError(f"extension.pairs: unknown model {m!r} (not in config/models.yaml)")
            if m in models:
                raise StudyError(f"extension.pairs: {m!r} is already in the main models list")
        if a == b:
            raise StudyError("extension.pairs: a pair needs two different models")
        ext_pairs.append((a, b))
    ext_models = [m for pr in ext_pairs for m in pr]
    if len(set(ext_models)) != len(ext_models):
        raise StudyError("extension.pairs: a model appears in two pairs")
    ext_swaps = tuple(p for a, b in ext_pairs for p in ((a, b), (b, a)))
    for a, b in ext_pairs:
        fa = (mcfg["models"][a].get("family") or (mcfg["models"][a].get("params") or {}).get("family"))
        fb = (mcfg["models"][b].get("family") or (mcfg["models"][b].get("params") or {}).get("family"))
        if not fa or fa != fb:
            raise StudyError(f"extension.pairs: {a} and {b} must be one maker (family in config/models.yaml)")
    main_models = list(models)
    models = main_models + ext_models
    pairs = tuple(pairs) + ext_swaps
    # The extension pairs are same-maker upgrades like the main four (D9: "same-maker groups then have
    # 6 pairs"): they join `upgrades` (online, subsets, the analysis's same-maker groups, the gate's old
    # models), but never a cross-maker cycle and never the "all" grid.
    main_upgrades = tuple(upgrades)
    upgrades = main_upgrades + tuple(ext_pairs)

    def expand(spec, what, allow_home=False):
        """expand_pairs plus three names that know the extension pairs: `extension` (both directions
        of every extension pair), `same_maker` (every upgrade and downgrade, extension pairs included)
        and `swaps` (every probe swap: the main grid's and the extension pairs')."""
        if spec == "extension":
            return ext_swaps
        if spec == "swaps":       # every probe swap: the main grid's and the extension pairs'
            return tuple(pairs)
        if spec == "same_maker":
            return tuple(upgrades) + tuple((b, a) for a, b in upgrades)
        if isinstance(spec, list) and spec and all(isinstance(x, str) for x in spec):
            out = []
            for name in spec:
                for pr in expand(name, what, allow_home):
                    if pr not in out:
                        out.append(pr)
            return tuple(out)
        return expand_pairs(spec, models, upgrades, what, allow_home, cycle=main_upgrades)

    streams = _need(raw, "streams", "the top level")
    if not isinstance(streams, list) or not streams:
        raise StudyError("streams must be a non-empty list")
    for s in streams:
        if s not in D.STREAMS:
            raise StudyError(f"unknown stream {s!r}; expected one of {D.STREAMS}")
    seeds = _need(raw, "seeds", "the top level")
    if not isinstance(seeds, list) or not seeds:
        raise StudyError("seeds must be a non-empty list of whole numbers")
    seeds = [_int(s, "each seed", 0) for s in seeds]
    if len(set(seeds)) != len(seeds):
        raise StudyError("a seed is listed twice")

    sz = _section(raw, "sizes")
    sizes = Sizes(_int(_need(sz, "n_build", "sizes"), "sizes.n_build", 2),
                  _int(_need(sz, "n_probe", "sizes"), "sizes.n_probe", 2),
                  _int(_need(sz, "n_test", "sizes"), "sizes.n_test", 0))
    for s in streams:
        total = sizes.n_build + sizes.n_probe + sizes.n_test
        usable = D.EXPECTED_ROWS[s] - sum(1 for t in (raw.get("exclude_tasks") or []) if str(t).startswith(s + "-"))
        if total > usable:
            raise StudyError(f"sizes add up to {total}, more than the {usable} usable tasks of {s}")

    excl = raw.get("exclude_tasks") or []
    if not isinstance(excl, list) or not all(isinstance(t, str) for t in excl):
        raise StudyError("exclude_tasks must be a list of task ids, e.g. [bird-0701]")
    bird_faithful = _bool((raw.get("grading") or {}).get("bird_faithful", False), "grading.bird_faithful")
    prompt_variant = str(raw.get("prompt_variant", "v1"))
    if prompt_variant not in PROMPT_VARIANTS:
        raise StudyError(f"prompt_variant must be one of {PROMPT_VARIANTS}")
    embedding_model = str(_need(_section(raw, "embedding"), "model", "embedding"))
    llm_sec = _section(raw, "llm")
    max_tokens = _int(_need(llm_sec, "max_tokens", "llm"), "llm.max_tokens", 1)
    grade_cache = _bool(llm_sec.get("grade_cache", False), "llm.grade_cache")
    workers = _int((raw.get("run") or {}).get("workers", 8), "run.workers", 1)

    b = _section(raw, "build")
    sb = b.get("second_bank_models") or []
    for m in sb:
        if m not in models:
            raise StudyError(f"build.second_bank_models: {m!r} is not in this study's models")
    build = BuildSettings(
        n_write=_int(_need(b, "n_write", "build"), "build.n_write", 1),
        epochs=_int(_need(b, "epochs", "build"), "build.epochs", 1),
        candidates=_int(_need(b, "candidates", "build"), "build.candidates", 1),
        n_show=_int(_need(b, "n_show", "build"), "build.n_show", 1),
        epsilon=_float(_need(b, "epsilon", "build"), "build.epsilon"),
        explore_pool=str(_need(b, "explore_pool", "build")),
        w_score=_float(_need(b, "w_score", "build"), "build.w_score"),
        drive=str(_need(b, "drive", "build")),
        store=str(_need(b, "store", "build")),
        item_style=str(_need(b, "item_style", "build")),
        self_tag=_bool(_need(b, "self_tag", "build"), "build.self_tag"),
        self_tag_sees_grade=_bool(_need(b, "self_tag_sees_grade", "build"), "build.self_tag_sees_grade"),
        batch=_int(_need(b, "batch", "build"), "build.batch", 1),
        no_memory_run=_bool(_need(b, "no_memory_run", "build"), "build.no_memory_run"),
        second_bank_models=tuple(str(m) for m in sb),
        second_bank_seed_offset=_int(b.get("second_bank_seed_offset", 1000), "build.second_bank_seed_offset", 1),
        second_bank_repeat_offset=_int(b.get("second_bank_repeat_offset", 100), "build.second_bank_repeat_offset", 1),
        write_repeat=_bool(b.get("write_repeat", False), "build.write_repeat"),
        self_rating=_bool(b.get("self_rating", False), "build.self_rating"),
        rating_scale=_int(b.get("rating_scale", 10), "build.rating_scale", 2),
    )
    if build.n_write >= sizes.n_build:
        raise StudyError("build.n_write must be smaller than sizes.n_build (the rest are score tasks)")
    if build.n_show > build.candidates:
        raise StudyError("build.n_show cannot be larger than build.candidates")
    if build.second_bank_repeat_offset < build.epochs:
        raise StudyError("build.second_bank_repeat_offset must be at least build.epochs")
    for key, ok in (("explore_pool", ("relevance", "mixed")), ("store", ("all", "correct_only")),
                    ("item_style", ("shot", "memprompt"))):
        if getattr(build, key) not in ok:
            raise StudyError(f"build.{key} must be one of {ok}")

    sc = _section(raw, "scores")
    fams = tuple(str(t) for t in _need(sc, "families", "scores"))
    bad = [t for t in fams if t not in FAMILIES]
    if bad or not fams:
        raise StudyError(f"scores.families: unknown {bad}; choose from {FAMILIES}")
    if not build.self_tag and "tags_self" in fams:
        raise StudyError("scores.families tags_self needs build.self_tag: true")
    if "credit" in fams and not build.no_memory_run:
        raise StudyError("scores.families credit needs build.no_memory_run: true (it compares with no memory)")
    scores = ScoreSettings(
        ema_alpha=_float(_need(sc, "ema_alpha", "scores"), "scores.ema_alpha"),
        ema_q0=_float(_need(sc, "ema_q0", "scores"), "scores.ema_q0"),
        counter_ranking=str(_need(sc, "counter_ranking", "scores")),
        families=fams,
    )
    if scores.counter_ranking not in ("net", "smoothed"):
        raise StudyError("scores.counter_ranking must be net or smoothed")
    if build.drive != "relevance" and build.drive not in fams:
        raise StudyError(f"build.drive {build.drive!r} must be one of scores.families {fams} or 'relevance'")

    p = _section(raw, "probe")
    subs = p.get("subsets") or {"enabled": False}
    sub_on = _bool(subs.get("enabled", False), "probe.subsets.enabled")
    sub_cells = expand(_need(subs, "pairs", "probe.subsets"), "probe.subsets.pairs",
                             allow_home=True) if sub_on else ()
    probe = ProbeSettings(
        candidates=_int(_need(p, "candidates", "probe"), "probe.candidates", 2),
        repeats=_int(_need(p, "repeats", "probe"), "probe.repeats", 2),
        no_memory_repeats=_int(_need(p, "no_memory_repeats", "probe"), "probe.no_memory_repeats", 1),
        home_extra_repeats=_int(_need(p, "home_extra_repeats", "probe"), "probe.home_extra_repeats", 0),
        home_extra_offset=_int(p.get("home_extra_offset", 1000), "probe.home_extra_offset", 1),
        subsets_enabled=sub_on,
        subset_tasks=_int(subs.get("tasks", 0), "probe.subsets.tasks", 0) if sub_on else 0,
        subset_cells=sub_cells,
        check_store_extra_tasks=_int(p.get("check_store_extra_tasks", 0), "probe.check_store_extra_tasks", 0),
        # pre-registration Parts 3-4 (statistics worker): repeat 2 of every cell in a LATER session; the
        # default gap is 6 h for real models and 0 for an all-simulated study (no provider, no cache)
        repeat_gap_hours=_float(p.get("repeat_gap_hours",
                                      0.0 if all(mcfg["models"][m].get("provider") == "sim" for m in models) else 6.0),
                                "probe.repeat_gap_hours", 0.0, 10000.0),
    )
    if probe.home_extra_offset < probe.repeats:
        raise StudyError("probe.home_extra_offset must be at least probe.repeats")
    if sub_on and probe.candidates > 6:
        raise StudyError("probe.subsets needs probe.candidates <= 6 (every subset is run)")

    e = _section(raw, "evaluate")
    lams = tuple(_float(x, "evaluate.fixed_lambdas") for x in _need(e, "fixed_lambdas", "evaluate"))
    ks = tuple(_int(x, "evaluate.k_values", 1) for x in _need(e, "k_values", "evaluate"))
    grid = tuple(_float(x, "evaluate.lambda_grid") for x in _need(e, "lambda_grid", "evaluate"))
    if not grid:
        raise StudyError("evaluate.lambda_grid is empty")
    ev = EvalSettings(
        calib_tasks=_int(_need(e, "calib_tasks", "evaluate"), "evaluate.calib_tasks", 1),
        calib_draws=_int(_need(e, "calib_draws", "evaluate"), "evaluate.calib_draws", 1),
        fixed_lambdas=lams, k_values=ks, lambda_grid=grid,
        shuffled_seeds=_int(_need(e, "shuffled_seeds", "evaluate"), "evaluate.shuffled_seeds", 1),
        w_sensitivity=tuple(_float(x, "evaluate.w_sensitivity") for x in e.get("w_sensitivity", [])),
        bootstrap=_int(_need(e, "bootstrap", "evaluate"), "evaluate.bootstrap", 100),
        seed=_int(_need(e, "seed", "evaluate"), "evaluate.seed", 0),
        summary_k=_int(e.get("summary_k", ks[0] if ks else 0), "evaluate.summary_k", 0),
        processes=_int(e.get("processes", 0), "evaluate.processes", 0),
        headline_family=str(e.get("headline_family", "ema_grade")),
        prob_clip=tuple(_float(x, "evaluate.prob_clip") for x in e.get("prob_clip", [0.01, 0.99])),
        ni_fraction=_float(e.get("ni_fraction", 0.25), "evaluate.ni_fraction"),
        min_difference=_float(e.get("min_difference", 0.05), "evaluate.min_difference"),
        ratio_min_z=_float(e.get("ratio_min_z", 4.0), "evaluate.ratio_min_z", 0.0, 100.0),
    )
    if ev.headline_family not in fams or ev.headline_family == "visits":
        raise StudyError(f"evaluate.headline_family {ev.headline_family!r} must be one of scores.families "
                         f"other than visits")
    if len(ev.prob_clip) != 2 or not (0.0 < ev.prob_clip[0] < ev.prob_clip[1] < 1.0):
        raise StudyError("evaluate.prob_clip must be [low, high] with 0 < low < high < 1, e.g. [0.01, 0.99]")
    if ev.calib_tasks >= sizes.n_probe:
        raise StudyError("evaluate.calib_tasks must be smaller than sizes.n_probe")
    # A k larger than the calibration pool (calibration tasks x candidates per task) cannot be
    # drawn as k distinct cells (pre-registration 2.6): it is skipped with a one-line note.
    pool_cells = ev.calib_tasks * probe.candidates
    notes = []
    skipped = tuple(k for k in ks if k > pool_cells)
    if skipped:
        notes.append(f"evaluate.k_values {list(skipped)} skipped: larger than the calibration pool of "
                     f"{pool_cells} cells ({ev.calib_tasks} calibration tasks x {probe.candidates} candidates)")
        kept = tuple(k for k in ks if k <= pool_cells)
        summary_k = ev.summary_k if ev.summary_k in kept else (kept[0] if kept else 0)
        ev = EvalSettings(**{**ev.__dict__, "k_values": kept, "k_skipped": skipped, "summary_k": summary_k})
    if sub_on and probe.subset_tasks > sizes.n_probe - ev.calib_tasks:
        raise StudyError("probe.subsets.tasks cannot be more than the evaluation probe tasks")

    o = raw.get("online") or {"enabled": False}
    if _bool(o.get("enabled", False), "online.enabled"):
        opairs = list(expand(_need(o, "pairs", "online"), "online.pairs"))
        for pr in expand(o.get("extra_pairs") or [], "online.extra_pairs"):
            if pr not in opairs:
                opairs.append(pr)
        oarms = tuple(str(a) for a in _need(o, "arms", "online"))
        for a in oarms:
            _check_arm(a, "online.arms")
            if a in ("oracle", "shuffled"):
                raise StudyError(f"online.arms: {a!r} cannot be run online")
        raw_ofams = _need(o, "families", "online")
        raw_ofams = [raw_ofams] if isinstance(raw_ofams, str) else list(raw_ofams or [])
        # `headline` = evaluate.headline_family: if the pilot rule of 9.2 replaces ema_grade, the run
        # after the swap ranks and learns with the new headline family's own rule (settled point 22)
        ofams = tuple(dict.fromkeys(ev.headline_family if str(t) == "headline" else str(t) for t in raw_ofams))
        for t in ofams:
            if t not in fams or t not in ONLINE_FAMILIES:
                raise StudyError(f"online.families: {t!r} must be in scores.families and one of {ONLINE_FAMILIES}")
        if ev.headline_family not in ofams:
            raise StudyError(f"online.families {list(ofams)} must include the headline family "
                             f"{ev.headline_family!r} (pre-registration 2.10); write  families: [headline]")
        if "tags_self" in ofams and not build.self_tag:
            raise StudyError("online.families tags_self needs build.self_tag: true")
        if any(not (a in _NO_CHECK_ARMS or a.startswith(_NO_CHECK_ARMS)) for a in oarms):
            missing = [pr for pr in opairs if pr not in pairs]
            if missing:
                raise StudyError(f"online.pairs {missing} are not probed swaps; arms with fresh checks need "
                                 f"their probe tables (add them to pairs)")
        if "credit" in ofams and "none" not in oarms:
            raise StudyError("online.families credit needs the 'none' arm (its no-memory results are the baseline)")
        online = OnlineSettings(True, tuple(opairs), oarms, ofams,
                                _int(_need(o, "n_show", "online"), "online.n_show", 1),
                                _float(_need(o, "epsilon", "online"), "online.epsilon"),
                                _bool(_need(o, "learn", "online"), "online.learn"),
                                _int(_need(o, "window", "online"), "online.window", 1),
                                _int(_need(o, "first_n", "online"), "online.first_n", 1),
                                _float(_need(o, "target_share", "online"), "online.target_share"),
                                _float(o.get("reexplore_epsilon", build.epsilon), "online.reexplore_epsilon"))
        for a in oarms:
            if a.startswith("reexplore_") and int(a.split("_")[1]) > sizes.n_test:
                raise StudyError(f"online.arms: {a} re-explores more tasks than the {sizes.n_test} test tasks")
        if online.n_show > build.candidates:
            raise StudyError("online.n_show cannot be larger than build.candidates")
        if sizes.n_test == 0:
            raise StudyError("online.enabled needs sizes.n_test > 0")
    else:
        online = OnlineSettings(False, (), (), (), 1, 0.0, True, 50, 100, 0.95)

    v = raw.get("variants") or {"enabled": False}
    if _bool(v.get("enabled", False), "variants.enabled"):
        vv = str(_need(v, "variant", "variants"))
        if vv not in PROMPT_VARIANTS or vv == prompt_variant:
            raise StudyError(f"variants.variant must be a wording other than prompt_variant ({prompt_variant})")
        vp = list(expand(_need(v, "pairs", "variants"), "variants.pairs", allow_home=True))
        for a, b2 in list(vp):
            for m in (a, b2):
                if (m, m) not in vp:
                    vp.append((m, m))          # home cells give the variant's home validity
        variants = VariantSettings(True, vv, tuple(vp), _int(_need(v, "tasks", "variants"), "variants.tasks", 1))
        if variants.tasks > sizes.n_probe - ev.calib_tasks:
            raise StudyError("variants.tasks cannot be more than the evaluation probe tasks")
    else:
        variants = VariantSettings(False, "v2", (), 0)

    j = raw.get("judge") or {"enabled": False}
    if _bool(j.get("enabled", False), "judge.enabled"):
        jspec = j.get("cells", "cells")
        jcells = tuple((m, m) for m in models) + tuple(pairs) if jspec == "cells" else \
            expand(jspec, "judge.cells", allow_home=True)
        judge = JudgeSettings(True, tuple(dict.fromkeys(jcells)), build.rating_scale)
    else:
        judge = JudgeSettings(False, (), build.rating_scale)

    rl = raw.get("relearn") or {"enabled": False}
    if _bool(rl.get("enabled", False), "relearn.enabled"):
        rpairs = expand(_need(rl, "pairs", "relearn"), "relearn.pairs")
        relearn = RelearnSettings(True, rpairs, _bool(rl.get("self_tag", False), "relearn.self_tag"),
                                  _int(rl.get("repeat_offset", 200), "relearn.repeat_offset", 1))
        if relearn.self_tag and not build.self_tag:
            raise StudyError("relearn.self_tag needs build.self_tag: true")
        if relearn.repeat_offset < build.second_bank_repeat_offset + build.epochs:
            raise StudyError("relearn.repeat_offset must be above the second bank's repeats "
                             "(build.second_bank_repeat_offset + build.epochs)")
    else:
        relearn = RelearnSettings(False, (), False, 200)

    sim_sec = raw.get("simulator") or {}
    simulator = SimSettings(correct_bonus=_float(sim_sec.get("correct_bonus", 0.0), "simulator.correct_bonus",
                                                 0.0, 10.0))
    if simulator.correct_bonus:
        # a study-level switch for the simulated models only: their params get correct_bonus in THIS
        # study's copy of the models config (config/models.yaml itself is unchanged)
        import copy
        mcfg = copy.deepcopy(mcfg)
        for m in models:
            mm = mcfg["models"][m]
            if mm.get("provider") == "sim":
                mm["params"] = {**(mm.get("params") or {}), "correct_bonus": simulator.correct_bonus}
        notes.append(f"simulator.correct_bonus {simulator.correct_bonus:g}: a simulated item helps more when its "
                     f"stored answer was graded correct (off in sim and simfull)")

    es = _section(raw, "estimate")
    out_tokens = dict(_need(es, "out_tokens", "estimate"))
    for s in streams:
        if s not in out_tokens:
            raise StudyError(f"estimate.out_tokens needs a value for {s}")
    estimate = EstimateSettings(out_tokens={k: float(x) for k, x in out_tokens.items()},
                                selfmark_out_tokens=float(_need(es, "selfmark_out_tokens", "estimate")),
                                token_factor={str(k): float(x) for k, x in (es.get("token_factor") or {}).items()})

    return Study(name=name, path=path, models=tuple(models), pairs=pairs, upgrade_pairs=upgrades,
                 streams=tuple(streams), seeds=tuple(seeds), sizes=sizes, exclude_tasks=tuple(excl),
                 bird_faithful=bird_faithful, prompt_variant=prompt_variant,
                 embedding_model=embedding_model, max_tokens=max_tokens, grade_cache=grade_cache,
                 workers=workers, build=build, scores=scores, probe=probe, evaluate=ev, online=online,
                 variants=variants, estimate=estimate, models_cfg=mcfg, raw=raw, notes=tuple(notes),
                 judge=judge, relearn=relearn, extension_pairs=tuple(ext_pairs), simulator=simulator)


# ---------------------------------------------------------------------------
# Planned calls (counted, never made)
# ---------------------------------------------------------------------------


def _prompt_sizes() -> dict:
    p = D.DATA_DIR / "prompt_sizes.json"
    if not p.exists():
        raise StudyError(f"{p} is missing; run  python -m msr.prompts  to measure prompt sizes")
    return json.loads(p.read_text(encoding="utf-8"))["streams"]


#: Tokens of the fixed instruction around one stored item in a rating prompt (self-rating, judge);
#: measured on the prompts of msr/build.py (rating_prompt) with len(text) / 4, rounded up.
RATING_PROMPT_TOKENS = 110


def subset_sizes(k: int) -> list:
    """Sizes of the subsets run in the realism check: every subset of 2..k candidates."""
    return [s for s in range(2, k + 1) for _ in combinations(range(k), s)]


def plan_calls(st: Study) -> dict:
    """Count every call the study will make, per stage and model, without making any.

    Returns {"calls": {stage: {model: n}}, "tokens_in", "tokens_out", "usd", "exact", "notes"}.
    Tokens come from data/prompt_sizes.json and estimate.out_tokens; prices from
    config/models.yaml. Counts are call invocations: a call whose exact prompt was already
    answered comes from the cache and costs nothing, so real spend is at most this."""
    sizes = _prompt_sizes()
    calls: dict = {s: {} for s in STAGES}
    tin: dict = {s: {} for s in STAGES}
    tout: dict = {s: {} for s in STAGES}
    notes = []
    exact = st.build.store == "all"
    notes += list(st.notes)
    if not exact:
        notes.append("build.store is correct_only: self-tag, probe and subset counts are upper bounds")

    def add(stage, model, n, tokens_in_each, tokens_out_each):
        if n <= 0:
            return
        f = st.estimate.token_factor.get(model, 1.0)
        calls[stage][model] = calls[stage].get(model, 0) + n
        tin[stage][model] = tin[stage].get(model, 0.0) + n * tokens_in_each * f
        tout[stage][model] = tout[stage].get(model, 0.0) + n * tokens_out_each * f

    def prompt_in(stream, k):
        s = sizes[stream]
        if k <= 0:
            return s["zero_shot"]["mean"]
        return s["one_memory_item"]["mean"] + (k - 1) * s["memory_item_alone"]["mean"]

    n_items = st.build.n_write                          # store: all -> one item per write task
    shown = min(st.build.n_show, st.build.candidates, n_items)
    k_probe = min(st.probe.candidates, n_items)
    readers = list(dict.fromkeys(r for _, r in st.cells))
    for stream in st.streams:
        out_t = st.estimate.out_tokens[stream]
        sm_in = sizes[stream]["one_memory_item"]["mean"]
        # a rating prompt (self-rating, judge) shows ONE stored item and a fixed instruction
        rate_in = sizes[stream]["memory_item_alone"]["mean"] + RATING_PROMPT_TOKENS
        rate_out = st.estimate.selfmark_out_tokens
        for _seed in st.seeds:
            for m in st.models:
                add("write", m, st.build.n_write, prompt_in(stream, 0), out_t)
                if st.build.write_repeat:
                    add("write2", m, st.build.n_write, prompt_in(stream, 0), out_t)
                if st.build.self_rating:
                    add("selfrate", m, n_items, rate_in, rate_out)
                if st.build.no_memory_run:
                    add("build0", m, st.n_score, prompt_in(stream, 0), out_t)
                for _bank in st.banks_of(m):
                    add("build", m, st.build.epochs * st.n_score, prompt_in(stream, shown), out_t)
                    if st.build.self_tag:
                        add("selfmark", m, st.build.epochs * st.n_score * shown, sm_in, st.estimate.selfmark_out_tokens)
            for owner, reader in st.cells:
                add("probe", reader, st.sizes.n_probe * k_probe * st.probe.repeats, prompt_in(stream, 1), out_t)
                if owner == reader:
                    add("probe_extra", reader, st.sizes.n_probe * k_probe * st.probe.home_extra_repeats,
                        prompt_in(stream, 1), out_t)
            for reader in readers:
                add("probe0", reader, st.sizes.n_probe * st.probe.no_memory_repeats, prompt_in(stream, 0), out_t)
            if st.probe.subsets_enabled:
                for _owner, reader in st.probe.subset_cells:
                    for s in subset_sizes(k_probe):
                        add("subset", reader, st.probe.subset_tasks, prompt_in(stream, s), out_t)
            if st.variants.enabled:
                for _owner, reader in st.variants.cells:
                    add("variant", reader, st.variants.tasks * k_probe * st.probe.repeats, prompt_in(stream, 1), out_t)
                for reader in dict.fromkeys(r for _, r in st.variants.cells):
                    add("variant0", reader, st.variants.tasks * st.probe.no_memory_repeats, prompt_in(stream, 0), out_t)
            if st.judge.enabled:
                for _owner, reader in st.judge.cells:
                    add("judge", reader, n_items, rate_in, rate_out)
            if st.relearn.enabled:
                for _owner, reader in st.relearn.pairs:
                    add("relearn", reader, st.build.epochs * st.n_score, prompt_in(stream, shown), out_t)
                    if st.relearn.self_tag:
                        add("relearn_tag", reader, st.build.epochs * st.n_score * shown, sm_in,
                            st.estimate.selfmark_out_tokens)
            extra = st.probe.check_store_extra_tasks
            if extra:
                # OPTION (not built): more evaluation tasks in the home and swap cells of the same-maker
                # pairs, for the paired keep-or-drop check (its median need is about 730 tasks)
                sm_cells = [c for c in st.cells if c[0] != c[1] and st.kind(*c) == "same_family"]
                sm_models = list(dict.fromkeys(m for c in sm_cells for m in c))
                for _owner, reader in sm_cells:
                    add("check_store", reader, extra * k_probe * st.probe.repeats, prompt_in(stream, 1), out_t)
                for m in sm_models:
                    add("check_store", m, extra * k_probe * (st.probe.repeats + st.probe.home_extra_repeats),
                        prompt_in(stream, 1), out_t)
                    add("check_store", m, extra * st.probe.no_memory_repeats, prompt_in(stream, 0), out_t)
            if st.online.enabled:
                for _owner, reader in st.online.pairs:
                    for arm in st.online.arms:
                        n_runs = 1 if arm in ("none", "relevance") else len(st.online.families)
                        k = 0 if arm == "none" else min(st.online.n_show, n_items)
                        add("online", reader, n_runs * st.sizes.n_test, prompt_in(stream, k), out_t)
                        # tags_self learns from the reader's own tag: one tag call per shown item
                        if (st.online.learn and arm not in ("none", "relevance")
                                and "tags_self" in st.online.families):
                            add("selfmark", reader, st.sizes.n_test * k, sm_in, st.estimate.selfmark_out_tokens)
    usd: dict = {s: {} for s in STAGES}
    for s in STAGES:
        for m in calls[s]:
            mc = st.models_cfg["models"][m]
            usd[s][m] = (tin[s][m] * float(mc.get("price_in", 0)) + tout[s][m] * float(mc.get("price_out", 0))) / 1e6
    return {"calls": calls, "tokens_in": tin, "tokens_out": tout, "usd": usd, "exact": exact, "notes": notes}


def plan_table(st: Study, plan: dict | None = None) -> str:
    """The plan as a plain text table: calls per stage and model, then dollars."""
    plan = plan or plan_calls(st)
    stages = [s for s in STAGES if plan["calls"][s]]
    w = max(12, max(len(m) for m in st.models) + 2)
    head = "model".ljust(w) + "".join(s.rjust(12) for s in stages) + "total".rjust(11) + "est. USD".rjust(11)
    lines = [head, "-" * len(head)]
    col_tot = {s: 0 for s in stages}
    tot_calls, tot_usd = 0, 0.0
    for m in st.models:
        row = [plan["calls"][s].get(m, 0) for s in stages]
        usd = sum(plan["usd"][s].get(m, 0.0) for s in stages)
        for s, n in zip(stages, row):
            col_tot[s] += n
        tot_calls += sum(row)
        tot_usd += usd
        lines.append(m.ljust(w) + "".join(f"{n:>12,}" for n in row) + f"{sum(row):>11,}" + f"{usd:>11.2f}")
    lines.append("-" * len(head))
    lines.append("all".ljust(w) + "".join(f"{col_tot[s]:>12,}" for s in stages) + f"{tot_calls:>11,}" + f"{tot_usd:>11.2f}")
    for n in plan["notes"]:
        lines.append("note: " + n)
    return "\n".join(lines)


def total_calls(plan: dict) -> int:
    return int(sum(n for s in plan["calls"].values() for n in s.values()))


def total_usd(plan: dict) -> float:
    return float(sum(v for s in plan["usd"].values() for v in s.values()))


def missing_keys(st: Study) -> list:
    """Names of key variables (never their values) that the study's real models need and
    that are not set. Simulated models need no key."""
    import os
    L.load_env()
    out = []
    for m in st.models:
        prov = st.models_cfg["models"][m].get("provider")
        if prov == "sim":
            continue
        env = (st.models_cfg.get("providers", {}).get(prov) or {}).get("key_env")
        if env and not L.provider_key(st.models_cfg, prov) and env not in out:
            out.append(env)
    return out


def describe(st: Study) -> str:
    return (f"study '{st.name}': {len(st.models)} models, {len(st.pairs)} swaps + {len(st.models)} home cells, "
            f"streams {list(st.streams)}, seeds {list(st.seeds)}, build {st.build.n_write} write + "
            f"{st.n_score} score tasks x {st.build.epochs} epochs, probe {st.sizes.n_probe}, test {st.sizes.n_test}")
