"""Find the memory items most similar to a new task.

Everyday picture: the librarian holds the new case's card next to every filed
card and hands back the k closest ones, closest first. "Closeness" is the cosine
similarity of the two vectors, turned into a relevance between 0 and 1 by
(cos + 1) / 2, so 1 = same direction, 0.5 = unrelated, 0 = opposite.

Same answer on every machine: relevances are worked out in float64 and rounded to
6 decimals before sorting, and equal relevances are ordered by item id (the
smaller id first). So two machines whose arithmetic differs in the last few bits
still return the same list in the same order.

StreamBench itself (agents/utils.py, RAG) uses a FAISS flat L2 index on unit
vectors; on unit vectors, smallest L2 distance = largest cosine, so the ranking is
the same. (StreamBench then puts the most similar item LAST in the prompt; that
ordering is the prompt builder's job, not this file's.)
"""
from __future__ import annotations

from pathlib import Path

import numpy as np

_DECIMALS = 6  # rounding of relevance before sorting (see the module note)


def _unit(a: np.ndarray) -> np.ndarray:
    """float64 copy with every row scaled to length 1 (all-zero rows stay zero)."""
    a = np.asarray(a, dtype=np.float64)
    if a.ndim == 1:
        n = np.linalg.norm(a)
        return a / n if n > 0 else a.copy()
    n = np.linalg.norm(a, axis=1, keepdims=True)
    n[n == 0] = 1.0
    return a / n


def relevance(query_vec: np.ndarray, item_vecs: np.ndarray) -> np.ndarray:
    """(cos + 1) / 2 for every row of item_vecs, rounded to 6 decimals, in [0, 1]."""
    if len(item_vecs) == 0:
        return np.zeros(0, dtype=np.float64)
    cos = _unit(item_vecs) @ _unit(query_vec)
    rel = np.clip((cos + 1.0) / 2.0, 0.0, 1.0)
    return np.round(rel, _DECIMALS)


def top_k(query_vec: np.ndarray, item_ids: list[str], item_vecs: np.ndarray,
          k: int) -> list[tuple[str, float]]:
    """The k items most similar to query_vec, as (item_id, relevance), best first.

    relevance = (cosine + 1) / 2; ties are broken by item_id (smaller first).
    Returns fewer than k pairs when there are fewer items; k <= 0 gives [].
    """
    item_ids = [str(i) for i in item_ids]
    if k <= 0 or not item_ids:
        return []
    item_vecs = np.asarray(item_vecs)
    if item_vecs.ndim != 2 or item_vecs.shape[0] != len(item_ids):
        raise ValueError(f"{len(item_ids)} ids but item_vecs has shape {item_vecs.shape}")
    rel = relevance(query_vec, item_vecs)
    # Rank of each id in plain sorted order, used as the tie-breaker.
    id_rank = np.empty(len(item_ids), dtype=np.int64)
    id_rank[np.argsort(np.array(item_ids), kind="stable")] = np.arange(len(item_ids))
    # np.lexsort sorts by the LAST key first: highest relevance, then smallest id.
    order = np.lexsort((id_rank, -rel))[:k]
    return [(item_ids[i], float(rel[i])) for i in order]


class Index:
    """A memory index that grows as the stream is processed.

    idx = Index()
    idx.add("ddxplus-0007", vec)
    idx.search(query_vec, k=16, exclude={"ddxplus-0042"})   # -> [(item_id, relevance), ...]
    idx.save(path); Index.load(path)
    """

    def __init__(self, dim: int | None = None):
        self.dim = dim
        self._ids: list[str] = []
        self._pos: dict[str, int] = {}
        self._vecs = np.zeros((0, dim or 0), dtype=np.float32)
        self._n = 0

    # ---- size and lookup
    def __len__(self) -> int:
        return self._n

    def __contains__(self, item_id: str) -> bool:
        return str(item_id) in self._pos

    @property
    def ids(self) -> list[str]:
        return list(self._ids)

    @property
    def vectors(self) -> np.ndarray:
        """The stored vectors, one row per id, in the order they were added."""
        return self._vecs[:self._n]

    def vector(self, item_id: str) -> np.ndarray:
        return self._vecs[self._pos[str(item_id)]]

    # ---- growing
    def add(self, item_id: str, vec: np.ndarray) -> None:
        """Add one item. Adding the same id twice is an error (it would be a bug upstream)."""
        item_id = str(item_id)
        if item_id in self._pos:
            raise ValueError(f"item {item_id!r} is already in the index")
        v = np.asarray(vec, dtype=np.float32).reshape(-1)
        if self.dim is None:
            self.dim = int(v.shape[0])
            self._vecs = np.zeros((0, self.dim), dtype=np.float32)
        if v.shape[0] != self.dim:
            raise ValueError(f"vector of length {v.shape[0]}, index holds length {self.dim}")
        if self._n == self._vecs.shape[0]:            # full: double the room
            grown = np.zeros((max(16, 2 * self._n), self.dim), dtype=np.float32)
            grown[:self._n] = self._vecs[:self._n]
            self._vecs = grown
        self._vecs[self._n] = v
        self._pos[item_id] = self._n
        self._ids.append(item_id)
        self._n += 1

    # ---- searching
    def search(self, query_vec: np.ndarray, k: int,
               exclude: set[str] | None = None) -> list[tuple[str, float]]:
        """top_k over the items added so far, leaving out the ids in `exclude`."""
        if self._n == 0 or k <= 0:
            return []
        ids, vecs = self._ids, self._vecs[:self._n]
        if exclude:
            keep = [i for i, item in enumerate(ids) if item not in exclude]
            ids = [ids[i] for i in keep]
            vecs = vecs[keep]
        return top_k(query_vec, ids, vecs, k)

    # ---- saving
    def save(self, path: str | Path) -> Path:
        """Write ids and vectors to a .npz file (no pickling, so it is safe to load)."""
        path = Path(path)
        if path.suffix != ".npz":
            path = path.with_name(path.name + ".npz")
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_name(path.stem + ".part.npz")
        np.savez(tmp, ids=np.array(self._ids, dtype=str),
                 vectors=self._vecs[:self._n], dim=np.array(self.dim or 0))
        tmp.replace(path)
        return path

    @classmethod
    def load(cls, path: str | Path) -> "Index":
        path = Path(path)
        if not path.exists() and path.suffix != ".npz":
            path = path.with_name(path.name + ".npz")
        with np.load(path, allow_pickle=False) as z:
            ids = [str(x) for x in z["ids"]]
            vecs = np.asarray(z["vectors"], dtype=np.float32)
            dim = int(z["dim"]) or None
        idx = cls(dim)
        for i, v in zip(ids, vecs):
            idx.add(i, v)
        return idx
