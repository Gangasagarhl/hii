"""The confirmatory analysis of the pre-registration (prediction/PREREGISTRATION.md, Parts 2-8).

Everyday picture: the garage has, for every old helper and every new helper, a sheet saying how
each repair tip worked on every job. This module reads those sheets (the per-task result files
that Stage C wrote) and answers, exactly as written down in advance, the questions of the paper:
do the old scores still rank the tips for the new helper, should the garage keep, wipe or discount
them, and which of the four registered predictions came true.

Everything here is computed from the files in runs/<study>/results/ (plus the post-swap logs in
runs/<study>/online/); no model is called. The output goes to runs/<study>/analysis/ as tidy CSV
files and ANALYSIS.md, which cites the CSV row behind every number it shows.

The one resampling scheme (pre-registration 4.1): in each draw the evaluation tasks of every task
stratum (stream, order) are resampled with replacement ONCE, and that same list is applied to every
owner, reader, arm, family, home and swap cell. The draws are the evaluate stage's own
(msr.metrics.bootstrap_counts with stratum_seed), so the per-pair numbers here equal those of
results/retained.csv at the same draw count. Ratio estimators (Cw, R) are recomputed from their
resampled numerators and weights, pooled over the orders of a stream; means are pooled over the
tasks of the three orders with equal weight per task (Part 2.12). Orders are fixed strata, never
resampled.

The raw cells (results/cells/) add the split-half references with intervals, the noise-adjusted
ratio R_adj, the inverse-propensity scores, Owen's pigeonhole bootstrap and the model-based ceiling.
Any study shape works: groups without swaps leave the confirmatory family (which then shrinks, and
ANALYSIS.md says so in its first lines), predictions the models at hand cannot test are reported as
"not testable here (needs ...)", and missing optional stages are skipped with a one-line note.

Run:  python -m msr.analysis --study sim            (or a study file, e.g. config/sim.yaml)
"""
from __future__ import annotations

import argparse
import csv
import itertools
import json
import math
import os
import re
import sys
import time
import warnings
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from msr import metrics as M  # noqa: E402

NAN = float("nan")
NO_FAMILY = "-"                       # family of the arms that ignore scores (none, relevance, split_half, ceiling)
#: file-name prefixes of the other modules that write into runs/<study>/analysis/ (never deleted here)
OTHER_PRODUCERS = ("construct_", "decomp_", "law_", "forecast_", "sequential_", "theory_", "slope_", "family_t")
GROUPS = ("upgrade", "downgrade", "cross")          # the three swap strata of the confirmatory tests
GROUP_LABEL = {"upgrade": "same-maker upgrades", "downgrade": "same-maker downgrades",
               "cross": "cross-maker swaps", "same_maker": "all same-maker swaps",
               "all_swaps": "all swaps (descriptive)", "home": "home cells (self-swap reference)",
               "same_other": "other same-maker swaps"}
GROUP_LABEL["same_family"] = GROUP_LABEL["same_maker"]      # the old key, still accepted
DESC_GROUPS = GROUPS + ("same_maker", "all_swaps", "home")
#: arms that ignore the scores (family "-"); `split_half` was called `oracle` before the round-1 revision
NO_FAMILY_ARMS = ("none", "relevance", "split_half", "ceiling", "oracle")
USEFUL = ("ema_grade", "beta_grade", "tags_self", "credit")
CHECK_ARMS = ("powerprior", "powerprior_flat", "recal", "retest", "audit", "pooled", "fresh")
ARM_ORDER = ("none", "relevance", "keep", "wipe", "constant", "fixed", "shuffled") + CHECK_ARMS + \
    ("own", "split_half", "ceiling", "oracle")
METRICS = ("value", "regret", "log", "brier", "log_lc", "brier_lc", "log_lcw", "brier_lcw")
METRIC_LABEL = {"value": "first-shown success", "regret": "regret", "log": "held-out log score",
                "brier": "Brier score", "log_lc": "held-out log score, level-corrected",
                "brier_lc": "Brier score, level-corrected",
                # revision 2 (R6 W7): the base-rate sensitivity, level target = the reader's with-item success
                "log_lcw": "held-out log score, level-corrected to the reader's with-item success",
                "brier_lcw": "Brier score, level-corrected to the reader's with-item success"}
EQUAL_BUDGET_RIVALS = ("fresh", "pooled", "powerprior", "retest", "audit")
#: Resampled statistics closer to 0 than this count as exactly 0 in the p-values of 4.2 (outcomes are
#: 0/1, so exact ties are common, and float summation order must not decide which side they fall on).
ZERO_TOL = 1e-12


# ===========================================================================
# Small numeric helpers
# ===========================================================================


def nanmean(a, axis=None):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        return np.nanmean(a, axis=axis)


def fin(x) -> bool:
    try:
        return x is not None and math.isfinite(float(x))
    except (TypeError, ValueError):
        return False


def num(v) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return NAN


def pvals(draws: np.ndarray) -> tuple:
    """Pre-registration 4.2: p_upper (evidence that theta > 0), p_lower (theta < 0), two-sided."""
    d = np.asarray(draws, dtype=float)
    d = d[np.isfinite(d)]
    if d.size == 0:
        return NAN, NAN, NAN
    d = np.where(np.abs(d) < ZERO_TOL, 0.0, d)     # an exact tie stays a tie after float summation
    b = d.size
    pu = (1.0 + float(np.sum(d <= 0))) / (b + 1.0)
    pl = (1.0 + float(np.sum(d >= 0))) / (b + 1.0)
    return pu, pl, min(1.0, 2.0 * min(pu, pl))


def summarize(point: float, draws: np.ndarray, level: float = 0.95) -> dict:
    """Point estimate, percentile interval, bootstrap SE and the three p-values of 4.2."""
    d = np.asarray(draws, dtype=float)
    d = d[np.isfinite(d)]
    if not fin(point) or d.size == 0:
        return {"est": point if fin(point) else NAN, "lo": NAN, "hi": NAN, "se": NAN,
                "p_upper": NAN, "p_lower": NAN, "p_two": NAN}
    tail = (1.0 - level) / 2.0 * 100.0
    lo, hi = np.percentile(d, [tail, 100.0 - tail])
    pu, pl, p2 = pvals(d)
    return {"est": float(point), "lo": float(lo), "hi": float(hi),
            "se": float(d.std(ddof=1)) if d.size > 1 else NAN, "p_upper": pu, "p_lower": pl, "p_two": p2}


def summarize_many(points, draws: np.ndarray) -> list:
    """summarize() for many statistics at once: points (q,), draws (B, q). Same numbers as calling
    summarize() column by column; complete columns are done in one vectorised pass."""
    P = np.asarray(points, dtype=float).reshape(-1)
    out: list = [None] * len(P)
    if not len(P):
        return out
    D = np.asarray(draws, dtype=float).reshape(-1, len(P))
    full = np.isfinite(D).all(axis=0) & np.isfinite(P)
    if full.any() and D.shape[0] > 1:
        Df = D[:, full]
        lo, hi = np.percentile(Df, [2.5, 97.5], axis=0)
        se = Df.std(axis=0, ddof=1)
        b = Df.shape[0]
        Dz = np.where(np.abs(Df) < ZERO_TOL, 0.0, Df)
        pu = (1.0 + (Dz <= 0).sum(axis=0)) / (b + 1.0)
        pl = (1.0 + (Dz >= 0).sum(axis=0)) / (b + 1.0)
        p2 = np.minimum(1.0, 2.0 * np.minimum(pu, pl))
        for n, j in enumerate(np.flatnonzero(full)):
            out[j] = {"est": float(P[j]), "lo": float(lo[n]), "hi": float(hi[n]), "se": float(se[n]),
                      "p_upper": float(pu[n]), "p_lower": float(pl[n]), "p_two": float(p2[n])}
    for j in range(len(P)):
        if out[j] is None:
            out[j] = summarize(P[j], D[:, j])
    return out


class Pending:
    """Collect (row, prefix, point, draws) and summarise them in one batch: the estimate goes to
    row[prefix] (or row['est'] without a prefix), the interval to <prefix>_lo / _hi, and the
    two-sided p (if asked) to <prefix>_p."""

    def __init__(self):
        self.items: list = []

    def add(self, row: dict, prefix: str, point: float, draws: np.ndarray, with_p: bool = False):
        self.items.append((row, prefix, point, draws, with_p))

    def flush(self) -> None:
        if not self.items:
            return
        sms = summarize_many([x[2] for x in self.items], np.column_stack([x[3] for x in self.items]))
        for (row, prefix, _pt, _d, with_p), sm in zip(self.items, sms):
            if prefix:
                row.update({prefix: sm["est"], f"{prefix}_lo": sm["lo"], f"{prefix}_hi": sm["hi"]})
                if with_p:
                    row[f"{prefix}_p"] = sm["p_two"]
            else:
                row.update(est=sm["est"], lo=sm["lo"], hi=sm["hi"])
                if with_p:
                    row["p_two"] = sm["p_two"]
        self.items = []


def spearman(x, y) -> float:
    x, y = np.asarray(x, float), np.asarray(y, float)
    ok = np.isfinite(x) & np.isfinite(y)
    if ok.sum() < 3:
        return NAN
    from scipy.stats import rankdata
    rx, ry = rankdata(x[ok]), rankdata(y[ok])
    if rx.std() == 0 or ry.std() == 0:
        return NAN
    return float(np.corrcoef(rx, ry)[0, 1])


def spearman_rows(a: np.ndarray, y: np.ndarray) -> np.ndarray:
    """Spearman correlation of every row of a (perms, n) with the fixed vector y (n,)."""
    from scipy.stats import rankdata
    a = np.asarray(a, float)
    y = np.asarray(y, float)
    out = np.full(a.shape[0], NAN)
    if np.isfinite(a).all() and np.isfinite(y).all():
        ra = rankdata(a, axis=1)
        ry = rankdata(y)
        ra = ra - ra.mean(axis=1, keepdims=True)
        ry = ry - ry.mean()
        den = np.sqrt((ra ** 2).sum(axis=1) * (ry ** 2).sum())
        with np.errstate(invalid="ignore", divide="ignore"):
            out = np.where(den > 0, (ra @ ry) / np.where(den > 0, den, 1.0), NAN)
        return out
    for i in range(a.shape[0]):
        out[i] = spearman(a[i], y)
    return out


def holm_steps(pvalues, alpha: float = 0.05) -> dict:
    """Holm's step-down (pre-registration 5.1). Returns, in input order: the Holm-adjusted
    p-value, whether the hypothesis is rejected, and the threshold alpha / (m - j + 1) the
    step-down reached for it (None if it stopped before). A missing p counts as 1."""
    p = np.array([float(x) if fin(x) else 1.0 for x in pvalues], dtype=float)
    m = len(p)
    if m == 0:
        return {"adjusted": [], "reject": [], "threshold": [], "rank": []}
    order = np.argsort(p, kind="stable")
    thr: list = [None] * m
    rej = [False] * m
    rank = [0] * m
    going = True
    for j, i in enumerate(order):
        rank[i] = j + 1
        t = alpha / (m - j)
        if going:
            thr[i] = t
            if p[i] <= t:
                rej[i] = True
            else:
                going = False
    adj_sorted = np.minimum(1.0, np.maximum.accumulate((m - np.arange(m)) * p[order]))
    adj = np.empty(m)
    adj[order] = adj_sorted
    return {"adjusted": [float(x) for x in adj], "reject": rej, "threshold": thr, "rank": rank}


def arm_parts(arm: str) -> tuple:
    """('fixed', 0.5), ('recal', 64), ('keep', None) ..."""
    if arm.startswith("fixed_"):
        return "fixed", num(arm[6:])
    m = re.match(r"^(.*)_(\d+)$", arm)
    if m and m.group(1) in CHECK_ARMS:
        return m.group(1), int(m.group(2))
    return arm, None


def arm_sort_key(arm: str) -> tuple:
    base, par = arm_parts(arm)
    i = ARM_ORDER.index(base) if base in ARM_ORDER else len(ARM_ORDER)
    return (i, par if par is not None else -1, arm)


# ===========================================================================
# Design and data
# ===========================================================================


@dataclass
class Design:
    """What the analysis needs to know about the study (independent of msr.study, so a test can
    build a tiny synthetic design by hand)."""
    name: str
    models: list
    family: dict                       # model -> maker family
    upgrades: list                     # [(old, new)]
    streams: list
    seeds: list
    score_families: list
    headline: str = "ema_grade"
    pairs: list = field(default_factory=list)          # ordered swaps (owner != reader) that were run
    k_values: list = field(default_factory=lambda: [8, 16, 32, 64])
    fixed_lambdas: list = field(default_factory=lambda: [0.5])
    all_sim: bool = False
    primary_k_wanted: int = 64
    primary_lambda: float = 0.5
    alpha: float = 0.05
    ni_fraction: float = 0.25
    min_difference: float = 0.05
    ratio_min_z: float = 4.0
    unbounded_share: float = 0.005
    first_n: int = 100
    window: int = 50
    target_share: float = 0.95
    w_score: float = 0.5
    prices: dict = field(default_factory=dict)
    kind: str = "real"                 # simulated | preliminary | real (labels of macros and banners)
    # calls of ONE swap day (one owner bank, one reader, one stream, one order), from the study sizes
    # (revision 2 cost accounting; NaN when the design is built by hand)
    own_build_calls: float = float("nan")      # one reader build: write + no-memory run + score epochs (+ tags)
    level_calls: float = float("nan")          # reader no-memory runs of the calibration tasks (level information)
    owner_pool_calls: float = float("nan")     # owner's stored home results on the calibration pool (2 repeats)

    def __post_init__(self):
        if not self.pairs:
            self.pairs = [(s, t) for s in self.models for t in self.models if s != t]

    @property
    def cells(self) -> list:
        return [(m, m) for m in self.models] + [p for p in self.pairs if p[0] != p[1]]

    @property
    def primary_k(self) -> int | None:
        if self.primary_k_wanted in self.k_values:
            return self.primary_k_wanted
        return max(self.k_values) if self.k_values else None

    def group(self, s: str, t: str) -> str:
        if s == t:
            return "home"
        if self.family.get(s) != self.family.get(t):
            return "cross"
        if (s, t) in self.upgrades:
            return "upgrade"
        if (t, s) in self.upgrades:
            return "downgrade"
        return "same_other"

    def in_group(self, s: str, t: str, g: str) -> bool:
        k = self.group(s, t)
        if g in ("same_maker", "same_family"):
            return k in ("upgrade", "downgrade", "same_other")
        if g == "all_swaps":
            return k != "home"
        return k == g

    def swaps(self, g: str = "all_swaps") -> list:
        cells = self.cells if g == "home" else [p for p in self.pairs if p[0] != p[1]]
        out = [p for p in cells if self.in_group(*p, g)]
        gi = {x: j for j, x in enumerate(("upgrade", "downgrade", "same_other", "cross", "home"))}
        mi = {m: j for j, m in enumerate(self.models)}
        return sorted(out, key=lambda p: (gi[self.group(*p)], mi[p[0]], mi[p[1]]))


@dataclass
class PerTask:
    """Per-task arrays of every cell, as (tasks, cells) matrices per task stratum (stream, seed).
    A 2-D per-task array (the concordance numerator and weight) becomes two keys, 'key#num' and
    'key#den'. A cell or key that is missing is NaN."""
    cells: list
    strata: list                       # [(stream, seed)]
    tasks: dict                        # stratum -> list of task ids
    mats: dict                         # stratum -> {key: (n, len(cells)) float array}

    def keys(self) -> set:
        out = set()
        for m in self.mats.values():
            out |= set(m)
        return out


def per_task_from_cells(design: Design, cell_arrays: dict) -> PerTask:
    """Build PerTask from {(owner, reader, stream, seed): {"tasks": ids, key: array}}."""
    cells = design.cells
    ci = {c: j for j, c in enumerate(cells)}
    strata = sorted({(k[2], k[3]) for k in cell_arrays}, key=lambda s: (design.streams.index(s[0])
                                                                       if s[0] in design.streams else 99, s[1]))
    tasks, mats = {}, {}
    for s in strata:
        order: list = []
        seen: set = set()
        for c in cells:
            arr = cell_arrays.get((c[0], c[1], s[0], s[1]))
            if arr is None:
                continue
            for t in arr["tasks"]:
                t = str(t)
                if t not in seen:
                    seen.add(t)
                    order.append(t)
        pos = {t: j for j, t in enumerate(order)}
        n, nc = len(order), len(cells)
        mm: dict = {}
        for c in cells:
            arr = cell_arrays.get((c[0], c[1], s[0], s[1]))
            if arr is None:
                continue
            rows = np.array([pos[str(t)] for t in arr["tasks"]], dtype=int)
            j = ci[c]
            for key, v in arr.items():
                if key == "tasks":
                    continue
                v = np.asarray(v, dtype=float)
                if v.ndim == 1:
                    parts = [(key, v)]
                elif v.shape[1] == 2:
                    parts = [(key + "#num", v[:, 0]), (key + "#den", v[:, 1])]
                else:
                    parts = [(f"{key}#{q}", v[:, q]) for q in range(v.shape[1])]
                for kk, vv in parts:
                    if kk not in mm:
                        mm[kk] = np.full((n, nc), np.nan, dtype=np.float32)
                    mm[kk][rows, j] = vv
        tasks[s] = order
        mats[s] = mm
    return PerTask(cells=cells, strata=strata, tasks=tasks, mats=mats)


# ===========================================================================
# The joint bootstrap (pre-registration 4.1)
# ===========================================================================


class JointBootstrap:
    """One resampled task list per task stratum (stream, order) and draw, shared by every cell.

    idx[stratum] is the (draws, tasks) array of resampled task positions; counts[stratum] holds how
    often each task was drawn in each draw. Every statistic of every pair, arm and family is
    recomputed from these same counts, so all correlations between pairs are kept.

    The draws are those of the evaluate stage (msr.metrics.bootstrap_counts): numpy's default
    generator seeded with stratum_seed(seed, stream, order), drawn in the same chunks, so this
    analysis and results/retained.csv resample exactly the same tasks."""

    def __init__(self, sizes: dict, n_draws: int, seed: int = 0, task_ids: dict | None = None):
        self.n_draws = int(n_draws)
        self.seed = int(seed)
        self.idx: dict = {}
        self.counts: dict = {}
        if task_ids is not None:
            # round-1 revision (Part 4.1): task IDS are the clusters, pooled over the orders of a
            # stream (a task in two orders' evaluation sets is one draw, with all its appearances)
            from msr import metrics as _M
            self.counts = _M.task_cluster_counts({k: list(task_ids[k]) for k in sizes}, self.n_draws, self.seed)
            self.cluster = "task id, pooled over the orders of a stream"
            return
        self.cluster = "task within (stream, order)"
        for key in sorted(sizes, key=lambda k: (str(k[0]), str(k[1]))):
            n = int(sizes[key])
            rng = np.random.default_rng(stratum_seed(self.seed, key[0], key[1]))
            chunk = max(1, min(self.n_draws, 4_000_000 // max(n, 1)))
            parts = []
            for start in range(0, self.n_draws, chunk):
                c = min(chunk, self.n_draws - start)
                parts.append(rng.integers(0, n, size=(c, n)).astype(np.int32))
            idx = np.vstack(parts) if parts else np.zeros((0, n), np.int32)
            off = idx.astype(np.int64) + (np.arange(self.n_draws, dtype=np.int64)[:, None] * n)
            cnt = np.bincount(off.ravel(), minlength=self.n_draws * n).reshape(self.n_draws, n)
            self.idx[key] = idx
            self.counts[key] = cnt.astype(np.float64)

    def resampled_sum(self, key, x: np.ndarray) -> np.ndarray:
        """Sum of x over the resampled tasks of every draw (NaN counted as 0)."""
        x = np.nan_to_num(np.asarray(x, dtype=float))
        return self.counts[key] @ x


def stratum_seed(seed: int, stream: str, order) -> list:
    """The pipeline's seed of one task stratum (msr.metrics.stratum_seed; same formula here so
    the analysis can also run on files alone)."""
    try:
        from msr import metrics as _M
        if hasattr(_M, "stratum_seed"):
            return _M.stratum_seed(seed, stream, order)
    except Exception:          # pragma: no cover - metrics is always importable in this repo
        pass
    import hashlib
    h = int.from_bytes(hashlib.sha256(f"boot|{stream}|{order}".encode()).digest()[:8], "big")
    return [int(seed), h]


class Engine:
    """Pooled per-stream values (points and bootstrap draws) of per-task keys, for every cell."""

    def __init__(self, design: Design, data: PerTask, n_boot: int, seed: int = 0):
        self.d = design
        self.data = data
        self.boot = JointBootstrap({s: len(data.tasks[s]) for s in data.strata}, n_boot, seed, task_ids=data.tasks)
        self.B = int(n_boot)
        self.ci = {c: j for j, c in enumerate(data.cells)}
        self.streams = [b for b in design.streams if any(s[0] == b for s in data.strata)]
        self.levels = self.streams + ["all"]
        self._cache: dict = {}
        self._keys = data.keys()

    def has(self, key: str) -> bool:
        return key in self._keys or (key + "#num") in self._keys

    def _blocks(self, keys: list, ratio: bool) -> dict:
        nc = len(self.data.cells)
        q = len(keys) * nc
        out = {}
        for b in self.streams:
            num_pt = np.zeros(q)
            den_pt = np.zeros(q)
            num_b = np.zeros((self.B, q))
            den_b = np.zeros((self.B, q))
            for s in self.data.strata:
                if s[0] != b:
                    continue
                mats = self.data.mats[s]
                n = len(self.data.tasks[s])
                cnt = self.boot.counts[s]

                def block(suffix):
                    cols = [mats.get(k + suffix) for k in keys]
                    return np.concatenate([c if c is not None else np.full((n, nc), np.nan, np.float32)
                                           for c in cols], axis=1).astype(np.float64)

                if ratio:
                    N = np.nan_to_num(block("#num"))
                    W = np.nan_to_num(block("#den"))
                    num_pt += N.sum(axis=0)
                    den_pt += W.sum(axis=0)
                    num_b += cnt @ N
                    den_b += cnt @ W
                else:
                    X = block("")
                    V = np.isfinite(X)
                    X0 = np.where(V, X, 0.0)
                    num_pt += X0.sum(axis=0)
                    den_pt += V.sum(axis=0)
                    num_b += cnt @ X0
                    full = V.all(axis=0)
                    # the task-id cluster bootstrap resamples a varying number of a stratum's tasks per draw
                    den_b[:, full] += cnt.sum(axis=1)[:, None]
                    if (~full).any():
                        den_b[:, ~full] += cnt @ V[:, ~full].astype(np.float64)
            with np.errstate(invalid="ignore", divide="ignore"):
                pt = np.where(den_pt != 0, num_pt / np.where(den_pt != 0, den_pt, 1.0), np.nan)
                dr = np.where(den_b != 0, num_b / np.where(den_b != 0, den_b, 1.0), np.nan)
            for j, k in enumerate(keys):
                d = np.ascontiguousarray(dr[:, j * nc:(j + 1) * nc])
                out.setdefault(k, {})[b] = (pt[j * nc:(j + 1) * nc], d, np.isnan(d).any(axis=0))
        return out

    def get(self, keys, ratio: bool = False, cache: bool = True) -> dict:
        """{key: {stream: (points (cells,), draws (B, cells))}}; ratio=True for (num, den) keys."""
        keys = [keys] if isinstance(keys, str) else list(keys)
        need = [k for k in keys if (k, ratio) not in self._cache]
        got = self._blocks(need, ratio) if need else {}
        if cache:
            for k, v in got.items():
                self._cache[(k, ratio)] = v
        return {k: (self._cache[(k, ratio)] if (k, ratio) in self._cache else got[k]) for k in keys}

    def part_sums(self, key: str, nparts: int) -> dict:
        """{stream: (point sums (nparts, cells), draw sums (B, nparts, cells))} of key#0..key#n-1,
        pooled over the orders of the stream (NaN counts as 0)."""
        nc = len(self.data.cells)
        out = {}
        for b in self.streams:
            pt = np.zeros((nparts, nc))
            dr = np.zeros((self.B, nparts, nc))
            for s in self.data.strata:
                if s[0] != b:
                    continue
                cnt = self.boot.counts[s]
                for q in range(nparts):
                    m = self.data.mats[s].get(f"{key}#{q}")
                    if m is None:
                        continue
                    X = np.nan_to_num(m.astype(np.float64))
                    pt[q] += X.sum(axis=0)
                    dr[:, q] += cnt @ X
            out[b] = (pt, dr)
        return out

    def derived(self, fn, sums: dict) -> dict:
        """An estimate dict {stream: (points, draws, nan mask)} of fn(parts) for every cell, where
        fn maps summed parts (..., nparts, cells) to values (..., cells)."""
        out = {}
        for b, (pt, dr) in sums.items():
            with np.errstate(invalid="ignore", divide="ignore"):
                p, d = fn(pt), fn(dr)
            d = np.ascontiguousarray(d)
            out[b] = (p, d, np.isnan(d).any(axis=0))
        return out

    def forget(self, prefix: str) -> None:
        """Drop cached estimates whose key starts with prefix (keeps memory flat in loops)."""
        for k in [k for k in self._cache if k[0].startswith(prefix)]:
            del self._cache[k]

    def add_keys(self) -> None:
        self._keys = self.data.keys()

    def one(self, key: str, ratio: bool = False, cache: bool = True) -> dict:
        return self.get([key], ratio, cache)[key]

    def at(self, est: dict, cell: tuple, level: str) -> tuple:
        """(point, draws) of one cell at one level: a stream, or 'all' = mean over the streams."""
        j = self.ci.get(cell)
        if j is None:
            return NAN, np.full(self.B, np.nan)
        if level != "all":
            p, d = est[level][:2]
            return float(p[j]), d[:, j]
        pts, drs = [], []
        for b in self.streams:
            p, d = est[b][:2]
            if np.isfinite(p[j]):
                pts.append(float(p[j]))
                drs.append(d[:, j])
        if not pts:
            return NAN, np.full(self.B, np.nan)
        return float(np.mean(pts)), np.mean(np.vstack(drs), axis=0)

    def combo(self, ests: list, items: list) -> tuple:
        """Plain mean over (cell, level) items of est[0] (or of est[0] - est[1], paired by the shared
        resampled tasks), over the items where every estimate exists (Part 2.12: equal weight per
        swap and stream). A repeated item counts as often as it is listed."""
        nan_out = (NAN, np.full(self.B, np.nan))
        if any(b == "all" for _, b in items):           # pair-level items: slow, general path
            pts, drs = [], []
            for cell, b in items:
                got = [self.at(e, cell, b) for e in ests]
                if all(np.isfinite(g[0]) for g in got):
                    pts.append(got[0][0] - (got[1][0] if len(got) > 1 else 0.0))
                    drs.append(got[0][1] - (got[1][1] if len(got) > 1 else 0.0))
            return (float(np.mean(pts)), np.mean(np.vstack(drs), axis=0)) if pts else nan_out
        by_stream: dict = defaultdict(list)
        for cell, b in items:
            if cell in self.ci:
                by_stream[b].append(self.ci[cell])
        tot_p, tot_d, n = 0.0, np.zeros(self.B), 0
        nc = len(self.data.cells)
        for b, cols in by_stream.items():
            cols = np.asarray(cols, dtype=int)
            pts = [e[b][0][cols] for e in ests]
            ok = np.logical_and.reduce([np.isfinite(p) for p in pts])
            if not ok.any():
                continue
            w = np.bincount(cols[ok], minlength=nc).astype(np.float64)   # multiplicity of each cell
            used = w > 0
            for sign, e, p in zip((1.0, -1.0), ests, pts):
                D, nanc = e[b][1], e[b][2]
                tot_p += sign * float(p[ok].sum())
                if nanc.any():               # never let a NaN of an unused cell spoil the sum
                    # (fault 9: the NaN-zeroed draws and the NaN rows of the NaN columns are made once per
                    # estimate, not copied per call; a draw is NaN when a USED cell is NaN in it, as before)
                    D0, nidx, Mn = self._zeroed(D, nanc)
                    part = D0 @ w
                    hit = used[nidx]
                    if hit.any():
                        part[Mn[:, hit].any(axis=1)] = np.nan
                    tot_d += sign * part
                else:
                    tot_d += sign * (D @ w)
            n += int(ok.sum())
        return (tot_p / n, tot_d / n) if n else nan_out

    def _zeroed(self, D: np.ndarray, nanc: np.ndarray) -> tuple:
        """(D with NaN set to 0, indices of the NaN columns, NaN mask of those columns), kept for the last
        few draw matrices (checked by identity, so a reused id never returns another matrix's copy)."""
        z = getattr(self, "_zcache", None)
        if z is None:
            z = self._zcache = {}
        hit = z.get(id(D))
        if hit is not None and hit[0] is D:
            return hit[1]
        nidx = np.flatnonzero(nanc)
        val = (np.where(np.isnan(D), 0.0, D), nidx, np.isnan(D[:, nidx]))
        if len(z) >= 32:
            z.pop(next(iter(z)))
        z[id(D)] = (D, val)
        return val

    def avg(self, est: dict, items: list) -> tuple:
        return self.combo([est], items)

    def pooled_ratio_point(self, key: str, items: list) -> float:
        """Sum of numerators / sum of weights over (cell, stream) items and their tasks: the
        pair-count-weighted pooling of 2.12 (secondary; point value only)."""
        nsum = wsum = 0.0
        for cell, b in items:
            j = self.ci.get(cell)
            if j is None:
                continue
            for s in self.data.strata:
                if s[0] != b:
                    continue
                mn, md = self.data.mats[s].get(key + "#num"), self.data.mats[s].get(key + "#den")
                if mn is None or md is None:
                    continue
                nsum += float(np.nansum(mn[:, j].astype(float)))
                wsum += float(np.nansum(md[:, j].astype(float)))
        return nsum / wsum if wsum else NAN

    def items(self, cells: list, level: str) -> list:
        bs = self.streams if level == "all" else [level]
        return [(c, b) for c in cells for b in bs]


# ===========================================================================
# Loading a study
# ===========================================================================


def resolve_study(study: str, runs_dir=None):
    from msr import llm as L
    from msr.study import load_study
    p = Path(study)
    if p.suffix in (".yaml", ".yml") and p.exists():
        return load_study(p)
    runs = Path(runs_dir) if runs_dir else Path(L.RUNS)
    for cand in (runs / study / "study.yaml", ROOT / "config" / f"{study}.yaml"):
        if cand.exists():
            st = load_study(cand)
            if st.name == study:
                return st
    raise FileNotFoundError(f"no study named {study!r} (looked in {runs / study} and config/)")


#: callers whose design is the CORE grid only (ruling of 24 Nov 2026, open point 29): the forecast's tests
#: (F1, and P1 through them) are computed on the models with every ordered pair; msr.forecast builds its design
#: with design_from_study, so the restriction is applied here and msr.forecast needs no change
CORE_GRID_CALLERS = ("msr.forecast",)


def core_design(design: Design) -> Design:
    """The same design restricted to the core grid (core_models): its models, their pairs and upgrades."""
    from dataclasses import replace
    core = core_models(design)
    keep = set(core)
    return replace(design, models=core, family={m: design.family[m] for m in core},
                   upgrades=[u for u in design.upgrades if u[0] in keep and u[1] in keep],
                   pairs=[p for p in design.pairs if p[0] in keep and p[1] in keep])


def design_from_study(st, grid: str | None = None) -> Design:
    """The analysis design of a study. grid='core' restricts it to the core grid; by default the core grid is
    used when the caller is msr.forecast (CORE_GRID_CALLERS), the whole design otherwise."""
    if grid is None:
        caller = sys._getframe(1).f_globals.get("__name__", "")
        grid = "core" if caller in CORE_GRID_CALLERS else "all"
    d = _design_from_study(st)
    return core_design(d) if grid == "core" else d


def _design_from_study(st) -> Design:
    ev = (st.raw.get("evaluate") or {}) if isinstance(st.raw, dict) else {}
    fams = list(st.scores.families)
    headline = ev.get("headline_family") or ("ema_grade" if "ema_grade" in fams else st.build.drive)
    prices = {m: (num(st.models_cfg["models"].get(m, {}).get("price_in")),
                  num(st.models_cfg["models"].get(m, {}).get("price_out"))) for m in st.models}
    on = st.online
    return Design(
        name=st.name, models=list(st.models), family={m: st.family(m) for m in st.models},
        upgrades=[tuple(p) for p in st.upgrade_pairs], streams=list(st.streams), seeds=list(st.seeds),
        score_families=fams, headline=headline, pairs=[tuple(p) for p in st.pairs if p[0] != p[1]],
        k_values=list(st.evaluate.k_values), fixed_lambdas=list(st.evaluate.fixed_lambdas),
        all_sim=bool(st.all_sim), alpha=float(ev.get("alpha", 0.05)),
        ni_fraction=float(ev.get("ni_fraction", 0.25)), min_difference=float(ev.get("min_difference", 0.05)),
        ratio_min_z=float(ev.get("ratio_min_z", 4.0)), first_n=int(getattr(on, "first_n", 100) or 100),
        window=int(getattr(on, "window", 50) or 50), target_share=float(getattr(on, "target_share", 0.95) or 0.95),
        w_score=float(st.build.w_score), prices=prices, kind=study_kind(st), **swap_day_sizes(st))


def swap_day_sizes(st) -> dict:
    """Calls of one swap day from the study sizes (the same formulas as msr.construct.cost_rules):
    own_build_calls = n_write + (n_score if the no-memory run) + epochs x n_score (x (1 + n_show) with
    self tags); level_calls = calibration tasks x no-memory repeats; owner_pool_calls = calibration
    tasks x candidates x 2 home repeats. NaN where the study object lacks a field."""
    try:
        b = st.build
        n_score = int(st.n_score)
        own = int(b.n_write) + (n_score if bool(b.no_memory_run) else 0) + int(b.epochs) * n_score \
            + (int(b.epochs) * n_score * int(b.n_show) if bool(b.self_tag) else 0)
        calib = int(st.evaluate.calib_tasks)
        return {"own_build_calls": float(own), "level_calls": float(calib * int(st.probe.no_memory_repeats)),
                "owner_pool_calls": float(calib * int(st.probe.candidates) * 2)}
    except (AttributeError, TypeError, ValueError):
        return {}


def study_kind(st) -> str:
    """simulated (any simulated model), preliminary (any model through the opencode_cli wrapper)
    or real. It decides the macro prefix and the banner of every table."""
    provs = [str(st.models_cfg["models"].get(m, {}).get("provider", "")) for m in st.models]
    if any(p == "sim" for p in provs):
        return "simulated"
    if any(p == "opencode_cli" for p in provs):
        return "preliminary"
    return "real"


KIND_LABEL = {"simulated": ("Sim", "SIMULATED DATA"),
              "preliminary": ("Pre", "PRELIMINARY: free models through a wrapper"),
              "real": ("", "")}


def online_constant_warnings(design: Design) -> list:
    """Part 2.10 fixes a trailing window of 50 tasks and 'the first 100 test tasks'. The study
    file sets them; a non-simulated study with other values gets a loud warning."""
    if design.kind == "simulated":
        return []
    out = []
    if design.window != 50:
        out.append(f"online.window is {design.window}, the pre-registration says 50 (tau95, Part 2.10)")
    if design.first_n != 100:
        out.append(f"online.first_n is {design.first_n}, the pre-registration says 100 (S_100, Part 2.10)")
    return out


def _keep_key(key: str, design: Design) -> bool:
    """Per-task keys the analysis reads (the mix-weight variants only for the main arms)."""
    if "|value_w" not in key:
        return True
    arm = key.split("|")[1]
    K = design.primary_k
    main = {"keep", "wipe", f"fixed_{design.primary_lambda:g}", "shuffled", "own", "relevance"}
    if K is not None:
        main |= {f"{a}_{K}" for a in CHECK_ARMS}
    return arm in main


def _read_npz(p: Path, design: Design) -> dict:
    with np.load(p, allow_pickle=False) as z:
        return {k: z[k] for k in z.files if _keep_key(k, design)}


def load_per_task_dir(design: Design, results: Path) -> PerTask:
    # the files are read by threads (decompression releases the interpreter lock); same dict, same order
    from concurrent.futures import ThreadPoolExecutor
    want = [((o, r, b, seed), results / "per_task" / f"{o}__{r}__{b}__seed{seed}.npz")
            for b in design.streams for seed in design.seeds for o, r in design.cells]
    want = [(k, p) for k, p in want if p.exists()]
    with ThreadPoolExecutor(max_workers=n_workers(len(want) or 1)) as ex:
        got = list(ex.map(lambda kp: _read_npz(kp[1], design), want))
    cell_arrays = {k: v for (k, _), v in zip(want, got)}
    if not cell_arrays:
        raise FileNotFoundError(f"no per-task files in {results / 'per_task'}; run the evaluate stage first")
    return per_task_from_cells(design, cell_arrays)


def read_csv(path: Path) -> list:
    if not path.exists():
        return []
    with open(path, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def read_jsonl(path: Path) -> list:
    with open(path, encoding="utf-8") as f:
        return [json.loads(x) for x in f if x.strip()]


# ===========================================================================
# Writing
# ===========================================================================


def _fmt(v):
    if isinstance(v, (bool, np.bool_)):
        return "true" if v else "false"
    if isinstance(v, (float, np.floating)):
        v = float(v)
        if math.isnan(v):
            return ""
        if math.isinf(v):
            return "inf" if v > 0 else "-inf"
        r = round(v, 6)
        return repr(0.0 if r == 0 else r)
    if isinstance(v, (np.integer,)):
        return int(v)
    if v is None:
        return ""
    return v


def write_csv(path: Path, rows: list, cols: list | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if cols is None:
        cols = []
        for r in rows:
            for k in r:
                if k not in cols:
                    cols.append(k)
    tmp = path.with_name(path.name + ".part")
    with open(tmp, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols, lineterminator="\n")
        w.writeheader()
        for r in rows:
            w.writerow({k: _fmt(r.get(k, "")) for k in cols})
    tmp.replace(path)


def _s(prefix: str, sm: dict, keys=("est", "lo", "hi")) -> dict:
    return {f"{prefix}_{k}" if k != "est" else prefix: sm[k] for k in keys}


# ===========================================================================
# Part 2: validity per pair and per swap stratum
# ===========================================================================


def ratio_report(design: Design, h: tuple, sw: tuple) -> dict:
    """R = (C_swap - 0.5) / (C_home - 0.5) with the reporting rule of 2.4."""
    hp, hd = h
    sp, sd = sw
    hdf = hd[np.isfinite(hd)]
    se = float(hdf.std(ddof=1)) if hdf.size > 1 else NAN
    sig = hp - 0.5 if fin(hp) else NAN
    z = sig / se if fin(sig) and fin(se) and se > 0 else (math.inf if fin(sig) and sig > 0 and se == 0 else NAN)
    defined = bool(fin(sig) and fin(se) and sig >= design.ratio_min_z * se and sig > 0)
    share_bad = float(np.mean(hdf - 0.5 <= 0)) if hdf.size else NAN
    out = {"home_signal": sig, "home_se": se, "home_z": z, "ratio_rule_min_z": design.ratio_min_z,
           "denominator_le0_share": share_bad}
    if not defined:
        out.update(R=NAN, R_lo=NAN, R_hi=NAN, R_status="undefined: home signal too weak", R_interval="")
        return out
    R = (sp - 0.5) / sig if fin(sp) else NAN
    with np.errstate(invalid="ignore", divide="ignore"):
        rd = (sd - 0.5) / (hd - 0.5)
    rd = rd[np.isfinite(rd)]
    if share_bad > design.unbounded_share or rd.size == 0:
        out.update(R=R, R_lo=-math.inf, R_hi=math.inf, R_status="reported", R_interval="unbounded")
    else:
        lo, hi = np.percentile(rd, [2.5, 97.5])
        out.update(R=R, R_lo=float(lo), R_hi=float(hi), R_status="reported", R_interval="percentile")
    return out


def pc1_category(design: Design, d_est: float, p_drop: float, p_ni: float, u_self: float, thr_drop, thr_ni) -> str:
    """Decision categories of PC1 (Part 3)."""
    drop = thr_drop is not None and fin(p_drop) and p_drop <= thr_drop and fin(d_est) and fin(u_self) and d_est > u_self
    ni = thr_ni is not None and fin(p_ni) and p_ni <= thr_ni
    parts = []
    if drop:
        parts.append("material drop" if d_est >= design.min_difference else "small drop")
    if ni:
        parts.append("no material drop")
    if not parts:
        if thr_drop is not None and fin(p_drop) and p_drop <= thr_drop:
            return "inconclusive (drop test rejects but the drop is within the self-swap reference)"
        return "inconclusive"
    return " + ".join(parts)


def validity_block(E: Engine, design: Design, fam: str, h_cell, swap_cells: list, level: str, owners_of) -> dict:
    """C_home, C_swap, C_fresh averages over the given swap cells at one level."""
    Ch = E.one(f"{fam}|conc_home", ratio=True)
    Cs = E.one(f"{fam}|conc_swap", ratio=True)
    Cf = E.one(f"{fam}|conc_floor", ratio=True)
    home_items = [((owners_of(c), owners_of(c)), b) for c, b in E.items(swap_cells, level)]
    swap_items = E.items(swap_cells, level)
    h = E.avg(Ch, home_items)
    f = E.avg(Cf, home_items)
    s = E.avg(Cf, home_items) if h_cell else E.avg(Cs, swap_items)
    return {"h": h, "s": s, "f": f}


def validity_stats(design: Design, blk: dict) -> tuple:
    """Every PC1 quantity from the (point, draws) of C_home, C_swap and C_fresh."""
    (hp, hd), (sp, sd), (fp, fd) = blk["h"], blk["s"], blk["f"]
    D = (hp - sp, hd - sd)
    Dself = (hp - fp, hd - fd)
    keep = 1.0 - design.ni_fraction
    N = (keep * (hp - 0.5) - (sp - 0.5), keep * (hd - 0.5) - (sd - 0.5))
    contrast = (fp - sp, fd - sd)                         # C_fresh - C_swap (4.4, secondary)
    sm = {"C_home": summarize(hp, hd), "C_swap": summarize(sp, sd), "C_fresh": summarize(fp, fd),
          "D": summarize(*D), "Dself": summarize(*Dself), "contrast": summarize(*contrast)}
    nd = N[1][np.isfinite(N[1])]
    n_lo, n_hi = (np.percentile(nd, [5, 95]) if nd.size else (NAN, NAN))
    sm["N"] = {"est": N[0], "lo90": float(n_lo), "hi90": float(n_hi), "p_lower": pvals(N[1])[1]}
    rr = ratio_report(design, blk["h"], blk["s"])
    return sm, rr, D, N


def pair_validity(E: Engine, design: Design, fam: str) -> tuple:
    """validity_pairs rows for one family: every ordered pair (homes included) at every level."""
    rows = []
    for cell in design.swaps("home") + design.swaps("all_swaps"):
        s, t = cell
        for level in E.levels:
            blk = validity_block(E, design, fam, s == t, [cell], level, lambda c: c[0])
            sm, rr, D, N = validity_stats(design, blk)
            if not fin(sm["C_home"]["est"]) and not fin(sm["C_swap"]["est"]):
                continue
            # owner's self-swap noise floor at the same level (4.4): upper end of the 95 % interval
            fl = validity_block(E, design, fam, True, [(s, s)], level, lambda c: c[0])
            u_self = summarize(fl["h"][0] - fl["f"][0], fl["h"][1] - fl["f"][1])["hi"]
            p_drop = sm["D"]["p_upper"]
            p_ni = sm["N"]["p_lower"] if rr["R_status"] == "reported" else NAN
            row = {"family": fam, "owner": s, "reader": t, "group": design.group(s, t), "level": level,
                   "C_home": sm["C_home"]["est"], "C_home_lo": sm["C_home"]["lo"], "C_home_hi": sm["C_home"]["hi"],
                   "C_home_se": sm["C_home"]["se"],
                   "C_swap": sm["C_swap"]["est"], "C_swap_lo": sm["C_swap"]["lo"], "C_swap_hi": sm["C_swap"]["hi"],
                   "C_fresh": sm["C_fresh"]["est"], "C_fresh_lo": sm["C_fresh"]["lo"], "C_fresh_hi": sm["C_fresh"]["hi"],
                   "D": sm["D"]["est"], "D_lo": sm["D"]["lo"], "D_hi": sm["D"]["hi"], "D_p_upper": p_drop,
                   "Dself_owner": sm["Dself"]["est"], "Dself_owner_lo": sm["Dself"]["lo"],
                   "U_self": u_self, "D_beyond_floor": bool(fin(sm["D"]["est"]) and fin(u_self) and sm["D"]["est"] > u_self),
                   "N": sm["N"]["est"], "N_lo90": sm["N"]["lo90"], "N_hi90": sm["N"]["hi90"], "N_p_lower": p_ni,
                   **rr,
                   "fresh_minus_swap": sm["contrast"]["est"], "fresh_minus_swap_lo": sm["contrast"]["lo"],
                   "fresh_minus_swap_hi": sm["contrast"]["hi"]}
            for tag, key in (("shuffled", "conc_swap_shuffled"), ("u", "conc_swap_u")):
                if E.has(f"{fam}|{key}"):
                    sh = summarize(*E.at(E.one(f"{fam}|{key}", ratio=True), cell, level))
                    row.update({f"C_swap_{tag}": sh["est"], f"C_swap_{tag}_lo": sh["lo"], f"C_swap_{tag}_hi": sh["hi"]})
            sh = getattr(E, "sh", None)
            if sh is not None:
                row.update(radj_report(design, rr["R_status"], [
                    {"h": blk["h"], "sw": blk["s"], "ro": E.at(sh, (s, s), level), "rr": E.at(sh, (t, t), level)}]))
            thr = design.alpha
            row["category_unadjusted"] = pc1_category(design, row["D"], p_drop, p_ni, u_self, thr, thr) \
                if s != t else "self-swap reference"
            rows.append(row)
    # Holm across the swaps (5.2, secondary flag), level "all", corrected in the round-1 revision:
    # the drop test and the no-material-drop test of every swap are two separate members (Holm over
    # 2 x the number of swaps). The former device, min(1, 2 x min(p_drop, p_NI)) per swap with both
    # claims allowed, does not hold the familywise error (docs/power/fwer_holm_output.md).
    sw = [r for r in rows if r["level"] == "all" and r["owner"] != r["reader"]]
    n_sw = len(sw)
    ps = [r["D_p_upper"] for r in sw] + [r["N_p_lower"] for r in sw]
    hs = holm_steps(ps, design.alpha)
    for j, r in enumerate(sw):
        r["holm_members"] = 2 * n_sw
        r["holm_p_drop"], r["holm_p_ni"] = hs["adjusted"][j], hs["adjusted"][n_sw + j]
        r["holm_category"] = pc1_category(design, r["D"], r["D_p_upper"], r["N_p_lower"], r["U_self"],
                                          hs["threshold"][j], hs["threshold"][n_sw + j])
    return rows


def group_validity(E: Engine, design: Design, fam: str) -> list:
    rows = []
    for g in DESC_GROUPS:
        cells = design.swaps(g)
        if not cells:
            continue
        for level in E.levels:
            blk = validity_block(E, design, fam, g == "home", cells, level, lambda c: c[0])
            sm, rr, D, N = validity_stats(design, blk)
            its = E.items(cells, level)
            pw_h = E.pooled_ratio_point(f"{fam}|conc_home", [((c[0], c[0]), b) for c, b in its])
            pw_s = E.pooled_ratio_point(f"{fam}|conc_floor" if g == "home" else f"{fam}|conc_swap",
                                        [((c[0], c[0]) if g == "home" else c, b) for c, b in its])
            rows.append({"family": fam, "group": g, "level": level, "n_swaps": len(cells),
                         "C_home_pairweighted": pw_h, "C_swap_pairweighted": pw_s, "D_pairweighted": pw_h - pw_s,
                         "C_home": sm["C_home"]["est"], "C_home_lo": sm["C_home"]["lo"], "C_home_hi": sm["C_home"]["hi"],
                         "C_swap": sm["C_swap"]["est"], "C_swap_lo": sm["C_swap"]["lo"], "C_swap_hi": sm["C_swap"]["hi"],
                         "D": sm["D"]["est"], "D_lo": sm["D"]["lo"], "D_hi": sm["D"]["hi"], "D_p_upper": sm["D"]["p_upper"],
                         "Dself": sm["Dself"]["est"], "Dself_lo": sm["Dself"]["lo"], "U_self": sm["Dself"]["hi"],
                         "N": sm["N"]["est"], "N_lo90": sm["N"]["lo90"], "N_hi90": sm["N"]["hi90"],
                         "N_p_lower": sm["N"]["p_lower"] if rr["R_status"] == "reported" else NAN,
                         **{k: rr[k] for k in ("R", "R_lo", "R_hi", "R_status", "R_interval", "home_z")},
                         "fresh_minus_swap": sm["contrast"]["est"], "fresh_minus_swap_lo": sm["contrast"]["lo"],
                         "fresh_minus_swap_hi": sm["contrast"]["hi"]})
            row = rows[-1]
            sh = getattr(E, "sh", None)
            if sh is not None:
                Ch_, Cs_, Cf_ = (E.one(f"{fam}|conc_{q}", ratio=True) for q in ("home", "swap", "floor"))
                ritems = [{"h": E.at(Ch_, (c[0], c[0]), b), "sw": E.at(Cf_ if g == "home" else Cs_, c, b),
                           "ro": E.at(sh, (c[0], c[0]), b), "rr": E.at(sh, (c[1], c[1]), b)} for c, b in its]
                ritems = [x for x in ritems if fin(x["h"][0]) and fin(x["sw"][0])]
                row.update(radj_report(design, rr["R_status"], ritems))
            home_items = [((c[0], c[0]), b) for c, b in its]
            for tag, hk, sk in (("shuffled", "conc_home_shuffled", "conc_swap_shuffled"),
                                ("u", "conc_home_u", "conc_swap_u")):
                if E.has(f"{fam}|{hk}") and E.has(f"{fam}|{sk}"):
                    hh = E.avg(E.one(f"{fam}|{hk}", ratio=True), home_items)
                    ss = E.avg(E.one(f"{fam}|{sk}", ratio=True), its)
                    a, b_, dd = summarize(*hh), summarize(*ss), summarize(hh[0] - ss[0], hh[1] - ss[1])
                    row.update({f"C_home_{tag}": a["est"], f"C_home_{tag}_lo": a["lo"], f"C_home_{tag}_hi": a["hi"],
                                f"C_swap_{tag}": b_["est"], f"C_swap_{tag}_lo": b_["lo"], f"C_swap_{tag}_hi": b_["hi"],
                                f"D_{tag}": dd["est"], f"D_{tag}_lo": dd["lo"], f"D_{tag}_hi": dd["hi"]})
    return rows


def group_R_draws(E: Engine, design: Design, fam: str, cells: list, level: str = "all") -> tuple:
    blk = validity_block(E, design, fam, False, cells, level, lambda c: c[0])
    (hp, hd), (sp, sd) = blk["h"], blk["s"]
    with np.errstate(invalid="ignore", divide="ignore"):
        return (sp - 0.5) / (hp - 0.5), (sd - 0.5) / (hd - 0.5), ratio_report(design, blk["h"], blk["s"])


# ===========================================================================
# Arms: per-pair contrasts and the primary comparisons PC2-PC4
# ===========================================================================


def arms_of(E: Engine, fam: str) -> list:
    arms = set()
    for k in E._keys:
        parts = k.split("|")
        if len(parts) == 3 and parts[0] == fam:
            arms.add(parts[1])
    return sorted(arms, key=arm_sort_key)


def diff_est(E: Engine, a: dict, b: dict, items: list) -> tuple:
    """Mean over (cell, level) items of a - b, paired by the shared resampled tasks."""
    return E.combo([a, b], items)


def contrast_specs(design: Design, fam: str) -> list:
    """(name, metric, arm a, family a, arm b, family b, test sidedness) of the per-pair contrasts."""
    K = design.primary_k
    lam = f"fixed_{design.primary_lambda:g}"
    out = [("PC2 keep - wipe", "value", "keep", fam, "wipe", fam, "two"),
           ("PC3 fixed - keep", "log", lam, fam, "keep", fam, "two"),
           ("PC3 fixed - keep (Brier)", "brier", lam, fam, "keep", fam, "two")]
    if K is not None:
        out += [(f"PC4a recal_{K} - keep", "log", f"recal_{K}", fam, "keep", fam, "upper"),
                (f"PC4b recal_{K} - wipe", "log", f"recal_{K}", fam, "wipe", fam, "upper")]
    out += [("keep - own", "value", "keep", fam, "own", fam, "two"),
            ("ceiling - keep", "value", "ceiling", NO_FAMILY, "keep", fam, "two"),
            ("keep - split_half", "value", "keep", fam, "split_half", NO_FAMILY, "two"),
            ("keep - shuffled", "value", "keep", fam, "shuffled", fam, "two"),
            (f"{lam} - keep (FS)", "value", lam, fam, "keep", fam, "two")]
    if K is not None:
        out += [(f"recal_{K} - keep (FS)", "value", f"recal_{K}", fam, "keep", fam, "two"),
                (f"recal_{K} - wipe (FS)", "value", f"recal_{K}", fam, "wipe", fam, "two")]
    return out


def pair_contrasts(E: Engine, design: Design, fam: str) -> list:
    rows = []
    for name, metric, a, fa, b, fb, side in contrast_specs(design, fam):
        ka, kb = f"{fa}|{a}|{metric}", f"{fb}|{b}|{metric}"
        if not (E.has(ka) and E.has(kb)):
            continue
        A, Bm = E.one(ka), E.one(kb)
        rs, pts, drs = [], [], []
        for cell in design.swaps("all_swaps") + design.swaps("home"):
            for level in E.levels:
                p, dr = diff_est(E, A, Bm, [(cell, level)])
                if not fin(p):
                    continue
                rs.append({"family": fam, "contrast": name, "metric": metric, "arm_a": a, "arm_b": b,
                           "owner": cell[0], "reader": cell[1], "group": design.group(*cell), "level": level})
                pts.append(p)
                drs.append(dr)
        for r, sm in zip(rs, summarize_many(pts, np.column_stack(drs)) if rs else []):
            r.update(est=sm["est"], lo=sm["lo"], hi=sm["hi"],
                     p=sm["p_upper"] if side == "upper" else sm["p_two"], p_sided=side)
        sw = [r for r in rs if r["level"] == "all" and r["owner"] != r["reader"]]
        hs = holm_steps([r["p"] for r in sw], design.alpha)
        for r, adj, rej in zip(sw, hs["adjusted"], hs["reject"]):
            r["holm56_p"], r["holm56_reject"] = adj, rej
        rows += rs
    return rows


def all_swaps_descriptive(E: Engine, design: Design) -> list:
    """PC1-PC4 statistics averaged over every swap (8.2.2, descriptive, no test)."""
    H, K, lam = design.headline, design.primary_k, f"fixed_{design.primary_lambda:g}"
    cells = design.swaps("all_swaps")
    items = E.items(cells, "all")
    out = []
    blk = validity_block(E, design, H, False, cells, "all", lambda c: c[0])
    sm, rr, _, _ = validity_stats(design, blk)
    out.append({"comparison": "PC1", "statistic": "D", **{k: sm["D"][k] for k in ("est", "lo", "hi")},
                "R": rr["R"], "R_status": rr["R_status"]})
    specs = [("PC2", "value", "keep", "wipe"), ("PC3", "log", lam, "keep")]
    if K is not None:
        specs += [("PC4a", "log", f"recal_{K}", "keep"), ("PC4b", "log", f"recal_{K}", "wipe")]
    for c, m, a, b in specs:
        if E.has(f"{H}|{a}|{m}") and E.has(f"{H}|{b}|{m}"):
            s2 = summarize(*diff_est(E, E.one(f"{H}|{a}|{m}"), E.one(f"{H}|{b}|{m}"), items))
            out.append({"comparison": c, "statistic": f"{a} - {b} ({m})", **{k: s2[k] for k in ("est", "lo", "hi")}})
    return out


# ===========================================================================
# Heterogeneity (Part 5.2): range, opposite signs, source-plus-target model
# ===========================================================================


def comparison_pair_values(E: Engine, design: Design, fam: str) -> dict:
    """{comparison: {cell: (point, draws)}} at level 'all' for every swap (PC1-PC4 statistics)."""
    K, lam = design.primary_k, f"fixed_{design.primary_lambda:g}"
    out: dict = {}
    Ch, Cs = E.one(f"{fam}|conc_home", ratio=True), E.one(f"{fam}|conc_swap", ratio=True)
    out["PC1 D"] = {}
    for c in design.swaps("all_swaps"):
        h = E.at(Ch, (c[0], c[0]), "all")
        s = E.at(Cs, c, "all")
        out["PC1 D"][c] = (h[0] - s[0], h[1] - s[1])
    specs = [("PC2 keep - wipe", "value", "keep", "wipe"), ("PC3 fixed - keep", "log", lam, "keep")]
    if K is not None:
        specs += [(f"PC4a recal_{K} - keep", "log", f"recal_{K}", "keep"),
                  (f"PC4b recal_{K} - wipe", "log", f"recal_{K}", "wipe")]
    for name, m, a, b in specs:
        if not (E.has(f"{fam}|{a}|{m}") and E.has(f"{fam}|{b}|{m}")):
            continue
        A, Bm = E.one(f"{fam}|{a}|{m}"), E.one(f"{fam}|{b}|{m}")
        out[name] = {c: diff_est(E, A, Bm, [(c, "all")]) for c in design.swaps("all_swaps")}
    return out


def source_target_fit(design: Design, cells: list, y: np.ndarray, Y: np.ndarray, se2: np.ndarray) -> dict:
    """Least-squares fit y_pair = mu + stratum + u(source) + v(target) + w(pair) over the swaps.
    u, v in sum-to-zero coding. Returns the variance pieces for the point data and for every draw."""
    models = design.models
    mi = {m: j for j, m in enumerate(models)}
    M = len(models)
    kinds = [k for k in ("downgrade", "same_other", "cross") if any(design.group(*c) == k for c in cells)]
    cols = 1 + len(kinds) + 2 * (M - 1)
    X = np.zeros((len(cells), cols))
    for r, (s, t) in enumerate(cells):
        X[r, 0] = 1.0
        g = design.group(s, t)
        if g in kinds:
            X[r, 1 + kinds.index(g)] = 1.0
        base = 1 + len(kinds)
        for off, m in ((base, s), (base + M - 1, t)):
            j = mi[m]
            if j < M - 1:
                X[r, off + j] = 1.0
            else:
                X[r, off:off + M - 1] = -1.0
    rank = int(np.linalg.matrix_rank(X))
    df = len(cells) - rank
    P = np.linalg.pinv(X)

    base = 1 + len(kinds)

    def effects(theta):
        """Source and target effects (sum-to-zero), for one theta (cols,) or many (B, cols)."""
        th = np.atleast_2d(theta)
        u = th[:, base:base + M - 1]
        v = th[:, base + M - 1:base + 2 * (M - 1)]
        u = np.concatenate([u, -u.sum(axis=1, keepdims=True)], axis=1)
        v = np.concatenate([v, -v.sum(axis=1, keepdims=True)], axis=1)
        return u, v

    def pieces(Yv, TH):
        """Variance pieces for every row of Yv (n, pairs) with its fitted TH (n, cols)."""
        u, v = effects(TH)
        resid = Yv - TH @ X.T
        if df > 0:
            tau2 = np.maximum(0.0, (resid ** 2).sum(axis=1) / df - float(np.mean(se2)))
        else:
            tau2 = np.full(Yv.shape[0], np.nan)
        su2, sv2 = u.var(axis=1, ddof=1), v.var(axis=1, ddof=1)
        return su2, sv2, tau2, u, v, resid

    th = P @ y
    su2, sv2, tau2, u, v, resid = pieces(y[None, :], th[None, :])
    su2, sv2, tau2, u, v, resid = float(su2[0]), float(sv2[0]), float(tau2[0]), u[0], v[0], resid[0]
    sd_between = math.sqrt(su2 + sv2 + (tau2 if fin(tau2) else 0.0))
    shrink = (tau2 / (tau2 + se2)) if fin(tau2) and tau2 > 0 else np.zeros_like(se2)
    pred = np.array([u[mi[s]] + v[mi[t]] for s, t in cells]) + shrink * resid
    ok = np.isfinite(Y).all(axis=1)
    if ok.any():
        Yo = Y[ok]
        a, c, t2, *_ = pieces(Yo, Yo @ P.T)
        boot_sd = np.sqrt(a + c + np.where(np.isfinite(t2), t2, 0.0))
        lo, hi = np.percentile(boot_sd, [2.5, 97.5])
    else:
        lo = hi = NAN
    return {"sd_source": math.sqrt(su2), "sd_target": math.sqrt(sv2),
            "sd_pair": math.sqrt(tau2) if fin(tau2) else NAN, "sd_between": sd_between,
            "sd_between_lo": float(lo), "sd_between_hi": float(hi), "rank": rank, "df_resid": df,
            "pred": pred, "u": u, "v": v}


def heterogeneity(E: Engine, design: Design, fam: str, pv: dict) -> tuple:
    rows, model_rows = [], []
    for comp, vals in pv.items():
        cells = [c for c in design.swaps("all_swaps") if c in vals and fin(vals[c][0])]
        if len(cells) < 3:
            continue
        y = np.array([vals[c][0] for c in cells])
        Y = np.vstack([vals[c][1] for c in cells]).T
        se2 = np.nanvar(Y, axis=0, ddof=1)
        fit = source_target_fit(design, cells, y, Y, se2)
        for g in GROUPS + ("all_swaps",):
            gi = [j for j, c in enumerate(cells) if design.in_group(*c, g)]
            if not gi:
                continue
            gy = y[gi]
            gm = float(np.mean(gy))
            opp = float(np.mean(np.sign(gy) == -np.sign(gm))) if gm != 0 else NAN
            jmin, jmax = gi[int(np.argmin(gy))], gi[int(np.argmax(gy))]
            pred_sd = float(np.std(fit["pred"][gi], ddof=1)) if len(gi) > 1 else NAN
            rows.append({"family": fam, "comparison": comp, "group": g, "n_swaps": len(gi), "group_mean": gm,
                         "min": float(np.min(gy)), "min_pair": f"{cells[jmin][0]} -> {cells[jmin][1]}",
                         "max": float(np.max(gy)), "max_pair": f"{cells[jmax][0]} -> {cells[jmax][1]}",
                         "opposite_sign_share": opp, "pred_effect_sd_in_group": pred_sd,
                         "sd_between": fit["sd_between"], "sd_between_lo": fit["sd_between_lo"],
                         "sd_between_hi": fit["sd_between_hi"], "sd_source": fit["sd_source"],
                         "sd_target": fit["sd_target"], "sd_pair": fit["sd_pair"],
                         "model_rank": fit["rank"], "model_df_resid": fit["df_resid"]})
        for j, m in enumerate(design.models):
            model_rows.append({"family": fam, "comparison": comp, "model": m, "source_effect": fit["u"][j],
                               "target_effect": fit["v"][j]})
    return rows, model_rows


# ===========================================================================
# All arms by group, k-curves, equal-budget comparisons
# ===========================================================================


def arms_jobs(E: Engine, design: Design, size: int = 12) -> list:
    """The (family, arms) pieces of arms_tables in its row order, about `size` arms each (for processes)."""
    jobs = []
    for fam in [NO_FAMILY] + list(design.score_families):
        arms = arms_of(E, fam)
        jobs += [(fam, tuple(arms[i:i + size])) for i in range(0, len(arms), size)]
    return jobs


def arms_tables(E: Engine, design: Design, pair_rows_for: set) -> tuple:
    """arms_groups rows (every family, arm, metric, group, level) and arms_pairs rows (per pair)."""
    grp_rows, pair_rows = [], []
    for fam, arms in arms_jobs(E, design):
        g, p = arms_tables_part(E, design, fam, arms, pair_rows_for)
        grp_rows += g
        pair_rows += p
    return grp_rows, pair_rows


def arms_tables_part(E: Engine, design: Design, fam: str, arms, pair_rows_for: set) -> tuple:
    """arms_tables for some arms of one family (the same rows, in the same order)."""
    grp_rows, pair_rows = [], []
    for fam in (fam,):
        refs = {}
        rfam = design.headline if fam == NO_FAMILY else fam   # none / relevance / references vs the headline's keep
        for m in METRICS:
            for ref, rf in (("keep", rfam), ("wipe", rfam), ("ceiling", NO_FAMILY)):
                k = f"{rf}|{ref}|{m}"
                if E.has(k):
                    refs[(ref, m)] = E.one(k, cache=False)
        for arm in arms:
            keys = [f"{fam}|{arm}|{m}" for m in METRICS if E.has(f"{fam}|{arm}|{m}")]
            ests = E.get(keys, cache=False)
            for key, est in ests.items():
                m = key.split("|")[2]
                pend = Pending()
                base, par = arm_parts(arm)
                for g in DESC_GROUPS:
                    cells = design.swaps(g)
                    if not cells:
                        continue
                    for level in E.levels:
                        items = E.items(cells, level)
                        p, dr = E.avg(est, items)
                        if not fin(p):
                            continue
                        row = {"family": fam, "arm": arm, "arm_base": base,
                               "k": par if base in CHECK_ARMS else "", "lambda": par if base == "fixed" else "",
                               "metric": m, "group": g, "level": level, "n_swaps": len(cells)}
                        pend.add(row, "", p, dr)
                        for ref in ("keep", "wipe", "ceiling"):
                            if (ref, m) in refs and ref != arm:
                                pend.add(row, f"minus_{ref}", *diff_est(E, est, refs[(ref, m)], items), with_p=True)
                        grp_rows.append(row)
                if fam == NO_FAMILY or fam in pair_rows_for:
                    for cell in design.swaps("home") + design.swaps("all_swaps"):
                        for level in E.levels:
                            p, dr = E.at(est, cell, level)
                            if not fin(p):
                                continue
                            row = {"family": fam, "arm": arm, "metric": m, "owner": cell[0], "reader": cell[1],
                                   "group": design.group(*cell), "level": level}
                            pend.add(row, "", p, dr)
                            pair_rows.append(row)
                pend.flush()
    return grp_rows, pair_rows


def equal_budget(E: Engine, design: Design, fam: str) -> list:
    """recal_k against fresh_k, pooled_k, powerprior_k, retest_k and audit_k (8.2.5)."""
    rows = []
    for k in design.k_values:
        ka = f"recal_{k}"
        for rival in EQUAL_BUDGET_RIVALS:
            kb = f"{rival}_{k}"
            for m in ("value", "log"):
                a, b = f"{fam}|{ka}|{m}", f"{fam}|{kb}|{m}"
                if not (E.has(a) and E.has(b)):
                    continue
                A, Bm = E.one(a, cache=False), E.one(b, cache=False)
                for g in GROUPS + ("all_swaps",):
                    cells = design.swaps(g)
                    if not cells:
                        continue
                    sm = summarize(*diff_est(E, A, Bm, E.items(cells, "all")))
                    rows.append({"family": fam, "k": k, "contrast": f"{ka} - {kb}", "metric": m, "group": g,
                                 "est": sm["est"], "lo": sm["lo"], "hi": sm["hi"], "p_two": sm["p_two"]})
    return rows


# ===========================================================================
# Part 7: predictions P1-P4
# ===========================================================================


def all_perms(n: int, cap: int = 50000, seed: int = 0) -> tuple:
    """Every permutation of n model labels when there are at most `cap` of them (8! = 40,320:
    exact, as pre-registered), otherwise the identity plus cap - 1 random ones (seed 0)."""
    if math.factorial(n) <= cap:
        return np.array(list(itertools.permutations(range(n))), dtype=np.int16).reshape(-1, n), True
    rng = np.random.default_rng(seed)
    perms = [np.arange(n)] + [rng.permutation(n) for _ in range(cap - 1)]
    return np.array(perms, dtype=np.int16), False


def agreement_pairs(design: Design, results: Path) -> list:
    """Cohen's kappa owner vs reader on the calibration tasks, pooled over the orders (2.11)."""
    rows = read_csv(results / "agreement.csv")
    exact = bool(rows) and all(c in rows[0] for c in ("same", "pairs", "succ_a", "n_a", "succ_b", "n_b"))
    acc: dict = defaultdict(lambda: [0.0] * 6)
    for r in rows:
        a = acc[(r["owner"], r["reader"], r["stream"])]
        if exact:                         # pool the counts of the orders exactly
            vals = [num(r[c]) for c in ("pairs", "same", "succ_a", "n_a", "succ_b", "n_b")]
            if all(fin(v) for v in vals) and vals[0] > 0:
                for j, v in enumerate(vals):
                    a[j] += v
            continue
        w = num(r.get("cells"))           # older files: weight each order by its cells
        if not fin(w) or w <= 0 or not fin(r.get("agree")):
            continue
        for j, v in enumerate((w, w * num(r["agree"]), w * num(r["rate_a"]), w, w * num(r["rate_b"]), w)):
            a[j] += v
    out = []
    for (o, rd, b), (w, ag, sa, na, sb, nb) in sorted(acc.items()):
        if w <= 0 or na <= 0 or nb <= 0:
            continue
        ag, ra, rb = ag / w, sa / na, sb / nb
        ch = ra * rb + (1 - ra) * (1 - rb)
        out.append({"owner": o, "reader": rd, "group": design.group(o, rd), "level": b, "weight": w,
                    "weight_kind": "repeat comparisons (exact counts)" if exact else "cells (approximate pooling)",
                    "agree": ag, "chance": ch, "kappa": (ag - ch) / (1 - ch) if ch < 1 else NAN})
    by_pair: dict = defaultdict(list)
    for r in out:
        by_pair[(r["owner"], r["reader"])].append(r)
    for (o, rd), rs in by_pair.items():
        out.append({"owner": o, "reader": rd, "group": design.group(o, rd), "level": "all",
                    "weight": sum(r["weight"] for r in rs), "weight_kind": rs[0]["weight_kind"],
                    "agree": float(np.mean([r["agree"] for r in rs])),
                    "chance": float(np.mean([r["chance"] for r in rs])),
                    "kappa": float(np.mean([r["kappa"] for r in rs]))})
    return out


def _perm_p(stat_obs: float, stats: np.ndarray, side: str) -> tuple:
    s = stats[np.isfinite(stats)]
    if not fin(stat_obs) or s.size == 0:
        return NAN, NAN
    eps = 1e-12
    hi = float(np.mean(s >= stat_obs - eps))
    lo = float(np.mean(s <= stat_obs + eps))
    return (hi, lo) if side == "greater" else (lo, hi)


def _theta_group(E: Engine, fam: str, cells: list) -> tuple:
    """(point, task-id bootstrap draws, reportable) of theta pooled over the cells (both streams);
    reportable = the headline calibration-task flag (Part 2.4 as revised)."""
    if not E.has(f"{fam}|V_swap"):
        return NAN, np.full(E.B, NAN), False
    d, p = theta_draws(E, fam, E.items(cells, "all"))
    TW = getattr(E, "tw", None)
    if TW is not None and TW.cal:
        z = TW.calibration(fam, E.items(cells, "all"))
        return p, d, M.theta_status_calibration(z) == M.THETA_DEFINED
    vh = E.one(f"{fam}|V_home")                 # no calibration tasks: the same-task status (reported)
    pts = [E.at(vh, c, "all") for c in cells]
    b = sum(x[0] for x in pts)
    bd = np.sum([x[1] for x in pts], axis=0)
    se = float(np.nanstd(bd, ddof=1)) if np.isfinite(bd).sum() > 1 else NAN
    return p, d, M.theta_status(b, se) == M.THETA_DEFINED


def core_models(design: Design) -> list:
    """The core grid (revision 2, Part 0.2): the largest set of models, found greedily, whose every
    ordered pair was run. Models that appear only in same-maker extension cells fall outside it."""
    run = set(design.pairs)
    core = list(design.models)
    while len(core) > 1:
        miss = {m: sum(1 for x in core if x != m and ((m, x) not in run or (x, m) not in run)) for m in core}
        worst = max(core, key=lambda m: (miss[m], core.index(m)))
        if miss[worst] == 0:
            break
        core.remove(worst)
    return core


def _block_product(M: int, blocks: list) -> np.ndarray:
    """Relabelings of M models as the product of per-block relabelings [(global indices, (G_b, n_b))];
    models in no block stay fixed. The identity is the first row."""
    sizes = [len(R) for _, R in blocks]
    n = int(np.prod(sizes)) if sizes else 1
    out = np.tile(np.arange(M, dtype=np.int16), (n, 1))
    if not blocks:
        return out
    grids = np.meshgrid(*[np.arange(s) for s in sizes], indexing="ij")
    for (idx, R), gi in zip(blocks, grids):
        ix = np.asarray(idx, dtype=np.int16)
        out[:, ix] = ix[np.asarray(R)[gi.ravel()]]
    return out


def maker_relabelings(design: Design) -> tuple:
    """P1's relabelings (revision 2; Part 7 as Part 11.3.8 registers them for F1): models relabelled
    within their maker and whole makers among makers of equal size (msr.forecast.relabelings, kind
    'maker'), separately in the core grid and among the extension makers, and the product taken (8 core
    models in 4 makers of 2 and 2 extension makers of 2: 384 x 8 = 3,072). Every relabelling keeps each
    pair's same-maker flag and maps every swap onto a swap that was run. (perms, exact, text)."""
    from msr import forecast as F
    models = list(design.models)
    core = core_models(design)
    rest = [m for m in models if m not in core]
    blocks, exact = [], True
    for blk in (core, rest):
        if len(blk) < 2:
            continue
        R, ex = F.relabelings(tuple(design.family[m] for m in blk), "maker")
        exact = exact and bool(ex)
        blocks.append(([models.index(m) for m in blk], R))
    perms = _block_product(len(models), blocks)
    txt = (f"{len(perms):,} maker-preserving relabellings (within makers and of whole makers of equal size"
           + (", core grid and extension makers separately" if rest else "") + ")")
    return perms, exact, txt


def core_permutations(design: Design) -> tuple:
    """P2's and P4's permutations (revision 2): all permutations of the core-grid models (8! = 40,320,
    enumerated), the other models fixed; the tests use the core grid's swaps only. (perms, exact, text, core)."""
    models = list(design.models)
    core = core_models(design)
    R, exact = all_perms(len(core))
    perms = _block_product(len(models), [([models.index(m) for m in core], R)])
    txt = f"{len(perms):,} {'' if exact else 'random '}permutations of the {len(core)} core-grid model labels"
    return perms, exact, txt, core


def theta_diff_twoway(TW: TwoWay, fam_a: str, fam_b: str, items: list) -> dict:
    """theta(fam_a) - theta(fam_b) over the same (cell, stream) items with the two-way jackknife of the
    linearised difference, sum (V_swap - theta V_home) / sum V_home of a minus the same of b (paired: both
    families sit on the same tasks, outcomes and items). est, se, lo, hi, p_upper, p_lower."""
    out = {"est": NAN, "se": NAN, "lo": NAN, "hi": NAN, "p_upper": NAN, "p_lower": NAN}
    th, comps = {}, []
    for fam, sign in ((fam_a, 1.0), (fam_b, -1.0)):
        a, _, _, _ = TW.comps([(f"{fam}|V_swap", c, b, 1.0) for c, b in items])
        b_, _, _, _ = TW.comps([(f"{fam}|V_home", c, b, 1.0) for c, b in items])
        if not (fin(a) and fin(b_)) or b_ == 0:
            return out
        th[fam] = a / b_
        comps += [(f"{fam}|V_swap", c, bb, sign / b_) for c, bb in items]
        comps += [(f"{fam}|V_home", c, bb, -sign * th[fam] / b_) for c, bb in items]
    lr = TW.linear(comps, "upper")
    est = th[fam_a] - th[fam_b]
    se = lr["se"]
    pp = M.normal_p(est, se) if fin(se) else {"p_upper": NAN, "p_lower": NAN}
    out.update(est=est, se=se, lo=est - M.Z95 * se if fin(se) else NAN, hi=est + M.Z95 * se if fin(se) else NAN,
               p_upper=pp["p_upper"], p_lower=pp["p_lower"], item_share=lr.get("item_share", NAN),
               eff_items=lr.get("eff_items", NAN))
    return out


def predictions(E: Engine, design: Design, vrows: list, agree_rows: list, trows: list | None = None) -> tuple:
    """P1-P4 with their pre-registered tests, Holm over the predictions that can be tested with the
    models at hand, and leave-one-model-out. A prediction the study cannot test (too few models
    for its permutation test to reach significance, a missing family or kind of swap) is reported
    as "not testable here (needs ...)", never as "fail"."""
    H = design.headline
    models = design.models
    M = len(models)
    mi = {m: j for j, m in enumerate(models)}
    swaps = design.swaps("all_swaps")
    # revision 2: P1 by maker-preserving relabellings (as F1, Part 11.3.8); P2 and P4 by all permutations
    # of the core grid's model labels, on the core grid's swaps (Part 7)
    perms, exact, perm_txt = maker_relabelings(design)
    n_perm = len(perms)
    perms_c, exact_c, perm_txt_c, core = core_permutations(design)
    n_perm_c = len(perms_c)
    core_set = set(core)
    # round-1 revision: the predictions read the headline theta (the retained ranking signal), not R
    Rg = np.full((M, M), np.nan)
    Rok = {}
    for r in (trows or []):
        if r["family"] == H and r["level"] == "all" and r["owner"] != r["reader"]:
            ok_ = flag_ok(r) and fin(r["theta"])
            Rok[(r["owner"], r["reader"])] = ok_
            if ok_:
                Rg[mi[r["owner"]], mi[r["reader"]]] = r["theta"]
    Kg = np.full((M, M), np.nan)
    for r in agree_rows:
        if r["level"] == "all" and r["owner"] != r["reader"] and r["owner"] in mi and r["reader"] in mi:
            Kg[mi[r["owner"]], mi[r["reader"]]] = r["kappa"]
    G = {b: np.full((M, M), np.nan) for b in E.streams}
    X = {b: np.full(M, np.nan) for b in E.streams}
    if E.has(f"{H}|keep|value") and E.has(f"{H}|wipe|value"):
        keep, wipe = E.one(f"{H}|keep|value"), E.one(f"{H}|wipe|value")
        for b in E.streams:
            for c in swaps:
                G[b][mi[c[0]], mi[c[1]]] = E.at(keep, c, b)[0] - E.at(wipe, c, b)[0]
    if E.has(f"{NO_FAMILY}|none|value"):
        none = E.one(f"{NO_FAMILY}|none|value")
        for b in E.streams:
            for m in models:
                X[b][mi[m]] = E.at(none, (m, m), b)[0]
    points = []
    for c in swaps:
        s_, t_ = mi[c[0]], mi[c[1]]
        pt = {"owner": c[0], "reader": c[1], "group": design.group(*c), "kappa": Kg[s_, t_], "theta": Rg[s_, t_],
              "theta_defined": Rok.get(c, False)}
        for b in E.streams:
            pt[f"G_{b}"] = G[b][s_, t_]
            pt[f"X_reader_{b}"] = X[b][t_]
        points.append(pt)

    def p1_cells(sub=None, kind="all_swaps"):
        return [c for c in design.swaps(kind) if Rok.get(c) and np.isfinite(Kg[mi[c[0]], mi[c[1]]])
                and (sub is None or (c[0] in sub and c[1] in sub))]

    def p1_stat(sub=None, kind="all_swaps", perm=None):
        cs = p1_cells(sub, kind)
        if len(cs) < 3:
            return NAN, None
        si = np.array([mi[c[0]] for c in cs])
        ti = np.array([mi[c[1]] for c in cs])
        rv = Rg[si, ti]
        obs = spearman(Kg[si, ti], rv)
        return obs, (spearman_rows(Kg[perm[:, si], perm[:, ti]], rv) if perm is not None else None)

    def p2_cells(sub=None):
        return [c for c in swaps if c[0] in core_set and c[1] in core_set and all(np.isfinite(G[b][mi[c[0]], mi[c[1]]]) and np.isfinite(X[b][mi[c[1]]])
                                        for b in E.streams) and (sub is None or (c[0] in sub and c[1] in sub))]

    def p2_stat(sub=None, perm=None):
        cs = p2_cells(sub)
        if len(cs) < 3 or len({c[1] for c in cs}) < 2:
            return NAN, None
        si = np.array([mi[c[0]] for c in cs])
        ti = np.array([mi[c[1]] for c in cs])
        obs = float(np.mean([spearman(G[b][si, ti], X[b][ti]) for b in E.streams]))
        if perm is None:
            return obs, None
        return obs, np.mean([spearman_rows(X[b][perm[:, ti]], G[b][si, ti]) for b in E.streams], axis=0)

    up_idx = [(mi[a], mi[b]) for a, b in design.upgrades if a in core_set and b in core_set]
    fam_of = [design.family[m] for m in models]
    cidx = [mi[m] for m in core]
    cross_idx = [(i, j) for i in cidx for j in cidx if i != j and fam_of[i] != fam_of[j]]
    same_idx = [(i, j) for i in cidx for j in cidx if i != j and fam_of[i] == fam_of[j]]

    def p4_stat(keep_models=None, perm=None, first=None):
        first = up_idx if first is None else first
        ok = (lambda i, j: True) if keep_models is None else (lambda i, j: i in keep_models and j in keep_models)
        U = [(i, j) for i, j in first if ok(i, j) and np.isfinite(Rg[i, j])]
        Cx = [(i, j) for i, j in cross_idx if ok(i, j) and np.isfinite(Rg[i, j])]
        if not U or not Cx:
            return NAN, None
        ui, uj = np.array(U).T
        ci_, cj = np.array(Cx).T
        obs = float(np.mean(Rg[ui, uj]) - np.mean(Rg[ci_, cj]))
        if perm is None:
            return obs, None
        U2 = [(i, j) for i, j in first if ok(i, j)]
        C2 = [(i, j) for i, j in cross_idx if ok(i, j)]
        ui, uj = np.array(U2).T
        ci_, cj = np.array(C2).T
        a = nanmean(Rg[perm[:, ui], perm[:, uj]], axis=1)
        b_ = nanmean(Rg[perm[:, ci_], perm[:, cj]], axis=1)
        return obs, a - b_

    def p3_point(fam, sub=None):
        cs = [c for c in swaps if sub is None or (c[0] in sub and c[1] in sub)]
        return _theta_group(E, fam, cs)[0] if cs else NAN

    rows, secondary, lomo = [], [], []
    # ---- structural testability
    need = {}
    if not agree_rows:
        need["P1"] = "agreement.csv (owner and reader on the same calibration cells)"
    elif len(p1_cells()) < 3:
        need["P1"] = "at least 3 swaps with a reportable theta and an agreement value"
    if len(p2_cells()) < 3:
        need["P2"] = "at least 3 swaps with keep, wipe and no-memory values, and 2 readers"
    fams_ok = "ema_grade" in design.score_families and "tags_self" in design.score_families
    if not fams_ok:
        need["P3"] = "the score families ema_grade and tags_self"
    if not up_idx:
        need["P4"] = "at least one same-maker upgrade (an old -> new pair of one maker)"
    elif not cross_idx:
        need["P4"] = "at least one cross-maker swap"
    elif not any(np.isfinite(Rg[i, j]) for i, j in up_idx) or not any(np.isfinite(Rg[i, j]) for i, j in cross_idx):
        need["P4"] = "a reportable theta on at least one upgrade and one cross-maker swap"
    n_struct = sum(1 for p in ("P1", "P2", "P3", "P4") if p not in need)
    alpha_min = design.alpha / max(1, n_struct)

    def min_p_check(name, min_p):
        if name not in need and fin(min_p) and min_p > alpha_min:
            need[name] = (f"more models: with {M} models the smallest possible p of its permutation test is "
                          f"{min_p:.4f}, above {design.alpha:g}/{n_struct} = {alpha_min:.4f}")

    # ---- P1 (revision 2, AC audit N3): F1's test of Part 11.3.8 (msr.forecast.pair_incremental_test): the
    # partial correlation of theta and agreement given Q = [1, same maker, x_owner, x_reader, |gap|, owner
    # newer, reader newer], its null by double semi-partialling over the maker-preserving relabellings. The
    # maker flag alone passes wrongly in 0.099-0.20 of null worlds; with F1's controls 0.048-0.07.
    # Ruling of 24 Nov 2026 (open point 29): P1 (as F1) is computed on the CORE grid only (the models with every
    # ordered pair run), relabelled within and among the core makers; extension pairs never enter it.
    from msr.forecast import newer_coding, pair_controls, pair_incremental_test
    cmods = [m for m in models if m in core_set]
    cmi = {m: j for j, m in enumerate(cmods)}
    p1_all = [c for c in swaps if c[0] in core_set and c[1] in core_set and np.isfinite(Kg[mi[c[0]], mi[c[1]]])]
    Xcap = np.nanmean(np.stack([X[b] for b in E.streams]), axis=0) if E.streams else np.full(M, np.nan)
    newer_c = newer_coding(cmods, [u for u in design.upgrades if u[0] in core_set and u[1] in core_set])

    def p1_test(y_mask=None):
        if len(p1_all) < 3:
            return None
        gi = np.array([mi[c[0]] for c in p1_all], int)       # rows of the full grids
        gj = np.array([mi[c[1]] for c in p1_all], int)
        si1 = np.array([cmi[c[0]] for c in p1_all], int)      # core-model indices for the test
        ti1 = np.array([cmi[c[1]] for c in p1_all], int)
        y = Rg[gi, gj].copy()
        if y_mask is not None:
            y = np.where(y_mask, y, np.nan)
        xc = Xcap[[mi[m] for m in cmods]]
        return pair_incremental_test(Kg[gi, gj], y, si1, ti1, [design.family[m] for m in cmods],
                                     controls=pair_controls(si1, ti1, xc, newer_c), alpha=design.alpha)

    r1 = p1_test() if "P1" not in need else None
    obs = r1["value"] if r1 else NAN
    pg = r1["p_one_sided"] if r1 else NAN
    pl = r1["p_opposite"] if r1 else NAN
    min_p1 = r1["min_attainable_p"] if r1 else NAN
    n_rel1 = r1.get("n_relabelings", NAN) if r1 else NAN
    if r1 is not None and not r1.get("testable", True) and "P1" not in need:
        need["P1"] = f"more models: {r1.get('result', 'not testable')}"
    min_p_check("P1", min_p1)
    rows.append({"prediction": "P1", "statement": "retained validity rises with agreement",
                 "statistic": "partial correlation of theta and kappa given the same-maker flag and F1's controls "
                              "(x_owner, x_reader, |gap|, owner newer, reader newer), over swaps with theta reported",
                 "value": obs, "direction": "> 0",
                 "test": "F1's test (msr.forecast.pair_incremental_test): double semi-partialling over the "
                         f"maker-preserving relabellings ({n_rel1 if fin(n_rel1) else '?'})",
                 "p_one_sided": pg, "p_opposite": pl, "n_swaps": (r1 or {}).get("n_swaps", 0),
                 "n_permutations": n_rel1, "min_possible_p": min_p1,
                 "spearman_kappa_theta": p1_stat()[0] if len(p1_cells()) >= 3 else NAN})
    if "P1" not in need or need["P1"].startswith("more models"):
        cross_mask = np.array([design.group(*c) == "cross" for c in p1_all], bool)
        r2 = p1_test(cross_mask) if cross_mask.any() else None
        secondary.append({"prediction": "P1", "analysis": "cross-maker swaps only (F1's test)",
                          "value": r2["value"] if r2 else NAN, "p_one_sided": r2["p_one_sided"] if r2 else NAN})
    # ---- P2
    obs2, st2 = p2_stat(perm=perms_c) if "P2" not in need else (NAN, None)
    p2l, p2h = _perm_p(obs2, st2, "less") if st2 is not None else (NAN, NAN)
    min_p_check("P2", 1.0 / n_perm_c)
    rows.append({"prediction": "P2", "statement": "the keep-wipe gap shrinks as the reader's no-memory success rises",
                 "statistic": "mean over streams of Spearman rho2(G, X) over swaps", "value": obs2,
                 "direction": "< 0", "test": f"model-label permutation of X ({perm_txt_c})",
                 "p_one_sided": p2l, "p_opposite": p2h, "n_swaps": len(p2_cells()), "n_permutations": n_perm_c,
                 "min_possible_p": 1.0 / n_perm_c})
    # ---- P3
    if fams_ok:
        re_p, re_d, re_ok = _theta_group(E, "ema_grade", swaps)
        rt_p, rt_d, rt_ok = _theta_group(E, "tags_self", swaps)
        testable = re_ok and rt_ok
        TWp = getattr(E, "tw", None) or TwoWay(E, design, {})
        # revision 2: the two-way jackknife of the linearised, paired difference (Part 7, P3)
        d3 = theta_diff_twoway(TWp, "ema_grade", "tags_self", E.items(swaps, "all"))
        d3b = summarize(re_p - rt_p, re_d - rt_d)          # the round-1 task bootstrap, kept as a column
        rows.append({"prediction": "P3", "statement": "self-given tags lose more ranking signal than program-graded scores",
                     "statistic": "theta(ema_grade) - theta(tags_self), all swaps and streams", "value": d3["est"],
                     "value_lo": d3["lo"], "value_hi": d3["hi"], "direction": "> 0",
                     "test": "two-way jackknife of the linearised paired difference, one-sided p_upper",
                     "p_one_sided": d3["p_upper"] if testable else NAN, "p_opposite": d3["p_lower"] if testable else NAN,
                     "n_swaps": len(swaps), "theta_ema_grade": re_p, "theta_tags_self": rt_p, "home_signal_ok": testable,
                     "value_lo_task_boot": d3b["lo"], "value_hi_task_boot": d3b["hi"]})
        for g in GROUPS:
            cs = design.swaps(g)
            if cs:
                sm = theta_diff_twoway(TWp, "ema_grade", "tags_self", E.items(cs, "all"))
                secondary.append({"prediction": "P3", "analysis": f"within {g}", "value": sm["est"],
                                  "lo": sm["lo"], "hi": sm["hi"], "p_one_sided": sm["p_upper"]})
        if "beta_grade" in design.score_families:
            b = _theta_group(E, "beta_grade", swaps)
            sm = summarize(b[0] - rt_p, b[1] - rt_d)
            secondary.append({"prediction": "P3", "analysis": "theta(beta_grade) - theta(tags_self)", "value": sm["est"],
                              "lo": sm["lo"], "hi": sm["hi"], "p_one_sided": sm["p_upper"]})
        dt = validity_block(E, design, "tags_self", False, swaps, "all", lambda c: c[0])
        de = validity_block(E, design, "ema_grade", False, swaps, "all", lambda c: c[0])
        sm = summarize((dt["h"][0] - dt["s"][0]) - (de["h"][0] - de["s"][0]),
                       (dt["h"][1] - dt["s"][1]) - (de["h"][1] - de["s"][1]))
        secondary.append({"prediction": "P3", "analysis": "D(tags_self) - D(ema_grade) in concordance points",
                          "value": sm["est"], "lo": sm["lo"], "hi": sm["hi"], "p_one_sided": sm["p_upper"]})
    else:
        rows.append({"prediction": "P3", "statement": "self-given tags lose more validity than program-graded scores",
                     "value": NAN, "p_one_sided": NAN, "direction": "> 0"})
    # ---- P4
    obs4, st4 = p4_stat(perm=perms_c) if "P4" not in need else (NAN, None)
    p4g, p4l = _perm_p(obs4, st4, "greater") if st4 is not None else (NAN, NAN)
    up_set = set(up_idx)
    n_fix = sum(1 for p in perms_c if {(int(p[i]), int(p[j])) for i, j in up_idx} == up_set) if up_idx else 0
    min_p4 = n_fix / n_perm_c if n_fix else NAN
    min_p_check("P4", min_p4)
    rows.append({"prediction": "P4", "statement": "same-maker upgrades retain more ranking signal than cross-maker swaps",
                 "statistic": "mean theta over upgrades - mean theta over cross-maker swaps", "value": obs4,
                 "direction": "> 0", "test": f"model-label permutation of the maker-and-generation structure ({perm_txt_c})",
                 "p_one_sided": p4g, "p_opposite": p4l, "n_swaps": len(up_idx) + len(cross_idx),
                 "n_permutations": n_perm_c, "min_possible_p": min_p4})
    if same_idx and cross_idx:
        o4s, s4s = p4_stat(perm=perms_c, first=same_idx)
        secondary.append({"prediction": "P4", "analysis": "all same-maker swaps vs cross-maker", "value": o4s,
                          "p_one_sided": _perm_p(o4s, s4s, "greater")[0] if s4s is not None else NAN})
    # ---- testable set, Holm over it, pass / fail
    for r in rows:
        r["testable_here"] = r["prediction"] not in need
        r["needs"] = need.get(r["prediction"], "")
    tested = [r for r in rows if r["testable_here"] and fin(r.get("p_one_sided"))]
    hs = holm_steps([r["p_one_sided"] for r in tested], design.alpha)
    for r, adj in zip(tested, hs["adjusted"]):
        r["holm_adjusted_p"] = adj
    for r in rows:
        r["holm_family_size"] = len(tested)
        if not r["testable_here"]:
            r["result"] = f"not testable here (needs {r['needs']})"
            r["contradicted"] = False
            continue
        if r["prediction"] == "P3" and not r.get("home_signal_ok", True):
            r["result"] = "not testable (home signal too weak; counts as not passed)"
            r["contradicted"] = False
            continue
        adj = r.get("holm_adjusted_p", NAN)
        good = fin(r.get("value")) and ((r["value"] > 0) if r.get("direction", "> 0") == "> 0" else (r["value"] < 0))
        r["result"] = "pass" if (good and fin(adj) and adj <= design.alpha) else "fail"
        r["contradicted"] = bool(fin(r.get("p_opposite")) and r["p_opposite"] <= design.alpha)
    # ---- leave one model out (only with more than 3 models)
    if M > 3:
        for m in models:
            keepm = {x for x in models if x != m}
            ki = {mi[x] for x in keepm}
            r1m = p1_test(np.array([m not in c for c in p1_all], bool)) if p1_all else None
            vals = {"P1": r1m["value"] if r1m else NAN, "P2": p2_stat(sub=keepm)[0], "P4": p4_stat(keep_models=ki)[0]}
            if fams_ok:
                vals["P3"] = p3_point("ema_grade", keepm) - p3_point("tags_self", keepm)
            for p_, v in vals.items():
                lomo.append({"prediction": p_, "left_out": m, "value": v})
    for r in rows:
        vs = [x for x in lomo if x["prediction"] == r["prediction"]]
        flips = [x["left_out"] for x in vs if fin(x["value"]) and fin(r.get("value"))
                 and np.sign(x["value"]) != np.sign(r["value"])]
        r["lomo_min"] = min([x["value"] for x in vs if fin(x["value"])] or [NAN])
        r["lomo_max"] = max([x["value"] for x in vs if fin(x["value"])] or [NAN])
        r["lomo_sign_flips"] = "; ".join(flips)
        if r["result"] == "pass" and flips:
            r["result"] = "pass, not robust to leaving out " + ", ".join(flips)
    return rows, secondary, lomo, points


# ===========================================================================
# Cross-checks (4.6) and leave-one-model-out of the primary statistics (8.2.13)
# ===========================================================================


def linearised_checks(E: Engine, design: Design, tests: list) -> list:
    """Cross-checks of the primary tests (4.6 as revised): the decision with the task-only variance
    beside the two-way one (columns of primary_tests.csv), and the paired sign-flip permutation test
    of PC2 on the task-level differences (10,000 flips, seed 0)."""
    H = design.headline
    out = []
    data = E.data

    def col(key, cell, s):
        m = data.mats[s].get(key)
        if m is None:
            return np.full(len(data.tasks[s]), np.nan)
        return m[:, E.ci[cell]].astype(float)

    for r in tests:
        g, comp = r["group"], r["comparison"]
        cells = design.swaps(g)
        if not cells or not fin(r.get("p_holm_input")):
            continue
        thr = r.get("holm_threshold")
        pt = {"PC1-drop": r.get("p_drop_task_lin"), "PC1-MD": r.get("p_md_task_lin"),
              "PC1-NI": r.get("p_ni_task_lin")}.get(comp, NAN)
        if comp in ("PC1-drop", "PC1-MD", "PC1-NI") and fin(pt):
            out.append({"test": r["test"], "check": "task-only linearised variance (task ids pooled over orders)",
                        "est": r.get("est"), "se": NAN, "p": pt, "note": "items treated as fixed",
                        "bootstrap_reject": r["holm_reject"],
                        "linearised_reject_at_same_threshold": bool(fin(thr) and pt <= thr),
                        "decisions_agree": bool(fin(thr) and pt <= thr) == bool(r["holm_reject"])})
        if comp == "PC2":
            rng = np.random.default_rng(0)
            nflip = 10000
            per_stream = []
            for b in E.streams:
                ss = [s for s in data.strata if s[0] == b]
                dsum = []
                for s in ss:
                    dd = nanmean(np.vstack([col(f"{H}|keep|value", c, s) - col(f"{H}|wipe|value", c, s)
                                            for c in cells]), axis=0)
                    dsum.append(dd[np.isfinite(dd)])
                per_stream.append(np.concatenate(dsum))
            obs = float(np.mean([x.mean() for x in per_stream]))
            stats = np.zeros(nflip)
            for x in per_stream:
                signs = rng.choice((-1.0, 1.0), size=(nflip, len(x)))
                stats += (signs * x).mean(axis=1)
            stats /= len(per_stream)
            p = float((1 + np.sum(np.abs(stats) >= abs(obs) - 1e-12)) / (nflip + 1))
            out.append({"test": r["test"], "check": "paired sign-flip permutation (10,000 flips, seed 0)",
                        "est": obs, "se": NAN, "p": p, "note": "tasks as independent units",
                        "bootstrap_reject": r["holm_reject"],
                        "linearised_reject_at_same_threshold": bool(fin(thr) and p <= thr), "decisions_agree": ""})
    return out


def lomo_primary(E: Engine, design: Design, pv: dict) -> list:
    """PC1-PC4 stratum statistics recomputed 8 times, each without one model (point estimates)."""
    out = []
    for comp, vals in pv.items():
        for g in GROUPS:
            base_cells = [c for c in design.swaps(g) if c in vals and fin(vals[c][0])]
            if not base_cells:
                continue
            full = float(np.mean([vals[c][0] for c in base_cells]))
            for m in design.models:
                cs = [c for c in base_cells if m not in c]
                v = float(np.mean([vals[c][0] for c in cs])) if cs else NAN
                out.append({"comparison": comp, "group": g, "left_out": m, "value": v, "full": full,
                            "sign_flip": bool(fin(v) and np.sign(v) != np.sign(full))})
    return out


# ===========================================================================
# Secondary analyses from the other result files
# ===========================================================================


def _wmean(rows, col, wcol=None):
    v = [(num(r.get(col)), num(r.get(wcol)) if wcol else 1.0) for r in rows]
    v = [(a, w) for a, w in v if fin(a) and fin(w) and w > 0]
    if not v:
        return NAN
    return sum(a * w for a, w in v) / sum(w for _, w in v)


def validity_extras(design: Design, results: Path, vrows: list) -> list:
    """Unweighted C, split-half noise references, noise-normalised C, top-1/top-2 agreement and the
    shuffled control, pooled over the orders (weights: evaluation tasks or informative pairs)."""
    rows = read_csv(results / "validity.csv")
    by = defaultdict(list)
    for r in rows:
        by[(r["family"], r["owner"], r["reader"], r["stream"])].append(r)
    cw = {(r["family"], r["owner"], r["reader"], r["level"]): r for r in vrows}
    out = []
    for (fam, o, rd, b), rs in sorted(by.items()):
        row = {"family": fam, "owner": o, "reader": rd, "group": design.group(o, rd), "level": b}
        for c, w in (("home_u", "home_pairs"), ("swap_u", "swap_pairs"), ("floor_u", "home_pairs"),
                     ("ceiling_home", "eval_tasks"), ("ceiling_swap", "eval_tasks"),
                     ("ceiling_home_extra", "eval_tasks"), ("top1_home", "eval_tasks"), ("top1_swap", "eval_tasks"),
                     ("top2_home", "eval_tasks"), ("top2_swap", "eval_tasks"), ("top1_home_chance", "eval_tasks"),
                     ("top1_swap_chance", "eval_tasks"), ("top2_home_chance", "eval_tasks"),
                     ("top2_swap_chance", "eval_tasks"), ("home_shuffled", "eval_tasks"),
                     ("swap_shuffled", "eval_tasks")):
            if c in rs[0]:
                row[c] = _wmean(rs, c, w if w in rs[0] else None)
        v = cw.get((fam, o, rd, b))
        if v is not None:
            for c, ce in (("C_home", "ceiling_home"), ("C_swap", "ceiling_swap")):
                if fin(row.get(ce)) and row[ce] != 0.5:
                    row[f"{c}_noise_normalised"] = (v[c] - 0.5) / (row[ce] - 0.5)
        out.append(row)
    # level "all" = mean over streams
    agg = defaultdict(list)
    for r in out:
        agg[(r["family"], r["owner"], r["reader"])].append(r)
    for (fam, o, rd), rs in sorted(agg.items()):
        row = {"family": fam, "owner": o, "reader": rd, "group": design.group(o, rd), "level": "all"}
        for c in rs[0]:
            if c not in row:
                row[c] = nanmean([num(r.get(c)) for r in rs])
        out.append(row)
    # group means of the shuffled control and unweighted C
    return out


def extras_by_group(design: Design, extras: list) -> list:
    out = []
    for fam in design.score_families:
        for g in DESC_GROUPS:
            rs = [r for r in extras if r["family"] == fam and r["level"] == "all" and design.in_group(r["owner"], r["reader"], g)]
            if not rs:
                continue
            row = {"family": fam, "group": g, "n_swaps": len(rs)}
            for c in ("home_shuffled", "swap_shuffled", "home_u", "swap_u", "top1_swap", "top1_swap_chance",
                      "top2_swap", "top2_swap_chance", "ceiling_home", "ceiling_swap"):
                row[c] = nanmean([num(r.get(c)) for r in rs])
            out.append(row)
    return out


def mix_weight(design: Design, results: Path) -> list:
    """Exploratory 8.3.1: first-shown success re-ranked offline with score weight 0.25 and 0.75
    (point estimates: the per-task values at those weights are not in the result files)."""
    rows = read_csv(results / "arms.csv")
    if not rows:
        return []
    wcols = [c for c in rows[0] if c.startswith("value_w")]
    acc = defaultdict(list)
    for r in rows:
        acc[(r["family"], r["arm"], r["owner"], r["reader"])].append(r)
    out = []
    for fam in design.score_families:
        for arm in ("keep", "wipe", f"fixed_{design.primary_lambda:g}", "shuffled", "own"):
            for g in GROUPS + ("all_swaps", "home"):
                cells = design.swaps(g)
                vals = {"main": [], **{c: [] for c in wcols}}
                for c in cells:
                    rs = acc.get((fam, arm, c[0], c[1]), [])
                    if not rs:
                        continue
                    vals["main"].append(_wmean(rs, "value", "n_tasks"))
                    for wc in wcols:
                        vals[wc].append(_wmean(rs, wc, "n_tasks"))
                if not vals["main"]:
                    continue
                row = {"family": fam, "arm": arm, "group": g, "n_swaps": len(vals["main"]),
                       f"value_score_w{design.w_score:g}": nanmean(vals["main"])}
                for wc in wcols:                   # arms.csv value_w<w>: w = weight on the score
                    row[f"value_score_w{wc[len('value_w'):]}"] = nanmean(vals[wc])
                out.append(row)
    return out


def shapley_tables(design: Design, results: Path) -> tuple:
    sub = read_csv(results / "subsets.csv")
    shp = read_csv(results / "shapley.csv")
    out = []
    by = defaultdict(list)
    for r in sub:
        by[(r["family"], r["owner"], r["reader"])].append(r)
    for (fam, o, rd), rs in sorted(by.items()):
        row = {"family": fam, "owner": o, "reader": rd, "group": design.group(o, rd),
               "tasks": sum(num(r["tasks"]) for r in rs),
               "single_vs_shapley": _wmean(rs, "single_vs_shapley", "tasks"),
               "validity_single": _wmean(rs, "validity_single", "tasks"),
               "validity_shapley": _wmean(rs, "validity_shapley", "tasks")}
        if o != rd and (fam, o, o) in by:
            hs = by[(fam, o, o)]
            row["D_single"] = _wmean(hs, "validity_single", "tasks") - row["validity_single"]
            row["D_shapley"] = _wmean(hs, "validity_shapley", "tasks") - row["validity_shapley"]
        out.append(row)
    pts = [{"owner": r["owner"], "reader": r["reader"], "group": design.group(r["owner"], r["reader"]),
            "stream": r["stream"], "seed": r["seed"], "task_id": r["task_id"], "item_id": r["item_id"],
            "single": num(r["single"]), "shapley": num(r["shapley"])} for r in shp]
    return out, pts


def second_bank(design: Design, results: Path) -> list:
    rows = read_csv(results / "repeatability.csv")
    by = defaultdict(list)
    for r in rows:
        by[(r["model"], r["family"])].append(r)
    out = []
    for (m, fam), rs in sorted(by.items()):
        out.append({"model": m, "family": fam, "orders": len(rs),
                    **{c: nanmean([num(r.get(c)) for r in rs]) for c in
                       ("spearman", "pair_agreement", "home_validity_bank1", "home_validity_bank2") if c in rs[0]}})
    return out


def second_wording(design: Design, results: Path) -> list:
    rows = read_csv(results / "variants.csv")
    by = defaultdict(list)
    for r in rows:
        by[(r["family"], r["owner"], r["reader"])].append(r)
    out = []
    for (fam, o, rd), rs in sorted(by.items()):
        row = {"family": fam, "owner": o, "reader": rd, "group": design.group(o, rd),
               "variant": rs[0].get("variant", ""), "tasks": sum(num(r["tasks"]) for r in rs),
               "validity_v1": _wmean(rs, "validity_v1", "tasks"),
               "validity_variant": _wmean(rs, "validity_variant", "tasks"),
               "outcome_agreement": _wmean(rs, "outcome_agreement", "tasks"),
               "outcome_kappa": _wmean(rs, "outcome_kappa", "tasks")}
        if o != rd and (fam, o, o) in by:
            hs = by[(fam, o, o)]
            row["D_v1"] = _wmean(hs, "validity_v1", "tasks") - row["validity_v1"]
            row["D_variant"] = _wmean(hs, "validity_variant", "tasks") - row["validity_variant"]
        out.append(row)
    return out


def _fmean(xs) -> float:
    """Mean of the finite numbers in xs (NaN if none); no numpy overhead for short lists."""
    v = [float(x) for x in xs if x is not None and x == x and fin(x)]
    return sum(v) / len(v) if v else NAN


def check_arm_draws(design: Design, results: Path) -> list:
    """8.2.10 and 4.5: the fitted values of the calibrated arms over the random draws (lambda,
    level, slope, audit decision) and the 5th-95th percentile of an arm's pooled value over draws
    ("what a single swap day may look like"), headline family, pooled over the orders."""
    H = design.headline
    acc = defaultdict(lambda: defaultdict(dict))         # (arm, owner, reader) -> draw -> seed -> row
    d = results / "draws"
    if not d.exists():
        return []
    needle = f'"family": "{H}"'
    for p in sorted(d.glob("*.jsonl")):
        parts = p.stem.split("__")
        if len(parts) != 4:
            continue
        o, rd, b, sd = parts
        with open(p, encoding="utf-8") as f:
            for line in f:
                if needle not in line:
                    continue
                r = json.loads(line)
                if r.get("family") != H:
                    continue
                acc[(r["arm"], o, rd)][int(r["draw"])][(b, sd)] = r
    out = []
    home_lam = {}
    for (arm, o, rd), draws in acc.items():
        if o == rd:
            lams = [num(x.get("lam")) for dd in draws.values() for x in dd.values() if "lam" in x]
            if lams:
                home_lam[(arm, o)] = float(np.median(lams))
    for (arm, o, rd), draws in sorted(acc.items(), key=lambda kv: (arm_sort_key(kv[0][0]), kv[0][1], kv[0][2])):
        vals = [_fmean([x.get("value") for x in dd.values()]) for _, dd in sorted(draws.items())]
        logs = [_fmean([x.get("log") for x in dd.values()]) for _, dd in sorted(draws.items())]
        allx = [x for dd in draws.values() for x in dd.values()]
        row = {"family": H, "arm": arm, "owner": o, "reader": rd, "group": design.group(o, rd),
               "draws": len(draws), "value_mean": nanmean(vals),
               "value_p05": float(np.nanpercentile(vals, 5)) if vals else NAN,
               "value_p95": float(np.nanpercentile(vals, 95)) if vals else NAN}
        lv = [v for v in logs if fin(v)]
        if lv:
            row.update(log_p05=float(np.percentile(lv, 5)), log_p95=float(np.percentile(lv, 95)))
        lams = [num(x["lam"]) for x in allx if "lam" in x]
        if lams:
            row.update(lam_mean=float(np.mean(lams)), lam_median=float(np.median(lams)),
                       lam_q25=float(np.percentile(lams, 25)), lam_q75=float(np.percentile(lams, 75)))
            hl = home_lam.get((arm, o))
            if hl:
                row["lam_median_over_home"] = row["lam_median"] / hl
        sl = [num(x["slope"]) for x in allx if "slope" in x]
        if sl:
            lv2 = [num(x["level"]) for x in allx if "level" in x]
            row.update(slope_median=float(np.median(sl)), slope_q25=float(np.percentile(sl, 25)),
                       slope_q75=float(np.percentile(sl, 75)), level_median=float(np.median(lv2)))
        dec = [x["decision"] for x in allx if "decision" in x]
        if dec:
            row["keep_share"] = float(np.mean([v == "keep" for v in dec]))
        out.append(row)
    return out


def online_tables(design: Design, run_dir: Path, n_boot: int, seed: int) -> tuple:
    """The post-swap run (2.10, 8.2.6): S_all, S_first and tau95 per arm and swap; differences from
    keep with intervals from positions resampled within each order (same draws for every arm)."""
    base = run_dir / "online"
    if not base.exists():
        return [], [], []
    runs = {}
    for pdir in sorted(base.iterdir()):
        if "__" not in pdir.name:
            continue
        o, rd = pdir.name.split("__", 1)
        for b in design.streams:
            for sd in design.seeds:
                f = pdir / b / f"seed{sd}" / "online.jsonl"
                if f.exists():
                    byarm = defaultdict(list)
                    for r in read_jsonl(f):
                        byarm[(r["arm"], r["family"])].append((int(r["position"]), bool(r["correct"])))
                    runs[(o, rd, b, sd)] = {k: np.array([c for _, c in sorted(v)], dtype=float)
                                            for k, v in byarm.items()}
    if not runs:
        return [], [], []
    pairs = sorted({(k[0], k[1]) for k in runs}, key=lambda p: (design.swaps("all_swaps").index(p)
                                                               if p in design.swaps("all_swaps") else 999))
    strata = sorted({(k[2], k[3]) for k in runs})
    sizes = {s: max(len(v) for k, arms in runs.items() if (k[2], k[3]) == s for v in arms.values()) for s in strata}
    boot = JointBootstrap({(f"online|{k[0]}", k[1]): v for k, v in sizes.items()}, n_boot, seed)
    boot.counts = {(k[0][len("online|"):], k[1]): v for k, v in boot.counts.items()}
    arm_keys = sorted({a for v in runs.values() for a in v}, key=lambda a: arm_sort_key(a[0]))
    streams = [b for b in design.streams if any(s[0] == b for s in strata)]
    rows, groups, curves = [], [], []
    first_n, W = design.first_n, design.window

    def pooled(o, rd, b, ak, first=False):
        num_pt = den_pt = 0.0
        num_b = np.zeros(boot.n_draws)
        den_b = np.zeros(boot.n_draws)
        for s in strata:
            if s[0] != b:
                continue
            x = runs.get((o, rd, b, s[1]), {}).get(ak)
            if x is None:
                continue
            n = sizes[s]
            v = np.full(n, np.nan)
            v[:len(x)] = x
            if first:
                v[first_n:] = np.nan
            ok = np.isfinite(v)
            num_pt += np.nansum(v)
            den_pt += ok.sum()
            num_b += boot.resampled_sum(s, np.where(ok, v, 0.0))
            den_b += boot.counts[s] @ ok.astype(float)
        if den_pt == 0:
            return NAN, np.full(boot.n_draws, np.nan)
        with np.errstate(invalid="ignore", divide="ignore"):
            return num_pt / den_pt, num_b / den_b

    def lvl(o, rd, ak, level, first=False):
        bs = streams if level == "all" else [level]
        got = [pooled(o, rd, b, ak, first) for b in bs]
        got = [g for g in got if fin(g[0])]
        if not got:
            return NAN, np.full(boot.n_draws, np.nan)
        return float(np.mean([g[0] for g in got])), np.mean(np.vstack([g[1] for g in got]), axis=0)

    H = design.headline
    keep_key = ("keep", H)
    own_key = ("own", H)
    for (o, rd) in pairs:
        for level in streams + ["all"]:
            kp = lvl(o, rd, keep_key, level)
            kf = lvl(o, rd, keep_key, level, True)
            own_all = lvl(o, rd, own_key, level)[0]
            for ak in arm_keys:
                s_all = lvl(o, rd, ak, level)
                if not fin(s_all[0]):
                    continue
                s_first = lvl(o, rd, ak, level, True)
                a, f = summarize(*s_all), summarize(*s_first)
                da = summarize(s_all[0] - kp[0], s_all[1] - kp[1])
                df_ = summarize(s_first[0] - kf[0], s_first[1] - kf[1])
                row = {"owner": o, "reader": rd, "group": design.group(o, rd), "level": level, "arm": ak[0],
                       "family": ak[1], "S_all": a["est"], "S_all_lo": a["lo"], "S_all_hi": a["hi"],
                       "S_first": f["est"], "S_first_lo": f["lo"], "S_first_hi": f["hi"], "first_n": first_n,
                       "S_all_minus_keep": da["est"], "S_all_minus_keep_lo": da["lo"], "S_all_minus_keep_hi": da["hi"],
                       "S_first_minus_keep": df_["est"], "S_first_minus_keep_lo": df_["lo"],
                       "S_first_minus_keep_hi": df_["hi"]}
                if level != "all":
                    # tau95: first position n >= W at which the trailing-W success, averaged over the
                    # orders, reaches target_share x S_all(own) (pre-registration 2.10)
                    trails = []
                    for s in strata:
                        if s[0] != level:
                            continue
                        x = runs.get((o, rd, level, s[1]), {}).get(ak)
                        if x is None or len(x) < W:
                            continue
                        c = np.cumsum(np.insert(x, 0, 0.0))
                        tr = np.full(len(x), np.nan)
                        tr[W - 1:] = (c[W:] - c[:-W]) / W
                        trails.append(tr)
                    if trails:
                        n_min = min(len(t) for t in trails)
                        avg = nanmean(np.vstack([t[:n_min] for t in trails]), axis=0)
                        target = design.target_share * own_all if fin(own_all) else NAN
                        hit = np.flatnonzero(avg >= target) if fin(target) else []
                        row["target"] = target
                        row["tau95"] = int(hit[0] + 1) if len(hit) else ""
                        row["tau95_status"] = "reached" if len(hit) else f"not reached by {n_min}"
                        for pos in range(W - 1, n_min):
                            if np.isfinite(avg[pos]):
                                curves.append({"owner": o, "reader": rd, "group": design.group(o, rd), "level": level,
                                               "arm": ak[0], "family": ak[1], "position": pos + 1,
                                               "trailing_success": float(avg[pos]), "window": W})
                rows.append(row)
    # group means (kind of swap) of S_all and its difference from keep
    for g in GROUPS + ("all_swaps",):
        gp = [p for p in pairs if design.in_group(*p, g)]
        if not gp:
            continue
        for ak in arm_keys:
            vals = [lvl(o, rd, ak, "all") for o, rd in gp]
            kps = [lvl(o, rd, keep_key, "all") for o, rd in gp]
            ok = [j for j, v in enumerate(vals) if fin(v[0]) and fin(kps[j][0])]
            if not ok:
                continue
            p = float(np.mean([vals[j][0] for j in ok]))
            dr = np.mean(np.vstack([vals[j][1] for j in ok]), axis=0)
            pk = float(np.mean([kps[j][0] for j in ok]))
            dk = np.mean(np.vstack([kps[j][1] for j in ok]), axis=0)
            a, d = summarize(p, dr), summarize(p - pk, dr - dk)
            groups.append({"group": g, "n_swaps": len(ok), "arm": ak[0], "family": ak[1], "S_all": a["est"],
                           "S_all_lo": a["lo"], "S_all_hi": a["hi"], "S_all_minus_keep": d["est"],
                           "S_all_minus_keep_lo": d["lo"], "S_all_minus_keep_hi": d["hi"]})
    return rows, groups, curves


def sensitivity_status(results: Path) -> list:
    """Pass-through of results/sensitivity.json (8.2.14 and Part 1 sensitivity rules), one row per item."""
    p = results / "sensitivity.json"
    if not p.exists():
        return []
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except ValueError:
        return []
    out = []
    for name, v in sorted(d.items()):
        if isinstance(v, dict):
            extra = "; ".join(f"{k}={v[k]}" for k in sorted(v) if k != "status")
            out.append({"analysis": name, "status": v.get("status", ""), "details": extra})
        else:
            out.append({"analysis": name, "status": str(v), "details": ""})
    return out


def cost_tables(design: Design, results: Path, run_dir: Path) -> tuple:
    rows = read_csv(results / "costs.csv")
    by_model = []
    stages = sorted({r["stage"] for r in rows})
    for m in design.models:
        rs = [r for r in rows if r["model"] == m]
        if not rs:
            continue
        for r in rs:
            by_model.append({"model": m, "stage": r["stage"], "calls": int(num(r["calls"])),
                             "fresh_calls": int(num(r.get("fresh_calls", r["calls"]))),
                             "tokens_in": int(num(r.get("tokens_in", 0))), "tokens_out": int(num(r.get("tokens_out", 0))),
                             "usd": num(r.get("usd", 0))})
        by_model.append({"model": m, "stage": "total", "calls": sum(int(num(r["calls"])) for r in rs),
                         "fresh_calls": sum(int(num(r.get("fresh_calls", r["calls"]))) for r in rs),
                         "tokens_in": sum(int(num(r.get("tokens_in", 0))) for r in rs),
                         "tokens_out": sum(int(num(r.get("tokens_out", 0))) for r in rs),
                         "usd": sum(num(r.get("usd", 0)) for r in rs)})
    if rows:
        by_model.append({"model": "all", "stage": "total", "calls": sum(int(num(r["calls"])) for r in rows),
                         "fresh_calls": sum(int(num(r.get("fresh_calls", r["calls"]))) for r in rows),
                         "tokens_in": sum(int(num(r.get("tokens_in", 0))) for r in rows),
                         "tokens_out": sum(int(num(r.get("tokens_out", 0))) for r in rows),
                         "usd": sum(num(r.get("usd", 0)) for r in rows)})
    # cost of one swap day per arm (one owner bank, one reader, one stream, one order), revision 2:
    # the k reader calls a k-check arm needs, at the reader's measured probe cost per call; own needs ONE
    # reader build (not the per-model total over every stream, order and second bank); the level
    # information behind every level-corrected log / Brier score (PC3, PC4) is bought once per swap day
    # and shared by every rule read on those scores, so it is ONE fixed row, not charged to each arm
    # (Part 6.4); first-shown success (PC2) needs none
    per_call = {}
    build_cost = {}
    for m in design.models:
        pr = [r for r in rows if r["model"] == m and r["stage"] == "probe"]
        fc = sum(num(r.get("fresh_calls", r["calls"])) for r in pr)
        if fc:
            per_call[m] = (sum(num(r.get("tokens_in", 0)) for r in pr) / fc,
                           sum(num(r.get("tokens_out", 0)) for r in pr) / fc,
                           sum(num(r.get("usd", 0)) for r in pr) / fc)
        br = [r for r in rows if r["model"] == m and r["stage"] in ("write", "build", "build0", "selfmark")]
        if br:
            build_cost[m] = (sum(num(r["calls"]) for r in br), sum(num(r.get("usd", 0)) for r in br))
    by_arm = []
    arms = ["none", "relevance", "keep", "wipe", f"fixed_{design.primary_lambda:g}", "shuffled"]
    arms += [f"{a}_{k}" for k in design.k_values for a in CHECK_ARMS]
    arms += ["own", "split_half", "ceiling"]
    tin = nanmean([v[0] for v in per_call.values()]) if per_call else NAN
    tout = nanmean([v[1] for v in per_call.values()]) if per_call else NAN
    usd = nanmean([v[2] for v in per_call.values()]) if per_call else NAN
    # one build of one reader for one stream and order; the measured per-model total divided by its
    # (stream, order) banks is the fallback when the design carries no sizes (second banks then inflate it)
    n_banks = max(1, len(design.streams) * len(design.seeds))
    own_calls = design.own_build_calls if fin(design.own_build_calls) else (
        nanmean([v[0] for v in build_cost.values()]) / n_banks if build_cost else NAN)
    build_usd_per_call = nanmean([v[1] / v[0] for v in build_cost.values() if v[0]]) if build_cost else NAN
    log_read = {"keep", "wipe", f"fixed_{design.primary_lambda:g}", "shuffled", "constant"}
    for a in arms:
        base, k = arm_parts(a)
        if base in CHECK_ARMS:
            calls = k
        elif a == "own":
            calls = own_calls
        elif a in ("split_half", "ceiling"):
            calls = NAN
        else:
            calls = 0
        row = {"arm": a, "reader_calls_per_swap_day": calls,
               "tokens_in_per_call": tin, "tokens_out_per_call": tout,
               "owner_calls_before_swap": 0,
               "uses_level_information": bool(base in CHECK_ARMS or a in log_read),
               "cost_kind": "per rule"}
        if a == "own":
            row["usd_per_swap_day"] = calls * build_usd_per_call if fin(calls) and fin(build_usd_per_call) else NAN
            row["note"] = ("ONE build by the reader on this stream and order (write, no-memory run, score epochs, tags); "
                           "revision 2: before, the per-model total over every stream, order and second bank was charged")
        elif a in ("split_half", "ceiling"):
            row["usd_per_swap_day"] = NAN
            row["note"] = ("a reference that needs the reader's full probe results; not a deployable rule"
                           + ("; the in-sample ceiling" if a == "ceiling" else "; not an upper bound"))
        else:
            row["usd_per_swap_day"] = calls * usd if fin(usd) else NAN
            row["note"] = ("per (owner, reader, stream, order) swap day; offline look-up costs nothing" if calls == 0
                           else "k reader calls on calibration cells, at the mean measured probe cost per call") \
                + ("; read on the level-corrected log / Brier score it also uses the shared level information "
                   "(row 'level information')" if row["uses_level_information"] else "")
        by_arm.append(row)
    lv = design.level_calls
    by_arm.append({"arm": "level information", "reader_calls_per_swap_day": lv, "tokens_in_per_call": tin,
                   "tokens_out_per_call": tout, "owner_calls_before_swap": 0, "uses_level_information": True,
                   "cost_kind": "shared fixed cost (once per swap day)",
                   "usd_per_swap_day": lv * usd if fin(lv) and fin(usd) else NAN,
                   "note": "the reader's no-memory runs of the calibration tasks: the level target of every level-corrected "
                           "log and Brier score (PC3, PC4); bought once per swap day and shared by every rule read on "
                           "those scores; first-shown success (PC2) needs none"})
    by_arm.append({"arm": "paired keep-or-drop test (owner's stored results)", "reader_calls_per_swap_day": NAN,
                   "tokens_in_per_call": tin, "tokens_out_per_call": tout,
                   "owner_calls_before_swap": design.owner_pool_calls, "uses_level_information": False,
                   "cost_kind": "per rule (old model, before it retires)", "usd_per_swap_day": NAN,
                   "note": "the OWNER's home results on the calibration pool, collected before the old model retires; the "
                           "reader's checks are counted where the test is run (msr.sequential, theory worker)"})
    by_arm.append({"arm": "pre-swap forecast", "reader_calls_per_swap_day": NAN, "tokens_in_per_call": tin,
                   "tokens_out_per_call": tout, "owner_calls_before_swap": NAN, "uses_level_information": False,
                   "cost_kind": "per swap (before the swap)", "usd_per_swap_day": NAN,
                   "note": "no-memory runs of both models on the write, score and calibration tasks; counted by msr.forecast "
                           "(theory worker); see construct_costs.csv for the sizes"})
    return by_model, by_arm


# ===========================================================================
# Secondary tables from the per-task files: top-k, tau-b and ties, concordance variants,
# mix weights, second bank
# ===========================================================================


def topk_tables(E: Engine, design: Design) -> tuple:
    """Top-1 and top-2 agreement (2.9) with intervals, beside their chance values: the owner's top
    candidate(s) against the reader's best; per pair and per swap stratum, every family."""
    rows, grows = [], []
    for fam in design.score_families:
        for kk in (1, 2):
            names = {q: f"{fam}|top{kk}_{q}" for q in ("home", "swap", "home_chance", "swap_chance")}
            if not all(E.has(k) for k in names.values()):
                continue
            ests = E.get(list(names.values()), cache=False)
            hit_s, ch_s = ests[names["swap"]], ests[names["swap_chance"]]
            hit_h, ch_h = ests[names["home"]], ests[names["home_chance"]]
            pend = Pending()
            for cell in design.swaps("home") + design.swaps("all_swaps"):
                o, r = cell
                for level in E.levels:
                    p, d = E.at(hit_s, cell, level)
                    if not fin(p):
                        continue
                    row = {"family": fam, "k": kk, "owner": o, "reader": r, "group": design.group(o, r), "level": level}
                    pend.add(row, "agreement_after", p, d)
                    pend.add(row, "chance_after", *E.at(ch_s, cell, level))
                    pend.add(row, "after_minus_chance", *E.combo([hit_s, ch_s], [(cell, level)]))
                    pend.add(row, "agreement_home", *E.at(hit_h, (o, o), level))
                    pend.add(row, "chance_home", *E.at(ch_h, (o, o), level))
                    rows.append(row)
            for g in DESC_GROUPS:
                cells = design.swaps(g)
                if not cells:
                    continue
                for level in E.levels:
                    its = E.items(cells, level)
                    p, d = E.avg(hit_s, its)
                    if not fin(p):
                        continue
                    row = {"family": fam, "k": kk, "group": g, "level": level, "n_swaps": len(cells)}
                    pend.add(row, "agreement_after", p, d)
                    pend.add(row, "chance_after", *E.avg(ch_s, its))
                    pend.add(row, "after_minus_chance", *E.combo([hit_s, ch_s], its))
                    pend.add(row, "agreement_home", *E.avg(hit_h, [((c[0], c[0]), b) for c, b in its]))
                    grows.append(row)
            pend.flush()
    return rows, grows


def _tau_fn(x):
    nc_, nd_, tx, ty = x[..., 0, :], x[..., 1, :], x[..., 2, :], x[..., 3, :]
    den = np.sqrt((nc_ + nd_ + tx) * (nc_ + nd_ + ty))
    return np.where(den > 0, (nc_ - nd_) / np.where(den > 0, den, 1.0), np.nan)


def tau_tie_tables(E: Engine, design: Design) -> tuple:
    """Kendall's tau-b (8.2.7, via Newson 2002: pairs within tasks pooled over tasks) and the share
    of informative pairs tied in the score, at home, after the swap and for the self-swap."""
    rows, grows = [], []
    for fam in design.score_families:
        if not E.has(f"{fam}|tau_home#0"):
            continue
        tau = {q: E.derived(_tau_fn, E.part_sums(f"{fam}|tau_{q}", 4)) for q in ("home", "swap", "floor")}
        ties = {q: E.one(f"{fam}|ties_{q}", ratio=True, cache=False) for q in ("home", "swap", "floor")
                if E.has(f"{fam}|ties_{q}")}
        pend = Pending()

        def fill(row, its_home, its_swap, its_floor):
            for name, est, its in (("tau_b_home", tau["home"], its_home), ("tau_b_after", tau["swap"], its_swap),
                                   ("tau_b_self", tau["floor"], its_floor)):
                pend.add(row, name, *E.avg(est, its))
            ph, dh = E.avg(tau["home"], its_home)
            ps, ds = E.avg(tau["swap"], its_swap)
            pend.add(row, "tau_b_drop", ph - ps, dh - ds)
            for name, q, its in (("tie_share_home", "home", its_home), ("tie_share_after", "swap", its_swap)):
                if q in ties:
                    pend.add(row, name, *E.avg(ties[q], its))

        for cell in design.swaps("home") + design.swaps("all_swaps"):
            o, r = cell
            for level in E.levels:
                bs = E.streams if level == "all" else [level]
                if not fin(E.at(tau["swap"], cell, level)[0]):
                    continue
                row = {"family": fam, "owner": o, "reader": r, "group": design.group(o, r), "level": level}
                fill(row, [((o, o), b) for b in bs], [(cell, b) for b in bs], [((o, o), b) for b in bs])
                rows.append(row)
        for g in GROUPS + ("all_swaps", "home"):
            cells = design.swaps(g)
            if not cells:
                continue
            for level in E.levels:
                its = E.items(cells, level)
                row = {"family": fam, "group": g, "level": level, "n_swaps": len(cells)}
                fill(row, [((c[0], c[0]), b) for c, b in its], its, [((c[0], c[0]), b) for c, b in its])
                grows.append(row)
        pend.flush()
    return rows, grows


VARIANTS = (("_u", "unweighted C (8.2.7)"), ("_noties", "pairs not tied in the score (8.2.7)"),
            ("_visits_low", "pairs whose less-visited item is in the lowest third of visits (8.2.7)"),
            ("_visits_mid", "... middle third of visits (8.2.7)"), ("_visits_high", "... highest third of visits (8.2.7)"),
            ("_bank2", "second independent bank's scores (8.3.4)"),
            ("_net", "counters ranked by helpful - harmful (8.2.14)"),
            ("_shuffled", "content-only control: scores permuted over the bank (2.6)"))


def add_alias(E: Engine, src_fam: str, suffix: str) -> str | None:
    """Make the keys <fam><suffix>|conc_<q> point at <fam>|conc_<q><suffix> (no copy), so the
    validity functions run unchanged on a concordance variant."""
    new = f"{src_fam}{suffix}"
    found = False
    for s in E.data.strata:
        m = E.data.mats[s]
        for q in ("home", "swap", "floor"):
            for part in ("#num", "#den"):
                k = f"{src_fam}|conc_{q}{suffix}{part}"
                if k in m:
                    m[f"{new}|conc_{q}{part}"] = m[k]
                    found = found or q in ("home", "swap")
    if not found:
        return None
    if not any(f"{new}|conc_floor#num" in E.data.mats[s] for s in E.data.strata):
        for s in E.data.strata:                  # no self-swap version: the floor is not defined
            n, nc = len(E.data.tasks[s]), len(E.data.cells)
            for part in ("#num", "#den"):
                E.data.mats[s][f"{new}|conc_floor{part}"] = np.full((n, nc), np.nan, np.float32)
    E.add_keys()
    return new


def variant_validity(E: Engine, design: Design) -> tuple:
    rows, grows = [], []
    for fam in design.score_families:
        for suffix, label in VARIANTS:
            name = add_alias(E, fam, suffix)
            if name is None:
                continue
            pr = pair_validity(E, design, name)
            gr = group_validity(E, design, name)
            for r in pr + gr:
                r["family"] = fam
                r["variant"] = suffix.lstrip("_")
                r["variant_meaning"] = label
            rows += pr
            grows += gr
            E.forget(f"{name}|")
    return rows, grows


def mix_weight_tables(E: Engine, design: Design) -> tuple:
    """8.3.1 (exploratory): first-shown success with the score weight 0.25 and 0.75 and with the
    z-scored mix, from the per-task values, with intervals; keep - wipe under each mix."""
    lam = f"fixed_{design.primary_lambda:g}"
    K = design.primary_k
    arms = ["keep", "wipe", lam, "shuffled", "own"] + ([f"recal_{K}"] if K else [])
    variants = (("value", f"score weight {design.w_score:g} (primary)"), ("value_w0.25", "score weight 0.25"),
                ("value_w0.75", "score weight 0.75"), ("value_wz", "z-scored mix (MemRL)"))
    rows, prow = [], []
    for fam in design.score_families:
        for metric, label in variants:
            if not E.has(f"{fam}|keep|{metric}"):
                continue
            ests = {a: E.one(f"{fam}|{a}|{metric}", cache=False) for a in arms if E.has(f"{fam}|{a}|{metric}")}
            pend = Pending()
            for g in GROUPS + ("all_swaps", "home"):
                cells = design.swaps(g)
                if not cells:
                    continue
                its = E.items(cells, "all")
                for a, est in ests.items():
                    row = {"family": fam, "mix": metric, "mix_meaning": label, "arm": a, "group": g, "level": "all"}
                    pend.add(row, "", *E.avg(est, its))
                    if a != "keep" and "keep" in ests:
                        pend.add(row, "minus_keep", *E.combo([est, ests["keep"]], its), with_p=True)
                    if a == "keep" and "wipe" in ests:
                        pend.add(row, "keep_minus_wipe", *E.combo([est, ests["wipe"]], its), with_p=True)
                    rows.append(row)
            if fam == design.headline:
                for cell in design.swaps("all_swaps"):
                    for a in ("keep", "wipe"):
                        if a in ests:
                            row = {"family": fam, "mix": metric, "arm": a, "owner": cell[0], "reader": cell[1],
                                   "group": design.group(*cell), "level": "all"}
                            pend.add(row, "", *E.at(ests[a], cell, "all"))
                            prow.append(row)
            pend.flush()
    return rows, prow


def second_bank_drop(E: Engine, design: Design) -> list:
    """8.3.4: for the owners with a second bank, the drop D under each bank and their difference."""
    rows = []
    for fam in design.score_families:
        if not E.has(f"{fam}|conc_home_bank2"):
            continue
        Ch, Cs = E.one(f"{fam}|conc_home", ratio=True), E.one(f"{fam}|conc_swap", ratio=True)
        Ch2 = E.one(f"{fam}|conc_home_bank2", ratio=True, cache=False)
        Cs2 = E.one(f"{fam}|conc_swap_bank2", ratio=True, cache=False)
        pend = Pending()
        for cell in design.swaps("all_swaps"):
            o, r = cell
            for level in E.levels:
                h2 = E.at(Ch2, (o, o), level)
                s2 = E.at(Cs2, cell, level)
                if not (fin(h2[0]) and fin(s2[0])):
                    continue
                h1, s1 = E.at(Ch, (o, o), level), E.at(Cs, cell, level)
                row = {"family": fam, "owner": o, "reader": r, "group": design.group(o, r), "level": level}
                pend.add(row, "C_home_bank1", *h1)
                pend.add(row, "C_home_bank2", *h2)
                pend.add(row, "D_bank1", h1[0] - s1[0], h1[1] - s1[1])
                pend.add(row, "D_bank2", h2[0] - s2[0], h2[1] - s2[1])
                pend.add(row, "D_bank2_minus_bank1", (h2[0] - s2[0]) - (h1[0] - s1[0]), (h2[1] - s2[1]) - (h1[1] - s1[1]))
                rows.append(row)
        pend.flush()
    return rows


# ===========================================================================
# Raw cells (results/cells/*.npz): split-half references, IPS scores, pigeonhole
# bootstrap and the model-based ceiling
# ===========================================================================


def cw_parts(x: np.ndarray, yo: np.ndarray, present: np.ndarray, pairs: bool = False):
    """Per-task numerator and weight of the weighted concordance Cw (Part 2.2) of score x
    against outcome yo, over the candidates marked present: weight |yo_i - yo_j|; 1 if the
    higher score did better, 1/2 if the scores tie (within 1e-12), 0 otherwise. With
    pairs=True it also returns the informative pairs (task, i, j, numerator, weight)."""
    T, C = x.shape
    num, den = np.zeros(T), np.zeros(T)
    plist = []
    for i in range(C):
        for j in range(i + 1, C):
            ok = present[:, i] & present[:, j] & np.isfinite(yo[:, i]) & np.isfinite(yo[:, j])
            w = np.where(ok, np.abs(yo[:, i] - yo[:, j]), 0.0)
            dx = x[:, i] - x[:, j]
            dy = yo[:, i] - yo[:, j]
            with np.errstate(invalid="ignore"):
                kap = np.where(np.abs(dx) <= 1e-12, 0.5, np.where(dx * dy > 0, 1.0, 0.0))
            num += w * kap
            den += w
            if pairs:
                t = np.flatnonzero(w > 0)
                plist.append((t, np.full(len(t), i), np.full(len(t), j), (w * kap)[t], w[t]))
    if not pairs:
        return num, den
    cat = [np.concatenate([p[q] for p in plist]) if plist else np.zeros(0) for q in range(5)]
    return num, den, cat


def load_raw_cells(design: Design, results: Path, data: PerTask) -> dict:
    """{(owner, reader, stream, seed): arrays} of results/cells/, restricted to the evaluation
    tasks and aligned with the per-task files; tasks dropped by the missing-cell rule (1.6,
    `valid`) are marked invalid."""
    d = results / "cells"
    if not d.exists():
        return {}
    out = {}
    ci = {c: j for j, c in enumerate(data.cells)}
    for (o, r) in data.cells:
        for s in data.strata:
            p = d / f"{o}__{r}__{s[0]}__seed{s[1]}.npz"
            if not p.exists():
                continue
            with np.load(p, allow_pickle=False) as z:
                raw = {k: z[k] for k in z.files}
            pos = {t: j for j, t in enumerate(data.tasks[s])}
            calib = raw.get("is_calib", np.zeros(len(raw["tasks"]), bool))
            src, dst = [], []
            for j, t in enumerate(raw["tasks"]):
                t = str(t)
                if t in pos and not bool(calib[j]):
                    src.append(j)
                    dst.append(pos[t])
            n = len(data.tasks[s])
            cell = {}
            for k, a in raw.items():
                if k in ("tasks", "is_calib") or a.ndim == 0 or a.shape[0] != len(raw["tasks"]):
                    continue
                if a.dtype.kind in "US":
                    b = np.full((n,) + a.shape[1:], "", dtype=a.dtype)
                elif a.dtype.kind in "iu":
                    b = np.full((n,) + a.shape[1:], -1, dtype=a.dtype)
                elif a.dtype.kind == "b":
                    b = np.zeros((n,) + a.shape[1:], dtype=bool)
                else:
                    b = np.full((n,) + a.shape[1:], np.nan)
                b[dst] = a[src]
                cell[k] = b
            vm = data.mats[s].get("valid")
            valid = np.zeros(n, bool)
            valid[dst] = True
            if vm is not None:
                valid &= np.nan_to_num(vm[:, ci[(o, r)]].astype(float)) > 0
            cell["valid"] = valid
            cell["present"] = (cell["items"] != "") if "items" in cell else np.ones((n, 1), bool)
            out[(o, r, s[0], s[1])] = cell
    return out


def _put(data: PerTask, s, j: int, key: str, num: np.ndarray, den: np.ndarray, valid: np.ndarray) -> None:
    n, nc = len(data.tasks[s]), len(data.cells)
    for suffix, v in (("#num", num), ("#den", den)):
        mm = data.mats[s].setdefault(key + suffix, np.full((n, nc), np.nan, dtype=np.float32))
        mm[:, j] = np.where(valid, v, np.nan)


def _ymean(a: np.ndarray) -> np.ndarray:
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        return np.nanmean(a, axis=-1)


def inject_raw_keys(design: Design, data: PerTask, raw: dict) -> list:
    """Per-task keys computed from the raw cells, for the joint bootstrap:
    -|sh_ab, -|sh_ba      split-half reference, repeat 1 as score vs repeat 2 as outcome and back (2.5)
    -|sh2_ab, -|sh2_ba    home cells: repeats 1-2 vs repeats 3-4
    ips|conc_home/_swap/_floor   Cw with the self-normalised IPS score (8.3.5); never-shown items 0.5
    Returns the names of the families / keys added."""
    added = set()
    ci = {c: j for j, c in enumerate(data.cells)}
    for (o, r, b, sd), R in raw.items():
        s = (b, sd)
        j = ci[(o, r)]
        v, pres = R["valid"], R["present"]
        y = R.get("y")
        if y is not None and y.ndim == 3 and y.shape[2] >= 2:
            A, Bv = y[..., 0], y[..., 1]
            both = pres & np.isfinite(A) & np.isfinite(Bv)
            for key, (sc, ou) in (("-|sh_ab", (A, Bv)), ("-|sh_ba", (Bv, A))):
                _put(data, s, j, key, *cw_parts(sc, ou, both), v)
                added.add(key)
            if o == r and R.get("y_extra") is not None:
                A2, B2 = _ymean(y), _ymean(R["y_extra"])
                both2 = pres & np.isfinite(A2) & np.isfinite(B2)
                for key, (sc, ou) in (("-|sh2_ab", (A2, B2)), ("-|sh2_ba", (B2, A2))):
                    _put(data, s, j, key, *cw_parts(sc, ou, both2), v)
                    added.add(key)
        if "ips_num" in R and "ips_den" in R:
            with np.errstate(invalid="ignore", divide="ignore"):
                x = np.where(R["ips_den"] > 0, R["ips_num"] / R["ips_den"], 0.5)
            x = np.where(np.isfinite(x), x, 0.5)
            yh = _ymean(R["y_home"]) if "y_home" in R else _ymean(y)
            _put(data, s, j, "ips|conc_home", *cw_parts(x, yh, pres), v)
            if o == r:
                if R.get("y_extra") is not None:
                    ye = _ymean(R["y_extra"])
                    _put(data, s, j, "ips|conc_floor", *cw_parts(x, ye, pres), v)
                    _put(data, s, j, "ips|conc_swap", *cw_parts(x, ye, pres), v)
            else:
                _put(data, s, j, "ips|conc_swap", *cw_parts(x, _ymean(y), pres), v)
            added.add("ips")
    return sorted(added)


def _combine(fn, *ests) -> dict:
    """An estimate dict of fn(e1, e2, ...) applied to the points and to the draws."""
    out = {}
    for b in ests[0]:
        with np.errstate(invalid="ignore", divide="ignore"):
            p = fn(*[e[b][0] for e in ests])
            d = np.ascontiguousarray(fn(*[e[b][1] for e in ests]))
        out[b] = (p, d, np.isnan(d).any(axis=0))
    return out


def split_half_est(E: Engine, which: str = "sh") -> dict | None:
    """C_SH = (Cw(A -> B) + Cw(B -> A)) / 2 per cell, pooled over the orders of each stream."""
    ka, kb = f"-|{which}_ab", f"-|{which}_ba"
    if not (E.has(ka) and E.has(kb)):
        return None
    return _combine(lambda a, b: 0.5 * (a + b), E.one(ka, ratio=True), E.one(kb, ratio=True))


def ref_passes(design: Design, ref: tuple) -> bool:
    """A noise reference is usable when it exceeds 0.5 by at least 4 bootstrap SE (as R's rule)."""
    p, d = ref
    d = d[np.isfinite(d)]
    if not fin(p) or d.size < 2:
        return False
    se = float(d.std(ddof=1))
    return bool(p - 0.5 > 0 and p - 0.5 >= design.ratio_min_z * se)


def radj_report(design: Design, r_status: str, items: list) -> dict:
    """Noise-adjusted retained validity R_adj = [mean (C_swap - .5)/(ref_reader - .5)] /
    [mean (C_home - .5)/(ref_owner - .5)] over the items (one item for a pair): reported only
    where R is reported and every noise reference passes its 4-SE rule."""
    if not items:
        return {"R_adj": NAN, "R_adj_lo": NAN, "R_adj_hi": NAN, "R_adj_status": "undefined: no noise reference"}
    if r_status != "reported":
        return {"R_adj": NAN, "R_adj_lo": NAN, "R_adj_hi": NAN, "R_adj_status": "undefined: R undefined"}
    if not all(ref_passes(design, it["ro"]) and ref_passes(design, it["rr"]) for it in items):
        return {"R_adj": NAN, "R_adj_lo": NAN, "R_adj_hi": NAN,
                "R_adj_status": "undefined: noise reference under 4 SE"}
    with np.errstate(invalid="ignore", divide="ignore"):
        ns_p = np.mean([(it["sw"][0] - 0.5) / (it["rr"][0] - 0.5) for it in items])
        nh_p = np.mean([(it["h"][0] - 0.5) / (it["ro"][0] - 0.5) for it in items])
        ns_d = np.mean([(it["sw"][1] - 0.5) / (it["rr"][1] - 0.5) for it in items], axis=0)
        nh_d = np.mean([(it["h"][1] - 0.5) / (it["ro"][1] - 0.5) for it in items], axis=0)
        bad = np.mean(np.any([(it["rr"][1] - 0.5 <= 0) | (it["h"][1] - 0.5 <= 0) | (it["ro"][1] - 0.5 <= 0)
                              for it in items], axis=0))
        val = ns_p / nh_p
        dr = ns_d / nh_d
    dr = dr[np.isfinite(dr)]
    if bad > design.unbounded_share or dr.size == 0:
        return {"R_adj": val, "R_adj_lo": -math.inf, "R_adj_hi": math.inf, "R_adj_status": "reported; interval unbounded"}
    lo, hi = np.percentile(dr, [2.5, 97.5])
    return {"R_adj": val, "R_adj_lo": float(lo), "R_adj_hi": float(hi), "R_adj_status": "reported"}


def noise_tables(E: Engine, design: Design, mc: dict) -> tuple:
    """Split-half noise references with intervals (2.5, 8.2.8), the noise-normalised Cw, and the
    model-based ceiling beside them."""
    sh = split_half_est(E, "sh")
    sh2 = split_half_est(E, "sh2")
    H = design.headline
    if sh is None:
        return [], []
    Ch = E.one(f"{H}|conc_home", ratio=True)
    Cs = E.one(f"{H}|conc_swap", ratio=True)
    rows, grows = [], []
    pend = Pending()
    for cell in design.swaps("home") + design.swaps("all_swaps"):
        o, r = cell
        for level in E.levels:
            ref = E.at(sh, cell, level)
            if not fin(ref[0]):
                continue
            row = {"owner": o, "reader": r, "group": design.group(o, r), "level": level, "family": H}
            pend.add(row, "split_half", *ref)
            row["split_half_passes_4se"] = ref_passes(design, ref)
            if o == r and sh2 is not None:
                pend.add(row, "split_half_extra", *E.at(sh2, cell, level))
            c = E.at(Ch, cell, level) if o == r else E.at(Cs, cell, level)
            with np.errstate(invalid="ignore", divide="ignore"):
                pend.add(row, "C_noise_normalised", (c[0] - 0.5) / (ref[0] - 0.5), (c[1] - 0.5) / (ref[1] - 0.5))
            m = mc.get((o, r, level))
            if m:
                row["model_ceiling"] = m["model_ceiling"]
            rows.append(row)
    for g in DESC_GROUPS:
        cells = design.swaps(g)
        if not cells:
            continue
        for level in E.levels:
            p, d = E.avg(sh, E.items(cells, level))
            if fin(p):
                row = {"group": g, "level": level, "n_cells": len(cells)}
                pend.add(row, "split_half", p, d)
                grows.append(row)
    pend.flush()
    return rows, grows


def _logit_re_fit(k: np.ndarray, n: np.ndarray, q: int = 12) -> dict:
    """Maximum likelihood of logit p = mu + a_task + b_item(task), a ~ N(0, sa^2), b ~ N(0, sb^2),
    binomial results per (task, item); Gauss-Hermite quadrature over a and b. k, n: (T, C)."""
    from numpy.polynomial.hermite_e import hermegauss
    from scipy.optimize import minimize
    from scipy.special import expit, gammaln
    xa, wa = hermegauss(q)
    wa = wa / wa.sum()
    ok = n > 0
    pats, inv = np.unique(np.stack([k[ok], n[ok]], axis=1), axis=0, return_inverse=True)
    inv = inv.reshape(-1)
    task_of = np.nonzero(ok)[0]
    T = k.shape[0]
    logc = gammaln(pats[:, 1] + 1) - gammaln(pats[:, 0] + 1) - gammaln(pats[:, 1] - pats[:, 0] + 1)

    def nll(theta):
        mu, la, lb = theta
        sa, sb = math.exp(la), math.exp(lb)
        eta = mu + sa * xa[:, None] + sb * xa[None, :]                   # (Qa, Qb)
        pr = np.clip(expit(eta), 1e-12, 1 - 1e-12)
        lp, lq = np.log(pr), np.log1p(-pr)
        ll = pats[:, 0][:, None, None] * lp + (pats[:, 1] - pats[:, 0])[:, None, None] * lq + logc[:, None, None]
        lb_ = np.log((np.exp(ll) * wa[None, None, :]).sum(-1))           # (P, Qa): b integrated out
        per_task = np.zeros((T, len(xa)))
        np.add.at(per_task, task_of, lb_[inv])
        m = per_task.max(axis=1, keepdims=True)
        return -float(np.sum(m[:, 0] + np.log((np.exp(per_task - m) * wa).sum(axis=1))))

    p0 = float(np.clip(k[ok].sum() / max(n[ok].sum(), 1), 0.02, 0.98))
    res = minimize(nll, x0=[math.log(p0 / (1 - p0)), math.log(0.8), math.log(0.8)], method="L-BFGS-B",
                   bounds=[(-8, 8), (math.log(1e-3), math.log(8)), (math.log(1e-3), math.log(8))])
    mu, la, lb = res.x
    return {"mu": float(mu), "sigma_task": math.exp(la), "sigma_item": math.exp(lb), "converged": bool(res.success)}


def _sim_ceiling(fit: dict, n_cand: int, reps: int, seed: int, n_tasks: int = 20000) -> float:
    """Cw a score equal to the TRUE success probability would reach, outcomes being the mean of
    `reps` results (the fitted model's world)."""
    from scipy.special import expit
    rng = np.random.default_rng(seed)
    a = rng.normal(0.0, fit["sigma_task"], n_tasks)
    b = rng.normal(0.0, fit["sigma_item"], (n_tasks, n_cand))
    p = expit(fit["mu"] + a[:, None] + b)
    y = rng.binomial(reps, p) / reps
    num, den = cw_parts(p, y, np.ones_like(p, dtype=bool))
    return float(num.sum() / den.sum()) if den.sum() else NAN


def model_ceiling(design: Design, raw: dict, seed: int) -> tuple:
    """8.2.8: a logistic model with task and item-in-task random effects fitted to the probe
    results of every cell (pooled over the orders of a stream), then the concordance of the true
    probabilities simulated under it. Reported as model-based; no interval."""
    rows, look = [], {}
    by: dict = defaultdict(list)
    for (o, r, b, sd), R in raw.items():
        if R.get("y") is None:
            continue
        by[(o, r, b)].append(R)
    for (o, r, b), Rs in sorted(by.items(), key=lambda kv: (design.swaps("home") + design.swaps("all_swaps")).index(
            (kv[0][0], kv[0][1])) if (kv[0][0], kv[0][1]) in design.cells else 999):
        ks, ns = [], []
        for R in Rs:
            y = np.where(R["present"][..., None] & R["valid"][:, None, None], R["y"], np.nan)
            ks.append(np.nansum(y, axis=2))
            ns.append(np.isfinite(y).sum(axis=2))
        k, n = np.vstack(ks), np.vstack(ns).astype(float)
        if n.sum() == 0:
            continue
        fit = _logit_re_fit(k, n)
        reps = int(Rs[0]["y"].shape[2])
        n_cand = int(Rs[0]["y"].shape[1])
        h = int.from_bytes(__import__("hashlib").sha256(f"ceiling|{o}|{r}|{b}".encode()).digest()[:4], "big")
        cw = _sim_ceiling(fit, n_cand, reps, seed=int(seed) * 1000003 + h)
        row = {"owner": o, "reader": r, "group": design.group(o, r), "level": b, **fit, "model_ceiling": cw,
               "tasks": int((n.sum(axis=1) > 0).sum()), "repeats": reps}
        rows.append(row)
        look[(o, r, b)] = row
    agg: dict = defaultdict(list)
    for r in rows:
        agg[(r["owner"], r["reader"])].append(r)
    for (o, r), rs in agg.items():
        row = {"owner": o, "reader": r, "group": design.group(o, r), "level": "all",
               "model_ceiling": float(np.mean([x["model_ceiling"] for x in rs]))}
        rows.append(row)
        look[(o, r, "all")] = row
    return rows, look


def pigeonhole_pc1(E: Engine, design: Design, raw: dict, n_boot: int, seed: int) -> list:
    """Owen's pigeonhole bootstrap for PC1 (4.6): tasks AND items resampled independently within
    each task stratum (tasks with the same draws as the main bootstrap; each owner's bank items
    with their own draws), a pair of candidates weighted by its task's count times both items'
    counts. Headline family; the drop D of each swap stratum."""
    H = design.headline
    key = f"score_{H}"
    if not raw or not any(key in R for R in raw.values()):
        return []
    B = E.B
    # item universe and draws per (stratum, owner)
    item_ix: dict = {}
    item_draws: dict = {}
    for (o, r, b, sd), R in raw.items():
        u = item_ix.setdefault(((b, sd), o), {})
        for it in R["items"][R["present"]]:
            u.setdefault(str(it), len(u))
    for (s, o), u in item_ix.items():
        h = int.from_bytes(__import__("hashlib").sha256(f"pigeon|{s[0]}|{s[1]}|{o}".encode()).digest()[:8], "big")
        rng = np.random.default_rng([int(seed), h])
        n_u = max(1, len(u))
        idx = rng.integers(0, n_u, size=(B, n_u))
        off = idx.astype(np.int64) + np.arange(B, dtype=np.int64)[:, None] * n_u
        item_draws[(s, o)] = np.bincount(off.ravel(), minlength=B * n_u).reshape(B, n_u).astype(float)

    def c_draws(o, r, which):
        """{stream: (point, draws)} of Cw of cell (o, r): which = home (owner's results),
        swap (the reader's; the extra repeats for a home cell)."""
        out = {}
        for b in E.streams:
            nump = denp = 0.0
            numb, denb = np.zeros(B), np.zeros(B)
            for sd in design.seeds:
                R = raw.get((o, r, b, sd))
                if R is None or key not in R:
                    continue
                s = (b, sd)
                if which == "home":
                    yo = _ymean(R["y_home"]) if "y_home" in R else _ymean(R["y"])
                elif o == r:
                    if R.get("y_extra") is None:
                        continue
                    yo = _ymean(R["y_extra"])
                else:
                    yo = _ymean(R["y"])
                pres = R["present"] & R["valid"][:, None]
                _, _, (t, i, j, nm, dn) = cw_parts(R[key], yo, pres, pairs=True)
                if not len(t):
                    continue
                u = item_ix[(s, o)]
                ii = np.array([u[str(R["items"][a, c])] for a, c in zip(t, i)])
                jj = np.array([u[str(R["items"][a, c])] for a, c in zip(t, j)])
                W = E.boot.counts[s]
                Mi = item_draws[(s, o)]
                nump += float(nm.sum())
                denp += float(dn.sum())
                for st_ in range(0, B, 1000):
                    sl = slice(st_, min(B, st_ + 1000))
                    G = W[sl][:, t] * Mi[sl][:, ii] * Mi[sl][:, jj]
                    numb[sl] += G @ nm
                    denb[sl] += G @ dn
            if denp > 0:
                with np.errstate(invalid="ignore", divide="ignore"):
                    out[b] = (nump / denp, numb / denb)
        return out

    rows = []
    for g in GROUPS:
        cells = design.swaps(g)
        if not cells:
            continue
        hp, hd, sp, sdr = [], [], [], []
        for (o, r) in cells:
            ch = c_draws(o, o, "home")
            cs = c_draws(o, r, "swap")
            for b in E.streams:
                if b in ch and b in cs:
                    hp.append(ch[b][0]); hd.append(ch[b][1]); sp.append(cs[b][0]); sdr.append(cs[b][1])
        if not hp:
            continue
        d_p = float(np.mean(hp) - np.mean(sp))
        d_d = np.mean(hd, axis=0) - np.mean(sdr, axis=0)
        sm = summarize(d_p, d_d)
        rows.append({"test": f"PC1-{g}", "check": "pigeonhole bootstrap (tasks and items, Owen 2007)",
                     "est": sm["est"], "lo": sm["lo"], "hi": sm["hi"], "se": sm["se"], "p": sm["p_upper"],
                     "note": "p_upper of the drop; items resampled per owner bank within each (stream, order)"})
    return rows


# ===========================================================================
# Round-1 revision (23 Nov 2026): theta headline, two-way inference, swap-minus-home contrasts, stakes
# ===========================================================================
#
# Everyday picture: the garage asks three questions after the new helper starts. (1) How much of the
# old scores' pointing power is left for the new helper (theta, the retained ranking signal)? (2) Is
# that a real loss, or is no material loss shown? (3) What does the order of the scores buy in jobs
# solved? Every interval below treats both the jobs (tasks) and the tips (items) as drawn at random:
# two jobs are related if they are the same job (the three stream orders share one task pool) or if
# their candidate tips overlap (msr.metrics.cluster_variance).

#: The primary family of revision 2 (Part 5.1): four hypotheses in each swap group, 12 members, plain
#: Holm. Every PC1 member is an intersection-union test with the home-sign test (msr.metrics.theta_tests).
PRIMARY_HYPOTHESES = ("PC1-drop", "PC1-MD", "PC1-NI", "PC2")
#: PC3 and PC4 left the family in revision 2 (R6 W7): secondary, with their additivity assumption, the
#: owner-reader base-rate gap and the with-item level-target sensitivity beside them
SECONDARY_HYPOTHESES = ("PC3", "PC4")
#: the estimand of the swap-minus-home contrasts and the assumption it needs (R6 W7; Part 5.1)
ADDITIVITY = ("the swap-minus-home contrast is a swap effect only if a rule's gain over keep is additive in its home "
              "gain and the swap effect; a base-rate difference between owner and reader alone moves it by about "
              "-0.013 to +0.012 nats per check (R6 C8), so it is read beside the base-rate gap and the with-item "
              "level-target sensitivity")
HYP_LABEL = {"PC1-drop": "the old scores rank worse after the swap (theta < 1), the home signal positive and the "
                         "loss beyond the owner's second home session",
             "PC1-MD": "material drop (theta < 0.75), the home signal positive",
             "PC1-NI": "no material drop (theta > 0.75), the home signal positive",
             "PC2": "keep differs from wipe on first-shown success",
             "PC3": "a fixed discount (lambda = 0.5) predicts the reader better than keep, beyond home "
                    "(swap-minus-home, level-corrected log score)",
             "PC4": "a calibrated discount (recal_k) predicts better than both keep and wipe, beyond home "
                    "(swap-minus-home, level-corrected log score)"}


def inject_theta_keys(design: Design, data: PerTask) -> list:
    """Per-task signed validity V (msr.metrics: V = 2 x numerator - weight of Cw) for every family
    and cell, as plain per-task keys '<family>|V_home' (owner's results) and '<family>|V_swap'
    (reader's results; for a home cell the extra repeats 3-4); NaN on tasks dropped by rule 1.6."""
    added = set()
    for s in data.strata:
        mats = data.mats[s]
        for key in list(mats):
            m = re.match(r"^(.+)\|conc_(home|swap)#num$", key)
            if not m:
                continue
            fam, which = m.group(1), m.group(2)
            den = mats.get(f"{fam}|conc_{which}#den")
            if den is None:
                continue
            num = mats[key].astype(np.float64)
            dd = den.astype(np.float64)
            v = np.where(np.isfinite(dd) & np.isfinite(num), 2.0 * num - dd, np.nan)
            mats[f"{fam}|V_{which}"] = v
            added.add(fam)
    return sorted(added)


#: the flag when the result files carry no calibration tasks (synthetic inputs); decisions then fall
#: back to the same-task status, and the report says so
NO_CAL_FLAG = "not available: no calibration tasks in these result files"


def flag_ok(row: dict) -> bool:
    """theta's headline flag (calibration tasks); the same-task status only where no calibration
    tasks exist (synthetic inputs)."""
    st = row.get("theta_status_calibration", "")
    if not st or st == NO_CAL_FLAG:
        return row.get("theta_status") == "defined"
    return st == "defined"


def calibration_signal(design: Design, results: Path | None) -> dict:
    """{(family, owner, stream, order): per-task V on the owner's CALIBRATION tasks} (its repeats
    1-2, its own scores), from results/cells/<owner>__<owner>__...npz: the input of the headline
    reporting flag (msr.metrics.calibration_z, theta_status_calibration; Part 2.4 as revised)."""
    out: dict = {}
    if results is None or not (Path(results) / "cells").exists():
        return out
    for o in design.models:
        for b in design.streams:
            for sd in design.seeds:
                p = Path(results) / "cells" / f"{o}__{o}__{b}__seed{sd}.npz"
                if not p.exists():
                    continue
                with np.load(p, allow_pickle=False) as z:
                    if "is_calib" not in z.files or "y_home" not in z.files:
                        continue
                    cal = z["is_calib"].astype(bool)
                    if not cal.any():
                        continue
                    items = z["items"][cal].astype(str)
                    yb = _ymean(z["y_home"][cal].astype(float))
                    for k in z.files:
                        if k.startswith("score_") and not k.endswith(("_bank2", "_net")):
                            fam = k[len("score_"):]
                            v, _ = M.signed_validity_parts(z[k][cal].astype(float), yb, items != "")
                            out[(fam, o, b, sd)] = v
    return out


def inject_spread_keys(design: Design, data: PerTask, raw: dict) -> list:
    """Per-task noise-free spread parts of every cell (msr.metrics.cross_repeat_parts), the inputs of
    retained order and stakes (decision D2; Part 2.4 as revised):
    -|S_owner   the owner's home repeats 1-2 (mean) x its later-session repeats 3-4 (mean), read from the
                owner's home cell and written into every cell of that owner (same tasks per stratum)
    -|S_reader  a swap cell: the reader's repeat 1 x repeat 2; a home cell: the extra repeat 3 x repeat 4
                (the self-swap's reader)
    NaN on tasks dropped by rule 1.6. Returns the keys added."""
    ci = {c: j for j, c in enumerate(data.cells)}
    nc = len(data.cells)
    own = {}
    for (o, r, b, sd), R in raw.items():
        if o == r and R.get("y_extra") is not None and R.get("y_home") is not None:
            own[(o, b, sd)] = M.cross_repeat_parts(R["y_home"], R["y_extra"], R["present"])
    added = set()
    for (o, r, b, sd), R in raw.items():
        s = (b, sd)
        j = ci.get((o, r))
        if j is None:
            continue
        v, n = R["valid"], len(data.tasks[s])
        so = own.get((o, b, sd))
        if so is not None and len(so) == n:
            mm = data.mats[s].setdefault(f"{NO_FAMILY}|S_owner", np.full((n, nc), np.nan))
            mm[:, j] = np.where(v, so, np.nan)
            added.add(f"{NO_FAMILY}|S_owner")
        y = R.get("y_extra") if o == r else R.get("y")
        if y is not None and y.ndim == 3 and y.shape[2] >= 2:
            sr = M.cross_repeat_parts(y[..., 0], y[..., 1], R["present"])
            mm = data.mats[s].setdefault(f"{NO_FAMILY}|S_reader", np.full((n, nc), np.nan))
            mm[:, j] = np.where(v, sr, np.nan)
            added.add(f"{NO_FAMILY}|S_reader")
    return sorted(added)


def reader_spread_calibration(design: Design, results: Path | None) -> dict:
    """{(owner, reader, stream, order): per-task reader spread S on the cell's CALIBRATION tasks} (a swap
    cell: repeat 1 x repeat 2; a home cell: the extra repeat 3 x repeat 4), from results/cells/: the input
    of order's identifiability flag (z >= msr.metrics.ORDER_MIN_Z; no estimate uses these tasks)."""
    out: dict = {}
    if results is None or not (Path(results) / "cells").exists():
        return out
    for o, r in design.cells:
        for b in design.streams:
            for sd in design.seeds:
                p = Path(results) / "cells" / f"{o}__{r}__{b}__seed{sd}.npz"
                if not p.exists():
                    continue
                with np.load(p, allow_pickle=False) as z:
                    if "is_calib" not in z.files or "items" not in z.files:
                        continue
                    cal = z["is_calib"].astype(bool)
                    key = "y_extra" if o == r else "y"
                    if not cal.any() or key not in z.files:
                        continue
                    y = z[key][cal].astype(float)
                    if y.ndim != 3 or y.shape[2] < 2:
                        continue
                    out[(o, r, b, sd)] = M.cross_repeat_parts(y[..., 0], y[..., 1], z["items"][cal].astype(str) != "")
    return out


#: the per-member diagnostics and order/stakes outputs of msr.metrics.theta_tests copied into every theta row
THETA_TEST_KEYS = (("p_home", "p_md", "p_drop_c", "p_md_c", "p_ni_c", "p_self_c", "home_est", "home_se",
                    "drop_c_est", "drop_c_se", "md_c_est", "md_c_se", "ni_c_est", "ni_c_se", "self_c_est",
                    "self_c_se")
                   + tuple(f"{n}_{d}" for n in ("home", "drop_c", "md_c", "ni_c", "self_c")
                           for d in ("item_share", "eff_items", "df_satt"))
                   + ("order", "order_lo", "order_hi", "order_interval", "order_status", "stakes", "stakes_lo",
                      "stakes_hi", "stakes_interval", "s_owner", "s_reader", "z_s_owner", "z_s_reader",
                      "z_s_reader_flag", "identity_gap"))


class TwoWay:
    """The clusters of every (cell, stratum, task) value: the task id within its stream (pooled
    over the orders) and the owner's 4 candidate items of that task, coded by item IDENTITY within
    (owner, stream), so an item that recurs across the stream orders is one cluster (revision 2).
    Built from the raw cells; without them only task clustering is possible (and the output says so).
    The variance is msr.metrics.robust_variance (two-way delete-one-cluster jackknife)."""

    def __init__(self, E: "Engine", design: Design, raw: dict):
        self.E, self.d = E, design
        data = E.data
        tmap: dict = {}
        self.tcode = {s: np.array([tmap.setdefault(f"{s[0]}|{t}", len(tmap)) for t in data.tasks[s]], dtype=np.int64)
                      for s in data.strata}
        imap: dict = {}
        self.icode: dict = {}
        for (o, r, b, sd), R in raw.items():
            key = (o, (b, sd))
            if key in self.icode or "items" not in R:
                continue
            it = np.asarray(R["items"]).astype(str)
            pres = np.asarray(R.get("present", it != ""), dtype=bool)
            codes = np.full(it.shape, -1, dtype=np.int64)
            for (e, c), v in np.ndenumerate(it):
                if pres[e, c] and v:
                    # identity within (owner, stream), the same cluster in every order (revision 2)
                    codes[e, c] = imap.setdefault(f"{o}|{b}|{v}", len(imap))
            self.icode[key] = codes
        self.has_items = bool(self.icode)
        self.n_task_clusters = len(tmap)
        self.n_item_clusters = len(imap)
        self.cal: dict = {}             # calibration_signal(), set by analyse()
        self.rcal: dict = {}            # reader_spread_calibration(), set by analyse()

    @property
    def variance_label(self) -> str:
        return ("two-way jackknife (task id x item)" if self.has_items
                else "task-id jackknife only (no raw cells)")

    def calibration(self, fam: str, items: list) -> float:
        """z of the owners' calibration-task signal for the (cell, stream) items: per owner its
        calibration V of every order of the streams involved, weighted by its number of swaps."""
        per: dict = {}
        for cell, b in items:
            o = cell[0]
            ent = per.setdefault(o, {"cells": set(), "streams": set()})
            ent["cells"].add(cell)
            ent["streams"].add(b)
        vals, wts = [], []
        for o, ent in per.items():
            arr = [self.cal[(fam, o, b, sd)] for b in sorted(ent["streams"]) for sd in self.d.seeds
                   if (fam, o, b, sd) in self.cal]
            if not arr:
                return NAN
            vals.append(np.concatenate(arr))
            wts.append(float(len(ent["cells"])))
        return M.calibration_z(vals, wts) if vals else NAN

    def reader_calibration(self, items: list) -> float | None:
        """z of the readers' spread on the calibration tasks of the (cell, stream) items (order's
        identifiability flag); None when the result files carry no calibration tasks (then the same-task
        z is used and the output says so)."""
        if not self.rcal:
            return None
        per: dict = {}
        for cell, b in items:
            per.setdefault(cell, set()).add(b)
        vals = []
        for (o, r), bs in per.items():
            arr = [self.rcal[(o, r, b, sd)] for b in sorted(bs) for sd in self.d.seeds if (o, r, b, sd) in self.rcal]
            if not arr:
                return NAN
            vals.append(np.concatenate(arr))
        return M.calibration_z(vals, [1.0] * len(vals)) if vals else NAN

    def col(self, key: str, cell: tuple, s) -> np.ndarray | None:
        m = self.E.data.mats[s].get(key)
        j = self.E.ci.get(cell)
        if m is None or j is None:
            return None
        return m[:, j].astype(np.float64)

    def items_of(self, owner: str, s, n: int) -> np.ndarray:
        it = self.icode.get((owner, s))
        if it is None or it.shape[0] != n:
            return np.full((n, 4), -1, dtype=np.int64)
        return it

    def comps_full(self, comps: list) -> tuple:
        """comps() plus the component id of every row (one component = one (key, cell, stream) mean
        pooled over the orders: the leverage term of the jackknife)."""
        point = 0.0
        P, T, I, C = [], [], [], []
        for k, (key, cell, b, coef) in enumerate(comps):
            ss = [s for s in self.E.data.strata if s[0] == b]
            vals = {s: self.col(key, cell, s) for s in ss}
            vals = {s: v for s, v in vals.items() if v is not None}
            n = sum(int(np.isfinite(v).sum()) for v in vals.values())
            if n == 0:
                return NAN, None, None, None, None
            mu = sum(float(np.nansum(v)) for v in vals.values()) / n
            point += coef * mu
            for s, v in vals.items():
                ok = np.isfinite(v)
                P.append(coef * (v[ok] - mu) / n)
                T.append(self.tcode[s][ok])
                I.append(self.items_of(cell[0], s, len(v))[ok])
                C.append(np.full(int(ok.sum()), k, dtype=np.int64))
        if not P:
            return NAN, None, None, None, None
        return point, np.concatenate(P), np.concatenate(T), np.vstack(I), np.concatenate(C)

    def comps(self, comps: list) -> tuple:
        """A linear statistic sum_k coef_k x mean over the valid tasks of stream b_k of key_k in
        cell_k. Returns (point, psi, task codes, item codes) with one row per used (component,
        stratum, task); psi is centred per component (the influence of its mean)."""
        return self.comps_full(comps)[:4]

    def linear(self, comps: list, side: str = "two") -> dict:
        """Point, two-way SE and p (msr.metrics.robust_variance: delete-one-cluster jackknife over task
        ids and items), the task-only SE and p, and the diagnostics item share, effective item clusters
        and Satterthwaite df."""
        pt, psi, t, it, cp = self.comps_full(comps)
        out = {"est": pt, "se": NAN, "lo": NAN, "hi": NAN, "p": NAN, "se_task": NAN, "lo_task": NAN, "hi_task": NAN,
               "p_task": NAN, "item_share": NAN, "eff_items": NAN, "df_satt": NAN, "variance": self.variance_label}
        if psi is None or not fin(pt):
            return out
        rv = M.robust_variance(psi, t, it if self.has_items else None, cp)
        key = {"two": "p_two", "upper": "p_upper", "lower": "p_lower"}[side]
        for tag, v in (("", rv["V"]), ("_task", rv["V_task"])):
            se = math.sqrt(v) if v > 0 else NAN
            out[f"se{tag}"] = se
            out[f"lo{tag}"], out[f"hi{tag}"] = (pt - M.Z95 * se, pt + M.Z95 * se) if fin(se) else (NAN, NAN)
            out[f"p{tag}"] = M.normal_p(pt, se)[key]
        if self.has_items:
            out["item_share_of_variance"] = rv["item_share"]
            out.update(item_share=rv["item_share"], eff_items=rv["eff_items"], df_satt=rv["df_satt"])
        return out

    def theta(self, fam: str, items: list, fresh: bool = True, spread: bool = True) -> dict:
        """theta = sum of mean V_swap / sum of mean V_home over the (cell, stream) items with the
        registered tests of revision 2 (msr.metrics.theta_tests: intersection-union members with the
        home-sign test; drop also beyond the self-swap reference, the owner's later-session repeats;
        Fieller set), retained order and stakes (decision D2), and the same tests with task clustering
        only (secondary, '*_task_lin')."""
        parts = [("swap", [(f"{fam}|V_swap", c, b, 1.0) for c, b in items]),
                 ("home", [(f"{fam}|V_home", c, b, 1.0) for c, b in items])]
        if fresh and items and all(c[0] != c[1] for c, _ in items):
            parts.append(("fresh", [(f"{fam}|V_swap", (c[0], c[0]), b, 1.0) for c, b in items]))
        so, sr = f"{NO_FAMILY}|S_owner", f"{NO_FAMILY}|S_reader"
        if spread and self.E.has(so) and self.E.has(sr):
            parts.append(("so", [(so, c, b, 1.0) for c, b in items]))
            parts.append(("sr", [(sr, c, b, 1.0) for c, b in items]))
        got = {name: self.comps_full(cs) for name, cs in parts}
        if got["swap"][1] is None or got["home"][1] is None:
            return {"theta": NAN, "status": M.THETA_UNDEFINED}
        got = {k: g for k, g in got.items() if g[1] is not None and fin(g[0])}
        if not ("so" in got and "sr" in got):
            got.pop("so", None)
            got.pop("sr", None)
        colix = {"swap": 0, "home": 1, "fresh": 2, "so": 3, "sr": 4}
        n = sum(len(g[1]) for g in got.values())
        P = np.zeros((n, 5))
        T, I, C = [], [], []
        at, off = 0, 0
        for name, (pt, psi, t, it, cp) in got.items():
            P[at:at + len(psi), colix[name]] = psi
            T.append(t)
            I.append(it)
            C.append(cp + off)
            off += int(cp.max()) + 1
            at += len(psi)
        t, it, cp = np.concatenate(T), np.vstack(I), np.concatenate(C)
        pt = {k: g[0] for k, g in got.items()}
        has_f, has_s = "fresh" in got, "so" in got
        kw = dict(margin=1.0 - self.d.ni_fraction,
                  v_fresh=pt["fresh"] if has_f else None, psi_fresh=P[:, 2] if has_f else None,
                  s_owner=pt["so"] if has_s else None, s_reader=pt["sr"] if has_s else None,
                  psi_so=P[:, 3] if has_s else None, psi_sr=P[:, 4] if has_s else None,
                  z_reader_cal=self.reader_calibration(items) if has_s else None)
        res = M.theta_tests(pt["swap"], pt["home"], P[:, 0], P[:, 1], t, it if self.has_items else None, cp, **kw)
        task = M.theta_tests(pt["swap"], pt["home"], P[:, 0], P[:, 1], t, None, cp, **{**kw, "s_owner": None})
        res.update(drop_V=res.get("drop_c_est", NAN), drop_se=res.get("drop_c_se", NAN),
                   ni_V=res.get("ni_c_est", NAN), ni_se=res.get("ni_c_se", NAN),
                   md_V=res.get("md_c_est", NAN), md_se=res.get("md_c_se", NAN),
                   variance=self.variance_label, has_fresh=has_f, has_spread=has_s,
                   order_flag_source=("calibration tasks" if has_s and self.rcal else
                                      "same tasks (no calibration tasks in these files)" if has_s else ""))
        res["status_task"] = task["status"]
        for k in ("lo", "hi", "se", "p_drop", "p_ni", "p_md", "se_V_home"):
            res[f"{k}_task_lin"] = task.get(k, NAN)
        return res


THIRDS = (("low", "_visits_low"), ("mid", "_visits_mid"), ("high", "_visits_high"))


def theta_visit_thirds(E: "Engine", TW: "TwoWay", design: Design) -> list:
    """theta of the headline score within the registered visit terciles (Part 8.2.7: pairs classed by their
    less-visited item, terciles of visits over the owner's bank), per swap group pooled over streams, with the
    two-way Fieller interval: the per-task V of each third from its concordance parts (V = 2 num - weight)."""
    H = design.headline
    rows = []
    added = False
    for third, suf in THIRDS:
        name = f"{H}{suf}"
        for s in E.data.strata:
            m = E.data.mats[s]
            for which in ("home", "swap"):
                num, den = m.get(f"{H}|conc_{which}{suf}#num"), m.get(f"{H}|conc_{which}{suf}#den")
                if num is None or den is None:
                    continue
                n_, d_ = num.astype(np.float64), den.astype(np.float64)
                m[f"{name}|V_{which}"] = np.where(np.isfinite(n_) & np.isfinite(d_), 2.0 * n_ - d_, np.nan)
                added = True
    if not added:
        return rows
    E.add_keys()
    for third, suf in THIRDS:
        name = f"{H}{suf}"
        if not (E.has(f"{name}|V_home") and E.has(f"{name}|V_swap")):
            continue
        for g in GROUPS + ("all_swaps",):
            cells = design.swaps(g)
            if not cells:
                continue
            r = TW.theta(name, E.items(cells, "all"), fresh=False, spread=False)
            rows.append({"family": H, "third": third, "group": g, "group_label": GROUP_LABEL[g], "n_swaps": len(cells),
                         "theta": r.get("theta", NAN), "theta_lo": r.get("lo", NAN), "theta_hi": r.get("hi", NAN),
                         "theta_interval": r.get("interval", ""), "V_home": r.get("V_home", NAN),
                         "V_swap": r.get("V_swap", NAN), "p_home": r.get("p_home", NAN),
                         "classing": "pair classed by its less-visited item; terciles of visits over the owner's bank"})
    return rows


def theta_draws(E: Engine, fam: str, items: list) -> np.ndarray:
    """Task-id cluster bootstrap draws of theta over the (cell, stream) items (secondary interval)."""
    vs, vh = E.one(f"{fam}|V_swap"), E.one(f"{fam}|V_home")
    a = np.zeros(E.B)
    b = np.zeros(E.B)
    pa = pb = 0.0
    for c, lev in items:
        x = E.at(vs, c, lev)
        y = E.at(vh, c, lev)
        if not (fin(x[0]) and fin(y[0])):
            return np.full(E.B, NAN), NAN
        pa += x[0]
        pb += y[0]
        a = a + x[1]
        b = b + y[1]
    with np.errstate(invalid="ignore", divide="ignore"):
        return a / b, (pa / pb if pb else NAN)


def theta_row(E: Engine, TW: TwoWay, design: Design, fam: str, items: list, self_items: list | None = None) -> dict:
    """Every theta quantity of one swap or group: two-way and task-only intervals, the registered
    intersection-union tests of revision 2 (p_drop, p_md, p_ni each include the home-sign test p_home;
    p_drop also the self-swap contrast), their diagnostics, retained order and stakes (theta = order x
    stakes), the self-swap theta (descriptive) and R beside it."""
    r = TW.theta(fam, items)
    d, pt = theta_draws(E, fam, items)
    dd = d[np.isfinite(d)]
    row = {"theta": r.get("theta", NAN), "theta_lo": r.get("lo", NAN), "theta_hi": r.get("hi", NAN),
           "theta_interval": r.get("interval", ""), "theta_se": r.get("se", NAN), "theta_status": r.get("status", ""),
           "V_home": r.get("V_home", NAN), "V_swap": r.get("V_swap", NAN), "se_V_home": r.get("se_V_home", NAN),
           "drop_V": r.get("drop_V", NAN), "drop_se": r.get("drop_se", NAN), "p_drop": r.get("p_drop", NAN),
           "ni_V": r.get("ni_V", NAN), "ni_se": r.get("ni_se", NAN), "p_ni": r.get("p_ni", NAN),
           "md_V": r.get("md_V", NAN), "md_se": r.get("md_se", NAN),
           "theta_lo_task_lin": r.get("lo_task_lin", NAN), "theta_hi_task_lin": r.get("hi_task_lin", NAN),
           "p_drop_task_lin": r.get("p_drop_task_lin", NAN), "p_ni_task_lin": r.get("p_ni_task_lin", NAN),
           "p_md_task_lin": r.get("p_md_task_lin", NAN), "variance": TW.variance_label,
           "self_swap_in_drop_test": bool(r.get("has_fresh", False)),
           "order_flag_source": r.get("order_flag_source", "")}
    for k in THETA_TEST_KEYS:
        row[k] = r.get(k, NAN if not k.endswith(("_status", "_interval")) else "")
    if dd.size > 1:                     # always written, whatever the flags say (ruling of 24 Nov 2026)
        row["theta_lo_task_boot"], row["theta_hi_task_boot"] = (float(x) for x in np.percentile(dd, [2.5, 97.5]))
    else:
        row["theta_lo_task_boot"] = row["theta_hi_task_boot"] = NAN
    # the reporting flag: the owners' signal on their calibration tasks (msr.metrics.home_signal_flag's
    # rule; no estimate uses those tasks); theta_status (the same-task 4-SE rule) is a secondary column
    z_cal = TW.calibration(fam, items)
    row["z_cal"] = z_cal
    row["theta_status_calibration"] = (M.theta_status_calibration(z_cal) if TW.cal else NO_CAL_FLAG)
    if self_items:
        sr = TW.theta(fam, self_items, fresh=False, spread=False)
        row["theta_self"] = sr.get("theta", NAN)
        row["theta_self_lo"] = sr.get("lo", NAN)
        # descriptive since revision 2 (the drop test itself carries the self-swap contrast): the upper end
        # of the 95 % interval of 1 - theta_self
        row["loss_self_hi"] = 1.0 - sr["lo"] if fin(sr.get("lo")) else NAN
    return row


def theta_label(p_drop: float, p_md: float, p_ni: float, thr_drop, thr_md, thr_ni) -> str:
    """The PC1 reading of a swap or group (msr.metrics.pc1_label) from its three intersection-union
    tests, each judged at its own threshold (None = not reached by the step-down): a label is only ever
    a function of rejections (R6 W6)."""
    def rej(p, t):
        return t is not None and fin(t) and fin(p) and p <= t
    return M.pc1_label(rej(p_drop, thr_drop), rej(p_md, thr_md), rej(p_ni, thr_ni))


def theta_category(design: Design, theta: float, p_drop: float, p_ni: float, loss_self_hi: float,
                   thr_drop, thr_ni) -> str:
    """Decision categories of PC1 of the ROUND-1 revision (kept for older result files and tests;
    revision 2 reads PC1 with theta_label / msr.metrics.pc1_label, whose drop test carries the
    home-sign and self-swap parts itself)."""
    margin = 1.0 - design.ni_fraction
    drop = thr_drop is not None and fin(p_drop) and p_drop <= thr_drop
    beyond = fin(theta) and fin(loss_self_hi) and (1.0 - theta) > loss_self_hi
    ni = thr_ni is not None and fin(p_ni) and p_ni <= thr_ni
    parts = []
    if drop and beyond:
        parts.append("material drop" if theta <= margin else "drop")
    if ni:
        parts.append("no material drop")
    if not parts:
        if drop:
            return "inconclusive (the drop test rejects but the loss is within the self-swap reference)"
        return "inconclusive"
    if parts == ["drop", "no material drop"]:
        return "small drop, within a quarter of the home signal"
    return " + ".join(parts)


def theta_pairs(E: Engine, TW: TwoWay, design: Design, fam: str) -> list:
    """theta per ordered pair (homes included: theta of the self-swap) and level; per-pair Holm over
    3 x (number of swaps) members (the drop, material-drop and no-material-drop tests of every swap,
    each an intersection-union test with the home-sign test; Part 5.2 as revised)."""
    rows = []
    vR = E.one(f"{fam}|conc_home", ratio=True), E.one(f"{fam}|conc_swap", ratio=True)
    for cell in design.swaps("home") + design.swaps("all_swaps"):
        s, t = cell
        for level in E.levels:
            items = E.items([cell], level)
            selfi = E.items([(s, s)], level)
            row = {"family": fam, "owner": s, "reader": t, "group": design.group(s, t), "level": level}
            row.update(theta_row(E, TW, design, fam, items, selfi if s != t else None))
            if not fin(row["theta"]) and not fin(row["V_home"]):
                continue
            h, w_ = E.at(vR[0], cell, level), E.at(vR[1], cell, level)
            row["C_home"], row["C_swap"] = h[0], w_[0]
            row["D"] = h[0] - w_[0]
            row["R"] = (w_[0] - 0.5) / (h[0] - 0.5) if fin(h[0]) and h[0] != 0.5 else NAN
            row["spread_ratio"] = (row["R"] / row["theta"]) if fin(row["R"]) and fin(row["theta"]) and row["theta"] else NAN
            if s != t:
                a = design.alpha
                row["label_unadjusted"] = theta_label(row["p_drop"], row["p_md"], row["p_ni"], a, a, a)
                row["category_unadjusted"] = row["label_unadjusted"]
            else:
                row["label_unadjusted"] = row["category_unadjusted"] = "self-swap reference"
            rows.append(row)
    sw = [r for r in rows if r["level"] == "all" and r["owner"] != r["reader"]]
    ps = [r["p_drop"] for r in sw] + [r["p_md"] for r in sw] + [r["p_ni"] for r in sw]
    hs = holm_steps(ps, design.alpha)
    n = len(sw)
    for j, r in enumerate(sw):
        r["holm_members"] = 3 * n
        r["holm_p_drop"], r["holm_p_md"], r["holm_p_ni"] = (hs["adjusted"][j], hs["adjusted"][n + j],
                                                            hs["adjusted"][2 * n + j])
        r["holm_label"] = theta_label(r["p_drop"], r["p_md"], r["p_ni"], hs["threshold"][j], hs["threshold"][n + j],
                                      hs["threshold"][2 * n + j])
        r["holm_category"] = r["holm_label"]
    return rows


def theta_groups(E: Engine, TW: TwoWay, design: Design, fam: str) -> list:
    rows = []
    for g in DESC_GROUPS:
        cells = design.swaps(g)
        if not cells:
            continue
        for level in E.levels:
            items = E.items(cells, level)
            selfi = [((c[0], c[0]), b) for c, b in items] if g != "home" else None
            row = {"family": fam, "group": g, "group_label": GROUP_LABEL[g], "level": level, "n_swaps": len(cells)}
            row.update(theta_row(E, TW, design, fam, items, selfi))
            a = design.alpha
            row["label_unadjusted"] = (theta_label(row["p_drop"], row["p_md"], row["p_ni"], a, a, a) if g != "home"
                                       else "self-swap reference")
            rows.append(row)
    return rows


def _did_comps(H: str, a: str, b: str, metric: str, cells: list, streams: list, fam_a=None, fam_b=None) -> tuple:
    """Components of the swap-minus-home contrast mean over (swap, stream) of
    [(a - b) after the swap] - [(a - b) at the owner's home], and of the swap part and the home part."""
    fa, fb = fam_a or H, fam_b or H
    n = len(cells) * len(streams)
    sw, hm = [], []
    for c in cells:
        for bb in streams:
            sw += [(f"{fa}|{a}|{metric}", c, bb, 1.0 / n), (f"{fb}|{b}|{metric}", c, bb, -1.0 / n)]
            hm += [(f"{fa}|{a}|{metric}", (c[0], c[0]), bb, 1.0 / n), (f"{fb}|{b}|{metric}", (c[0], c[0]), bb, -1.0 / n)]
    did = sw + [(k, c, bb, -w) for k, c, bb, w in hm]
    return did, sw, hm


def primary_tests(E: Engine, design: Design, TW: "TwoWay | None" = None) -> tuple:
    """The primary family of revision 2 (Parts 3 and 5.1): in each swap group PC1-drop (theta < 1),
    PC1-MD (theta < 0.75) and PC1-NI (theta > 0.75), each an intersection-union test with the
    home-sign test (msr.metrics.theta_tests; the drop test also beyond the self-swap reference), and PC2
    (keep - wipe, first-shown success): 4 x 3 = 12 members, plain Holm; the PC1 reading of a group is
    msr.metrics.pc1_label of its three Holm decisions. PC3 and PC4 (swap-minus-home, level-corrected log
    score) are computed in the same table as SECONDARY rows (role 'secondary', outside the family), with
    their additivity assumption, the owner-reader base-rate gap and the with-item level-target
    sensitivity (R6 W7). Every test uses the two-way jackknife variance; the task-only one is beside."""
    if TW is None:
        TW = TwoWay(E, design, {})
    H = design.headline
    K = design.primary_k
    lam = f"fixed_{design.primary_lambda:g}"
    m_ = 1.0 - design.ni_fraction
    streams = E.streams
    tests = []
    cache: dict = {}
    for hyp in PRIMARY_HYPOTHESES + SECONDARY_HYPOTHESES:
        role = "primary" if hyp in PRIMARY_HYPOTHESES else "secondary"
        for g in GROUPS:
            cells = design.swaps(g)
            row = {"test": f"{hyp}-{g}", "comparison": hyp, "hypothesis": HYP_LABEL[hyp], "group": g,
                   "group_label": GROUP_LABEL[g], "family": H, "n_swaps": len(cells), "n_streams": len(streams),
                   "variance": TW.variance_label, "role": role}
            if not cells:
                row.update(p_holm_input=NAN, note="no swaps of this kind in the study")
                tests.append(row)
                continue
            items = E.items(cells, "all")
            if hyp.startswith("PC1"):
                if not E.has(f"{H}|V_swap"):
                    row.update(p_holm_input=NAN, note="no signed-validity parts")
                    tests.append(row)
                    continue
                if g not in cache:
                    tr = theta_row(E, TW, design, H, items, [((c[0], c[0]), b) for c, b in items])
                    vb = validity_block(E, design, H, False, cells, "all", lambda c: c[0])
                    sm, rr, _, _ = validity_stats(design, vb)
                    cache[g] = (tr, dict(C_home=sm["C_home"]["est"], C_swap=sm["C_swap"]["est"], D=sm["D"]["est"],
                                         D_lo=sm["D"]["lo"], D_hi=sm["D"]["hi"], R=rr["R"], R_lo=rr["R_lo"],
                                         R_hi=rr["R_hi"], R_status=rr["R_status"]))
                tr, extra = cache[g]
                row.update(tr)
                row.update(extra)
                selfpart = " and V_fresh - V_swap > 0 (beyond the owner's second home session)" \
                    if tr.get("self_swap_in_drop_test") else ""
                c, pk, stat = {
                    "PC1-drop": ("drop_c", "p_drop", f"theta (H1: theta < 1): V_home > 0 and V_home - V_swap > 0{selfpart}"),
                    "PC1-MD": ("md_c", "p_md", f"theta (H1: theta < {m_:g}): V_home > 0 and {m_:g} V_home - V_swap > 0"),
                    "PC1-NI": ("ni_c", "p_ni", f"theta (H1: theta > {m_:g}): V_home > 0 and V_swap - {m_:g} V_home > 0"),
                }[hyp]
                row.update(statistic=stat, est=tr["theta"], lo=tr["theta_lo"], hi=tr["theta_hi"], p_holm_input=tr[pk],
                           side="one-sided, intersection-union with the home-sign test", p_contrast=tr.get(f"p_{c}", NAN),
                           item_share=tr.get(f"{c}_item_share", NAN), eff_items=tr.get(f"{c}_eff_items", NAN),
                           df_satt=tr.get(f"{c}_df_satt", NAN))
            elif hyp == "PC2":
                if not (E.has(f"{H}|keep|value") and E.has(f"{H}|wipe|value")):
                    row.update(p_holm_input=NAN, note="no keep / wipe values")
                    tests.append(row)
                    continue
                n = len(cells) * len(streams)
                comps = [(f"{H}|keep|value", c, b, 1.0 / n) for c, b in items] + \
                        [(f"{H}|wipe|value", c, b, -1.0 / n) for c, b in items]
                lr = TW.linear(comps, "two")
                hcomps = [(f"{H}|keep|value", (c[0], c[0]), b, 1.0 / n) for c, b in items] + \
                         [(f"{H}|wipe|value", (c[0], c[0]), b, -1.0 / n) for c, b in items]
                hr = TW.linear(hcomps, "two")
                row.update(statistic="keep - wipe, first-shown success (after the swap)", est=lr["est"], lo=lr["lo"],
                           hi=lr["hi"], se=lr["se"], p_holm_input=lr["p"], side="two-sided", lo_task=lr["lo_task"],
                           hi_task=lr["hi_task"], p_task=lr["p_task"], home_est=hr["est"], home_lo=hr["lo"],
                           home_hi=hr["hi"], item_share=lr["item_share"], eff_items=lr["eff_items"],
                           df_satt=lr["df_satt"])
            else:
                metric = "log_lc" if E.has(f"{H}|keep|log_lc") else "log"
                if metric != "log_lc":
                    row["note"] = "no level-corrected log score in these result files: the raw log score is used"
                pairs = [(lam, "keep")] if hyp == "PC3" else [(f"recal_{K}", "keep"), (f"recal_{K}", "wipe")]
                if (K is None and hyp == "PC4") or not all(E.has(f"{H}|{a}|{metric}") and E.has(f"{H}|{b}|{metric}")
                                                           for a, b in pairs):
                    row.update(p_holm_input=NAN, note=f"no {metric} for {pairs} in family {H}")
                    tests.append(row)
                    continue
                parts = []
                for a, b in pairs:
                    did, swp, hmp = _did_comps(H, a, b, metric, cells, streams)
                    d_ = TW.linear(did, "upper" if hyp == "PC4" else "two")
                    s_, h_ = TW.linear(swp), TW.linear(hmp)
                    fs_did, _, _ = _did_comps(H, a, b, "value", cells, streams)
                    fsd = TW.linear(fs_did)
                    fsw = TW.linear(_did_comps(H, a, b, "value", cells, streams)[1])
                    raw_did = TW.linear(_did_comps(H, a, b, "log", cells, streams)[0]) if E.has(f"{H}|{a}|log") else {}
                    # base-rate sensitivity (R6 W7): the level target set to the reader's with-item success
                    lcw = (TW.linear(_did_comps(H, a, b, "log_lcw", cells, streams)[0], "upper" if hyp == "PC4" else "two")
                           if E.has(f"{H}|{a}|log_lcw") and E.has(f"{H}|{b}|log_lcw") else {})
                    parts.append((a, b, d_, s_, h_, fsd, fsw, raw_did, lcw))
                a, b, d_, s_, h_, fsd, fsw, raw_did, lcw = parts[0]
                row.update(statistic=f"[{a} - {b}] after the swap minus at home, {METRIC_LABEL[metric]}",
                           metric=metric, est=d_["est"], lo=d_["lo"], hi=d_["hi"], se=d_["se"],
                           lo_task=d_["lo_task"], hi_task=d_["hi_task"],
                           swap_est=s_["est"], swap_lo=s_["lo"], swap_hi=s_["hi"],
                           home_est=h_["est"], home_lo=h_["lo"], home_hi=h_["hi"],
                           fs_did=fsd["est"], fs_did_lo=fsd["lo"], fs_did_hi=fsd["hi"],
                           fs_swap=fsw["est"], fs_swap_lo=fsw["lo"], fs_swap_hi=fsw["hi"],
                           raw_log_did=raw_did.get("est", NAN), item_share=d_["item_share"],
                           eff_items=d_["eff_items"], df_satt=d_["df_satt"], assumption=ADDITIVITY,
                           est_lcw=lcw.get("est", NAN), lo_lcw=lcw.get("lo", NAN), hi_lcw=lcw.get("hi", NAN),
                           p_lcw=lcw.get("p", NAN))
                # the owner-reader base-rate gap: owner minus reader no-memory success, mean over (swap, stream)
                nk = f"{NO_FAMILY}|none|value"
                if E.has(nk):
                    nn = len(items)
                    bg = TW.linear([(nk, (c[0], c[0]), bb, 1.0 / nn) for c, bb in items]
                                   + [(nk, (c[1], c[1]), bb, -1.0 / nn) for c, bb in items])
                    row.update(base_gap=bg["est"], base_gap_lo=bg["lo"], base_gap_hi=bg["hi"])
                if hyp == "PC3":
                    row.update(p_holm_input=d_["p"], side="two-sided")
                else:
                    a2, b2, d2, s2, h2, fs2, fw2, _, lcw2 = parts[1]
                    row.update(p_4a=d_["p"], est_b=d2["est"], lo_b=d2["lo"], hi_b=d2["hi"], p_4b=d2["p"],
                               swap_est_b=s2["est"], home_est_b=h2["est"], fs_did_b=fs2["est"], fs_did_b_lo=fs2["lo"],
                               fs_did_b_hi=fs2["hi"], fs_swap_b=fw2["est"],
                               p_holm_input=max(d_["p"], d2["p"]) if fin(d_["p"]) and fin(d2["p"]) else NAN,
                               side="one-sided, intersection-union", k_used=K, est_lcw_b=lcw2.get("est", NAN),
                               p_lcw=(max(lcw.get("p", NAN), lcw2.get("p", NAN))
                                      if fin(lcw.get("p", NAN)) and fin(lcw2.get("p", NAN)) else NAN))
            tests.append(row)
    fam_tests = [r for r in tests if r["role"] == "primary" and fin(r.get("p_holm_input"))]
    for r in tests:
        r["in_family"] = r in fam_tests
    hs = holm_steps([r["p_holm_input"] for r in fam_tests], design.alpha)
    for r, adj, rej, thr, rank in zip(fam_tests, hs["adjusted"], hs["reject"], hs["threshold"], hs["rank"]):
        r.update(holm_rank=rank, holm_threshold=thr if thr is not None else NAN, holm_adjusted_p=adj,
                 holm_reject=rej, family_size=len(fam_tests))
    # concern marks of Part 4.1 (they never change a decision): df < 100 -> the t(df) p beside the normal one and a
    # note when a rejection holds only with the normal p; item share >= 0.5 -> a note that items carry most of the variance
    from scipy import stats as _st

    def _pt(est, se, df, two=False):
        if not (fin(est) and fin(se) and se > 0 and fin(df) and df > 0):
            return NAN
        z = est / se
        return float(2 * _st.t.sf(abs(z), df)) if two else float(_st.t.sf(z, df))

    for r in fam_tests:
        c = {"PC1-drop": "drop_c", "PC1-MD": "md_c", "PC1-NI": "ni_c"}.get(r["comparison"])
        if c:
            parts = [_pt(r.get(f"{c}_est"), r.get(f"{c}_se"), r.get(f"{c}_df_satt")),
                     _pt(r.get("home_est"), r.get("home_se"), r.get("home_df_satt"))]
            if c == "drop_c" and fin(r.get("self_c_est")):
                parts.append(_pt(r.get("self_c_est"), r.get("self_c_se"), r.get("self_c_df_satt")))
            p_t = max(parts) if all(fin(x) for x in parts) else NAN
            dfs = [r.get(f"{c}_df_satt"), r.get("home_df_satt")]
        else:
            p_t = _pt(r.get("est"), r.get("se"), r.get("df_satt"), two=True)
            dfs = [r.get("df_satt")]
        low_df = any(fin(x) and x < 100 for x in dfs)
        r["p_t_satt"] = p_t if low_df else NAN
        r["reference_note"] = ("not robust to the reference distribution (passes with the normal p only)"
                               if low_df and r["holm_reject"] and fin(p_t) and fin(r.get("holm_threshold"))
                               and p_t > r["holm_threshold"] else ("df < 100: t(df) p printed" if low_df else ""))
        r["item_note"] = ("items carry most of the variance (item share >= 0.5)"
                          if fin(r.get("item_share")) and r["item_share"] >= 0.5 else "")
    # PC1: one reading per group from its three Holm decisions (msr.metrics.pc1_label), on all three rows
    by = {r["test"]: r for r in tests}
    for g in GROUPS:
        rs = [by.get(f"{h}-{g}", {}) for h in ("PC1-drop", "PC1-MD", "PC1-NI")]
        if not any(r.get("in_family") for r in rs):
            continue
        lab = M.pc1_label(*(bool(r.get("holm_reject")) for r in rs))
        for r in rs:
            if r.get("in_family"):
                r["label"] = r["decision"] = lab
    for r in fam_tests:
        if r["comparison"] == "PC2":
            r["label"] = r["decision"] = primary_decision(design, r, r.get("holm_threshold"))
    for r in tests:
        if r["in_family"]:
            continue
        r.update(holm_reject=False, family_size=len(fam_tests))
        if r["role"] == "secondary" and fin(r.get("p_holm_input")):
            rr = dict(r, holm_reject=r["p_holm_input"] <= design.alpha)
            r["decision"] = "secondary (outside the family, unadjusted): " + primary_decision(design, rr, design.alpha)
        else:
            r["decision"] = "not in the confirmatory family here: " + r.get("note", "not computable")
    return tests, {}, hs


def primary_decision(design: Design, r: dict, thr) -> str:
    """The reading of a PC2 member (revision 2: a function of the test only, no size word) and the
    unadjusted reading of the secondary PC3 / PC4 rows."""
    if not fin(r.get("p_holm_input")):
        return "not computable: " + r.get("note", "missing input")
    c, est = r["comparison"], r.get("est", NAN)
    if not r["holm_reject"]:
        return {"PC2": "no difference shown", "PC4": "not supported"}.get(c, "no difference detected")
    if c == "PC2":
        return "keep beats wipe" if est > 0 else "wipe beats keep"
    if c == "PC3":
        return ("the fixed discount gains more over keep after the swap than at home" if est > 0
                else "keep gains more over the fixed discount after the swap than at home")
    return "the calibrated discount beats both keep and wipe beyond its home advantage"


def random_effects(y, v, level: float = 0.95) -> dict:
    """Between-pair spread of one group (revision 2; R4, R6 W12.1): DerSimonian-Laird tau^2 from the
    per-pair estimates y and their variances v, its Q-profile interval (Viechtbauer 2007), the
    random-effects mean and the prediction interval for a NEW pair, mean +- t_{k-2} sqrt(tau^2 +
    se_mean^2) (Higgins, Thompson and Spiegelhalter 2009; k >= 3). The pairs of a group share models,
    so the interval describes these pairs' spread, not a sampling design (Part 5.2)."""
    from scipy import optimize, stats
    y, v = np.asarray(y, float), np.asarray(v, float)
    ok = np.isfinite(y) & np.isfinite(v) & (v > 0)
    y, v = y[ok], v[ok]
    k = len(y)
    out = {"k": k, "re_mean": NAN, "se_mean": NAN, "tau": NAN, "tau_lo": NAN, "tau_hi": NAN, "Q": NAN, "I2": NAN,
           "pi_lo": NAN, "pi_hi": NAN, "pi_df": NAN,
           "method": "DerSimonian-Laird; Q-profile interval of tau; prediction interval with t(k - 2) (Higgins 2009)"}
    if k < 2:
        return out
    w = 1.0 / v
    mu_f = float(np.sum(w * y) / np.sum(w))
    Q = float(np.sum(w * (y - mu_f) ** 2))
    C = float(np.sum(w) - np.sum(w ** 2) / np.sum(w))
    t2 = max(0.0, (Q - (k - 1)) / C) if C > 0 else 0.0
    ws = 1.0 / (v + t2)
    mu = float(np.sum(ws * y) / np.sum(ws))
    se = float(1.0 / math.sqrt(np.sum(ws)))
    out.update(re_mean=mu, se_mean=se, tau=math.sqrt(t2), Q=Q, I2=max(0.0, (Q - (k - 1)) / Q) if Q > 0 else 0.0)

    def qgen(t):
        wt = 1.0 / (v + t)
        m = np.sum(wt * y) / np.sum(wt)
        return float(np.sum(wt * (y - m) ** 2))

    a = 1.0 - level
    hi_q, lo_q = stats.chi2.ppf(1 - a / 2, k - 1), stats.chi2.ppf(a / 2, k - 1)
    big = max(1.0, 100.0 * (float(np.var(y)) + float(np.max(v))))

    def root(target):
        if qgen(0.0) <= target:
            return 0.0
        if qgen(big) > target:
            return float("inf")
        return float(optimize.brentq(lambda t: qgen(t) - target, 0.0, big))

    out["tau_lo"], out["tau_hi"] = math.sqrt(root(hi_q)), math.sqrt(root(lo_q))
    if k >= 3:
        tq = float(stats.t.ppf(1 - a / 2, k - 2))
        half = tq * math.sqrt(t2 + se * se)
        out.update(pi_lo=mu - half, pi_hi=mu + half, pi_df=k - 2)
    return out


def group_random_effects(E: Engine, TW: TwoWay, design: Design, trows: list) -> list:
    """Per swap group: the between-pair SD (tau) and the prediction interval for a new pair of the two
    primary quantities, PC1 theta (per-pair theta and its two-way delta SE from theta_pairs) and PC2
    keep - wipe in first-shown success (per-pair two-way estimates). One row per (comparison, group)."""
    H = design.headline
    rows = []
    tp = {(r["owner"], r["reader"]): r for r in trows if r["family"] == H and r["level"] == "all"}
    kw = E.has(f"{H}|keep|value") and E.has(f"{H}|wipe|value")
    for g in GROUPS + ("same_maker", "all_swaps"):
        cells = design.swaps(g)
        if not cells:
            continue
        y = [tp[c]["theta"] if c in tp else NAN for c in cells]
        v = [tp[c]["theta_se"] ** 2 if c in tp and fin(tp[c].get("theta_se")) else NAN for c in cells]
        rows.append({"family": H, "comparison": "PC1 theta", "group": g, "group_label": GROUP_LABEL[g],
                     "n_swaps": len(cells), **random_effects(y, v)})
        if kw:
            ys, vs = [], []
            for c in cells:
                it = E.items([c], "all")
                n = len(it)
                lr = TW.linear([(f"{H}|keep|value", cc, b, 1.0 / n) for cc, b in it]
                               + [(f"{H}|wipe|value", cc, b, -1.0 / n) for cc, b in it])
                ys.append(lr["est"])
                vs.append(lr["se"] ** 2 if fin(lr["se"]) else NAN)
            rows.append({"family": H, "comparison": "PC2 keep - wipe", "group": g, "group_label": GROUP_LABEL[g],
                         "n_swaps": len(cells), **random_effects(ys, vs)})
    return rows


def join_group_re(re_rows: list, tests: list) -> None:
    """Copy each group's tau, its interval and the prediction interval into the primary-test rows."""
    by = {(r["comparison"], r["group"]): r for r in re_rows}
    for t in tests:
        comp = "PC1 theta" if t["comparison"].startswith("PC1") else "PC2 keep - wipe" if t["comparison"] == "PC2" else None
        r = by.get((comp, t["group"]))
        if r is None:
            continue
        t.update(group_sd=r["tau"], group_sd_lo=r["tau_lo"], group_sd_hi=r["tau_hi"], pi_lo=r["pi_lo"],
                 pi_hi=r["pi_hi"], pi_df=r["pi_df"], re_mean=r["re_mean"], group_sd_k=r["k"])


def _ols(y: np.ndarray, X: np.ndarray) -> tuple:
    """OLS coefficients and HC1 standard errors (descriptive)."""
    n, p = X.shape
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    if n <= p:
        return beta, np.full(p, NAN)
    e = y - X @ beta
    XtXi = np.linalg.pinv(X.T @ X)
    meat = (X * e[:, None] ** 2).T @ X
    V = XtXi @ meat @ XtXi * n / (n - p)
    return beta, np.sqrt(np.clip(np.diag(V), 0, None))


def _capability_rows(swaps: list, tp: dict, forecast_csv: Path | None) -> tuple:
    """swaps: [(owner, reader, group, same_maker)]; tp: {(owner, reader): theta row}."""
    fp = {}
    src = ""
    if forecast_csv is not None and Path(forecast_csv).exists():
        for r in read_csv(Path(forecast_csv)):
            fp[(r.get("owner"), r.get("reader"))] = r
        src = f"{Path(forecast_csv).name} (msr.forecast)"
    rows = []
    for o, rd, g, same in swaps:
        f, t = fp.get((o, rd), {}), tp.get((o, rd), {})
        rows.append({"owner": o, "reader": rd, "group": g, "same_maker": int(same),
                     "gap": num(f.get("gap")), "abs_gap": num(f.get("abs_gap")), "ec": num(f.get("ec")),
                     "ec_se": num(f.get("ec_se")), "x_owner": num(f.get("x_owner")), "x_reader": num(f.get("x_reader")),
                     "theta": num(t.get("theta")), "theta_lo": num(t.get("theta_lo")), "theta_hi": num(t.get("theta_hi")),
                     "label_unadjusted": t.get("label_unadjusted", ""), "source": src or "forecast_pairs.csv not found"})
    fits = []
    models = (("maker only", ("same_maker",)),
              ("maker + capability gap + error consistency", ("same_maker", "gap", "abs_gap", "ec")))
    for name, terms in models:
        use = [r for r in rows if fin(r["theta"]) and all(fin(r[k]) for k in terms)]
        n = len(use)
        note = "descriptive: pairs share models, so these SEs ignore that dependence; no test is made"
        if n <= len(terms) + 1 or len({r["same_maker"] for r in use}) < 2:
            fits.append({"model": name, "term": "", "coef": NAN, "se": NAN, "n_pairs": n,
                         "note": "too few pairs (or no same-maker / cross-maker contrast) to fit"})
            continue
        X = np.column_stack([np.ones(n)] + [[float(r[k]) for r in use] for k in terms])
        beta, se = _ols(np.array([float(r["theta"]) for r in use]), X)
        for k, b_, s_ in zip(("intercept",) + terms, beta, se):
            fits.append({"model": name, "term": k, "coef": float(b_), "se": float(s_), "n_pairs": n, "note": note})
    return rows, fits


def capability_tables(design: Design, trows: list, forecast_csv: Path | None) -> tuple:
    """theta per swap against the capability gap (no-memory success, reader minus owner) and error
    consistency (both read from msr.forecast's forecast_pairs.csv), with maker as a separate term (R5 W9).
    Descriptive: the pairs share models, so the HC1 SEs ignore that dependence and no test is made.
    Fits: theta ~ same_maker, and theta ~ same_maker + gap + |gap| + error consistency."""
    H = design.headline
    tp = {(r["owner"], r["reader"]): r for r in trows if r["family"] == H and r["level"] == "all"}
    sw = [(c[0], c[1], design.group(*c), design.family.get(c[0]) == design.family.get(c[1]))
          for c in design.swaps("all_swaps")]
    return _capability_rows(sw, tp, forecast_csv)


def refresh_capability(adir) -> tuple:
    """Rewrite capability.csv and capability_fit.csv of an analysis folder from its theta_pairs.csv and
    the forecast_pairs.csv that msr.forecast wrote AFTER the analysis (make_paper_assets calls this once
    the forecast has run, so the table never reads a stale forecast). Returns the two paths."""
    adir = Path(adir)
    meta = {r["key"]: r["value"] for r in read_csv(adir / "meta.csv")} if (adir / "meta.csv").exists() else {}
    H = meta.get("headline_family", "ema_grade")
    tp, sw = {}, []
    if (adir / "theta_pairs.csv").exists():
        for r in read_csv(adir / "theta_pairs.csv"):
            if r.get("family") == H and r.get("level") == "all" and r.get("owner") != r.get("reader"):
                tp[(r["owner"], r["reader"])] = r
                sw.append((r["owner"], r["reader"], r.get("group", ""),
                           r.get("group") in ("upgrade", "downgrade", "same_other")))
    rows, fits = _capability_rows(sw, tp, adir / "forecast_pairs.csv")
    write_csv(adir / "capability.csv", rows)
    write_csv(adir / "capability_fit.csv", fits)
    return adir / "capability.csv", adir / "capability_fit.csv"


def stakes_table(E: Engine, TW: TwoWay, design: Design, fam: str) -> list:
    """What is at stake, in success points (decision S7): per group, keep - wipe, keep - shuffled and
    ceiling - keep in first-shown success, at home (the owners' home cells, one per swap) and after
    the swap, with two-way intervals; and the swap-minus-home change of each."""
    rows = []
    specs = (("keep - wipe", (fam, "keep"), (fam, "wipe")),
             ("keep - shuffled", (fam, "keep"), (fam, "shuffled")),
             ("ceiling - keep", (NO_FAMILY, "ceiling"), (fam, "keep")),
             ("keep - none", (fam, "keep"), (NO_FAMILY, "none")))
    for g in GROUPS + ("same_maker", "all_swaps"):
        cells = design.swaps(g)
        if not cells:
            continue
        items = E.items(cells, "all")
        n = len(items)
        for name, (fa, a), (fb, b) in specs:
            ka, kb = f"{fa}|{a}|value", f"{fb}|{b}|value"
            if not (E.has(ka) and E.has(kb)):
                continue
            row = {"family": fam, "group": g, "group_label": GROUP_LABEL[g], "n_swaps": len(cells), "contrast": name}
            sw = [(ka, c, bb, 1.0 / n) for c, bb in items] + [(kb, c, bb, -1.0 / n) for c, bb in items]
            hm = [(ka, (c[0], c[0]), bb, 1.0 / n) for c, bb in items] + [(kb, (c[0], c[0]), bb, -1.0 / n) for c, bb in items]
            for tag, comps in (("home", hm), ("swap", sw), ("swap_minus_home", sw + [(k, c, bb, -w) for k, c, bb, w in hm])):
                lr = TW.linear(comps, "two")
                row.update({f"{tag}": lr["est"], f"{tag}_lo": lr["lo"], f"{tag}_hi": lr["hi"], f"{tag}_p": lr["p"],
                            f"{tag}_lo_task": lr["lo_task"], f"{tag}_hi_task": lr["hi_task"]})
            row["unit"] = "success points (0.01 = 1 point)"
            rows.append(row)
    return rows


def group_spread(het: list, tests: list) -> None:
    """Join the pre-registered spread statistics of each group (Part 5.2: range with its pairs, share
    of opposite sign, between-pair SD) into the primary-test rows."""
    name = {"PC1-drop": "PC1 theta loss", "PC1-MD": "PC1 theta loss", "PC1-NI": "PC1 theta loss", "PC2": "PC2 keep - wipe",
            "PC3": "PC3 fixed - keep (swap - home)", "PC4": "PC4a recal - keep (swap - home)"}
    by = {(r["comparison"], r["group"]): r for r in het}
    for t in tests:
        h = by.get((name.get(t["comparison"], ""), t["group"]))
        if not h:
            continue
        t.update(spread_n=h["n_swaps"], spread_min=h["min"], spread_min_pair=h["min_pair"], spread_max=h["max"],
                 spread_max_pair=h["max_pair"], spread_opposite_share=h["opposite_sign_share"],
                 spread_sd_between=h["sd_between"], spread_sd_between_lo=h["sd_between_lo"],
                 spread_sd_between_hi=h["sd_between_hi"], spread_statistic=h["comparison"])


def revision_pair_values(E: Engine, design: Design, fam: str) -> dict:
    """Per-swap values (point, task-id bootstrap draws) of the revised primary statistics, for the
    source-and-target spread (Part 5.2): theta loss 1 - theta, keep - wipe, and the swap-minus-home
    contrasts of PC3 and PC4a."""
    out: dict = {}
    K, lam = design.primary_k, f"fixed_{design.primary_lambda:g}"
    if E.has(f"{fam}|V_swap"):
        out["PC1 theta loss"] = {}
        for c in design.swaps("all_swaps"):
            d, p = theta_draws(E, fam, E.items([c], "all"))
            out["PC1 theta loss"][c] = (1.0 - p, 1.0 - d)
    metric = "log_lc" if E.has(f"{fam}|keep|log_lc") else "log"
    specs = [("PC2 keep - wipe", "value", "keep", "wipe", False), ("PC3 fixed - keep (swap - home)", metric, lam, "keep", True)]
    if K is not None:
        specs.append(("PC4a recal - keep (swap - home)", metric, f"recal_{K}", "keep", True))
    for name, m, a, b, did in specs:
        if not (E.has(f"{fam}|{a}|{m}") and E.has(f"{fam}|{b}|{m}")):
            continue
        A, Bm = E.one(f"{fam}|{a}|{m}"), E.one(f"{fam}|{b}|{m}")
        vals = {}
        for c in design.swaps("all_swaps"):
            p, d = diff_est(E, A, Bm, [(c, "all")])
            if did:
                ph, dh = diff_est(E, A, Bm, [((c[0], c[0]), "all")])
                p, d = p - ph, d - dh
            vals[c] = (p, d)
        out[name] = vals
    return out


# ===========================================================================
# Processes (revision 2, fault 9 of the full-size rehearsal): the per-family steps run in forked worker
# processes that share the loaded data and the bootstrap counts copy-on-write. Every step is
# deterministic and independent across its jobs, so the rows are the same as in one process, in the
# same order. MSR_ANALYSIS_WORKERS sets the number (1 = one process); default min(8, cores).
# ===========================================================================

_PAR: dict = {}


def n_workers(n_jobs: int) -> int:
    try:
        w = int(os.environ.get("MSR_ANALYSIS_WORKERS", "") or 0)
    except ValueError:
        w = 0
    w = w or min(8, os.cpu_count() or 1)
    return max(1, min(w, n_jobs))


def par_map(fn, jobs: list, **ctx) -> list:
    """[fn(job) for job in jobs], in forked processes when more than one worker is allowed; fn is a
    module-level function that reads its shared inputs from _PAR (set from ctx before the fork)."""
    import multiprocessing as mp
    _PAR.clear()
    _PAR.update(ctx)
    n = n_workers(len(jobs))
    if n <= 1 or "fork" not in mp.get_all_start_methods():
        return [fn(j) for j in jobs]
    with mp.get_context("fork").Pool(n) as pool:
        return pool.map(fn, jobs, chunksize=1)


def _job_theta(fam):
    E, TW, d = _PAR["E"], _PAR["TW"], _PAR["design"]
    return theta_pairs(E, TW, d, fam), theta_groups(E, TW, d, fam)


def _job_validity(fam):
    E, d = _PAR["E"], _PAR["design"]
    return pair_validity(E, d, fam), group_validity(E, d, fam)


def _job_contrasts(fam):
    return pair_contrasts(_PAR["E"], _PAR["design"], fam)


def _job_arms(job):
    fam, arms = job
    return arms_tables_part(_PAR["E"], _PAR["design"], fam, arms, _PAR["pair_rows_for"])


def _job_equal_budget(fam):
    return equal_budget(_PAR["E"], _PAR["design"], fam)


def _job_secondary(name):
    E, d = _PAR["E"], _PAR["design"]
    if name == "topk":
        return topk_tables(E, d)
    if name == "tau":
        return tau_tie_tables(E, d)
    if name == "variants":
        return variant_validity(E, d)
    if name == "mix":
        return mix_weight_tables(E, d)
    if name == "second_bank":
        return second_bank_drop(E, d)
    if name == "ceiling_noise":
        raw = _PAR["raw"]
        mc_rows, mc_look = model_ceiling(d, raw, _PAR["seed"]) if raw else ([], {})
        a, b = noise_tables(E, d, mc_look)
        return mc_rows, a, b
    if name == "ips":
        return pair_validity(E, d, "ips"), group_validity(E, d, "ips")
    if name == "linearised":
        return linearised_checks(E, d, _PAR["tests"])
    if name == "pigeonhole":
        return pigeonhole_pc1(E, d, _PAR["raw"], _PAR["n_boot"], _PAR["seed"])
    raise ValueError(name)


def _job_heterogeneity(fam):
    E, d = _PAR["E"], _PAR["design"]
    pv = {**revision_pair_values(E, d, fam), **comparison_pair_values(E, d, fam)}
    h1, h2 = heterogeneity(E, d, fam, pv)
    return h1, h2, (lomo_primary(E, d, pv) if fam == d.headline else [])


# ===========================================================================
# The whole analysis
# ===========================================================================


def run_analysis(study_name: str, n_boot: int | None = None, seed: int | None = None, out_dir=None,
                 runs_dir=None, quiet: bool = False) -> dict:
    """Compute everything pre-registered that the result files allow and write it to
    runs/<study>/analysis/ (or out_dir). Returns a dict of the tables and the file paths."""
    t0 = time.time()
    st = resolve_study(study_name, runs_dir)
    from msr import llm as L
    run_dir = (Path(runs_dir) if runs_dir else Path(L.RUNS)) / st.name
    results = run_dir / "results"
    design = design_from_study(st)
    n_boot = int(n_boot if n_boot is not None else 10000)
    seed = int(seed if seed is not None else st.evaluate.seed)
    out = Path(out_dir) if out_dir else run_dir / "analysis"
    data = load_per_task_dir(design, results)
    res = analyse(design, data, results, run_dir, n_boot, seed, out, printer=None if quiet else print)
    res["runtime_s"] = time.time() - t0
    if not quiet:
        print(f"  analysis written to {out} ({res['runtime_s']:.1f} s, {n_boot:,} draws)")
    return res


def analyse(design: Design, data: PerTask, results: Path | None, run_dir: Path | None, n_boot: int, seed: int,
            out: Path, printer=None) -> dict:
    say = printer or (lambda *_: None)
    H = design.headline
    tables: dict = {}
    deviations, skipped, warn = [], [], online_constant_warnings(design)
    for wmsg in warn:
        print(f"WARNING (pre-registration Part 2.10): {wmsg}", file=sys.stderr)
        warnings.warn(wmsg)
    raw = load_raw_cells(design, results, data) if results is not None else {}
    injected = inject_raw_keys(design, data, raw) if raw else []
    # revision 2 (D2): per-task cross-repeat spread parts of owner and reader, for order and stakes
    spread_keys = inject_spread_keys(design, data, raw) if raw else []
    if not raw:
        skipped.append("Raw cells (results/cells/): none, so the split-half intervals, R_adj, the IPS scores, the "
                       "pigeonhole bootstrap and the model-based ceiling are skipped.")
    E = Engine(design, data, n_boot, seed)
    # The noise reference of R_adj: each model's split-half reference on its own home cells,
    # repeats 1-2 vs repeats 3-4 (outcomes average two repeats, as C's do); repeat 1 vs repeat 2
    # where the extra home repeats are missing.
    E.sh, E.sh_kind = split_half_est(E, "sh2"), "repeats 1-2 vs 3-4 on the model's home cells"
    if E.sh is None:
        E.sh, E.sh_kind = split_half_est(E, "sh"), "repeat 1 vs repeat 2 on the model's home cells"
    if design.primary_k != design.primary_k_wanted and design.primary_k is not None:
        deviations.append(f"PC4 uses recal_{design.primary_k}: this study has no k = {design.primary_k_wanted} "
                          f"(k values {design.k_values}).")
    if design.primary_k is None:
        skipped.append("Arms with fresh checks: this study has no k values, so PC4, the equal-budget comparisons and "
                       "the k-curves are skipped.")
    if len(E.streams) < 2:
        deviations.append(f"one stream only ({', '.join(E.streams)}); every 'pooled over streams' value is that stream.")
    n_orders = len({s_[1] for s_ in data.strata})
    if n_orders != 3:
        deviations.append(f"{n_orders} stream orders (the pre-registration has 3).")
    n_eval = sorted({len(t) for t in data.tasks.values()})
    if n_eval != [400]:
        deviations.append(f"{'/'.join(map(str, n_eval))} evaluation tasks per order (the pre-registration has 400).")
    n_models = len(design.models)
    core_m = core_models(design)
    got = (n_models, len(core_m), len(design.swaps()), len(design.swaps("upgrade")), len(design.swaps("downgrade")),
           len(design.swaps("cross")))
    if got != (12, 8, 60, 6, 6, 48):
        # revision 2 (Part 0.2): 8 core-grid models with every ordered pair + 4 extension models paired within
        # their maker = 60 swaps (6 upgrades, 6 downgrades, 48 cross-maker)
        deviations.append(f"{n_models} models ({len(core_m)} in the core grid), so {got[2]} swaps ({got[3]} upgrades, "
                          f"{got[4]} downgrades, {got[5]} cross-maker) instead of 60 (6, 6, 48; 8 core-grid models "
                          f"and 4 extension models); the permutation tests have {len(maker_relabelings(design)[0]):,} "
                          f"maker-preserving relabellings (P1) and {min(math.factorial(len(core_m)), 50000):,} core-grid "
                          f"permutations (P2, P4), not 3,072 and 40,320.")
    if n_boot != 10000:
        deviations.append(f"{n_boot:,} bootstrap draws (the pre-registration has 10,000).")
    deviations += [f"{w_} (warning)" for w_ in warn]

    theta_fams = inject_theta_keys(design, data)
    E.add_keys()
    TW = TwoWay(E, design, raw)
    TW.cal = calibration_signal(design, results)
    TW.rcal = reader_spread_calibration(design, results)
    E.tw = TW
    if len(spread_keys) < 2:
        skipped.append("Repeat spreads (D2): the raw cells lack the owner's later-session repeats or the reader's two "
                       "repeats, so retained order and stakes are not computed (theta and its tests are).")
    elif not TW.rcal:
        skipped.append("Calibration tasks: none in these result files, so order's identifiability flag uses the "
                       "same-task spread z (reported, not the registered rule).")
    if not TW.has_items:
        skipped.append("Raw cells (results/cells/): none, so the primary intervals cluster on task ids only, not on "
                       "items (the registered two-way variance needs the candidates' item ids).")
    if not TW.cal:
        skipped.append("Calibration tasks: none in these result files, so theta's reporting flag (Part 2.4) is 'not "
                       "available' and decisions that need it use the secondary same-task status.")
    ov = M.task_overlap(data.tasks)

    say("  [analysis] theta (the headline), per pair and per group, two-way intervals ...")
    trows, tgrows = [], []
    tfams = [f for f in design.score_families if f in theta_fams] + (["ips"] if "ips" in theta_fams else [])
    for a_, b_ in par_map(_job_theta, tfams, E=E, TW=TW, design=design):
        trows += a_
        tgrows += b_
    tables["theta_pairs"] = trows
    tables["theta_groups"] = tgrows
    # the registered visit terciles (Part 8.2.7), headline score, per swap group
    tables["theta_visit_thirds"] = theta_visit_thirds(E, TW, design)

    say("  [analysis] validity per pair and per swap stratum (Cw, D, R: secondary) ...")
    vrows, grows = [], []
    for a_, b_ in par_map(_job_validity, [f for f in design.score_families if E.has(f"{f}|conc_home")],
                          E=E, design=design):
        vrows += a_
        grows += b_
    tables["validity_pairs"] = vrows
    tables["group_validity"] = grows

    say("  [analysis] the primary tests ...")
    tests, _, _ = primary_tests(E, design, TW)
    tables["primary_tests"] = tests
    tables["all_swaps_descriptive"] = all_swaps_descriptive(E, design)

    say("  [analysis] per-pair contrasts and heterogeneity ...")
    crows = []
    for part in par_map(_job_contrasts, [f for f in design.score_families if f != "visits"], E=E, design=design):
        crows += part
    tables["contrasts_pairs"] = crows
    het, het_models, lomo_p = [], [], []
    hfams = [H] + [f for f in design.score_families if f != H and f in USEFUL]
    for fam, (h1, h2, lp) in zip(hfams, par_map(_job_heterogeneity, hfams, E=E, design=design)):
        het += h1
        het_models += h2
        if fam == H:
            lomo_p = lp
    tables["heterogeneity"] = het
    group_spread([r for r in het if r["family"] == H], tests)
    say("  [analysis] per-group between-pair SD and prediction interval for a new pair ...")
    tables["group_re"] = group_random_effects(E, TW, design, trows)
    join_group_re(tables["group_re"], tests)
    tables["capability"], tables["capability_fit"] = capability_tables(design, trows, Path(out) / "forecast_pairs.csv")
    say("  [analysis] what is at stake, in success points ...")
    tables["stakes"] = stakes_table(E, TW, design, H)
    tables["heterogeneity_model_effects"] = het_models
    tables["lomo_primary"] = lomo_p

    say("  [analysis] predictions P1-P4 ...")
    ag = agreement_pairs(design, results) if results is not None else []
    tables["agreement_pairs"] = ag
    prow, psec, plomo, ppts = predictions(E, design, vrows, ag, trows)
    tables["predictions"] = prow
    tables["predictions_secondary"] = psec
    tables["predictions_lomo"] = plomo
    tables["prediction_points"] = ppts

    say("  [analysis] arms, k-curves, equal budgets ...")
    garms, parms = [], []
    for g_, p_ in par_map(_job_arms, arms_jobs(E, design), E=E, design=design, pair_rows_for={H}):
        garms += g_
        parms += p_
    tables["arms_groups"] = garms
    tables["arms_pairs"] = parms
    tables["kcurve"] = [r for r in garms if r["level"] == "all" and (r["k"] != "" or r["arm"] in ("keep", "wipe"))
                        and r["metric"] in ("value", "log", "brier", "regret")]
    eb = []
    for part in par_map(_job_equal_budget, [f for f in design.score_families if f != "visits"], E=E, design=design):
        eb += part
    tables["equal_budget"] = eb

    say("  [analysis] secondary: top-k, tau-b and ties, concordance variants, mix weights, noise, cross-checks, "
        "pigeonhole bootstrap (in processes) ...")
    # fault 9: the secondary steps are independent of each other; each is one job (same rows as in one process)
    sec_jobs = ["topk", "tau", "variants", "mix", "second_bank", "ceiling_noise", "linearised"]
    if "ips" in injected:
        sec_jobs.append("ips")
    if raw:
        sec_jobs.append("pigeonhole")
    sec = dict(zip(sec_jobs, par_map(_job_secondary, sec_jobs, E=E, design=design, raw=raw, seed=seed,
                                     n_boot=n_boot, tests=tests)))
    tables["topk_pairs"], tables["topk_groups"] = sec["topk"]
    tables["tau_ties_pairs"], tables["tau_ties_groups"] = sec["tau"]
    tables["validity_variants_pairs"], tables["validity_variants_groups"] = sec["variants"]
    mw, mwp = sec["mix"]
    if mw:
        tables["mix_weight"], tables["mix_weight_pairs"] = mw, mwp
    elif results is not None:
        tables["mix_weight"] = mix_weight(design, results)
    tables["second_bank_drop"] = sec["second_bank"]
    if not tables["second_bank_drop"]:
        skipped.append("Second bank: none in this study, so 8.3.4 is skipped.")
    tables["model_ceiling"], tables["noise_reference_pairs"], tables["noise_reference_groups"] = sec["ceiling_noise"]
    if "ips" in sec:
        tables["exploratory_ips_pairs"], tables["exploratory_ips_groups"] = sec["ips"]
    cc = sec["linearised"] + sec.get("pigeonhole", [])
    tables["cross_checks"] = cc

    if results is not None:
        say("  [analysis] secondary analyses from the other result files ...")
        ex = validity_extras(design, results, vrows)
        tables["validity_extras"] = ex
        tables["validity_extras_groups"] = extras_by_group(design, ex)
        tables["shapley_summary"], tables["shapley_points"] = shapley_tables(design, results)
        if not tables["shapley_summary"]:
            skipped.append("Shapley realism check: no subsets stage in this study, so 8.3.2 is skipped.")
        tables["second_bank"] = second_bank(design, results)
        tables["second_wording"] = second_wording(design, results)
        if not tables["second_wording"]:
            skipped.append("Second prompt wording: none in this study, so 8.3.3 is skipped.")
        tables["check_arm_draws"] = check_arm_draws(design, results)
        tables["costs_by_model"], tables["costs_by_arm"] = cost_tables(design, results, run_dir)
        tables["sensitivity_status"] = sensitivity_status(results)
    if run_dir is not None:
        tables["online_arms"], tables["online_groups"], tables["online_curves"] = \
            online_tables(design, run_dir, n_boot, seed)
    if not tables.get("online_arms"):
        skipped.append("Run after the swap: no online stage in this study, so 2.10 and 8.2.6 are skipped.")

    tables["not_computed"] = not_computed(design, tables)
    tables["meta"] = meta_rows(design, data, n_boot, seed, deviations)
    if E.sh is not None:
        tables["meta"].append({"key": "noise_reference_of_R_adj", "value": E.sh_kind})
    tables["meta"] += [{"key": "primary_variance", "value": TW.variance_label},
                       {"key": "item_coding", "value": "item identity within (owner, stream), one cluster across the orders"},
                       {"key": "core_grid_models", "value": "; ".join(core_models(design))},
                       {"key": "task_clusters", "value": TW.n_task_clusters},
                       {"key": "item_clusters", "value": TW.n_item_clusters},
                       {"key": "bootstrap_clusters", "value": getattr(E.boot, "cluster", "")},
                       {"key": "primary_family_size", "value": sum(1 for r in tests if r.get("in_family"))}]
    for b_, o_ in ov.items():
        tables["meta"] += [{"key": f"task_overlap_{b_}_appearances", "value": o_["appearances"]},
                           {"key": f"task_overlap_{b_}_distinct", "value": o_["distinct"]},
                           {"key": f"task_overlap_{b_}_share_in_more_than_one_order",
                            "value": o_["share_in_more_than_one_order"]}]
    tables["notes"] = [{"kind": "skipped", "note": x} for x in skipped] + \
        [{"kind": "warning", "note": x} for x in warn]
    out.mkdir(parents=True, exist_ok=True)
    keep = {f"{k}.csv" for k, v in tables.items() if isinstance(v, list)}
    for old in out.glob("*.csv"):                       # no stale file from an earlier run
        # ...of this module: the files of the other producers in this folder (msr.construct, msr.theory,
        # msr.forecast, msr.sequential) are theirs to replace
        if old.name not in keep and not old.name.startswith(OTHER_PRODUCERS):
            old.unlink()
    paths = {}
    for name, rows in tables.items():
        if isinstance(rows, list):
            p = out / f"{name}.csv"
            write_csv(p, rows)
            paths[name] = p
    md = write_markdown(design, tables, out, deviations, skipped, warn)
    paths["ANALYSIS.md"] = md
    return {"tables": tables, "paths": paths, "out": out, "design": design}


def meta_rows(design: Design, data: PerTask, n_boot: int, seed: int, deviations: list) -> list:
    rows = [("study", design.name), ("study_kind", design.kind), ("all_models_simulated", design.all_sim),
            ("models", " ".join(design.models)),
            ("families_of_models", " ".join(f"{m}:{design.family[m]}" for m in design.models)),
            ("upgrades", " ".join(f"{a}->{b}" for a, b in design.upgrades)),
            ("streams", " ".join(design.streams)), ("orders", " ".join(map(str, sorted({s[1] for s in data.strata})))),
            ("evaluation_tasks_per_order", " ".join(f"{s[0]}/{s[1]}:{len(t)}" for s, t in data.tasks.items())),
            ("score_families", " ".join(design.score_families)), ("headline_family", design.headline),
            ("primary_k", design.primary_k), ("primary_lambda", design.primary_lambda),
            ("bootstrap_draws", n_boot), ("bootstrap_seed", seed), ("alpha", design.alpha),
            ("ni_fraction", design.ni_fraction), ("min_difference", design.min_difference),
            ("ratio_min_z", design.ratio_min_z), ("n_swaps", len(design.swaps())),
            ("n_upgrades", len(design.swaps("upgrade"))), ("n_downgrades", len(design.swaps("downgrade"))),
            ("n_cross", len(design.swaps("cross")))]
    rows += [(f"deviation_{j + 1}", d) for j, d in enumerate(deviations)]
    return [{"key": k, "value": v} for k, v in rows]


def not_computed(design: Design, tables: dict) -> list:
    """What the pre-registration asks for that this study's files do not allow (said plainly)."""
    out = [("8.2.12 logistic mixed model of first-shown success at the cell level",
            "replaced by the least-squares source-plus-target summary (amendment accepted 23 Nov 2026)"),
           ("8.3.3 wording variance component beside the repeat and task components",
            "variants.csv holds Cw per wording; the raw results under the second wording are not in results/"),
           ("8.3.6 labelled (memprompt) items", "a separate study (config/study_memprompt.yaml, DDXPlus, order 0); "
            "analyse it on its own and compare theta, D and R"),
           ("8.2.15 sampling sensitivity (Qwen pair at temperature 0.7)", "a separate study "
            "(config/study_temperature.yaml); analyse it on its own and compare theta of its two swaps"),
           ("8.4 the agent leg L3 (MemRL on LifelongAgentBench)", "its own pipeline (legs/memrl/); family L")]
    if not any(k in (128, 256) for k in design.k_values):
        out.append(("8.3.7 more fresh checks by look-up (k = 128, 256)", "not in this study's evaluate.k_values"))
    checks = {
        "topk_pairs": ("8.2.9 top-1 / top-2 agreement with intervals", "no per-task top-k hits in per_task/"),
        "tau_ties_pairs": ("8.2.7 Kendall tau-b and tie shares", "no tau / ties parts in per_task/"),
        "noise_reference_pairs": ("2.5 / 8.2.8 split-half references with intervals, R_adj", "no raw cells"),
        "model_ceiling": ("8.2.8 model-based ceiling", "no raw cells"),
        "exploratory_ips_pairs": ("8.3.5 inverse-propensity scores", "no ips_num / ips_den in the raw cells"),
        "validity_variants_pairs": ("8.2.7 / 8.2.14 concordance variants", "no variant parts in per_task/"),
    }
    for k, (a, why) in checks.items():
        if not tables.get(k):
            out.append((a, why))
    if not any(r.get("check", "").startswith("pigeonhole") for r in tables.get("cross_checks", [])):
        out.append(("4.6 pigeonhole bootstrap", "no item ids (raw cells) in this study's results"))
    return [{"analysis": a, "why": w} for a, w in out]


# ===========================================================================
# ANALYSIS.md
# ===========================================================================


def f3(x, d=3) -> str:
    if isinstance(x, str):
        return x
    return "–" if not fin(x) else f"{float(x):.{d}f}"


def ci(r, k, d=3, lo=None, hi=None) -> str:
    lo = lo or f"{k}_lo"
    hi = hi or f"{k}_hi"
    if not fin(r.get(k)):
        return "–"
    if r.get(lo) in (-math.inf,) or r.get(hi) in (math.inf,):
        return f"{f3(r[k], d)} [unbounded]"
    return f"{f3(r[k], d)} [{f3(r.get(lo), d)}, {f3(r.get(hi), d)}]"


def pf(p) -> str:
    if not fin(p):
        return "–"
    return f"{p:.4f}" if p >= 0.0001 else f"{p:.1e}"


def write_md_secondary(design: Design, T: dict, w) -> None:
    """ANALYSIS.md sections of the secondary and exploratory analyses built on the per-task and raw
    files: noise references and R_adj, top-k, tau-b and ties, concordance variants, mix weights,
    second bank, IPS, model-based ceiling."""
    H = design.headline
    gv = {(r["family"], r["group"]): r for r in T["group_validity"] if r["level"] == "all"}
    if any("R_adj_status" in r for r in gv.values()):
        w(f"## Noise-adjusted retained validity R_adj (secondary; family `{H}`)")
        w("")
        kind_ = next((r["value"] for r in T["meta"] if r["key"] == "noise_reference_of_R_adj"), "split-half")
        w("R_adj = [(C_swap − 0.5) / (ref_reader − 0.5)] / [(C_home − 0.5) / (ref_owner − 0.5)], ref = each model's "
          f"split-half noise reference on its own home cells ({kind_}) [meta.csv: noise_reference_of_R_adj]. Shown "
          "beside R, never in place of it, and only where R is reported and both references exceed 0.5 by 4 SE. "
          "Group values use the means of the noise-normalised C.")
        w("")
        w("| group | R [95 % CI] | R_adj [95 % CI] |")
        w("|---|---|---|")
        for g in GROUPS + ("all_swaps",):
            r = gv.get((H, g))
            if r:
                ra = ci(r, "R_adj") if str(r.get("R_adj_status", "")).startswith("reported") else r.get("R_adj_status", "–")
                w(f"| {g} | {ci(r, 'R') if r['R_status'] == 'reported' else r['R_status']} | {ra} |")
        w("")
        w(f"Source: `group_validity.csv` (family={H}, level=all, columns R*, R_adj*); per pair: the R_adj column of the "
          "per-pair validity table above (`validity_pairs.csv`).")
        w("")
    if T.get("noise_reference_pairs"):
        w("## Split-half noise references (2.5, 8.2.8) with intervals, and the model-based ceiling")
        w("")
        w("| owner → reader | group | split-half C_SH [95 % CI] | home: repeats 1-2 vs 3-4 | noise-normalised Cw | model-based ceiling |")
        w("|---|---|---|---|---|---:|")
        for r in T["noise_reference_pairs"]:
            if r["level"] == "all":
                w(f"| {r['owner']} → {r['reader']} | {r['group']} | {ci(r, 'split_half')} | "
                  f"{ci(r, 'split_half_extra') if 'split_half_extra' in r else '–'} | {ci(r, 'C_noise_normalised')} | "
                  f"{f3(r.get('model_ceiling'))} |")
        w("")
        w("Source: `noise_reference_pairs.csv` (level=all; per stream: level = the stream), group means in "
          "`noise_reference_groups.csv`, the fitted logistic random-effects models in `model_ceiling.csv`. The split-half "
          "value is a noise reference, not an upper bound; the model-based ceiling is model-based.")
        w("")
    tk = [r for r in T.get("topk_groups", []) if r["family"] == H and r["level"] == "all" and r["group"] in GROUPS + ("home",)]
    if tk:
        w(f"## Top-1 and top-2 agreement (2.9; family `{H}`)")
        w("")
        w("| k | group | agreement after the swap [95 % CI] | chance | minus chance [95 % CI] | at home |")
        w("|---|---|---|---:|---|---:|")
        for r in tk:
            w(f"| {r['k']} | {r['group']} | {ci(r, 'agreement_after')} | {f3(r['chance_after'])} | "
              f"{ci(r, 'after_minus_chance')} | {f3(r['agreement_home'])} |")
        w("")
        w("Source: `topk_groups.csv` (family, k, group, level=all); per pair: `topk_pairs.csv`.")
        w("")
    tt = [r for r in T.get("tau_ties_groups", []) if r["family"] == H and r["level"] == "all"]
    if tt:
        w(f"## Kendall's tau-b and ties in the score (8.2.7; family `{H}`)")
        w("")
        w("| group | tau-b at home | tau-b after [95 % CI] | tau-b drop [95 % CI] | tie share after |")
        w("|---|---:|---|---|---:|")
        for r in tt:
            w(f"| {r['group']} | {f3(r.get('tau_b_home'))} | {ci(r, 'tau_b_after')} | {ci(r, 'tau_b_drop')} | "
              f"{f3(r.get('tie_share_after'))} |")
        w("")
        w("Source: `tau_ties_groups.csv` (family, group, level=all); per pair: `tau_ties_pairs.csv`.")
        w("")
    vg = [r for r in T.get("validity_variants_groups", []) if r["family"] == H and r["level"] == "all"
          and r["group"] in GROUPS + ("home",)]
    if vg:
        w(f"## Concordance variants (8.2.7, 8.2.14, 8.3.4; family `{H}`): the drop D and R under each")
        w("")
        w("| variant | group | Cw home | Cw after | D [95 % CI] | R |")
        w("|---|---|---:|---:|---|---|")
        for r in vg:
            w(f"| {r['variant']} | {r['group']} | {f3(r['C_home'])} | {f3(r['C_swap'])} | {ci(r, 'D')} | "
              f"{f3(r['R']) if r['R_status'] == 'reported' else r['R_status']} |")
        w("")
        w("Variants: " + "; ".join(f"`{v.lstrip('_')}` = {m}" for v, m in VARIANTS) + ". Source: "
          "`validity_variants_groups.csv` (family, variant, group, level); per pair: `validity_variants_pairs.csv`. "
          "Other counters ranked by helpful − harmful appear under family beta_grade and tags_self, variant `net`.")
        w("")
    sb = [r for r in T.get("second_bank_drop", []) if r["family"] == H and r["level"] == "all"]
    if sb:
        w(f"## Second independent bank (8.3.4; family `{H}`): the drop under each bank")
        w("")
        w("| owner → reader | D, bank 1 | D, bank 2 | bank 2 − bank 1 [95 % CI] |")
        w("|---|---:|---:|---|")
        for r in sb:
            w(f"| {r['owner']} → {r['reader']} | {f3(r['D_bank1'])} | {f3(r['D_bank2'])} | {ci(r, 'D_bank2_minus_bank1')} |")
        w("")
        w("Source: `second_bank_drop.csv` (family, owner, reader, level=all).")
        w("")
    mw = [r for r in T.get("mix_weight", []) if "mix" in r and r["family"] == H and r["arm"] == "keep"
          and r["group"] in GROUPS + ("all_swaps",)]
    if mw:
        w(f"## Mix weight (8.3.1, exploratory; family `{H}`): keep − wipe on first-shown success under each mix")
        w("")
        w("| mix | group | keep | keep − wipe [95 % CI] |")
        w("|---|---|---:|---|")
        for r in mw:
            w(f"| {r['mix_meaning']} | {r['group']} | {f3(r.get('est'))} | {ci(r, 'keep_minus_wipe')} |")
        w("")
        w("Source: `mix_weight.csv` (family, mix, arm, group); per pair: `mix_weight_pairs.csv`.")
        w("")
    ips = [r for r in T.get("exploratory_ips_groups", []) if r["level"] == "all" and r["group"] in GROUPS + ("home",)]
    if ips:
        w("## Inverse-propensity scores (8.3.5, exploratory)")
        w("")
        w("Self-normalised IPS score per item, sum(y / π) / sum(1 / π) over its score-phase shows; never-shown items "
          "sit at 0.5.")
        w("")
        w("| group | Cw home | Cw after | D [95 % CI] | R |")
        w("|---|---:|---:|---|---|")
        for r in ips:
            w(f"| {r['group']} | {f3(r['C_home'])} | {f3(r['C_swap'])} | {ci(r, 'D')} | "
              f"{f3(r['R']) if r['R_status'] == 'reported' else r['R_status']} |")
        w("")
        w("Source: `exploratory_ips_groups.csv` (group, level=all); per pair: `exploratory_ips_pairs.csv`.")
        w("")


def write_markdown(design: Design, T: dict, out: Path, deviations: list, skipped: list | None = None,
                   warn: list | None = None) -> Path:
    H = design.headline
    L: list = []
    w = L.append
    w(f"# Analysis of study `{design.name}` (study kind: {design.kind})")
    w("")
    fam = [r for r in T["primary_tests"] if r.get("in_family")]
    out_of = [r for r in T["primary_tests"] if not r.get("in_family") and r.get("role", "primary") == "primary"]
    n_reg = len(PRIMARY_HYPOTHESES) * len(GROUPS)
    if out_of:
        empty = [g for g in GROUPS if not design.swaps(g)]
        other = [r for r in out_of if r["group"] not in empty]
        parts = []
        if empty:
            parts.append("this study has no " + " and no ".join(GROUP_LABEL[g] for g in empty)
                         + f", so the four hypotheses are tested on the {' and '.join(GROUP_LABEL[g] for g in GROUPS if g not in empty)} only")
        if other:
            parts.append("not computable here: " + "; ".join(f"{r['test']} ({r.get('note', 'missing input')})" for r in other))
        w(f"**The confirmatory family has {len(fam)} tests here, not {n_reg}:** " + "; ".join(parts)
          + f". Holm runs over the {len(fam)} that exist [primary_tests.csv, column in_family].")
    else:
        w(f"The confirmatory family has all {len(fam)} pre-registered tests (4 hypotheses: PC1-drop, PC1-MD, PC1-NI, "
          f"PC2, x 3 swap groups), Holm over {len(fam)}; PC3 and PC4 are secondary [primary_tests.csv].")
    w("")
    for x in (warn or []):
        w(f"**WARNING: {x}.** Fix the study file before the confirmatory run [notes.csv].")
        w("")
    if design.kind == "simulated":
        w("**SIMULATED DATA.** The study contains simulated models (msr/sim.py) with a known truth. "
          "Nothing here is a finding about real models; it checks that the analysis machinery recovers the truth.")
        w("")
    elif design.kind == "preliminary":
        w("**PRELIMINARY: free models through a wrapper** (provider `opencode_cli`). Not the pre-registered models "
          "or routes; nothing here is a confirmatory result.")
        w("")
    meta = {r["key"]: r["value"] for r in T["meta"]}
    w("Made by `python -m msr.analysis` from the files in `results/` (no model was called). It follows "
      "`prediction/PREREGISTRATION.md` Parts 2-8. Every number below comes from a CSV file in this folder; the "
      "file and the row are named under each table or in brackets after each number.")
    w("")
    w("## What was analysed")
    w("")
    w(f"- Models: {meta['models']} (makers: {meta['families_of_models']}); upgrades: {meta['upgrades'] or 'none'}. "
      f"Swaps: {meta['n_swaps']} ({meta['n_upgrades']} upgrades, {meta['n_downgrades']} downgrades, "
      f"{meta['n_cross']} cross-maker) [meta.csv].")
    w(f"- Streams: {meta['streams']}; orders: {meta['orders']}; evaluation tasks per order: "
      f"{meta['evaluation_tasks_per_order']} [meta.csv].")
    w(f"- Headline family `{H}`; PC3 uses λ = {design.primary_lambda:g}; PC4 uses k = {design.primary_k}. "
      f"Primary variance: {meta.get('primary_variance', '')} ({meta.get('task_clusters', '?')} task clusters, "
      f"{meta.get('item_clusters', '?')} item clusters coded by identity across the orders; delete-one-cluster "
      f"jackknife in each dimension, MacKinnon, Nielsen and Webb 2023, combined as Cameron, Gelbach and Miller 2011, "
      f"items as multiple membership). Secondary, task-only bootstrap: {int(meta['bootstrap_draws']):,} draws, seed "
      f"{meta['bootstrap_seed']}, task ids resampled per stream with all their appearances in every order, applied "
      "to every pair, arm and family [meta.csv].")
    ovk = [k for k in meta if k.startswith("task_overlap_") and k.endswith("_share_in_more_than_one_order")]
    for k in ovk:
        b_ = k[len("task_overlap_"):-len("_share_in_more_than_one_order")]
        w(f"- Task overlap across orders, stream {b_}: {meta.get(f'task_overlap_{b_}_appearances')} evaluation-task "
          f"appearances, {meta.get(f'task_overlap_{b_}_distinct')} distinct tasks, share of appearances whose task "
          f"sits in another order too: {f3(num(meta[k]))} [meta.csv].")
    if deviations:
        w("- Differences from the pre-registered design (this study's own settings) [meta.csv, deviation_*]:")
        for d in deviations:
            w(f"  - {d}")
    w("")
    w("How to read: theta (the retained ranking signal, the headline) = V after the swap / V at home, where V "
      "sums, over the candidate pairs of every task, the outcome difference signed by the old score order; 1 = all "
      "of the home ranking signal kept, 0 = none, below 0 = reversed. Outcome noise does not move it. theta and its "
      "Fieller set are always shown (an unbounded set is a valid answer); its flag 'defined' means the owner's "
      "signal on its calibration tasks (which no estimate uses) is at least 2 standard errors above 0 "
      "(msr.metrics.home_signal_flag). Every PC1 claim is an intersection-union test: the home signal is shown "
      "positive AND the linear contrast rejects (the drop test also beyond the owner's second home session), so "
      "no claim can come from a non-positive home signal; the reading of a group is a function of its three "
      "tests only (msr.metrics.pc1_label). theta = order x stakes: stakes = sqrt(S_reader / S_owner), how much "
      "the reader's outcomes spread across a task's candidates relative to the owner's (cross-repeat products), "
      "and order = theta / stakes, how well the old order still fits the reader ('not identifiable' when the "
      "reader's spread on the calibration tasks is under 2 SE). Secondary: Cw (weighted "
      "concordance, 0.5 = coin toss), D = Cw at home − Cw after, R = (Cw after − 0.5) / (Cw home − 0.5) = theta x "
      "(outcome spread at home / after), which moves with the reader's outcome noise. Primary intervals: two-way "
      "jackknife (task id x item); theta's is a Fieller interval.")
    w("")

    # ---- primary tests
    w(f"## The primary tests (4 hypotheses x 3 swap groups, Holm over {len(fam)})")
    w("")
    w("| test | hypothesis (H1) | estimate [95 % CI] | p | Holm threshold | Holm-adjusted p | rejected | item share | "
      "effective items | decision |")
    w("|---|---|---|---:|---:|---:|---|---:|---:|---|")
    for r in T["primary_tests"]:
        if r.get("role", "primary") != "primary":
            continue
        w(f"| {r['test']} | {r.get('hypothesis', '–')} | {ci(r, 'est', 4, 'lo', 'hi')} | {pf(r.get('p_holm_input'))} | "
          f"{pf(r.get('holm_threshold'))} | {pf(r.get('holm_adjusted_p'))} | {'yes' if r.get('holm_reject') else 'no'} | "
          f"{f3(r.get('item_share'), 2)} | {f3(r.get('eff_items'), 1)} | {r.get('decision', '')} |")
    w("")
    w("Source: `primary_tests.csv`, rows with role = primary. PC1-drop, PC1-MD and PC1-NI are separate members of "
      "the Holm family, each an intersection-union test with the home-sign test (p = the largest of its parts; "
      "p_home beside it). The PC1 reading of a group is msr.metrics.pc1_label of its three Holm decisions: "
      "'material drop shown', 'small drop shown' (theta < 1 and theta > 0.75 both shown), 'drop shown', 'no "
      "material drop shown' or 'inconclusive' (never read as 'no drop'). Item share = share of the variance due to "
      "the items; effective items = the item clusters' effective number (concern below 10 or item share >= 0.5).")
    w("")
    sec = [r for r in T["primary_tests"] if r.get("role") == "secondary"]
    if sec:
        w("### Secondary: swap-minus-home contrasts PC3 and PC4 (outside the family)")
        w("")
        w("| test | estimate [95 % CI] | p (unadjusted) | owner − reader base rate | with-item level target: "
          "estimate [95 % CI] | reading |")
        w("|---|---|---:|---|---|---|")
        for r in sec:
            w(f"| {r['test']} | {ci(r, 'est', 4, 'lo', 'hi')} | {pf(r.get('p_holm_input'))} | "
              f"{ci(r, 'base_gap', 3, 'base_gap_lo', 'base_gap_hi')} | {ci(r, 'est_lcw', 4, 'lo_lcw', 'hi_lcw')} | "
              f"{r.get('decision', '')} |")
        w("")
        w(f"Assumption: {ADDITIVITY}. Source: `primary_tests.csv`, rows with role = secondary.")
        w("")
    gre = {(r["comparison"], r["group"]): r for r in T.get("group_re", [])}
    if gre:
        w("### Between-pair spread per group and the prediction interval for a new pair")
        w("")
        w("| group | quantity | pairs | random-effects mean | between-pair SD [95 % CI] | prediction interval |")
        w("|---|---|---:|---|---|---|")
        for r in T["group_re"]:
            if r["group"] in GROUPS:
                w(f"| {r['group_label']} | {r['comparison']} | {r['k']} | {f3(r['re_mean'], 4)} | "
                  f"{ci(r, 'tau', 4, 'tau_lo', 'tau_hi')} | [{f3(r['pi_lo'], 3)}, {f3(r['pi_hi'], 3)}] |")
        w("")
        w("Source: `group_re.csv` (DerSimonian-Laird, Q-profile interval, t with k − 2 df; the pairs of a group share "
          "models, so this describes these pairs).")
        w("")
    for r in T["primary_tests"]:
        if r["comparison"] == "PC1-drop" and fin(r.get("theta")):
            w(f"- **{r['group_label']}** ({r['n_swaps']} swaps): theta {ci(r, 'theta', 3, 'theta_lo', 'theta_hi')} "
              f"(two-way Fieller; task-only bootstrap [{f3(r.get('theta_lo_task_boot'))}, "
              f"{f3(r.get('theta_hi_task_boot'))}]) = order {ci(r, 'order', 3, 'order_lo', 'order_hi')} "
              f"({r.get('order_status', '')}) x stakes {ci(r, 'stakes', 3, 'stakes_lo', 'stakes_hi')}; p_home "
              f"{pf(r.get('p_home'))}, p_drop {pf(r.get('p_drop'))}, p_MD {pf(r.get('p_md'))}, p_NI {pf(r.get('p_ni'))}"
              f"; reading: {r.get('label', '')}; "
              f"self-swap theta {f3(r.get('theta_self'))} (loss reference {f3(r.get('loss_self_hi'))}); secondary: "
              f"C̄_home {f3(r.get('C_home'))}, C̄_swap {f3(r.get('C_swap'))}, D {ci(r, 'D')}, R {ci(r, 'R')}; spread "
              f"of the per-pair loss 1 − theta: {f3(r.get('spread_min'))} ({r.get('spread_min_pair', '')}) … "
              f"{f3(r.get('spread_max'))} ({r.get('spread_max_pair', '')}), opposite-sign share "
              f"{f3(r.get('spread_opposite_share'), 2)} [primary_tests.csv: {r['test']}].")
        if r["comparison"] == "PC2" and fin(r.get("est")):
            w(f"- **{r['test']}**: after the swap {ci(r, 'est', 4, 'lo', 'hi')}; at home "
              f"{ci(r, 'home_est', 4, 'home_lo', 'home_hi')} (success points; task-only interval "
              f"[{f3(r.get('lo_task'), 4)}, {f3(r.get('hi_task'), 4)}]) [primary_tests.csv: {r['test']}].")
        if r["comparison"] in ("PC3", "PC4") and fin(r.get("est")):
            w(f"- **{r['test']}** ({r.get('metric', '')}): swap minus home {ci(r, 'est', 4, 'lo', 'hi')} = after "
              f"{f3(r.get('swap_est'), 4)} − home {f3(r.get('home_est'), 4)}"
              + (f"; recal − wipe: swap minus home {ci(r, 'est_b', 4, 'lo_b', 'hi_b')}" if r["comparison"] == "PC4" else "")
              + f". Beside it, in success points: first-shown success, swap minus home {ci(r, 'fs_did', 4, 'fs_did_lo', 'fs_did_hi')}"
              f" (after the swap {f3(r.get('fs_swap'), 4)}); raw (uncorrected) log score, swap minus home "
              f"{f3(r.get('raw_log_did'), 4)} [primary_tests.csv: {r['test']}].")
    w("")

    # ---- stakes
    if T.get("stakes"):
        w(f"## What is at stake, in success points (family `{H}`; two-way 95 % intervals)")
        w("")
        w("| group | contrast | at home | after the swap | after minus home |")
        w("|---|---|---|---|---|")
        for r in T["stakes"]:
            w(f"| {r['group_label']} | {r['contrast']} | {ci(r, 'home', 3, 'home_lo', 'home_hi')} | "
              f"{ci(r, 'swap', 3, 'swap_lo', 'swap_hi')} | {ci(r, 'swap_minus_home', 3, 'swap_minus_home_lo', 'swap_minus_home_hi')} |")
        w("")
        w("Source: `stakes.csv`, one row per (group, contrast). First-shown success differences (0.01 = 1 point). "
          "'At home' uses each swap's owner on its own bank; `ceiling` is the best candidate by both repeats, "
          "scored in-sample (an upper reference, biased upward).")
        w("")

    # ---- theta per pair
    tp = [r for r in T.get("theta_pairs", []) if r["family"] == H and r["level"] == "all"]
    if tp:
        w(f"## theta per pair (family `{H}`, pooled over streams)")
        w("")
        w("| owner → reader | group | theta [two-way 95 % CI] | order | stakes | task-only bootstrap CI | p_drop | "
          "p_MD | p_NI | R | spread ratio | unadjusted | Holm over all swaps (3 members each) |")
        w("|---|---|---|---|---|---|---:|---:|---:|---:|---:|---|---|")
        for r in tp:
            w(f"| {r['owner']} → {r['reader']} | {r['group']} | {ci(r, 'theta', 3, 'theta_lo', 'theta_hi')} "
              f"({r.get('theta_status_calibration', r['theta_status'])}) | {f3(r.get('order'))} | {f3(r.get('stakes'))} | "
              f"[{f3(r.get('theta_lo_task_boot'))}, {f3(r.get('theta_hi_task_boot'))}] | "
              f"{pf(r.get('p_drop'))} | {pf(r.get('p_md'))} | {pf(r.get('p_ni'))} | {f3(r.get('R'))} | "
              f"{f3(r.get('spread_ratio'))} | {r.get('category_unadjusted', '')} | {r.get('holm_category', '')} |")
        w("")
        w("Source: `theta_pairs.csv` (every score family, every level; home rows hold the self-swap theta from the "
          "extra repeats 3-4). Spread ratio = R / theta = outcome spread at home / after the swap.")
        w("")
    w("Descriptive average over all swaps (8.2.2, no test): " + "; ".join(
        f"{r['comparison']} {r['statistic']} {ci(r, 'est', 4, 'lo', 'hi')}" for r in T["all_swaps_descriptive"])
      + " [all_swaps_descriptive.csv].")
    w("")

    # ---- per-pair validity
    w(f"## Per-pair concordance, D and R (secondary; family `{H}`, pooled over streams)")
    w("")
    sh = {(r["owner"], r["reader"]): r for r in T.get("validity_extras", []) if r["family"] == H and r["level"] == "all"}
    w("| owner → reader | group | Cw home | Cw after | D [95 % CI] | owner's U_self | beyond floor | R [95 % CI] | "
      "unadjusted category | Holm (all swaps) | shuffled Cw after | R_adj [95 % CI] |")
    w("|---|---|---:|---:|---|---:|---|---|---|---|---:|---|")
    for r in T["validity_pairs"]:
        if r["family"] != H or r["level"] != "all":
            continue
        rtxt = ci(r, "R") if r["R_status"] == "reported" else "undefined: home signal too weak"
        shv = r.get("C_swap_shuffled", sh.get((r["owner"], r["reader"]), {}).get("swap_shuffled"))
        w(f"| {r['owner']} → {r['reader']} | {r['group']} | {f3(r['C_home'])} | {f3(r['C_swap'])} | {ci(r, 'D')} | "
          f"{f3(r['U_self'])} | {'yes' if r['D_beyond_floor'] else 'no'} | {rtxt} | {r['category_unadjusted']} | "
          f"{r.get('holm_category', '')} | {f3(shv)} | "
          f"{ci(r, 'R_adj') if str(r.get('R_adj_status', '')).startswith('reported') else r.get('R_adj_status', '–')} |")
    w("")
    w("Holm (all swaps), the secondary per-pair flag of 5.2: the drop test and the no-material-drop test of every "
      "swap are two separate members, Holm over twice the number of swaps [validity_pairs.csv, columns "
      "holm_members, holm_p_drop, holm_p_ni, holm_category].")
    w("")
    w(f"Source: `validity_pairs.csv`, rows family={H}, level=all, one per (owner, reader); home rows (owner = "
      "reader) show the self-swap: 'after' is the extra home repeats. Per-stream rows have level = the stream. "
      f"Shuffled control: column C_swap_shuffled (with its interval) of the same rows, or `validity_extras.csv` "
      "column swap_shuffled for result files without per-task shuffled parts.")
    w("")

    # ---- per-pair PC2-PC4
    K = design.primary_k
    names = ["PC2 keep - wipe", "PC3 fixed - keep", f"PC4a recal_{K} - keep", f"PC4b recal_{K} - wipe"]
    cp = {(r["contrast"], r["owner"], r["reader"]): r for r in T["contrasts_pairs"]
          if r["family"] == H and r["level"] == "all"}
    w(f"## Per-pair PC2-PC4 (family `{H}`, pooled over streams)")
    w("")
    w("| owner → reader | group | keep − wipe, first-shown success | fixed − keep, log score | "
      f"recal_{K} − keep, log score | recal_{K} − wipe, log score |")
    w("|---|---|---|---|---|---|")
    for c in design.swaps():
        cells = [cp.get((n, c[0], c[1])) for n in names]
        w(f"| {c[0]} → {c[1]} | {design.group(*c)} | " + " | ".join(
            (ci(x, "est", 3, "lo", "hi") + (" *" if x.get("holm56_reject") else "")) if x else "–" for x in cells) + " |")
    w("")
    w(f"Source: `contrasts_pairs.csv`, rows family={H}, level=all, contrast = the column name. * = Holm-adjusted "
      "across the swaps (secondary flag, column `holm56_reject`).")
    w("")

    # ---- heterogeneity
    w(f"## Heterogeneity inside each swap stratum (family `{H}`)")
    w("")
    w("| comparison | group | mean | range (min … max) | opposite-sign share | between-pair SD [95 % CI] | "
      "SD source / target / pair | SD of predicted pair effects |")
    w("|---|---|---:|---|---:|---|---|---:|")
    for r in T["heterogeneity"]:
        if r["family"] != H:
            continue
        w(f"| {r['comparison']} | {r['group']} | {f3(r['group_mean'], 4)} | {f3(r['min'], 4)} ({r['min_pair']}) … "
          f"{f3(r['max'], 4)} ({r['max_pair']}) | {f3(r['opposite_sign_share'], 2)} | "
          f"{f3(r['sd_between'], 4)} [{f3(r['sd_between_lo'], 4)}, {f3(r['sd_between_hi'], 4)}] | "
          f"{f3(r['sd_source'], 4)} / {f3(r['sd_target'], 4)} / {f3(r['sd_pair'], 4)} | "
          f"{f3(r['pred_effect_sd_in_group'], 4)} |")
    w("")
    w(f"Source: `heterogeneity.csv`, rows family={H}, (comparison, group). The model is fitted by least squares over "
      "all swaps: estimate = μ + stratum + source + target + pair (streams averaged first); SD pair = "
      "√max(0, residual variance − mean bootstrap variance). Model effects per model: `heterogeneity_model_effects.csv`.")
    w("")
    w("**Amendment to Part 8.2.12 (accepted by the research manager, 23 Nov 2026):** the between-pair SD comes from "
      "this least-squares source-plus-target model with the moment estimate of the pair variance, in place of the "
      "crossed random-effects model with known bootstrap variances; the cell-level logistic version is not fitted.")
    w("")

    # ---- predictions
    w("## Predictions P1-P4 (Holm over the four, one-sided)")
    w("")
    w("| prediction | statistic | value | p (one-sided) | Holm-adjusted p | result | contradicted | leave-one-model-out range |")
    w("|---|---|---:|---:|---:|---|---|---|")
    for r in T["predictions"]:
        w(f"| {r['prediction']}: {r['statement']} | {r.get('statistic', '–')} | {f3(r.get('value'))} | "
          f"{pf(r.get('p_one_sided'))} | {pf(r.get('holm_adjusted_p'))} | {r['result']} | "
          f"{'yes' if r.get('contradicted') else 'no'} | {f3(r.get('lomo_min'))} … {f3(r.get('lomo_max'))} |")
    w("")
    w("Source: `predictions.csv` (one row per prediction; `min_possible_p` is the smallest p the permutation test "
      "can give), the 8 leave-one-model-out values in `predictions_lomo.csv`, secondary versions in "
      "`predictions_secondary.csv`, and the per-swap points (κ, theta, G, X) in `prediction_points.csv`. P1, P3 "
      "and P4 read theta since the round-1 revision; the paper reports P1-P4 in an appendix.")
    for r in T["predictions"]:
        if fin(r.get("min_possible_p")) and r["min_possible_p"] > design.alpha / 4:
            w(f"- {r['prediction']}: with {r.get('n_permutations')} permutations the smallest possible p is "
              f"{pf(r['min_possible_p'])}, so this test cannot pass at Holm level in this study "
              f"[predictions.csv: {r['prediction']}, min_possible_p].")
    if T.get("prediction_points"):
        w("")
        w("Per swap, the quantities behind P1, P2 and P4 (`prediction_points.csv`, one row per (owner, reader)):")
        w("")
        gcols = [k for k in T["prediction_points"][0] if k.startswith("G_") or k.startswith("X_reader_")]
        w("| owner → reader | group | κ (calibration tasks) | theta | " + " | ".join(gcols) + " |")
        w("|---|---|---:|---:|" + "---:|" * len(gcols))
        for r in T["prediction_points"]:
            w(f"| {r['owner']} → {r['reader']} | {r['group']} | {f3(r['kappa'])} | "
              f"{f3(r['theta']) if r['theta_defined'] else 'undef.'} | " + " | ".join(f3(r[k]) for k in gcols) + " |")
        w("")
    for r in T["predictions_secondary"]:
        w(f"- Secondary, {r['prediction']}, {r['analysis']}: {f3(r.get('value'))}"
          + (f" [{f3(r.get('lo'))}, {f3(r.get('hi'))}]" if fin(r.get("lo")) else "")
          + f", one-sided p {pf(r.get('p_one_sided'))} [predictions_secondary.csv].")
    w("")

    # ---- arms
    ga = {(r["family"], r["arm"], r["metric"], r["group"]): r for r in T["arms_groups"] if r["level"] == "all"}
    main = ["none", "relevance", "keep", "wipe", f"fixed_{design.primary_lambda:g}", "shuffled"] + \
        ([f"{a}_{K}" for a in CHECK_ARMS] if K else []) + ["constant", "own", "split_half", "ceiling"]
    for metric in ("value", "regret", "log", "brier", "log_lc", "brier_lc"):
        w(f"## Arms by swap stratum: {METRIC_LABEL[metric]} (family `{H}`, pooled over streams)")
        w("")
        gs = [g for g in GROUPS + ("all_swaps", "home") if design.swaps(g)]
        w("| arm | " + " | ".join(GROUP_LABEL[g] for g in gs) + " |")
        w("|---|" + "---|" * len(gs))
        for a in main:
            fam = NO_FAMILY if a in NO_FAMILY_ARMS else H
            cells = [ga.get((fam, a, metric, g)) for g in gs]
            if not any(cells):
                continue
            w(f"| {a} | " + " | ".join(ci(x, "est", 3, "lo", "hi") if x else "–" for x in cells) + " |")
        w("")
        w(f"Source: `arms_groups.csv`, rows level=all, metric={metric}, family={H} (or '-' for none, relevance, "
          "split_half, ceiling), (arm, group). Columns `minus_keep*`, `minus_wipe*` and `minus_ceiling*` hold the "
          "paired differences with their task-only intervals. `split_half` picks on one repeat and scores on the "
          "other (a reference, not a bound); `ceiling` is the in-sample best candidate. The k-curves are in "
          "`kcurve.csv`.")
        w("")
        pa = {(r["family"], r["arm"], r["owner"], r["reader"]): r for r in T["arms_pairs"]
              if r["metric"] == metric and r["level"] == "all"}
        cols = [a for a in main if any(k[1] == a for k in pa)]
        if cols:
            w(f"Per pair, {METRIC_LABEL[metric]} (point values; intervals in `arms_pairs.csv`, rows metric={metric}, "
              "level=all, (family, arm, owner, reader)):")
            w("")
            w("| owner → reader | group | " + " | ".join(cols) + " |")
            w("|---|---|" + "---:|" * len(cols))
            for c in design.swaps() + design.swaps("home"):
                vals = [pa.get((NO_FAMILY if a in NO_FAMILY_ARMS else H, a, c[0], c[1])) for a in cols]
                w(f"| {c[0]} → {c[1]} | {design.group(*c)} | " + " | ".join(f3(v["est"]) if v else "–" for v in vals) + " |")
            w("")
    eb = [r for r in T["equal_budget"] if r["family"] == H and r["k"] == K and r["group"] == "all_swaps"]
    if eb:
        w(f"Equal budgets at k = {K}, all swaps (family `{H}`): " + "; ".join(
            f"{r['contrast']} ({r['metric']}) {ci(r, 'est', 4, 'lo', 'hi')}" for r in eb)
          + " [equal_budget.csv: family, k, contrast, metric, group=all_swaps].")
        w("")

    # ---- controls and secondary
    w("## Controls")
    w("")
    gsh = [r for r in T["group_validity"] if r["family"] == H and r["level"] == "all" and "C_swap_shuffled" in r]
    if gsh:
        for r in gsh:
            if r["group"] in GROUPS + ("all_swaps", "home"):
                w(f"- Content-only control (old scores handed to the wrong items), {GROUP_LABEL[r['group']]}: Cw after "
                  f"{ci(r, 'C_swap_shuffled')}, at home {ci(r, 'C_home_shuffled')} (0.5 = coin) "
                  f"[group_validity.csv: family={H}, group={r['group']}, level=all, columns C_*_shuffled].")
    else:
        for r in T.get("validity_extras_groups", []):
            if r["family"] == H and r["group"] in ("all_swaps", "home"):
                w(f"- Content-only control (old scores handed to the wrong items), {GROUP_LABEL[r['group']]}: Cw after "
                  f"{f3(r['swap_shuffled'])}, at home {f3(r['home_shuffled'])} (0.5 = coin) "
                  f"[validity_extras_groups.csv: family={H}, group={r['group']}].")
    for r in T.get("validity_extras_groups", []):
        if r["family"] == H and r["group"] in GROUPS and fin(r.get("top1_swap_chance")):
            w(f"- Top-1 agreement after the swap, {GROUP_LABEL[r['group']]}: {f3(r['top1_swap'])} (chance "
              f"{f3(r['top1_swap_chance'])}); top-2 {f3(r['top2_swap'])} (chance {f3(r['top2_swap_chance'])}) "
              f"[validity_extras_groups.csv: family={H}, group={r['group']}].")
    for r in T["group_validity"]:
        if r["family"] == H and r["group"] == "home" and r["level"] == "all":
            w(f"- Self-swap reference, mean over the {r['n_swaps']} home cells: D̄self {ci(r, 'D')} (expected 0) "
              f"[group_validity.csv: family={H}, group=home, level=all, column D].")
    for r in T["arms_groups"]:
        if r["family"] == NO_FAMILY and r["arm"] in ("none", "relevance") and r["metric"] == "value" \
                and r["group"] == "all_swaps" and r["level"] == "all":
            w(f"- Baseline `{r['arm']}`, first-shown success over all swaps: {ci(r, 'est', 3, 'lo', 'hi')} "
              f"[arms_groups.csv: family=-, arm={r['arm']}, metric=value, group=all_swaps, level=all].")
    w("")

    w("## Every score family (secondary 8.2.4): concordance, D and R by swap group")
    w("")
    w("| family | group | Cw home | Cw after | D [95 % CI] | R [95 % CI] | D, pair-count weighted | D, unweighted C |")
    w("|---|---|---:|---:|---|---|---:|---|")
    for r in T["group_validity"]:
        if r["level"] == "all" and r["group"] in GROUPS + ("home",):
            rtxt = ci(r, "R") if r["R_status"] == "reported" else r["R_status"]
            w(f"| {r['family']} | {r['group']} | {f3(r['C_home'])} | {f3(r['C_swap'])} | {ci(r, 'D')} | {rtxt} | "
              f"{f3(r.get('D_pairweighted'))} | {ci(r, 'D_u') if 'D_u' in r else '–'} |")
    w("")
    w("Source: `group_validity.csv`, rows level=all, (family, group); the last two columns are the secondary "
      "pair-count-weighted pooling (2.12) and the unweighted concordance (8.2.7). Per-stream rows have level = the stream.")
    w("")
    fams = [f for f in design.score_families if any(r["family"] == f for r in T["validity_pairs"])]
    vp = {(r["family"], r["owner"], r["reader"]): r for r in T["validity_pairs"] if r["level"] == "all"}
    w("Per pair, D and R for every family (`validity_pairs.csv`, rows level=all, (family, owner, reader)):")
    w("")
    w("| owner → reader | group | " + " | ".join(f"{f} D / R" for f in fams) + " |")
    w("|---|---|" + "---|" * len(fams))
    for c in design.swaps() + design.swaps("home"):
        txt = []
        for f in fams:
            r = vp.get((f, c[0], c[1]))
            txt.append("–" if r is None else f"{f3(r['D'])} / " + (f3(r["R"]) if r["R_status"] == "reported" else "undef."))
        w(f"| {c[0]} → {c[1]} | {design.group(*c)} | " + " | ".join(txt) + " |")
    w("")

    if T.get("cross_checks"):
        w("## Cross-checks of the primary tests (4.6, not decisive)")
        w("")
        for r in T["cross_checks"]:
            w(f"- {r['test']}, {r['check']}: estimate {f3(r['est'], 4)}, SE {f3(r['se'], 4)}, p {pf(r['p'])}"
              + (f"; decision agrees with the bootstrap: {r['decisions_agree']}" if r.get("decisions_agree", "") != "" else "")
              + (f"; 95 % interval [{f3(r['lo'], 4)}, {f3(r['hi'], 4)}]" if fin(r.get("lo")) else "")
              + f" [cross_checks.csv: {r['test']}, {r['check'][:20]}…].")
        w("")
    flips = [r for r in T.get("lomo_primary", []) if r["sign_flip"]]
    w("## Leave-one-model-out of the primary statistics (8.2.13)")
    w("")
    w(("Sign flips when one model is left out: " + "; ".join(
        f"{r['comparison']} in {r['group']} without {r['left_out']} ({f3(r['full'], 4)} → {f3(r['value'], 4)})"
        for r in flips)) if flips else "No stratum statistic changes sign when any one model is left out.")
    w(" [lomo_primary.csv]")
    w("")

    w("## Exploratory and other secondary analyses")
    w("")
    for r in T.get("shapley_summary", []):
        if r["family"] == H:
            extra = (f"; D with single-item outcomes {f3(r.get('D_single'))}, with Shapley outcomes "
                     f"{f3(r.get('D_shapley'))}") if fin(r.get("D_single")) else ""
            w(f"- Shapley realism check, {r['owner']} → {r['reader']} ({int(r['tasks'])} task-orders): within-task "
              f"concordance of single-item results with Shapley values {f3(r['single_vs_shapley'])}; validity vs "
              f"single {f3(r['validity_single'])}, vs Shapley {f3(r['validity_shapley'])}{extra} "
              f"[shapley_summary.csv: family={H}, owner, reader].")
    for r in T.get("second_bank", []):
        if r["family"] == H:
            w(f"- Second bank, {r['model']}: rank correlation of the two banks' scores {f3(r.get('spearman'))}, "
              f"same order on probe pairs {f3(r.get('pair_agreement'))}, home Cw bank 1 {f3(r.get('home_validity_bank1'))}"
              f" / bank 2 {f3(r.get('home_validity_bank2'))} [second_bank.csv: {r['model']}, {H}].")
    for r in T.get("second_wording", []):
        if r["family"] == H:
            extra = (f"; D under wording 1 {f3(r.get('D_v1'))}, under {r['variant']} {f3(r.get('D_variant'))}"
                     if fin(r.get("D_v1")) else "")
            w(f"- Second wording ({r['variant']}), {r['owner']} → {r['reader']}: Cw {f3(r['validity_v1'])} vs "
              f"{f3(r['validity_variant'])}; outcome agreement {f3(r['outcome_agreement'])}{extra} "
              f"[second_wording.csv: family={H}, owner, reader].")
    mw = [r for r in T.get("mix_weight", []) if r["family"] == H and r["group"] == "all_swaps" and r["arm"] in ("keep", "wipe")
          and "mix" not in r]
    if mw:
        w("- Mix weight (point values; per-task values at other weights are not in the result files): " + "; ".join(
            f"{r['arm']}: " + ", ".join(f"score weight {k[len('value_score_w'):]} {f3(v)}" for k, v in r.items()
                                       if k.startswith("value_score_w"))
            for r in mw) + f" [mix_weight.csv: family={H}, group=all_swaps].")
    w("")
    if T.get("online_groups"):
        w(f"## The run after the swap (test tasks; family `{H}`)")
        w("")
        w("| group | arm | success S_all [95 % CI] | minus keep [95 % CI] |")
        w("|---|---|---|---|")
        for r in T["online_groups"]:
            w(f"| {r['group']} | {r['arm']} | {ci(r, 'S_all')} | {ci(r, 'S_all_minus_keep')} |")
        w("")
        w("Source: `online_groups.csv` (group, arm); per swap with S_first and τ95: `online_arms.csv`; curves: "
          "`online_curves.csv` (trailing window as in the study file).")
        w("")
        oa = [r for r in T.get("online_arms", []) if r["level"] == "all"]
        arms_on = list(dict.fromkeys(r["arm"] for r in oa))
        swaps_on = list(dict.fromkeys((r["owner"], r["reader"]) for r in oa))
        if oa:
            w("Per swap, success S_all (`online_arms.csv`, rows level=all, (owner, reader, arm)); τ95 per stream is in "
              "the rows level = the stream:")
            w("")
            w("| owner → reader | group | " + " | ".join(arms_on) + " |")
            w("|---|---|" + "---:|" * len(arms_on))
            look = {(r["owner"], r["reader"], r["arm"]): r for r in oa}
            for c in swaps_on:
                w(f"| {c[0]} → {c[1]} | {design.group(*c)} | " + " | ".join(
                    f3(look[(c[0], c[1], a)]["S_all"]) if (c[0], c[1], a) in look else "–" for a in arms_on) + " |")
            w("")
    if T.get("costs_by_model"):
        tot = [r for r in T["costs_by_model"] if r["model"] == "all"]
        if tot:
            r = tot[0]
            w(f"## Cost")
            w("")
            w(f"All calls: {r['calls']:,} ({r['fresh_calls']:,} answered fresh), {r['tokens_in']:,} input and "
              f"{r['tokens_out']:,} output tokens, USD {r['usd']:.2f} [costs_by_model.csv: model=all]. Per model and "
              "stage: `costs_by_model.csv`; per swap-day rule (the k reader calls a check arm needs): `costs_by_arm.csv`.")
            w("")
    write_md_secondary(design, T, w)
    if skipped:
        w("## Stages this study does not have (skipped)")
        w("")
        for x in skipped:
            w(f"- {x} [notes.csv]")
        w("")
    if T.get("sensitivity_status"):
        w("## Sensitivity rules of Part 1 (status from the evaluate stage)")
        w("")
        for r in T["sensitivity_status"]:
            w(f"- {r['analysis']}: {r['status']} [sensitivity_status.csv: {r['analysis']}].")
        w("")
    w("## What the result files do not allow (reported, not silently skipped)")
    w("")
    for r in T["not_computed"]:
        w(f"- {r['analysis']}: {r['why']}.")
    w("")
    w("## Files")
    w("")
    w(", ".join(f"`{k}.csv`" for k, v in T.items() if isinstance(v, list)) + ".")
    p = out / "ANALYSIS.md"
    tmp = p.with_name(p.name + ".part")
    tmp.write_text("\n".join(L) + "\n", encoding="utf-8")
    tmp.replace(p)
    return p


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Run the pre-registered analysis on a study's result files.")
    ap.add_argument("--study", required=True, help="study name (runs/<name>/) or study file")
    ap.add_argument("--draws", type=int, default=None, help="bootstrap draws (default 10,000)")
    ap.add_argument("--seed", type=int, default=None, help="bootstrap seed (default: the study's evaluate.seed)")
    ap.add_argument("--out", default=None, help="output folder (default runs/<study>/analysis/)")
    ap.add_argument("--runs-dir", default=None)
    a = ap.parse_args(argv)
    run_analysis(a.study, a.draws, a.seed, a.out, a.runs_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
