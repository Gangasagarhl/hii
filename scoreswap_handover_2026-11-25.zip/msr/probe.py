"""Stage B, PROBE: show the reader one of the owner's items at a time and record the result.

Everyday picture: the old helper's tip box is now fixed. For each job of the probe pool we
pull the 4 tips closest to the job, and ask the NEW helper to do the job with exactly ONE of
those tips in front of him, twice per tip, plus twice with no tip at all. That table of
results is the measuring instrument: every swap-day rule (keep, wipe, discount, ...) is
later scored by looking things up in it, with no further calls.

Also made here:
  - home cells get extra, independent repeats: the same model, same scores, fresh runs.
    That is the self-swap noise floor.
  - the realism check (probe.subsets): on some tasks the reader also gets every group of
    2, 3 and 4 of the candidates shown together, so exact Shapley values can be computed
    and "one tip at a time" can be compared with "tips shown together".
  - the second wording (variants): the same probes again with the instructions reworded.

One probe table per (owner, reader, stream, seed). The no-memory runs depend only on the
reader, so they are made once per reader and copied into each of that reader's tables.
"""
from __future__ import annotations

import json
import os
import uuid
from datetime import datetime, timedelta, timezone
from itertools import combinations

from msr import data as D
from msr.build import (Progress, graded, load_items, mark, messages, now_iso, read_jsonl, run_jobs,
                       write_json, write_jsonl)
from msr.study import Study

#: Repeat numbers of the second-wording runs start here, so they are fresh runs (for the
#: simulated models, whose draws do not depend on the wording, as well as real ones).
VARIANT_REPEAT_OFFSET = 2000


# ---------------------------------------------------------------------------
# The candidates: the owner's closest items for each probe task
# ---------------------------------------------------------------------------


def candidates_for(st: Study, owner: str, stream: str, seed: int, emb: dict, task_ids: list,
                   k: int, name: str) -> dict:
    """{task_id: [(item_id, relevance), ...]} best first, from the owner's frozen items.

    Items are found by the embedding of the write task that made them. Saved once per
    owner as <name>.jsonl in the owner's bank folder, and read back on later runs."""
    path = st.bank_dir(owner, stream, seed) / f"{name}.jsonl"
    if path.exists():
        out: dict = {}
        for r in read_jsonl(path):
            out.setdefault(r["task_id"], []).append((r["item_id"], r["relevance"]))
        if set(out) == set(task_ids):
            return {t: out[t] for t in task_ids}
    from msr.retrieval import Index
    items = load_items(st, owner, stream, seed)
    index = Index()
    for iid, it in items.items():
        index.add(iid, emb[it["task_id"]])
    out = {t: index.search(emb[t], k) for t in task_ids}
    write_jsonl(path, [{"task_id": t, "rank": r, "item_id": i, "relevance": rel}
                       for t in task_ids for r, (i, rel) in enumerate(out[t])])
    return out


def probe_candidates(st: Study, owner: str, stream: str, seed: int, emb: dict) -> dict:
    probe_ids = list(st.splits(stream, seed)["probe"])
    return candidates_for(st, owner, stream, seed, emb, probe_ids, st.probe.candidates, "probe_candidates")


def load_candidates(st: Study, owner: str, stream: str, seed: int) -> dict:
    out: dict = {}
    for r in read_jsonl(st.bank_dir(owner, stream, seed) / "probe_candidates.jsonl"):
        out.setdefault(r["task_id"], []).append((r["item_id"], float(r["relevance"])))
    return out


# ---------------------------------------------------------------------------
# Sessions: repeat 2 of every cell runs in a LATER session than repeat 1 (pre-registration Parts 3-4)
# ---------------------------------------------------------------------------
#
# Everyday picture: a taster who tastes the same dish twice in one sitting remembers the first taste.
# The two repeats of a probe call are the two independent tastings that the "stakes" and "order"
# measures multiply together; a provider-side cache inside one session could make them agree too
# often. So the probe stage runs in passes: pass 1 makes repeat 1 of every cell (and of every reader's
# no-memory run), pass 2 makes repeat 2, and pass 2 of a unit starts only `probe.repeat_gap_hours`
# after that unit's pass 1 finished (default 6 h; 0 in the simulated studies). No extra call.
# Every call carries meta "session" (stage, repeat, start time, a random id) and "session_started";
# each pass is saved on its own (repeat<r>.jsonl + repeat<r>.json with the session and its times), and
# the cell's usual files (probe.jsonl, done.json, probe0.jsonl) are put together when every pass is in,
# in exactly the row order of the one-session layout.


#: This process, as the pre-registration's "new connection" rule (Part 2.4 (b)) sees it: a later session
#: of a real model must run in another process (a new HTTP client, no reused connection).
PROCESS = {"pid": os.getpid(), "process_id": uuid.uuid4().hex[:12]}
NEW_PROCESS = "a new process"


def new_session(stage: str, r: int) -> dict:
    started = now_iso()
    return {"session": f"{stage}:repeat{r + 1}:{started}:{uuid.uuid4().hex[:6]}", "session_started": started,
            "pid": PROCESS["pid"], "process_id": PROCESS["process_id"]}


def _pass_rows(d, r: int):
    return d / f"repeat{r}.jsonl"


def _pass_info(d, r: int):
    return d / f"repeat{r}.json"


def pass_done(d, r: int) -> bool:
    return _pass_info(d, r).exists() and _pass_rows(d, r).exists()


def _save_pass(d, r, rows: list, session: dict, started: str) -> None:
    write_jsonl(_pass_rows(d, r), rows)
    write_json(_pass_info(d, r), {**session, "repeat_index": r, "started": started, "finished": now_iso(),
                                  "rows": len(rows)})        # written last: marks the pass as done


def later_session_wait(st: Study, prev_info, new_process: bool):
    """None when a session may start now after the earlier session described by prev_info (a repeat<r>.json
    path); else the time (ISO, UTC) it may start, NEW_PROCESS when only a new process is missing, or
    "after its earlier repeat" when the earlier session is not saved yet. Pre-registration Part 2.4: (a) the
    first call starts at least probe.repeat_gap_hours after the last call of the earlier session; (b) a real
    model's later session runs in a new process (new HTTP client); (d) the cache key holds the repeat."""
    if not prev_info.exists():
        return "after its earlier repeat"
    info = json.loads(prev_info.read_text(encoding="utf-8"))
    gap = float(st.probe.repeat_gap_hours)
    if gap > 0:
        ready = datetime.fromisoformat(info["finished"]) + timedelta(hours=gap)
        if datetime.now(timezone.utc) < ready:
            return ready.isoformat(timespec="seconds")
    if new_process and info.get("process_id") == PROCESS["process_id"]:
        return NEW_PROCESS
    return None


def gap_wait(st: Study, d, r: int, new_process: bool = False):
    """None when pass r of the unit in folder d may start now (see later_session_wait); pass r needs pass
    r - 1 saved, at least probe.repeat_gap_hours ago and, for a real model, in another process."""
    if r == 0:
        return None
    if not pass_done(d, r - 1):
        return "after its earlier repeat"
    return later_session_wait(st, _pass_info(d, r - 1), new_process)


def _interleave(passes: list) -> list:
    """Rows of the passes back in the one-session order: for each unit (task, or task and item), its
    repeats in order. Every pass lists the same units in the same order."""
    n = len(passes[0])
    if any(len(p) != n for p in passes):
        raise RuntimeError("the passes of one cell do not have the same rows")
    return [p[i] for i in range(n) for p in passes]


# ---------------------------------------------------------------------------
# The no-memory runs of one reader (stage probe0, and variant0 for the second wording)
# ---------------------------------------------------------------------------


def _no_memory_pass(st, llm, reader, stream, seed, tasks, task_ids, stage, variant, rep, workers, progress,
                    session) -> list:
    jobs, keys = [], []
    for tid in task_ids:
        system, user = messages(stream, tasks[tid], [], variant)
        jobs.append(dict(model=reader, user=user, system=system, repeat=rep, max_tokens=st.max_tokens,
                         meta={"study": st.name, "stage": stage, "model": reader, "reader": reader,
                               "stream": stream, "seed": seed, "task_id": tid, "item_id": None,
                               "items": [], "repeat": rep, "variant": variant, **session}))
        keys.append((tid, rep))
    started = now_iso()
    res, grades = run_jobs(llm, jobs, workers, progress,
                           post=lambda i, x: graded(st, stream, tasks[keys[i][0]], x.answer))
    finished = now_iso()
    return [mark({"task_id": tid, "item_id": None, "repeat": rp, "correct": ok, "call_id": x.call_id,
                  "extra": False, "batch": stage, "batch_started": started, "batch_finished": finished,
                  "session": session["session"]}, ung)
            for (tid, rp), x, (ok, ung) in zip(keys, res, grades)]


def _no_memory_unit(st, llm, reader, stream, seed, tasks, task_ids, stage, variant, rep0, path, r,
                    workers, progress, session, waiting):
    """Pass r of one reader's no-memory runs (one repeat), if it may start; then the full file when
    every pass is in. Returns the full rows, or None while a pass is missing."""
    if path.exists():
        return read_jsonl(path)
    d = path.parent
    if r < st.probe.no_memory_repeats and not pass_done(d, r):
        wait = gap_wait(st, d, r, new_process=not st.is_sim(reader))
        if wait is None:
            started = now_iso()
            rows = _no_memory_pass(st, llm, reader, stream, seed, tasks, task_ids, stage, variant, rep0 + r,
                                   workers, progress, session)
            _save_pass(d, r, rows, session, started)
        else:
            waiting.append(wait)
    if all(pass_done(d, q) for q in range(st.probe.no_memory_repeats)):
        rows = _interleave([read_jsonl(_pass_rows(d, q)) for q in range(st.probe.no_memory_repeats)])
        write_jsonl(path, rows)
        return rows
    return None


def probe0_path(st: Study, reader: str, stream: str, seed: int):
    return st.probe0_dir(reader, stream, seed) / "probe0.jsonl"


def run_probe0(st, llm, reader, stream, seed, tasks, workers, progress=None) -> list:
    """Every pass of one reader's no-memory runs at once (gap rules apply): the full rows, or None."""
    rows = None
    for r in range(st.probe.no_memory_repeats):
        rows = _no_memory_unit(st, llm, reader, stream, seed, tasks, list(st.splits(stream, seed)["probe"]),
                               "probe0", st.prompt_variant, 0, probe0_path(st, reader, stream, seed), r,
                               workers, progress, new_session("probe0", r), [])
    return rows


# ---------------------------------------------------------------------------
# One probe cell: (owner, reader, stream, seed)
# ---------------------------------------------------------------------------


def probe_done(st: Study, owner: str, reader: str, stream: str, seed: int) -> bool:
    return (st.probe_dir(owner, reader, stream, seed) / "done.json").exists()


def _single_item_runs(st, llm, owner, reader, stream, seed, tasks, cands, task_ids, reps, extra,
                      stage, variant, workers, progress, session: dict | None = None) -> list:
    items = load_items(st, owner, stream, seed)
    jobs, keys = [], []
    extra_set = set(extra)
    session = session or {}
    for tid in task_ids:
        for iid, _rel in cands[tid]:
            system, user = messages(stream, tasks[tid], [items[iid]["text"]], variant)
            for r in list(reps) + list(extra):
                jobs.append(dict(model=reader, user=user, system=system, repeat=r, max_tokens=st.max_tokens,
                                 meta={"study": st.name, "stage": stage, "model": reader, "owner": owner,
                                       "reader": reader, "stream": stream, "seed": seed, "task_id": tid,
                                       "item_id": iid, "items": [iid], "repeat": r, "extra": r in extra_set,
                                       "variant": variant, **session}))
                keys.append((tid, iid, r))
    started = now_iso()
    res, grades = run_jobs(llm, jobs, workers, progress,
                           post=lambda i, x: graded(st, stream, tasks[keys[i][0]], x.answer))
    finished = now_iso()
    extra_row = {"session": session["session"]} if session.get("session") else {}
    return [mark({"task_id": tid, "item_id": iid, "repeat": r, "correct": ok, "call_id": x.call_id,
                  "extra": r in extra_set, "batch": stage, "batch_started": started, "batch_finished": finished,
                  **extra_row}, ung)
            for (tid, iid, r), x, (ok, ung) in zip(keys, res, grades)]


def _cell_pass(st, llm, owner, reader, stream, seed, tasks, cands, task_ids, d, r, rep, stage, variant,
               workers, progress, session, waiting) -> None:
    """Pass r (one repeat) of one cell, if it is not saved yet and may start."""
    if pass_done(d, r):
        return
    wait = gap_wait(st, d, r, new_process=not st.is_sim(reader))
    if wait is not None:
        waiting.append(wait)
        return
    started = now_iso()
    rows = _single_item_runs(st, llm, owner, reader, stream, seed, tasks, cands, task_ids, [rep], [],
                             stage, variant, workers, progress, session)
    _save_pass(d, r, rows, session, started)


def assemble_probe_cell(st: Study, owner: str, reader: str, stream: str, seed: int, probe0_rows: list | None,
                        cands: dict) -> bool:
    """probe.jsonl, candidates.jsonl and done.json of a cell once every pass and the reader's no-memory
    rows are in (the same files and row order as when both repeats ran in one session)."""
    out = st.probe_dir(owner, reader, stream, seed)
    if probe_done(st, owner, reader, stream, seed):
        return True
    if probe0_rows is None or not all(pass_done(out, r) for r in range(st.probe.repeats)):
        return False
    probe_ids = list(st.splits(stream, seed)["probe"])
    rows = _interleave([read_jsonl(_pass_rows(out, r)) for r in range(st.probe.repeats)])
    n_mem = len(rows)
    rows += [dict(x) for x in probe0_rows]           # the reader's no-memory runs (item_id null)
    write_jsonl(out / "probe.jsonl", rows)
    write_jsonl(out / "candidates.jsonl", [{"task_id": t, "rank": k, "item_id": i, "relevance": rel}
                                           for t in probe_ids for k, (i, rel) in enumerate(cands[t])])
    sessions = [json.loads(_pass_info(out, r).read_text(encoding="utf-8")) for r in range(st.probe.repeats)]
    write_json(out / "done.json", {"complete": True, "owner": owner, "reader": reader, "stream": stream,
                                   "seed": seed, "memory_rows": n_mem, "no_memory_rows": len(probe0_rows),
                                   "sessions": sessions})
    return True


def run_probe_cell(st: Study, llm, owner: str, reader: str, stream: str, seed: int, emb: dict,
                   tasks: dict, probe0_rows: list, workers: int, progress: Progress | None = None) -> None:
    """Every pass of one cell at once (the gap rule applies: with a gap above 0 only pass 1 runs now)."""
    if probe_done(st, owner, reader, stream, seed):
        return
    cands = probe_candidates(st, owner, stream, seed, emb)
    probe_ids = list(st.splits(stream, seed)["probe"])
    d = st.probe_dir(owner, reader, stream, seed)
    for r in range(st.probe.repeats):
        _cell_pass(st, llm, owner, reader, stream, seed, tasks, cands, probe_ids, d, r, r, "probe",
                   st.prompt_variant, workers, progress, new_session("probe", r), [])
    assemble_probe_cell(st, owner, reader, stream, seed, probe0_rows, cands)


def load_probe(st: Study, owner: str, reader: str, stream: str, seed: int) -> list:
    """The probe table of a cell: regular repeats, no-memory runs and, for a home cell, the
    extra repeats when they have been run (stage probe_extra)."""
    d = st.probe_dir(owner, reader, stream, seed)
    p = d / "probe.jsonl"
    if not p.exists():
        raise FileNotFoundError(f"{p} is missing: run the probe stage first")
    rows = read_jsonl(p)
    if (d / "probe_extra.jsonl").exists():
        rows += read_jsonl(d / "probe_extra.jsonl")
    return rows


# ---------------------------------------------------------------------------
# Extra home repeats (stage probe_extra): the self-swap noise floor, run LAST
# ---------------------------------------------------------------------------


def extra_done(st: Study, model: str, stream: str, seed: int) -> bool:
    return (st.probe_dir(model, model, stream, seed) / "probe_extra.jsonl").exists()


def _extra_rows(d, q: int):
    return d / f"extra{q}.jsonl"


def _extra_info(d, q: int):
    return d / f"extra{q}.json"


def run_probe_extra_cell(st: Study, llm, model: str, stream: str, seed: int, emb: dict, tasks: dict,
                         workers: int, progress: Progress | None = None, waiting: list | None = None,
                         sessions: dict | None = None, only: list | None = None) -> None:
    """The extra repeats of a home cell (same model, same items, fresh runs): the self-swap noise floor.
    Kept as a separate stage so they can be scheduled in the last third of a model's collection window
    (pre-registration 4.4). Each extra repeat is its own session (Part 2.4): repeat 3 in a later session
    than repeats 1-2 of the cell, repeat 4 in a later session than repeat 3; the rows are put together in
    the one-session order when every extra repeat is in."""
    waiting = [] if waiting is None else waiting
    if extra_done(st, model, stream, seed) or not st.probe.home_extra_repeats:
        return
    if not probe_done(st, model, model, stream, seed):
        raise RuntimeError(f"the home probe of {model} ({stream}, seed {seed}) must run before its extra repeats")
    d = st.probe_dir(model, model, stream, seed)
    cands = probe_candidates(st, model, stream, seed, emb)
    probe_ids = list(st.splits(stream, seed)["probe"])
    real = not st.is_sim(model)
    for q in (range(st.probe.home_extra_repeats) if only is None else only):
        if _extra_info(d, q).exists():
            continue
        if q == 0:
            prev = _pass_info(d, st.probe.repeats - 1)
            # a home cell made before sessions existed (one session for repeats 1-2): no earlier pass file
            wait = None if not prev.exists() else later_session_wait(st, prev, real)
        else:
            wait = later_session_wait(st, _extra_info(d, q - 1), real)
        if wait is not None:
            waiting.append(wait)
            break
        session = (sessions or {}).get(q) or new_session("probe_extra", st.probe.repeats + q)
        started = now_iso()
        rows = _single_item_runs(st, llm, model, model, stream, seed, tasks, cands, probe_ids, [],
                                 [st.probe.home_extra_offset + q], "probe_extra", st.prompt_variant, workers,
                                 progress, session)
        write_jsonl(_extra_rows(d, q), rows)
        write_json(_extra_info(d, q), {**session, "repeat_index": st.probe.repeats + q, "started": started,
                                       "finished": now_iso(), "rows": len(rows)})
    if all(_extra_info(d, q).exists() for q in range(st.probe.home_extra_repeats)):
        rows = _interleave([read_jsonl(_extra_rows(d, q)) for q in range(st.probe.home_extra_repeats)])
        write_jsonl(d / "probe_extra.jsonl", rows)


def run_extra_stage(st: Study, llm, embeddings: dict, workers: int = 8, printer=print) -> dict:
    todo = [(m, s, k) for s in st.streams for k in st.seeds for m in st.models if not extra_done(st, m, s, k)]
    if not todo or not st.probe.home_extra_repeats:
        return {"waiting": 0, "ready_at": None, "new_process": False}
    waiting_cells = [c for c in todo if not probe_done(st, c[0], c[0], c[1], c[2])]
    if waiting_cells:      # a home cell still waits for its second session: its extra repeats come after
        printer(f"  [probe_extra] {len(waiting_cells)} home cell(s) are not complete yet (repeat 2 waits for its "
                f"session); their extra repeats run on a later call of this stage")
        todo = [c for c in todo if c not in waiting_cells]
    waiting: list = []
    if todo:
        from msr.study import plan_calls
        tasks_by_stream = {s: D.task_index(s) for s in st.streams}
        per = sum(plan_calls(st)["calls"]["probe_extra"].values()) // max(1, len(st.models) * len(st.streams) * len(st.seeds))
        prog = Progress("extra home repeats", per * len(todo), printer)
        sessions = {q: new_session("probe_extra", st.probe.repeats + q) for q in range(st.probe.home_extra_repeats)}
        for q in range(st.probe.home_extra_repeats):      # every cell's repeat 3 before any repeat 4
            for m, s, k in todo:
                cell_wait: list = []
                run_probe_extra_cell(st, llm, m, s, k, embeddings[s], tasks_by_stream[s], workers, prog,
                                     cell_wait, {q: sessions[q]}, only=[q])
                waiting += cell_wait
    return _waiting_report(st, waiting + [w for w in ["after its earlier repeat"] * len(waiting_cells)],
                           "probe_extra", printer)


def _waiting_report(st, waiting: list, stage: str, printer) -> dict:
    times = sorted(w for w in waiting if w[:1].isdigit())
    new_proc = bool(waiting) and all(w in (NEW_PROCESS, "after its earlier repeat") for w in waiting) and \
        NEW_PROCESS in waiting
    if waiting:
        printer(f"  [{stage}] {len(waiting)} later session(s) cannot start yet" +
                (f": the first may start at {times[0]} (UTC), {st.probe.repeat_gap_hours:g} h after the earlier one"
                 if times else "") +
                ("; they need a new process (a new connection, pre-registration 2.4 (b))" if NEW_PROCESS in waiting
                 else "") + ". Everything finished is kept.")
    return {"waiting": len(waiting), "ready_at": times[0] if times else None, "new_process": new_proc}


# ---------------------------------------------------------------------------
# Realism check: groups of 2, 3 and 4 candidates shown together (stage "subset")
# ---------------------------------------------------------------------------


def subset_done(st: Study, owner: str, reader: str, stream: str, seed: int) -> bool:
    return (st.subset_dir(owner, reader, stream, seed) / "done.json").exists()


def run_subset_cell(st: Study, llm, owner: str, reader: str, stream: str, seed: int, emb: dict,
                    tasks: dict, workers: int, progress: Progress | None = None) -> None:
    """Run the reader once on every group of 2..K candidates for the subset tasks. Groups of
    size 0 and 1 come from the ordinary probe table. Inside a group the most relevant item
    is placed last, as StreamBench does."""
    out = st.subset_dir(owner, reader, stream, seed)
    if subset_done(st, owner, reader, stream, seed):
        return
    items = load_items(st, owner, stream, seed)
    cands = probe_candidates(st, owner, stream, seed, emb)
    session = new_session("subset", 0)
    jobs, keys = [], []
    for tid in st.subset_task_ids(stream, seed):
        ranked = [i for i, _ in cands[tid]]                 # best first
        for size in range(2, len(ranked) + 1):
            for group in combinations(ranked, size):        # keeps best-first order
                shown = list(group)
                texts = [items[i]["text"] for i in reversed(shown)]
                system, user = messages(stream, tasks[tid], texts, st.prompt_variant)
                jobs.append(dict(model=reader, user=user, system=system, repeat=0, max_tokens=st.max_tokens,
                                 meta={"study": st.name, "stage": "subset", "model": reader, "owner": owner,
                                       "reader": reader, "stream": stream, "seed": seed, "task_id": tid,
                                       "item_id": None, "items": shown, "repeat": 0, **session}))
                keys.append((tid, shown))
    res, grades = run_jobs(llm, jobs, workers, progress,
                           post=lambda i, x: graded(st, stream, tasks[keys[i][0]], x.answer))
    finished = now_iso()
    rows = [mark({"task_id": tid, "items": shown, "size": len(shown), "correct": ok, "call_id": x.call_id,
                  "batch_finished": finished}, ung)
            for (tid, shown), x, (ok, ung) in zip(keys, res, grades)]
    write_jsonl(out / "subsets.jsonl", rows)
    write_json(out / "done.json", {"complete": True, "rows": len(rows)})


# ---------------------------------------------------------------------------
# Second wording: the same probes with the instructions reworded (stage "variant")
# ---------------------------------------------------------------------------


def variant_done(st: Study, owner: str, reader: str, stream: str, seed: int) -> bool:
    return (st.variant_dir(owner, reader, stream, seed) / "done.json").exists()


def run_variant_cell(st: Study, llm, owner: str, reader: str, stream: str, seed: int, emb: dict,
                     tasks: dict, v0_rows: list | None, workers: int, progress: Progress | None = None,
                     r: int | None = None, session: dict | None = None, waiting: list | None = None) -> None:
    """Pass r of a second-wording cell (every pass when r is None), then its files when all are in."""
    out = st.variant_dir(owner, reader, stream, seed)
    if variant_done(st, owner, reader, stream, seed):
        return
    cands = probe_candidates(st, owner, stream, seed, emb)
    ids = st.variant_task_ids(stream, seed)
    waiting = [] if waiting is None else waiting
    for q in (range(st.probe.repeats) if r is None else [r]):
        _cell_pass(st, llm, owner, reader, stream, seed, tasks, cands, ids, out, q, VARIANT_REPEAT_OFFSET + q,
                   "variant", st.variants.variant, workers, progress, session or new_session("variant", q), waiting)
    if v0_rows is None or not all(pass_done(out, q) for q in range(st.probe.repeats)):
        return
    rows = _interleave([read_jsonl(_pass_rows(out, q)) for q in range(st.probe.repeats)])
    rows += [dict(x) for x in v0_rows]
    write_jsonl(out / "probe.jsonl", rows)
    write_json(out / "done.json", {"complete": True, "variant": st.variants.variant, "rows": len(rows)})


# ---------------------------------------------------------------------------
# Stage runner
# ---------------------------------------------------------------------------


def run_stage(st: Study, llm, embeddings: dict, workers: int = 8, printer=print) -> dict:
    """The probe stage in passes (see "Sessions" above): pass 1 = repeat 1 of every reader's no-memory
    runs and of every cell (then the subsets, which have one repeat), pass 2 = repeat 2 of each, started
    only when the unit's pass 1 finished at least probe.repeat_gap_hours ago. Returns {"waiting": n,
    "ready_at": earliest time a waiting pass may start, or None}; run.py stops after this stage while
    anything waits, and the same command later carries on (finished passes are kept)."""
    from msr.study import plan_calls
    plan = plan_calls(st)
    tasks_by_stream = {s: D.task_index(s) for s in st.streams}
    readers = list(dict.fromkeys(r for _, r in st.cells))
    n_pass = max(st.probe.repeats, st.probe.no_memory_repeats)
    waiting: list = []

    todo0 = [(r, s, k) for s in st.streams for k in st.seeds for r in readers
             if not probe0_path(st, r, s, k).exists()]
    todo = [(o, r, s, k) for s in st.streams for k in st.seeds for (o, r) in st.cells
            if not probe_done(st, o, r, s, k)]
    if todo or todo0:
        n_cells = len(st.cells) * len(st.streams) * len(st.seeds)
        total_mem = sum(plan["calls"]["probe"].values())
        per_reader0 = st.sizes.n_probe * st.probe.no_memory_repeats
        # an approximate total for the percentage: the cells still to do
        prog = Progress("probe", int(total_mem * len(todo) / max(1, n_cells)) + per_reader0 * len(todo0), printer)
        for r in range(n_pass):
            s0, s1 = new_session("probe0", r), new_session("probe", r)
            for stream in st.streams:
                for seed in st.seeds:
                    ids = list(st.splits(stream, seed)["probe"])
                    p0 = {rd: _no_memory_unit(st, llm, rd, stream, seed, tasks_by_stream[stream], ids, "probe0",
                                              st.prompt_variant, 0, probe0_path(st, rd, stream, seed), r, workers,
                                              prog, s0, waiting) for rd in readers}
                    for owner, reader in st.cells:
                        if probe_done(st, owner, reader, stream, seed):
                            continue
                        cands = probe_candidates(st, owner, stream, seed, embeddings[stream])
                        d = st.probe_dir(owner, reader, stream, seed)
                        if r < st.probe.repeats:
                            _cell_pass(st, llm, owner, reader, stream, seed, tasks_by_stream[stream], cands, ids, d,
                                       r, r, "probe", st.prompt_variant, workers, prog, s1, waiting)
                        assemble_probe_cell(st, owner, reader, stream, seed, p0[reader], cands)
            if r == 0 and st.probe.subsets_enabled:
                _run_subsets(st, llm, embeddings, tasks_by_stream, plan, workers, printer)
    elif st.probe.subsets_enabled:
        _run_subsets(st, llm, embeddings, tasks_by_stream, plan, workers, printer)

    if st.variants.enabled:
        todo_v = [(o, r, s, k) for s in st.streams for k in st.seeds for (o, r) in st.variants.cells
                  if not variant_done(st, o, r, s, k)]
        if todo_v:
            prog = Progress(f"wording {st.variants.variant}",
                            sum(plan["calls"]["variant"].values()) + sum(plan["calls"]["variant0"].values()), printer)
            for r in range(n_pass):
                s0, s1 = new_session("variant0", r), new_session("variant", r)
                for stream in st.streams:
                    for seed in st.seeds:
                        ids = st.variant_task_ids(stream, seed)
                        v0 = {}
                        for reader in dict.fromkeys(x for _, x in st.variants.cells):
                            path = st.variant0_dir(reader, stream, seed) / "probe0.jsonl"
                            v0[reader] = _no_memory_unit(st, llm, reader, stream, seed, tasks_by_stream[stream], ids,
                                                         "variant0", st.variants.variant, VARIANT_REPEAT_OFFSET, path,
                                                         r, workers, prog, s0, waiting)
                        for owner, reader in st.variants.cells:
                            if r < st.probe.repeats or v0[reader] is not None:
                                run_variant_cell(st, llm, owner, reader, stream, seed, embeddings[stream],
                                                 tasks_by_stream[stream], v0[reader], workers, prog,
                                                 r=min(r, st.probe.repeats - 1), session=s1, waiting=waiting)

    return _waiting_report(st, waiting, "probe", printer)


def _run_subsets(st, llm, embeddings, tasks_by_stream, plan, workers, printer) -> None:
    todo_s = [(o, r, s, k) for s in st.streams for k in st.seeds for (o, r) in st.probe.subset_cells
              if not subset_done(st, o, r, s, k)]
    if todo_s:
        per = sum(plan["calls"]["subset"].values()) // max(1, len(st.probe.subset_cells) * len(st.streams) * len(st.seeds))
        prog = Progress("subsets", per * len(todo_s), printer)
        for o, r, s, k in todo_s:
            run_subset_cell(st, llm, o, r, s, k, embeddings[s], tasks_by_stream[s], workers, prog)
