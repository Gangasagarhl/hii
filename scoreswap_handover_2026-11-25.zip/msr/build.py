"""Stage A, BUILD: one model writes a tip box, then earns scores for the tips over several passes.

Everyday picture: a new garage helper first does a batch of jobs on his own, with no tips,
and writes one tip card per job (WRITE phase). The box is then closed: no card is added or
changed again. Next he works through a second queue of jobs three times over (SCORE phase,
three epochs). Before each job he pulls the 4 closest cards, reads one (usually the
best-rated, sometimes a random one so every card gets a chance), does the job, and the job
is checked. The card he read gets its scores updated. Three passes give each card several
visits, which one pass did not (our first simulated run showed most cards seen once or never).

Five score families sit on every card, all fed by the same jobs:
  ema_grade   moving average of the program's grade (step 0.3, start 0.5)   MemRL style; drives retrieval
  beta_grade  graded successes and failures as a Beta(1,1) posterior        Memp / ReMe style
  tags_self   the model's own helpful / harmful tag (neutral adds nothing)  ACE style
  credit      success with the card minus success WITHOUT it on that task   MemCredit style
  visits      how often the card was shown (a baseline with no usefulness signal)

Everything is deterministic: the random exploration is seeded per (seed, epoch, task), so a
re-run asks exactly the same questions and every paid answer comes from the llm cache.
That is what makes an interrupted build resumable for free.

A second bank (build.second_bank_models) reuses the SAME cards but earns its scores with a
different exploration seed and fresh repeats; comparing the two shows how repeatable the
scores are.
"""
from __future__ import annotations

import hashlib
import json
import re
import threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import numpy as np

from msr import data as D
from msr import grade as G
from msr import prompts as P
from msr import scores as S
from msr.study import Study

MARKS = ("helpful", "harmful", "neutral")


# ---------------------------------------------------------------------------
# Small helpers shared by the other stages
# ---------------------------------------------------------------------------


def stable_int(text: str) -> int:
    """A whole number made from text that is the same on every machine and run
    (Python's own hash() changes between runs, so it cannot be used for seeds)."""
    return int(hashlib.sha256(text.encode("utf-8")).hexdigest()[:12], 16)


def task_rng(seed: int, epoch: int, task_id: str) -> np.random.Generator:
    """The random generator for one task in one epoch of one stream order. Every model
    meets the same random draws on the same task and epoch."""
    return np.random.default_rng([int(seed), int(epoch), stable_int(task_id)])


def make_item_id(task_id: str, model: str) -> str:
    """A memory item is named "<write task id>@<model that wrote it>", for example
    "ddxplus-0123@haiku-4.5"."""
    return f"{task_id}@{model}"


def make_rules(st: Study) -> dict:
    """The score rule behind each family."""
    value = S.ValueScore(alpha=st.scores.ema_alpha, q0=st.scores.ema_q0)
    out = {"ema_grade": value,
           "beta_grade": S.CounterScore(ranking=st.scores.counter_ranking),
           "tags_self": S.CounterScore(ranking=st.scores.counter_ranking),
           "credit": S.CreditScore(),
           "visits": S.VisitScore()}
    return {f: out[f] for f in st.scores.families}


def write_jsonl(path: Path, rows) -> None:
    """Write JSON lines to a temporary file, then rename it, so a crash never leaves half a
    file (the rename works on Windows too)."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".part")
    with open(tmp, "w", encoding="utf-8", newline="\n") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    tmp.replace(path)


def read_jsonl(path: Path) -> list:
    with open(path, encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def write_json(path: Path, obj) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".part")
    tmp.write_text(json.dumps(obj, indent=1, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)


def grade_detail(st: Study, stream: str, task: dict, answer: str | None) -> dict:
    """Grade one answer. BIRD uses the corrected SQL parser unless grading.bird_faithful
    is true (pre-registration 1.5); DDXPlus is graded by StreamBench's parser either way."""
    return G.grade_detail(stream, task, answer, faithful=st.bird_faithful)


def is_correct(st: Study, stream: str, task: dict, answer: str | None) -> bool:
    return bool(grade_detail(st, stream, task, answer)["correct"])


def graded(st: Study, stream: str, task: dict, answer: str | None) -> tuple:
    """(correct, ungraded) of one answer. `ungraded` is None, or "timeout" when a BIRD query could not
    be run to the end even after a retry (msr.grade): the answer then counts as not correct for now, the
    row is marked, and run.py retries the query at the end of the stage and redoes the unit."""
    d = grade_detail(st, stream, task, answer)
    return bool(d["correct"]), d.get("ungraded")


def mark(row: dict, ungraded) -> dict:
    """Add "ungraded" to a saved row only when there is something to say (rows stay as before)."""
    if ungraded:
        row["ungraded"] = ungraded
    return row


def other_grade(st: Study, stream: str, task: dict, answer: str | None) -> bool:
    """The grade under BIRD's OTHER SQL parser (StreamBench's original one when the study uses the
    corrected one, Part 1.5), kept with every stored item so msr/construct.py can be rerun under it.
    DDXPlus has one parser: the same grade."""
    if stream != "bird":
        return is_correct(st, stream, task, answer)
    return bool(G.grade_detail(stream, task, answer, faithful=not st.bird_faithful)["correct"])


def now_iso() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def shown_order_for_prompt(shown: list) -> list:
    """StreamBench puts the MOST relevant item LAST, so the best-ranked item goes last."""
    return list(reversed(shown))


def run_jobs(llm, jobs: list, workers: int, progress=None, post=None):
    """Make the calls (in parallel when there are several) and return results in order.

    post(i, result), when given, runs in the worker thread right after job i's call returns (for example
    grading the answer, so BIRD's SQL runs while other calls are still waiting on the model); then the
    return value is (results, [post(0, r0), post(1, r1), ...]) in job order. Grading is a pure function
    of the answer (its caches never change a grade), so the grades equal grading one by one afterwards."""
    if not jobs:
        return ([], []) if post else []
    out: list = [None] * len(jobs)
    posts: list = [None] * len(jobs)

    def one(i):
        r = llm.call(**jobs[i])
        out[i] = r
        if post is not None:
            posts[i] = post(i, r)
        if progress:
            progress.add()

    if len(jobs) == 1 or workers <= 1:
        for i in range(len(jobs)):
            one(i)
    else:
        with ThreadPoolExecutor(max_workers=min(workers, len(jobs))) as ex:
            list(ex.map(one, range(len(jobs))))
    return (out, posts) if post is not None else out


class Progress:
    """Prints plain progress lines with a percentage, about every 5 %."""

    def __init__(self, label: str, total: int, printer=print):
        self.label, self.total, self.done = label, max(0, int(total)), 0
        self._next = 0.0
        self._lock = threading.Lock()
        self._print = printer

    def add(self, n: int = 1) -> None:
        with self._lock:
            self.done += n
            pct = 100.0 * self.done / self.total if self.total else 100.0
            if pct >= self._next or self.done >= self.total:
                self._print(f"  [{self.label}] {min(pct, 100.0):5.1f}%  ({self.done:,}/{self.total:,} calls)")
                while self._next <= pct:
                    self._next += 5.0


# ---------------------------------------------------------------------------
# Prompt wording: v1 = StreamBench's own text, v2 = a second honest rewording
# ---------------------------------------------------------------------------

#: v2 rewrites ONLY the instruction sentences; the task text, the memory items and the
#: answer format (which the grader reads) stay exactly as in v1. Each pair is
#: (StreamBench's sentence, our rewording). Defined here, not in msr/prompts.py, so the
#: StreamBench copy stays untouched.
V2_REWORDING = {
    "ddxplus": [
        ("Act as a medical doctor and diagnose the patient based on the following patient profile:",
         "You are a physician. Read the patient profile below and decide on the most likely diagnosis."),
        ("Act as a medical doctor and diagnose the patient based on the provided patient profile.",
         "You are a physician. Read the patient profile at the end and decide on the most likely diagnosis."),
        ("All possible diagnoses for you to choose from are as follows (one diagnosis per line, "
         "in the format of <number>. <diagnosis>):",
         "Choose exactly one diagnosis from this numbered list (each line reads <number>. <diagnosis>):"),
        ("Here are some example cases.", "Some earlier cases, for reference:"),
        ("Now it's your turn.", "The case to diagnose:"),
        ("Now, directly provide the diagnosis for the patient in the following format: <number>. <diagnosis>",
         "Reply with the diagnosis only, written as <number>. <diagnosis>"),
        ("Now provide the diagnosis for the patient in the following format: <number>. <diagnosis>",
         "Reply with the diagnosis only, written as <number>. <diagnosis>"),
    ],
    "bird": [
        ("-- Using valid SQLite, answer the following question for the tables provided above.",
         "-- Write one SQLite query over the tables above that answers this question."),
        ("-- Using valid SQLite, answer the following question for the SQL schema provided above.",
         "-- Write one SQLite query over the schema above that answers this question."),
        ("You are performing the text-to-SQL task. Here are some examples:",
         "Task: turn a question into SQL. Some solved examples:"),
        ("Now it's your turn.", "Now the new question."),
        ("Now, generate the correct SQL code directly (Do NOT generate other text except the SQL code):",
         "Reply with the SQL query only, with no other text:"),
    ],
}


def messages(stream: str, task: dict, item_texts: list, variant: str = "v1") -> tuple:
    """(system, user) for a task with these memory item texts shown, in wording v1 or v2."""
    system, user = P.build_messages(stream, task, item_texts)
    if variant == "v1":
        return system, user
    if variant != "v2":
        raise ValueError(f"unknown prompt variant {variant!r}")
    changed = 0
    for old, new in V2_REWORDING[stream]:
        if old in user:
            user = user.replace(old, new, 1)
            changed += 1
    if changed < 2:   # the instruction and the answer line must both have been reworded
        raise RuntimeError(f"prompt variant v2 found only {changed} StreamBench sentences in a {stream} "
                           "prompt; msr/prompts.py changed, update V2_REWORDING in msr/build.py")
    return system, user


# ---------------------------------------------------------------------------
# The self-tag question (ACE style: the model says if the item helped)
# ---------------------------------------------------------------------------


def selftag_prompt(stream: str, task: dict, item_text: str, parsed_answer: str,
                   correct: bool, sees_grade: bool) -> str:
    """After a score-phase task: was the shown memory item helpful, harmful or neutral?"""
    what = "patient case" if stream == "ddxplus" else "question"
    grade_line = ""
    if sees_grade:
        grade_line = ("\nYour answer was graded CORRECT.\n" if correct
                      else "\nYour answer was graded NOT CORRECT.\n")
    return (
        f"You just answered a {what} with the help of one example case taken from memory.\n\n"
        f"The {what}:\n{task['question']}\n\n"
        f"The example case from memory:\n{item_text}\n\n"
        f"Your answer:\n{parsed_answer}\n{grade_line}\n"
        "Was the example case helpful, harmful or neutral for answering this "
        f"{what}? Reply with exactly one word: helpful, harmful or neutral."
    )


def rating_prompt(stream: str, item_text: str, scale: int, who: str) -> str:
    """A rating question about ONE stored item (its task and its stored answer, never a right / wrong
    label). who = "writer" (write-time self-rating) or "reader" (the new model as judge)."""
    what = "patient case" if stream == "ddxplus" else "question"
    if who == "writer":
        head = (f"You just answered the {what} below. Your answer will be stored and later shown as an "
                f"example to help answer similar {what}s.\n\n")
        ask = (f"How likely is your answer to be right, and how useful will this example be for similar "
               f"{what}s?")
    else:
        head = (f"Below is a stored example: a {what} with an answer. It may be shown to you as an example "
                f"while you answer new {what}s of the same kind.\n\n")
        ask = f"How useful would this example be to you for answering new {what}s?"
    return (head + f"The example:\n{item_text}\n\n" + ask +
            f" Reply with one whole number from 1 (useless or misleading) to {scale} (very useful).")


def parse_rating(answer: str | None, scale: int):
    """The first whole number 1..scale in the answer, else None (counted as missing)."""
    for m in re.findall(r"\d+", answer or ""):
        v = int(m)
        if 1 <= v <= scale:
            return v
        break
    return None


def parse_mark(answer: str | None) -> str:
    """The first word of the answer if it is helpful / harmful / neutral; anything else
    counts as neutral."""
    words = re.findall(r"[a-z]+", (answer or "").lower())
    return words[0] if words and words[0] in MARKS else "neutral"


# ---------------------------------------------------------------------------
# Choosing which items to show, and updating the families
# ---------------------------------------------------------------------------


def select_items(cands: list, score_norm: dict, n_show: int, w_score: float, epsilon: float,
                 explore_pool: str, rng: np.random.Generator, drive: str):
    """Pick up to n_show items from the candidates [(item_id, relevance)], best first.

    Each slot is one epsilon-greedy draw (msr.scores.choose) among the candidates not yet
    picked, ranked by w_score * score + (1 - w_score) * relevance (msr.scores.rank takes the
    weight on RELEVANCE, so w = 1 - w_score is passed). With drive == "relevance" the score
    is ignored. Returns (shown ids, probability of each pick, explored flags)."""
    rel = {i: r for i, r in cands}
    remaining = [i for i, _ in cands]
    w_rel = 1.0 - w_score if drive != "relevance" else 1.0
    shown, probs, explored = [], [], []
    for _ in range(min(n_show, len(remaining))):
        ch = S.choose(remaining, rel, score_norm, w=w_rel, epsilon=epsilon, top_k=len(remaining),
                      rng=rng, explore_pool=explore_pool)
        shown.append(ch.item_id)
        probs.append(round(float(ch.prob), 6))
        explored.append(bool(ch.explored))
        remaining.remove(ch.item_id)
    return shown, probs, explored


def candidate_probs(cands: list, score_norm: dict, shown: list, w_score: float, epsilon: float,
                    drive: str) -> list:
    """The chance that EACH candidate had of filling each slot, given the items already picked for the
    earlier slots: one {item_id: probability} per shown slot (no randomness used, no calls). Within a
    slot select_items explores over every remaining candidate (top_k = all of them), so a candidate's
    chance is epsilon / remaining, plus 1 - epsilon for the best one by the mixed ranking."""
    rel = {i: r for i, r in cands}
    w_rel = 1.0 - w_score if drive != "relevance" else 1.0
    remaining = [i for i, _ in cands]
    out = []
    for pick in shown:
        ranked = S.rank(remaining, rel, score_norm, w_rel)
        best = ranked[0]
        n = len(remaining)
        out.append({i: round((epsilon / n if epsilon > 0 else 0.0) + ((1.0 - epsilon) if i == best else 0.0), 6)
                     for i in remaining})
        remaining.remove(pick)
    return out


def update_families(rules: dict, banks: dict, item_id: str, correct: bool, tag: str | None,
                    baseline: float | None, model: str) -> None:
    """One episode in which item_id was shown: every family takes its own update."""
    for fam, rule in rules.items():
        bank = banks[fam]
        if fam in ("ema_grade", "beta_grade"):
            rule.update(bank, item_id, bool(correct), model=model)
        elif fam == "tags_self":
            if tag is not None:
                rule.update(bank, item_id, tag, model=model)      # neutral counts a visit only
        elif fam == "credit":
            rule.update(bank, item_id, bool(correct), model=model, baseline=float(baseline or 0.0))
        elif fam == "visits":
            rule.update(bank, item_id, bool(correct), model=model)


# ---------------------------------------------------------------------------
# WRITE phase and the no-memory run (shared by both banks of a model)
# ---------------------------------------------------------------------------


def _base_meta(st: Study, model: str, stream: str, seed: int) -> dict:
    return {"study": st.name, "model": model, "stream": stream, "seed": seed}


def write_done(st: Study, model: str, stream: str, seed: int) -> bool:
    d = st.bank_dir(model, stream, seed)
    return (d / "write.jsonl").exists() and (d / "items.jsonl").exists()


def run_write(st: Study, llm, model: str, stream: str, seed: int, tasks: dict, workers: int,
              progress: Progress | None = None) -> None:
    """Answer the write tasks with no memory; each answer becomes one memory item. These
    answers are also the model's no-memory results on the write tasks."""
    if write_done(st, model, stream, seed):
        return
    d = st.bank_dir(model, stream, seed)
    ids = st.write_ids(stream, seed)
    base = _base_meta(st, model, stream, seed)
    jobs = []
    for pos, tid in enumerate(ids):
        system, user = messages(stream, tasks[tid], [], st.prompt_variant)
        jobs.append(dict(model=model, user=user, system=system, repeat=0, max_tokens=st.max_tokens,
                         meta={**base, "stage": "write", "task_id": tid, "position": pos,
                               "item_id": None, "items": []}))
    res, grades = run_jobs(llm, jobs, workers, progress,
                           post=lambda i, x: (graded(st, stream, tasks[ids[i]], x.answer),
                                              other_grade(st, stream, tasks[ids[i]], x.answer)))
    rows, items = [], []
    for pos, (tid, r, ((ok, ung), ok_other)) in enumerate(zip(ids, res, grades)):
        rows.append(mark({"task_id": tid, "correct": ok, "call_id": r.call_id}, ung))
        if st.build.store == "all" or ok:
            it = P.memory_item_from(stream, tasks[tid], r.answer, style=st.build.item_style, correct=ok,
                                    faithful=st.bird_faithful)
            iid = make_item_id(tid, model)
            items.append(mark({"item_id": iid, "task_id": tid, "text": it["text"], "answer": it["answer"],
                               "correct": ok, "position": pos, "style": st.build.item_style, "model": model,
                               "correct_other_parser": ok_other}, ung))
    write_jsonl(d / "items.jsonl", items)
    write_jsonl(d / "write.jsonl", rows)          # written last: marks the phase as done


def build0_done(st: Study, model: str, stream: str, seed: int) -> bool:
    return (st.bank_dir(model, stream, seed) / "build0.jsonl").exists()


def run_build0(st: Study, llm, model: str, stream: str, seed: int, tasks: dict, workers: int,
               progress: Progress | None = None) -> None:
    """Every score-phase task once with NO memory: the baseline of the credit family and of
    the memory-gain number."""
    out = st.bank_dir(model, stream, seed) / "build0.jsonl"
    if out.exists():
        return
    base = _base_meta(st, model, stream, seed)
    ids = st.score_ids(stream, seed)
    jobs = []
    for pos, tid in enumerate(ids):
        system, user = messages(stream, tasks[tid], [], st.prompt_variant)
        jobs.append(dict(model=model, user=user, system=system, repeat=0, max_tokens=st.max_tokens,
                         meta={**base, "stage": "build0", "task_id": tid, "position": pos,
                               "item_id": None, "items": []}))
    res, grades = run_jobs(llm, jobs, workers, progress,
                           post=lambda i, x: graded(st, stream, tasks[ids[i]], x.answer))
    write_jsonl(out, [mark({"task_id": tid, "correct": ok, "call_id": r.call_id}, ung)
                      for tid, r, (ok, ung) in zip(ids, res, grades)])


# ---------------------------------------------------------------------------
# Decision D7 / construct checks: a second no-memory answer to each write task (stage write2) and
# the writer's own rating of each stored item at write time (stage selfrate). Both are SEPARATE
# calls: the write call and its stored answer are exactly as before (same prompt, repeat 0).
# ---------------------------------------------------------------------------


def write2_done(st: Study, model: str, stream: str, seed: int) -> bool:
    return (st.bank_dir(model, stream, seed) / "write2.jsonl").exists()


def run_write2(st: Study, llm, model: str, stream: str, seed: int, tasks: dict, workers: int,
               progress: Progress | None = None) -> None:
    """Each write task answered a second time with no memory (repeat 1, a separate session): the home
    value and self-swap reference of the re-answer agreement (msr/construct.py)."""
    out = st.bank_dir(model, stream, seed) / "write2.jsonl"
    if out.exists():
        return
    base = _base_meta(st, model, stream, seed)
    ids = st.write_ids(stream, seed)
    jobs = []
    for pos, tid in enumerate(ids):
        system, user = messages(stream, tasks[tid], [], st.prompt_variant)
        jobs.append(dict(model=model, user=user, system=system, repeat=1, max_tokens=st.max_tokens,
                         meta={**base, "stage": "write2", "task_id": tid, "position": pos,
                               "item_id": None, "items": [], "repeat": 1}))
    res, grades = run_jobs(llm, jobs, workers, progress,
                           post=lambda i, x: (graded(st, stream, tasks[ids[i]], x.answer),
                                              other_grade(st, stream, tasks[ids[i]], x.answer)))
    rows = []
    for pos, (tid, r, ((ok, ung), ok_other)) in enumerate(zip(ids, res, grades)):
        parsed = G.parse_answer(stream, r.answer, faithful=st.bird_faithful)
        rows.append(mark({"task_id": tid, "position": pos, "correct": ok, "answer": parsed,
                          "correct_other_parser": ok_other, "call_id": r.call_id}, ung))
    write_jsonl(out, rows)


def selfrate_done(st: Study, model: str, stream: str, seed: int) -> bool:
    return (st.bank_dir(model, stream, seed) / "selfrate.jsonl").exists()


def run_selfrate(st: Study, llm, model: str, stream: str, seed: int, workers: int,
                 progress: Progress | None = None) -> None:
    """The writer rates each of its stored items (its task and its stored answer, no label), 1..scale:
    score type `self_rating`. Not the same as tags_self, which is the model's helpful / harmful tag
    AFTER an item was used on a score task (many tags, only for items that get shown); this is one
    rating per item, before any use, for every item, also those never shown."""
    out = st.bank_dir(model, stream, seed) / "selfrate.jsonl"
    if out.exists():
        return
    items = load_items(st, model, stream, seed)
    base = _base_meta(st, model, stream, seed)
    scale = st.build.rating_scale
    jobs, ids = [], []
    for iid, it in items.items():
        user = rating_prompt(stream, it["text"], scale, "writer")
        jobs.append(dict(model=model, user=user, system=None, repeat=0, max_tokens=st.max_tokens,
                         meta={**base, "stage": "selfrate", "task_id": it["task_id"], "item_id": iid,
                               "items": [iid], "scale": scale, "repeat": 0}))
        ids.append(iid)
    res = run_jobs(llm, jobs, workers, progress)
    write_jsonl(out, [{"item_id": iid, "rating": parse_rating(r.answer, scale), "scale": scale,
                       "call_id": r.call_id} for iid, r in zip(ids, res)])


# ---------------------------------------------------------------------------
# SCORE phase: one bank of one (model, stream, seed)
# ---------------------------------------------------------------------------


def bank_done(st: Study, model: str, stream: str, seed: int, bank: int = 1) -> bool:
    p = st.bank_dir(model, stream, seed, bank) / "build_summary.json"
    if not p.exists():
        return False
    try:
        return bool(json.loads(p.read_text(encoding="utf-8")).get("complete"))
    except ValueError:
        return False


def load_items(st: Study, model: str, stream: str, seed: int) -> dict:
    """{item_id: item} of a model's (frozen) memory content."""
    p = st.bank_dir(model, stream, seed) / "items.jsonl"
    if not p.exists():
        raise FileNotFoundError(f"{p} is missing: run the build stage first")
    return {r["item_id"]: r for r in read_jsonl(p)}


def run_score_phase(st: Study, llm, model: str, stream: str, seed: int, bank: int, emb: dict,
                    tasks: dict, workers: int = 1, progress: Progress | None = None) -> dict:
    """The score phase for one bank; saves the score files, episodes and summary."""
    out = st.bank_dir(model, stream, seed, bank)
    if bank_done(st, model, stream, seed, bank):
        return json.loads((out / "build_summary.json").read_text(encoding="utf-8"))
    B = st.build
    items = load_items(st, model, stream, seed)
    baseline = {}
    if B.no_memory_run:
        baseline = {r["task_id"]: float(r["correct"])
                    for r in read_jsonl(st.bank_dir(model, stream, seed) / "build0.jsonl")}
    explore_seed = seed if bank == 1 else seed + B.second_bank_seed_offset
    rep_offset = 0 if bank == 1 else B.second_bank_repeat_offset
    base = {**_base_meta(st, model, stream, seed), "bank": bank}
    rules, banks, episodes, counts = score_phase(st, llm, model, stream, seed, items, emb, tasks, baseline,
                                                 explore_seed, rep_offset, B.self_tag, base, "build", None,
                                                 workers, progress)
    out.mkdir(parents=True, exist_ok=True)
    for f, bank_ in banks.items():
        S.save_bank(out / f"bank_{f}.json", bank_, rules[f],
                    note=f"study {st.name}; model {model}; stream {stream}; seed {seed}; bank {bank}; family {f}")
    write_jsonl(out / "episodes.jsonl", episodes)
    summary = _summary(st, model, stream, seed, bank, episodes, items, *counts)
    write_json(out / "build_summary.json", summary)
    return summary


def score_phase(st: Study, llm, model: str, stream: str, seed: int, items: dict, emb: dict, tasks: dict,
                baseline: dict, explore_seed: int, rep_offset: int, self_tag: bool, base: dict, stage: str,
                phase: str | None, workers: int = 1, progress: Progress | None = None) -> tuple:
    """One score phase: `model` works through the score tasks `epochs` times over the FROZEN `items`
    (its own, or another model's for relearn), scores start from zero and are updated after every task.
    Returns (rules, banks, episodes, (calls, paid calls, cost)). stage names the solve calls in the call
    log ("build", or "relearn"); a self-tag call is stage "selfmark", or "<phase>_tag" when `phase` is given."""
    from msr.retrieval import Index

    B = st.build
    index = Index()
    for iid, it in items.items():
        index.add(iid, emb[it["task_id"]])
    rules = make_rules(st)
    banks = {f: {iid: rules[f].new_record() for iid in items} for f in rules}
    score_ids = st.score_ids(stream, seed)
    episodes = []
    n_calls = paid = 0
    cost = 0.0
    tag_meta = {"phase": phase} if phase else {}
    tag_stage = f"{phase}_tag" if phase else "selfmark"     # relearn's tags: "relearn_tag" (its own cost line)

    def count(r):
        nonlocal n_calls, paid, cost
        n_calls += 1
        if not r.cached:
            paid += 1
            cost += r.cost_usd

    for epoch in range(B.epochs):
        repeat = epoch + rep_offset
        for g0 in range(0, len(score_ids), B.batch):
            group = list(enumerate(score_ids[g0:g0 + B.batch], start=g0))
            # 1) choose what to show, with the scores as they stand at the start of the group
            plans = []
            for pos, tid in group:
                cands = index.search(emb[tid], B.candidates)
                if B.drive == "relevance":
                    score_norm = {}
                else:
                    rule = rules[B.drive]
                    score_norm = {i: rule.normalised(banks[B.drive][i]) for i, _ in cands}
                shown, probs, explored = select_items(cands, score_norm, B.n_show, B.w_score, B.epsilon,
                                                      B.explore_pool, task_rng(explore_seed, epoch, tid), B.drive)
                plans.append({"pos": pos, "tid": tid, "cands": cands, "shown": shown,
                              "probs": probs, "explored": explored,
                              "cand_probs": candidate_probs(cands, score_norm, shown, B.w_score, B.epsilon, B.drive),
                              "cand_scores": {i: round(float(v), 6) for i, v in score_norm.items()}})
            # 2) the solve calls
            jobs = []
            for pl in plans:
                texts = [items[i]["text"] for i in shown_order_for_prompt(pl["shown"])]
                system, user = messages(stream, tasks[pl["tid"]], texts, st.prompt_variant)
                jobs.append(dict(model=model, user=user, system=system, repeat=repeat, max_tokens=st.max_tokens,
                                 meta={**base, "stage": stage, "epoch": epoch, "task_id": pl["tid"],
                                       "position": pl["pos"], "item_id": pl["shown"][0] if pl["shown"] else None,
                                       "items": list(pl["shown"]), "repeat": repeat}))
            for pl, r in zip(plans, run_jobs(llm, jobs, workers, progress)):
                det = grade_detail(st, stream, tasks[pl["tid"]], r.answer)
                pl["correct"] = bool(det["correct"])
                pl["ungraded"] = det.get("ungraded")
                pl["parsed"] = det["parsed_text"] if stream == "ddxplus" else det["parsed"]
                pl["call_id"] = r.call_id
                count(r)
            # 3) the self-tag calls: one per shown item
            sm_jobs, sm_where = [], []
            for pl in plans:
                pl["tags"], pl["tag_calls"] = {}, []
                if not self_tag:
                    continue
                for iid in pl["shown"]:
                    user = selftag_prompt(stream, tasks[pl["tid"]], items[iid]["text"], str(pl["parsed"]),
                                          pl["correct"], B.self_tag_sees_grade)
                    sm_jobs.append(dict(model=model, user=user, system=None, repeat=repeat, max_tokens=st.max_tokens,
                                        meta={**base, **tag_meta, "stage": tag_stage, "epoch": epoch,
                                              "task_id": pl["tid"], "position": pl["pos"], "item_id": iid,
                                              "items": [iid], "shown": list(pl["shown"]), "correct": pl["correct"],
                                              "sees_grade": B.self_tag_sees_grade, "repeat": repeat}))
                    sm_where.append((pl, iid))
            for (pl, iid), r in zip(sm_where, run_jobs(llm, sm_jobs, workers, progress)):
                pl["tags"][iid] = parse_mark(r.answer)
                pl["tag_calls"].append(r.call_id)
                count(r)
            # 4) update every family of every shown item, in task order
            for pl in plans:
                for iid in pl["shown"]:
                    update_families(rules, banks, iid, pl["correct"], pl["tags"].get(iid),
                                    baseline.get(pl["tid"]), model)
                episodes.append(mark({
                    "epoch": epoch, "position": pl["pos"], "task_id": pl["tid"],
                    "candidates": [[i, r] for i, r in pl["cands"]],
                    "shown": pl["shown"], "probs": pl["probs"], "explored": pl["explored"],
                    "parsed": pl["parsed"], "correct": pl["correct"], "no_memory": baseline.get(pl["tid"]),
                    "tags": pl["tags"], "call_id": pl["call_id"], "tag_call_ids": pl["tag_calls"],
                    "cand_probs": pl["cand_probs"], "cand_scores": pl["cand_scores"],
                }, pl["ungraded"]))
    return rules, banks, episodes, (n_calls, paid, cost)


def _summary(st, model, stream, seed, bank, episodes, items, n_calls, paid, cost) -> dict:
    visits = {i: 0 for i in items}
    for e in episodes:
        for i in e["shown"]:
            visits[i] += 1
    v = np.array(list(visits.values()) or [0])
    by_epoch = []
    for ep in range(st.build.epochs):
        es = [e for e in episodes if e["epoch"] == ep]
        by_epoch.append({"epoch": ep, "success": round(float(np.mean([e["correct"] for e in es])), 4) if es else None,
                         "explored": round(float(np.mean([any(e["explored"]) for e in es if e["shown"]] or [0])), 4)})
    tags = {m: 0 for m in MARKS}
    for e in episodes:
        for t in e["tags"].values():
            tags[t] += 1
    b0 = [e["no_memory"] for e in episodes if e["no_memory"] is not None]
    return {
        "complete": True, "study": st.name, "model": model, "stream": stream, "seed": seed, "bank": bank,
        "items": len(items), "items_correct": int(sum(1 for i in items.values() if i["correct"])),
        "score_tasks": st.n_score, "epochs": st.build.epochs, "episodes": len(episodes),
        "success_by_epoch": by_epoch,
        "success_with_memory": round(float(np.mean([e["correct"] for e in episodes])), 4) if episodes else None,
        "success_no_memory": round(float(np.mean(b0)), 4) if b0 else None,
        "visits_mean": round(float(v.mean()), 3), "visits_median": float(np.median(v)),
        "items_with_5plus_visits": int((v >= 5).sum()), "items_never_shown": int((v == 0).sum()),
        "tags": tags, "calls": n_calls, "paid_calls": paid, "cost_usd": round(cost, 6),
        "drive": st.build.drive,
    }


# ---------------------------------------------------------------------------
# Stage runner
# ---------------------------------------------------------------------------


def run_stage(st: Study, llm, embeddings: dict, workers: int = 8, printer=print) -> None:
    """WRITE phase for every (model, stream, seed), then the no-memory runs, then every bank's
    score phase (several banks at once; each bank is one sequential stream of tasks)."""
    from msr.study import plan_calls
    plan = plan_calls(st)
    tasks_by_stream = {s: D.task_index(s) for s in st.streams}
    combos = [(m, s, k) for s in st.streams for k in st.seeds for m in st.models]

    todo_w = [c for c in combos if not write_done(st, *c)]
    if todo_w:
        prog = Progress("write", st.build.n_write * len(todo_w), printer)
        for m, s, k in todo_w:
            run_write(st, llm, m, s, k, tasks_by_stream[s], workers, prog)
    if st.build.write_repeat:
        todo2 = [c for c in combos if not write2_done(st, *c)]
        if todo2:
            prog2 = Progress("write, second answer", st.build.n_write * len(todo2), printer)
            for m, s, k in todo2:
                run_write2(st, llm, m, s, k, tasks_by_stream[s], workers, prog2)
    if st.build.self_rating:
        todor = [c for c in combos if not selfrate_done(st, *c)]
        if todor:
            progr = Progress("self-rating", st.build.n_write * len(todor), printer)
            for m, s, k in todor:
                run_selfrate(st, llm, m, s, k, workers, progr)
    if st.build.no_memory_run:
        todo0 = [c for c in combos if not build0_done(st, *c)]
        if todo0:
            prog0 = Progress("build0", st.n_score * len(todo0), printer)
            for m, s, k in todo0:
                run_build0(st, llm, m, s, k, tasks_by_stream[s], workers, prog0)

    banks = [(m, s, k, b) for m, s, k in combos for b in st.banks_of(m)]
    todo = [x for x in banks if not bank_done(st, *x)]
    if not todo:
        return
    per_bank = (sum(plan["calls"]["build"].values()) + sum(plan["calls"]["selfmark"].values())) // max(1, len(banks))
    prog = Progress("score phase", per_bank * len(todo), printer)
    inner = max(1, min(workers, st.build.batch))
    with ThreadPoolExecutor(max_workers=max(1, min(workers, len(todo)))) as ex:
        futs = [ex.submit(run_score_phase, st, llm, m, s, k, b, embeddings[s], tasks_by_stream[s], inner, prog)
                for m, s, k, b in todo]
        for f in futs:
            f.result()
