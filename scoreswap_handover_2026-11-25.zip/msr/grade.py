"""Parse a model's raw answer and grade it the way StreamBench (commit cf72f26) does.

ddxplus  (stream_bench/benchmarks/ddxplus.py, postprocess_generation + process_results)
    Lower-case the answer, find every "<digits>." with re.findall(r"(\\d+)\\."):
    exactly one number -> that number if it is a label (0-48), else 49 (NOTINLABEL);
    several numbers   -> the FIRST one, whatever it is;
    none              -> 49 (NOTINLABEL).
    Correct when that number equals the gold label. The diagnosis words are never read.

bird     (text2sql_utils/string_formatter.py parse_sql, sqlite_interpreter.py execute_sql)
    parse_sql takes the ```sql block (or the text after the first ```), strips it and puts
    "SELECT " in front unless it already starts with the exact, upper-case word SELECT.
    (So an answer starting with "WITH" or lower-case "select" becomes invalid SQL and is
    graded wrong. 7 of the 1534 gold queries start with WITH. ``faithful=False`` keeps a
    leading SELECT/WITH of any case and changes nothing else.)
    Then predicted and gold SQL are executed and graded correct iff
    set(predicted rows) == set(gold rows): row order and duplicate rows are ignored,
    column order counts, 1 == 1.0. An empty result raises IndexError inside StreamBench
    (it builds a table header from row 0), so an empty predicted or gold result is wrong.

Differences from StreamBench, all on the safety side:
    * the database is opened read-only and immutable (``file:...?mode=ro&immutable=1``),
      with PRAGMA query_only and an authorizer that allows only reads (no ATTACH, no
      writes, no schema changes), so a model's SQL can never change a database file;
    * the time limit is per query (default 30 s); StreamBench's func_timeout(30) covers
      the predicted AND the gold query together;
    * gold results are computed once per (database, gold SQL) and cached in memory, and
      predicted results once per (database, SQL); both can also be kept on disk
      (set_disk_cache). The cache never changes a grade, it only skips re-running SQL;
    * a predicted result longer than ``max_rows`` (default 2,000,000) is stopped and wrong.

The time limit counts the query's own CPU time (changed 24 Nov 2026, dress rehearsal fault 2).
    Everyday picture: an exam timed by how long the student actually writes, not by the clock
    on the wall, so a noisy room does not cost anyone marks. ``DEFAULT_TIMEOUT`` (30 s) is
    measured with ``time.thread_time()`` inside SQLite's progress handler; SQLite runs a query
    in the thread that asked for it, so that clock counts this query's work and nothing else.
    A busy machine slows the wall clock, not this one, so the same query gets the same grade on
    a quiet or a busy machine. The pre-registration's "30 s per query" therefore means 30 s of
    the query's own CPU time. A wall-clock cap (``WALL_CAP_FACTOR`` x the limit, 300 s) still
    stops a query that waits on the disk for ever. (Not perfectly fixed: a very busy machine
    can still slow CPU work a little, through shared caches, but not by the factors seen on
    the wall clock.)

A query that times out is never graded wrong and never stored on disk.
    It is run once more at once. If it times out again, the answer is "ungraded: timeout"
    (``grade_detail(...)["ungraded"] == "timeout"``, correct False, counted by
    ``ungraded_count()``), and the query waits in memory (``pending_timeouts()``) without being
    run again. At the end of a stage, with nothing else running, ``retry_pending()`` runs each
    waiting query once more: a result that now finishes is cached as usual, so grading the
    answer again gives its real grade; one that still times out stays ungraded for the rest of
    the process and is reported, never silently wrong. Old disk entries that say "timed out"
    (written by earlier code) are treated as missing.

A big result is kept as a fingerprint (changed 24 Nov 2026, dress rehearsal fault 5).
    A predicted result with more than ``CACHE_MAX_ROWS`` distinct rows is cached (in memory
    and on disk) as its number of distinct rows plus a digest of the SET of its rows
    (``result_fingerprint``), not as the rows. Values are written in one fixed form first, so
    that rows Python counts as equal (1 == 1.0 == True, 0.0 == -0.0) get the same digest and
    rows it counts as different (text '1' and bytes b'1') do not. Grading compares sets when
    both sides have their rows, and fingerprints otherwise (the gold side's fingerprint is
    computed once and kept in memory), with exactly the grades the set comparison gives.
"""
from __future__ import annotations

import re
import sqlite3
import threading
import time
from pathlib import Path

from msr.data import LABEL2TEXT, NOTINLABEL, TEXT2LABEL, bird_db_path, get_label_text

#: Seconds of the query's own CPU time (time.thread_time) before it is stopped.
DEFAULT_TIMEOUT = 30.0
#: A query is also stopped after this many times its CPU limit on the wall clock (a query that
#: waits on the disk uses no CPU time; this cap stops it all the same).
WALL_CAP_FACTOR = 10.0
MAX_ROWS = 2_000_000
_PROGRESS_EVERY = 1000  # SQLite VM steps between time checks (overhead measured < 2 %)
# The two clocks, as module names so that the tests can replace them.
_wall = time.monotonic
_cpu = time.thread_time

# Measured 2026-11-23 over all 1534 bird gold queries (read-only, 30 s per query):
# 1533 run and match themselves; this one did not finish even in 360 s, so with the default
# limit it is "ungraded: timeout" whatever the model answers (StreamBench: wrong, 30 s for both
# queries). The studies remove it before the splits (exclude_tasks).
KNOWN_SLOW_GOLD = {"bird-0701"}  # codebase_community
# Gold queries that start with WITH: StreamBench's parse_sql turns them into "SELECT WITH ...".
GOLD_STARTS_WITH_WITH = {"bird-0944", "bird-0955", "bird-1011", "bird-1013", "bird-1014",
                         "bird-1015", "bird-1016"}  # all formula_1


# --------------------------------------------------------------------------- ddxplus
def parse_ddxplus(raw_text: str | None) -> int:
    """StreamBench MedicalDiagnosisBench.postprocess_generation (without the prints)."""
    res = (raw_text or "").lower().strip()
    numbers = re.findall(pattern=r"(\d+)\.", string=res)
    if len(numbers) == 1:
        number = int(numbers[0])
        return number if number in LABEL2TEXT else NOTINLABEL
    if len(numbers) > 1:
        return int(numbers[0])
    return NOTINLABEL


# --------------------------------------------------------------------------- bird
_SQL_BLOCK = r"```sql\n([\s\S]*?)\n```"


def parse_sql(plain_result: str | None, faithful: bool = True) -> str:
    """StreamBench string_formatter.parse_sql for a string answer.

    faithful=False only changes the last step: a block that already starts with
    SELECT or WITH (any case) is left as it is instead of getting "SELECT " in front.
    """
    plain_result = plain_result or ""
    sql_block = plain_result
    SQL_PREFIX = "```sql\n"
    SQL_SUFFIX = "```"
    if (sql_block[:len(SQL_PREFIX)] == SQL_PREFIX) and (sql_block[-len(SQL_SUFFIX):] == SQL_SUFFIX):
        sql_block = sql_block[len(SQL_PREFIX):-len(SQL_SUFFIX)]
    elif '```' in sql_block:
        match = re.search(_SQL_BLOCK, plain_result)
        if match:
            sql_block = match.group(1)
        else:
            sql_block = sql_block.replace('```sql\n', '```').replace('```SQL\n', '```')
            sql_block = sql_block.split('```', maxsplit=1)[-1]
            sql_block = sql_block.replace('```', '').strip()
    sql_block = sql_block.strip()
    if faithful:
        if 'SELECT' != sql_block[:len('SELECT')]:
            sql_block = 'SELECT ' + sql_block
    else:
        if not re.match(r"(?is)\s*(select|with)\b", sql_block):
            sql_block = 'SELECT ' + sql_block
    return sql_block


_READ_ACTIONS = {
    sqlite3.SQLITE_SELECT,
    sqlite3.SQLITE_READ,
    sqlite3.SQLITE_FUNCTION,
    getattr(sqlite3, "SQLITE_RECURSIVE", 33),
}


def _read_only_authorizer(action, arg1, arg2, dbname, source):
    return sqlite3.SQLITE_OK if action in _READ_ACTIONS else sqlite3.SQLITE_DENY


def connect_readonly(db_path: str | Path) -> sqlite3.Connection:
    """Open a SQLite file so that nothing run on the connection can change any file."""
    p = Path(db_path).resolve()
    if not p.is_file():
        raise FileNotFoundError(f"{p} not found; run  python scripts/get_data.py")
    # immutable=1: no locks, no -wal/-shm side files (card_games is a WAL-mode file).
    conn = sqlite3.connect(p.as_uri() + "?mode=ro&immutable=1", uri=True)
    conn.execute("PRAGMA query_only = ON")
    if hasattr(conn, "setlimit") and hasattr(sqlite3, "SQLITE_LIMIT_ATTACHED"):
        conn.setlimit(sqlite3.SQLITE_LIMIT_ATTACHED, 0)
    conn.set_authorizer(_read_only_authorizer)
    return conn


def run_sql(db_path: str | Path, sql: str, timeout: float = DEFAULT_TIMEOUT,
            max_rows: int = MAX_ROWS, wall_cap: float | None = None) -> dict:
    """Execute one SQL statement read-only with a time limit.

    `timeout` is seconds of this query's own CPU time (time.thread_time, read in SQLite's
    progress handler; SQLite runs the query in this thread, so other work on the machine does
    not count). `wall_cap` (default WALL_CAP_FACTOR x timeout) also stops a query on the wall
    clock, for one that waits instead of working.

    Returns {"rows": list[tuple] | None, "error": str | None, "timed_out": bool,
             "limit": None | "cpu" | "wall", "transient": bool,
             "seconds": float (wall clock), "cpu_seconds": float}.
    A timed-out query has error "timeout" and `limit` says which clock stopped it.
    "transient" is True when the error came from the machine, not from the SQL (the file could
    not be opened, out of memory, a disk error): such a result is never cached.
    """
    t0, c0 = _wall(), _cpu()
    cap = WALL_CAP_FACTOR * timeout if wall_cap is None else wall_cap
    state = {"limit": None, "next_cpu_check": t0 + timeout}

    def _progress():
        now = _wall()
        if now >= state["next_cpu_check"]:
            used = _cpu() - c0
            if used > timeout:
                state["limit"] = "cpu"
                return 1  # SQLite aborts the statement ("interrupted")
            # One thread cannot use CPU time faster than the wall clock runs, so the CPU limit
            # cannot be reached before this much more wall time has passed: read the (slower)
            # CPU clock only then.
            state["next_cpu_check"] = now + (timeout - used)
        if now - t0 > cap:
            state["limit"] = "wall"
            return 1
        return 0

    def _done(rows, error, transient):
        return {"rows": rows, "error": error, "timed_out": state["limit"] is not None,
                "limit": state["limit"], "transient": transient,
                "seconds": _wall() - t0, "cpu_seconds": _cpu() - c0}

    try:
        conn = connect_readonly(db_path)
    except Exception as e:  # missing file, cannot open: the machine's state, not the SQL
        return _done(None, f"{type(e).__name__}: {e}", True)
    rows, error, transient = None, None, False
    try:
        conn.set_progress_handler(_progress, _PROGRESS_EVERY)
        cur = conn.cursor()
        cur.execute(sql)
        out = []
        while True:
            chunk = cur.fetchmany(10000)
            if not chunk:
                break
            out.extend(chunk)
            if len(out) > max_rows:
                raise _TooManyRows(f"more than {max_rows} rows")
        rows = out
    except _TooManyRows as e:
        error = f"row cap: {e}"
    except Exception as e:  # syntax errors, denied writes, interrupts, ...
        if state["limit"] is not None:
            error = "timeout"
        else:
            error = f"{type(e).__name__}: {e}"
            transient = _transient_error(error)
    finally:
        try:
            conn.close()
        except Exception:
            pass
    return _done(rows, error, transient)


class _TooManyRows(Exception):
    pass


# Error texts that come from the machine, not from the SQL. A result with one of them is never
# cached (it would grade the same answer wrong for ever). Lower case.
_TRANSIENT_WORDS = ("memoryerror", "out of memory", "disk i/o error", "unable to open database file",
                    "database is locked", "database or disk is full", "filenotfounderror")


def _transient_error(error: str | None) -> bool:
    e = (error or "").lower()
    return any(w in e for w in _TRANSIENT_WORDS)


# ---- result caches (they never change a grade; they only skip running the same SQL twice)
# Everyday picture: the examiner keeps the answer key worked out once per question, and a
# note of what each submitted query returned, so the same query on the same database is
# not run again. In memory always; also on disk (data/grade_cache/) once set_disk_cache()
# is called, so a resumed run grades exactly as before without re-running slow queries.
# A timed-out query is never kept on disk (see the module docstring).
_GOLD_CACHE: dict[tuple, dict] = {}
_GOLD_LOCK = threading.Lock()
_PRED_CACHE: dict[tuple, dict] = {}
_PRED_LOCK = threading.Lock()
_DISK_DIR: Path | None = None
#: A predicted result with more distinct rows than this is kept as a fingerprint (its number of
#: distinct rows and a digest of its set of rows), not as the rows (they would use too much memory).
CACHE_MAX_ROWS = 10_000

# ---- queries that timed out (memory only; see the module docstring)
_TIMEOUT_LOCK = threading.Lock()
_PENDING: dict[tuple, dict] = {}   # timed out twice: waiting for retry_pending()
_GAVE_UP: dict[tuple, dict] = {}   # still timed out at retry_pending(): ungraded for the rest of the process
_UNGRADED = 0                      # grade_detail calls that returned ungraded


def set_disk_cache(path: str | Path | None) -> None:
    """Also keep gold and predicted query results on disk under `path` (None = memory only)."""
    global _DISK_DIR
    _DISK_DIR = Path(path) if path else None
    if _DISK_DIR is not None:
        (_DISK_DIR / "gold").mkdir(parents=True, exist_ok=True)
        (_DISK_DIR / "pred").mkdir(parents=True, exist_ok=True)


def _disk_key(kind: str, db: str, sql: str, timeout: float, max_rows: int | None = None) -> str:
    import hashlib
    # The database's file name (not its full path) so the cache works on any machine.
    text = "\x1f".join([kind, Path(db).name, sql, repr(float(timeout)), repr(max_rows)])
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _cacheable(entry) -> bool:
    """True for a result that depends on the SQL and the database alone: not a timeout, not an
    error that came from the machine, not a big result that could not be fingerprinted.
    Old disk entries (no "transient" key) are judged by their error text."""
    return (isinstance(entry, dict) and not entry.get("timed_out") and not entry.get("transient")
            and not entry.get("too_big") and not _transient_error(entry.get("error")))


def _disk_get(folder: str, key: str):
    """A result kept on disk, or None. Timed-out entries (old code wrote them) count as missing."""
    if _DISK_DIR is None:
        return None
    f = _DISK_DIR / folder / f"{key}.pkl"
    if not f.exists():
        return None
    import pickle
    try:
        with open(f, "rb") as fh:
            entry = pickle.load(fh)   # our own cache files only (data/ is never shared)
    except Exception:
        return None
    return entry if _cacheable(entry) else None


def _disk_put(folder: str, key: str, value: dict) -> None:
    if _DISK_DIR is None or not _cacheable(value):   # a timeout is never written to disk
        return
    import os
    import pickle
    import tempfile
    path = _DISK_DIR / folder
    path.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=key[:16], suffix=".tmp", dir=str(path))
    try:
        with os.fdopen(fd, "wb") as fh:
            pickle.dump(value, fh, protocol=4)
        os.replace(tmp, path / f"{key}.pkl")
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass


def _disk_read(kind: str, db: str, sql: str, timeout: float, max_rows: int):
    if _DISK_DIR is None:
        return None
    if kind == "gold":
        return _disk_get("gold", _disk_key("gold", db, sql, timeout))
    hit = _disk_get("pred", _disk_key("pred", db, sql, timeout, max_rows))
    if hit is None:   # a big result, kept as a fingerprint under its own key
        hit = _disk_get("pred", _disk_key("predfp", db, sql, timeout, max_rows))
    return hit


def _disk_write(kind: str, db: str, sql: str, timeout: float, max_rows: int, entry: dict) -> None:
    if _DISK_DIR is None:
        return
    if kind == "gold":
        _disk_put("gold", _disk_key("gold", db, sql, timeout), entry)
    elif entry.get("fp") is not None:
        # Its own key, so that older code (which compares row sets only) never reads it.
        _disk_put("pred", _disk_key("predfp", db, sql, timeout, max_rows), entry)
    else:
        _disk_put("pred", _disk_key("pred", db, sql, timeout, max_rows), entry)


# ---- fingerprints of big results
_PLAIN_TYPES = frozenset({type(None), int, str, bytes})


def _fixed(v):
    """The one form of a float or bool that Python counts as equal to it: an integral float
    becomes an int (1.0 -> 1, -0.0 -> 0, 1e20 -> 100000000000000000000), True/False 1/0;
    any other float stays (its repr is exact)."""
    if type(v) is float:
        return int(v) if v.is_integer() else v
    return int(v)


def result_fingerprint(rows) -> dict:
    """{"n_distinct": number of distinct rows, "digest": sha256 hex of the SET of rows}.

    Two results get the same fingerprint exactly when set(rows_a) == set(rows_b) in Python
    (StreamBench's rule): row order and duplicate rows do not count, column order does,
    1 == 1.0 == True, 0.0 == -0.0, text '1' != bytes b'1' != 1, None only equals None
    (barring a sha256 collision). Each row is written as the repr of its values in one fixed
    form (``_fixed``); the distinct forms are sorted and hashed with their lengths.
    The one difference: SQLite never returns NaN (it stores NULL), and a NaN would count as
    equal to itself here. Raises TypeError for a value that is not None, int, float, str,
    bytes or bool."""
    import hashlib
    forms = set()
    for row in rows:
        fix = False
        for v in row:
            t = type(v)
            if t is float or t is bool:
                fix = True
            elif t not in _PLAIN_TYPES:
                raise TypeError(f"no fixed form for a {t.__name__} value in a result row")
        if fix:
            forms.add(repr(tuple([v if type(v) in _PLAIN_TYPES else _fixed(v) for v in row])))
        else:
            forms.add(repr(row if type(row) is tuple else tuple(row)))
    h = hashlib.sha256(b"scoreswap result set v1\n")
    for f in sorted(forms):
        b = f.encode("utf-8", "surrogatepass")
        h.update(len(b).to_bytes(8, "big"))
        h.update(b)
    return {"n_distinct": len(forms), "digest": h.hexdigest()}


def _summarise(p: dict, big_as_fingerprint: bool) -> dict:
    """A run_sql result cut down to what grading needs: the rows become a set ("set"), or, for
    a big predicted result, a fingerprint ("fp", with "set" None)."""
    rows = p.pop("rows")
    entry = {**p, "n_rows": None if rows is None else len(rows), "set": None}
    if rows is not None:
        s = set(rows)
        rows = None
        if big_as_fingerprint and len(s) > CACHE_MAX_ROWS:
            try:
                entry["fp"] = result_fingerprint(s)
            except TypeError:
                entry["set"], entry["too_big"] = s, True   # no fixed form: use once, do not cache
        else:
            entry["set"] = s
    return entry


def _run(kind: str, db: str, sql: str, timeout: float, max_rows: int) -> dict:
    return _summarise(run_sql(db, sql, timeout=timeout, max_rows=max_rows),
                      big_as_fingerprint=(kind == "pred"))


def _memory(kind: str):
    return (_GOLD_CACHE, _GOLD_LOCK) if kind == "gold" else (_PRED_CACHE, _PRED_LOCK)


def _mem_key(kind: str, db: str, sql: str, timeout: float, max_rows: int) -> tuple:
    return (db, sql, timeout) if kind == "gold" else (db, sql, timeout, max_rows)


def _keep(kind: str, db: str, sql: str, timeout: float, max_rows: int, entry: dict) -> None:
    """Cache a finished result in memory and on disk (only one that depends on the SQL alone)."""
    if not _cacheable(entry):
        return
    _disk_write(kind, db, sql, timeout, max_rows, entry)
    mem, lock = _memory(kind)
    with lock:
        mem[_mem_key(kind, db, sql, timeout, max_rows)] = entry


def _result(kind: str, db: str, sql: str, timeout: float, max_rows: int) -> dict:
    """The result of one query: from memory, from disk, or by running it (with one immediate
    retry after a timeout). A query that timed out twice is not run again before retry_pending()."""
    mem, lock = _memory(kind)
    mkey = _mem_key(kind, db, sql, timeout, max_rows)
    with lock:
        hit = mem.get(mkey)
    if hit is not None:
        return hit
    hit = _disk_read(kind, db, sql, timeout, max_rows)
    if hit is not None:
        with lock:
            mem[mkey] = hit
        return hit
    tkey = (kind, db, sql, timeout, max_rows)
    with _TIMEOUT_LOCK:
        waiting = _GAVE_UP.get(tkey) or _PENDING.get(tkey)
    if waiting is not None:
        return waiting
    hit = _run(kind, db, sql, timeout, max_rows)
    if hit["timed_out"]:
        hit = _run(kind, db, sql, timeout, max_rows)   # once more, at once
    if hit["timed_out"]:
        with _TIMEOUT_LOCK:
            if tkey not in _GAVE_UP:
                _PENDING.setdefault(tkey, hit)
        return hit
    _keep(kind, db, sql, timeout, max_rows, hit)
    return hit


def gold_result(task: dict, timeout: float = DEFAULT_TIMEOUT) -> dict:
    """run_sql on the task's gold SQL, cached per (database, SQL, timeout).
    {"error", "timed_out", "seconds", "n_rows", "set", ...}; the rows are always kept as a set."""
    return _result("gold", str(_task_db(task)), task["SQL"], float(timeout), MAX_ROWS)


def predicted_result(db_path: str | Path, sql: str, timeout: float = DEFAULT_TIMEOUT,
                     max_rows: int = MAX_ROWS) -> dict:
    """run_sql on a predicted query, summarised to what grading needs and cached per
    (database, SQL, timeout, row cap): {"error", "timed_out", "seconds", "n_rows", "set", ...}.
    A result with more than CACHE_MAX_ROWS distinct rows has "set" None and "fp" (its fingerprint)."""
    return _result("pred", str(db_path), sql, float(timeout), int(max_rows))


def clear_gold_cache() -> None:
    with _GOLD_LOCK:
        _GOLD_CACHE.clear()


def clear_pred_cache() -> None:
    with _PRED_LOCK:
        _PRED_CACHE.clear()


# ---- the timeout contract (see the module docstring)
def pending_timeouts() -> list:
    """The queries that timed out twice and wait for retry_pending(): [(kind, database, sql)],
    kind "gold" or "pred"."""
    with _TIMEOUT_LOCK:
        return [(k[0], k[1], k[2]) for k in _PENDING]


def retry_pending(printer=print) -> dict:
    """Run each waiting query once more, one at a time (call it at the end of a stage, with
    nothing else running). A result that now finishes is cached as usual (memory and disk), so
    grading its answers again gives their real grade. A query that still times out stays
    ungraded for the rest of the process and is not run again by later grading.
    Returns {"retried": n, "graded": k, "still_timed_out": m}."""
    with _TIMEOUT_LOCK:
        todo = list(_PENDING)
    graded = still = 0
    if todo:
        printer(f"  grading: {len(todo)} SQL quer{'y' if len(todo) == 1 else 'ies'} timed out twice; "
                f"running each once more, one at a time ...")
    for tkey in todo:
        kind, db, sql, timeout, max_rows = tkey
        hit = _run(kind, db, sql, timeout, max_rows)
        if hit["timed_out"]:
            hit["gave_up"] = True
            with _TIMEOUT_LOCK:
                _PENDING.pop(tkey, None)
                _GAVE_UP[tkey] = hit
            still += 1
            printer(f"    still timed out after {timeout:g} s of CPU time ({'gold' if kind == 'gold' else 'predicted'}"
                    f" query on {Path(db).name}): {' '.join(sql.split())[:120]}")
            continue
        _keep(kind, db, sql, timeout, max_rows, hit)
        with _TIMEOUT_LOCK:
            _PENDING.pop(tkey, None)
        graded += 1
    if todo:
        printer(f"  grading: {graded} of {len(todo)} now finished; {still} stay ungraded (timeout)")
    return {"retried": len(todo), "graded": graded, "still_timed_out": still}


def ungraded_count() -> int:
    """How many grade_detail calls returned ungraded so far in this process."""
    with _TIMEOUT_LOCK:
        return _UNGRADED


def reset_timeouts() -> None:
    """Forget every waiting or given-up query and set the ungraded count to 0 (for tests)."""
    global _UNGRADED
    with _TIMEOUT_LOCK:
        _PENDING.clear()
        _GAVE_UP.clear()
        _UNGRADED = 0


def _task_db(task: dict) -> Path:
    return Path(task["db_path"]) if task.get("db_path") else bird_db_path(task["db_id"])


# --------------------------------------------------------------------------- public API
def parse_answer(stream: str, raw_text: str | None, task: dict | None = None,
                 faithful: bool = True):
    """ddxplus -> int label (49 = no valid label); bird -> SQL string."""
    if stream == "ddxplus":
        return parse_ddxplus(raw_text)
    if stream == "bird":
        return parse_sql(raw_text, faithful=faithful)
    raise ValueError(f"unknown stream {stream!r}")


def _ungraded(out: dict, which: str, r: dict) -> dict:
    """Mark an answer "ungraded: timeout": never wrong, counted, and said why."""
    global _UNGRADED
    clock = "the wall-clock cap" if r.get("limit") == "wall" else "its own CPU time"
    when = ("and once more at the end of the stage" if r.get("gave_up")
            else "and waits for retry_pending() at the end of the stage")
    out["correct"], out["ungraded"] = False, "timeout"
    out["reason"] = f"ungraded: timeout (the {which} query timed out twice on {clock}, {when})"
    with _TIMEOUT_LOCK:
        _UNGRADED += 1
    return out


def _gold_fingerprint(g: dict) -> dict:
    """The gold result's fingerprint, computed once and kept in the (memory) cache entry."""
    fp = g.get("fp")
    if fp is None:
        fp = result_fingerprint(g["set"])
        with _GOLD_LOCK:
            g["fp"] = fp
    return fp


def _same_rows(p: dict, g: dict) -> bool:
    """StreamBench's rule, set(predicted rows) == set(gold rows): by the sets when both are
    kept, by fingerprints when the predicted result is big (the gold side always keeps its set)."""
    if p.get("set") is not None:
        return p["set"] == g["set"]
    fp = p["fp"]
    if fp["n_distinct"] != len(g["set"]):
        return False
    return fp["digest"] == _gold_fingerprint(g)["digest"]


def grade_detail(stream: str, task: dict, raw_text: str | None, *,
                 timeout: float = DEFAULT_TIMEOUT, gold_timeout: float | None = None,
                 faithful: bool = True, max_rows: int = MAX_ROWS) -> dict:
    """Grade one answer and say why. Keys: correct, ungraded, reason, parsed, gold, and timings
    for bird. ``ungraded`` is None, or "timeout" when the predicted or the gold query still timed
    out after one immediate retry: then correct is False and reason starts "ungraded: timeout"
    (count such answers as ungraded, never as wrong)."""
    if stream == "ddxplus":
        pred = parse_ddxplus(raw_text)
        gold = task["label"] if "label" in task else TEXT2LABEL[task["PATHOLOGY"].lower().strip()]
        if pred == gold:
            reason = "label matches"
        elif pred == NOTINLABEL:
            reason = "no valid '<number>.' label found"
        elif pred not in LABEL2TEXT:
            reason = f"first number {pred} is not a label"
        else:
            reason = f"wrong label ({pred} vs gold {gold})"
        return {"stream": stream, "task_id": task.get("task_id"), "correct": pred == gold, "ungraded": None,
                "reason": reason, "parsed": pred, "parsed_text": get_label_text(pred), "gold": gold}

    if stream != "bird":
        raise ValueError(f"unknown stream {stream!r}")
    sql = parse_sql(raw_text, faithful=faithful)
    out = {"stream": stream, "task_id": task.get("task_id"), "correct": False, "ungraded": None, "parsed": sql,
           "gold": task["SQL"], "seconds_pred": None, "seconds_gold": None}
    g = gold_result(task, timeout=gold_timeout if gold_timeout is not None else timeout)
    out["seconds_gold"] = round(g["seconds"], 3)
    if g.get("timed_out"):
        return _ungraded(out, "gold", g)
    if g.get("error"):
        out["reason"] = f"gold query failed: {g['error']}"
        return out
    if g["n_rows"] == 0:
        out["reason"] = "gold result is empty (StreamBench raises IndexError: always wrong)"
        return out
    p = predicted_result(_task_db(task), sql, timeout=timeout, max_rows=max_rows)
    out["seconds_pred"] = round(p["seconds"], 3)
    if p.get("timed_out"):
        return _ungraded(out, "predicted", p)
    if p["error"]:
        out["reason"] = f"predicted query failed: {p['error']}"
        return out
    if not p["n_rows"]:
        out["reason"] = "predicted result is empty (StreamBench raises IndexError: wrong)"
        return out
    same = _same_rows(p, g)
    out["correct"] = same
    out["reason"] = "result sets equal" if same else "result sets differ"
    return out


def grade(stream: str, task: dict, raw_text: str | None, **kwargs) -> bool:
    """True if the answer is correct by StreamBench's rule; see grade_detail for the reason.
    An ungraded answer (timeout) is False here: use grade_detail to tell it from a wrong one."""
    return bool(grade_detail(stream, task, raw_text, **kwargs)["correct"])
