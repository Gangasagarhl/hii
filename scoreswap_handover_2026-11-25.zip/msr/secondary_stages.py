"""Registered secondary swap-day rules of the paid stages (pre-registration Part 8.2.18-8.2.21; open point 30).

Everyday picture: besides keeping or wiping the old mechanic's marks, the new mechanic could (a) re-solve the
job on each card himself and trust the cards whose written repair matches his own (re-answer), (b) read each
card and mark it 1-10 (judge), (c) use the marks the old mechanic gave each card the day he wrote it
(self-rating), or (d) throw away the old marks and earn his own on the same practice jobs (relearn). Each is
scored here exactly like the paper's swap-day rules: which card does it show first, and how often does that
card help, against keep and wipe; and how much of the home ranking signal its marks carry (theta).

Rules and their per-item score x (ranked within a probe task; the normalised score u enters the retrieval mix
u_mix = w_score u + (1 - w_score) relevance, as every score does):
  reanswer     swap cell: 1 if the reader's own write-phase answer to the item's write task agrees with the
               stored answer (msr.construct.answers_agree), else 0; home cell (its home value): the owner's
               SECOND no-memory answer to the write task (stage write2) against the stored one. u = x.
  judge        the rating 1..scale the cell's reader gave the stored item (stage judge; home cells: the owner
               rating its own items); a missing or unreadable rating is a tie at the scale's middle.
               u = (x - 1) / (scale - 1).
  self_rating  the owner's write-time rating of the item (stage selfrate), carried to every reader unchanged.
  relearn      swap cells of relearn.pairs only: the relearned bank's ranking score x and normalised score u of
               the headline family (msr.engine.Fam on runs/<study>/relearn/...), ranked as the owner's own bank
               would be.
Per (rule, cell, stream, order): first-shown success of the rule, of keep (the owner's headline scores) and of
wipe (every score at its start value: relevance only), on the cell's reader results (msr.engine.first_shown);
signed validity V and weight W of x on the reader's results (swap side) and of the rule's HOME version on the
owner's home results of the same tasks (home side): judge at home = the owner's own ratings (home cell's judge
file), self_rating = the same ratings, reanswer at home = the write2 agreement, relearn at home = the owner's
own headline scores (so relearn's theta is the share of the owner's home signal its relearned scores recover).
Per swap group and level (stream, or 'all' = equal weight per (swap, stream)): rule - keep and rule - wipe in
first-shown success, theta with the registered tests and Fieller set (msr.metrics.theta_tests), Cw at home and
after the swap. Intervals: msr.metrics.robust_variance, clustered by task id within stream and by WRITE TASK
within stream (the item id without its "@owner" suffix, shared across owners: revision 3's coding for every
statistic that pools owners). Not in any family; no log or Brier score (a rating is not a probability).
"""
from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np

from msr import metrics as M

NAN = float("nan")
RULES = ("reanswer", "judge", "self_rating", "relearn")
RULE_MEANING = {
    "reanswer": "the reader's own write-phase answer agrees with the stored answer (home: the owner's second answer)",
    "judge": "the reader's 1..scale rating of each stored item (home: the owner's rating of its own items)",
    "self_rating": "the owner's write-time 1..scale rating of each stored item, carried unchanged",
    "relearn": "the reader re-earns the headline scores on the owner's frozen items (relearn.pairs cells only)",
}


# ---------------------------------------------------------------------------
# small readers
# ---------------------------------------------------------------------------


def _jsonl(path: Path) -> list:
    if not Path(path).exists():
        return []
    out = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                out.append(json.loads(line))
    return out


def write_task(item_id) -> str:
    """The write task of an item id '<write task>@<owner>' (the id itself when it has no owner suffix)."""
    s = str(item_id)
    return s.rsplit("@", 1)[0] if "@" in s else s


def _ybar(y) -> np.ndarray:
    y = np.asarray(y, dtype=float)
    if y.ndim == 2:
        return y
    ok = np.isfinite(y)
    n = ok.sum(-1)
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(n > 0, np.where(ok, y, 0.0).sum(-1) / np.where(n > 0, n, 1), np.nan)


def _vw(x: np.ndarray, ybar: np.ndarray, present: np.ndarray) -> tuple:
    """Per-task signed validity V and weight W of score x against outcome means (msr.metrics)."""
    v, w = M.signed_validity_parts(np.where(present, x, np.nan), ybar, present)
    return np.asarray(v, dtype=float), np.asarray(w, dtype=float)


def _first_shown(cand_ok: np.ndarray, rel: np.ndarray, y: np.ndarray, u: np.ndarray, w_score: float,
                 valid: np.ndarray) -> np.ndarray:
    """First-shown success per task under normalised scores u (E, C) (msr.engine.first_shown, same mix and tie
    rule as the paper's arms); NaN on tasks dropped by the missing-cell rule."""
    from msr import engine as EN
    E, C = cand_ok.shape
    cand = np.where(cand_ok, np.arange(E * C).reshape(E, C), -1)
    T = EN.Table(cand, np.where(cand_ok, np.nan_to_num(rel), 0.0), np.asarray(y, dtype=float), task_ok=valid)
    uu = np.where(cand_ok, np.nan_to_num(u, nan=0.5), 0.5).ravel()
    fs, _ = EN.first_shown(T, uu, w_score)
    return np.asarray(fs, dtype=float)


# ---------------------------------------------------------------------------
# per-cell inputs
# ---------------------------------------------------------------------------


class _Inputs:
    """Everything of one study the four rules need, read once (no model call)."""

    def __init__(self, st, design, results: Path, run_dir: Path):
        from msr import data as D
        self.st, self.d = st, design
        self.results, self.run_dir = Path(results), Path(run_dir)
        self.H = design.headline
        self.w_score = float(getattr(st.build, "w_score", 0.5))
        self.scale = int(getattr(st.build, "rating_scale", 10) or 10)
        self.faithful = bool(getattr(st, "bird_faithful", False))
        self.tasks = {}
        for b in design.streams:
            try:
                self.tasks[b] = D.task_index(b)
            except Exception:            # a stream without its data file: re-answer cannot grade there
                self.tasks[b] = {}
        rl = getattr(st, "relearn", None)
        self.relearn_pairs = set(tuple(p) for p in (getattr(rl, "pairs", ()) or ())) if rl is not None else set()
        self._items, self._owner, self._relearn = {}, {}, {}

    # banks ----------------------------------------------------------------
    def bank_dir(self, model, b, sd) -> Path:
        return self.st.bank_dir(model, b, sd)

    def items(self, model, b, sd) -> dict:
        """{item_id: record} of a bank's items.jsonl."""
        k = (model, b, sd)
        if k not in self._items:
            self._items[k] = {r["item_id"]: r for r in _jsonl(self.bank_dir(model, b, sd) / "items.jsonl")}
        return self._items[k]

    def write_answers(self, model, b, sd, second: bool = False) -> dict:
        """{write task id: answer} of a model's first (items.jsonl) or second (write2.jsonl) no-memory answer."""
        if second:
            return {r["task_id"]: r.get("answer") for r in _jsonl(self.bank_dir(model, b, sd) / "write2.jsonl")}
        return {r["task_id"]: r.get("answer") for r in self.items(model, b, sd).values()}

    def ratings(self, path: Path) -> dict:
        return {r["item_id"]: r.get("rating") for r in _jsonl(path)}

    def owner_fam(self, owner, b, sd):
        """The owner's headline engine.Fam (keep's scores) and its item index."""
        k = (owner, b, sd)
        if k not in self._owner:
            from msr import evaluate as EV
            O = EV.OwnerData(self.st, owner, b, sd, None)
            self._owner[k] = (O.fams[self.H], O.index)
        return self._owner[k]

    def relearn_fam(self, owner, reader, b, sd):
        """The relearned headline engine.Fam of a relearn cell (None when the cell was not relearned)."""
        k = (owner, reader, b, sd)
        if k not in self._relearn:
            from msr import engine as EN
            from msr import scores as S
            p = self.run_dir / "relearn" / f"{owner}__{reader}" / b / f"seed{sd}" / f"bank_{self.H}.json"
            if not p.exists():
                self._relearn[k] = None
            else:
                bank, rule = S.load_bank(p)
                items = sorted(bank, key=str)
                self._relearn[k] = (EN.Fam(self.H, rule, bank, items, 0.5), {i: n for n, i in enumerate(items)})
        return self._relearn[k]

    # cells ----------------------------------------------------------------
    def cell(self, o, r, b, sd) -> dict | None:
        """Evaluation-task arrays of one probe cell (calibration tasks left out), aligned with its per-task file."""
        p = self.results / "cells" / f"{o}__{r}__{b}__seed{sd}.npz"
        if not p.exists():
            return None
        with np.load(p, allow_pickle=False) as z:
            Z = {k: z[k] for k in z.files}
        ev = ~Z.get("is_calib", np.zeros(len(Z["tasks"]), bool)).astype(bool)
        out = {"tasks": Z["tasks"][ev].astype(str), "items": Z["items"][ev].astype(str),
               "rel": Z["relevance"][ev].astype(float), "y": Z["y"][ev].astype(float),
               "y_home": Z["y_home"][ev].astype(float)}
        out["present"] = out["items"] != ""
        pt = self.results / "per_task" / f"{o}__{r}__{b}__seed{sd}.npz"
        valid = np.ones(len(out["tasks"]), bool)
        if pt.exists():
            with np.load(pt, allow_pickle=False) as z:
                if "valid" in z.files and "tasks" in z.files and list(z["tasks"].astype(str)) == list(out["tasks"]):
                    valid = np.nan_to_num(z["valid"].astype(float)) > 0
        out["valid"] = valid
        return out

    # per-item scores ------------------------------------------------------
    def per_item(self, values: dict, items: np.ndarray, default: float) -> np.ndarray:
        x = np.full(items.shape, np.nan)
        for (e, c), v in np.ndenumerate(items):
            if v:
                got = values.get(str(v))
                x[e, c] = float(got) if got is not None and _finite(got) else default
        return x

    def reanswer_values(self, o, r, b, sd, home: bool) -> dict:
        """{item id: 1/0}: the reader's (home: the owner's second) write answer agrees with the stored answer."""
        from msr.construct import answers_agree
        its = self.items(o, b, sd)
        other = self.write_answers(o, b, sd, second=True) if home else self.write_answers(r, b, sd)
        out = {}
        for iid, rec in its.items():
            t = rec.get("task_id")
            a = other.get(t)
            if t is None or a is None or t not in self.tasks.get(b, {}):
                continue
            if home:      # write2.jsonl stores the PARSED answer (msr.build.run_write2)
                out[iid] = 1.0 if _agree_parsed(b, self.tasks[b][t], rec.get("answer"), a, self.faithful) else 0.0
            else:
                out[iid] = 1.0 if answers_agree(b, self.tasks[b][t], rec.get("answer"), a, self.faithful) else 0.0
        return out


def _agree_parsed(stream: str, task: dict, stored_raw, parsed, faithful: bool) -> bool:
    """msr.construct.answers_agree for a second answer stored already parsed (DDXPlus: the int label; BIRD: the
    SQL text): the same valid label, or the same non-empty result set as the stored query."""
    from msr import grade as G
    from msr.data import LABEL2TEXT
    if stored_raw is None or parsed is None:
        return False
    if stream == "ddxplus":
        a = G.parse_answer("ddxplus", stored_raw)
        try:
            p = int(parsed)
        except (TypeError, ValueError):
            return False
        return a in LABEL2TEXT and a == p
    pseudo = dict(task)
    pseudo["SQL"] = G.parse_answer("bird", stored_raw, faithful=faithful)
    return bool(G.grade_detail("bird", pseudo, str(parsed), faithful=faithful)["correct"])


def _finite(v) -> bool:
    try:
        return math.isfinite(float(v))
    except (TypeError, ValueError):
        return False


# ---------------------------------------------------------------------------
# per (rule, cell, stream, order) values
# ---------------------------------------------------------------------------


def cell_values(I: _Inputs, rule: str, o: str, r: str, b: str, sd: int) -> dict | None:
    """Per-task arrays of one rule in one cell: fs_rule, fs_keep, fs_wipe, V/W swap side, V/W home side, the
    task ids and the candidates' write-task codes; None when the rule has no input for this cell."""
    c = I.cell(o, r, b, sd)
    if c is None:
        return None
    items, pres, rel = c["items"], c["present"], c["rel"]
    mid = (1.0 + I.scale) / 2.0
    from msr import engine as EN
    F, idx = I.owner_fam(o, b, sd)
    jx = np.array([[idx.get(str(v), -1) for v in row] for row in items], dtype=np.int64)
    ok = pres & (jx >= 0)
    x_keep = np.where(ok, F.x[np.maximum(jx, 0)], np.nan)
    u_keep = np.where(ok, EN.u_of(F.kind, F.A)[np.maximum(jx, 0)], np.nan)
    # wipe exactly as msr.evaluate scores it: every score at its start value (the kind's u of the start state)
    u_wipe = np.where(ok, EN.u_of(F.kind, F.start())[np.maximum(jx, 0)], np.nan)
    home_cell = o == r
    if rule == "judge":
        path = I.run_dir / "judge" / f"{o}__{r}" / b / f"seed{sd}" / "judge.jsonl"
        hpath = I.run_dir / "judge" / f"{o}__{o}" / b / f"seed{sd}" / "judge.jsonl"
        if not path.exists() or not hpath.exists():
            return None
        x = I.per_item(I.ratings(path), items, mid)
        xh = I.per_item(I.ratings(hpath), items, mid)
        u = (x - 1.0) / max(I.scale - 1.0, 1.0)
    elif rule == "self_rating":
        path = I.bank_dir(o, b, sd) / "selfrate.jsonl"
        if not path.exists():
            return None
        x = xh = I.per_item(I.ratings(path), items, mid)
        u = (x - 1.0) / max(I.scale - 1.0, 1.0)
    elif rule == "reanswer":
        if not (I.bank_dir(o, b, sd) / "write2.jsonl").exists() and home_cell:
            return None
        sw = I.reanswer_values(o, r, b, sd, home=home_cell)
        hm = I.reanswer_values(o, o, b, sd, home=True)
        if not sw or not hm:
            return None
        x = I.per_item(sw, items, NAN)
        xh = I.per_item(hm, items, NAN)
        u = x
    elif rule == "relearn":
        if home_cell or (o, r) not in I.relearn_pairs:
            return None
        got = I.relearn_fam(o, r, b, sd)
        if got is None:
            return None
        RF, ridx = got
        rj = np.array([[ridx.get(str(v), -1) for v in row] for row in items], dtype=np.int64)
        rok = pres & (rj >= 0)
        x = np.where(rok, RF.x[np.maximum(rj, 0)], np.nan)
        u = np.where(rok, EN.u_of(RF.kind, RF.A)[np.maximum(rj, 0)], np.nan)
        xh = x_keep
    else:
        raise ValueError(rule)
    use = pres & np.isfinite(x)
    yb, yh = _ybar(c["y"]), _ybar(c["y_home"])
    v_s, w_s = _vw(x, yb, use)
    use_h = pres & np.isfinite(xh)
    v_h, w_h = _vw(xh, yh, use_h)
    valid = c["valid"]
    fs_rule = _first_shown(pres, rel, c["y"], u, I.w_score, valid)
    fs_keep = _first_shown(pres, rel, c["y"], u_keep, I.w_score, valid)
    fs_wipe = _first_shown(pres, rel, c["y"], u_wipe, I.w_score, valid)
    bad = ~valid
    for a in (v_s, w_s, v_h, w_h):
        a[bad] = np.nan
    codes = np.where(pres, np.char.add(f"{b}|", np.vectorize(write_task)(items)), "")
    return {"tasks": np.char.add(f"{b}|", c["tasks"]), "codes": codes, "fs_rule": fs_rule, "fs_keep": fs_keep,
            "fs_wipe": fs_wipe, "V_swap": v_s, "W_swap": w_s, "V_home": v_h, "W_home": w_h,
            "missing_share": float(np.mean(~np.isfinite(np.where(pres, x, 0.0))[pres])) if pres.any() else NAN}


# ---------------------------------------------------------------------------
# pooling with the two-way variance (task id x write task)
# ---------------------------------------------------------------------------


def _component(vals: list, key: str) -> tuple:
    """Rows of one (cell, stream) component pooled over its orders: (mean, values, tasks, codes) over finite
    values; None when nothing is finite."""
    v = np.concatenate([d[key] for d in vals])
    t = np.concatenate([d["tasks"] for d in vals])
    cd = np.vstack([d["codes"] for d in vals])
    ok = np.isfinite(v)
    if not ok.any():
        return None
    return float(v[ok].mean()), v[ok], t[ok], cd[ok]


def _linear(parts: list) -> dict:
    """mean over components of sum_k coef_k mean_k(key_k): parts = [(component rows, coef)] where a component
    is (mean, values, tasks, codes). Two-way (task id x write task) jackknife."""
    P, T, I, C = [], [], [], []
    est = 0.0
    for k, (comp, coef) in enumerate(parts):
        mu, v, t, cd = comp
        est += coef * mu
        P.append(coef * (v - mu) / len(v))
        T.append(t)
        I.append(cd)
        C.append(np.full(len(v), k))
    if not P:
        return {"est": NAN, "se": NAN, "lo": NAN, "hi": NAN, "p": NAN, "item_share": NAN, "eff_items": NAN}
    rv = M.robust_variance(np.concatenate(P), np.concatenate(T), np.vstack(I), np.concatenate(C))
    se = math.sqrt(rv["V"]) if rv["V"] > 0 else NAN
    p = M.normal_p(est, se)["p_two"] if math.isfinite(se) else NAN
    return {"est": est, "se": se, "lo": est - M.Z95 * se if math.isfinite(se) else NAN,
            "hi": est + M.Z95 * se if math.isfinite(se) else NAN, "p": p,
            "item_share": rv["item_share"], "eff_items": rv["eff_items"]}


def _theta(items: list) -> dict:
    """theta = sum of mean V_swap / sum of mean V_home over (cell, stream) components, with the registered tests
    and Fieller set (msr.metrics.theta_tests), two-way (task id x write task) jackknife."""
    sw, hm = [], []
    for vals in items:
        a, b_ = _component(vals, "V_swap"), _component(vals, "V_home")
        if a is None or b_ is None:
            return {"theta": NAN}
        sw.append(a)
        hm.append(b_)
    A = sum(x[0] for x in sw)
    B = sum(x[0] for x in hm)
    n = sum(len(x[1]) for x in sw) + sum(len(x[1]) for x in hm)
    ps, ph = np.zeros(n), np.zeros(n)
    T, I, C = [], [], []
    at = 0
    for k, comp in enumerate(sw + hm):
        mu, v, t, cd = comp
        target = ps if k < len(sw) else ph
        target[at:at + len(v)] = (v - mu) / len(v)
        T.append(t)
        I.append(cd)
        C.append(np.full(len(v), k))
        at += len(v)
    res = M.theta_tests(A, B, ps, ph, np.concatenate(T), np.vstack(I), np.concatenate(C))
    W_s = sum(_component(v, "W_swap")[0] for v in items)
    W_h = sum(_component(v, "W_home")[0] for v in items)
    res["C_swap"] = 0.5 + A / (2.0 * W_s) if W_s else NAN
    res["C_home"] = 0.5 + B / (2.0 * W_h) if W_h else NAN
    return res


# ---------------------------------------------------------------------------
# the tables
# ---------------------------------------------------------------------------


def stage_tables(design, results, run_dir, E=None, TW=None, st=None) -> dict:
    """{table name: rows} of the registered secondary paid-stage rules (Part 8.2.18-8.2.21; open point 30):
    secondary_stage_cells (per rule, cell, stream, order), secondary_stage_groups (per rule, swap group and
    level) and reanswer_home (the owner's second no-memory answer against its stored answer, per bank).
    E and TW are accepted for the call from msr.analysis.analyse and not needed (the rules' values are not in
    the per-task files). A study without the stages gives empty tables."""
    from msr import analysis as A
    if results is None or run_dir is None:
        return {"secondary_stage_cells": [], "secondary_stage_groups": [], "reanswer_home": []}
    run_dir = Path(run_dir)
    if st is None:
        try:
            st = A.resolve_study(design.name, runs_dir=run_dir.parent)
        except FileNotFoundError:
            return {"secondary_stage_cells": [], "secondary_stage_groups": [], "reanswer_home": []}
    I = _Inputs(st, design, Path(results), run_dir)
    cells_rows, vals = [], {}
    for rule in RULES:
        for (o, r) in design.cells:
            for b in design.streams:
                for sd in design.seeds:
                    try:
                        cv = cell_values(I, rule, o, r, b, sd)
                    except (OSError, KeyError, ValueError) as exc:
                        cells_rows.append({"rule": rule, "owner": o, "reader": r, "stream": b, "seed": sd,
                                           "note": f"not computed: {type(exc).__name__}: {exc}"})
                        continue
                    if cv is None:
                        continue
                    vals.setdefault((rule, (o, r), b), []).append(cv)
                    with np.errstate(invalid="ignore"):
                        cells_rows.append({
                            "rule": rule, "owner": o, "reader": r, "group": design.group(o, r), "stream": b, "seed": sd,
                            "tasks": int(np.isfinite(cv["fs_rule"]).sum()),
                            "value_rule": float(np.nanmean(cv["fs_rule"])), "value_keep": float(np.nanmean(cv["fs_keep"])),
                            "value_wipe": float(np.nanmean(cv["fs_wipe"])),
                            "V_home": float(np.nanmean(cv["V_home"])), "V_swap": float(np.nanmean(cv["V_swap"])),
                            "missing_score_share": cv["missing_share"], "meaning": RULE_MEANING[rule]})
    groups = [g for g in ("upgrade", "downgrade", "cross", "same_maker", "all_swaps", "home") if design.swaps(g)]
    levels = list(design.streams) + ["all"]
    grows = []
    for rule in RULES:
        for g in groups:
            cells = design.swaps(g)
            for lev in levels:
                bs = design.streams if lev == "all" else [lev]
                comps = [(c, b) for c in cells for b in bs if (rule, c, b) in vals]
                if not comps:
                    continue
                n = len(comps)
                row = {"rule": rule, "group": g, "level": lev, "n_swaps": len({c for c, _ in comps}),
                       "n_components": n, "meaning": RULE_MEANING[rule],
                       "variance": "two-way jackknife: task id x write task within stream (shared across owners)"}
                rule_c = [_component(vals[(rule, c, b)], "fs_rule") for c, b in comps]
                keep_c = [_component(vals[(rule, c, b)], "fs_keep") for c, b in comps]
                wipe_c = [_component(vals[(rule, c, b)], "fs_wipe") for c, b in comps]
                if all(x is not None for x in rule_c + keep_c + wipe_c):
                    row["value_rule"] = float(np.mean([x[0] for x in rule_c]))
                    row["value_keep"] = float(np.mean([x[0] for x in keep_c]))
                    row["value_wipe"] = float(np.mean([x[0] for x in wipe_c]))
                    for tag, other in (("keep", keep_c), ("wipe", wipe_c)):
                        lr = _linear([(x, 1.0 / n) for x in rule_c] + [(x, -1.0 / n) for x in other])
                        row.update({f"minus_{tag}": lr["est"], f"minus_{tag}_lo": lr["lo"], f"minus_{tag}_hi": lr["hi"],
                                    f"minus_{tag}_p": lr["p"], f"minus_{tag}_item_share": lr["item_share"],
                                    f"minus_{tag}_eff_items": lr["eff_items"]})
                if g != "home":
                    th = _theta([vals[(rule, c, b)] for c, b in comps])
                    row.update(theta=th.get("theta", NAN), theta_lo=th.get("lo", NAN), theta_hi=th.get("hi", NAN),
                               theta_interval=th.get("interval", ""), p_home=th.get("p_home", NAN),
                               p_drop=th.get("p_drop", NAN), p_ni=th.get("p_ni", NAN), C_home=th.get("C_home", NAN),
                               C_swap=th.get("C_swap", NAN), V_home=th.get("V_home", NAN), V_swap=th.get("V_swap", NAN))
                grows.append(row)
    home_rows = []
    for m in design.models:
        for b in design.streams:
            for sd in design.seeds:
                if not (I.bank_dir(m, b, sd) / "write2.jsonl").exists():
                    continue
                ag = I.reanswer_values(m, m, b, sd, home=True)
                its = I.items(m, b, sd)
                g = [float(bool(its[i].get("correct"))) for i in ag if its.get(i, {}).get("correct") is not None]
                agv = np.array(list(ag.values()), dtype=float)
                home_rows.append({"owner": m, "stream": b, "seed": sd, "items": len(its), "items_with_write2": len(ag),
                                  "agree_rate": float(agv.mean()) if agv.size else NAN,
                                  "stored_correct_rate": float(np.mean(g)) if g else NAN,
                                  "meaning": "the owner's second no-memory answer to each write task agrees with its "
                                             "stored answer: the home value of the re-answer score"})
    return {"secondary_stage_cells": cells_rows, "secondary_stage_groups": grows, "reanswer_home": home_rows}
