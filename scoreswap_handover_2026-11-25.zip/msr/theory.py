"""The transfer decomposition: estimators, the linear-transfer specification test and two figures.

Everyday picture: a garage scored its repair tips while the old helper worked there. A new helper
arrives. Two different things decide how well the old scores still rank the tips for the new
helper: (1) how much the tips that helped the old helper also help the new one, and (2) how noisy
each helper's results are on the test jobs. The plain ratio of concordances mixes the two. This
module separates them. Statements and proofs: docs/theory_note.md and paper/sections/A8_proofs.tex.

What is classical and what is ours.
- Classical: the weighted concordance is (1 + Gamma) / 2 with Gamma the pooled within-task Gini
  correlation of outcomes with score ranks (Schechtman and Yitzhaki 1987), so its numerator is
  linear in the outcomes; the decomposition below is an identity; R_V (theta) is an instrumental-
  variable slope with the score sign as instrument and gamma a reliability-corrected least-squares
  slope (Fuller 1987), so "L = 0" is a Durbin-Wu-Hausman-type specification restriction (Hausman
  1978; Angrist and Imbens 1995 for the weights under heterogeneous slopes).
- Ours: the use. The identity R = theta * W_home / W_swap shows that the plain retained ratio R is
  confounded by the new model's outcome noise, so the noise-free retained share theta = V_swap /
  V_home is the headline measure; the specification test is a parameter-free consistency check on
  the benchmark's own measurements.

Notation (docs/theory_note.md, section 1). Inside one probe task, for candidates i < j:
    sgn_ij   = sgn(x(i) - x(j)), 0 for a score tie (|difference| <= 1e-12)
    dy_m     = ybar_m(i) - ybar_m(j)     model m's observed difference (mean of its repeats)
    delta_m  = mu_m(i) - mu_m(j)          the true difference of success probabilities
    V(tau)   = sum_{i<j} sgn_ij * dy     "signed validity"; linear in the outcomes
    W(tau)   = sum_{i<j} |dy|            "outcome spread"; the weight sum of Cw
    Cw       = 1/2 + sum V / (2 sum W)   (Result 1: exact; = (1 + Gamma) / 2)
    theta    = V_swap / V_home           noise-free retained share (= R_V), the headline measure
    gamma    = E[delta_s delta_t] / E[delta_s^2]      the score-free transfer slope
    L        = E[sgn (delta_t - gamma delta_s)]       so that E V_swap = gamma E V_home + L (identity)
The owner s is "old" and the reader t is "new". In a home row the "new" outcomes are the owner's
extra home repeats 3-4 (the self-swap).

Estimators (Result 3):
    V_hat         sum of sgn * dy: unbiased for sum sgn * delta, whatever the noise or repeat dependence
    C_on          sum dy_s(rep 1-2) * dy_t: unbiased for sum delta_s delta_t (the two models' calls are independent)
    C_oo          sum dy_s(rep 1-2) * dy_s(rep 3-4): unbiased for sum delta_s^2 when the two SESSIONS are
                  independent, even if repeats inside a session are not (caching, near-greedy decoding)
    gamma_hat     C_on / C_oo   (primary, cross-session)
    gamma_within  S_on / S_oo with the within-session U-statistic S_oo = sum dhat2 (sensitivity; needs
                  independent repeats inside a session). Their difference is a check of that assumption.
    rho_hat       S_on / sqrt(S_oo S_nn) (Spearman's correction for attenuation; descriptive)
    spec_Q        V_swap * C_oo - C_on * V_home: estimates (pairs^2) E[delta_s^2] L, zero under the linear
                  specification whatever the strength of the home signal (Fieller's device: no division)
    gap           Q / (2 C_oo W_swap) = Cw_swap - (1/2 + gamma_hat V_home / (2 W_swap)), in Cw units
Intervals: Fieller sets for theta and gamma with a two-way (task and item) linearised variance, the
stratified task bootstrap of the study (msr.metrics.bootstrap_counts with stratum_seed) beside them.
The item clusters of the two-way variance are WRITE TASKS within a stream (ITEM_CLUSTER, the manager's
ruling E1 of revision 3, after review R7 W2): every owner writes its bank from the same write tasks, so
two owners' versions of one write task are one cluster in every statistic that pools owners. For a
statistic of one owner this is the same partition as the earlier owner coding (kept as a sensitivity).
Definedness is decided on the owner's CALIBRATION tasks (data that no estimate here uses), so the rule
cannot select on the estimate's own noise.

Run:  python -m msr.theory --study sim          (writes runs/<study>/analysis/decomp_*.csv and
                                                  paper/assets/fig_decomp_*.{pdf,png})
"""
from __future__ import annotations

import argparse
import csv
import itertools
import math
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

TIE = 1e-12
NAN = float("nan")
SQRT_2_PI = math.sqrt(2.0 / math.pi)

#: per-pair summands, all additive over pairs, tasks and orders (so every bootstrap is a sum)
SCORE_KEYS = ("V_o", "V_n", "U_o", "U_n", "XY_o", "XX_o", "XY_n", "XX_n", "XB", "XX_b", "BB_b")
OUTCOME_KEYS = ("W_o", "N_o", "W_n", "N_n", "I_o", "I_n", "YY_o", "YY_n",
                "C_on", "C_oo", "N_c",                   # gamma (primary): owner sessions 1-2 and 3-4, reader >= 1
                "S_on", "S_oo", "N_g",                   # gamma_within: owner >= 2 repeats in session 1-2
                "S_on2", "S_oo2", "S_nn2", "N_r",        # rho: both >= 2 repeats
                "Q_oo", "R_oo", "N_oo", "Q_nn", "R_nn", "N_nn")   # reliabilities
TRUTH_KEYS = ("T_Vo", "T_Vn", "T_on", "T_oo", "T_nn", "T_abs_o")

#: The item clusters of the two-way variance (manager's ruling E1, revision 3; review R7 W2):
#: "write_task" (registered) = the write task within its stream, so the items that different owners wrote
#: from one write task are one cluster; "owner" = the earlier coding owner | stream | item id, kept as a
#: sensitivity. Read by every variance helper below at call time (_item_keys).
ITEM_CLUSTER = "write_task"
ITEM_CLUSTERS = ("write_task", "owner")


def write_task_key(item, stream) -> str:
    """The item cluster of one candidate under the registered coding (manager's ruling E1, revision 3,
    after review R7 W2): f"{stream}|{write task}". An item id is "<write task id>@<owner>"
    (msr.build.make_item_id) and every owner's bank is written from the same write tasks of an order, so
    the "@<owner>" suffix is dropped and two owners' versions of one write task are one cluster. An id
    without "@" is its own write task; '' (no candidate) stays ''. Within one owner this is the same
    partition as the owner coding, so a statistic of one owner is unchanged."""
    s = str(item)
    if s == "":
        return ""
    return f"{stream}|{s.rsplit('@', 1)[0]}"


def owner_item_key(item, owner, stream) -> str:
    """The earlier item cluster (identity within (owner, stream), revision 2), kept as a sensitivity:
    f"{owner}|{stream}|{item}"; '' (no candidate) stays ''."""
    s = str(item)
    return "" if s == "" else f"{owner}|{stream}|{s}"


# ===========================================================================
# Pairs and the basic per-pair quantities
# ===========================================================================


def pair_index(n_cand: int) -> tuple:
    """(ia, ib): every unordered pair i < j of n_cand candidates."""
    if n_cand < 2:
        return np.zeros(0, dtype=int), np.zeros(0, dtype=int)
    a, b = zip(*itertools.combinations(range(n_cand), 2))
    return np.array(a, dtype=int), np.array(b, dtype=int)


def pair_sign(x: np.ndarray, ia: np.ndarray, ib: np.ndarray) -> np.ndarray:
    """sgn(x_i - x_j) per pair (E, P), 0 for a tie within 1e-12 (the tie rule of Cw), NaN where a
    score is missing."""
    d = x[..., ia] - x[..., ib]
    s = np.sign(d)
    with np.errstate(invalid="ignore"):
        s = np.where(np.abs(d) <= TIE, 0.0, s)
    return s


def cell_moments(y: np.ndarray) -> tuple:
    """For outcomes y (E, C, R) with NaN for a missing repeat: (ybar, n, u2) per cell, where n is
    the number of valid repeats and u2 = ybar^2 - s^2 / n is the unbiased estimate of mu^2 (NaN
    when n < 2: one draw per cell has no unbiased estimator of mu^2)."""
    y = np.asarray(y, dtype=float)
    if y.ndim == 2:
        y = y[..., None]
    n = (~np.isnan(y)).sum(-1)
    with np.errstate(invalid="ignore", divide="ignore"):
        ybar = np.where(n > 0, np.nansum(y, -1) / np.maximum(n, 1), NAN)
        dev = np.where(np.isnan(y), 0.0, y - ybar[..., None])
        s2 = np.where(n > 1, (dev ** 2).sum(-1) / np.maximum(n - 1, 1), NAN)
        u2 = np.where(n > 1, ybar ** 2 - s2 / np.maximum(n, 1), NAN)
    return ybar, n, u2


def pair_delta2_unbiased(y: np.ndarray, ia: np.ndarray, ib: np.ndarray) -> np.ndarray:
    """Unbiased estimate of delta^2 = (mu_i - mu_j)^2 per pair (E, P): u2_i + u2_j - 2 ybar_i ybar_j
    (Result 3). NaN where either cell has fewer than 2 valid repeats."""
    ybar, n, u2 = cell_moments(y)
    return u2[..., ia] + u2[..., ib] - 2.0 * ybar[..., ia] * ybar[..., ib]


def _z(a: np.ndarray, ok: np.ndarray) -> np.ndarray:
    return np.where(ok, a, 0.0)


def outcome_pairs(y_old: np.ndarray, y_new: np.ndarray, ia: np.ndarray, ib: np.ndarray,
                  has: np.ndarray | None = None, y_old2: np.ndarray | None = None) -> dict:
    """Per-pair summands (E, P) that depend on the outcomes only (zero where a pair is not usable).

    y_old: the owner's repeats 1-2 (E, C, R_o); y_new: the reader's (E, C, R_n); y_old2: the owner's
    second session, home repeats 3-4 (E, C, R_o2), or None; has (E, C) marks the candidates that exist
    (default: all). The cross-session parts C_on, C_oo use the pairs where both owner sessions and the
    reader have a valid result on both candidates."""
    yb_o, n_o, u2_o = cell_moments(y_old)
    yb_n, n_n, u2_n = cell_moments(y_new)
    if has is None:
        has = np.ones(yb_o.shape, dtype=bool)
    if y_old2 is not None:
        yb_s2, n_s2, _ = cell_moments(y_old2)
        c_s2 = has & (n_s2 >= 1)
    else:
        yb_s2 = np.full(yb_o.shape, NAN)
        c_s2 = np.zeros(yb_o.shape, dtype=bool)
    c_o = has & (n_o >= 1)
    c_n = has & (n_n >= 1)
    c_o2 = has & (n_o >= 2)
    c_n2 = has & (n_n >= 2)
    ok_o = c_o[:, ia] & c_o[:, ib]
    ok_n = c_n[:, ia] & c_n[:, ib]
    ok_o2 = c_o2[:, ia] & c_o2[:, ib]
    ok_n2 = c_n2[:, ia] & c_n2[:, ib]
    with np.errstate(invalid="ignore"):
        dy_o = yb_o[:, ia] - yb_o[:, ib]
        dy_n = yb_n[:, ia] - yb_n[:, ib]
        d2_o = u2_o[:, ia] + u2_o[:, ib] - 2.0 * yb_o[:, ia] * yb_o[:, ib]
        d2_n = u2_n[:, ia] + u2_n[:, ib] - 2.0 * yb_n[:, ia] * yb_n[:, ib]
        inf_o = ok_o & (np.abs(dy_o) > TIE)
        inf_n = ok_n & (np.abs(dy_n) > TIE)
    g = ok_o2 & ok_n          # gamma_within: the owner needs 2 repeats in session 1-2, the reader 1
    r = ok_o2 & ok_n2         # rho: both need 2
    cs = ok_o & ok_n & c_s2[:, ia] & c_s2[:, ib]      # gamma (cross-session)
    with np.errstate(invalid="ignore"):
        dy_s2 = yb_s2[:, ia] - yb_s2[:, ib]
    out = {
        "C_on": _z(dy_o * dy_n, cs), "C_oo": _z(dy_o * dy_s2, cs), "N_c": cs.astype(float),
        "W_o": _z(np.abs(dy_o), ok_o), "N_o": ok_o.astype(float),
        "W_n": _z(np.abs(dy_n), ok_n), "N_n": ok_n.astype(float),
        "I_o": inf_o.astype(float), "I_n": inf_n.astype(float),
        "YY_o": _z(dy_o ** 2, ok_o), "YY_n": _z(dy_n ** 2, ok_n),
        "S_on": _z(dy_o * dy_n, g), "S_oo": _z(d2_o, g), "N_g": g.astype(float),
        "S_on2": _z(dy_o * dy_n, r), "S_oo2": _z(d2_o, r), "S_nn2": _z(d2_n, r), "N_r": r.astype(float),
        "Q_oo": _z(d2_o, ok_o2), "R_oo": _z(dy_o ** 2, ok_o2), "N_oo": ok_o2.astype(float),
        "Q_nn": _z(d2_n, ok_n2), "R_nn": _z(dy_n ** 2, ok_n2), "N_nn": ok_n2.astype(float),
    }
    out["_dy_o"], out["_dy_n"], out["_ok_o"], out["_ok_n"] = dy_o, dy_n, ok_o, ok_n
    out["_inf_o"], out["_inf_n"] = inf_o, inf_n
    return out


def score_pairs(x: np.ndarray, op: dict, ia: np.ndarray, ib: np.ndarray,
                x_bank2: np.ndarray | None = None) -> dict:
    """Per-pair summands (E, P) that involve the owner's score x (E, C): the signed validities V
    (Result 1), the unweighted sign parts U, and the Pearson parts of the Gaussian corollary
    (Result 4). With a second bank's scores, the parts of the test-retest correlation of the
    score differences."""
    s = pair_sign(x, ia, ib)
    dx = x[..., ia] - x[..., ib]
    okx = np.isfinite(dx)
    dy_o, dy_n, ok_o, ok_n = op["_dy_o"], op["_dy_n"], op["_ok_o"], op["_ok_n"]
    ko, kn = ok_o & okx, ok_n & okx
    with np.errstate(invalid="ignore"):
        out = {
            "V_o": _z(s * dy_o, ko), "V_n": _z(s * dy_n, kn),
            "U_o": _z(s * np.sign(dy_o), op["_inf_o"] & okx), "U_n": _z(s * np.sign(dy_n), op["_inf_n"] & okx),
            "XY_o": _z(dx * dy_o, ko), "XX_o": _z(dx * dx, ko),
            "XY_n": _z(dx * dy_n, kn), "XX_n": _z(dx * dx, kn),
        }
        if x_bank2 is not None and np.isfinite(x_bank2).any():
            dx2 = x_bank2[..., ia] - x_bank2[..., ib]
            k2 = okx & np.isfinite(dx2)
            out.update({"XB": _z(dx * dx2, k2), "XX_b": _z(dx * dx, k2), "BB_b": _z(dx2 * dx2, k2)})
        else:
            z = np.zeros_like(dy_o, dtype=float)
            out.update({"XB": z, "XX_b": z, "BB_b": z})
    return out


def truth_pairs(x: np.ndarray, mu_old: np.ndarray, mu_new: np.ndarray, ia, ib, ok: np.ndarray) -> dict:
    """Noise-free versions (true success probabilities, e.g. from msr.sim) on the same pairs."""
    s = pair_sign(x, ia, ib)
    d_o = mu_old[:, ia] - mu_old[:, ib]
    d_n = mu_new[:, ia] - mu_new[:, ib]
    with np.errstate(invalid="ignore"):
        k = ok & np.isfinite(s)
        return {"T_Vo": _z(s * d_o, k), "T_Vn": _z(s * d_n, k), "T_on": _z(d_o * d_n, ok),
                "T_oo": _z(d_o * d_o, ok), "T_nn": _z(d_n * d_n, ok), "T_abs_o": _z(np.abs(d_o), ok)}


# ===========================================================================
# Small estimators (each named after its result in docs/theory_note.md)
# ===========================================================================


def signed_validity(x, y, has=None) -> tuple:
    """Result 1. (V, W) summed over the tasks of one cell: V = sum sgn(dx) dybar, W = sum |dybar|,
    so that Cw = 1/2 + V / (2 W). x (E, C), y (E, C, R) or (E, C)."""
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    ia, ib = pair_index(x.shape[-1])
    op = outcome_pairs(y, y, ia, ib, has)
    sp = score_pairs(x, op, ia, ib)
    return float(sp["V_o"].sum()), float(op["W_o"].sum())


def cw_from_identity(x, y, has=None) -> float:
    """Result 1: the weighted concordance through the identity Cw = 1/2 + V / (2 W)."""
    v, w = signed_validity(x, y, has)
    return 0.5 + v / (2.0 * w) if w > 0 else NAN


def gini_correlation(x, y, has=None) -> float:
    """Result 1 (classical): the pooled within-task Gini correlation of the outcomes with the score
    ranks, Gamma = sum_tau cov_tau(ybar, midrank x) / sum_tau cov_tau(ybar, midrank ybar)
    (Schechtman and Yitzhaki 1987), computed from ranks only. Cw = (1 + Gamma) / 2 exactly."""
    from scipy.stats import rankdata
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    yb = cell_moments(y)[0] if y.ndim == 3 else y
    if has is None:
        has = np.ones(x.shape, dtype=bool)
    num = den = 0.0
    for e in range(x.shape[0]):
        k = has[e] & np.isfinite(yb[e]) & np.isfinite(x[e])
        if k.sum() < 2:
            continue
        xx, yy = x[e, k], yb[e, k]
        xr = rankdata(xx)          # exact ties share a midrank (as Cw's tie rule for exact ties)
        yr = rankdata(yy)
        num += float(np.sum((yy - yy.mean()) * (xr - xr.mean())))
        den += float(np.sum((yy - yy.mean()) * (yr - yr.mean())))
    return num / den if den > 0 else NAN


def gamma_hat(y_old, y_new, has=None, y_old2=None) -> float:
    """Result 3: the score-free transfer slope gamma = E[delta_s delta_t] / E[delta_s^2]. With the
    owner's second session y_old2 (home repeats 3-4) the denominator is the cross-session product
    sum dy_s(1-2) dy_s(3-4), unbiased whenever the two sessions are independent, even if repeats
    inside a session are not (the primary estimator). Without it, the within-session U-statistic
    (needs independent repeats inside the session). NaN (with a warning) when the owner has fewer
    than 2 repeats in total on every pair: gamma is then not estimable."""
    y_old = np.asarray(y_old, dtype=float)
    ia, ib = pair_index(y_old.shape[1])
    op = outcome_pairs(y_old, np.asarray(y_new, dtype=float), ia, ib, has,
                       None if y_old2 is None else np.asarray(y_old2, dtype=float))
    if y_old2 is not None and op["N_c"].sum() > 0:
        den = op["C_oo"].sum()
        return float(op["C_on"].sum() / den) if den > 0 else NAN
    if op["N_g"].sum() == 0:
        import warnings
        warnings.warn("gamma cannot be estimated: the old model needs at least 2 independent repeats "
                      "on the same (task, item) cells (one Bernoulli draw per cell has no unbiased "
                      "estimator of the squared difference)")
        return NAN
    den = op["S_oo"].sum()
    return float(op["S_on"].sum() / den) if den > 0 else NAN


def rho_hat(y_old, y_new, has=None) -> float:
    """Result 3: the cross-model correlation of the true within-task differences, corrected for
    the outcome noise of both models (Spearman's correction). NaN unless both have >= 2 repeats.
    Can leave [-1, 1] in small samples; it is reported as computed."""
    y_old = np.asarray(y_old, dtype=float)
    ia, ib = pair_index(y_old.shape[1])
    op = outcome_pairs(y_old, np.asarray(y_new, dtype=float), ia, ib, has)
    a, b = op["S_oo2"].sum(), op["S_nn2"].sum()
    if op["N_r"].sum() == 0 or a <= 0 or b <= 0:
        return NAN
    return float(op["S_on2"].sum() / math.sqrt(a * b))


def reliability(y, has=None) -> float:
    """Reliability of the observed within-task differences at the design's repeats:
    sum dhat2 / sum dybar^2 (the share of the variance of dybar that is true difference)."""
    y = np.asarray(y, dtype=float)
    ia, ib = pair_index(y.shape[1])
    op = outcome_pairs(y, y, ia, ib, has)
    d = op["R_oo"].sum()
    return float(op["Q_oo"].sum() / d) if d > 0 else NAN


def gaussian_c(r) -> np.ndarray:
    """Result 4 (classical): unweighted concordance of a bivariate normal pair with correlation r,
    1/2 + arcsin(r) / pi (Kendall's tau = (2 / pi) arcsin r)."""
    r = np.clip(np.asarray(r, dtype=float), -1.0, 1.0)
    return 0.5 + np.arcsin(r) / np.pi


def gaussian_cw(r) -> np.ndarray:
    """Result 4 (classical): weighted concordance of a bivariate normal pair, 1/2 + r / 2 (twice
    Cw minus 1 is a Gini correlation, which equals Pearson's r under bivariate normality)."""
    return 0.5 + 0.5 * np.clip(np.asarray(r, dtype=float), -1.0, 1.0)


def ceiling_bound(mean_d2: float, mean_abs_dy: float) -> float:
    """Result 1b: Cw <= 1/2 + E|delta| / (2 E|dybar|) <= 1/2 + sqrt(E delta^2) / (2 E|dybar|).
    Returns the right-hand bound (estimable without assumptions)."""
    if not (mean_d2 > 0 and mean_abs_dy > 0):
        return NAN
    return 0.5 + math.sqrt(mean_d2) / (2.0 * mean_abs_dy)


def ceiling_gauss(mean_d2: float, mean_abs_dy: float) -> float:
    """Result 4b: the ceiling when the true differences are normal, E|delta| = sqrt(2/pi) sd."""
    if not (mean_d2 > 0 and mean_abs_dy > 0):
        return NAN
    return 0.5 + SQRT_2_PI * math.sqrt(mean_d2) / (2.0 * mean_abs_dy)


# ---------------------------------------------------------------- Result 6: break-even fresh checks
def keep_corr(n, rho, c_old) -> np.ndarray:
    """Result 6: correlation of an n-visit old-evidence score with the new model's probability,
    rho * sqrt(n / (n + c_old)), c = E[p(1-p)] / Var(p) (= a + b for Beta(a, b) items)."""
    n = np.asarray(n, dtype=float)
    return np.asarray(rho, dtype=float) * np.sqrt(n / (n + c_old))


def fresh_corr(k, c_new) -> np.ndarray:
    """Result 6: correlation of a k-check fresh score with the new model's probability."""
    k = np.asarray(k, dtype=float)
    return np.sqrt(k / (k + c_new))


def combined_corr(n, k, rho, c_old, c_new) -> np.ndarray:
    """Result 6 (remark): correlation of the best linear combination of old and fresh evidence
    with the new model's probability; it is never below either part."""
    a = 1.0 + c_old / np.asarray(n, dtype=float)
    b = 1.0 + c_new / np.asarray(k, dtype=float)
    r2 = (rho ** 2 * b - 2.0 * rho ** 2 + a) / (a * b - rho ** 2)
    return np.sqrt(np.clip(r2, 0.0, 1.0))


def break_even_k(n, rho, c_old, c_new) -> np.ndarray:
    """Result 6: fresh-only evidence ranks better than kept old evidence iff k > k*, with
    k* = c_new rho^2 n / (c_old + (1 - rho^2) n). rho is clipped to [0, 1]; k* = inf when
    rho = 1 (the old evidence is never beaten)."""
    n = np.asarray(n, dtype=float)
    r2 = np.clip(np.asarray(rho, dtype=float), 0.0, 1.0) ** 2
    with np.errstate(divide="ignore", invalid="ignore"):
        return np.where((1.0 - r2) * n + c_old > 0, c_new * r2 * n / (c_old + (1.0 - r2) * n), np.inf)


def break_even_k_inf(rho, c_new) -> np.ndarray:
    """Result 6: the limit of k* for a very well visited item, c_new rho^2 / (1 - rho^2)."""
    r2 = np.clip(np.asarray(rho, dtype=float), 0.0, 1.0) ** 2
    with np.errstate(divide="ignore"):
        return np.where(r2 < 1.0, c_new * r2 / (1.0 - r2), np.inf)


def beta_binomial_c(s, n) -> float:
    """Moment estimate of c = E[p(1-p)] / Var(p) across items from success counts s of n visits
    (items with n >= 2): E[p(1-p)] by the unbiased s(n-s)/(n(n-1)); Var(p) by the variance of s/n
    minus the mean binomial part. inf when no spread between items is left."""
    s = np.asarray(s, dtype=float)
    n = np.asarray(n, dtype=float)
    k = np.isfinite(s) & np.isfinite(n) & (n >= 2)
    s, n = s[k], n[k]
    if s.size < 3:
        return NAN
    pq = s * (n - s) / (n * (n - 1.0))
    var_p = np.var(s / n, ddof=1) - np.mean(pq / n)
    if var_p <= 0:
        return math.inf
    return float(np.mean(pq) / var_p)


# ===========================================================================
# Derived statistics from summed parts (work on scalars or on arrays of draws)
# ===========================================================================


def _div(a, b):
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(b != 0, a / np.where(b != 0, b, 1.0), NAN)


def decomp_stats(T: dict) -> dict:
    """Every statistic of the transfer decomposition from summed parts T (scalars, or arrays over
    bootstrap draws)."""
    g = lambda k: np.asarray(T.get(k, NAN), dtype=float)
    out = {}
    out["cw_home"] = 0.5 + _div(g("V_o"), 2.0 * g("W_o"))
    out["cw_swap"] = 0.5 + _div(g("V_n"), 2.0 * g("W_n"))
    out["cu_home"] = 0.5 + _div(g("U_o"), 2.0 * g("I_o"))
    out["cu_swap"] = 0.5 + _div(g("U_n"), 2.0 * g("I_n"))
    out["R"] = _div(out["cw_swap"] - 0.5, out["cw_home"] - 0.5)
    from msr.metrics import theta_from_sums     # THE definition of theta (Part 2.4)
    out["theta"] = np.vectorize(theta_from_sums, otypes=[float])(g("V_n"), g("V_o"))   # the headline (= R_V)
    out["R_V"] = out["theta"]
    out["spread_sum_ratio"] = _div(g("W_o"), g("W_n"))      # R = theta * W_home / W_swap exactly
    out["gamma"] = np.where(g("N_c") > 0, _div(g("C_on"), g("C_oo")), NAN)          # cross-session
    out["gamma_within"] = np.where(g("N_g") > 0, _div(g("S_on"), g("S_oo")), NAN)   # sensitivity
    # within-session minus cross-session estimate of the owner's signal, per pair (an A2 check):
    # zero in expectation when repeats inside a session are independent and the model did not drift
    out["d2_within_minus_cross"] = _div(g("S_oo"), g("N_g")) - _div(g("C_oo"), g("N_c"))
    with np.errstate(invalid="ignore"):
        den = np.sqrt(np.where((g("S_oo2") > 0) & (g("S_nn2") > 0), g("S_oo2") * g("S_nn2"), NAN))
        out["rho"] = np.where(g("N_r") > 0, _div(g("S_on2"), den), NAN)
        # theta x sqrt(S_owner / S_reader): the "retained agreement" of msr.forecast (a correlation-type
        # measure, manager's ruling E3); the key R_std stays as other modules read it
        out["R_std"] = out["theta"] * np.sqrt(_div(g("S_oo2"), g("S_nn2")))
    out["rel_old"] = _div(g("Q_oo"), g("R_oo"))
    out["rel_new"] = _div(g("Q_nn"), g("R_nn"))
    out["spread_ratio"] = _div(_div(g("W_o"), g("N_o")), _div(g("W_n"), g("N_n")))
    # the specification test in product form (no division by the weak denominator):
    # Q = V_swap C_oo - C_on V_home estimates P_V P_C E[delta_s^2] L, zero when L = 0
    out["spec_Q"] = g("V_n") * g("C_oo") - g("C_on") * g("V_o")
    out["pred_V"] = out["gamma"] * g("V_o")
    out["pred_cw_swap"] = 0.5 + _div(out["pred_V"], 2.0 * g("W_n"))
    out["gap_cw"] = out["cw_swap"] - out["pred_cw_swap"]
    out["gap_theta"] = out["theta"] - out["gamma"]
    out["gap_RV"] = out["gap_theta"]
    out["pred_R"] = out["gamma"] * out["spread_ratio"]
    # Result 4: the Gaussian corollaries
    with np.errstate(invalid="ignore"):
        r_h = _div(g("XY_o"), np.sqrt(g("XX_o") * g("YY_o")))
        r_s = _div(g("XY_n"), np.sqrt(g("XX_n") * g("YY_n")))
    out["r_home"], out["r_swap"] = r_h, r_s
    out["gauss_cu_home"] = gaussian_c(r_h)
    out["gauss_cw_home"] = gaussian_cw(r_h)
    with np.errstate(invalid="ignore"):
        r_pred = r_h * out["rho"] * np.sqrt(_div(out["rel_new"], out["rel_old"]))
    out["gauss_pred_cu_swap"] = gaussian_c(r_pred)
    out["gauss_pred_cw_swap"] = gaussian_cw(r_pred)
    # Result 1b / 4b: the home ceilings
    md2 = _div(g("Q_oo"), g("N_oo"))
    mab = _div(g("W_o"), g("N_o"))
    with np.errstate(invalid="ignore"):
        root = np.sqrt(np.where(md2 > 0, md2, NAN))
    out["ceiling_bound"] = 0.5 + _div(root, 2.0 * mab)
    out["ceiling_gauss"] = 0.5 + SQRT_2_PI * _div(root, 2.0 * mab)
    with np.errstate(invalid="ignore"):
        out["rel_x_bank2"] = _div(g("XB"), np.sqrt(g("XX_b") * g("BB_b")))
    # truth (simulated studies)
    if "T_Vo" in T:
        out["true_gamma"] = _div(g("T_on"), g("T_oo"))
        with np.errstate(invalid="ignore"):
            out["true_rho"] = _div(g("T_on"), np.sqrt(g("T_oo") * g("T_nn")))
        out["true_R_V"] = _div(g("T_Vn"), g("T_Vo"))
        out["true_theta"] = out["true_R_V"]
        out["true_gap_RV"] = out["true_R_V"] - out["true_gamma"]
        out["true_ceiling"] = 0.5 + _div(g("T_abs_o"), 2.0 * g("W_o"))
        out["true_V_home"] = g("T_Vo")
        out["true_V_swap"] = g("T_Vn")
    out["V_home"], out["V_swap"], out["W_home"], out["W_swap"] = g("V_o"), g("V_n"), g("W_o"), g("W_n")
    return out


# ===========================================================================
# Bootstraps
# ===========================================================================


def task_totals(per_task: dict, counts: np.ndarray, keys) -> dict:
    """Task bootstrap: per-task sums (E,) and a count matrix (B, E) -> totals per draw (B,)."""
    return {k: counts @ per_task[k] for k in keys}


#: per-pair parts of each numerator and denominator (for Fieller sets and for the product-form test)
RATIO_PARTS = {"theta": ("V_n", "V_o"), "gamma": ("C_on", "C_oo"), "gamma_within": ("S_on", "S_oo")}


def influence(stat: str, T: dict, Q: dict) -> np.ndarray:
    """Per-pair influence values of a statistic (first-order expansion around the totals T); Q[k]
    are the per-pair arrays of the parts. stat: gap_cw, gamma, gamma_within, theta (= R_V), spec_Q,
    or "num:<ratio>" / "den:<ratio>" (the raw parts of a ratio, for Fieller sets)."""
    g = lambda k: float(T[k])
    if stat.startswith("num:") or stat.startswith("den:"):
        nk, dk = RATIO_PARTS[stat[4:]]
        return np.asarray(Q[nk if stat.startswith("num:") else dk], dtype=float)
    if stat == "spec_Q":
        return (g("C_oo") * Q["V_n"] + g("V_n") * Q["C_oo"] - g("V_o") * Q["C_on"] - g("C_on") * Q["V_o"])
    if stat == "spec_D":          # D = 2 C_oo W_swap, the scale that turns Q into a gap in Cw
        return 2.0 * (g("C_oo") * Q["W_n"] + g("W_n") * Q["C_oo"])
    if stat in ("spec_eq_hi", "spec_eq_lo"):      # Q -/+ margin D (the two one-sided equivalence tests)
        sgn = -1.0 if stat == "spec_eq_hi" else 1.0
        return influence("spec_Q", T, Q) + sgn * EQ_MARGIN * influence("spec_D", T, Q)
    stat = {"R_V": "theta"}.get(stat, stat)
    bad = {"gamma": g("C_oo") <= 0, "gamma_within": g("S_oo") <= 0, "theta": g("V_o") == 0,
           "gap_cw": g("C_oo") <= 0 or g("W_n") <= 0}.get(stat, False)
    if bad:
        return np.full(np.shape(Q["V_o"]), NAN)
    if stat in RATIO_PARTS:
        nk, dk = RATIO_PARTS[stat]
        r = g(nk) / g(dk)
        return (Q[nk] - r * Q[dk]) / g(dk)
    if stat == "gap_cw":
        gam = g("C_on") / g("C_oo")
        G = g("V_n") - gam * g("V_o")
        Wn = g("W_n")
        return ((Q["V_n"] - gam * Q["V_o"] - (g("V_o") / g("C_oo")) * Q["C_on"]
                 + (gam * g("V_o") / g("C_oo")) * Q["C_oo"]) / (2.0 * Wn) - G / (2.0 * Wn ** 2) * Q["W_n"])
    raise ValueError(stat)


def interval(draws: np.ndarray, level: float = 0.95) -> tuple:
    d = np.asarray(draws, dtype=float)
    d = d[np.isfinite(d)]
    if d.size < 10:
        return NAN, NAN
    a = (1.0 - level) / 2.0
    lo, hi = np.percentile(d, [100 * a, 100 * (1 - a)])
    return float(lo), float(hi)


def p_two_sided(draws: np.ndarray) -> float:
    """The pre-registration's percentile p-value (4.2) for 'the statistic is 0'."""
    d = np.asarray(draws, dtype=float)
    d = d[np.isfinite(d)]
    if d.size == 0:
        return NAN
    B = d.size
    pu = (1 + np.sum(d <= 0)) / (B + 1)
    pl = (1 + np.sum(d >= 0)) / (B + 1)
    return float(min(1.0, 2.0 * min(pu, pl)))


# ===========================================================================
# Loading a study's cells
# ===========================================================================


class Cell:
    """The per-pair arrays of one (owner, reader, stream, order), for every family. tkey (E,) and
    ikey_a / ikey_b (E, P) are descriptive keys of the tasks and of each pair's two items (no variance
    reads ikey_a / ikey_b); the two-way variance reads tkey_pooled and the item clusters items_task
    (write task within stream, the registered coding) or items_owner (the earlier owner coding), as
    ITEM_CLUSTER selects (_item_keys)."""

    def __init__(self, owner, reader, stream, order, tasks, ikey_a, ikey_b, n_items, outcome, scores,
                 truth=None, variants=None, beta_sn=None, calib=None):
        self.owner, self.reader, self.stream, self.order = owner, reader, stream, order
        self.tasks = tasks
        self.tkey = np.array([f"{stream}|{order}|{t}" for t in tasks.tolist()])
        # the canonical clusters (msr.metrics.robust_variance): a task id within a stream, pooled
        # over the stream orders, and the candidate items of each task
        self.tkey_pooled = np.array([f"{stream}|{t}" for t in tasks.tolist()])
        self.items_task = None          # (E, C) write task within stream (registered, ruling E1), '' = no candidate
        self.items_owner = None         # (E, C) owner | stream | item id (the earlier coding, a sensitivity)
        self.ikey_a, self.ikey_b = ikey_a, ikey_b     # (E, P) strings
        self.n_items = n_items
        self.outcome = outcome          # {key: (E, P)}
        self.scores = scores            # {family: {key: (E, P)}}
        self.truth = truth or {}        # {family: {key: (E, P)}}
        self.variants = variants or {}  # {name: (outcome dict, {family: score dict})}
        self.beta_sn = beta_sn
        self.calib = calib or {}        # per calibration task: {"V:<family>": (Ec,), "C": (Ec,)} (definedness)

    def arrays(self, family: str, variant: str | None = None) -> dict:
        if variant is None:
            d = dict(self.outcome)
            d.update(self.scores[family])
            d.update(self.truth.get(family, {}))
        else:
            o, sc = self.variants[variant]
            d = dict(o)
            d.update(sc[family])
        return {k: v for k, v in d.items() if not k.startswith("_")}


def _load_npz(path: Path) -> dict:
    with np.load(path, allow_pickle=False) as z:
        return {k: z[k] for k in z.files}


def _valid_mask(results: Path, cell_name: str, eval_tasks: np.ndarray) -> np.ndarray:
    p = results / "per_task" / f"{cell_name}.npz"
    if not p.exists():
        return np.ones(len(eval_tasks), dtype=bool)
    d = _load_npz(p)
    pos = {t: k for k, t in enumerate(d["tasks"].tolist())}
    return np.array([bool(d["valid"][pos[t]]) if t in pos else False for t in eval_tasks.tolist()])


def _true_mu(model: str, stream: str, tasks, items) -> np.ndarray:
    from msr import sim
    out = np.full(items.shape, NAN)
    for e, t in enumerate(tasks):
        for c, i in enumerate(items[e]):
            if i:
                out[e, c] = sim.true_success_prob(model, stream, str(t), str(i))
    return out


def calib_parts(x_by_family: dict, y_old, y_old2, has) -> dict:
    """Per-task parts on the owner's CALIBRATION tasks, used only to decide definedness (Result 3):
    "V:<family>" = the home signed validity of each task (repeats 1-2) and "C" = the cross-session
    product sum dy(1-2) dy(3-4) of each task. No estimate of the decomposition uses these tasks."""
    y_old = np.asarray(y_old, dtype=float)
    ia, ib = pair_index(y_old.shape[1])
    op = outcome_pairs(y_old, y_old, ia, ib, has, None if y_old2 is None else np.asarray(y_old2, dtype=float))
    out = {"C": op["C_oo"].sum(-1)}
    for f, x in x_by_family.items():
        out[f"V:{f}"] = score_pairs(np.where(has, np.asarray(x, dtype=float), NAN), op, ia, ib)["V_o"].sum(-1)
    return out


def calib_z(cells: list, key: str) -> float:
    """z = sum / (sd * sqrt(n)) of the per-calibration-task parts `key` over the cells (orders,
    streams): the home signal's strength measured on tasks that no estimate uses."""
    from msr.metrics import calibration_z            # THE definition (msr.metrics, Part 2.4)
    v = np.concatenate([np.asarray(c.calib.get(key, np.zeros(0)), dtype=float) for c in cells]) if cells else np.zeros(0)
    return calibration_z(v)


def cell_from_arrays(owner, reader, stream, order, tasks, items, x_by_family: dict, y_old, y_new,
                     has=None, x_bank2: dict | None = None, mu_old=None, mu_new=None, beta_sn=None,
                     y_old2=None, calib=None) -> Cell:
    """A Cell from plain arrays (used by load_cell and by synthetic tests). items (E, C) item ids
    ('' = no candidate); x_by_family {family: (E, C)}; y_old (E, C, R_o) the owner's home repeats
    1-2; y_new (E, C, R_n); y_old2 (E, C, R) the owner's second home session (repeats 3-4) or None;
    calib: calib_parts() of the owner's calibration tasks (definedness), or None."""
    items = np.asarray(items).astype(str)
    if has is None:
        has = items != ""
    C = items.shape[1]
    ia, ib = pair_index(C)
    ik = np.array([[f"{owner}|{stream}|{order}|{i}" for i in row] for row in items.tolist()])
    op = outcome_pairs(y_old, y_new, ia, ib, has, y_old2)
    scores, tr, variants = {}, {}, {}
    xs = {f: np.where(has, np.asarray(x, dtype=float), NAN) for f, x in x_by_family.items()}
    for f, x in xs.items():
        xb = None if not x_bank2 or f not in x_bank2 else np.where(has, x_bank2[f], NAN)
        scores[f] = score_pairs(x, op, ia, ib, xb)
    if mu_old is not None and mu_new is not None:
        okp = has[:, ia] & has[:, ib]
        for f, x in xs.items():
            tr[f] = truth_pairs(x, mu_old, mu_new, ia, ib, okp)
    if np.asarray(y_new).shape[-1] >= 2:
        opr = outcome_pairs(y_old, np.asarray(y_new)[..., :1], ia, ib, has, y_old2)
        variants["reader1"] = (opr, {f: score_pairs(x, opr, ia, ib) for f, x in xs.items()})
    if np.asarray(y_old).shape[-1] >= 2:
        opo = outcome_pairs(np.asarray(y_old)[..., :1], y_new, ia, ib, has,
                            None if y_old2 is None else np.asarray(y_old2)[..., :1])
        variants["owner1"] = (opo, {f: score_pairs(x, opo, ia, ib) for f, x in xs.items()})
    n_items = len({str(i) for i in items[has].tolist()})
    cell = Cell(owner, reader, stream, order, np.asarray(tasks), ik[:, ia], ik[:, ib], n_items, op, scores, tr,
                variants, beta_sn, calib)
    # the canonical item clusters (ruling E1, revision 3): the WRITE TASK within the stream, so the items
    # that two owners wrote from one write task are one cluster, and an item that recurs in two orders'
    # banks is one cluster; the earlier coding (identity within (owner, stream), revision 2) is kept as a
    # sensitivity. For one owner the two are the same partition.
    rows = items.tolist()
    cell.items_task = np.where(has, np.array([[write_task_key(i, stream) for i in row] for row in rows]), "")
    cell.items_owner = np.where(has, np.array([[owner_item_key(i, owner, stream) for i in row] for row in rows]), "")
    return cell


def load_cell(results: Path, owner: str, reader: str, stream: str, order, families, truth: bool = False) -> Cell | None:
    """One cell's arrays on its evaluation tasks. For a home cell (owner == reader) the 'new'
    outcomes are the extra home repeats 3-4 (the self-swap). Tasks dropped by the missing-cell
    rule in either the home or the swap cell are left out, so home and swap use the same tasks.
    The owner's second home session (repeats 3-4, the cross-session denominator of gamma) and the
    owner's calibration tasks (definedness only) come from the home cell's file."""
    name = f"{owner}__{reader}__{stream}__seed{order}"
    path = results / "cells" / f"{name}.npz"
    if not path.exists():
        return None
    d = _load_npz(path)
    hpath = results / "cells" / f"{owner}__{owner}__{stream}__seed{order}.npz"
    hd = d if owner == reader else (_load_npz(hpath) if hpath.exists() else {})
    ev = ~d["is_calib"].astype(bool)
    tasks = d["tasks"][ev]
    items = d["items"][ev].astype(str)
    y_old = d["y_home"][ev]
    if owner == reader:
        if "y_extra" not in d:
            return None
        y_new = d["y_extra"][ev]
    else:
        y_new = d["y"][ev]
    valid = _valid_mask(results, name, tasks) & _valid_mask(results, f"{owner}__{owner}__{stream}__seed{order}", tasks)
    has = (items != "") & valid[:, None]
    xs = {f: d[f"score_{f}"][ev] for f in families if f"score_{f}" in d}
    xb = {f: d[f"score_{f}_bank2"][ev] for f in xs if f"score_{f}_bank2" in d}
    y_old2, calib = None, None
    if "y_extra" in hd and np.array_equal(np.asarray(hd["tasks"]), np.asarray(d["tasks"])):
        y_old2 = hd["y_extra"][ev]
        cal = d["is_calib"].astype(bool)
        if cal.any():
            hc = hd["items"][cal].astype(str) != ""
            calib = calib_parts({f: hd[f"score_{f}"][cal] for f in xs if f"score_{f}" in hd},
                                hd["y_home"][cal], hd["y_extra"][cal], hc)
    mu_o = mu_n = None
    if truth:
        it = np.where(has, items, "")
        mu_o = _true_mu(owner, stream, tasks, it)
        mu_n = mu_o if owner == reader else _true_mu(reader, stream, tasks, it)
    beta_sn = None
    if "score_beta_grade" in d and "visits" in d:      # Result 6: successes and visits, one per item
        xbg, nv = d["score_beta_grade"][ev], d["visits"][ev]
        sn = {}
        for e in range(items.shape[0]):
            for c in range(items.shape[1]):
                if has[e, c]:
                    sn[items[e, c]] = (xbg[e, c] * (2.0 + nv[e, c]) - 1.0, nv[e, c])
        beta_sn = np.array(list(sn.values()), dtype=float) if sn else None
    return cell_from_arrays(owner, reader, stream, order, tasks, items, xs, y_old, y_new, has, xb, mu_o, mu_n,
                            beta_sn, y_old2=y_old2, calib=calib)


# ===========================================================================
# Synthetic worlds with a known truth (tests and the numbers of docs/theory_note.md)
# ===========================================================================


def _draw_session(rng, mu, reps, cache):
    """reps Bernoulli(mu) repeats per cell; with probability `cache` each repeat after the first copies
    the first (provider-side caching or near-greedy decoding: dependence INSIDE a session)."""
    y = (rng.random(mu.shape + (reps,)) < mu[..., None]).astype(float)
    if cache > 0 and reps > 1:
        cp = rng.random(mu.shape + (reps - 1,)) < cache
        y[..., 1:] = np.where(cp, y[..., :1], y[..., 1:])
    return y


def synthetic_world(n_tasks=400, n_items=250, n_cand=4, reps_old=2, reps_new=2, corr=0.6, scale_old=0.15,
                    scale_new=0.15, score_noise=1.0, leak=0.0, split=0.0, split_transfer=1.0, task_sd=0.0,
                    level_new=0.0, cache_old=0.0, n_calib=0, seed=0) -> dict:
    """Items with an old effect e_o ~ N(0, 1) and a new effect e_n = corr e_o + sqrt(1 - corr^2) u.
    mu_m(task, i) = clip(0.5 + level_m + scale_m * e_m(i) + task_sd * v_m(task, i), 0.01, 0.99), where
    v is a task-by-item part shared by both models when task_sd > 0. Score x(i) = e_o(i) +
    score_noise * z(i) + leak * u(i): leak = 0 gives L = 0 in the population of items (linear
    transfer, no leakage); leak != 0 lets the score see the new model's own part.
    split > 0 instead builds e_o from two parts, e_o = sqrt(1 - split) a + sqrt(split) c, where the
    new model inherits a fully and c with weight split_transfer, and the score sees only c: the
    signal sits in the component that transfers worse (or better) than the average.
    The owner has two home sessions of reps_old repeats each (y_old = repeats 1-2, y_old2 = repeats
    3-4); cache_old > 0 makes repeats inside each session dependent (sessions stay independent).
    n_calib > 0 adds that many calibration tasks (same items and distribution), returned as calib parts.
    Returns x (E, C), y_old, y_old2, y_new (E, C, R), mu_old, mu_new, items (E, C), calib and the
    population gamma."""
    rng = np.random.default_rng(seed)
    if split > 0:
        a_ = rng.normal(size=n_items)
        c_ = rng.normal(size=n_items)
        e_o = math.sqrt(1 - split) * a_ + math.sqrt(split) * c_
        u = rng.normal(size=n_items)
        e_n = math.sqrt(1 - split) * a_ + math.sqrt(split) * split_transfer * c_
        resid = 1.0 - (1 - split) - split * split_transfer ** 2
        e_n = e_n + math.sqrt(max(resid, 0.0)) * u
        x_item = c_ + score_noise * rng.normal(size=n_items)
        gamma_e = (1 - split) + split * split_transfer
    else:
        e_o = rng.normal(size=n_items)
        u = rng.normal(size=n_items)
        e_n = corr * e_o + math.sqrt(1 - corr ** 2) * u
        x_item = e_o + score_noise * rng.normal(size=n_items) + leak * u
        gamma_e = corr
    nt = n_tasks + n_calib
    cand = np.array([rng.choice(n_items, n_cand, replace=False) for _ in range(nt)])
    v = rng.normal(size=cand.shape) * task_sd
    mu_o = np.clip(0.5 + scale_old * e_o[cand] + v, 0.01, 0.99)
    mu_n = np.clip(0.5 + level_new + scale_new * e_n[cand] + v, 0.01, 0.99)
    y_o = _draw_session(rng, mu_o, reps_old, cache_old)
    y_o2 = _draw_session(rng, mu_o, reps_old, cache_old)
    y_n = (rng.random(cand.shape + (reps_new,)) < mu_n[..., None]).astype(float)
    gam = (scale_new * scale_old * gamma_e + task_sd ** 2) / (scale_old ** 2 + task_sd ** 2)
    x = x_item[cand]
    ev = slice(0, n_tasks)
    calib = None
    if n_calib:
        cs = slice(n_tasks, nt)
        calib = calib_parts({"f": x[cs]}, y_o[cs], y_o2[cs], np.ones(x[cs].shape, bool))
    return {"x": x[ev], "y_old": y_o[ev], "y_old2": y_o2[ev], "y_new": y_n[ev], "mu_old": mu_o[ev],
            "mu_new": mu_n[ev], "items": cand[ev].astype(str), "tasks": np.array([f"t{k}" for k in range(n_tasks)]),
            "gamma_population": gam, "calib": calib}


def decomp_on_world(w: dict, B: int = 0, seed: int = 0, within: bool = False) -> dict:
    """The decomposition's statistics on one synthetic world (one cell): point values, the two-way
    SEs, Fieller sets for theta and gamma, the product-form specification test and, if B > 0,
    task-bootstrap intervals. within=True drops the owner's second session (gamma then has no
    cross-session estimate; gamma_within is the within-session one)."""
    c = cell_from_arrays("o", "n", "s", 0, w["tasks"], w["items"], {"f": w["x"]}, w["y_old"], w["y_new"],
                         mu_old=w.get("mu_old"), mu_new=w.get("mu_new"),
                         y_old2=None if within else w.get("y_old2"), calib=w.get("calib"))
    T = _sum([c], "f")
    out = _stats_row(T)
    for stat in ("gap_cw", "gamma", "gamma_within", "theta", "spec_Q"):
        v = _twoway([c], "f", stat, T)
        out[f"se2_{stat}"] = math.sqrt(v["V"]) if v["V"] > 0 else NAN
        out[f"se_task_lin_{stat}"] = math.sqrt(v["V_task"]) if v["V_task"] > 0 else NAN
    out["se2_R_V"] = out["se2_theta"]
    out["spec_z"] = out["spec_Q"] / out["se2_spec_Q"] if out["se2_spec_Q"] > 0 else NAN
    out["spec_p"] = _normal_p(out["spec_Q"], out["se2_spec_Q"])
    for r in ("theta", "gamma"):
        lo, hi, kind = ratio_interval([c], "f", r, T)
        out[f"{r}_fieller_lo"], out[f"{r}_fieller_hi"], out[f"{r}_fieller"] = lo, hi, kind
    if c.calib:
        out["z_cal_theta"] = calib_z([c], "V:f")
        out["z_cal_gamma"] = calib_z([c], "C")
    if B:
        from msr.metrics import bootstrap_counts
        counts = bootstrap_counts(len(c.tasks), B, [seed, 7])
        arr = c.arrays("f")
        d = decomp_stats(task_totals({k: v.sum(-1) for k, v in arr.items()}, counts, list(arr)))
        out["gap_cw_lo"], out["gap_cw_hi"] = interval(d["gap_cw"])
        out["gamma_lo"], out["gamma_hi"] = interval(d["gamma"])
    return out


# ===========================================================================
# Numerical companions of the remarks (docs/theory_note.md; tests/test_theory.py)
# ===========================================================================


def baseline_comparison(n_worlds: int = 60, seed: int = 0, **world) -> dict:
    """Review R6 W5: the decomposition's value of the swap concordance, 1/2 + gamma_hat V_home / (2 W_swap),
    against its same-information baselines R = gamma_hat (spreads ignored) and R = rho_hat, and against
    "no change" (C_swap = C_home, no reader data), as mean absolute errors over independent worlds
    built by synthetic_world(**world). Returns the four MAEs and the median gamma_hat with its truth."""
    err = {"decomposition": [], "gamma_only": [], "rho_only": [], "no_change": []}
    g, gt = [], []
    for k in range(n_worlds):
        w = synthetic_world(seed=seed + k, **world)
        o = decomp_on_world(w)
        cs, ch = o["cw_swap"], o["cw_home"]
        err["decomposition"].append(abs(cs - o["pred_cw_swap"]))
        err["gamma_only"].append(abs(cs - (0.5 + o["gamma"] * (ch - 0.5))))
        err["rho_only"].append(abs(cs - (0.5 + o["rho"] * (ch - 0.5))))
        err["no_change"].append(abs(cs - ch))
        g.append(o["gamma"]), gt.append(w["gamma_population"])
    out = {f"mae_{k}": float(np.nanmean(v)) for k, v in err.items()}
    out.update({"gamma_median": float(np.nanmedian(g)), "gamma_mean": float(np.nanmean(g)),
                "gamma_true": float(np.mean(gt))})
    return out


def _slope_truth_one(args) -> dict:
    results, s, t, streams, seeds, fam, group = args
    cs = [load_cell(results, s, t, b, o, [fam], truth=True) for b in streams for o in seeds]
    cs = [c for c in cs if c is not None]
    T = _sum(cs, fam)
    lo, hi, kind = ratio_interval(cs, fam, "gamma", T)
    return {"owner": s, "reader": t, "group": group, "gamma_hat": T["C_on"] / T["C_oo"] if T["C_oo"] else NAN,
            "gamma_within": T["S_on"] / T["S_oo"] if T["S_oo"] else NAN,
            "gamma_true": T["T_on"] / T["T_oo"] if T["T_oo"] else NAN, "gamma_lo": lo, "gamma_hi": hi,
            "gamma_interval": kind, "C_oo": T["C_oo"], "T_oo": T["T_oo"]}


def slope_truth_rows(study_name: str, pairs=None, workers: int = 8) -> list:
    """Round-2 check (AC audit N6, R6 claim 9): the cross-session transfer slope against the simulator's
    truth on a simulated study, per ordered swap, with its Fieller interval (headline variance). On the
    full-size simulated study (8 models, 400 evaluation tasks per order) it tracks the truth (see
    docs/theory_note.md, round 2); on the 4-model practice study each owner's denominator rests on 56
    tasks per order and is shared by its three swaps, so the 12 swaps are four draws."""
    from concurrent.futures import ProcessPoolExecutor
    from msr.analysis import design_from_study, resolve_study
    st = resolve_study(study_name)
    d = design_from_study(st)
    pairs = pairs or [p for p in d.pairs if p[0] != p[1]]
    args = [(st.results_dir, s, t, list(d.streams), list(d.seeds), d.headline, d.group(s, t)) for s, t in pairs]
    if workers > 1 and len(args) > 1:
        with ProcessPoolExecutor(min(workers, len(args))) as ex:
            return list(ex.map(_slope_truth_one, args))
    return [_slope_truth_one(a) for a in args]


def expected_abs_diff_two_repeats(mi, mj) -> np.ndarray:
    """E|ybar_i - ybar_j| exactly, for two-repeat means of independent Bernoulli(mi), Bernoulli(mj)."""
    vals = np.array([0.0, 0.5, 1.0])
    pi = np.stack([(1 - mi) ** 2, 2 * mi * (1 - mi), mi ** 2], -1)
    pj = np.stack([(1 - mj) ** 2, 2 * mj * (1 - mj), mj ** 2], -1)
    out = 0.0
    for a in range(3):
        for b in range(3):
            out = out + pi[..., a] * pj[..., b] * abs(vals[a] - vals[b])
    return out


def monotone_map_world(g, n_tasks=200000, n_items=5000, sd_b=0.8, sd_e=0.8, sd_xn=0.4, lvl_mean=0.3, lvl_sd=1.0,
                       seed=7) -> dict:
    """The reviewer's counter-example, as population values (large Monte Carlo over tasks, exact
    expectations over the outcome noise). The owner's chance is mu_s = expit(level + b_i + e_tau,i),
    the score x_i = b_i + noise sees the owner's item effect only, and the reader's chance is a
    deterministic increasing function of the owner's, mu_t = g(mu_s), cell by cell: the scores carry
    nothing about the reader beyond the owner's usefulness (x independent of mu_t given mu_s), yet L
    need not be 0 because transfer is not linear.

    Returns gamma, theta (= R_V), L, the gap in theta units (theta - gamma) and in Cw units (two
    repeats each), the local-slope form (Remark: theta - gamma = E[(s - gamma) a delta_s] /
    E[a delta_s] with s the mean slope of g over each pair's segment), and the mean success chances."""
    rng = np.random.default_rng(seed)
    ia, ib = pair_index(4)
    items = rng.integers(0, n_items, size=(n_tasks, 4))
    b = rng.normal(0, sd_b, n_items)
    e = rng.normal(0, sd_e, (n_tasks, 4))
    lvl = rng.normal(lvl_mean, lvl_sd, (n_tasks, 1))
    mu_s = 1 / (1 + np.exp(-(lvl + b[items] + e)))
    mu_t = g(mu_s)
    x = (b + rng.normal(0, sd_xn, n_items))[items]
    ds = mu_s[:, ia] - mu_s[:, ib]
    dt = mu_t[:, ia] - mu_t[:, ib]
    a = np.sign(x[:, ia] - x[:, ib])
    gam = float((ds * dt).mean() / (ds ** 2).mean())
    Vh, Vs = float((a * ds).mean()), float((a * dt).mean())
    L = Vs - gam * Vh
    Ws = float(expected_abs_diff_two_repeats(mu_s[:, ia], mu_s[:, ib]).mean())
    Wt = float(expected_abs_diff_two_repeats(mu_t[:, ia], mu_t[:, ib]).mean())
    with np.errstate(invalid="ignore", divide="ignore"):
        slope = np.where(np.abs(ds) > 1e-12, dt / ds, 0.0)     # mean slope of g over the segment
    local = float(np.sum((slope - gam) * a * ds) / np.sum(a * ds))
    return {"gamma": gam, "theta": Vs / Vh, "L": L, "gap_theta": Vs / Vh - gam, "gap_theta_local": local,
            "gap_cw": L / (2 * Wt), "cw_home": 0.5 + Vh / (2 * Ws), "cw_swap": 0.5 + Vs / (2 * Wt),
            "mean_mu_s": float(mu_s.mean()), "mean_mu_t": float(mu_t.mean())}


def _expit(z):
    return 1 / (1 + np.exp(-z))


def _logit(p):
    return np.log(p / (1 - p))


#: increasing maps from the owner's to the reader's success chance used for the curvature remark
MONOTONE_MAPS = {
    **{f"logit{c:+g}": (lambda c: (lambda p: _expit(_logit(p) + c)))(c) for c in (-2.5, -2, -1.5, -1, -0.5, 0.5, 1, 1.5, 2, 2.5)},
    **{f"logit*{k:g}": (lambda k: (lambda p: _expit(k * _logit(p))))(k) for k in (0.5, 0.75, 1.5, 2, 3)},
    "threshold 5*logit-1": lambda p: _expit(5 * _logit(p) - 1),
    "p^0.5": lambda p: p ** 0.5, "p^2": lambda p: p ** 2, "p^4": lambda p: p ** 4,
}

#: the (sd_b, sd_e, sd_xn) worlds of the remark: the reviewer's default and his reliable-score world
#: (sd_b, sd_e, sd_xn, level mean, level sd): the owner worlds of the curvature remark. The first two are
#: ours; "hard tasks" and "easy, item-dominated" are review R6's (c4 (v)): there a reader one logit away
#: misses by 0.13, so no single bound holds for monotone readers.
MONOTONE_WORLDS = {"default": (0.8, 0.8, 0.4, 0.3, 1.0), "reliable score, item effects dominant": (1.2, 0.5, 0.1, 0.3, 1.0),
                   "item-dominated": (1.5, 0.3, 0.3, 0.3, 1.0), "hard tasks": (0.8, 0.8, 0.4, -1.8, 1.0),
                   "easy, item-dominated": (1.5, 0.3, 0.3, 1.8, 0.5)}


def monotone_map_table(n_tasks=200000, seed=7) -> list:
    """Every map of MONOTONE_MAPS in every world of MONOTONE_WORLDS (rows for docs/theory_note.md)."""
    rows = []
    for wname, (sb, se, sx, lm, ls) in MONOTONE_WORLDS.items():
        for mname, g in MONOTONE_MAPS.items():
            r = monotone_map_world(g, n_tasks=n_tasks, sd_b=sb, sd_e=se, sd_xn=sx, lvl_mean=lm, lvl_sd=ls, seed=seed)
            rows.append({"world": wname, "map": mname, **r})
    return rows


def gaussian_misses(sd_b, sd_e, sd_xn, n_tasks=200000, n_items=5000, link="logit", seed=11) -> dict:
    """How far the Gaussian forms miss with two-repeat 0/1 outcomes (Result 4): the arcsin form for the
    unweighted concordance, (1 + r)/2 for Cw, and the form that keeps the measured E|dybar|. The
    misses depend on the data-generating process; this returns them for one process (logistic or
    linear-probability link, item effect sd_b, task-by-item effect sd_e, score noise sd_xn)."""
    rng = np.random.default_rng(seed)
    ia, ib = pair_index(4)
    items = rng.integers(0, n_items, (n_tasks, 4))
    b = rng.normal(0, sd_b, n_items)
    z = b[items] + rng.normal(0, sd_e, (n_tasks, 4))
    if link == "logit":
        mu = _expit(rng.normal(0.3, 1.0, (n_tasks, 1)) + z)
    else:
        mu = np.clip(0.5 + z, 0.0, 1.0)
    x = (b + rng.normal(0, sd_xn, n_items))[items]
    y = (rng.random((n_tasks, 4, 2)) < mu[..., None]).mean(-1)
    dx = (x[:, ia] - x[:, ib]).ravel()
    dy = (y[:, ia] - y[:, ib]).ravel()
    dm = (mu[:, ia] - mu[:, ib]).ravel()
    inf = dy != 0
    cu = float(np.mean(np.sign(dx[inf]) == np.sign(dy[inf])))
    r = float(np.corrcoef(dx, dy)[0, 1])
    cw = 0.5 + float(np.sum(np.sign(dx) * dy)) / (2 * float(np.sum(np.abs(dy))))
    r_xd = float(np.corrcoef(dx, dm)[0, 1])
    meas = 0.5 + 0.5 * SQRT_2_PI * r_xd * float(dm.std()) / float(np.abs(dy).mean())
    return {"cu": cu, "cw": cw, "miss_arcsin": cu - float(gaussian_c(r)), "miss_r": cw - float(gaussian_cw(r)),
            "miss_measured": cw - meas}


#: the processes behind the stated ranges (the reviewer's three logistic worlds and four linear ones)
GAUSS_WORLDS = (("logit", 0.6, 0.6, 0.3), ("logit", 1.0, 0.5, 0.2), ("logit", 0.4, 0.8, 0.6),
                ("linear", 0.1, 0.0, 0.05), ("linear", 0.2, 0.0, 0.1), ("linear", 0.2, 0.0, 0.2),
                ("linear", 0.3, 0.0, 0.3))


# ===========================================================================
# The study run
# ===========================================================================


def _stats_row(T: dict) -> dict:
    return {k: float(np.asarray(v)) for k, v in decomp_stats(T).items()}


def _sum(cells: list, family: str, variant: str | None = None) -> dict:
    tot = {}
    for c in cells:
        for k, v in c.arrays(family, variant).items():
            tot[k] = tot.get(k, 0.0) + float(v.sum())
    return tot


def _draws(cells: list, family: str, B: int, seed: int, cache: dict) -> dict:
    """Task-bootstrap totals per draw over the cells (orders) of one (owner, reader, level): the
    study's own count matrices (msr.metrics.bootstrap_counts with stratum_seed, Part 4.1)."""
    from msr.metrics import bootstrap_counts, stratum_seed
    tot = None
    for c in cells:
        key = ("counts", c.stream, c.order, len(c.tasks))
        if key not in cache:
            cache[key] = bootstrap_counts(len(c.tasks), B, stratum_seed(seed, c.stream, c.order))
        arr = c.arrays(family)
        part = task_totals({k: v.sum(-1) for k, v in arr.items()}, cache[key], list(arr))
        tot = part if tot is None else {k: tot[k] + part[k] for k in tot}
    return tot


class _Codes:
    """Kept for the call signatures; the item clusters are chosen by _item_keys (ITEM_CLUSTER) and coded
    inside msr.metrics."""


def _item_keys(c: Cell, coding: str | None = None) -> np.ndarray:
    """The (E, C) item clusters of a cell under `coding` (default: the module's ITEM_CLUSTER, read at call
    time): "write_task" = write task within stream (registered, ruling E1), "owner" = owner | stream | item
    id (the earlier coding, a sensitivity)."""
    coding = ITEM_CLUSTER if coding is None else coding
    if coding == "write_task":
        return c.items_task
    if coding == "owner":
        return c.items_owner
    raise ValueError(f"item cluster coding {coding!r}: use one of {ITEM_CLUSTERS}")


def _task_obs(cells: list, family: str, stat: str, T: dict, weight: float = 1.0, coding: str | None = None) -> tuple:
    """One observation per (cell, task): the per-pair influence values of `stat` summed over the pairs
    of the task, centred within its COMPONENT (owner, reader, stream, pooled over the orders, as the
    headline's variance pools them), with the canonical clusters of msr.metrics.robust_variance (task id
    within a stream, pooled over orders; the task's candidate items as write tasks within the stream, so
    a write task is one cluster across owners and orders; coding="owner" or ITEM_CLUSTER = "owner" gives
    the earlier identity within (owner, stream)). Returns (psi, task keys, item keys (n, C), component keys)."""
    groups = {}
    for c in cells:
        q = np.asarray(influence(stat, T, c.arrays(family)), dtype=float)
        v = np.where(np.isfinite(q), q, 0.0).sum(-1)
        bad = ~np.isfinite(q).any(-1) if q.ndim == 2 else np.zeros(len(v), bool)
        v = np.where(bad, np.nan, v)
        ok = np.isfinite(v)
        if not ok.any():
            continue
        key = f"{c.owner}|{c.reader}|{c.stream}"
        groups.setdefault(key, []).append((v[ok], c.tkey_pooled[ok], _item_keys(c, coding)[ok]))
    P, Tk, I, Cp = [], [], [], []
    for key, parts in groups.items():
        vv = np.concatenate([x[0] for x in parts])
        P.append(weight * (vv - vv.mean()))
        Tk.append(np.concatenate([x[1] for x in parts]))
        I.append(np.vstack([x[2] for x in parts]))
        Cp.append(np.full(len(vv), key))
    if not P:
        return np.zeros(0), np.zeros(0, dtype=str), np.zeros((0, 1), dtype=str), np.zeros(0, dtype=str)
    return np.concatenate(P), np.concatenate(Tk), np.vstack(I), np.concatenate(Cp)


def _cluster_var(psi, tk, it, comp=None) -> dict:
    """The headline's variance (msr.metrics.robust_variance: two-way delete-one-cluster jackknife)."""
    from msr import metrics as M
    if len(psi) == 0:
        return {"V": NAN, "V_task": NAN, "V_item": NAN}
    return M.robust_variance(psi, tk, it, comp)


def _fieller_union(a: float, b: float, P2: np.ndarray, tk, it, comp, level: float = 0.95) -> tuple:
    """Fieller set for a / b from the two columns P2 (numerator, denominator influence values) that
    inverts the headline's variance exactly as msr.metrics.theta_tests does: the union of the raw
    two-way and the task-only Fieller sets of robust_variance."""
    from msr import metrics as M
    from statistics import NormalDist
    res = M.robust_variance(P2, tk, it, comp)
    z = NormalDist().inv_cdf(0.5 + level / 2.0)
    ivs = [M._fieller_set(a, b, Q[0, 0], Q[0, 1], Q[1, 1], z) for Q in (res["V_raw"][:2, :2], res["V_task"][:2, :2])]
    got = [iv for iv in ivs if iv[2] in ("bounded", "unbounded")]
    if any(iv[2] == "unbounded" for iv in got):
        return -math.inf, math.inf, "unbounded"
    if got:
        return min(iv[0] for iv in got), max(iv[1] for iv in got), "bounded"
    return NAN, NAN, "not computable"


def _twoway(cells: list, family: str, stat: str, T: dict | None = None, codes=None, coding: str | None = None) -> dict:
    """Two-way (task id x item) variance of a statistic over the cells: msr.metrics.robust_variance
    on the per-task influence values (the same variance as the headline theta, Part 4.1); items coded
    as `coding` (default ITEM_CLUSTER)."""
    T = T or _sum(cells, family)
    return _cluster_var(*_task_obs(cells, family, stat, T, coding=coding))


def ratio_interval(cells: list, family: str, ratio: str, T: dict | None = None, level: float = 0.95,
                   coding: str | None = None) -> tuple:
    """Fieller interval for theta or gamma that inverts the headline's variance (msr.metrics: the
    union of the raw two-way and task-only Fieller sets of robust_variance, as theta_tests); items coded
    as `coding` (default ITEM_CLUSTER). Returns (lo, hi, status): 'bounded', 'unbounded' or 'not computable'."""
    T = T or _sum(cells, family)
    nk, dk = RATIO_PARTS[ratio]
    a, b = float(T.get(nk, 0.0)), float(T.get(dk, 0.0))
    pn, tk, it, cp = _task_obs(cells, family, f"num:{ratio}", T, coding=coding)
    pd, _, _, _ = _task_obs(cells, family, f"den:{ratio}", T, coding=coding)
    if len(pn) == 0 or len(pn) != len(pd):
        return NAN, NAN, "not computable"
    return _fieller_union(a, b, np.column_stack([pn, pd]), tk, it, cp, level)


_fieller_cells = ratio_interval


def theta_canonical(cells: list, family: str, T: dict | None = None, coding: str | None = None) -> dict:
    """theta with the headline's own inference (msr.metrics.theta_tests: the registered variance, the
    Fieller set and the intersection-union tests), from this module's cells (items coded as `coding`,
    default ITEM_CLUSTER); the home-signal status is the single flag of msr.metrics (home_signal_flag on
    the owner's calibration tasks)."""
    from msr import metrics as M
    T = T or _sum(cells, family)
    pn, tk, it, cp = _task_obs(cells, family, "num:theta", T, coding=coding)
    pd, _, _, _ = _task_obs(cells, family, "den:theta", T, coding=coding)
    if len(pn) == 0:
        return {"theta": NAN, "lo": NAN, "hi": NAN, "interval": "not computable", "status": M.THETA_CAL_UNDEFINED}
    out = M.theta_tests(float(T["V_n"]), float(T["V_o"]), pn, pd, tk, it, cp)
    v = np.concatenate([np.asarray(c.calib.get(f"V:{family}", np.zeros(0)), dtype=float) for c in cells])
    out["z_cal"], out["status"] = M.home_signal_flag(v) if v.size else (NAN, M.THETA_CAL_UNDEFINED)
    return out


def _kind(design, s, t) -> str:
    if s == t:
        return "home"
    return "same_maker" if design.family.get(s) == design.family.get(t) else "cross_maker"


Z95 = 1.959963984540054
from msr.metrics import THETA_CAL_MIN_Z as CAL_MIN_Z   # 2.0: the owner's calibration-task signal >= 2 SEs (msr.metrics)


def _normal_p(est: float, se: float) -> float:
    if not (math.isfinite(est) and math.isfinite(se) and se > 0):
        return NAN
    return float(math.erfc(abs(est / se) / math.sqrt(2.0)))


def run(study_name: str = "sim", draws: int | None = None, out_dir=None, fig_dir=None,
        truth: bool | None = None, make_figures: bool = True, printer=print) -> dict:
    """Compute the transfer decomposition for every ordered pair, stream level and family; write
    decomp_pairs.csv and decomp_summary.csv to runs/<study>/analysis/ (out_dir) and the figures
    fig_decomp_predicted_vs_measured and fig_decomp_ratio_vs_noise to paper/assets/ (fig_dir).

    draws: task-bootstrap draws (default: the study's evaluate.bootstrap, at most 2,000).
    truth: also compute the noise-free values from msr.sim (default: when every model is simulated)."""
    from msr.analysis import design_from_study, resolve_study
    st = resolve_study(study_name)
    design = design_from_study(st)
    results = st.results_dir
    out_dir = Path(out_dir) if out_dir else st.dir / "analysis"
    fig_dir = Path(fig_dir) if fig_dir else ROOT / "paper" / "assets"
    B = int(draws or min(int(st.evaluate.bootstrap), 2000))
    seed = int(st.evaluate.seed)
    if truth is None:
        truth = design.kind == "simulated"
    fams = list(design.score_families)
    cells_all = [(m, m) for m in design.models] + [p for p in design.pairs if p[0] != p[1]]
    loaded = {}
    for (s, t) in cells_all:
        for b in design.streams:
            for o in design.seeds:
                c = load_cell(results, s, t, b, o, fams, truth=truth)
                if c is not None:
                    loaded[(s, t, b, o)] = c
    if not loaded:
        raise FileNotFoundError(f"no cells in {results / 'cells'}; run the evaluate stage first")
    levels = list(design.streams) + ["all"]
    rows, store = [], {}
    cache = {}
    codes = _Codes()
    for f in fams:
        for (s, t) in cells_all:
            for lev in levels:
                bs = design.streams if lev == "all" else [lev]
                cs = [loaded[(s, t, b, o)] for b in bs for o in design.seeds if (s, t, b, o) in loaded]
                if not cs or f not in cs[0].scores:
                    continue
                T = _sum(cs, f)
                point = _stats_row(T)
                tot = _draws(cs, f, B, seed, cache)
                dt = decomp_stats(tot)
                store[(f, s, t, lev)] = {"draws": dt, "T": T, "cells": cs}
                row = {"owner": s, "reader": t, "kind": _kind(design, s, t), "group": design.group(s, t),
                       "level": lev, "family": f, "n_tasks": int(sum(len(c.tasks) for c in cs)),
                       "n_pairs": int(T["N_o"]), "n_items": int(sum(c.n_items for c in cs))}
                for k in ("cw_home", "cw_swap", "R", "V_home", "V_swap", "W_home", "W_swap", "theta", "R_V",
                          "gamma", "gamma_within", "d2_within_minus_cross", "rho", "R_std", "rel_old", "rel_new",
                          "spread_ratio", "spread_sum_ratio", "pred_R", "pred_cw_swap", "gap_cw", "gap_theta",
                          "gap_RV", "spec_Q", "cu_home", "cu_swap", "r_home", "r_swap", "gauss_cu_home",
                          "gauss_cw_home", "gauss_pred_cu_swap", "gauss_pred_cw_swap", "ceiling_bound",
                          "ceiling_gauss", "rel_x_bank2"):
                    row[k] = point.get(k, NAN)
                for k in ("cw_home", "cw_swap", "V_home", "V_swap", "theta", "gamma", "rho", "pred_cw_swap",
                          "gap_cw", "gap_theta"):
                    row[f"{k}_lo"], row[f"{k}_hi"] = interval(dt[k])
                row["R_V_lo"], row["R_V_hi"] = row["theta_lo"], row["theta_hi"]
                row["p_gap_task"] = p_two_sided(dt["gap_cw"])
                # the specification test in product form: defined whatever the strength of the home signal
                vq = _twoway(cs, f, "spec_Q", T, codes) if T["N_c"] > 0 else {"V": NAN, "V_task": NAN}
                row["se2_spec_Q"] = math.sqrt(vq["V"]) if vq["V"] > 0 else NAN
                row["spec_z"] = point["spec_Q"] / row["se2_spec_Q"] if math.isfinite(row["se2_spec_Q"]) else NAN
                row["p_spec_2way"] = _normal_p(point["spec_Q"], row["se2_spec_Q"])
                # Fieller sets (two-way variance) for the two ratios
                th = theta_canonical(cs, f, T)          # the headline's own theta, interval and status
                row["theta_fieller_lo"], row["theta_fieller_hi"], row["theta_fieller"] = th["lo"], th["hi"], th["interval"]
                row["theta_status_headline"] = th["status"]     # THE flag (msr.metrics.home_signal_flag)
                for k in ("p_home", "p_drop", "p_md", "p_ni"):
                    row[f"theta_{k}"] = th.get(k, NAN)
                lo, hi, kind = ratio_interval(cs, f, "gamma", T)
                row["gamma_fieller_lo"], row["gamma_fieller_hi"], row["gamma_fieller"] = lo, hi, kind
                ok_lin = T["C_oo"] > 0 and T["V_o"] != 0 and T["W_n"] > 0
                for stat in ("gap_cw", "gamma", "theta"):
                    v = _twoway(cs, f, stat, T, codes) if ok_lin else {"V": NAN, "V_task": NAN, "V_item": NAN}
                    se = math.sqrt(v["V"]) if v["V"] > 0 else NAN
                    row[f"se2_{stat}"] = se
                    row[f"{stat}_lo2"] = point[stat] - Z95 * se if math.isfinite(se) else NAN
                    row[f"{stat}_hi2"] = point[stat] + Z95 * se if math.isfinite(se) else NAN
                    if stat == "gap_cw":
                        row["se_task_lin_gap_cw"] = math.sqrt(v["V_task"]) if v["V_task"] > 0 else NAN
                        row["item_share_var_gap_cw"] = (1.0 - v["V_task"] / v["V"]) if v["V"] > 0 else NAN
                row["se2_R_V"] = row["se2_theta"]
                row["p_gap_2way"] = _normal_p(point["gap_cw"], row["se2_gap_cw"])
                row["covered_task"] = bool(row["gap_cw_lo"] <= 0 <= row["gap_cw_hi"]) if math.isfinite(row["gap_cw_lo"]) else ""
                row["covered_2way"] = bool(row["gap_cw_lo2"] <= 0 <= row["gap_cw_hi2"]) if math.isfinite(row["gap_cw_lo2"]) else ""
                # definedness, decided on the owner's calibration tasks (no estimate uses them)
                zt, zg = calib_z(cs, f"V:{f}"), calib_z(cs, "C")
                row["z_cal_theta"], row["z_cal_gamma"] = zt, zg
                # theta's status is THE home-signal flag (msr.metrics.home_signal_flag, Part 2.4: the owner's
                # calibration tasks, z >= 2); gamma uses the same z rule on the cross-session product there
                row["ratio_status"] = row["theta_status_headline"]
                row["theta_status"] = row["theta_status_headline"]
                row["theta_status_calibration"] = row["theta_status_headline"]
                row["gamma_status"] = ("not estimable: the old model needs two home sessions" if T["N_c"] == 0
                                       else "defined" if (math.isfinite(zg) and zg >= CAL_MIN_Z)
                                       else "undefined: old-model signal too weak on the calibration tasks")
                for vname in ("reader1", "owner1"):      # noise dials (the confound figure)
                    if all(vname in c.variants for c in cs):
                        vt = _stats_row(_sum(cs, f, vname))
                        row[f"R_{vname}"], row[f"spread_ratio_{vname}"] = vt["R"], vt["spread_ratio"]
                        row[f"R_V_{vname}"], row[f"gamma_{vname}"] = vt["theta"], vt["gamma"]
                    else:
                        for k in ("R", "spread_ratio", "R_V", "gamma"):
                            row[f"{k}_{vname}"] = NAN
                sn = [c.beta_sn for c in cs if c.beta_sn is not None]     # Result 6, illustrative
                if sn:
                    sn = np.concatenate(sn)
                    c_hat = beta_binomial_c(sn[:, 0], sn[:, 1])
                    n_med = float(np.median(sn[sn[:, 1] >= 1, 1])) if (sn[:, 1] >= 1).any() else NAN
                else:
                    c_hat, n_med = NAN, NAN
                rr = point.get("rho", NAN)
                row["c_bank"], row["visits_median"] = c_hat, n_med
                ok6 = all(math.isfinite(v) for v in (c_hat, rr, n_med))
                row["k_breakeven"] = float(break_even_k(n_med, rr, c_hat, c_hat)) if ok6 else NAN
                row["k_breakeven_inf"] = (float(break_even_k_inf(rr, c_hat))
                                          if (math.isfinite(c_hat) and math.isfinite(rr)) else NAN)
                if truth:
                    for k in ("true_gamma", "true_rho", "true_theta", "true_R_V", "true_gap_RV", "true_ceiling",
                              "true_V_home", "true_V_swap"):
                        row[k] = point.get(k, NAN)
                    for sfx in ("", "2"):
                        lo, hi = row[f"gamma_lo{sfx}"], row[f"gamma_hi{sfx}"]
                        row[f"true_gamma_in_ci{sfx}"] = bool(lo <= row["true_gamma"] <= hi) if math.isfinite(lo) else ""
                rows.append(row)
    summary = summarise(design, rows, store, truth, codes)
    out_dir.mkdir(parents=True, exist_ok=True)
    _write_csv(out_dir / "decomp_pairs.csv", rows)
    _write_csv(out_dir / "decomp_summary.csv", summary)
    figs = make_figures_from_rows(design, rows, summary, fig_dir) if make_figures else []
    printer(f"decomposition: {len(rows)} pair rows, {len(summary)} summary rows -> {out_dir}")
    return {"rows": rows, "summary": summary, "figures": figs, "design": design}


# ===========================================================================
# Summary across pairs
# ===========================================================================


def _ols(x: np.ndarray, y: np.ndarray) -> tuple:
    k = np.isfinite(x) & np.isfinite(y)
    x, y = x[k], y[k]
    if x.size < 3 or np.var(x) == 0:
        return NAN, NAN, NAN
    b = np.cov(x, y, ddof=1)[0, 1] / np.var(x, ddof=1)
    a = y.mean() - b * x.mean()
    resid = y - a - b * x
    r2 = 1.0 - resid.var() / y.var() if y.var() > 0 else NAN
    return float(b), float(a), float(r2)


def _mae(a, b) -> float:
    a, b = np.asarray(a, dtype=float), np.asarray(b, dtype=float)
    k = np.isfinite(a) & np.isfinite(b)
    return float(np.mean(np.abs(a[k] - b[k]))) if k.any() else NAN


def permutation_p(models: list, pairs: list, measured: dict, predicted: dict, max_perm: int = 50000,
                  seed: int = 0) -> tuple:
    """Model-label permutation test of the decomposition's specificity (respects shared models): the
    statistic is the mean absolute error between measured and predicted swap concordance; the
    prediction of pair (s, t) is replaced by that of (pi(s), pi(t)) for every relabelling pi of the
    models (all of them when n! <= max_perm, otherwise a seeded sample). p = share of relabellings
    with an error at most the observed one (the identity is one of them)."""
    obs = _mae([measured[p] for p in pairs], [predicted[p] for p in pairs])
    n = len(models)
    if math.factorial(n) <= max_perm:
        perms = itertools.permutations(range(n))
        total = math.factorial(n)
    else:
        rng = np.random.default_rng(seed)
        perms = (tuple(rng.permutation(n)) for _ in range(max_perm))
        total = max_perm
    idx = {m: k for k, m in enumerate(models)}
    hits = 0
    for perm in perms:
        pm = {m: models[perm[idx[m]]] for m in models}
        err = _mae([measured[p] for p in pairs], [predicted.get((pm[p[0]], pm[p[1]]), NAN) for p in pairs])
        if err <= obs + 1e-12:
            hits += 1
    return obs, hits / total, total


def _stack_obs(store: dict, keys: list, stat: str, weights=None, coding: str | None = None) -> tuple:
    """Per-(cell, task) influence values of `stat` stacked over pair rows, with the canonical clusters
    and components (rows share tasks; under the registered coding the rows of DIFFERENT owners share a
    write task's cluster, ruling E1; coding="owner" gives the earlier coding, where only rows of one owner
    share items)."""
    P, Tk, I, Cp = [], [], [], []
    for n, k in enumerate(keys):
        e = store[k]
        w = 1.0 if weights is None else weights[n]
        psi, tk, it, cp = _task_obs(e["cells"], k[0], stat, e["T"], w, coding=coding)
        if len(psi):
            P.append(psi), Tk.append(tk), I.append(it), Cp.append(cp)
    if not P:
        return np.zeros(0), np.zeros(0, dtype=str), np.zeros((0, 1), dtype=str), np.zeros(0, dtype=str)
    return np.concatenate(P), np.concatenate(Tk), np.vstack(I), np.concatenate(Cp)


def _fieller_stack(store: dict, keys: list, a: float, b: float, num: str = "spec_Q", den: str = "spec_D",
                   level: float = 0.95, coding: str | None = None) -> tuple:
    """Fieller interval for (sum over rows of a statistic) / (sum of another), e.g. the weighted gap
    sum Q / sum 2 C_oo W_swap, inverting the headline's variance (_fieller_union); items coded as
    `coding` (default ITEM_CLUSTER: write task within stream)."""
    pq, tk, it, cp = _stack_obs(store, keys, num, coding=coding)
    pd, _, _, _ = _stack_obs(store, keys, den, coding=coding)
    if len(pq) == 0 or len(pq) != len(pd):
        return NAN, NAN, "not computable"
    return _fieller_union(a, b, np.column_stack([pq, pd]), tk, it, cp, level)


def _twoway_mean(store: dict, keys: list, stat: str, codes=None, weights=None, coding: str | None = None) -> float:
    """SE of a weighted sum over pair rows of a statistic with the headline's variance (rows share
    tasks; rows share write tasks across owners under the registered coding, ruling E1; `coding`
    default ITEM_CLUSTER)."""
    w = [1.0 / len(keys)] * len(keys) if weights is None else weights
    psi, tk, it, cp = _stack_obs(store, keys, stat, w, coding=coding)
    if len(psi) == 0:
        return NAN
    v = _cluster_var(psi, tk, it, cp)
    return math.sqrt(v["V"]) if v["V"] > 0 else NAN


EQ_MARGIN = 0.02           # equivalence margin of the decomposition gap in Cw units (family T, PREREGISTRATION 11.2.4)
Z90 = 1.6448536269514722


def _tost_p(est: float, se: float, margin: float) -> float:
    """Two one-sided tests of |mean| < margin with a normal SE: the larger of the two p-values."""
    if not (math.isfinite(est) and math.isfinite(se) and se > 0):
        return NAN
    phi = lambda z: 0.5 * math.erfc(-z / math.sqrt(2.0))
    return float(max(1.0 - phi((est + margin) / se), 1.0 - phi((margin - est) / se)))


def _pooled_rv_diff_se(store: dict, f: str, h: str, pairs: list, lev: str, codes=None,
                       coding: str | None = None) -> float:
    """SE of pooled theta(f) - pooled theta(h) over the same swaps (Result 8): per-task influence values
    (v_swap - theta v_home) / sum V_home per family, differenced task by task (same cells, same tasks),
    with the headline's variance; items coded as `coding` (default ITEM_CLUSTER: write task within
    stream, so the swaps of different owners share a write task's cluster)."""
    def infl(fam):
        To = sum(store[(fam, p[0], p[1], lev)]["T"]["V_o"] for p in pairs)
        Tn = sum(store[(fam, p[0], p[1], lev)]["T"]["V_n"] for p in pairs)
        if To == 0:
            return None
        rv = Tn / To
        out, tk, it, cp = [], [], [], []
        for p in pairs:
            for c in store[(fam, p[0], p[1], lev)]["cells"]:
                ar = c.arrays(fam)
                v = ((ar["V_n"] - rv * ar["V_o"]) / To).sum(-1)
                out.append(v - v.mean()), tk.append(c.tkey_pooled), it.append(_item_keys(c, coding))
                cp.append(np.full(len(v), f"{c.owner}|{c.reader}|{c.stream}|{c.order}"))
        return np.concatenate(out), np.concatenate(tk), np.vstack(it), np.concatenate(cp)
    a_f, a_h = infl(f), infl(h)
    if a_f is None or a_h is None:
        return NAN
    v = _cluster_var(a_f[0] - a_h[0], a_f[1], a_f[2], a_f[3])
    return math.sqrt(v["V"]) if v["V"] > 0 else NAN


def summarise(design, rows: list, store: dict, truth: bool, codes: _Codes | None = None) -> list:
    """Rows of decomp_summary.csv (long format: family, level, group, metric, value, lo, hi, p, n, detail).
    Every pooled interval and test clusters items by write task within stream (ITEM_CLUSTER, ruling E1).
    The rows that enter family T (headline family, level 'all': T1-diff and T1-eq of the three strata; T2
    of each other usefulness family) also carry the sensitivity columns se (the SE behind p, registered
    coding), se_owner_coding (the same SE with the earlier owner coding) and p_raw_owner_coding (the
    unadjusted p with that SE); for T1-eq both SEs are those of the binding one-sided statistic."""
    codes = codes or _Codes()
    out = []

    def add(f, lev, grp, metric, value, lo=NAN, hi=NAN, p=NAN, n="", detail="", **extra):
        out.append({"family": f, "level": lev, "group": grp, "metric": metric, "value": value, "lo": lo,
                    "hi": hi, "p": p, "n": n, "detail": detail, **extra})

    groups = ("all_swaps", "same_maker", "cross", "upgrade", "downgrade", "home")
    fams = sorted({r["family"] for r in rows}, key=lambda f: (f != design.headline, f))
    levels = sorted({r["level"] for r in rows}, key=lambda l: (l != "all", l))
    for f in fams:
        for lev in levels:
            R = {(r["owner"], r["reader"]): r for r in rows if r["family"] == f and r["level"] == lev}
            for g in groups:
                pairs = [p for p in design.swaps(g) if p in R]
                if not pairs:
                    continue
                n = len(pairs)
                keys = [(f, p[0], p[1], lev) for p in pairs]
                meas = np.array([R[p]["cw_swap"] for p in pairs])
                pred = np.array([R[p]["pred_cw_swap"] for p in pairs])
                home = np.array([R[p]["cw_home"] for p in pairs])
                gam = np.array([R[p]["gamma"] for p in pairs])
                rho = np.array([R[p]["rho"] for p in pairs])
                gap = meas - pred
                mg = float(np.nanmean(gap))
                dd = np.nanmean(np.array([store[k]["draws"]["gap_cw"] for k in keys]), axis=0)
                lo, hi = interval(dd)
                add(f, lev, g, "mean_gap_cw_task", mg, lo, hi, p_two_sided(dd), n,
                    "mean over pairs of measured - predicted Cw_swap; joint task bootstrap")
                se = _twoway_mean(store, keys, "gap_cw", codes)
                add(f, lev, g, "mean_gap_cw_2way", mg, mg - Z95 * se, mg + Z95 * se, _normal_p(mg, se), n,
                    "same, two-way (task and item) linearised SE")
                add(f, lev, g, f"tost_gap_cw_margin_{EQ_MARGIN:g}", mg, mg - Z90 * se, mg + Z90 * se,
                    _tost_p(mg, se, EQ_MARGIN), n,
                    "equivalence of the mean gap within +-margin (90% two-way interval; p = max of the one-sided p); secondary")
                # the specification test of the stratum (family T, T1): sum of Q over the swaps, two-way SE;
                # no ratio is formed, so it needs no definedness rule. Its point value is the
                # denominator-weighted mean gap sum Q / sum (2 C_oo W_swap), in Cw units.
                Qs = np.array([store[k]["T"]["V_n"] * store[k]["T"]["C_oo"] - store[k]["T"]["C_on"] * store[k]["T"]["V_o"]
                               for k in keys])
                Ds = np.array([2.0 * store[k]["T"]["C_oo"] * store[k]["T"]["W_n"] for k in keys])
                okq = [k for k in keys if store[k]["T"]["N_c"] > 0]
                if okq and Ds.sum() > 0:
                    ones = [1.0] * len(okq)
                    # a family T member (11.2.4): also the SEs with the earlier owner coding (a sensitivity)
                    sens = f == design.headline and lev == "all" and g in T_STRATA
                    seq = _twoway_mean(store, okq, "spec_Q", codes, weights=ones)
                    qsum, dsum = float(Qs.sum()), float(Ds.sum())
                    lo95, hi95, _ = _fieller_stack(store, okq, qsum, dsum, level=0.95)
                    lo90, hi90, _ = _fieller_stack(store, okq, qsum, dsum, level=0.90)
                    extra = {}
                    if sens:
                        seq_o = _twoway_mean(store, okq, "spec_Q", codes, weights=ones, coding="owner")
                        extra = {"se": seq, "se_owner_coding": seq_o, "p_raw_owner_coding": _normal_p(qsum, seq_o)}
                    add(f, lev, g, "spec_gap_cw_2way", float(Qs.sum() / Ds.sum()), lo95, hi95,
                        _normal_p(float(Qs.sum()), seq), n,
                        "linear-transfer specification test (T1-diff): sum_k (V_swap C_oo - C_on V_home), two-way SE; "
                        "value = sum Q / sum (2 C_oo W_swap) (denominator-weighted mean gap in Cw)", **extra)
                    # T1-eq: |gap| < margin by two one-sided tests on Q -/+ margin D (Fieller form: no division)
                    phi = lambda z: 0.5 * math.erfc(-z / math.sqrt(2.0))
                    hi_stat, lo_stat = float(Qs.sum() - EQ_MARGIN * Ds.sum()), float(Qs.sum() + EQ_MARGIN * Ds.sum())

                    def tost(coding=None):
                        se_hi = _twoway_mean(store, okq, "spec_eq_hi", codes, weights=ones, coding=coding)
                        se_lo = _twoway_mean(store, okq, "spec_eq_lo", codes, weights=ones, coding=coding)
                        p_hi = phi(hi_stat / se_hi) if se_hi > 0 else NAN        # H0 gap >= margin
                        p_lo = 1.0 - phi(lo_stat / se_lo) if se_lo > 0 else NAN  # H0 gap <= -margin
                        return max(p_hi, p_lo), (se_hi if p_hi >= p_lo else se_lo)   # p, SE of the binding side

                    p_eq, se_eq = tost()
                    extra = {}
                    if sens:
                        p_eq_o, se_eq_o = tost("owner")
                        extra = {"se": se_eq, "se_owner_coding": se_eq_o, "p_raw_owner_coding": p_eq_o}
                    add(f, lev, g, f"spec_tost_cw_margin_{EQ_MARGIN:g}", float(Qs.sum() / Ds.sum()), lo90, hi90,
                        p=p_eq, n=n,
                        detail="T1-eq: equivalence of the weighted gap within +-margin, p = max of the two one-sided "
                               "p-values of Q -/+ margin D (two-way SE); lo/hi = the 90% Fieller interval of the gap",
                        **extra)
                Vo = np.array([R[p]["V_home"] for p in pairs])
                Vn = np.array([R[p]["V_swap"] for p in pairs])
                dts = [store[k]["draws"] for k in keys]
                if Vo.sum() != 0:
                    pooled = Vn.sum() / Vo.sum()
                    pooled_pred = float(np.nansum(gam * Vo) / Vo.sum())
                    dV = np.sum([d["V_home"] for d in dts], 0)
                    dpool = np.sum([d["V_swap"] for d in dts], 0) / dV
                    dpred = np.sum([d["gamma"] * d["V_home"] for d in dts], 0) / dV
                    lo, hi = interval(dpool)
                    add(f, lev, g, "pooled_theta", pooled, lo, hi, n=n, detail="sum V_swap / sum V_home over pairs")
                    lo, hi = interval(dpred)
                    add(f, lev, g, "pooled_pred_theta", pooled_pred, lo, hi, n=n, detail="sum gamma_hat V_home / sum V_home")
                    lo, hi = interval(dpool - dpred)
                    add(f, lev, g, "pooled_gap_theta", pooled - pooled_pred, lo, hi, p_two_sided(dpool - dpred), n)
                b, a, r2 = _ols(pred - 0.5, meas - 0.5)
                add(f, lev, g, "calib_slope", b, n=n,
                    detail="OLS of Cw_swap-0.5 on predicted-0.5 over pairs; attenuated by noise in the prediction")
                add(f, lev, g, "calib_intercept", a, n=n)
                add(f, lev, g, "calib_r2", r2, n=n)
                add(f, lev, g, "mae_decomp", _mae(meas, pred), n=n,
                    detail="mean |Cw_swap - (1/2 + gamma_hat V_home / (2 W_swap))| over the swaps")
                add(f, lev, g, "mae_no_change", _mae(meas, home), n=n, detail="predict Cw_swap = Cw_home")
                add(f, lev, g, "mae_gamma_only", _mae(meas, 0.5 + gam * (home - 0.5)), n=n,
                    detail="predict R = gamma_hat (ignores the outcome spreads)")
                add(f, lev, g, "mae_rho_only", _mae(meas, 0.5 + rho * (home - 0.5)), n=n, detail="predict R = rho_hat")
                # the same comparisons draw by draw (joint task bootstrap): is the decomposition any closer
                # than its same-information baselines? (descriptive; review R6 W5)
                dm = [store[k]["draws"] for k in keys]
                Mcw = np.array([d["cw_swap"] for d in dm])
                Mpr = np.array([d["pred_cw_swap"] for d in dm])
                Mho = np.array([d["cw_home"] for d in dm])
                Mga = np.array([d["gamma"] for d in dm])
                Mrh = np.array([d["rho"] for d in dm])
                with np.errstate(invalid="ignore"):
                    e_dec = np.nanmean(np.abs(Mcw - Mpr), 0)
                    base = {"gamma_only": np.nanmean(np.abs(Mcw - (0.5 + Mga * (Mho - 0.5))), 0),
                            "rho_only": np.nanmean(np.abs(Mcw - (0.5 + Mrh * (Mho - 0.5))), 0),
                            "no_change": np.nanmean(np.abs(Mcw - Mho), 0)}
                pt_base = {"gamma_only": _mae(meas, 0.5 + gam * (home - 0.5)), "rho_only": _mae(meas, 0.5 + rho * (home - 0.5)),
                           "no_change": _mae(meas, home)}
                for bname, eb in base.items():
                    dd_ = e_dec - eb
                    lo, hi = interval(dd_)
                    add(f, lev, g, f"mae_decomp_minus_{bname}", _mae(meas, pred) - pt_base[bname], lo, hi,
                        p_two_sided(dd_), n, detail=f"MAE of the decomposition minus MAE of {bname} (< 0 favours the "
                        "decomposition); joint task bootstrap; descriptive")
                for kind in ("task", "2way"):
                    cov = [R[p][f"covered_{kind}"] for p in pairs if R[p][f"covered_{kind}"] != ""]
                    add(f, lev, g, f"coverage_{kind}", float(np.mean(cov)) if cov else NAN, n=len(cov),
                        detail="share of pairs whose 95% interval of the gap contains 0")
                dfd = [p for p in pairs if R[p]["ratio_status"] == "defined" and R[p]["gamma_status"] == "defined"]
                add(f, lev, g, "n_pairs_defined", len(dfd), n=n,
                    detail="theta and gamma defined: owner's signal >= 2 SE on the calibration tasks")
                if dfd:
                    add(f, lev, g, "mae_decomp_defined", _mae([R[p]["cw_swap"] for p in dfd],
                                                           [R[p]["pred_cw_swap"] for p in dfd]), n=len(dfd))
                for k in ("gamma", "gamma_within", "rho", "R", "theta", "R_std", "spread_ratio"):
                    add(f, lev, g, f"mean_{k}", float(np.nanmean([R[p][k] for p in pairs])), n=n,
                        detail=("theta x sqrt(S_owner / S_reader), the retained agreement (a correlation-type measure)"
                                if k == "R_std" else ""))
                if truth:
                    tg = np.array([R[p]["true_gamma"] for p in pairs])
                    add(f, lev, g, "truth_mean_gamma", float(np.nanmean(tg)), n=n)
                    add(f, lev, g, "truth_mean_rho", float(np.nanmean([R[p]["true_rho"] for p in pairs])), n=n)
                    add(f, lev, g, "truth_mae_gamma_hat", _mae(gam, tg), n=n)
                    for sfx, nm in (("", "task"), ("2", "2way")):
                        cin = [R[p][f"true_gamma_in_ci{sfx}"] for p in pairs if R[p][f"true_gamma_in_ci{sfx}"] != ""]
                        add(f, lev, g, f"truth_gamma_coverage_{nm}", float(np.mean(cin)) if cin else NAN, n=len(cin))
                    tgap = np.array([R[p]["true_gap_RV"] for p in pairs])
                    add(f, lev, g, "truth_mean_gap_theta", float(np.nanmean(tgap)), n=n,
                        detail="noise-free theta - gamma on these tasks and items (this bank's L)")
                    add(f, lev, g, "truth_mean_abs_gap_theta", float(np.nanmean(np.abs(tgap))), n=n)
                    add(f, lev, g, "truth_mean_ceiling", float(np.nanmean([R[p]["true_ceiling"] for p in pairs])), n=n)
                if g == "all_swaps":
                    models = list(design.models)
                    _, p_perm, nperm = permutation_p(models, pairs, {p: R[p]["cw_swap"] for p in pairs},
                                                     {p: R[p]["pred_cw_swap"] for p in R if p[0] != p[1]})
                    add(f, lev, g, "perm_p_mae", p_perm, n=nperm, detail="model-label permutation, statistic = MAE")
                    for m in models:
                        keep = [k for k, p in enumerate(pairs) if m not in p]
                        if len(keep) < 2:
                            continue
                        add(f, lev, g, "lomo_mean_gap_cw", float(np.nanmean(gap[keep])), n=len(keep), detail=m)
                        add(f, lev, g, "lomo_mae_decomp", _mae(meas[keep], pred[keep]), n=len(keep), detail=m)
                        bb, aa, _ = _ols(pred[keep] - 0.5, meas[keep] - 0.5)
                        add(f, lev, g, "lomo_calib_slope", bb, n=len(keep), detail=m)
            # Result 7: is R_V the same for every family? (pooled over all swaps, against the headline)
            if f != design.headline:
                H = {(r["owner"], r["reader"]): r for r in rows if r["family"] == design.headline and r["level"] == lev}
                pairs = [p for p in design.swaps("all_swaps") if p in R and p in H]
                if pairs:
                    sf = sum(R[p]["V_home"] for p in pairs)
                    sh = sum(H[p]["V_home"] for p in pairs)
                    if sf != 0 and sh != 0:
                        pf = sum(R[p]["V_swap"] for p in pairs) / sf
                        ph = sum(H[p]["V_swap"] for p in pairs) / sh
                        df_ = [store[(f, p[0], p[1], lev)]["draws"] for p in pairs]
                        dh_ = [store[(design.headline, p[0], p[1], lev)]["draws"] for p in pairs]
                        dd = (np.sum([d["V_swap"] for d in df_], 0) / np.sum([d["V_home"] for d in df_], 0)
                              - np.sum([d["V_swap"] for d in dh_], 0) / np.sum([d["V_home"] for d in dh_], 0))
                        lo, hi = interval(dd)
                        add(f, lev, "all_swaps", "family_pooled_theta_minus_headline", pf - ph, lo, hi, p_two_sided(dd),
                            len(pairs), detail=f"pooled theta of {f} minus {design.headline}; task bootstrap")
                        se = _pooled_rv_diff_se(store, f, design.headline, pairs, lev, codes)
                        extra = {}
                        if lev == "all" and f in T2_FAMILIES:        # a family T member (T2): the sensitivity
                            se_o = _pooled_rv_diff_se(store, f, design.headline, pairs, lev, codes, coding="owner")
                            extra = {"se": se, "se_owner_coding": se_o, "p_raw_owner_coding": _normal_p(pf - ph, se_o)}
                        add(f, lev, "all_swaps", "family_pooled_theta_minus_headline_2way", pf - ph, pf - ph - Z95 * se,
                            pf - ph + Z95 * se, _normal_p(pf - ph, se), len(pairs),
                            detail="same, two-way (task and item) linearised SE", **extra)
    out += family_t(design, out)
    return out


T_STRATA = ("upgrade", "downgrade", "cross")
T2_FAMILIES = ("beta_grade", "tags_self", "credit")     # the usefulness score families other than ema_grade



def family_t(design, summary: list, alpha: float = 0.05) -> list:
    """Family T (PREREGISTRATION 11.2.4): Holm at alpha over SEPARATE members, headline family, both
    streams: T1-diff(g) (the specification test, two-sided) and T1-eq(g) (equivalence within the
    margin) for the three strata, and T2(f) (pooled theta of each other score family minus the
    headline's). No member is a min of two p-values (docs/power/fwer_holm.py, device E-new).
    Every member clusters items by write task within stream (ruling E1); each member row also carries
    the sensitivity columns of its per-group row (se, se_owner_coding, p_raw_owner_coding: the earlier
    owner coding, unadjusted), empty when that row has none."""
    from msr.metrics import holm
    H = design.headline
    S = {(r["family"], r["level"], r["group"], r["metric"]): r for r in summary}
    members = []
    for g in T_STRATA:
        r = S.get((H, "all", g, "spec_gap_cw_2way"))
        if r is not None:
            members.append((f"T1diff_{g}", r["p"], r["value"], r))
        r = S.get((H, "all", g, f"spec_tost_cw_margin_{EQ_MARGIN:g}"))
        if r is not None:
            members.append((f"T1eq_{g}", r["p"], r["value"], r))
    for f in sorted({r["family"] for r in summary if r["family"] != H and r["family"] in T2_FAMILIES}):
        r = S.get((f, "all", "all_swaps", "family_pooled_theta_minus_headline_2way"))
        if r is not None:
            members.append((f"T2_{f}", r["p"], r["value"], r))
    ok = [m for m in members if isinstance(m[1], (int, float)) and math.isfinite(m[1])]
    if not ok:
        return []
    res = holm([m[1] for m in ok], alpha)
    rows = []
    for (name, pv, val, src), adj, rej in zip(ok, res.adjusted, res.reject):
        if name.startswith("T1diff"):
            reading = ("specification rejected" + ("" if abs(val) >= EQ_MARGIN else ", departure within the margin")) if rej \
                else "not rejected"
        elif name.startswith("T1eq"):
            reading = "equivalent within the margin" if rej else "equivalence not shown"
        else:
            reading = "families differ" if rej else "no family difference shown"
        rows.append({"family": H, "level": "all", "group": "family_T", "metric": name, "value": val, "lo": NAN,
                     "hi": NAN, "p": adj, "n": len(ok),
                     "detail": f"raw p {pv:.4g}; Holm-adjusted p in column p; {reading}",
                     "se": src.get("se", NAN), "se_owner_coding": src.get("se_owner_coding", NAN),
                     "p_raw_owner_coding": src.get("p_raw_owner_coding", NAN)})
    # the registered group readings (PREREGISTRATION 11.2.4), one row per group
    rej = {name: r for (name, _, _, _), r in zip(ok, res.reject)}
    for g in T_STRATA:
        if f"T1diff_{g}" not in rej and f"T1eq_{g}" not in rej:
            continue
        r_eq = S.get((H, "all", g, f"spec_tost_cw_margin_{EQ_MARGIN:g}"), {})
        gap = r_eq.get("value", NAN)
        rows.append({"family": H, "level": "all", "group": "family_T", "metric": f"T1_reading_{g}", "value": gap,
                     "lo": r_eq.get("lo", NAN), "hi": r_eq.get("hi", NAN), "p": NAN, "n": len(ok),
                     "detail": group_reading(rej.get(f"T1diff_{g}", False), rej.get(f"T1eq_{g}", False), gap)
                     + "; lo/hi = 90% Fieller interval of the weighted gap"})
    return rows


def group_reading(diff_rejected: bool, eq_rejected: bool, gap: float, margin: float = EQ_MARGIN) -> str:
    """The registered reading of one group (PREREGISTRATION 11.2.4), each test at its own Holm threshold:
    'specification supported' (T1-eq rejects), 'specification fails' (T1-diff rejects and |gap| >= margin),
    'departure within the margin' (T1-diff rejects and |gap| < margin), otherwise 'inconclusive'."""
    if eq_rejected and diff_rejected:
        return "specification supported, with a departure within the margin"
    if eq_rejected:
        return "specification supported"
    if diff_rejected:
        return "specification fails" if (math.isfinite(gap) and abs(gap) >= margin) else "departure within the margin"
    return "inconclusive"


def _fmt(v):
    if isinstance(v, (bool, np.bool_)):
        return "True" if v else "False"
    if isinstance(v, (float, np.floating)):
        if math.isnan(v):
            return ""
        if math.isinf(v):
            return "inf" if v > 0 else "-inf"
        return f"{float(v):.6g}"
    return v


def _write_csv(path: Path, rows: list) -> None:
    cols = []
    for r in rows:
        for k in r:
            if k not in cols:
                cols.append(k)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        for r in rows:
            w.writerow({k: _fmt(r.get(k, "")) for k in cols})


# ===========================================================================
# Figures
# ===========================================================================


def make_figures_from_rows(design, rows: list, summary: list, fig_dir: Path, family: str | None = None) -> list:
    """fig_decomp_predicted_vs_measured and fig_decomp_ratio_vs_noise for the headline family, level 'all'."""
    from msr import figures as FG
    fam = family or design.headline
    mark = FG.MARKS.get(design.kind, "")
    sel = [r for r in rows if r["family"] == fam and r["level"] == "all" and r["owner"] != r["reader"]]
    paths = []
    if not sel:
        return paths
    plt = FG._mpl()

    def style(r):
        g = r["group"] if r["group"] in FG.GROUP_STYLE else "cross"
        if g == "same_other":
            g = "upgrade"
        return FG.GROUP_STYLE[g]

    # ---- predicted vs measured swap concordance
    fig, ax = plt.subplots(figsize=(FG.COLUMN_W, 2.7))
    pts = []
    for r in sel:
        st = style(r)
        x, y = r["pred_cw_swap"], r["cw_swap"]
        if not (math.isfinite(x) and math.isfinite(y)):
            continue
        pts += [x, y]
        ax.plot([r["pred_cw_swap_lo"], r["pred_cw_swap_hi"]], [y, y], color=st["color"], lw=0.6, alpha=0.6)
        ax.plot([x, x], [r["cw_swap_lo"], r["cw_swap_hi"]], color=st["color"], lw=0.6, alpha=0.6)
        ax.plot(x, y, marker=st["marker"], color=st["color"], mfc=st["mfc"], mew=0.8, ms=4.2, ls="none", zorder=3)
    lo_v = min(pts + [0.5]) - 0.07 if pts else 0.4
    hi_v = max(pts + [0.6]) + 0.07 if pts else 0.8
    ax.plot([lo_v, hi_v], [lo_v, hi_v], color="#555555", lw=0.7, ls=(0, (3, 2)), zorder=0)
    ax.axhline(0.5, color="#cccccc", lw=0.5, zorder=0)
    ax.axvline(0.5, color="#cccccc", lw=0.5, zorder=0)
    ax.set_xlim(lo_v, hi_v)
    ax.set_ylim(lo_v, hi_v)
    ax.set_aspect("equal", adjustable="box")
    ax.set_xlabel(r"Predicted $C_w$ after the swap, $\frac{1}{2}+\hat\gamma\,V_{\mathrm{home}}/(2W_{\mathrm{swap}})$")
    ax.set_ylabel(r"Measured $C_w$ after the swap")
    from matplotlib.lines import Line2D
    present = {r["group"] for r in sel}
    handles = []
    for g in ("upgrade", "downgrade", "cross"):
        if g in present or (g == "upgrade" and "same_other" in present):
            st = FG.GROUP_STYLE[g]
            handles.append(Line2D([], [], marker=st["marker"], color=st["color"], mfc=st["mfc"], ls="none", ms=4.2,
                                  label=FG.GROUP_LABEL[g]))
    handles.append(Line2D([], [], color="#555555", lw=0.7, ls=(0, (3, 2)), label="measured = predicted"))
    ax.legend(handles=handles, loc="upper left", fontsize=5.5, handletextpad=0.3)
    get = {s["metric"]: s for s in summary if s["family"] == fam and s["level"] == "all" and s["group"] == "all_swaps"}
    if "mae_decomp" in get:
        txt = (f"mean abs. error {get['mae_decomp']['value']:.3f} (no change: {get['mae_no_change']['value']:.3f})\n"
               f"{len(sel)} ordered swaps; bars: 95% task bootstrap")
        ax.text(0.98, 0.03, txt, transform=ax.transAxes, ha="right", va="bottom", fontsize=5, color="#333333")
    FG._sim_mark(fig, mark)
    paths += FG._save(fig, fig_dir, "fig_decomp_predicted_vs_measured")

    # ---- plain R and R_V against the outcome-spread ratio, as only the number of repeats changes
    use = [r for r in sel if r.get("ratio_status") == "defined"]
    fig, axes = plt.subplots(1, 2, figsize=(FG.COLUMN_W, 1.9), sharey=True, sharex=True)
    allx, ally = [], []
    for ax, (key, title) in zip(axes, (("R", r"plain ratio $R$"), ("R_V", r"retained share $\theta$"))):
        for r in use:
            st = style(r)
            pts = []
            for v, full in (("", True), ("_owner1", False), ("_reader1", False)):
                x = r["spread_ratio" + v] if v else r["spread_ratio"]
                y = r[key + v] if v else r[key]
                if math.isfinite(x) and math.isfinite(y):
                    pts.append((x, y, full))
            pts.sort()
            if len(pts) > 1:
                ax.plot([p[0] for p in pts], [p[1] for p in pts], color=st["color"], lw=0.6, alpha=0.7)
            for x, y, full in pts:
                ax.plot(x, y, marker=st["marker"], color=st["color"], mfc=st["mfc"] if full else "white",
                        mew=0.7, ms=3.8 if full else 2.6, ls="none", zorder=3)
                allx.append(x), ally.append(y)
        ax.set_title(title, fontsize=6.5, pad=2)
        ax.axhline(0.0, color="#cccccc", lw=0.5, zorder=0)
    for ax in axes:
        ax.set_xlabel(r"spread ratio $\bar W_{\mathrm{home}}/\bar W_{\mathrm{swap}}$", fontsize=6)
    axes[0].set_ylabel("ratio")
    if allx:
        axes[0].set_xlim(min(allx) - 0.05, max(allx) + 0.05)
        axes[0].set_ylim(min(ally + [0.0]) - 0.1, max(ally + [1.0]) + 0.1)
    handles = [Line2D([], [], marker="o", color="#333333", mfc="#333333", ls="none", ms=3.8, label="2 repeats each"),
               Line2D([], [], marker="o", color="#333333", mfc="white", ls="none", ms=2.6,
                      label="owner or reader cut to 1 repeat")]
    for g in ("upgrade", "downgrade", "cross"):
        if any(style(r) is FG.GROUP_STYLE[g] for r in use):
            st = FG.GROUP_STYLE[g]
            handles.append(Line2D([], [], marker=st["marker"], color=st["color"], mfc=st["mfc"], ls="none", ms=3.4,
                                  label=FG.GROUP_LABEL[g]))
    fig.tight_layout(w_pad=0.6, rect=(0, 0, 1, 0.84))
    fig.legend(handles=handles, loc="upper center", ncol=3, fontsize=5, handletextpad=0.2,
               bbox_to_anchor=(0.5, 1.0), columnspacing=0.8)
    FG._sim_mark(fig, mark)
    paths += FG._save(fig, fig_dir, "fig_decomp_ratio_vs_noise")
    return paths


# ===========================================================================
# CLI
# ===========================================================================


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="The transfer decomposition on a study's result files.")
    ap.add_argument("--study", default="sim")
    ap.add_argument("--draws", type=int, default=None)
    ap.add_argument("--no-figures", action="store_true")
    a = ap.parse_args(argv)
    run(a.study, draws=a.draws, make_figures=not a.no_figures)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
