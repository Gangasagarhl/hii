"""Two new stages of revision 2 (decision D7): the new model as judge, and relearning on frozen content.

Everyday picture: a new mechanic joins the garage and finds the old mechanic's box of tip cards.
  JUDGE: before using any card, he reads each one (the job and the repair written on it, never whether
  it worked) and says how useful it looks, 1 to 10. Those marks are one more way to order the cards.
  RELEARN: he keeps the cards but throws away all the old marks, and earns his own marks by working
  through the same practice jobs the old mechanic did (same passes, same exploration), card content
  unchanged. That is the most expensive swap-day rule: a whole score phase, paid by the new model.

Both are cached (every answer comes from the answer cache on a re-run), resumable (a unit is saved
only when complete) and work with simulated models (msr/sim.py answers the rating calls).

Files (runs/<study>/...):
  judge/<owner>__<reader>/<stream>/seed<k>/judge.jsonl      one row per owner item: rating 1..scale
  relearn/<owner>__<reader>/<stream>/seed<k>/bank_<family>.json, episodes.jsonl, build_summary.json
Analysis hooks (msr/evaluate.py and msr/analysis.py belong to the statistics worker): `judge` is a
score type and swap-day rule whose scores are the ratings (x = rating; a missing rating is a tie at the
scale's middle); `relearn` is a swap-day rule whose scores are the relearned bank's, ranked exactly as
the owner's own bank would be (same families, same rules); both are scored on the cell's probe table.
"""
from __future__ import annotations

import json
from concurrent.futures import ThreadPoolExecutor

from msr import data as D
from msr import scores as S
from msr.build import (Progress, _summary, load_items, parse_rating, rating_prompt, read_jsonl, run_jobs,
                       score_phase, write_json, write_jsonl)
from msr.study import Study


# ---------------------------------------------------------------------------
# The new model as judge
# ---------------------------------------------------------------------------


def judge_dir(st: Study, owner: str, reader: str, stream: str, seed: int):
    return st.dir / "judge" / f"{owner}__{reader}" / stream / f"seed{seed}"


def judge_done(st: Study, owner: str, reader: str, stream: str, seed: int) -> bool:
    return (judge_dir(st, owner, reader, stream, seed) / "judge.jsonl").exists()


def load_judge(st: Study, owner: str, reader: str, stream: str, seed: int) -> dict:
    """{item_id: rating or None} of one judge cell."""
    return {r["item_id"]: r["rating"] for r in read_jsonl(judge_dir(st, owner, reader, stream, seed) / "judge.jsonl")}


def run_judge_cell(st: Study, llm, owner: str, reader: str, stream: str, seed: int, workers: int,
                   progress: Progress | None = None) -> None:
    """The reader rates every stored item of the owner's bank: one call per item, repeat 0."""
    if judge_done(st, owner, reader, stream, seed):
        return
    items = load_items(st, owner, stream, seed)
    scale = st.judge.scale
    base = {"study": st.name, "stage": "judge", "model": reader, "owner": owner, "reader": reader,
            "stream": stream, "seed": seed, "scale": scale, "repeat": 0}
    ids = list(items)
    jobs = [dict(model=reader, user=rating_prompt(stream, items[i]["text"], scale, "reader"), system=None,
                 repeat=0, max_tokens=st.max_tokens,
                 meta={**base, "task_id": items[i]["task_id"], "item_id": i, "items": [i]}) for i in ids]
    res = run_jobs(llm, jobs, workers, progress)
    write_jsonl(judge_dir(st, owner, reader, stream, seed) / "judge.jsonl",
                [{"item_id": i, "rating": parse_rating(r.answer, scale), "scale": scale, "call_id": r.call_id}
                 for i, r in zip(ids, res)])


def run_judge_stage(st: Study, llm, embeddings: dict | None = None, workers: int = 8, printer=print) -> None:
    if not st.judge.enabled:
        printer("  [judge] switched off in the study file (judge.enabled: false)")
        return
    todo = [(o, r, s, k) for s in st.streams for k in st.seeds for (o, r) in st.judge.cells
            if not judge_done(st, o, r, s, k)]
    if not todo:
        return
    prog = Progress("judge", st.build.n_write * len(todo), printer)
    for o, r, s, k in todo:
        run_judge_cell(st, llm, o, r, s, k, workers, prog)


# ---------------------------------------------------------------------------
# Relearn on frozen content
# ---------------------------------------------------------------------------


def relearn_dir(st: Study, owner: str, reader: str, stream: str, seed: int):
    return st.dir / "relearn" / f"{owner}__{reader}" / stream / f"seed{seed}"


def relearn_done(st: Study, owner: str, reader: str, stream: str, seed: int) -> bool:
    p = relearn_dir(st, owner, reader, stream, seed) / "build_summary.json"
    if not p.exists():
        return False
    try:
        return bool(json.loads(p.read_text(encoding="utf-8")).get("complete"))
    except ValueError:
        return False


def load_relearned(st: Study, owner: str, reader: str, stream: str, seed: int) -> dict:
    """{family: (bank, rule)} of a relearned bank (msr.scores.load_bank)."""
    d = relearn_dir(st, owner, reader, stream, seed)
    return {f: S.load_bank(d / f"bank_{f}.json") for f in st.scores.families}


def run_relearn_cell(st: Study, llm, owner: str, reader: str, stream: str, seed: int, emb: dict, tasks: dict,
                     workers: int = 1, progress: Progress | None = None) -> dict:
    """The reader re-runs the whole score phase on the owner's frozen items: scores start from zero, the
    exploration draws are the owner's bank 1's (same seed), the repeats are fresh (relearn.repeat_offset),
    the credit family's no-memory baseline is the READER's own (its build0 on the same score tasks)."""
    out = relearn_dir(st, owner, reader, stream, seed)
    if relearn_done(st, owner, reader, stream, seed):
        return json.loads((out / "build_summary.json").read_text(encoding="utf-8"))
    items = load_items(st, owner, stream, seed)
    baseline = {}
    if st.build.no_memory_run:
        baseline = {r["task_id"]: float(r["correct"])
                    for r in read_jsonl(st.bank_dir(reader, stream, seed) / "build0.jsonl")}
    base = {"study": st.name, "model": reader, "owner": owner, "reader": reader, "stream": stream, "seed": seed,
            "bank": "relearn"}
    rules, banks, episodes, counts = score_phase(st, llm, reader, stream, seed, items, emb, tasks, baseline,
                                                 seed, st.relearn.repeat_offset, st.relearn.self_tag, base,
                                                 "relearn", "relearn", workers, progress)
    out.mkdir(parents=True, exist_ok=True)
    for f, bank_ in banks.items():
        S.save_bank(out / f"bank_{f}.json", bank_, rules[f],
                    note=f"study {st.name}; relearn: reader {reader} on the frozen items of {owner}; "
                         f"stream {stream}; seed {seed}; family {f}"
                         + ("" if st.relearn.self_tag or f != "tags_self" else "; NO self-tags (relearn.self_tag false)"))
    write_jsonl(out / "episodes.jsonl", episodes)
    summary = _summary(st, reader, stream, seed, "relearn", episodes, items, *counts)
    summary.update(owner=owner, reader=reader, self_tag=st.relearn.self_tag)
    write_json(out / "build_summary.json", summary)
    return summary


def run_relearn_stage(st: Study, llm, embeddings: dict, workers: int = 8, printer=print) -> None:
    """Every relearn cell; several at once (each one is a sequential stream of tasks, like a bank)."""
    if not st.relearn.enabled:
        printer("  [relearn] switched off in the study file (relearn.enabled: false)")
        return
    todo = [(o, r, s, k) for s in st.streams for k in st.seeds for (o, r) in st.relearn.pairs
            if not relearn_done(st, o, r, s, k)]
    if not todo:
        return
    tasks_by_stream = {s: D.task_index(s) for s in st.streams}
    per = st.build.epochs * st.n_score * (1 + (st.build.n_show if st.relearn.self_tag else 0))
    prog = Progress("relearn", per * len(todo), printer)
    inner = max(1, min(workers, st.build.batch))
    with ThreadPoolExecutor(max_workers=max(1, min(workers, len(todo)))) as ex:
        futs = [ex.submit(run_relearn_cell, st, llm, o, r, s, k, embeddings[s], tasks_by_stream[s], inner, prog)
                for o, r, s, k in todo]
        for f in futs:
            f.result()
