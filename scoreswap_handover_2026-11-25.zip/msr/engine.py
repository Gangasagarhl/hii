"""Stage C's array engine: every swap-day rule, on every random draw at once, with numpy.

Everyday picture: Stage C asks the same small question hundreds of thousands of times:
"with these scores on the tips, which tip would be shown first on each probe job, and how
did that tip do?" The old code answered it one bank at a time with Python dicts. This file
turns one owner's bank into a few arrays (one number per tip) and one reader's probe table
into arrays (task x candidate x repeat), and answers the question for 200 random draws in
one go. Nothing here reads or writes files; msr/evaluate.py drives it.

The rules are exactly those of prediction/PREREGISTRATION.md (Part 0.4 for the families,
2.2 Cw, 2.6 the arms, 2.7 first-shown success, 2.8 log and Brier scores, 2.9 top-1/top-2).
Every arithmetic step copies the dict code in msr/scores.py and msr/arms.py in the same
order, so the two agree to the last bit wherever no sum is re-ordered;
tests/test_engine_reference.py checks that they agree on every arm.

Shapes: E evaluation tasks, C candidates per task (4), R repeats, N items in the bank,
B a batch of banks (random draws or permutations).
"""
from __future__ import annotations

import math
from itertools import combinations

import numpy as np

from msr import scores as S

TIE = S.SCORE_TIE_TOL
NAN = float("nan")

#: The four rule kinds behind the five families (msr.build.make_rules).
KINDS = ("value", "counter", "credit", "visits")


def kind_of(rule) -> str:
    if isinstance(rule, S.ValueScore):
        return "value"
    if isinstance(rule, S.CounterScore):
        return "counter"
    if isinstance(rule, S.CreditScore):
        return "credit"
    if isinstance(rule, S.VisitScore):
        return "visits"
    raise ValueError(f"unknown rule {rule!r}")


# ---------------------------------------------------------------------------
# One family of one bank, as arrays over the items (sorted ids)
# ---------------------------------------------------------------------------


_FIELDS = {"value": (("q", "q", None), ("n", "visits", 0), ("s", "successes", 0), ("f", "failures", 0)),
           "counter": (("h", "helpful", 0), ("g", "harmful", 0), ("v", "visits", 0)),
           "credit": (("c", "credit", 0.0), ("n", "visits", 0)),
           "visits": (("n", "visits", 0),)}


class Fam:
    """The arrays of one score family of one bank.

    A: {field: array (N,)}: value q, n (visits), s, f; counter h, g, v (visits);
    credit c, n; visits n. `x` is the ranking score (Part 0.4), `u0` the normalised
    score used in the mix, `p0` the predicted success (None for visits), with r0 the
    owner's no-memory success (credit). For the power prior: the pseudo-counts and the
    Beta prior fitted to the bank; for recal: the standardised score x' and whether its
    slope applies (False when the standardising sd over the visited items is 0: the
    recalibration then fits the level only, pre-registration 2.6)."""

    def __init__(self, name: str, rule, bank: dict, items: list, r0: float):
        self.name, self.rule, self.kind = name, rule, kind_of(rule)
        self.items = list(items)
        self.N = len(items)
        self.r0 = float(r0)
        self.alpha = float(getattr(rule, "alpha", 0.3))
        self.q0 = float(getattr(rule, "q0", 0.5))
        self.ranking = getattr(rule, "ranking", "smoothed")
        self.A = {}
        for key, rec_key, default in _FIELDS[self.kind]:
            if default is None:
                self.A[key] = np.array([float(bank[i][rec_key]) for i in items], dtype=float)
            else:
                self.A[key] = np.array([float(bank[i].get(rec_key, default)) for i in items], dtype=float)
        self.x = x_of(self.kind, self.A, self.ranking)
        self.has_p = self.kind != "visits"
        self.has_counts = self.kind in ("value", "counter")
        self.prior = None
        self.s_ps = self.f_ps = None
        if self.has_counts:
            self.prior = S.fit_beta_prior(bank, rule)
            if self.kind == "value":
                n, q = self.A["n"], self.A["q"]
                self.s_ps, self.f_ps = q * n, (1.0 - q) * n
            else:
                self.s_ps, self.f_ps = self.A["h"].copy(), self.A["g"].copy()
        self.xprime = None
        self.slope_ok = True
        if self.has_p:
            xp, self.slope_ok = S.standardise(bank, rule, self.prior)
            self.xprime = np.array([xp[i] for i in items], dtype=float)

    def start(self, shape=()) -> dict:
        """Every item at the start value (the `wipe` state), arrays of `shape` + (N,)."""
        shp = tuple(shape) + (self.N,)
        out = {k: np.zeros(shp) for k in self.A}
        if self.kind == "value":
            out["q"][...] = self.q0
        return out

    def batch(self, B: int, A: dict | None = None) -> dict:
        """B independent copies of a state (default: the owner's), shape (B, N)."""
        A = self.A if A is None else A
        return {k: np.repeat(v[None, :], B, axis=0) for k, v in A.items()}


def x_of(kind: str, A: dict, ranking: str = "smoothed") -> np.ndarray:
    """The ranking score x (Part 0.4; the same arithmetic as rule.score)."""
    if kind == "value":
        return A["q"].astype(float)
    if kind == "counter":
        if ranking == "net":
            return A["h"] - A["g"]
        return (A["h"] + 1.0) / (A["h"] + A["g"] + 2.0)
    if kind == "credit":
        return A["c"].astype(float)
    return A["n"].astype(float)


def u_of(kind: str, A: dict) -> np.ndarray:
    """The normalised score u in [0, 1] used in the mix (the same arithmetic as
    rule.normalised / normalised_scores)."""
    if kind == "value":
        return np.minimum(1.0, np.maximum(0.0, A["q"]))
    if kind == "counter":
        return (A["h"] + 1.0) / (A["h"] + A["g"] + 2.0)
    if kind == "credit":
        return np.minimum(1.0, np.maximum(0.0, (A["c"] + 1.0) / 2.0))
    n = A["n"]
    mx = n.max(axis=-1, keepdims=True) if n.size else np.zeros(n.shape[:-1] + (1,))
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(mx > 0, n / np.where(mx > 0, mx, 1.0), 0.0)


def p_of(kind: str, A: dict, r0: float):
    """The predicted success p before clipping (Part 0.4), or None (visits)."""
    if kind == "value":
        return A["q"].astype(float)
    if kind == "counter":
        return (A["h"] + 1.0) / (A["h"] + A["g"] + 2.0)
    if kind == "credit":
        return float(r0) + A["c"]
    return None


def discount(fam: Fam, lam: float) -> dict:
    """fixed_lam (Part 2.6): q' = q0 + lam (q - q0); counts and c multiplied by lam."""
    A = fam.A
    if fam.kind == "value":
        return {"q": fam.q0 + lam * (A["q"] - fam.q0), "n": lam * A["n"], "s": lam * A["s"], "f": lam * A["f"]}
    return {k: lam * v for k, v in A.items()}


def permute(fam: Fam, perms: np.ndarray) -> dict:
    """shuffled: item i takes the record of item perm[i]; perms (B, N) -> state (B, N)."""
    return {k: v[perms] for k, v in fam.A.items()}


def fold(fam: Fam, A: dict, ci: np.ndarray, cy: np.ndarray, cb: np.ndarray) -> dict:
    """Add fresh outcomes with the family's own update, check by check in the order
    drawn (pooled, fresh, retest). A: state (B, N), changed in place and returned;
    ci (B, m) item indices, cy (B, m) outcomes 0/1, cb (B, m) no-memory baselines.
    The same arithmetic as rule.update (value: q + alpha (r - q); counter: success =
    helpful, failure = harmful; credit: c + ((y - b) - c) / n; visits: n + 1)."""
    B, m = ci.shape
    rows = np.arange(B)
    k = fam.kind
    for j in range(m):
        it = ci[:, j]
        y = cy[:, j]
        if k == "value":
            q = A["q"][rows, it]
            A["q"][rows, it] = q + fam.alpha * (y - q)
            A["n"][rows, it] += 1.0
            A["s"][rows, it] += y
            A["f"][rows, it] += 1.0 - y
        elif k == "counter":
            A["h"][rows, it] += y
            A["g"][rows, it] += 1.0 - y
            A["v"][rows, it] += 1.0
        elif k == "credit":
            n = A["n"][rows, it] + 1.0
            c = A["c"][rows, it]
            A["c"][rows, it] = c + ((y - cb[:, j]) - c) / n
            A["n"][rows, it] = n
        else:
            A["n"][rows, it] += 1.0
    return A


# ---------------------------------------------------------------------------
# One reader's results on the owner's candidates
# ---------------------------------------------------------------------------


class Table:
    """Results of one reader on the owner's candidates of a list of tasks.

    cand (E, C) item index (-1 = no candidate), rel (E, C) raw relevance, y (E, C, R)
    results 0/1 with NaN for a missing repeat. task_ok (E,) marks tasks kept by the
    missing-cell rule (Part 1.6); a dropped task is NaN in every per-task value.
    ybar = mean over the valid repeats; cmask = candidate with at least one valid repeat."""

    def __init__(self, cand: np.ndarray, rel: np.ndarray, y: np.ndarray, task_ok: np.ndarray | None = None):
        self.has = cand >= 0
        self.cand = np.where(self.has, cand, 0)
        self.rel = np.asarray(rel, dtype=float)
        self.y = np.asarray(y, dtype=float)
        E, C = cand.shape
        self.E, self.C = E, C
        cnt = (~np.isnan(self.y)).sum(-1) if self.y.size else np.zeros((E, C), dtype=int)
        with np.errstate(invalid="ignore", divide="ignore"):
            self.ybar = np.where(cnt > 0, np.nansum(self.y, -1) / np.where(cnt > 0, cnt, 1), NAN) if self.y.size \
                else np.full((E, C), NAN)
        self.cmask = self.has & (cnt > 0)
        anyc = self.cmask.any(1)
        self.best = np.where(anyc, np.max(np.where(self.cmask, self.ybar, -np.inf), axis=1), NAN)
        self.ok = anyc if task_ok is None else (np.asarray(task_ok, dtype=bool) & anyc)
        self._wrel = {}
        n = self.cmask.sum(1, keepdims=True)
        with np.errstate(invalid="ignore", divide="ignore"):
            mu = np.where(self.cmask, self.rel, 0.0).sum(1, keepdims=True) / np.maximum(n, 1)
            sd = np.sqrt(np.where(self.cmask, (self.rel - mu) ** 2, 0.0).sum(1, keepdims=True) / np.maximum(n, 1))
            self.relz = np.where(sd > 0, (self.rel - mu) / np.where(sd > 0, sd, 1.0), 0.0)
        ia, ib = (np.array(v, dtype=int) for v in zip(*combinations(range(C), 2))) if C >= 2 else \
            (np.zeros(0, dtype=int), np.zeros(0, dtype=int))
        self.ia, self.ib = ia, ib

    def wrel(self, w_rel: float) -> np.ndarray:
        if w_rel not in self._wrel:
            self._wrel[w_rel] = w_rel * self.rel
        return self._wrel[w_rel]


def first_shown(T: Table, u: np.ndarray, w_score: float) -> tuple:
    """(fs, regret), each (..., E): the item shown first under scores u ((N,) or (B, N))
    and its mean result (Part 2.7). Mix = (1 - w_score) relevance + w_score u, computed as
    msr.evaluate.FirstShown does; ties to the higher relevance, then to the candidate
    listed first. Dropped tasks are NaN."""
    w_rel = 1.0 - float(w_score)
    w1 = 1.0 - w_rel
    U = u[..., T.cand]
    return _pick(T, T.wrel(w_rel) + w1 * U)


def first_shown_z(T: Table, u: np.ndarray) -> tuple:
    """(fs, regret) under the z-scored mix (Part 8.3.1, exploratory, a sensitivity for
    MemRL's z-normalised mix): 0.5 z(relevance) + 0.5 z(u), with relevance AND score both
    z-scored within each task's candidates (settled 23 Nov 2026): centred on the mean over
    the task's candidates and divided by their population sd; a constant gives 0. Only the
    candidates that count in the task (`T.cmask`) enter the mean and sd. Same tie rule as
    `first_shown`."""
    U = u[..., T.cand]                                      # (..., E, C)
    m = T.cmask
    n = np.maximum(m.sum(-1, keepdims=True), 1)
    with np.errstate(invalid="ignore", divide="ignore"):
        mu = np.where(m, U, 0.0).sum(-1, keepdims=True) / n
        sd = np.sqrt(np.where(m, (U - mu) ** 2, 0.0).sum(-1, keepdims=True) / n)
        uz = np.where(sd > 0, (U - mu) / np.where(sd > 0, sd, 1.0), 0.0)
    return _pick(T, 0.5 * T.relz + 0.5 * uz)


def _pick(T: Table, mix: np.ndarray) -> tuple:
    mix = np.where(T.cmask, mix, -np.inf)
    m = mix.max(-1, keepdims=True)
    c1 = mix == m
    r = np.where(c1, T.rel, -np.inf)
    c2 = c1 & (r == r.max(-1, keepdims=True))
    idx = c2.argmax(-1)
    ybar = np.broadcast_to(T.ybar, mix.shape)
    fs = np.take_along_axis(ybar, idx[..., None], -1)[..., 0]
    fs = np.where(T.ok, fs, NAN)
    return fs, T.best - fs


def log_brier(T: Table, p: np.ndarray, clip: tuple) -> tuple:
    """(log score, Brier score), each (..., E): the mean over the task's candidates of
    ybar log p + (1 - ybar) log (1 - p) and (p - ybar)^2 + ybar (1 - ybar), with p clipped
    to `clip` (Part 2.8)."""
    P = np.minimum(clip[1], np.maximum(clip[0], p))
    lp, l1 = np.log(P), np.log(1.0 - P)
    Pc, Lp, L1 = P[..., T.cand], lp[..., T.cand], l1[..., T.cand]
    Y = T.ybar
    cnt = T.cmask.sum(-1)
    with np.errstate(invalid="ignore", divide="ignore"):
        lg = np.where(T.cmask, Y * Lp + (1.0 - Y) * L1, 0.0).sum(-1) / cnt
        br = np.where(T.cmask, (Pc - Y) ** 2 + Y * (1.0 - Y), 0.0).sum(-1) / cnt
    return np.where(T.ok, lg, NAN), np.where(T.ok, br, NAN)


def conc_parts(T: Table, Sc: np.ndarray, Y: np.ndarray | None = None, mask: np.ndarray | None = None) -> tuple:
    """Per-task parts of the concordance (Part 2.2): (num, den, num_u, den_u), each
    (..., E). Sc (..., E, C) holds the score of every candidate (x[cand] for an item
    score); Y (E, C) the outcomes (default: the table's ybar) and mask the candidates
    that count (default: the table's cmask). Weighted: weight |y_i - y_j| per informative
    pair; unweighted: weight 1. Score ties within 1e-12 earn one half."""
    Y = T.ybar if Y is None else Y
    mask = T.cmask if mask is None else mask
    ia, ib = T.ia, T.ib
    yi, yj = Y[:, ia], Y[:, ib]
    ok = mask[:, ia] & mask[:, ib]
    with np.errstate(invalid="ignore"):
        dy = yi - yj
        inf = ok & (np.abs(dy) > TIE)
        w = np.where(inf, np.abs(dy), 0.0)
        si, sj = Sc[..., ia], Sc[..., ib]
        tie = np.abs(si - sj) <= TIE
        agree = (si > sj) == (yi > yj)
    kap = np.where(tie, 0.5, np.where(agree, 1.0, 0.0))
    num = (w * kap).sum(-1)
    den = np.broadcast_to(w.sum(-1), num.shape)
    num_u = (inf * kap).sum(-1)
    den_u = np.broadcast_to(inf.sum(-1).astype(float), num.shape)
    keep = T.ok
    return (np.where(keep, num, NAN), np.where(keep, den, NAN), np.where(keep, num_u, NAN),
            np.where(keep, den_u, NAN))


def ratio(num: np.ndarray, den: np.ndarray) -> np.ndarray:
    """sum(num) / sum(den) over the last axis, NaN tasks left out; NaN when the weight is 0."""
    n = np.nansum(num, -1)
    d = np.nansum(den, -1)
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(d > 0, n / np.where(d > 0, d, 1.0), NAN)


def top_agreement_tasks(T: Table, x: np.ndarray, k: int) -> tuple:
    """(hits (E,), chances (E,)) of the top-1 / top-2 agreement (Part 2.9) per task: 1 or 0,
    and the chance value; NaN on tasks without an informative pair (or dropped)."""
    X = np.where(T.cmask, x[T.cand], -np.inf)
    Y = np.where(T.cmask, T.ybar, -np.inf)
    n = T.cmask.sum(1)
    top = Y.max(1, keepdims=True)
    best = T.cmask & (Y >= top - TIE)
    nb = best.sum(1)
    judged = T.ok & (n >= 2) & (nb < n)
    hits = np.full(T.E, NAN)
    chances = np.full(T.E, NAN)
    # rank by x, ties to higher relevance, then the candidate listed first
    rel = np.where(T.cmask, T.rel, -np.inf)
    for e in np.flatnonzero(judged):
        order = sorted(range(T.C), key=lambda j: (-X[e, j], -rel[e, j], j))
        order = [j for j in order if T.cmask[e, j]][: min(k, n[e])]
        hits[e] = 1.0 if any(best[e, j] for j in order) else 0.0
        kk = min(k, int(n[e]))
        chances[e] = 1.0 - math.comb(int(n[e] - nb[e]), kk) / math.comb(int(n[e]), kk)
    return hits, chances


def top_agreement(T: Table, x: np.ndarray, k: int) -> tuple:
    """(value, chance, n_tasks) of the top-1 / top-2 agreement (Part 2.9) of item scores
    x (N,) against the table's outcomes; see msr.metrics.top_agreement."""
    hits, chances = top_agreement_tasks(T, x, k)
    ok = ~np.isnan(hits)
    if not ok.any():
        return NAN, NAN, 0
    return float(hits[ok].mean()), float(chances[ok].mean()), int(ok.sum())


def pair_stats(T: Table, x: np.ndarray, thirds: np.ndarray | None = None) -> dict:
    """Per-task parts of the concordance variants of Part 8.2.7 for item scores x (N,):

    tau   (E, 4): within-task pairs concordant, discordant, tied in score only, tied in
          outcome only; Kendall's tau-b pooled over tasks is
          (nc - nd) / sqrt((nc + nd + tx) (nc + nd + ty)).
    ties  (E, 2): informative pairs tied in score, informative pairs (the share of ties).
    noties (E, 2): weighted Cw numerator and weight over pairs NOT tied in score.
    visits_low / visits_mid / visits_high (E, 2): weighted Cw parts over the pairs whose
          less-visited item falls in that third of the bank's visit counts (thirds: (N,)
          0, 1 or 2 per item).
    Dropped tasks are NaN."""
    ia, ib = T.ia, T.ib
    Y = T.ybar
    yi, yj = Y[:, ia], Y[:, ib]
    ok = T.cmask[:, ia] & T.cmask[:, ib]
    xi, xj = x[T.cand[:, ia]], x[T.cand[:, ib]]
    with np.errstate(invalid="ignore"):
        dy = yi - yj
        dx = xi - xj
        ytie = np.abs(dy) <= TIE
        xtie = np.abs(dx) <= TIE
        same = (dx > 0) == (dy > 0)
    inf = ok & ~ytie
    w = np.where(inf, np.abs(dy), 0.0)
    kap = np.where(xtie, 0.5, np.where(same, 1.0, 0.0))
    both = ok & ~xtie & ~ytie
    out = {"tau": np.stack([(both & same).sum(1), (both & ~same).sum(1), (ok & xtie & ~ytie).sum(1),
                            (ok & ~xtie & ytie).sum(1)], axis=1).astype(float),
           "ties": np.stack([(inf & xtie).sum(1), inf.sum(1)], axis=1).astype(float),
           "noties": np.stack([(w * np.where(~xtie & same, 1.0, 0.0)).sum(1), (w * ~xtie).sum(1)], axis=1)}
    if thirds is not None:
        pt = np.minimum(thirds[T.cand[:, ia]], thirds[T.cand[:, ib]])
        for g, name in enumerate(("visits_low", "visits_mid", "visits_high")):
            m = pt == g
            out[name] = np.stack([(w * kap * m).sum(1), (w * m).sum(1)], axis=1)
    for key in out:
        out[key] = np.where(T.ok[:, None], out[key], NAN)
    return out


def tau_b(parts: np.ndarray) -> float:
    """Kendall's tau-b from summed (nc, nd, tx, ty) parts."""
    nc, nd, tx, ty = np.nansum(parts, 0)
    den = math.sqrt((nc + nd + tx) * (nc + nd + ty))
    return (nc - nd) / den if den > 0 else NAN


def split_half_pick(T: Table) -> tuple:
    """(fs, regret) per task of `split_half` (Part 2.6; called `oracle` before the round-1
    revision): pick the candidate with the best result on one repeat, score it on the other,
    both ways, averaged; ties to the more relevant item, then the candidate listed first. Only
    candidates with both repeats count. A one-repeat reference, NOT an upper bound: it picks on
    one noisy repeat, so a rule ranking by many visits can beat it. The in-sample ceiling is
    the arm `ceiling` (msr.evaluate: Table.best)."""
    if T.y.shape[-1] < 2:
        nanv = np.full(T.E, NAN)
        return nanv, nanv
    y0, y1 = T.y[..., 0], T.y[..., 1]
    both = T.has & ~np.isnan(y0) & ~np.isnan(y1)
    vals = []
    for pick, score in ((y0, y1), (y1, y0)):
        key = np.where(both, pick, -np.inf)
        m = key.max(1, keepdims=True)
        c1 = both & (key == m)
        r = np.where(c1, T.rel, -np.inf)
        c2 = c1 & (r == r.max(1, keepdims=True))
        idx = c2.argmax(1)
        vals.append(score[np.arange(T.E), idx])
    per = (vals[0] + vals[1]) / 2.0
    per = np.where(T.ok & both.any(1), per, NAN)
    return per, T.best - per


#: the old name, kept for the reference tests and older callers
oracle = split_half_pick


def split_half(T: Table, Ya: np.ndarray, Yb: np.ndarray) -> float:
    """The split-half noise reference (Part 2.5): 1/2 [Cw(score = Ya, outcome = Yb) +
    Cw(score = Yb, outcome = Ya)] over the candidates that have both halves."""
    mask = T.has & ~np.isnan(Ya) & ~np.isnan(Yb)
    vals = []
    for a, b in ((Ya, Yb), (Yb, Ya)):
        num, den, _, _ = conc_parts(T, a, Y=b, mask=mask)
        vals.append(float(ratio(num, den)))
    vals = [v for v in vals if not math.isnan(v)]
    return float(np.mean(vals)) if vals else NAN


# ---------------------------------------------------------------------------
# The calibrated arms
# ---------------------------------------------------------------------------


def powerprior_lambda(fam: Fam, ci: np.ndarray, cy: np.ndarray, grid, a0: float, b0: float) -> np.ndarray:
    """lam per draw (B,): the grid value with the largest beta-binomial marginal
    likelihood of the checks, ties (within 1e-9) to the SMALLER lam (Part 2.6).
    The likelihood of an item's checks is written as the product of its sequential
    predictive chances, which equals B(a + y, b + m - y) / B(a, b) exactly."""
    B, m = ci.shape
    rows = np.arange(B)
    ys = np.zeros((B, fam.N))
    ms = np.zeros((B, fam.N))
    py = np.empty((B, m))
    pm = np.empty((B, m))
    for j in range(m):
        it = ci[:, j]
        py[:, j] = ys[rows, it]
        pm[:, j] = ms[rows, it]
        ys[rows, it] += cy[:, j]
        ms[rows, it] += 1.0
    g = np.asarray(grid, dtype=float)[:, None, None]
    al = a0 + g * fam.s_ps[ci]
    be = b0 + g * fam.f_ps[ci]
    num = np.where(cy[None] > 0.5, al + py[None], be + (pm - py)[None])
    ll = (np.log(num) - np.log(al + be + pm[None])).sum(-1)          # (G, B)
    best = ll.max(0)
    cand = np.where(ll >= best - 1e-9, g[:, :, 0], np.inf)
    return cand.min(0)


def powerprior_state(fam: Fam, lam: float, a0: float, b0: float) -> dict:
    """The bank of powerprior at weight lam: Beta(a0 + lam s, b0 + lam f) per item,
    written as arms._with_beta writes it (counter: helpful = alpha - 1; value: q = mean)."""
    alpha = a0 + lam * fam.s_ps
    beta = b0 + lam * fam.f_ps
    if fam.kind == "counter":
        return {"h": alpha - 1.0, "g": beta - 1.0, "v": lam * fam.A["v"]}
    return {"q": alpha / (alpha + beta), "n": lam * fam.A["n"], "s": lam * fam.A["s"], "f": lam * fam.A["f"]}


def flat_lambda(fam: Fam, ci: np.ndarray, cy: np.ndarray, grid) -> np.ndarray:
    """powerprior_flat (an extra comparison): Beta(1, 1) base, ties to the smaller lam."""
    return powerprior_lambda(fam, ci, cy, grid, 1.0, 1.0)


def _sigmoid(x: np.ndarray) -> np.ndarray:
    out = np.empty_like(x)
    pos = x >= 0
    out[pos] = 1.0 / (1.0 + np.exp(-x[pos]))
    ex = np.exp(x[~pos])
    out[~pos] = ex / (1.0 + ex)
    return out


def recal_batch(X: np.ndarray, Y: np.ndarray, level_sd: float = 1.0, slope_mean: float = 0.5,
                slope_sd: float = 1.0, max_iter: int = 100, fit_slope: bool = True) -> tuple:
    """(a, b, converged), each (B,): the penalised maximum-likelihood fit of
    p = sigmoid(a + b x') to every draw's checks at once, with a ~ N(0, level_sd) and
    b ~ N(slope_mean, slope_sd) (Part 2.6). Damped Newton steps from (0, slope_mean), as
    arms._fit_logistic takes them one draw at a time. fit_slope=False is the level-only
    fit used when the standardising sd of x' is 0 (Part 2.6): p = sigmoid(a), b is NaN."""
    if not fit_slope:
        a, _b, conv = recal_batch(np.zeros_like(X, dtype=float), Y, level_sd, slope_mean, slope_sd, max_iter)
        return a, np.full(X.shape[0], NAN), conv
    B = X.shape[0]
    a = np.zeros(B)
    b = np.full(B, float(slope_mean))
    v0, v1 = level_sd ** 2, slope_sd ** 2

    def obj(a_, b_, rows):
        eta = a_[:, None] + b_[:, None] * X[rows]
        return (Y[rows] * eta - np.logaddexp(0.0, eta)).sum(1) - a_ ** 2 / (2 * v0) - (b_ - slope_mean) ** 2 / (2 * v1)

    allr = np.arange(B)
    o = obj(a, b, allr)
    active = np.ones(B, dtype=bool)
    conv = np.zeros(B, dtype=bool)
    if X.shape[1] == 0:
        return a, b, np.ones(B, dtype=bool)
    for _ in range(max_iter):
        rows = np.flatnonzero(active)
        if len(rows) == 0:
            break
        Xr, Yr = X[rows], Y[rows]
        ar, br = a[rows], b[rows]
        eta = ar[:, None] + br[:, None] * Xr
        p = _sigmoid(eta)
        r = Yr - p
        w = p * (1.0 - p)
        ga = r.sum(1) - ar / v0
        gb = (r * Xr).sum(1) - (br - slope_mean) / v1
        haa = -(w.sum(1) + 1.0 / v0)
        hab = -(w * Xr).sum(1)
        hbb = -((w * Xr * Xr).sum(1) + 1.0 / v1)
        det = haa * hbb - hab * hab
        sa = -(hbb * ga - hab * gb) / det
        sb = -(-hab * ga + haa * gb) / det
        t = np.ones(len(rows))
        na, nb = ar + sa, br + sb
        no = obj(na, nb, rows)
        for _h in range(40):
            bad = no < o[rows] - 1e-12
            if not bad.any():
                break
            t[bad] *= 0.5
            na[bad] = ar[bad] + t[bad] * sa[bad]
            nb[bad] = br[bad] + t[bad] * sb[bad]
            no[bad] = obj(na[bad], nb[bad], rows[bad])
        a[rows], b[rows], o[rows] = na, nb, no
        done = np.maximum(np.abs(t * sa), np.abs(t * sb)) < 1e-10
        conv[rows[done]] = True
        active[rows[done]] = False
    fail = ~conv
    a[fail], b[fail] = 0.0, slope_mean
    return a, b, conv


def recal_probs(fam: Fam, a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """p = sigmoid(a + b x') for every draw and item, (B, N); sigmoid(a) when the slope
    term is dropped (fam.slope_ok False)."""
    if not fam.slope_ok:
        return _sigmoid(np.repeat(a[:, None], fam.N, axis=1).astype(float))
    return _sigmoid(a[:, None] + b[:, None] * fam.xprime[None, :])


def audit_keep(x: np.ndarray, items: np.ndarray, ys: np.ndarray, pair_a: np.ndarray, pair_b: np.ndarray,
               pair_draw: np.ndarray, B: int) -> tuple:
    """audit decisions per draw (Part 2.6): Cw of the OLD ranking scores x on the checks,
    pairs within each checked task (weight |y_i - y_j|, score ties 1/2); keep when
    Cw > 0.5 or when no pair is informative. items/ys: the checked cells of all draws in
    one flat list; pair_a/pair_b index two cells of the same task and draw.
    Returns (keep (B,) bool, num (B,), den (B,))."""
    xa, xb = x[items[pair_a]], x[items[pair_b]]
    ya, yb = ys[pair_a], ys[pair_b]
    w = np.abs(ya - yb)
    inf = w > TIE
    kap = np.where(np.abs(xa - xb) <= TIE, 0.5, np.where((xa > xb) == (ya > yb), 1.0, 0.0))
    num = np.bincount(pair_draw, weights=np.where(inf, w * kap, 0.0), minlength=B)
    den = np.bincount(pair_draw, weights=np.where(inf, w, 0.0), minlength=B)
    with np.errstate(invalid="ignore", divide="ignore"):
        keep = (den <= 0) | (num / np.where(den > 0, den, 1.0) > 0.5)
    return keep, num, den
