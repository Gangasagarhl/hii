# ScoreSwap: how to test your own rule

## The story first

A garage keeps a box of repair tips. Each tip has a score: how often it worked. The scores
were earned while one mechanic worked there.

Then a new mechanic arrives. The old one has left for good.

Are the old scores still right for the new mechanic? On the first day, the garage has to decide
what to do with them. It can keep them. It can wipe them and start again. It can trust them
halfway. Or it can try a few tips with the new mechanic first, and then decide.

In our study the mechanic is an AI model, the tips are memory items, and the new mechanic is a
newer (or different) model. We ran every old model's tips with every new model, and wrote down
every result. Those written results are frozen tables. With them you can test your own idea
**without calling any model and without paying anything**.

## Two kinds of entry

1. **A swap-day rule.** It decides the scores on the day the model changes. It may ask for a few
   fresh checks first: "how did the new model do with tip X on test job Y?" You choose how many
   (the budget k: 0, 8, 16, 32, 64, 128 or 256; a pack only offers the budgets its tables can hold,
   `describe` lists them).
2. **A score type.** It is a new way to compute the scores in the first place, from the old
   model's diary of every time a tip was used.

Each entry is **one Python file** (at most 256 KB). It may import Python's standard library,
numpy, scipy and the other installed packages, and `scoreswap` and `msr`. It may not read any
other file, not even one in its own folder.

## Two boards: develop on the public owners, be ranked on owners you have never seen

The old models (the **owners**, whose tips are read) are split into two sides, a whole maker at a
time, by a seeded draw whose rule and seed are in the pack's `manifest.json` ("owner_split"):

- **public owners**: the **development board**. Every bank of a public owner (all task streams
  and stream orders), its diary, its tips' scores and every new model's results with its tips are
  in the public pack. Tune on it as much as you like. `score` and `leaderboard` use it unless you
  are a maintainer. Because everything on it is public, **a development number is never a
  ranking**.
- **private owners**: the **ranked board**. Every bank of a private owner, every new model's
  results with its tips (on the jobs fresh checks are drawn from and on the scored jobs alike) and
  the secret seed of its random checks are kept by the maintainers in a private folder. Nothing
  about a private owner's tips is public: no result, no score, no diary, no text. The public
  manifest holds the sha256 of every private file, so anyone can later check they were fixed in
  advance. To be ranked, submit your entry file (see "Submitting"); the maintainers run it on both
  boards.

The ranked board's cells are every cell whose owner is private, with every new model as the
reader: they hold upgrades, downgrades, swaps to another maker's model and home rows. In the
practice pack (`release/sim`, four simulated models of two makers) the public owners are the two
models of maker a and the private owners the two models of maker b. In the full study each side
gets one closed-weight maker, one open-weight maker and one extension pair.

**What your entry can still carry: everything public.** Here is what that buys on the ranked
board, measured on the practice pack (first-shown success minus `keep`, swaps to another maker's
model, k = 0 unless said; interval: two-way 95 %):

| what the file carries | development board | ranked board |
|---|---|---|
| every public check result of the cells it is run on, used without asking (reviewer R9's A1) | +0.053 [+0.007, +0.098] | 0.000 (it has none for a private bank) |
| the best tip of every scored job of every public cell, memorised (R9's A10) | +0.294 [+0.234, +0.354] | 0.000 |
| what each new model did with each public TIP, pooled per tip ("item transfer") | +0.202 [+0.149, +0.255] | 0.000 |
| the same, pooled across OWNERS: for each candidate, what the same new model did with the public owners' tips written on the same write task, matched by the candidates' relevance values ("owner pooling"; on the development board this includes the cell's own public results) | +0.185 [+0.124, +0.247] | -0.040 [-0.115, +0.035] |
| the same, matched by position (row and slot) | -0.008 [-0.083, +0.067] | -0.009 [-0.081, +0.063] |
| the cells `request(random=k)` will return, predicted from public values (R9's A12, k = 16) | 16 of 16 | not better than chance |
| for scale: the template rule below with 16 honest checks (k = 16) | +0.009 [-0.006, +0.024] | +0.007 [-0.006, +0.021] |

So: a result about a private owner's tip can be learnt only by spending a check. Results carried
for public tips give exactly nothing on the ranked board (the file has none for a private bank).
Positions do not link a private bank to a public one: a bank's tips and jobs reach a call in an
order of their own, drawn from the secret seed on the ranked board.

**But one link cannot be hidden.** Every owner wrote its tips on the same write tasks, and the
candidates of a job are found by the embedding of the write task, so a private bank lists the same
jobs with the same candidate write tasks and the same relevance values as every public bank. An
entry can therefore match a private tip with the public tips written on the same write task, and
use what public results say about them ("owner pooling" above). On the practice pack this loses
(-0.040): its simulated owners write tips whose usefulness is drawn separately for each owner, so
another owner's tip says little about yours. **On real data, where tips written on one task by
different models may behave alike, it may gain.** The maintainers re-measure it on every real pack
before it opens (the test `test_item_transfer_and_owner_pooling_gain_nothing_on_the_ranked_board`
and `tests/scoreswap_r9/make_owner_pool.py`) and print the number on its board. Read a ranked
number as "fresh checks plus public knowledge of the write tasks and the new models". Also public:
a new model's own results with NO tip on every job (they are the same model calls whatever bank is
read), which can help a rule that returns `p` in the log and Brier scores, not in first-shown
success. The manifest lists both ("owner_split" > "exposure").

The **held-out alarm** (maintainers' scoring, below) compares an entry's lead over keep on the two
boards. It flagged A10, the item transfer and owner pooling above; it did not flag A1 on the
practice pack (a gap of 0.038 where 0.046 was allowed). It is a flag, not a proof.

## Install

You need Python 3.10 or newer with numpy, scipy and pyyaml (`pip install numpy scipy pyyaml`).
Run the commands from the folder that holds `scoreswap/` and `msr/`. A laptop is enough: no GPU,
no key, no internet connection.

Tested with Python 3.12.7, numpy 2.5.5 and scipy 1.18.1; maintainers should score with these
versions (an entry may import any installed package, so the versions are part of the result).

**Sealing needs Linux.** Ranked scoring needs Linux on x86_64 with bubblewrap (`bwrap`, which puts
the whole run in a namespace jail) and Landlock (kernel 5.13 or newer); `score --private` refuses
to produce a ranked result without them, and says why. Development scoring runs anywhere: without
the jail it prints a warning; off Linux each call still runs in a fresh process but only a
Python-level guard watches files.

## Get the frozen tables

The practice pack is the folder `release/sim/` in this repository: use it as it is.
(Maintainers make packs from a finished study with
`python -m scoreswap export --study sim --out release/sim`, which also writes the private half,
`release/sim_private/`, and needs the study's runs.)
Open `release/sim/SCHEMA.md` (what every file and column means) and `release/sim/DATASHEET.md`
(how the pack was made, its licences and limits); `croissant.json` describes the files in the
Croissant format.

Text: the pack holds the text of every job and of the public owners' tips wherever the licences
allow it: DDXPlus is CC BY 4.0 and BIRD CC BY-SA 4.0 (a file that holds BIRD text carries
CC BY-SA 4.0), and a tip also holds a model's answer, so its text is released only where that
model's output terms allow it (`licences/`). The practice pack's models are simulated, so all its
public tips have text. A private owner's tips never have text, and a call on the ranked board gets
no text. Each tip also has a fingerprint (sha256) of its text.

To see exactly what your rule will receive, with sample values:

```
python -m scoreswap describe --pack release/sim
```

## Write a swap-day rule

Copy `scoreswap/templates/swap_day_rule_template.py` and change one function:

```python
import numpy as np

KIND = "swap_day_rule"        # these settings must be plain constants
NAME = "my_rule"
DRAW_KEY = "recal"            # optional: share recal_k's seeded random checks (the default)

def rule(bank, candidates, swap, checks):
    u = bank.mix_score["ema_grade"].copy()            # the old scores, one per tip, in [0, 1]
    if checks.budget > 0:
        hits = np.zeros(bank.n)
        tries = np.zeros(bank.n)
        for a in checks.request(random=checks.budget):  # k fresh checks at random
            hits[a.item_index] += a.result              # 1.0 right, 0.0 wrong
            tries[a.item_index] += 1
        u = (2 * u + hits) / (2 + tries)                # the old score counts as two checks
    return {"u": u, "p": u}
```

### When and how often it is called

- Once for every **cell**: every old model (the owner of the tips) with every new model (the
  reader), **including the owner with itself** (`swap.kind == "home"`), in every task stream and
  every stream order, on the board being scored.
- With a budget above 0, once for every **seeded draw** of a cell (200 in the paper's pack), so the
  random checks average out. Each per-job number is the mean over the draws.
- **Every call is a fresh process.** Nothing you store survives to the next call. Names of tips,
  jobs and check cells are **random and new in every call**, and a bank's tips and jobs come in an
  order of their own (fixed for a run, drawn from a secret seed on the ranked board): use positions
  within the call, never names, to match things across lists.

### What it receives

`bank`: the old model's tips. Every per-tip array follows `bank.items`.

| field | what it holds |
|---|---|
| `bank.items` | the tips' names (random in every call); `bank.n` how many; `bank.index[name]` a tip's position |
| `bank.owner`, `bank.owner_maker` | the old model and its maker |
| `bank.stream`, `bank.order` | the task stream and its stream order |
| `bank.families` | the five score types: `ema_grade`, `beta_grade`, `tags_self`, `credit`, `visits` |
| `bank.score[f]` | each tip's ranking score under type `f` |
| `bank.mix_score[f]` | the same squeezed into [0, 1], as the old model's retrieval used it |
| `bank.p[f]` | the chance of success that type implies (`None` for `visits`) |
| `bank.counts[f][field]` | the counts behind each score: `ema_grade`: q, visits, successes, failures; `beta_grade`: helpful (= graded successes), harmful (= failures), visits; `tags_self`: helpful, harmful (the old model's own opinion), visits; `credit`: credit (result with the tip minus without), visits; `visits`: visits |
| `bank.visits` | how often each tip was shown while the scores were earned |
| `bank.showing_probabilities` | per tip, the logged chance it had of being shown, each time it was |
| `bank.no_memory_rate` | the old model's success with no tip at all |
| `bank.text` | each tip's text for a public bank whose licences allow it, else `None` (always `None` on the ranked board) |
| `bank.records(f)`, `bank.rule(f)` | the same in the paper's own format, for its helper functions in `msr` |
| `bank.engine_family(f)` | the paper's ready-made arrays of type `f` (`msr.engine.Fam`: state, fitted prior, standardised score). The scorer builds them once per bank before any call, so using them costs nothing per call; building your own per-bank tables inside `rule` is paid again on every call |

`candidates`: every test and calibration job, each with its 4 best-matching tips.

| field | what it holds |
|---|---|
| `candidates.tasks`, `candidates.T`, `candidates.C` | the jobs' names (random), how many, and 4 |
| `candidates.task_index` | `{job name: its row}`: maps a check cell's job (`CheckCell.task`) to its row here |
| `candidates.roles` | `"calibration"` (fresh checks come only from these) or `"evaluation"` (scored) |
| `candidates.item_index` | T x 4 array: the position in `bank.items` of each candidate (-1 if none) |
| `candidates.items` | the same as names |
| `candidates.relevance` | T x 4 array: how well each candidate matches the job (cosine) |
| `candidates.task_text` | each job's text where the licence allows it, else `None` (always `None` on the ranked board) |

`swap`: what is known before the swap.

| field | what it holds |
|---|---|
| `swap.owner`, `swap.owner_maker` | the old model and its maker |
| `swap.reader`, `swap.reader_maker` | the new model and its maker |
| `swap.kind` | `home`, `same_maker_upgrade`, `same_maker_downgrade`, `same_maker_other` or `cross_maker` |
| `swap.budget` | k, the checks you may use in this call |
| `swap.draw`, `swap.draws` | which seeded draw this is, and how many the pack has |
| `swap.options` | the values given on the command line with `--set name=value` (always strings) |
| `swap.family()` | the score type the rule is measured against for theta: `--set family=...`, else `ema_grade` |
| `swap.settings` | the study's settings: mix weight, families, budgets, draws, seeds |

`checks`: fresh checks, up to the budget.

| field | what it holds |
|---|---|
| `checks.budget`, `checks.used`, `checks.remaining` | the counts (the harness keeps the real count) |
| `checks.cells` | the calibration cells you may check: `CheckCell(id, task, item, position, item_index, max_answers)`; `id` is what you name, `max_answers` is 2 (or 1 if one run is missing) |
| `checks.by_item`, `checks.by_task` | `{tip or job name: [cell ids]}` |
| `checks.request(cells=[ids])` | named cells; a cell named again gives its other stored run |
| `checks.request(random=m)` | m cells drawn at random among the cells not yet answered |
| `checks.request(..., with_no_memory=True)` | also each job's no-tip success of the new model (it costs 2 more model calls per job on a real swap day) |
| answers | `Answer(cell, task, item, item_index, result, answer_number, no_memory)`: `result` 1.0 right or 0.0 wrong; `answer_number` 1 or 2 |
| `checks.rng` | a seeded random generator for your own choices: use it, never the clock |

Random cells always come from the harness's own generator, seeded like the paper's rules: a rule
that asks for k random cells at once gets exactly the cells `recal_k` got, whatever it did before.

### What it returns

- `{"u": u}` or `{"u": u, "p": p}`: one number per tip, in `bank.items` order (a list, an array, or
  a dict `{name: number}`). `u` in [0, 1] ranks the tips: on each job the harness shows the
  candidate with the largest `0.5 u + 0.5 relevance` (ties to the more relevant). `p` in [0, 1] is
  the chance the new model succeeds with the tip (clipped to [0.01, 0.99] when scored).
- or `{"u_cand": U, "p_cand": P}`: T x 4 arrays, one value per job and candidate, when the value
  should depend on the job (see `examples/relevance_gate.py`).

## Write a score type

Copy `scoreswap/templates/score_type_template.py`. `score(log)` is called once per bank, in a fresh
process, and returns one number per tip of `log.items` (higher = more useful; only the order counts).

| field of `log` | per showing, in the order it happened |
|---|---|
| `log.task`, `log.item`, `log.item_index` | the job, and the tip shown (name and position) |
| `log.result` | the old model's graded result with the tip (1.0 or 0.0) |
| `log.tag` | the old model's own opinion of the tip: helpful, harmful, neutral or None |
| `log.no_memory` | the old model's result on the same job with no tip (NaN if none) |
| `log.probability`, `log.explored` | the logged chance the tip had of being shown; picked by exploration or not |
| `log.pass_`, `log.position` | the pass over the jobs and the job's place in it |

Also `log.items`, `log.n`, `log.no_memory_rate` and `log.score_rules`.

## Check it

```
python -m scoreswap check my_rule.py --pack release/sim
```

Every line says PASS or FAIL, and why:

- **sealed**: it ran one fresh process per call, and the line says whether the namespace jail and
  the kernel enforced it.
- **the contract**: shapes, no missing or broken numbers, values in [0, 1], no more checks than
  the budget, no cell asked a third time.
- **order and repeat**: a second run, in another order, gives byte-identical output for every
  call. A rule that depends on earlier calls, the clock, its own unseeded randomness or the random
  names fails here.
- **canary**: the results the harness holds are secretly shuffled; your output must not change by
  a single byte.

`check` runs a few of the pack's draws, picked at random, and tells your rule the pack's number of
draws, exactly as `score` does: a rule cannot tell a check from a score by what it is given. A PASS
says nothing about public data your file may carry; that is what the ranked board is for.

## Score it

```
python -m scoreswap score my_rule.py --pack release/sim --budget 16 --out my_results
```

The results go to `my_results/<name>/k16/` (`--out` defaults to `scores/` in the current folder).
Open `SUMMARY.md`; the bold lines under its title say which board was scored. You will see:

- **First-shown success**: how often the new model got the job right with the tip your rule shows
  first. Higher is better.
- **Regret**: how far that is from the best of the 4 tips. Lower is better.
- **Log score** (only if you return `p`): how good your chances are; closer to 0 is better. The
  "level-corrected" one takes out a common offset, so it judges the order and spread.
- **Theta** (value kept): how much of the old model's ranking skill your order keeps for the new
  model (1 = all, 0 = none), measured against the old model's own `swap.family()` score at home. In
  a home row the new model is the old one, so `keep` scores exactly 1 there. Theta = **retained
  agreement** x **stakes**: retained agreement is how well the old order still fits the new model,
  stakes how much the new model cares which tip it gets. Retained agreement reads "not estimated
  (reader's spread below z = 2)" where the new model's own spread between tips cannot be told from
  zero on the calibration jobs. Theta reads "no home signal" where the old model's score shows no
  ranking skill on its own calibration jobs (less than 2 standard errors above zero): there is
  nothing to keep. That flag is `msr.metrics.home_signal_flag`, the same one rule the paper uses.
- **minus keep, minus wipe, minus recal_16, ...**: your rule against the paper's rules, on the same
  jobs and the same random checks.

Every number comes per pair of models, per task stream, and per kind of swap (the same maker's
newer model, the same maker's older model, another maker's model, and home). Each has two 95%
intervals: **two-way** (jobs and tips both treated as a sample, by leaving out one job, or one tip,
at a time and recomputing: `msr.metrics.robust_variance`, the paper's primary interval; a tip that
comes back in several stream orders counts once) and **task-only** (resampling jobs only: the one
the paper's tables of rules print, so maintainers' numbers on all banks match the paper's tables
digit for digit). Theta's two-way bracket is the union of its two-way and task-only sets, as in
the paper (`msr.metrics.theta_tests`).

Maintainers score with `--private release/sim_private`: both boards, and the **held-out alarm**,
computed on the full runs: your lead over `keep` on the development board (public owners' swaps)
may not exceed your lead on the ranked board (private owners' swaps) by more than 3 standard errors
(and 3 points); the two boards score the same jobs with different owners' tips, so the standard
error comes from one jackknife over both. `--split test` scores the ranked board alone; `--split
all` scores every bank with the paper's seeds (the paper's tables).

## Read the boards

```
python -m scoreswap leaderboard my_entries/ --pack release/sim --out my_boards
```

This re-runs every entry in the folder from the frozen tables, sealed. It writes:

- **Score types**, ranked by the **value after the swap** (how well the score still ranks the tips
  for the new model, with its interval), with theta (value kept), retained agreement and stakes
  beside it and the home concordance beside every number; ranks whose intervals overlap are marked
  "tied". Theta reads "no home signal" where the owner's score is less than 2 standard errors above
  zero on its calibration jobs (`msr.metrics.home_signal_flag`). The registered no-signal controls
  (`visits`, `shuffled`) are listed apart, under "control", and never ranked.
- **Swap-day rules**, one board per budget, ranked by first-shown success for each kind of swap,
  with the difference from keep and its interval (an interval holding 0 means "not distinguishable
  from keep"), regret, theta (or "no home signal") and retained agreement (or "not estimated"), the
  log score and the checks used.

Without the private folder the boards are development boards and say so. With it they show a dev
and a test column per kind of swap (different owners on each), rank on the ranked board and list
each entry's held-out alarm in `entries.json`. The paper's own rules are run on the boards by the
same harness (as trusted code), so their theta and labels are computed exactly as an entry's.
Every board also lists every pair of models of the board it ranks on, and carries the pack version
and the board format.

## How long it takes

On the practice pack (`release/sim`: 4 simulated models, 16 cells, 2 stream orders, 200 draws), on
a laptop with 4 cores (8 threads) shared with other heavy jobs (load average 5 to 11), limited to
two cores:

| command | time | most memory |
|---|---|---|
| `score examples/rank_focus_shrink.py --budget 16 --workers 2` (development board, sealed in the jail, the paper's rules beside it; 3,200 calls) | 38 s | 0.1 GB per process |
| the same with `--private` (maintainers: both boards and the held-out alarm) | 1 min 31 s | 0.1 GB per process |
| `check examples/rank_focus_shrink.py --workers 2` | 11 s | 0.1 GB per process |

On a full-size practice pack (8 simulated models, 64 cells counting each model with itself, 48
banks; at k = 64 that is 76,800 calls: 64 cells x 2 streams x 3 orders x 200 draws), on the same
laptop at a load average of 15 to 67:

| command | time | most memory |
|---|---|---|
| `score examples/rank_focus_shrink.py --budget 64` (sealed, the paper's rules beside it) | 19 min | 1.3 GB |
| `score scoreswap/reference_rules/keep.py --budget 64` (sealed, the paper's rules beside it) | 22 min, of which the calls 11 min | 1.3 GB |
| `python -m scoreswap.parity --only keep,recal_64 --workers 2` (maintainers) | 25 min | 1.0 GB |

(The full-size figures were measured before whole banks were held out; a board now holds about
half the cells, so each board takes about half as long.) Almost all of it is one fresh process per
call: about 15 ms of computer time per call for the scorer itself, plus whatever your rule does,
paid again on every call. Work that depends only on the bank (sorting all tips, fitting a prior) is
the costly kind: take it from `bank.engine_family(f)`, which the scorer prepares once per bank, or
keep it small. A board costs one score per entry and budget, so ten entries at one budget take
about ten times one score. `--workers` sets how many processes run at once (default: up to 8).

## What is guaranteed, and what is not

Each sentence below is shown by a test in `tests/test_scoreswap_*.py`; the attack files are in
`tests/scoreswap_r9/`.

**Stopped by construction** (on any system):
- The harness alone answers checks and counts them: at most k per call, at most two per cell, no
  unknown cell. Random checks come from a generator the rule cannot steer; on the ranked board
  their seed is secret, so they cannot be predicted from public values.
- No public file holds any result, score, diary, candidate list or text of a private owner's
  bank; each private file is committed by its sha256 in the public manifest, and a private folder
  that does not match is refused. So results carried in an entry file are about public tips only:
  on the ranked board the carried check pool (A1), memorised scored jobs (A10) and the per-tip
  item transfer gain exactly 0.
- A private bank's tips and jobs reach a call in an order drawn from the secret seed, so a position
  in it says nothing about the same position in a public bank.
- A rule is told the pack's number of draws in `check` as in `score`, and `check` runs draws picked
  at random.

**Stopped by the jail** (Linux on x86_64 with bubblewrap, Landlock and the system-call filter; the
outputs say when it applied, and a ranked result is refused without it): every call is a fresh
process forked from a launcher that never runs your code; the launcher runs in its own user, PID,
network, IPC and mount namespaces, whose file system holds only read-only copies of the system
libraries, Python, `scoreswap`, `msr` and your file. So a call cannot see or reach any process
outside the jail, cannot learn that any other file exists, cannot change any file or its access
time, and cannot leave a note for a later call: no files, pipes, sockets, shared memory, signals,
file locks or file watches, no change to the launcher's or any other process's resource limits,
priority or scheduling, no new process or thread. A call speaks only to the launcher, through
pipes made for that call; the launcher relays one answer per call, so a call cannot forge messages
or stop the launcher. A call may use at most 2 GB of memory beyond the launcher's (`--memory`),
300 s (`--timeout`), and a whole run 6 hours (`--time-budget`).

**Not stopped:**
- Anything public. Your file may carry the whole public pack. On the ranked board, what public
  results say about other owners' tips written on the same write tasks can be used, because every
  bank lists the same jobs and candidates (the relevance values identify them); on the practice
  pack that lost (-0.040), on real data it may gain (see "Two boards"). A new model's no-tip
  results on every job are public.
- Special-casing named models and cells: `swap.owner` and `swap.reader` name them, so a rule can
  treat these models differently; the board says nothing about a model outside the pack.
- Timing: calls of a run that run at the same time share the machine, and a very patient entry
  could signal through how busy it is.
- Kernel bugs: the jail is the kernel's.
- The Python audit hook only gives friendly messages; an entry can switch it off, and the kernel's
  refusals are silent, so `check` cannot always name what was refused.
- Off Linux, or without bubblewrap, only part of the above holds; a ranked result is then refused.
- Repeated submissions can slowly fit the ranked board; see the limits under "Submitting".

## For maintainers: running submitted entries

- Score submitted entries on Linux x86_64 with bubblewrap, in a throwaway account or container
  that holds nothing else, never beside other work: the jail stops what is listed above, not what
  a kernel bug would allow.
- Give the run a memory ceiling of its own as well (for example `systemd-run --user --scope -p
  MemoryMax=4G`), and keep `--memory` and `--time-budget` at their defaults unless a pack needs more.
- Run `check`, then `score --private <private folder>` (both boards and the held-out alarm) or
  `leaderboard --private`. Never copy the private folder onto a machine an entrant controls.
- Before a pack opens, measure owner pooling on it (`tests/scoreswap_r9/make_owner_pool.py`, both
  matches) and print the ranked-board numbers on its board page.

## Submitting, the ranked board and its log

- **How**: one entry file, as a pull request to the public repository (after the paper's
  de-anonymisation; during review, through the venue's channel). The file must pass `check` on the
  practice pack.
- **Who runs it**: the maintainers (the authors, and a named co-maintainer outside the author team
  once one has agreed), on the private half, with the procedure above.
- **How often**: at most 2 ranked runs per team per calendar month, and at most 10 per pack; a
  withdrawn or failed entry counts.
- **The log**: every ranked run is appended to a public log: the entry's sha256, the date, the pack
  version, the board version, both boards' numbers and the held-out alarm, failed and withdrawn
  entries included. The log is never edited, only appended to.
- **Versions**: packs and boards carry versions (`manifest.json` "version"; `entries.json`
  "board_version"). A pack is replaced, never edited; a new pack starts a new board, and the entries
  of the old board are re-run on it.
- **Opening the commitment**: when a pack is retired, its private half is published, so anyone can
  check every ranked number against the sha256 committed in the public manifest and re-run the
  log's entries.
- **When closed models retire**: their stored results stay valid and scorable for as long as the
  pack exists (the pack holds results, not live models), but a retired model can read no new bank
  and write none, so a later pack cannot extend its row or column. A pack is replaced when most of
  its models are retired.

## What cannot be tested offline

The tables hold only what was run. These need new model calls:
- rules that change a tip's text;
- rules that show more than one tip at a time, or no tip at all;
- rules that look beyond the 4 stored tips for a job;
- rules that need more than two checks of the same job and tip;
- rules that call a model themselves.

Adding a new model as the reader needs its own runs on every old model's tips. Adding a new
model as the owner needs runs by every reader. A retired model can read no new tips.

## Fair play, in short

- Fresh checks come only from the calibration jobs. Every score is computed on other jobs.
- A rule that uses random checks is run 200 times with 200 seeds, the same seeds the paper's
  rules get (public ones on the development board, secret ones on the ranked board), and each job's
  score is the average.
- The scorer reproduces the paper's own numbers for keep, wipe, the discounts, the power prior,
  recalibration, re-test and audit (`python -m scoreswap.parity --study sim`).
