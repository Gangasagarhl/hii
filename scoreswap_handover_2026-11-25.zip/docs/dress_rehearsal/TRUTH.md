# The known truth of the full-size dress rehearsal

Everyday picture: eight actors play eight garage helpers. Each follows a written script: how
skilled he is, how much each repair tip helps HIM, and how much of that he shares with the other
helpers. Because we wrote the script, we know before any job is done how well an old helper's tip
scores should carry over to a new one. This file writes that down, so the analysis of
`runs/simfull` can be checked against it.

The script is `msr/sim.py`; the actors are in `config/models.yaml`; the numbers below come from
`docs/dress_rehearsal/truth.py`, which uses only the script and the study's own task splits, never
the results. The four practice models (makers a and b) are unchanged; makers c and d are new.

## Part A. The eight models (from the parameters; written before the run)

| model | maker | skill | item strength | g (shared by all) | f (shared in maker) | relevance bonus | task spread | no-memory success DDXPlus / BIRD | repeat reliability DDXPlus / BIRD |
|---|---|---|---|---|---|---|---|---|---|
| sim-a-old | a | 0.00 | 1.20 | 0.30 | 0.40 | 0.50 | 1.00 | 0.495 / 0.500 | 0.299 / 0.304 |
| sim-a-new | a | 0.50 | 1.20 | 0.30 | 0.40 | 0.50 | 1.00 | 0.597 / 0.602 | 0.312 / 0.312 |
| sim-b-old | b | -0.30 | 1.20 | 0.30 | 0.40 | 0.50 | 1.00 | 0.433 / 0.438 | 0.307 / 0.296 |
| sim-b-new | b | 0.30 | 1.20 | 0.30 | 0.40 | 0.50 | 1.00 | 0.557 / 0.562 | 0.302 / 0.311 |
| sim-c-old | c | -1.20 | 1.20 | 0.30 | 0.65 | 0.50 | 1.00 | 0.264 / 0.268 | 0.274 / 0.282 |
| sim-c-new | c | 1.20 | 1.20 | 0.30 | 0.65 | 0.50 | 1.00 | 0.728 / 0.731 | 0.282 / 0.294 |
| sim-d-old | d | 0.00 | 1.20 | 0.30 | 0.00 | 0.50 | 1.00 | 0.495 / 0.500 | 0.315 / 0.309 |
| sim-d-new | d | 0.06 | 0.72 | 0.30 | 0.00 | 0.30 | 0.60 | 0.510 / 0.513 | 0.154 / 0.158 |

No-memory success: the mean true success probability with no item shown, over the probe tasks of
the three stream orders. Repeat reliability: the share of the variance of a one-item call's result
that the (task, item) explains, the rest being the coin toss of a single call (higher = two repeats
of one call agree more often). Source: `truth_models.csv`.

What each maker is for:
- **a and b** (unchanged practice pairs): moderate transfer, small upgrades (+10 and +12 points).
- **c: scores transfer almost fully, and the new model is much stronger with no memory.** The two c
  models share 95 % of the item-quality variance (0.30 + 0.65). The new one solves about 73 % of the
  tasks with no memory against 27 % (+46 points). The two levels sit evenly around 50 %, so a tip
  can move either model's success by about as much: the retained share should stay high in both
  directions even though the level jumps.
- **d: scores transfer poorly, and the new model is noisier.** The two d models share only the
  global 30 % of the item-quality variance, exactly as much as models of different makers; so for
  d, same-maker transfer should be NO better than cross-maker transfer. The new d model's answers
  depend less on the task and the tip (all its effects are 0.6 x the usual, the same as a random jolt
  on every call), so its repeats agree about half as often (reliability 0.16 against 0.31).

## The item-quality correlation of every swap (from the formula of msr/sim.py)

| swap | correlation of the item-quality parts |
|---|---|
| home (a model with itself) | 1.00 |
| a or b, same maker (old -> new and new -> old) | 0.70 |
| c, same maker | 0.95 |
| d, same maker | 0.30 |
| any two models of different makers (48 swaps) | 0.30 |

`truth_corr_q.csv` lists all 64 cells. The item quality is not the whole effect: every model also
gets the relevance bonus when the tip came from a task with the same label (DDXPlus) or database
(BIRD), the same for all models (0.3 for sim-d-new). That shared part raises the correlation of the
whole effect a little above these numbers, for every swap.

## What the analysis should find (direction, written before the run)

theta is a ratio in SUCCESS POINTS: how much of the owner's home ranking signal holds for the reader.
So besides the correlation it carries the ratio of the two models' item effects in success points.
- Home cells (self-swap): theta = 1 and the drop = 0 by construction (fresh repeats of the same model).
- The shuffled control (scores given to the wrong items): Cw = 0.50.
- Same maker a, b: theta about 0.6-0.7 in both directions.
- Same maker c: the highest, about 0.9-1.0 in both directions.
- Same maker d: low, about 0.2-0.3 for the upgrade, as low as cross-maker. The downgrade d-new -> d-old
  is higher (about 0.35-0.45): its owner is the noisy model, whose own home signal is small, and the
  old d model reacts more strongly to the same items.
- Cross maker: about 0.2-0.3; higher when sim-d-new is the owner, lower when it is the reader.
- Same maker above cross maker: yes for a, b, c (both directions); no for d.

These ranges come from a quick check with random candidates; the exact values on the real
candidates follow in Parts B and C.

## Part B. On the real probe candidates (computed 24 Nov 2026, 00:55, after the probe stage, before Stage C)

`python docs/dress_rehearsal/truth.py candidates` takes the 4 candidates the probe stage really
retrieved for every evaluation task (400 per order, 3 orders, 2 streams) and computes, with true
success probabilities instead of 0/1 results: rho (correlation of the within-task differences of
owner and reader), the transfer slope, and theta_or, the retained share if the owner's scores
ranked its own items perfectly. Files: `truth_cells_candidates.csv`, `truth_pairs_candidates.csv`,
`truth_groups_candidates.csv`.

| maker | upgrade rho | upgrade slope | upgrade theta_or | downgrade rho | downgrade slope | downgrade theta_or |
|---|---|---|---|---|---|---|
| a | 0.693 | 0.630 | 0.619 | 0.664 | 0.702 | 0.716 |
| b | 0.679 | 0.673 | 0.684 | 0.664 | 0.697 | 0.719 |
| c | 0.755 | 0.641 | 0.764 | 0.767 | 0.912 | 1.203 |
| d | 0.307 | 0.219 | 0.240 | 0.229 | 0.330 | 0.345 |

| cross-maker swaps | rho | slope | theta_or | theta_or range |
|---|---|---|---|---|
| neither model is sim-d-new (36) | 0.287 | 0.289 | 0.312 | 0.22-0.43 |
| owner sim-d-new (6) | 0.285 | 0.393 | 0.391 | 0.36-0.48 |
| reader sim-d-new (6) | 0.300 | 0.228 | 0.246 | 0.20-0.33 |
| all 48 | 0.288 | 0.294 | 0.314 | 0.20-0.48 |

Groups (both streams; per stream within 0.02): upgrades rho 0.611, theta_or 0.569; downgrades rho
0.598, theta_or 0.752; cross-maker rho 0.285, theta_or 0.309; home 1.

What changed against the expectation of Part A:
- **Maker c transfers less than its 95 % item correlation suggests.** In success points the two c
  models' tip differences correlate only 0.75-0.77: on a hard task the weak model fails whatever tip it
  sees while the strong one is in the range where tips matter, and on an easy task the reverse. So a
  big jump in skill by itself loses ranking signal, even when the tips' effects are nearly the same in
  log-odds. The upgrade keeps 0.76 of the oracle signal (the most of the four upgrades); the downgrade
  keeps MORE than all of it (1.20): the weak old model reacts more strongly to the strong model's top
  tips than the strong model itself does. A theta above 1 is therefore a true value here, not noise.
- **Maker d shows poor transfer in both directions** (0.24 and 0.35 against 0.62-0.72 for a and b),
  about the cross-maker level (0.31), as designed. The noisy sim-d-new moves theta down when it reads
  (0.25) and up when it owns (0.39).
- The rho of a and b (0.66-0.69) sits near the 0.70 item correlation; the shared relevance bonus adds a
  little and the skill gaps take a little away.

Part C (after Stage C) replaces the perfect ranking by the owners' REAL final scores: that is exactly
what theta estimates, without the outcome noise.

## Part C. With the owners' real final scores (computed 24 Nov 2026, 02:40, from Stage C's raw cells)

`python docs/dress_rehearsal/truth.py scores` reads `runs/simfull/results/cells/*.npz` (the candidates
and the owner's real `ema_grade` scores exactly as Stage C used them) and puts the true success
probabilities in place of the 0/1 results. theta_true is then exactly what theta estimates, with the
outcome noise removed. Files: `truth_cells_scores_ema_grade.csv`, `truth_pairs_scores_ema_grade.csv`,
`truth_groups_scores_ema_grade.csv`. These are the values the analysis is checked against.

| maker | upgrade theta_true | (oracle theta_or) | downgrade theta_true | (oracle theta_or) |
|---|---|---|---|---|
| a | 0.624 | 0.619 | 0.787 | 0.716 |
| b | 0.740 | 0.684 | 0.797 | 0.719 |
| c | 0.681 | 0.764 | 1.220 | 1.203 |
| d | 0.207 | 0.239 | 0.217 | 0.345 |

Cross-maker swaps: theta_true 0.328 on average (0.18-0.62); 0.329 when neither model is sim-d-new,
0.394 when sim-d-new owns the items, 0.261 when it reads them.

Groups (sums of per-cell mean V, as the analysis pools them):

| group | DDXPlus | BIRD | both streams |
|---|---|---|---|
| upgrades (4 swaps) | 0.558 | 0.539 | **0.549** |
| downgrades (4 swaps) | 0.820 | 0.783 | **0.801** |
| cross-maker (48 swaps) | 0.335 | 0.309 | **0.322** |
| home (self-swap) | 1 | 1 | **1** |

So the truth says: same maker above cross maker for a, b and c in both directions; NOT for d (0.21
and 0.22, below the cross-maker 0.33); maker c's downgrade keeps more than all of the signal (1.22).
The real scores rank less well than a perfect ranking, which changes theta little except for the
d downgrade (0.35 -> 0.22): the noisy sim-d-new's own scores point the right way less often.

## Part D. The estimates against the truth (24 Nov 2026, from runs/simfull/results/retained.csv)

Stage C's theta per swap (ema_grade, both streams pooled) with its task-cluster 95 % interval, against
theta_true of Part C. File: `theta_retained_vs_truth.csv` (every swap, both streams and pooled).

| swap | theta [95 %] | theta_true | R (secondary) |
|---|---|---|---|
| sim-a-old -> sim-a-new | 0.579 [0.509, 0.654] | 0.624 | 0.631 |
| sim-a-new -> sim-a-old | 0.806 [0.722, 0.894] | 0.787 | 0.765 |
| sim-b-old -> sim-b-new | 0.797 [0.707, 0.894] | 0.740 | 0.837 |
| sim-b-new -> sim-b-old | 0.866 [0.778, 0.959] | 0.797 | 0.815 |
| sim-c-old -> sim-c-new | 0.669 [0.598, 0.746] | 0.681 | 0.834 |
| sim-c-new -> sim-c-old | 1.210 [1.096, 1.337] | 1.220 | 0.989 |
| sim-d-old -> sim-d-new | 0.232 [0.164, 0.302] | 0.207 | 0.238 |
| sim-d-new -> sim-d-old | 0.249 [0.116, 0.388] | 0.217 | 0.248 |

Over all 56 swaps, pooled over the streams: mean error -0.003 (estimate minus truth),
mean absolute error 0.031, largest 0.091; the interval covers the truth for 55 of 56 swaps (98 %).
Per stream: DDXPlus 56 of 56, BIRD 54 of 56. Home cells: theta 1.000 on average, drop -0.0005.
The shuffled control: Cw 0.5001 on average over 1,920 rows (0.492-0.508).

Groups (Stage C's per-swap-and-stream V summed over the group's swaps and both streams, as the
analysis pools them): upgrades 0.555 (truth 0.549), downgrades 0.824 (truth 0.801), cross-maker 0.319
(truth 0.322). Same maker above cross maker where the truth says so (a, b, c, both directions) and not
for d (both directions): 8 of 8 swaps agree (`checks.txt`). The msr.analysis tables (two-way
intervals, the primary family) were not produced in this rehearsal: the 10,000-draw analysis was
stopped after 3 h 23 min (FAULTS.md 9); the manager's re-run of Stage C and the analysis will add them.

## Revision 2: two simulated extension pairs (added 24 Nov 2026, for the simfull re-run)

The re-run of the rehearsal (`config/sim_full.yaml`, 5 passes, new stages) adds two simulated
same-maker pairs on the slots of the Mistral and DeepSeek extension pairs (same-maker cells only):

| model | maker | skill | f (shared in maker) | item-quality correlation with its pair | what it is for |
|---|---|---|---|---|---|
| sim-e-old -> sim-e-new | e | -0.2 -> 0.3 | 0.40 | 0.70 | an ordinary upgrade, like a and b |
| sim-f-old -> sim-f-new | f | 0.1 -> 0.2 | 0.65 | 0.95 | a "minor update" (like DeepSeek V4.1-Flash -> 1017): close to a self-swap |

So the same-maker groups have 6 pairs each, and the truth says: f transfers best of all six (both
directions near the self-swap), e like a and b. The exact noise-free values come from `truth.py` after
the re-run (Parts B and C), as for the first run.
