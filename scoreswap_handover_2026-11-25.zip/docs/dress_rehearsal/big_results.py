"""BIRD tasks whose gold result has more rows than msr.grade caches (CACHE_MAX_ROWS), and how many
simulated calls re-ran such a query (each correct answer to such a task is run again in full).

    python docs/dress_rehearsal/big_results.py
"""
import json
import pickle
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from msr import data as D  # noqa: E402
from msr import grade as G  # noqa: E402

big = {}
for t in D.load_stream("bird"):
    k = G._disk_key("gold", str(G._task_db(t)), t["SQL"], G.DEFAULT_TIMEOUT)
    p = D.DATA_DIR / "grade_cache" / "gold" / f"{k}.pkl"
    if p.exists():
        v = pickle.load(open(p, "rb"))
        if (v.get("n_rows") or 0) > G.CACHE_MAX_ROWS:
            big[t["task_id"]] = (v["n_rows"], v["seconds"], t["SQL"].strip())
print(f"{len(big)} BIRD tasks have a gold result above {G.CACHE_MAX_ROWS:,} rows")
runs, secs = Counter(), 0.0
with open(ROOT / "runs" / "simfull" / "calls.jsonl", encoding="utf-8") as f:
    for line in f:
        if '"bird-' not in line:
            continue
        r = json.loads(line)
        tid = (r.get("meta") or {}).get("task_id")
        if tid in big and r["answer"].strip().startswith("SELECT") and r["answer"].strip() not in ("SELECT 1", "SELECT 0", "SELECT -1"):
            runs[(r["meta"].get("stage"))] += 1
            secs += big[tid][1]
print(f"calls whose answer re-ran such a query in full: {sum(runs.values()):,} {dict(runs)}; "
      f"at the queries' own first-run times that is about {secs / 3600:.1f} h of SQL")
