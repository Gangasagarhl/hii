# Disk projection for runs/simfull (written 23 Nov 2026, 23:36, before the run had written anything large)

Basis: `runs/sim` (207 MB, 57,880 calls, DDXPlus only, 16 cells x 2 orders x 80 probe tasks, 3 of the k
values kept) and `runs/scoreswap_fixture` (37 MB, 13,392 calls). The full study makes 2,240,400 calls
(`estimate_simfull.txt`), 64 cells x 2 streams x 3 orders, 500 probe tasks (400 evaluation tasks), six k.

| part | measured on the small run | scaling | projection |
|---|---|---|---|
| `calls.jsonl` | 657 bytes per call (DDXPlus); a BIRD answer is SQL, about 140 bytes longer | x 2,240,400 calls | about 1.6 GB |
| `prompts/` (one file per distinct prompt) | 0.20 files per call, 4.6 KB on disk each (4 KB blocks); BIRD prompts are about 4 KB, often 8 KB on disk | about 350,000-450,000 files | 2.0-2.7 GB |
| `banks/` | 4.6 MB for 10 banks of 80 items | 60 banks of 250 items | about 0.1 GB |
| `probes/`, `probes0/`, `subsets/`, `variants/` | 11 MB for 32 cell tables of 80 tasks | 384 tables of 500 tasks (x 75) | about 0.8 GB |
| `online/` | 1.5 MB | 72 cells x 250 tasks x 7 arms | under 0.1 GB |
| `results/` | 96 MB: `draws/` 73 MB, `per_task/` 21 MB, 32 cell files | x 12 cell files; per_task also x 7 tasks; draws also x 2 k values; `sensitivity/` may repeat parts | 3.6-7 GB |
| `analysis/` | 5 MB | | about 0.1 GB |
| **total** | | | **about 8-12 GB (upper bound 15 GB)** |

Below the 25 GB limit set for this job, with about 60 GB free, so the run goes ahead as it is, with no
lighter logging switch: the rehearsal then writes exactly what a paid run would write (a paid run's
answers are longer free text, so its `calls.jsonl` will be somewhat larger; its prompts are the same).
The measured figures are in `stage_metrics.tsv` and below.

## Measured (24 Nov 2026, 01:15, after build, probe, probe_extra and online; before Stage C)

| part | projected | measured on disk (apparent size) |
|---|---|---|
| `calls.jsonl` | about 1.6 GB | 1.6 GB (1.62 GB; 724 bytes per line; 2,243,865 lines = 2,240,400 calls + 3,465 asked again after the deliberate stop) |
| `prompts/` | 2.0-2.7 GB | 0.82 GB (0.51 GB): 168,103 files, 0.075 per call, not 0.20: at full size the 8 readers share the same probe prompts |
| `banks/` | about 0.1 GB | 0.09 GB |
| `probes/` + `probes0/` + `subsets/` + `variants/` | about 0.8 GB | 0.63 GB |
| `online/` | under 0.1 GB | 0.02 GB |
| **total before Stage C** | | **3.1 GB (2.8 GB)** |

Stage C (`results/`) and the analysis are added below when they finish.

## Measured after Stage C (24 Nov 2026, 03:45)

| part | projected | measured on disk |
|---|---|---|
| `results/draws/` | about 1.75 GB | 1.6 GB (4.3 MB per cell) |
| `results/per_task/` | about 1.8 GB | 1.3 GB (3.4 MB per cell) |
| `results/sensitivity/` | 0 to a second copy | 0.67 GB (the BIRD half again, per-task values only; `FAULTS.md` 6) |
| rest of `results/` (cells, csv) | about 0.1 GB | 0.05 GB |
| **runs/simfull in all** | **8-12 GB (upper 15 GB)** | **6.6 GB (6.2 GB apparent)** |
| `release/simfull` + `release/simfull_private` | | 0.10 + 0.06 GB |

For the paid run add about 9 GB for `runs/_cache/` (one answer file per paid call, which simulated calls
skip) and somewhat more for `calls.jsonl` if the real answers are longer than the estimate's 15 / 80
tokens: about 16-18 GB in all. (The analysis folder was not written: the analysis was stopped, FAULTS.md 9; the small study's was 5 MB.)

## Revision 2 (24 Nov 2026): the paid study after the pipeline changes

The sections above are kept as history. This one is made with `python docs/dress_rehearsal/project_real.py`
(free, no call). The paid study is now 12 models (the 8 of the main grid and the two extension pairs),
72 cells, 5 passes, 16 online pairs with 9 arms each (864 online runs), and the new stages (judge,
self-rating, second no-memory answer, relearn): 3,384,000 calls, as `run.py --estimate` prints.

Everyday picture: the kitchen got two fixes. Before, the last station served one table at a time, so
most cooks stood idle; now every free cook takes the next dish from any table. And the taster used to
taste a whole table's dishes alone after the last one came out; now each cook tastes his own dish as he
plates it, and remembers big dishes by a short label instead of tasting them again.

### What changed in the pipeline

- **The run after the swap runs in parallel.** All runs of all unfinished cells share one pool of
  `workers` runs. Each run is still a chain of 250 calls, so the stage takes about
  ceil(runs / workers) x 250 call times: at 16 workers, 864 runs make 54 x 250 = 13,500 call times
  (3.8 h at 1 s per call). The old schedule (one cell at a time: its `none` run first, then its other runs
  side by side) would need 96 cells x 500 = 48,000 call times (13.3 h) for this study.
- **BIRD answers are graded in the worker threads**, as each call returns. Grading no longer waits at the
  end of each probe cell; it overlaps the other workers' calls. At the earlier assumption (0.28 distinct
  SQL strings per graded answer, 0.09 s each), grading is 10.6 h of work in all, but it adds only about
  1 h of wall time at 16 workers. Before, it was a serial tail (10.6 h for this study's size).
- **Big results are cached** as a fingerprint (row count and a hash of the rows), so a correct answer
  with a result above 10,000 rows is run once, not on every call that gives it.
- **New stages in the model.** Judge, self-rating and second no-memory answer calls run `workers` at
  once, one cell (or one model, stream and order) at a time. Relearn cells are sequential chains like
  banks (5 passes x 500 tasks, no self-tags), `workers` chains at once (120 chains).

### Wall time of the calls

Hours; no rate limit, a steady time per call, 3 ms of pipeline work per call, grading as above.

| workers | s per call | write, write2, selfrate, build0 | build score phase | probe | probe_extra | subsets + wording | judge | relearn | online | **total** |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 4 | 1 | 6.4 | 29.4 | 126.9 | 20.3 | 11.4 | 7.6 | 21.2 | 15.2 | **238.5 h (9.9 days)** |
| 4 | 2 | 12.5 | 58.6 | 251.9 | 40.3 | 22.7 | 15.1 | 42.0 | 30.2 | **473.6 h (19.7 days)** |
| 8 | 1 | 3.1 | 15.4 | 63.5 | 10.2 | 5.7 | 3.9 | 10.6 | 7.6 | **120.1 h (5.0 days)** |
| 8 | 2 | 6.4 | 30.7 | 126.0 | 20.2 | 11.4 | 7.7 | 21.0 | 15.1 | **238.4 h (9.9 days)** |
| 16 | 1 | 1.5 | 8.4 | 31.7 | 5.1 | 2.9 | 1.9 | 5.6 | 3.8 | **61.1 h (2.5 days)** |
| 16 | 2 | 3.1 | 16.7 | 63.0 | 10.1 | 5.7 | 3.8 | 11.2 | 7.6 | **121.3 h (5.1 days)** |

- The earlier projection (`projection_real_run.txt`, 2,240,400 calls at 3 passes) was 54 / 91 / 169 h at
  16 / 8 / 4 workers and 1 s per call, of which 7.5 h was the serial grading tail and 10 h the online
  stage. The study now has 1.51 times the calls and takes 61 / 120 / 239 h: the new calls add time, the
  two fixes take most of the old waiting away.
- The stages are now close to the floor of calls / workers (3,384,000 / 16 = 58.8 h at 1 s). Only the
  chains (banks and relearn) lose a little, in the last round when fewer chains than workers are left.
- Grading at 0.26 s per distinct SQL run (the measured mean of the gold queries) instead of 0.09 s:
  62.4 h at 16 workers and 1 s (1.3 h more). With no grading and no pipeline work: 60.2 h.
- Not counted: real latency, rate limits (16 calls at once on one model), refusals and retries; the
  analysis (see below); the pilots and side studies (about 253,000 calls, their
  own runs); the option `check_store_extra_tasks` (costed, not built).

### Disk

The measured rehearsal figures above, scaled by the call count (3,384,000 / 2,240,400 = 1.51), plus the
answer cache of a paid run:

| part | rehearsal (2,240,400 calls) | paid study (3,384,000 calls) |
|---|---:|---:|
| `calls.jsonl` | 1.6 GB | 2.4 GB |
| `prompts/` | 0.82 GB | 1.2 GB |
| `banks/` | 0.09 GB | 0.14 GB |
| `probes/`, `probes0/`, `subsets/`, `variants/` | 0.63 GB | 0.95 GB |
| `online/` | 0.02 GB | 0.03 GB |
| `results/` (draws, per-task, sensitivity, rest) | 3.6 GB | 5.5 GB |
| **runs/study in all** | **6.6 GB** | **about 10 GB** |
| `runs/_cache/` (one answer file per fresh paid call, 4 KB on disk) | (simulated calls skip it) | 13.9 GB, 3.38 million files at most |
| **paid run in all** | | **about 24 GB** |

- Longer real answers make `calls.jsonl` bigger: up to about 1 GB more if the answers are twice the
  estimate's 15 / 80 tokens.
- Three parts are rough. `results/` grows with cells and score types more than with calls (72 cells
  against 64, plus the judge, self-rating and relearn score types). `prompts/` is an upper figure: a judge
  prompt is the same for every reader, so it is stored once. Banks grow with passes, and the new
  `relearn/` folder holds 120 bank-like chains: at about 2.5 MB per chain of 5 passes, `banks/`,
  `relearn/` and `judge/` together come to about 0.5 GB, not 0.14 GB.
- The machine has about 52 GB and 27 million inodes free today. The pilots and side studies add about
  253,000 calls (under 2 GB with their cache). If space runs short, the rehearsal folder
  (`runs/simfull`, 6.6 GB) can go after its one planned re-run.

### Later additions (24 Nov 2026, pipeline phase 2)

- **The analysis** (`python -m msr.analysis`, after Stage C) now takes about 52 minutes at full size on 8
  processes, with a memory peak of 6.9 GB (statistics worker; it did not finish in 3 h 23 min in the
  rehearsal). Run it in a unit with `MemoryMax=8G`, not 6G:
  `systemd-run --user --unit <name> -p MemoryMax=8G -p CPUQuota=500% ... python -m msr.analysis --study <name>`.
  Stage C itself: 2 h 10 min in the rehearsal (1 h 13 min for the 384 cells, about 11 s of wall time per
  cell on 8 processes, plus a BIRD re-run that is now skipped when no answer is graded differently).
- **Two sessions per probe cell.** Repeat 2 of every cell now runs in a later session than repeat 1
  (pre-registration Parts 3-4): the probe stage makes repeat 1 of every cell first, then repeat 2, and a
  cell's repeat 2 waits until `probe.repeat_gap_hours` (6 h for real models) after its repeat 1. This
  adds no call. At 16 workers and 1 s per call one pass of the probe stage takes about 16 h, longer
  than the gap, so the second pass starts without waiting; only a much faster pass (more workers, a
  smaller study) would make the run stop after the first pass and carry on at the time it prints.
- **Prompt caching and price.** The estimate never assumed a cache discount (every input token at the
  full price), so switching caching off changes no number in `docs/COST_2026-11-24.md`. Anthropic caches
  only when a request asks for it, and ours never ask. OpenAI caches long prompts on its own and cannot be
  told not to; OpenRouter's hosts give no switch. Every call now logs the cached input tokens the host
  reports (`cache_read_tokens`, `cache_write_tokens` in calls.jsonl), so any caching shows; if it
  happens, the real spend is lower than the estimate, never higher.
- **After the pre-registration's revision 2 (24 Nov, later):** the run after the swap keeps its 12 swaps
  (the extension pairs are not in it, Part 2.10), so the study is 3,330,000 calls (54,000 fewer than the
  table above; about 0.6 h less at 16 workers). A later session of a real model must also run in a NEW
  process (Part 2.4 (b)): `run.py` starts a fresh copy of itself for repeat 2, for extra repeat 3 and for
  extra repeat 4 (each after the gap); every call logs its session, process id, start and end time and the
  host's cache fields.
