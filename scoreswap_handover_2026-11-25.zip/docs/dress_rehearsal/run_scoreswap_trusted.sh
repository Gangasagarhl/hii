#!/usr/bin/env bash
# score at k = 64 in this process (--trusted: the project's own reference rules and example entry).
set -u
cd "$(dirname "$0")/../.."
LOG=docs/dress_rehearsal/scoreswap_k64.txt
PY=".venv/bin/python -u docs/dress_rehearsal/tsrun.py .venv/bin/python -u"
run() { echo "=== $(date -Is) $*" >> "$LOG"; $PY "$@" >> "$LOG" 2>&1; echo "=== exit $?" >> "$LOG"; }
run -m scoreswap score scoreswap/reference_rules/keep.py --pack release/simfull --budget 64 --out docs/dress_rehearsal/scores_k64 --trusted
run -m scoreswap score scoreswap/reference_rules/recal.py --pack release/simfull --budget 64 --out docs/dress_rehearsal/scores_k64 --trusted
run -m scoreswap score examples/rank_focus_shrink.py --pack release/simfull --budget 64 --out docs/dress_rehearsal/scores_k64 --trusted
