# Faults and limits found by the full-size dress rehearsal

None of these stopped the simulated run. Each is in a file this job may not change (or the change is
not a small bug fix), so each is written down with a proposed fix. Line numbers are of 23 Nov 2026.

## Status after pipeline phase 2 (24 Nov 2026)

| fault | status |
|---|---|
| 1 cut files (llm.py) | FIXED: cache, prompt and spend files are written to a temporary file and swapped in; a cut cache file is asked again; a cut prompt file is rewritten; the spend file keeps a backup and a run stops (never resets) when neither copy can be read. Tests: `test_llm_atomic_and_pins.py`, `test_dress_rehearsal_resume.py` |
| 2 timeouts cached for ever (grade.py) | FIXED: the 30 s limit is the query's own CPU time (300 s wall cap); a timed-out result is never written to disk (old ones are ignored); retried once at once, then again at the end of the stage with nothing else running (msr/regrade.py); still timed out = "ungraded: timeout", counted and printed, never silently wrong. Tests: `test_grade_timeouts.py`, `test_data_grade.py` |
| 3 online never above 6 calls (online.py) | FIXED: one pool of `workers` runs over all cells, results identical (peak 24 calls at once in the test with 24 workers). Test: `test_online_phase2.py` |
| 4 BIRD graded one by one (probe.py) | FIXED: each answer is graded in its worker thread as its call returns (also the write, second-write and no-memory steps); the grades equal grading one by one. Test: `test_phase2_pipeline.py` |
| 5 big results re-run (grade.py) | FIXED: a result above 10,000 distinct rows is cached as a fingerprint (distinct-row count + order-free digest); equal to the set comparison on all 20 big BIRD gold results and 4,000 random pairs. Test: `test_grade_timeouts.py` |
| 6 needless BIRD re-run (evaluate.py) | FIXED: no re-run when no BIRD answer is graded differently. Test: `test_phase2_pipeline.py` |
| 7, 8 scorer speed and parity memory | sent to the scorer builder |
| 9 analysis time | fixed by the statistics worker (about 52 min at full size, 6.9 GB peak: use MemoryMax=8G) |

## 1. A stop during a write can leave a cut file that blocks or damages the paid run (msr/llm.py)

- `msr/llm.py:273` `cache_file.write_text(json.dumps(asdict(r), ...))` writes the answer-cache file in
  place. If the run is stopped during that write (a stop, a crash, a full disk), the file is cut. On
  the next run `msr/llm.py:237` `json.loads(cache_file.read_text())` raises, so the run stops at
  that call every time until someone deletes the file by hand.
  Shown by `tests/test_dress_rehearsal_resume.py::test_cut_cache_file_does_not_stop_a_resumed_run`
  (an expected failure, strict, so it turns red once fixed and can then be made a normal test).
- `msr/llm.py:229` the prompt store: `prompt_file.write_text(...)` in place, and it is never rewritten
  because of the `exists()` check. A cut prompt file stays cut, silently: the record of what was
  asked is damaged.
- `msr/llm.py:206` `SPEND_PATH.write_text(...)` in place. A cut `runs/spend.json` makes `spent()`
  (read before every paid call, line 196) raise, so every paid call stops until it is repaired.
- Proposed fix (about 10 lines): write each to a temporary file in the same folder and `os.replace`
  it (as `_record_settings` already does at line 410); in `call`, treat an unreadable cache file as
  missing (ask again, then overwrite).
- The simulated rehearsal does not reach these lines (simulated calls are not cached and cost 0).
  The deliberate stop left no cut file (`resume_result.txt`); a stop is unlikely to land inside a
  1 KB write, but over 2.24 million calls and several stops it can.

## 2. A query that times out once is graded wrong for ever (msr/grade.py)

- `msr/grade.py:42` sets a 30 s wall-clock limit per SQL query; `msr/grade.py:259` (gold) and
  `msr/grade.py:283` (predicted) store the result on disk in `data/grade_cache/` whatever it is,
  including `timed_out: True`. A slow query that passes 30 s once because the machine is busy is
  read back as "timed out" by every later run: a correct BIRD answer stays graded wrong, and a gold
  query that timed out makes the whole task wrong for every model.
- Measured here, with the machine at load average 15-23: the slowest gold query took 18.5 s (62 % of
  the limit); mean 0.26 s, median 0.016 s over 1,525 gold queries. No query timed out in this run.
- Proposed fix: do not write results with `timed_out: True` to the disk cache (run them again next
  time), or re-run a timed-out query once before grading it wrong.

## 3. The run after the swap can never use more than 6 calls at once (msr/online.py)

- `msr/online.py:227` runs the 72 online cells one after another; inside a cell, `msr/online.py:186`
  runs the `none` arm first, one call at a time (250 calls in a row), then `msr/online.py:204` runs
  the other six runs side by side (each 250 calls in a row). Whatever `run.workers` says, the stage
  takes 72 x 500 = 36,000 call latencies: about 10 h at 1 s per call, 20 h at 2 s.
- Not wrong, but slow for the paid run. Proposed: run several online cells at once (they are
  independent), for example `workers // 6` cells side by side.

## 4. BIRD answers are graded one by one after each probe cell (msr/probe.py)

- `msr/probe.py:139` grades the 4,000 answers of a cell in the main thread after the cell's last
  call returns; no call is in flight meanwhile. For simulated models this is cheap (about two queries
  per task, then cache look-ups). A real model's BIRD answers are mostly different SQL strings, and
  each different one is run once on its database (here: mean 0.26 s, up to 18.5 s for a gold query).
- Proposed: grade inside the worker threads as calls finish (SQLite releases the Python lock), or
  grade the previous cell while the next one's calls run.

## 5. A correct answer with a big result is run again in full every time (msr/grade.py)

- `msr/grade.py:192` `CACHE_MAX_ROWS = 10_000` and `msr/grade.py:281-285`: a predicted query whose
  result has more than 10,000 rows is never cached, in memory or on disk, so every call that gives
  that SQL runs it again in full. 20 BIRD tasks have a gold result above 10,000 rows (up to
  278,230 rows; 0.1-3.7 s per run when first run, more under load). Every correct answer to one of
  them is such a call. In the rehearsal this made the BIRD half of the probe stage two to three
  times slower than the DDXPlus half (300 against 850 calls per second); `big_results.py` counts the
  calls. A paid run hits the same tasks (with fewer correct answers, but also wrong answers with big
  results).
- Proposed fix: for a big result, cache a fingerprint instead of the rows (the row count and a
  sha256 of the sorted rows) and compare fingerprints; or keep the result of the last few big
  queries in memory.

## 6. Stage C re-runs the whole BIRD half even when no answer is graded differently (msr/evaluate.py)

- `msr/evaluate.py:2292-2303` (`run_sensitivity`, BIRD's original parser, Part 1.5) always calls
  `run_variant(..., streams=("bird",))`, even when `regrade.json` is empty. Here 0 of the 1.1 million
  BIRD answers parse differently under the two parsers (`results/sensitivity/bird_original/regrade.json`
  is `{}`), yet the 192 BIRD cells were evaluated a second time (about half of Stage C's time again).
  The function's own docstring says an analysis that changes nothing is "recorded as identical".
- Proposed fix: when `flips` is empty and no score episode changed, write the entry as
  "identical to the primary analysis: no BIRD answer parses differently" and skip the re-run. A paid
  run will have some differences, so it will need the re-run; the cost is about one BIRD half of
  Stage C (here about 35 minutes).

## 7. Scoring an outside entry in the sealed mode takes hours at the full size (scoreswap)

- `python -m scoreswap score <entry> --budget 64` (sealed, the default for outside code) on the
  rehearsal's pack: 5 of 48 banks in 2,574 s (200 draws per cell; machine load average 45-66),
  so roughly 1.5-7 h per entry and budget. The same entry with `--trusted` scored all 48 banks in
  184 s. `check` (3 draws) took 12 min (keep), 11.5 min (recal) and 3 min (the example) and passed.
  The sealed launcher forks one fresh process per call (scoreswap/harness.py); at 384 cells x 200
  draws that dominates. A leaderboard of several entries and budgets would take days.
- Proposed: batch all draws of a cell into one sealed call, or keep one sealed worker process per
  bank; or score the leaderboard with fewer draws (the check already proves the entry is sealed).

## 8. scoreswap.parity holds every cell's whole per-task file in memory (scoreswap/parity.py)

- `scoreswap/parity.py:97-104` (`per_task_cache`) keeps the whole per-task npz of every cell it
  meets: 7.8 MB uncompressed per cell, 384 cells = 3 GB at the full size (2,279 arrays per cell).
  `python -m scoreswap.parity --study simfull --pack release/simfull --only keep,recal_64 --workers 2`
  was killed for memory at a 2.5 GB cap after 3.6 min.
- Proposed: read only the arrays `{family}|{arm}|...` of the arm being checked, per cell, and keep
  nothing between cells. `parity_light.py` in this folder does exactly that with the same rules,
  columns and tolerance, and is what produced `parity_k64.txt`.

## 9. The analysis takes hours at the full size, in one process (msr/analysis.py)

- `python -m msr.analysis --study simfull` (10,000 draws, the registered number) ran 3 h 23 min on this
  machine (load average 45-66) and had not finished: theta 864 s, validity 426 s, primary tests 107 s,
  contrasts 466 s, stakes and predictions 79 s, then `arms_tables` (`msr/analysis.py:1219`, every
  family x arm x k x metric x group x level, plus every pair for the headline family) alone 7,878 s;
  it was stopped in the "secondary" step to free memory (3.55 GB, steady) for the rest of the checks.
  The step runs in one process (about 1.3 cores used).
- Not wrong, only slow; it calls no model. Proposed: spread `arms_tables` over processes by family
  (as Stage C does by owner), or plan about half a day for the analysis of the paid run.

## 10. Facts about the paid run that the rehearsal cannot measure

- Answer cache: a paid run writes one file per fresh call in `runs/_cache/` (simulated calls skip it):
  about 2.24 million files of about 0.8 KB, 4 KB each on disk, so about 9 GB on disk and 2.24 million
  inodes in one folder (this disk has 27 million free inodes).
- Model latency, rate limits and refusals: the simulated models answer at once.
- Identical prompts: a real reader shown two owners' items with the same TEXT gets one cached answer
  for both (the prompt is the same); the simulator keys its draws on item ids, so it never does. The
  `--estimate` dollar figure is therefore an upper bound.
