#!/usr/bin/env bash
# Stage C (evaluate) and the analysis of the full-size rehearsal, with per-stage figures in
# docs/dress_rehearsal/stage_metrics.tsv (the same columns as run_rehearsal.sh) and a timestamp
# on every output line (docs/dress_rehearsal/evaluate_log.txt), so the time per evaluate job shows.
#   systemd-run --user --unit msr-simfull -p MemoryMax=6G -p CPUQuota=500% \
#     --working-directory=<project> bash docs/dress_rehearsal/run_evaluate.sh
set -u
cd "$(dirname "$0")/../.."
RUN=runs/simfull
OUT=docs/dress_rehearsal/stage_metrics.tsv
LOG=docs/dress_rehearsal/evaluate_log.txt
CG=/sys/fs/cgroup$(cut -d: -f3 /proc/self/cgroup | head -1)
lines() { [ -f "$RUN/calls.jsonl" ] && wc -l < "$RUN/calls.jsonl" || echo 0; }
dkb() { du -sk "$RUN" | cut -f1; }
akb() { du -sk --apparent-size "$RUN" | cut -f1; }

step() {   # step <name> <command ...>
  local name=$1; shift
  c0=$(lines); d0=$(dkb); a0=$(akb); t0=$(date +%s.%N); started=$(date -Is)
  echo "=== $started $name" >> "$LOG"
  .venv/bin/python -u docs/dress_rehearsal/tsrun.py "$@" >> "$LOG" 2>&1 &
  pid=$!; pa=0; pc=0
  while kill -0 "$pid" 2>/dev/null; do
    an=$(awk '$1=="anon"{print $2}' "$CG/memory.stat" 2>/dev/null || echo 0)
    cu=$(cat "$CG/memory.current" 2>/dev/null || echo 0)
    [ "${an:-0}" -gt "$pa" ] && pa=$an
    [ "${cu:-0}" -gt "$pc" ] && pc=$cu
    sleep 0.5
  done
  wait "$pid"; rc=$?
  t1=$(date +%s.%N); c1=$(lines); d1=$(dkb); a1=$(akb)
  mp=$(cat "$CG/memory.peak" 2>/dev/null || echo 0)
  printf '%s\t%s\t%.1f\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%.0f\t%.0f\t%.0f\n' "$name" "$started" \
    "$(echo "$t1 - $t0" | bc)" "$rc" "$c0" "$c1" "$((c1 - c0))" "$d0" "$d1" "$a0" "$a1" "n/a" \
    "$(echo "$pa / 1048576" | bc -l)" "$(echo "$pc / 1048576" | bc -l)" "$(echo "$mp / 1048576" | bc -l)" >> "$OUT"
  echo "=== $(date -Is) $name exit $rc" >> "$LOG"
  return "$rc"
}

step evaluate .venv/bin/python -u run.py --study config/sim_full.yaml --stage evaluate || exit $?
step analysis .venv/bin/python -u -m msr.analysis --study simfull || exit $?
