"""What did the restart after the deliberate stop do again? (full-size dress rehearsal)

    python docs/dress_rehearsal/resume_check.py snapshot     # right after the stop, before the restart
    python docs/dress_rehearsal/resume_check.py compare      # after the restart has passed the stop point

A call is identified by (model, stage, owner, reader, stream, seed, task, items, repeat, bank, epoch,
arm, family). `snapshot` saves the call-log size, the identities of the calls logged before the stop,
and which units of work (probe cells, no-memory runs, banks) were finished on disk. `compare` counts,
among the calls logged after the restart, those whose identity was already logged before the stop
(= redone), and groups them by unit of work.
"""
from __future__ import annotations

import json
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
RUN = ROOT / "runs" / "simfull"
SNAP = Path(__file__).resolve().parent / "resume_snapshot.json"
#: the call stages of run.py's probe stage (the stop is made during it; earlier stages had finished)
PROBE_STAGES = ("probe", "probe0", "subset", "variant", "variant0")


def ident(r: dict) -> str:
    m = r.get("meta") or {}
    return json.dumps([r["model"], m.get("stage"), m.get("owner"), m.get("reader"), m.get("stream"), m.get("seed"),
                       m.get("task_id"), sorted(m.get("items") or []), m.get("repeat"), m.get("bank"), m.get("epoch"),
                       m.get("arm"), m.get("family"), m.get("phase")])


def unit(r: dict) -> str:
    m = r.get("meta") or {}
    return f"{m.get('stage')} {m.get('owner', '-')}->{m.get('reader', r['model'])} {m.get('stream')} seed{m.get('seed')}"


def done_units() -> list:
    out = [str(p.parent.relative_to(RUN)) for p in RUN.glob("probes/*/*/*/done.json")]
    out += [str(p.parent.relative_to(RUN)) for p in RUN.glob("probes0/*/*/*/probe0.jsonl")]
    return sorted(out)


def main(argv) -> int:
    log = RUN / "calls.jsonl"
    if argv[0] == "snapshot":
        ids, n, lines_ok = set(), 0, True
        with open(log, "rb") as f:
            raw = f.read()
        size = len(raw)
        tail_ok = raw.endswith(b"\n")
        for line in raw.splitlines():
            if not line.strip():
                continue
            try:
                r = json.loads(line)
                n += 1
                if (r.get("meta") or {}).get("stage") in PROBE_STAGES:
                    ids.add(ident(r))
            except ValueError:
                lines_ok = False
        SNAP.write_text(json.dumps({"size": size, "calls": n, "last_line_complete": tail_ok, "all_lines_parse": lines_ok,
                                    "done": done_units(), "ids": sorted(ids)}), encoding="utf-8")
        print(f"snapshot: {n:,} calls, {size:,} bytes, last line complete: {tail_ok}, every line parses: {lines_ok}, "
              f"{len(done_units())} finished probe units")
        return 0
    snap = json.loads(SNAP.read_text(encoding="utf-8"))
    before = set(snap["ids"])
    redone, new = Counter(), Counter()
    with open(log, encoding="utf-8") as f:
        f.seek(snap["size"])
        for line in f:
            if not line.strip():
                continue
            r = json.loads(line)
            (redone if ident(r) in before else new)[unit(r)] += 1
    print(f"after the restart: {sum(redone.values()):,} calls were asked again (logged before the stop), "
          f"{sum(new.values()):,} were new")
    for u, n in sorted(redone.items()):
        print(f"  redone  {n:>6,}  {u}")
    finished_before = set(snap["done"])
    print(f"units finished before the stop: {len(finished_before)}; units redone: {len(redone)}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
