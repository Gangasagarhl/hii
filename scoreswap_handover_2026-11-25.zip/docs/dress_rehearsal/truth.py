"""The known truth of the full-size dress rehearsal (config/sim_full.yaml), from msr/sim.py alone.

Everyday picture: the actors follow a script, so before we read the scoring sheets we can write
down, from the script, what a perfect sheet would say. This file writes that down, and later
puts the sheets (the analysis) next to it.

    python docs/dress_rehearsal/truth.py params              # Part A: from the parameters only
    python docs/dress_rehearsal/truth.py candidates          # Part B: on the real probe candidates
    python docs/dress_rehearsal/truth.py scores              # Part C: with the owners' real scores
    python docs/dress_rehearsal/truth.py compare             # Part D: estimates against the truth

Definitions (noise-free: true success probabilities mu from msr.sim.true_success_prob instead of
0/1 results; pairs = every pair of candidates of one evaluation task, as in msr.metrics):
  rho         correlation of the within-task differences d_mu(owner) and d_mu(reader), all pairs
  slope       sum d_mu(owner) d_mu(reader) / sum d_mu(owner)^2   (the transfer slope)
  theta_or    sum sgn(d_mu owner) d_mu(reader) / sum |d_mu owner|  (theta if the owner's scores
              ranked its own items perfectly)
  theta_true  sum sgn(dx) d_mu(reader) / sum sgn(dx) d_mu(owner) with x = the owner's real final
              scores (score ties count 0): exactly what theta estimates, with the outcome noise
              removed. A group value is the sum over its cells of the per-cell mean V_swap over the
              sum of the per-cell mean V_home (equal weight per swap, stream and order).
Part B needs the probe stage (probe_candidates.jsonl); Part C needs Stage C (results/cells/*.npz).
Nothing here calls a model or writes outside docs/dress_rehearsal/.
"""
from __future__ import annotations

import argparse
import csv
import itertools
import json
import math
import sys
from collections import defaultdict
from functools import lru_cache
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from msr import sim  # noqa: E402
from msr.study import load_study  # noqa: E402

OUT = Path(__file__).resolve().parent
STUDY = ROOT / "config" / "sim_full.yaml"
TIE = 1e-12


def _st():
    return load_study(STUDY)


def group_of(st, owner, reader):
    if owner == reader:
        return "home"
    if (owner, reader) in st.upgrade_pairs:
        return "upgrade"
    if (reader, owner) in st.upgrade_pairs:
        return "downgrade"
    return "cross"


# --------------------------------------------------------------------------- Part A
def params_table(st) -> list:
    """Per model: parameters, no-memory success and repeat reliability on the real probe tasks."""
    rows = []
    for m in st.models:
        p = sim.model_params(m, st.models_cfg["models"][m])
        r = {"model": m, "maker": p["family"], "skill": p["skill"], "strength": p["strength"], "g": p["g"],
             "f": p["f"], "rel": p["rel"], "difficulty_sd": p["difficulty_sd"], "seed": p["seed"]}
        for stream in st.streams:
            nomem, icc_num, icc_den = [], [], []
            for seed in st.seeds:
                probe = st.splits(stream, seed)["probe"]
                write = st.write_ids(stream, seed)
                mus = np.array([mu(m, stream, t, None) for t in probe])
                nomem.extend(mus.tolist())
                # repeat reliability of a one-item call: share of the outcome variance that the
                # (task, item) explains, over the probe tasks x 4 write items of this model
                rng = np.random.default_rng(seed)
                mu1 = np.array([[mu(m, stream, t, f"{w}@{m}")
                                 for w in rng.choice(write, 4, replace=False)] for t in probe])
                icc_num.append(mu1.var())
                icc_den.append(mu1.var() + np.mean(mu1 * (1 - mu1)))
            r[f"nomem_{stream}"] = round(float(np.mean(nomem)), 3)
            r[f"reliability_{stream}"] = round(float(np.mean(icc_num) / np.mean(icc_den)), 3)
        rows.append(r)
    return rows


def corr_q(st, a, b) -> float:
    """Correlation of the item-quality parts of two models (formula of msr/sim.py)."""
    pa = sim.model_params(a, st.models_cfg["models"][a])
    pb = sim.model_params(b, st.models_cfg["models"][b])
    if a == b:
        return 1.0
    v = math.sqrt(pa["g"] * pb["g"])
    if pa["family"] == pb["family"]:
        v += math.sqrt(pa["f"] * pb["f"])
        if f"{a}#{pa['seed']}" == f"{b}#{pb['seed']}":
            v += math.sqrt(max(0, 1 - pa["g"] - pa["f"]) * max(0, 1 - pb["g"] - pb["f"]))
    return v


# --------------------------------------------------------------------------- Parts B and C
_ZERO: dict = {}


def graded_zero(stream: str) -> set:
    """Tasks the grader marks wrong whatever the simulator draws (a BIRD gold query that returns
    no rows, fails or times out, or a gold answer that does not grade right): true success 0."""
    if stream not in _ZERO:
        out = set()
        if stream == "bird":
            from msr import data as D
            from msr import grade as G
            G.set_disk_cache(D.DATA_DIR / "grade_cache")       # read the run's cached results
            excluded = set(load_study(STUDY).exclude_tasks)      # bird-0701: its gold never finishes
            for t in D.load_stream(stream):
                if t["task_id"] in excluded:
                    continue
                if not G.grade_detail("bird", t, sim.correct_answer("bird", t), faithful=False)["correct"]:
                    out.add(t["task_id"])
        _ZERO[stream] = out
    return _ZERO[stream]


@lru_cache(maxsize=None)
def mu(model: str, stream: str, task: str, item) -> float:
    return 0.0 if task in graded_zero(stream) else sim.true_success_prob(model, stream, task, item)


def _pairs(n):
    return list(itertools.combinations(range(n), 2))


def cell_truth(st, owner, reader, stream, seed, items_by_task, x_by_task=None, eval_tasks=None) -> dict:
    """Noise-free sums of one (owner, reader, stream, order) cell over its evaluation tasks."""
    do_all, dr_all = [], []
    vs = vh = 0.0
    n = 0
    for t in eval_tasks:
        its = [i for i in items_by_task.get(t, []) if i]
        if len(its) < 2:
            continue
        mo = [mu(owner, stream, t, i) for i in its]
        mr = mo if reader == owner else [mu(reader, stream, t, i) for i in its]
        xs = x_by_task[t] if x_by_task is not None else None
        n += 1
        for i, j in _pairs(len(its)):
            do, dr = mo[i] - mo[j], mr[i] - mr[j]
            do_all.append(do)
            dr_all.append(dr)
            if xs is not None and np.isfinite(xs[i]) and np.isfinite(xs[j]):
                dx = xs[i] - xs[j]
                s = 0.0 if abs(dx) <= TIE else math.copysign(1.0, dx)
                vs += s * dr
                vh += s * do
    do_a, dr_a = np.array(do_all), np.array(dr_all)
    out = {"owner": owner, "reader": reader, "group": group_of(st, owner, reader), "stream": stream, "seed": seed,
           "tasks": n, "pairs": len(do_a),
           "sum_do_dr": float((do_a * dr_a).sum()), "sum_do2": float((do_a ** 2).sum()), "sum_dr2": float((dr_a ** 2).sum()),
           "sum_do": float(do_a.sum()), "sum_dr": float(dr_a.sum()),
           "or_num": float((np.sign(do_a) * dr_a).sum()), "or_den": float(np.abs(do_a).sum())}
    if x_by_task is not None:
        out.update(v_swap=vs, v_home=vh)
    return out


def _rho(r):
    n = r["pairs"]
    if n < 3:
        return float("nan")
    mo, mr = r["sum_do"] / n, r["sum_dr"] / n
    cov = r["sum_do_dr"] / n - mo * mr
    vo, vr = r["sum_do2"] / n - mo * mo, r["sum_dr2"] / n - mr * mr
    return cov / math.sqrt(vo * vr) if vo > 0 and vr > 0 else float("nan")


def summarise(rows: list, keys: tuple) -> list:
    """Pool cells: sums for rho / slope / theta_or; per-cell MEAN V for theta_true."""
    agg = defaultdict(lambda: defaultdict(float))
    for r in rows:
        k = tuple(r[x] for x in keys)
        a = agg[k]
        for f in ("pairs", "sum_do_dr", "sum_do2", "sum_dr2", "sum_do", "sum_dr", "or_num", "or_den"):
            a[f] += r[f]
        if "v_swap" in r and r["tasks"]:
            a["mv_swap"] += r["v_swap"] / r["tasks"]
            a["mv_home"] += r["v_home"] / r["tasks"]
            a["has_v"] = 1
        a["cells"] += 1
    out = []
    for k, a in sorted(agg.items()):
        row = dict(zip(keys, k))
        row["cells"] = int(a["cells"])
        row["rho"] = round(_rho(a), 4)
        row["slope"] = round(a["sum_do_dr"] / a["sum_do2"], 4) if a["sum_do2"] else float("nan")
        row["theta_or"] = round(a["or_num"] / a["or_den"], 4) if a["or_den"] else float("nan")
        if a.get("has_v"):
            row["theta_true"] = round(a["mv_swap"] / a["mv_home"], 4) if a["mv_home"] else float("nan")
        out.append(row)
    return out


def items_from_candidates(st, owner, stream, seed) -> dict:
    p = st.bank_dir(owner, stream, seed) / "probe_candidates.jsonl"
    by = defaultdict(list)
    for line in p.read_text(encoding="utf-8").splitlines():
        if line.strip():
            r = json.loads(line)
            by[r["task_id"]].append((r["rank"], r["item_id"]))
    return {t: [i for _, i in sorted(v)] for t, v in by.items()}


def all_cells(st, source: str, family: str = "ema_grade") -> list:
    rows = []
    for stream in st.streams:
        for seed in st.seeds:
            calib, ev = st.calib_eval(stream, seed)
            for owner in st.models:
                if source == "candidates":
                    items = items_from_candidates(st, owner, stream, seed)
                    xs = None
                for reader in [r for o, r in st.cells if o == owner]:
                    if source == "scores":
                        z = np.load(st.results_dir / "cells" / f"{owner}__{reader}__{stream}__seed{seed}.npz")
                        tasks = z["tasks"].tolist()
                        items = {t: z["items"][e].tolist() for e, t in enumerate(tasks)}
                        xs = {t: z[f"score_{family}"][e] for e, t in enumerate(tasks)}
                    rows.append(cell_truth(st, owner, reader, stream, seed, items, xs, ev))
    return rows


def write_csv(path: Path, rows: list) -> None:
    if not rows:
        return
    keys = list(dict.fromkeys(k for r in rows for k in r))
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def md_table(rows: list, cols: list) -> str:
    lines = ["| " + " | ".join(cols) + " |", "|" + "---|" * len(cols)]
    for r in rows:
        lines.append("| " + " | ".join(str(r.get(c, "")) for c in cols) + " |")
    return "\n".join(lines)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("part", choices=("params", "candidates", "scores"))
    ap.add_argument("--family", default="ema_grade")
    a = ap.parse_args(argv)
    st = _st()
    if a.part == "params":
        rows = params_table(st)
        write_csv(OUT / "truth_models.csv", rows)
        print(md_table(rows, list(rows[0])))
        cq = [{"owner": o, "reader": r, "group": group_of(st, o, r), "corr_q": round(corr_q(st, o, r), 3)}
              for o, r in st.cells]
        write_csv(OUT / "truth_corr_q.csv", cq)
        print()
        print(md_table(cq, ["owner", "reader", "group", "corr_q"]))
        return 0
    rows = all_cells(st, a.part, a.family)
    tag = "candidates" if a.part == "candidates" else f"scores_{a.family}"
    write_csv(OUT / f"truth_cells_{tag}.csv", rows)
    pairs = summarise(rows, ("owner", "reader", "group", "stream"))
    pairs += summarise(rows, ("owner", "reader", "group"))
    for r in pairs:
        r.setdefault("stream", "all")
    write_csv(OUT / f"truth_pairs_{tag}.csv", pairs)
    groups = summarise(rows, ("group", "stream")) + [dict(r, stream="all") for r in summarise(rows, ("group",))]
    write_csv(OUT / f"truth_groups_{tag}.csv", groups)
    print(md_table(groups, list(groups[0])))
    return 0


if __name__ == "__main__":
    sys.exit(main())
