"""scoreswap.parity at the full size, with less memory (full-size dress rehearsal).

    python docs/dress_rehearsal/parity_light.py --only keep,recal_64 [--families ema_grade] [--workers 1]

The same comparison as `python -m scoreswap.parity` (same reference rules, same scorer call, same
columns, same tolerance 1e-9), but each cell's per-task file is opened, only the arrays of the arm
being checked are read, and nothing is kept between cells. scoreswap/parity.py keeps every cell's
whole per-task file in memory (`per_task_cache`): at the full size that is 384 cells x 7.8 MB = 3 GB,
and its run was killed for memory at a 2.5 GB cap (FAULTS.md). This script does not change scoreswap.
"""
from __future__ import annotations

import argparse
import math
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scoreswap import parity as PA  # noqa: E402
from scoreswap import scoring as SC  # noqa: E402
from scoreswap.pack import Pack  # noqa: E402


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pack", default=str(ROOT / "release" / "simfull"))
    ap.add_argument("--results", default=str(ROOT / "runs" / "simfull" / "results"))
    ap.add_argument("--only", default="keep,recal_64")
    ap.add_argument("--families", default=None)
    ap.add_argument("--workers", type=int, default=1)
    a = ap.parse_args(argv)
    pack_dir = Path(a.pack)
    pack = Pack(pack_dir, private=pack_dir.parent / f"{pack_dir.name}_private")
    res_dir = Path(a.results)
    only = a.only.split(",")
    fams_only = a.families.split(",") if a.families else None
    arms = {}
    for r in PA._read(res_dir / "arms.csv"):
        if r["arm"] in only:
            arms[(r["owner"], r["reader"], r["stream"], int(r["seed"]), r["family"], r["arm"])] = r
    print(f"Parity (light) of the scorer against {res_dir} (tolerance {PA.TOL:g}):", flush=True)
    bad = []
    for arm, fname, opts, draws, fams in PA.rules_to_check(pack):
        if arm not in only:
            continue
        k = int(arm.rsplit("_", 1)[1]) if arm.rsplit("_", 1)[-1].isdigit() else 0
        for fam in fams:
            if fams_only is not None and fam != "-" and fam not in fams_only:
                continue
            o = dict(opts)
            if fam != "-":
                o["family"] = fam
            res = SC.run_rule(pack, PA.REF / fname, k, draws=draws, options=o, trusted=True, workers=a.workers)
            worst_row = worst_task = 0.0
            where, n = "", 0
            for key, rec in res["cells"].items():
                ref = arms.get((*key, fam, arm))
                if ref is None:
                    continue
                n += 1
                for c in PA.ROW_COLS:
                    if c not in ref or ref[c] == "":
                        continue
                    d = PA._diff(PA._printed(rec["row"].get(c)), ref[c])
                    if d > worst_row:
                        worst_row, where = d, f"{key} {c}: scorer {rec['row'].get(c)} paper {ref[c]}"
                p = res_dir / "per_task" / f"{key[0]}__{key[1]}__{key[2]}__seed{key[3]}.npz"
                with np.load(p, allow_pickle=False) as z:
                    for mine, theirs in PA.TASK_KEYS.items():
                        name = f"{fam}|{arm}|{theirs}"
                        x = rec["arrays"].get(mine)
                        if x is None or name not in z.files:
                            continue
                        x, y = np.asarray(x, float), np.asarray(z[name], float)
                        if x.shape != y.shape or not np.array_equal(np.isnan(x), np.isnan(y)):
                            worst_task, where = math.inf, f"{key} per-task {mine}: missing values differ"
                            continue
                        ok = ~np.isnan(x)
                        if ok.any():
                            worst_task = max(worst_task, float(np.max(np.abs(x[ok] - y[ok]))))
            flag = "" if max(worst_row, worst_task) <= PA.TOL and n else f"   <- {where or 'no rows'}"
            print(f"  {arm:<12} {fam:<11} cells {n:>4}   max |difference|: arms.csv as printed {worst_row:.3g}, "
                  f"per-task values {worst_task:.3g}{flag}", flush=True)
            if flag:
                bad.append((arm, fam))
            del res
    print("ALL MATCH" if not bad else f"NOT MATCHING: {bad}", flush=True)
    return 0 if not bad else 1


if __name__ == "__main__":
    sys.exit(main())
