# config/sim_full.yaml against config/study.yaml

`diff config/study.yaml config/sim_full.yaml` shows these lines, and only these. Every other line
(sizes, k values, calibration tasks, passes, repeats, seeds 0/1/2, both streams, exclusions,
grading, prompt wording, embedding model, answer limit, workers, build, scores, probe, subsets,
evaluate, online and variants settings) is the same text.

| line in study.yaml | line in sim_full.yaml | why |
|---|---|---|
| header comment (6 lines on the paid run) | header comment (9 lines on the rehearsal) | says what the file is and how to run it |
| `name: study` | `name: simfull` | results go to `runs/simfull/`, never into the real run's folder |
| `models: [haiku-4.5, haiku-5.5, gpt-5.6-luna, gpt-6-luna, qwen3.5-27b, qwen3.8-27b, gemma-3-27b, gemma-4-31b]` | `models: [sim-a-old, sim-a-new, sim-b-old, sim-b-new, sim-c-old, sim-c-new, sim-d-old, sim-d-new]` | the eight simulated models, slot for slot (a = Claude, b = GPT, c = Qwen, d = Gemma) |
| (none) | `upgrade_pairs: [[sim-a-old, sim-a-new], [sim-b-old, sim-b-new], [sim-c-old, sim-c-new], [sim-d-old, sim-d-new]]` | study.yaml takes its four upgrades from `pairs:` in config/models.yaml, which lists only the real models. The rehearsal names them, in the same maker order, so `cross_cycle` gives the same pattern |
| `pairs: all  # ... come from config/models.yaml` | `pairs: all  # ... are upgrade_pairs above` | comment only |
| `extension: pairs: [[mistral-small-3, mistral-small-3.2], [deepseek-v4.1-flash, deepseek-v4.1-flash-1017]]` | `extension: pairs: [[sim-e-old, sim-e-new], [sim-f-old, sim-f-new]]` | the two extension pairs (revision 2, decision D9) on two simulated makers: e is an ordinary upgrade, f a "minor update" (95 % shared item quality, small skill step), like DeepSeek's |
| `second_bank_models: [haiku-4.5, qwen3.5-27b]` | `second_bank_models: [sim-a-old, sim-c-old]` | the same two slots |
| `extra_pairs: cross_cycle  # haiku-4.5 -> gpt-6-luna, ...` | `extra_pairs: cross_cycle  # sim-a-old -> sim-b-new, ...` | comment only; the value is the same |
| `variants.pairs: [[haiku-4.5, haiku-5.5], [haiku-5.5, haiku-4.5], [qwen3.5-27b, qwen3.8-27b], [qwen3.8-27b, qwen3.5-27b]]` | `[[sim-a-old, sim-a-new], [sim-a-new, sim-a-old], [sim-c-old, sim-c-new], [sim-c-new, sim-c-old]]` | the same slots |
| `token_factor: {haiku-5.5: 1.3}` | `token_factor: {sim-a-new: 1.3}` | the same slot; it only changes the token count in `--estimate` (simulated calls cost 0) |

The commented "Smaller options" block (six-model designs with real model names) is kept as it is in
study.yaml; it is a comment and is not read.

Checked by `tests/test_dress_rehearsal.py::test_same_design_as_the_real_study`: both files are loaded
with `msr.study.load_study` and every setting is compared after renaming the models to their slots.
Both plan exactly 3,330,000 calls since revision 2 (2,240,400 before; `estimate_simfull.txt` is the old one).

Revision 2 (pipeline phase 2, 24 Nov 2026): both files now have 5 passes (`build.epochs: 5`, the
budget; the pilot decides 3..6), the new stages (second write answer, self-rating, judge, relearn,
`reexplore_25` and `reexplore_50`) and the extension pairs, with the same lines in both. One setting
differs without a line in either file: `probe.repeat_gap_hours` defaults to 6 h when any model is a real
one and to 0 when every model is simulated (repeat 2 of a cell runs in a later session; simulated
models have no provider cache), so the rehearsal does not wait. The rehearsal folder `runs/simfull`
was made with 3 passes and no new stage: its re-run is a fresh run (the run refuses to mix them).

## How BIRD outcomes are made for simulated models

The simulated model does not write SQL of its own. For each call `msr/sim.py` draws right or wrong
from its true success probability (a hash of model, task, items and repeat, so the same call always
gives the same answer). When right it answers the task's gold SQL (the seven gold queries that start
with `WITH` are wrapped as `SELECT * FROM (...)`, which returns the same rows); when wrong it answers
`SELECT 1` (or `SELECT 0` / `SELECT -1` if the gold result happens to be exactly that one row).

That answer then goes through the ordinary grader, `msr.grade.grade_detail`, exactly as a real
model's answer would: the predicted and the gold SQL are run read-only on the BIRD SQLite database and
the result sets are compared. Results are cached per (database, SQL) in memory and, because the study
sets `llm.grade_cache: true`, also on disk under `data/grade_cache/`. So for simulated models the SQL
runs about twice per task (the gold query and the same query as an answer), once more per database
for `SELECT 1`, and every later call is a cache look-up.

Two consequences:
- The grader can overrule the simulator. A task whose gold query returns no rows, fails or times out
  is graded wrong for every answer (StreamBench's rule), whatever the simulator drew. The truth table
  (`truth.py`) uses the graded outcome for such tasks (probability 0). Checked on this machine: of the
  1,533 BIRD tasks in the study, none is in that case (only the excluded bird-0701, whose gold query
  never finishes), so here the grader and the simulator agree on every task.
- The SQL work of a real run is much larger: every DIFFERENT answer a real model writes is run once
  on its database. The rehearsal measured the gold queries (mean 0.26 s, median 0.016 s, slowest 18.5 s; `FAULTS.md`), from which the
  real run's grading time can be projected.
