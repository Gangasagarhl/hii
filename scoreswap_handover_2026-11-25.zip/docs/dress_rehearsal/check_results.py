"""Checks of the full-size dress rehearsal's results (runs/simfull/) against its shape and its truth.

    python docs/dress_rehearsal/check_results.py > docs/dress_rehearsal/checks.txt

Reads runs/simfull/results/*.csv, runs/simfull/analysis/*.csv and the truth tables written by
docs/dress_rehearsal/truth.py. Prints one line per check, starting with OK, NOTE or FAIL.
"""
from __future__ import annotations

import csv
import math
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from msr.study import load_study  # noqa: E402

HERE = Path(__file__).resolve().parent
st = load_study(ROOT / "config" / "sim_full.yaml")
RES = st.results_dir
ANA = st.dir / "analysis"
FAMS = list(st.scores.families)
USEFUL = [f for f in FAMS if f != "visits"]
fails = 0


def read(p: Path) -> list:
    with open(p, encoding="utf-8") as f:
        return list(csv.DictReader(f))


def num(v) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return float("nan")


def say(ok, text):
    global fails
    ok = None if ok is None else bool(ok)
    tag = "OK  " if ok is True else ("NOTE" if ok is None else "FAIL")
    if ok is False:
        fails += 1
    print(f"{tag} {text}")


def group(o, r):
    if o == r:
        return "home"
    if (o, r) in st.upgrade_pairs:
        return "upgrade"
    if (r, o) in st.upgrade_pairs:
        return "downgrade"
    return "cross"


cells = st.cells
streams = list(st.streams)

# ---------------------------------------------------------------- shape of results/
ret = read(RES / "retained.csv")
have = {(r["owner"], r["reader"], r["stream"], r["family"]) for r in ret}
want = {(o, r, s, f) for o, r in cells for s in streams + ["all"] for f in FAMS}
miss = want - have
say(not miss, f"retained.csv: {len(ret)} rows; every (owner, reader) of the {len(cells)} cells x {streams + ['all']} x "
              f"{len(FAMS)} families present" + (f" (missing {len(miss)}: {sorted(miss)[:4]} ...)" if miss else ""))
bad = [(r["owner"], r["reader"], r["stream"], r["family"], k) for r in ret for k in ("c_home", "c_swap", "drop", "v_home", "v_swap")
       if r["family"] != "visits" and not math.isfinite(num(r[k]))]
say(not bad, f"retained.csv: no NaN in c_home, c_swap, drop, v_home, v_swap of the usefulness families"
             + (f" ({len(bad)} NaN, e.g. {bad[:3]})" if bad else ""))
bad = [(r["owner"], r["reader"], r["stream"], r["family"]) for r in ret
       if r["theta_status"] == "defined" and not math.isfinite(num(r["theta"]))]
say(not bad, f"retained.csv: theta is a number wherever its status is 'defined' ({sum(r['theta_status'] == 'defined' for r in ret)} rows)"
             + (f" (NaN in {bad[:3]})" if bad else ""))
und = [(r["owner"], r["reader"], r["stream"], r["family"]) for r in ret
       if r["theta_status"] != "defined" and r["family"] in USEFUL]
say(None, f"retained.csv: theta undefined (home signal too weak) in {len(und)} usefulness-family rows"
          + (f", e.g. {und[:6]}" if und else ""))

val = read(RES / "validity.csv")
vk = {(r["owner"], r["reader"], r["stream"], r["seed"], r["family"]) for r in val}
wantv = {(o, r, s, str(k), f) for o, r in cells for s in streams for k in st.seeds for f in FAMS}
say(not (wantv - vk), f"validity.csv: {len(val)} rows; all {len(cells)} cells x {len(streams)} streams x "
                       f"{len(st.seeds)} orders x {len(FAMS)} families")

# shuffled control
sh = np.array([num(r["swap_shuffled"]) for r in val if r["family"] in USEFUL])
shh = np.array([num(r["home_shuffled"]) for r in val if r["family"] in USEFUL])
say(abs(np.nanmean(sh) - 0.5) < 0.01 and abs(np.nanmean(shh) - 0.5) < 0.01,
    f"shuffled control: mean Cw after the swap {np.nanmean(sh):.4f}, at home {np.nanmean(shh):.4f} "
    f"(per cell range {np.nanmin(sh):.3f} .. {np.nanmax(sh):.3f}); target 0.50")

# self-swap drop (home cells: drop = home vs extra repeats)
hd = [num(r["drop"]) for r in ret if r["owner"] == r["reader"] and r["stream"] == "all" and r["family"] == "ema_grade"]
th = [num(r["theta"]) for r in ret if r["owner"] == r["reader"] and r["stream"] == "all" and r["family"] == "ema_grade"]
say(abs(np.mean(hd)) < 0.02, f"self-swap (home cells, ema_grade, both streams): mean drop {np.mean(hd):+.4f} "
                             f"(range {min(hd):+.3f} .. {max(hd):+.3f}); theta mean {np.nanmean(th):.3f}")

# arms: every registered k
arms = read(RES / "arms.csv")
ks = sorted({int(a["arm"].rsplit("_", 1)[1]) for a in arms if a["arm"].startswith(("recal_", "powerprior_", "retest_", "audit_", "pooled_", "fresh_"))})
say(ks == [8, 16, 32, 64, 128, 256], f"arms.csv: {len(arms)} rows; fresh-check budgets present: {ks}")
per_arm = defaultdict(set)
for a in arms:
    per_arm[a["arm"]].add((a["owner"], a["reader"], a["stream"], a["seed"]))
n_combo = len(cells) * len(streams) * len(st.seeds)
short = {k: len(v) for k, v in per_arm.items() if len(v) < n_combo and k not in ("none", "relevance", "split_half", "ceiling")}
say(not short, f"arms.csv: every arm on all {n_combo} (cell, stream, order) combinations" + (f"; fewer for {short}" if short else ""))
nanv = [(a["arm"], a["family"]) for a in arms if not math.isfinite(num(a["value"]))]
say(not nanv, f"arms.csv: first-shown success (value) is a number in every row" + (f"; NaN in {sorted(set(nanv))[:6]}" if nanv else ""))

# ---------------------------------------------------------------- the analysis
if (ANA / "primary_tests.csv").exists():
    pt = read(ANA / "primary_tests.csv")
    fam = [r for r in pt if r.get("in_family") in ("True", "true", "1")]
    nsw = {r["group"]: r["n_swaps"] for r in pt}
    n_up = len(st.upgrade_pairs)
    n_cross = sum(1 for p in st.pairs if st.kind(*p) == "cross_family")
    say(len(fam) == 12 and nsw.get("upgrade") == str(n_up) and nsw.get("downgrade") == str(n_up)
        and nsw.get("cross") == str(n_cross),
        f"primary_tests.csv: {len(fam)} tests in the Holm family (12 registered); swaps per group {nsw} "
        f"(want {n_up} / {n_up} / {n_cross})")
    for r in fam:
        say(None, f"  {r['test']:<16} est {num(r['est']):+.4f} [{num(r['lo']):+.4f}, {num(r['hi']):+.4f}] "
                  f"p {num(r['p_holm_input']):.4g} -> {r['decision']}")
    tp = read(ANA / "theta_pairs.csv")
    rows = [r for r in tp if r["family"] == "ema_grade"]
    keys = {(r["owner"], r["reader"], r["level"]) for r in rows}
    wantp = {(o, r, lv) for o, r in st.pairs for lv in streams + ["all"]}
    say(not (wantp - keys), f"theta_pairs.csv (ema_grade): {len(rows)} rows; all {len(st.pairs)} swaps x {streams + ['all']}")
    tpf = {(r["family"], r["owner"], r["reader"], r["level"]) for r in tp}
    wantf = {(f, o, r, lv) for f in USEFUL for o, r in st.pairs for lv in streams + ["all"]}
    say(not (wantf - tpf), f"theta_pairs.csv: every usefulness family present for every swap and level"
                          + (f" (missing {len(wantf - tpf)})" if wantf - tpf else ""))
    tg = read(ANA / "theta_groups.csv")
    for r in tg:
        if r["family"] == "ema_grade" and r["level"] == "all":
            say(None, f"  theta group {r['group']:<11} n_swaps {r['n_swaps']:>2}: {num(r['theta']):.3f} "
                      f"[{num(r['theta_lo']):.3f}, {num(r['theta_hi']):.3f}] ({r['theta_status']})")

# ---------------------------------------------------------------- against the truth
tpath = HERE / "truth_pairs_scores_ema_grade.csv"
if tpath.exists():
    truth = {(r["owner"], r["reader"], r["stream"]): r for r in read(tpath)}
    if (ANA / "theta_pairs.csv").exists():
        est = {(r["owner"], r["reader"], r["level"]): r for r in read(ANA / "theta_pairs.csv") if r["family"] == "ema_grade"}
        src = "analysis/theta_pairs.csv (two-way intervals)"
    else:      # the analysis has not run: Stage C's own theta with its task-cluster interval
        est = {(r["owner"], r["reader"], r["stream"]): dict(r, theta_lo=r["theta_lo_task"], theta_hi=r["theta_hi_task"])
               for r in ret if r["family"] == "ema_grade" and r["owner"] != r["reader"]}
        src = "results/retained.csv (task-cluster intervals; the analysis has not run)"
    say(None, f"theta estimates from {src}")
    out = []
    cover = defaultdict(list)
    for (o, r, lv), e in est.items():
        t = truth.get((o, r, lv))
        if not t:
            continue
        tt, te, lo, hi = num(t["theta_true"]), num(e["theta"]), num(e["theta_lo"]), num(e["theta_hi"])
        out.append({"owner": o, "reader": r, "group": group(o, r), "level": lv, "theta_true": tt, "theta_hat": te,
                    "lo": lo, "hi": hi, "rho_true": num(t["rho"]), "theta_or": num(t["theta_or"]),
                    "covered": lo <= tt <= hi if math.isfinite(lo) and math.isfinite(hi) else ""})
        if math.isfinite(lo) and math.isfinite(hi):
            cover[(group(o, r), lv)].append(lo <= tt <= hi)
    with open(HERE / "theta_vs_truth.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(out[0]))
        w.writeheader()
        w.writerows(out)
    err = np.array([x["theta_hat"] - x["theta_true"] for x in out if x["level"] == "all"])
    say(None, f"theta vs truth, per swap pooled over streams: mean error {np.nanmean(err):+.4f}, "
              f"mean |error| {np.nanmean(np.abs(err)):.4f}, {len(err)} swaps")
    allc = [c for v in cover.values() for c in v]
    say(np.mean(allc) >= 0.85, f"95 % intervals of theta cover the noise-free truth in {np.mean(allc):.1%} of "
                               f"{len(allc)} (swap, level) rows; by group: "
                               + ", ".join(f"{g}/{lv} {np.mean(v):.0%}" for (g, lv), v in sorted(cover.items())))
    gt = {(r["group"], r["stream"]): r for r in read(HERE / "truth_groups_scores_ema_grade.csv")}
    for g in ("upgrade", "downgrade", "cross"):
        t = gt.get((g, "all"))
        if not (ANA / "theta_groups.csv").exists():
            break
        e = [r for r in read(ANA / "theta_groups.csv") if r["family"] == "ema_grade" and r["level"] == "all" and r["group"] == g]
        if t and e:
            say(num(e[0]["theta_lo"]) <= num(t["theta_true"]) <= num(e[0]["theta_hi"]),
                f"group {g}: theta {num(e[0]['theta']):.3f} [{num(e[0]['theta_lo']):.3f}, {num(e[0]['theta_hi']):.3f}] "
                f"against the truth {num(t['theta_true']):.3f}")
    # same maker above cross maker where the truth says so
    by = {(x["owner"], x["reader"]): x for x in out if x["level"] == "all"}
    cross_hat = np.nanmean([x["theta_hat"] for x in by.values() if x["group"] == "cross"])
    cross_true = np.nanmean([x["theta_true"] for x in by.values() if x["group"] == "cross"])
    for o, r in st.upgrade_pairs:
        for a, b in ((o, r), (r, o)):
            x = by.get((a, b))
            if not x:
                continue
            truth_above = x["theta_true"] > cross_true + 0.05
            hat_above = x["theta_hat"] > cross_hat + 0.05
            say(truth_above == hat_above,
                f"{a} -> {b}: theta {x['theta_hat']:.3f} [{x['lo']:.3f}, {x['hi']:.3f}], truth {x['theta_true']:.3f} "
                f"(rho {x['rho_true']:.3f}); cross-maker mean {cross_hat:.3f} (truth {cross_true:.3f}); "
                f"truth says {'above' if truth_above else 'not above'}, estimate {'above' if hat_above else 'not above'}")

# ---------------------------------------------------------------- gate lines
summ = (RES / "SUMMARY.md").read_text(encoding="utf-8") if (RES / "SUMMARY.md").exists() else ""
gl = [ln.strip() for ln in summ.splitlines() if ln.strip()[:3] in ("1. ", "2. ", "3. ", "4. ", "5. ")
      and ("PASS" in ln or "FAIL" in ln)]
say(None, f"SUMMARY.md gate lines: {len(gl)} ({sum('PASS' in x for x in gl)} PASS, {sum('FAIL' in x for x in gl)} FAIL)")
for x in gl:
    print("     " + x)
print(f"\n{fails} check(s) failed")
