"""Wall time and disk of the PAID full study from the pipeline's structure, for a given call latency.

    python docs/dress_rehearsal/project_real.py                          # 4, 8, 16 workers at 1 and 2 s per call
    python docs/dress_rehearsal/project_real.py --latency 1.5 --workers 16 --grade-s 0.26

Everyday picture: a kitchen's day is not "dishes / cooks". Some dishes must be cooked one after
another (a bank learns task by task), and a station that plates one table at a time waits for its
slowest plate. This counts the waiting slots of every stage of config/study.yaml, as msr/build.py,
msr/probe.py, msr/stages.py and msr/online.py schedule them, and multiplies by the time of one call.
The simulated rehearsal cannot measure that time (its models answer at once); a pilot or the smoke
test can. Assumes no rate limit and a steady latency.

Revision 2 (24 Nov 2026). What runs one after another now (from the code):
- write, write2 (second no-memory answer), selfrate (the writer's rating) and build0: one
  (model, stream, order) at a time, its calls `workers` at once;
- build, score phase: each bank is a sequential chain of passes x 500 tasks x (answer + self-tag);
  `workers` banks at once (84 banks: 72 + 12 second banks), taken in order;
- probe (no-memory runs, then the cells), probe_extra, subsets, wording: one cell at a time, its calls
  `workers` at once;
- judge: one cell at a time (72 cells per stream order), its 250 rating calls `workers` at once;
- relearn: each (owner, reader, stream, order) is a sequential chain like a bank (passes x 500 tasks,
  no self-tags); `workers` chains at once;
- online: ONE pool of `workers` runs over all cells; each run is a chain of 250 calls; runs start cell
  by cell; a credit-family run waits for its cell's `none` run. With equal runs and no waits this is
  ceil(runs / workers) x 250 call times (it was 72 x 500 before revision 2).
- BIRD grading: each answer is graded in the worker thread as its call returns (so it overlaps the
  other workers' calls), and the grade cache keeps big results as a fingerprint, so a SQL string is
  run once. A graded BIRD call therefore takes latency + (distinct share x seconds per SQL run) on
  average. Rating and tag calls are not graded.
- Every call also costs the pipeline's own work (`--overhead-ms`, measured in the rehearsal at about
  1-4 ms), counted once per slot.
The option `probe.check_store_extra_tasks` is costed but not built, so it is not timed here.
"""
from __future__ import annotations

import argparse
import heapq
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

#: Stages whose answers are graded (BIRD answers run SQL); the rest are tags and ratings.
GRADED = {"write", "write2", "build0", "build", "probe", "probe0", "probe_extra", "subset", "variant", "variant0",
          "relearn", "online"}
#: Earlier projection's grading assumption: 300,000 distinct BIRD answers among about 1.08 million graded
#: BIRD answers of the 3-pass study (2,240,400 calls less 90,000 self-tags, half of them BIRD), 0.09 s each.
DISTINCT_SHARE = 300_000 / ((2_240_400 - 90_000) / 2)

# Disk measured in the rehearsal (docs/dress_rehearsal/PROJECTION.md), GB on disk, 2,240,400 simulated calls.
REHEARSAL_CALLS = 2_240_400
REHEARSAL_GB = {"calls.jsonl": 1.6, "prompts/": 0.82, "banks/": 0.09,
                "probes/, probes0/, subsets/, variants/": 0.63, "online/": 0.02,
                "results/ (draws, per_task, sensitivity, rest)": 3.62}
REHEARSAL_TOTAL_GB = 6.6        # runs/simfull as measured; the parts above add to 6.8 (each part rounded up)
CACHE_FILE_KB = 4               # one answer file per fresh paid call, about 0.8 KB, one 4 KB block on disk


def pool_fifo(durations: list, workers: int) -> float:
    """Time for `workers` workers to take jobs in the given order (a ThreadPoolExecutor with every job
    submitted at once): each free worker takes the next job."""
    if not durations:
        return 0.0
    free = [0.0] * max(1, min(workers, len(durations)))
    end = 0.0
    for d in durations:
        t = heapq.heappop(free) + d
        end = max(end, t)
        heapq.heappush(free, t)
    return end


def online_pool(cells: list, workers: int) -> float:
    """msr.online._run_cells: ONE pool of `workers` runs. cells = [(durations, waits)], in order; a run
    whose `waits` is True starts only after its cell's first run (`none`) has finished."""
    t = 0.0
    running: list = []          # (finish time, cell, run)
    ready: list = []            # (cell, run)
    q = 0
    while True:
        while len(running) < workers:
            if ready:
                n, i = heapq.heappop(ready)
                heapq.heappush(running, (t + cells[n][0][i], n, i))
                continue
            if q < len(cells):
                for i, w in enumerate(cells[q][1]):
                    if not w:
                        heapq.heappush(ready, (q, i))
                q += 1
                continue
            break
        if not running:
            return t
        t, n, i = heapq.heappop(running)
        if i == 0 and any(cells[n][1]):
            for j, w in enumerate(cells[n][1]):
                if w:
                    heapq.heappush(ready, (n, j))


def stage_seconds(st, W: int, lat: float, ov: float, g: float) -> dict:
    """Seconds per stage at `W` calls at once, `lat` s per call, `ov` s of pipeline work per call and
    `g` s of grading per graded BIRD call."""
    from msr.study import subset_sizes

    def step(stream: str, graded: bool = True) -> float:
        return lat + ov + (g if graded and stream == "bird" else 0.0)

    def batch(n: int, t: float) -> float:          # one run_jobs of n calls, W at once
        return math.ceil(n / W) * t if n > 0 else 0.0

    B, P, O = st.build, st.probe, st.online
    n_items = B.n_write
    shown = min(B.n_show, B.candidates, n_items)
    k = min(P.candidates, n_items)
    combos = [(m, s, kk) for s in st.streams for kk in st.seeds for m in st.models]
    out: dict = {}
    out["write"] = sum(batch(B.n_write, step(s)) for _m, s, _k in combos)
    if B.write_repeat:
        out["write2"] = sum(batch(B.n_write, step(s)) for _m, s, _k in combos)
    if B.self_rating:
        out["selfrate"] = sum(batch(n_items, step(s, False)) for _m, s, _k in combos)
    if B.no_memory_run:
        out["build0"] = sum(batch(st.n_score, step(s)) for _m, s, _k in combos)
    chains = [B.epochs * st.n_score * (step(s) + (shown * step(s, False) if B.self_tag else 0.0))
              for m, s, _k in combos for _b in st.banks_of(m)]
    out["build score phase"] = pool_fifo(chains, W)

    readers = list(dict.fromkeys(r for _, r in st.cells))
    sec = 0.0
    for s in st.streams:
        for _kk in st.seeds:
            sec += sum(batch(st.sizes.n_probe * P.no_memory_repeats, step(s)) for _r in readers)
            sec += sum(batch(st.sizes.n_probe * k * P.repeats, step(s)) for _c in st.cells)
    out["probe"] = sec
    out["probe_extra"] = sum(batch(st.sizes.n_probe * k * P.home_extra_repeats, step(s)) for _m, s, _k in combos)
    sec = 0.0
    if P.subsets_enabled:
        per = P.subset_tasks * len(subset_sizes(k))
        sec += sum(batch(per, step(s)) for s in st.streams for _kk in st.seeds for _c in P.subset_cells)
    V = st.variants
    if V.enabled:
        vreaders = list(dict.fromkeys(r for _, r in V.cells))
        for s in st.streams:
            for _kk in st.seeds:
                sec += sum(batch(V.tasks * P.no_memory_repeats, step(s)) for _r in vreaders)
                sec += sum(batch(V.tasks * k * P.repeats, step(s)) for _c in V.cells)
    out["subsets + wording"] = sec
    if st.judge.enabled:
        out["judge"] = sum(batch(n_items, step(s, False)) for s in st.streams for _kk in st.seeds
                           for _c in st.judge.cells)
    if st.relearn.enabled:
        R = st.relearn
        rchains = [B.epochs * st.n_score * (step(s) + (shown * step(s, False) if R.self_tag else 0.0))
                   for s in st.streams for _kk in st.seeds for _p in R.pairs]
        out["relearn"] = pool_fifo(rchains, W)
    if O.enabled:
        cells = []
        for s in st.streams:
            for _kk in st.seeds:
                for _p in O.pairs:
                    durs, waits = [], []
                    has_none = "none" in O.arms
                    if has_none:
                        durs.append(st.sizes.n_test * step(s))
                        waits.append(False)
                    for a in O.arms:
                        if a == "none":
                            continue
                        for f in (["-"] if a == "relevance" else list(O.families)):
                            tag = O.learn and a != "relevance" and f == "tags_self"
                            n_show = min(O.n_show, n_items)
                            durs.append(st.sizes.n_test * (step(s) + (n_show * step(s, False) if tag else 0.0)))
                            waits.append(has_none and f == "credit")
                    cells.append((durs, waits))
        out["online"] = online_pool(cells, W)
    return out


def graded_bird_calls(plan: dict, streams: tuple) -> int:
    """Graded BIRD answers (every stage counts the same calls on each stream)."""
    n = sum(v for s, per in plan["calls"].items() if s in GRADED for v in per.values())
    return int(n * sum(1 for s in streams if s == "bird") / max(1, len(streams)))


def disk_lines(total_calls: int) -> list:
    r = total_calls / REHEARSAL_CALLS
    lines = [f"disk, the rehearsal's measured figures ({REHEARSAL_CALLS:,} calls) scaled by the call count "
             f"({total_calls:,} calls, x {r:.2f}):"]
    for part, gb in REHEARSAL_GB.items():
        lines.append(f"  {part:<52} {gb:>5.2f} GB -> {gb * r:>5.2f} GB")
    lines.append(f"  {'runs/<study> in all (measured ' + str(REHEARSAL_TOTAL_GB) + ' GB)':<52} "
                 f"{'':>14} {REHEARSAL_TOTAL_GB * r:>5.1f} GB")
    cache = total_calls * CACHE_FILE_KB * 1024 / 1e9
    lines.append(f"  {'runs/_cache/ (paid run only; one file per fresh call)':<52} {'':>14} {cache:>5.1f} GB "
                 f"({total_calls / 1e6:.2f} million files at most)")
    lines.append(f"  {'paid run in all':<52} {'':>14} {REHEARSAL_TOTAL_GB * r + cache:>5.1f} GB "
                 f"(plus some more in calls.jsonl if the real answers are long)")
    return lines


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--study", default=str(ROOT / "config" / "study.yaml"))
    ap.add_argument("--latency", type=float, nargs="+", default=[1.0, 2.0], help="seconds per call")
    ap.add_argument("--workers", type=int, nargs="+", default=[4, 8, 16])
    ap.add_argument("--overhead-ms", type=float, default=3.0, help="pipeline work per call (rehearsal: 1-4 ms)")
    ap.add_argument("--distinct-share", type=float, default=DISTINCT_SHARE,
                    help="distinct SQL strings per graded BIRD answer (each is run once)")
    ap.add_argument("--distinct-sql", type=int, default=0, help="or: distinct BIRD answers in all (overrides the share)")
    ap.add_argument("--grade-s", type=float, default=0.09, help="mean seconds per distinct SQL run")
    a = ap.parse_args(argv)
    from msr.study import load_study, plan_calls, total_calls
    st = load_study(a.study)
    plan = plan_calls(st)
    extra = sum(plan["calls"]["check_store"].values())             # an option: costed only, not built
    calls = total_calls(plan) - extra
    bird = graded_bird_calls(plan, st.streams)          # GRADED leaves check_store out
    share = a.distinct_sql / bird if a.distinct_sql and bird else a.distinct_share
    g = share * a.grade_s
    runs = len(st.online.pairs) * len(st.streams) * len(st.seeds) * sum(
        1 if x in ("none", "relevance") else len(st.online.families) for x in st.online.arms)
    print(f"{st.name}: {calls:,} calls; {len(st.models)} models, {len(st.cells)} cells, {st.build.epochs} passes, "
          f"{len(st.online.pairs)} online pairs x {len(st.online.arms)} arms ({runs} online runs)")
    print(f"BIRD grading: {bird:,} graded answers, {share:.3f} distinct per answer, {a.grade_s} s per distinct run: "
          f"{bird * g / 3600:.1f} h of grading work, done inside the workers ({g * 1000:.0f} ms per answer); "
          f"pipeline work {a.overhead_ms} ms per call")
    names = list(stage_seconds(st, 4, 1.0, 0.0, 0.0))
    print(f"{'workers':>7} {'lat s':>5} " + " ".join(f"{n[:12]:>12}" for n in names) + f" {'total h':>8} {'days':>5}")
    for W in a.workers:
        for lat in a.latency:
            s = stage_seconds(st, W, lat, a.overhead_ms / 1000, g)
            tot = sum(s.values()) / 3600
            print(f"{W:>7} {lat:>5.1f} " + " ".join(f"{s[n] / 3600:>11.1f}h" for n in names)
                  + f" {tot:>8.1f} {tot / 24:>5.1f}")
    print()
    for line in disk_lines(calls):
        print(line)
    return 0


if __name__ == "__main__":
    sys.exit(main())
