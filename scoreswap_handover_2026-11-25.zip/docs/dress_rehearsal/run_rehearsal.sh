#!/usr/bin/env bash
# Full-size dress rehearsal runner (docs/dress_rehearsal/). Runs the given stages of
# config/sim_full.yaml one after the other and writes one line per stage to
# docs/dress_rehearsal/stage_metrics.tsv: wall time, calls added to the log, disk used by
# runs/simfull before/after (on disk and apparent), bytes this unit wrote (cgroup io.stat),
# and the peak memory of this unit's processes (anon = the programs' own memory; current =
# also the file cache the kernel charged to the unit), sampled every half second.
#
# Start it as a capped user unit so the shared machine stays usable:
#   systemd-run --user --unit msr-simfull -p MemoryMax=6G -p CPUQuota=500% \
#     --working-directory=<project> \
#     bash docs/dress_rehearsal/run_rehearsal.sh build probe probe_extra online
# Stop it only by name:  systemctl --user stop msr-simfull
set -u
cd "$(dirname "$0")/../.."
STUDY=config/sim_full.yaml
RUN=runs/simfull
OUT=docs/dress_rehearsal/stage_metrics.tsv
LOG=docs/dress_rehearsal/run_log.txt
CG=/sys/fs/cgroup$(cut -d: -f3 /proc/self/cgroup | head -1)
[ -f "$OUT" ] || printf 'stage\tstarted\tseconds\texit\tcalls_before\tcalls_after\tcalls_added\tdisk_kb_before\tdisk_kb_after\tapparent_kb_before\tapparent_kb_after\tunit_wbytes_stage\tpeak_anon_mb\tpeak_current_mb\tunit_memory_peak_mb\n' > "$OUT"

lines() { [ -f "$RUN/calls.jsonl" ] && wc -l < "$RUN/calls.jsonl" || echo 0; }
dkb() { [ -d "$RUN" ] && du -sk "$RUN" | cut -f1 || echo 0; }
akb() { [ -d "$RUN" ] && du -sk --apparent-size "$RUN" | cut -f1 || echo 0; }
wbytes() { awk '{for(i=1;i<=NF;i++) if($i ~ /^wbytes=/){split($i,a,"="); s+=a[2]}} END{print s+0}' "$CG/io.stat" 2>/dev/null || echo 0; }

for stage in "$@"; do
  c0=$(lines); d0=$(dkb); a0=$(akb); w0=$(wbytes); t0=$(date +%s.%N); started=$(date -Is)
  echo "=== $started stage $stage (cgroup $CG)" | tee -a "$LOG"
  if [ "$stage" = evaluate ]; then
    .venv/bin/python -u run.py --study "$STUDY" --stage evaluate >> "$LOG" 2>&1 &
  else
    .venv/bin/python -u run.py --study "$STUDY" --stage "$stage" >> "$LOG" 2>&1 &
  fi
  pid=$!
  pa=0; pc=0
  while kill -0 "$pid" 2>/dev/null; do
    an=$(awk '$1=="anon"{print $2}' "$CG/memory.stat" 2>/dev/null || echo 0)
    cu=$(cat "$CG/memory.current" 2>/dev/null || echo 0)
    [ "${an:-0}" -gt "$pa" ] && pa=$an
    [ "${cu:-0}" -gt "$pc" ] && pc=$cu
    sleep 0.5
  done
  wait "$pid"; rc=$?
  t1=$(date +%s.%N)
  c1=$(lines); d1=$(dkb); a1=$(akb); w1=$(wbytes)
  mp=$(cat "$CG/memory.peak" 2>/dev/null || echo 0)
  printf '%s\t%s\t%.1f\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%.0f\t%.0f\t%.0f\n' "$stage" "$started" \
    "$(echo "$t1 - $t0" | bc)" "$rc" "$c0" "$c1" "$((c1 - c0))" "$d0" "$d1" "$a0" "$a1" "$((w1 - w0))" \
    "$(echo "$pa / 1048576" | bc -l)" "$(echo "$pc / 1048576" | bc -l)" "$(echo "$mp / 1048576" | bc -l)" >> "$OUT"
  echo "=== $(date -Is) stage $stage exit $rc" | tee -a "$LOG"
  [ "$rc" -eq 0 ] || exit "$rc"
done
