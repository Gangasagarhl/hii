# recal: swap-day rule at budget k = 64

**Tasks scored: the DEV half of the evaluation tasks, which is public. You may have tuned on it, and a rule can memorise it, so this is a development number, not a ranking. The board ranks on the held-out TEST half, scored by the maintainers from your entry file.**

Scored from the frozen tables of study `simfull` with no model call (pack fingerprint `c2fb0957811b1fa7`). Each value is a mean over the evaluation tasks; 200 seeded draw(s), each task's value the mean over the draws. Differences use the same tasks and the same draws.

Brackets: 95 % intervals. Two-way = tasks and items both treated as sampled (pre-registration Part 4.1, the primary interval). Task-only = the task-id cluster bootstrap, 10,000 draws, seed 0 (secondary; the paper's tables of rule values use this one, so on all evaluation tasks they match it digit for digit).

First-shown success: the reader's success with the candidate the rule shows first (higher is better). Regret: the gap to the task's best candidate (lower is better). Theta: the share of the owner's home ranking signal (its `ema_grade` score with its own results) that the rule's order keeps for the reader; at a home cell the reader is the owner itself with the same results, so keep's theta there is exactly 1.

- Run unsealed (--trusted).

## By kind of swap, dev half (public) (streams pooled)

| kind | first-shown success | minus keep | minus wipe | minus fixed_0.5 | minus powerprior_64 | minus recal_64 | minus retest_64 | minus audit_64 | regret | log score (level-corrected) | theta | checks used |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| same-maker upgrades | 0.715 [0.702, 0.729] (task-only [0.704, 0.727]) | -0.014 [-0.019, -0.010] | 0.067 [0.056, 0.077] | -0.014 [-0.018, -0.009] | 0.006 [0.002, 0.010] | -0.000 [-0.000, -0.000] | 0.014 [0.006, 0.022] | -0.002 [-0.005, 0.001] | 0.213 | -0.640 [-0.646, -0.633] | 0.45 [0.40, 0.49] | 64.0 |
| same-maker downgrades | 0.593 [0.577, 0.609] (task-only [0.579, 0.607]) | -0.013 [-0.019, -0.008] | 0.075 [0.063, 0.087] | -0.013 [-0.017, -0.008] | 0.013 [0.008, 0.018] | -0.000 [-0.000, -0.000] | 0.014 [0.005, 0.024] | -0.005 [-0.008, -0.001] | 0.249 | -0.697 [-0.705, -0.690] | 0.71 [0.64, 0.78] | 64.0 |
| cross-maker swaps | 0.604 [0.592, 0.615] (task-only [0.593, 0.614]) | -0.016 [-0.019, -0.013] | 0.019 [0.015, 0.023] | -0.016 [-0.019, -0.014] | -0.001 [-0.002, 0.001] | -0.000 [-0.000, 0.000] | -0.022 [-0.025, -0.019] | -0.005 [-0.007, -0.004] | 0.280 | -0.678 [-0.680, -0.677] | 0.17 [0.15, 0.19] | 64.0 |
| home cells (each owner reading its own bank) | 0.693 [0.681, 0.706] (task-only [0.681, 0.705]) | -0.010 [-0.012, -0.008] | 0.111 [0.103, 0.120] | -0.008 [-0.010, -0.007] | 0.009 [0.006, 0.013] | -0.000 [-0.000, -0.000] | 0.041 [0.035, 0.047] | -0.001 [-0.003, 0.000] | 0.191 | -0.653 [-0.657, -0.649] | 0.94 [0.93, 0.94] | 64.0 |

### Every ordered pair, dev half (public)

| owner -> reader | kind | first-shown success | minus keep | minus wipe | regret | theta |
|---|---|---|---|---|---|---|
| sim-a-old -> sim-a-old | home | 0.706 [0.685, 0.728] | -0.011 | 0.127 | 0.187 | 0.97 |
| sim-a-old -> sim-a-new | same_maker_upgrade | 0.723 [0.702, 0.743] | -0.018 | 0.068 | 0.210 | 0.45 |
| sim-a-old -> sim-b-old | cross_maker | 0.527 [0.500, 0.553] | -0.021 | 0.003 | 0.325 | 0.14 |
| sim-a-old -> sim-b-new | cross_maker | 0.636 [0.615, 0.657] | -0.020 | 0.015 | 0.281 | 0.12 |
| sim-a-old -> sim-c-old | cross_maker | 0.384 [0.360, 0.408] | -0.016 | 0.008 | 0.323 | 0.13 |
| sim-a-old -> sim-c-new | cross_maker | 0.777 [0.756, 0.799] | -0.026 | 0.020 | 0.194 | 0.14 |
| sim-a-old -> sim-d-old | cross_maker | 0.617 [0.593, 0.641] | -0.031 | 0.018 | 0.279 | 0.17 |
| sim-a-old -> sim-d-new | cross_maker | 0.578 [0.556, 0.601] | -0.010 | 0.021 | 0.305 | 0.09 |
| sim-a-new -> sim-a-old | same_maker_downgrade | 0.666 [0.642, 0.690] | -0.023 | 0.091 | 0.223 | 0.73 |
| sim-a-new -> sim-a-new | home | 0.769 [0.745, 0.792] | -0.007 | 0.114 | 0.170 | 0.94 |
| sim-a-new -> sim-b-old | cross_maker | 0.537 [0.510, 0.564] | -0.015 | 0.023 | 0.294 | 0.24 |
| sim-a-new -> sim-b-new | cross_maker | 0.654 [0.629, 0.679] | -0.019 | 0.031 | 0.269 | 0.24 |
| sim-a-new -> sim-c-old | cross_maker | 0.385 [0.362, 0.408] | -0.015 | 0.036 | 0.304 | 0.26 |
| sim-a-new -> sim-c-new | cross_maker | 0.778 [0.758, 0.797] | -0.013 | 0.024 | 0.188 | 0.23 |
| sim-a-new -> sim-d-old | cross_maker | 0.595 [0.573, 0.616] | -0.030 | 0.024 | 0.303 | 0.23 |
| sim-a-new -> sim-d-new | cross_maker | 0.577 [0.555, 0.598] | -0.014 | 0.017 | 0.317 | 0.16 |
| sim-b-old -> sim-a-old | cross_maker | 0.636 [0.611, 0.660] | -0.024 | 0.042 | 0.268 | 0.28 |
| sim-b-old -> sim-a-new | cross_maker | 0.699 [0.679, 0.720] | -0.014 | 0.028 | 0.240 | 0.18 |
| sim-b-old -> sim-b-old | home | 0.633 [0.607, 0.660] | -0.010 | 0.128 | 0.214 | 0.94 |
| sim-b-old -> sim-b-new | same_maker_upgrade | 0.711 [0.685, 0.737] | -0.014 | 0.120 | 0.206 | 0.72 |
| sim-b-old -> sim-c-old | cross_maker | 0.394 [0.368, 0.420] | -0.010 | 0.026 | 0.315 | 0.22 |
| sim-b-old -> sim-c-new | cross_maker | 0.785 [0.767, 0.804] | -0.015 | 0.029 | 0.189 | 0.22 |
| sim-b-old -> sim-d-old | cross_maker | 0.616 [0.592, 0.641] | -0.016 | 0.034 | 0.277 | 0.29 |
| sim-b-old -> sim-d-new | cross_maker | 0.587 [0.566, 0.608] | -0.009 | 0.013 | 0.300 | 0.05 |
| sim-b-new -> sim-a-old | cross_maker | 0.594 [0.565, 0.622] | -0.003 | 0.011 | 0.295 | 0.17 |
| sim-b-new -> sim-a-new | cross_maker | 0.682 [0.660, 0.704] | -0.011 | 0.012 | 0.262 | 0.16 |
| sim-b-new -> sim-b-old | same_maker_downgrade | 0.628 [0.600, 0.656] | -0.010 | 0.096 | 0.235 | 0.73 |
| sim-b-new -> sim-b-new | home | 0.746 [0.722, 0.770] | -0.008 | 0.124 | 0.172 | 0.97 |
| sim-b-new -> sim-c-old | cross_maker | 0.410 [0.382, 0.438] | -0.016 | 0.036 | 0.315 | 0.23 |
| sim-b-new -> sim-c-new | cross_maker | 0.773 [0.753, 0.794] | -0.015 | 0.019 | 0.203 | 0.16 |
| sim-b-new -> sim-d-old | cross_maker | 0.599 [0.573, 0.624] | -0.014 | 0.025 | 0.284 | 0.23 |
| sim-b-new -> sim-d-new | cross_maker | 0.578 [0.559, 0.598] | -0.017 | 0.005 | 0.309 | 0.11 |
| sim-c-old -> sim-a-old | cross_maker | 0.586 [0.561, 0.611] | -0.023 | 0.017 | 0.302 | 0.16 |
| sim-c-old -> sim-a-new | cross_maker | 0.689 [0.668, 0.711] | -0.014 | 0.021 | 0.245 | 0.18 |
| sim-c-old -> sim-b-old | cross_maker | 0.546 [0.520, 0.571] | -0.018 | 0.025 | 0.301 | 0.24 |
| sim-c-old -> sim-b-new | cross_maker | 0.643 [0.620, 0.667] | -0.013 | 0.015 | 0.276 | 0.09 |
| sim-c-old -> sim-c-old | home | 0.499 [0.469, 0.529] | -0.005 | 0.131 | 0.217 | 0.96 |
| sim-c-old -> sim-c-new | same_maker_upgrade | 0.836 [0.818, 0.855] | -0.007 | 0.064 | 0.132 | 0.57 |
| sim-c-old -> sim-d-old | cross_maker | 0.619 [0.595, 0.643] | -0.028 | 0.030 | 0.287 | 0.14 |
| sim-c-old -> sim-d-new | cross_maker | 0.591 [0.570, 0.612] | -0.007 | 0.010 | 0.299 | 0.08 |
| sim-c-new -> sim-a-old | cross_maker | 0.603 [0.576, 0.629] | -0.013 | 0.018 | 0.285 | 0.24 |
| sim-c-new -> sim-a-new | cross_maker | 0.683 [0.660, 0.706] | -0.018 | 0.027 | 0.249 | 0.26 |
| sim-c-new -> sim-b-old | cross_maker | 0.535 [0.511, 0.559] | -0.019 | 0.011 | 0.321 | 0.21 |
| sim-c-new -> sim-b-new | cross_maker | 0.647 [0.622, 0.672] | -0.015 | 0.017 | 0.269 | 0.14 |
| sim-c-new -> sim-c-old | same_maker_downgrade | 0.509 [0.482, 0.536] | -0.010 | 0.116 | 0.223 | 1.16 |
| sim-c-new -> sim-c-new | home | 0.851 [0.834, 0.867] | -0.014 | 0.086 | 0.125 | 0.87 |
| sim-c-new -> sim-d-old | cross_maker | 0.603 [0.576, 0.630] | -0.013 | 0.029 | 0.284 | 0.24 |
| sim-c-new -> sim-d-new | cross_maker | 0.592 [0.571, 0.613] | -0.018 | 0.001 | 0.305 | 0.12 |
| sim-d-old -> sim-a-old | cross_maker | 0.605 [0.582, 0.629] | -0.025 | 0.031 | 0.278 | 0.16 |
| sim-d-old -> sim-a-new | cross_maker | 0.696 [0.670, 0.723] | -0.017 | 0.034 | 0.247 | 0.25 |
| sim-d-old -> sim-b-old | cross_maker | 0.543 [0.519, 0.567] | -0.020 | 0.013 | 0.316 | 0.07 |
| sim-d-old -> sim-b-new | cross_maker | 0.643 [0.621, 0.666] | -0.020 | 0.019 | 0.279 | 0.10 |
| sim-d-old -> sim-c-old | cross_maker | 0.405 [0.378, 0.432] | -0.017 | 0.020 | 0.336 | 0.15 |
| sim-d-old -> sim-c-new | cross_maker | 0.785 [0.767, 0.804] | -0.012 | 0.013 | 0.188 | 0.12 |
| sim-d-old -> sim-d-old | home | 0.714 [0.688, 0.739] | -0.004 | 0.137 | 0.182 | 0.99 |
| sim-d-old -> sim-d-new | same_maker_upgrade | 0.592 [0.573, 0.611] | -0.019 | 0.015 | 0.302 | 0.10 |
| sim-d-new -> sim-a-old | cross_maker | 0.571 [0.549, 0.594] | 0.004 | 0.001 | 0.310 | 0.04 |
| sim-d-new -> sim-a-new | cross_maker | 0.651 [0.627, 0.674] | -0.011 | 0.004 | 0.285 | 0.06 |
| sim-d-new -> sim-b-old | cross_maker | 0.551 [0.525, 0.577] | -0.013 | 0.011 | 0.320 | 0.19 |
| sim-d-new -> sim-b-new | cross_maker | 0.648 [0.623, 0.672] | -0.014 | 0.023 | 0.272 | 0.31 |
| sim-d-new -> sim-c-old | cross_maker | 0.375 [0.351, 0.399] | -0.014 | 0.012 | 0.328 | 0.13 |
| sim-d-new -> sim-c-new | cross_maker | 0.766 [0.746, 0.785] | -0.015 | 0.002 | 0.207 | 0.07 |
| sim-d-new -> sim-d-old | same_maker_downgrade | 0.568 [0.545, 0.591] | -0.011 | -0.003 | 0.317 | 0.03 |
| sim-d-new -> sim-d-new | home | 0.628 [0.609, 0.647] | -0.020 | 0.045 | 0.264 | 0.77 |

Per-stream values, the Brier scores, the uncorrected log score, Cw, both intervals of every number and the paper's rules' own values are in summary.csv and compare.csv; one row per cell is in cells.csv.
