# rank_focus_shrink: swap-day rule at budget k = 64

**Tasks scored: the DEV half of the evaluation tasks, which is public. You may have tuned on it, and a rule can memorise it, so this is a development number, not a ranking. The board ranks on the held-out TEST half, scored by the maintainers from your entry file.**

Scored from the frozen tables of study `simfull` with no model call (pack fingerprint `c2fb0957811b1fa7`). Each value is a mean over the evaluation tasks; 200 seeded draw(s), each task's value the mean over the draws. Differences use the same tasks and the same draws.

Brackets: 95 % intervals. Two-way = tasks and items both treated as sampled (pre-registration Part 4.1, the primary interval). Task-only = the task-id cluster bootstrap, 10,000 draws, seed 0 (secondary; the paper's tables of rule values use this one, so on all evaluation tasks they match it digit for digit).

First-shown success: the reader's success with the candidate the rule shows first (higher is better). Regret: the gap to the task's best candidate (lower is better). Theta: the share of the owner's home ranking signal (its `ema_grade` score with its own results) that the rule's order keeps for the reader; at a home cell the reader is the owner itself with the same results, so keep's theta there is exactly 1.

- Run unsealed (--trusted).

## By kind of swap, dev half (public) (streams pooled)

| kind | first-shown success | minus keep | minus wipe | minus fixed_0.5 | minus powerprior_64 | minus recal_64 | minus retest_64 | minus audit_64 | regret | log score (level-corrected) | theta | checks used |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| same-maker upgrades | 0.729 [0.716, 0.742] (task-only [0.717, 0.740]) | -0.001 [-0.009, 0.007] | 0.080 [0.070, 0.090] | -0.000 [-0.008, 0.007] | 0.019 [0.013, 0.026] | 0.013 [0.007, 0.019] | 0.027 [0.020, 0.034] | 0.011 [0.005, 0.018] | 0.199 | -0.643 [-0.649, -0.637] | 0.49 [0.44, 0.54] | 64.0 |
| same-maker downgrades | 0.601 [0.586, 0.617] (task-only [0.588, 0.615]) | -0.005 [-0.014, 0.005] | 0.084 [0.073, 0.094] | -0.004 [-0.013, 0.005] | 0.022 [0.014, 0.029] | 0.009 [0.001, 0.017] | 0.023 [0.016, 0.030] | 0.004 [-0.004, 0.012] | 0.241 | -0.700 [-0.708, -0.693] | 0.68 [0.61, 0.75] | 64.0 |
| cross-maker swaps | 0.637 [0.626, 0.648] (task-only [0.627, 0.648]) | 0.017 [0.014, 0.021] | 0.053 [0.049, 0.057] | 0.017 [0.014, 0.021] | 0.033 [0.030, 0.036] | 0.033 [0.031, 0.036] | 0.012 [0.009, 0.014] | 0.028 [0.025, 0.031] | 0.246 | -0.675 [-0.677, -0.674] | 0.43 [0.40, 0.46] | 64.0 |
| home cells (each owner reading its own bank) | 0.688 [0.676, 0.700] (task-only [0.677, 0.699]) | -0.015 [-0.020, -0.010] | 0.106 [0.098, 0.114] | -0.013 [-0.018, -0.009] | 0.004 [-0.001, 0.009] | -0.005 [-0.009, -0.001] | 0.036 [0.030, 0.041] | -0.007 [-0.011, -0.002] | 0.197 | -0.660 [-0.664, -0.656] | 0.80 [0.77, 0.83] | 64.0 |

### Every ordered pair, dev half (public)

| owner -> reader | kind | first-shown success | minus keep | minus wipe | regret | theta |
|---|---|---|---|---|---|---|
| sim-a-old -> sim-a-old | home | 0.692 [0.669, 0.715] | -0.025 | 0.113 | 0.201 | 0.78 |
| sim-a-old -> sim-a-new | same_maker_upgrade | 0.736 [0.715, 0.757] | -0.005 | 0.081 | 0.197 | 0.49 |
| sim-a-old -> sim-b-old | cross_maker | 0.569 [0.542, 0.596] | 0.021 | 0.045 | 0.283 | 0.38 |
| sim-a-old -> sim-b-new | cross_maker | 0.670 [0.647, 0.693] | 0.014 | 0.049 | 0.246 | 0.44 |
| sim-a-old -> sim-c-old | cross_maker | 0.425 [0.396, 0.454] | 0.025 | 0.049 | 0.282 | 0.30 |
| sim-a-old -> sim-c-new | cross_maker | 0.808 [0.785, 0.832] | 0.005 | 0.051 | 0.163 | 0.37 |
| sim-a-old -> sim-d-old | cross_maker | 0.644 [0.618, 0.669] | -0.005 | 0.045 | 0.253 | 0.36 |
| sim-a-old -> sim-d-new | cross_maker | 0.598 [0.576, 0.621] | 0.010 | 0.041 | 0.285 | 0.25 |
| sim-a-new -> sim-a-old | same_maker_downgrade | 0.673 [0.647, 0.698] | -0.017 | 0.098 | 0.216 | 0.75 |
| sim-a-new -> sim-a-new | home | 0.764 [0.740, 0.788] | -0.012 | 0.110 | 0.174 | 0.84 |
| sim-a-new -> sim-b-old | cross_maker | 0.559 [0.534, 0.584] | 0.007 | 0.046 | 0.272 | 0.42 |
| sim-a-new -> sim-b-new | cross_maker | 0.688 [0.662, 0.714] | 0.015 | 0.064 | 0.235 | 0.47 |
| sim-a-new -> sim-c-old | cross_maker | 0.394 [0.371, 0.417] | -0.006 | 0.044 | 0.295 | 0.28 |
| sim-a-new -> sim-c-new | cross_maker | 0.813 [0.795, 0.832] | 0.022 | 0.060 | 0.152 | 0.45 |
| sim-a-new -> sim-d-old | cross_maker | 0.645 [0.621, 0.669] | 0.021 | 0.074 | 0.253 | 0.57 |
| sim-a-new -> sim-d-new | cross_maker | 0.607 [0.586, 0.628] | 0.015 | 0.046 | 0.287 | 0.33 |
| sim-b-old -> sim-a-old | cross_maker | 0.666 [0.640, 0.693] | 0.007 | 0.073 | 0.237 | 0.52 |
| sim-b-old -> sim-a-new | cross_maker | 0.732 [0.710, 0.754] | 0.019 | 0.061 | 0.207 | 0.45 |
| sim-b-old -> sim-b-old | home | 0.620 [0.594, 0.647] | -0.023 | 0.115 | 0.227 | 0.74 |
| sim-b-old -> sim-b-new | same_maker_upgrade | 0.728 [0.704, 0.752] | 0.003 | 0.137 | 0.189 | 0.78 |
| sim-b-old -> sim-c-old | cross_maker | 0.427 [0.401, 0.453] | 0.023 | 0.060 | 0.281 | 0.44 |
| sim-b-old -> sim-c-new | cross_maker | 0.819 [0.799, 0.838] | 0.019 | 0.062 | 0.155 | 0.45 |
| sim-b-old -> sim-d-old | cross_maker | 0.644 [0.620, 0.669] | 0.012 | 0.062 | 0.250 | 0.50 |
| sim-b-old -> sim-d-new | cross_maker | 0.595 [0.572, 0.617] | -0.001 | 0.020 | 0.292 | 0.17 |
| sim-b-new -> sim-a-old | cross_maker | 0.639 [0.609, 0.669] | 0.042 | 0.056 | 0.250 | 0.48 |
| sim-b-new -> sim-a-new | cross_maker | 0.722 [0.699, 0.745] | 0.030 | 0.052 | 0.222 | 0.48 |
| sim-b-new -> sim-b-old | same_maker_downgrade | 0.633 [0.606, 0.660] | -0.005 | 0.101 | 0.230 | 0.65 |
| sim-b-new -> sim-b-new | home | 0.745 [0.720, 0.770] | -0.009 | 0.123 | 0.173 | 0.81 |
| sim-b-new -> sim-c-old | cross_maker | 0.417 [0.393, 0.440] | -0.009 | 0.043 | 0.308 | 0.30 |
| sim-b-new -> sim-c-new | cross_maker | 0.820 [0.800, 0.841] | 0.032 | 0.066 | 0.156 | 0.51 |
| sim-b-new -> sim-d-old | cross_maker | 0.634 [0.608, 0.661] | 0.022 | 0.061 | 0.248 | 0.48 |
| sim-b-new -> sim-d-new | cross_maker | 0.597 [0.576, 0.618] | 0.002 | 0.024 | 0.290 | 0.31 |
| sim-c-old -> sim-a-old | cross_maker | 0.615 [0.589, 0.640] | 0.006 | 0.045 | 0.273 | 0.35 |
| sim-c-old -> sim-a-new | cross_maker | 0.711 [0.690, 0.732] | 0.008 | 0.043 | 0.223 | 0.34 |
| sim-c-old -> sim-b-old | cross_maker | 0.571 [0.543, 0.599] | 0.007 | 0.050 | 0.276 | 0.44 |
| sim-c-old -> sim-b-new | cross_maker | 0.682 [0.659, 0.705] | 0.025 | 0.053 | 0.238 | 0.37 |
| sim-c-old -> sim-c-old | home | 0.489 [0.460, 0.518] | -0.015 | 0.121 | 0.228 | 0.67 |
| sim-c-old -> sim-c-new | same_maker_upgrade | 0.828 [0.810, 0.846] | -0.015 | 0.056 | 0.140 | 0.48 |
| sim-c-old -> sim-d-old | cross_maker | 0.655 [0.630, 0.680] | 0.008 | 0.066 | 0.251 | 0.44 |
| sim-c-old -> sim-d-new | cross_maker | 0.601 [0.577, 0.624] | 0.002 | 0.020 | 0.290 | 0.17 |
| sim-c-new -> sim-a-old | cross_maker | 0.650 [0.623, 0.678] | 0.034 | 0.065 | 0.238 | 0.72 |
| sim-c-new -> sim-a-new | cross_maker | 0.719 [0.697, 0.741] | 0.017 | 0.063 | 0.213 | 0.58 |
| sim-c-new -> sim-b-old | cross_maker | 0.593 [0.567, 0.618] | 0.039 | 0.069 | 0.264 | 0.60 |
| sim-c-new -> sim-b-new | cross_maker | 0.693 [0.669, 0.718] | 0.031 | 0.064 | 0.223 | 0.53 |
| sim-c-new -> sim-c-old | same_maker_downgrade | 0.475 [0.449, 0.501] | -0.044 | 0.082 | 0.257 | 0.57 |
| sim-c-new -> sim-c-new | home | 0.860 [0.845, 0.875] | -0.004 | 0.095 | 0.115 | 0.98 |
| sim-c-new -> sim-d-old | cross_maker | 0.651 [0.625, 0.678] | 0.035 | 0.078 | 0.236 | 0.63 |
| sim-c-new -> sim-d-new | cross_maker | 0.627 [0.606, 0.649] | 0.018 | 0.036 | 0.269 | 0.40 |
| sim-d-old -> sim-a-old | cross_maker | 0.638 [0.612, 0.663] | 0.007 | 0.064 | 0.246 | 0.39 |
| sim-d-old -> sim-a-new | cross_maker | 0.728 [0.702, 0.754] | 0.014 | 0.066 | 0.216 | 0.43 |
| sim-d-old -> sim-b-old | cross_maker | 0.588 [0.565, 0.610] | 0.025 | 0.058 | 0.272 | 0.31 |
| sim-d-old -> sim-b-new | cross_maker | 0.678 [0.652, 0.704] | 0.015 | 0.054 | 0.245 | 0.38 |
| sim-d-old -> sim-c-old | cross_maker | 0.441 [0.411, 0.472] | 0.019 | 0.056 | 0.300 | 0.35 |
| sim-d-old -> sim-c-new | cross_maker | 0.812 [0.793, 0.831] | 0.014 | 0.040 | 0.161 | 0.31 |
| sim-d-old -> sim-d-old | home | 0.701 [0.678, 0.724] | -0.016 | 0.125 | 0.195 | 0.78 |
| sim-d-old -> sim-d-new | same_maker_upgrade | 0.623 [0.602, 0.644] | 0.012 | 0.046 | 0.271 | 0.26 |
| sim-d-new -> sim-a-old | cross_maker | 0.607 [0.583, 0.630] | 0.040 | 0.036 | 0.275 | 0.56 |
| sim-d-new -> sim-a-new | cross_maker | 0.697 [0.673, 0.720] | 0.035 | 0.050 | 0.239 | 0.67 |
| sim-d-new -> sim-b-old | cross_maker | 0.591 [0.564, 0.617] | 0.027 | 0.050 | 0.281 | 0.73 |
| sim-d-new -> sim-b-new | cross_maker | 0.684 [0.659, 0.708] | 0.022 | 0.059 | 0.236 | 0.76 |
| sim-d-new -> sim-c-old | cross_maker | 0.425 [0.398, 0.451] | 0.035 | 0.062 | 0.278 | 0.53 |
| sim-d-new -> sim-c-new | cross_maker | 0.794 [0.774, 0.815] | 0.013 | 0.031 | 0.178 | 0.50 |
| sim-d-new -> sim-d-old | same_maker_downgrade | 0.625 [0.601, 0.650] | 0.047 | 0.054 | 0.260 | 0.75 |
| sim-d-new -> sim-d-new | home | 0.631 [0.613, 0.650] | -0.016 | 0.049 | 0.260 | 0.77 |

Per-stream values, the Brier scores, the uncorrected log score, Cw, both intervals of every number and the paper's rules' own values are in summary.csv and compare.csv; one row per cell is in cells.csv.
