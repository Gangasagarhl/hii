# keep: swap-day rule at budget k = 64

**Tasks scored: the DEV half of the evaluation tasks, which is public. You may have tuned on it, and a rule can memorise it, so this is a development number, not a ranking. The board ranks on the held-out TEST half, scored by the maintainers from your entry file.**

Scored from the frozen tables of study `simfull` with no model call (pack fingerprint `c2fb0957811b1fa7`). Each value is a mean over the evaluation tasks; 200 seeded draw(s), each task's value the mean over the draws. Differences use the same tasks and the same draws.

Brackets: 95 % intervals. Two-way = tasks and items both treated as sampled (pre-registration Part 4.1, the primary interval). Task-only = the task-id cluster bootstrap, 10,000 draws, seed 0 (secondary; the paper's tables of rule values use this one, so on all evaluation tasks they match it digit for digit).

First-shown success: the reader's success with the candidate the rule shows first (higher is better). Regret: the gap to the task's best candidate (lower is better). Theta: the share of the owner's home ranking signal (its `ema_grade` score with its own results) that the rule's order keeps for the reader; at a home cell the reader is the owner itself with the same results, so keep's theta there is exactly 1.

- Run unsealed (--trusted).

## By kind of swap, dev half (public) (streams pooled)

| kind | first-shown success | minus keep | minus wipe | minus fixed_0.5 | minus powerprior_64 | minus recal_64 | minus retest_64 | minus audit_64 | regret | log score (level-corrected) | theta | checks used |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| same-maker upgrades | 0.730 [0.716, 0.744] (task-only [0.717, 0.742]) | 0.000  | 0.081 [0.068, 0.094] | 0.001 [-0.002, 0.003] | 0.020 [0.014, 0.027] | 0.014 [0.010, 0.019] | 0.028 [0.019, 0.038] | 0.012 [0.009, 0.015] | 0.198 | -0.708 [-0.719, -0.696] | 0.54 [0.48, 0.60] | 0.0 |
| same-maker downgrades | 0.606 [0.589, 0.623] (task-only [0.591, 0.621]) | 0.000  | 0.088 [0.074, 0.103] | 0.001 [-0.002, 0.003] | 0.026 [0.019, 0.034] | 0.013 [0.008, 0.019] | 0.028 [0.016, 0.039] | 0.009 [0.006, 0.012] | 0.236 | -0.788 [-0.801, -0.775] | 0.82 [0.74, 0.91] | 0.0 |
| cross-maker swaps | 0.620 [0.608, 0.631] (task-only [0.609, 0.631]) | 0.000  | 0.035 [0.030, 0.041] | -0.000 [-0.001, 0.001] | 0.015 [0.012, 0.019] | 0.016 [0.013, 0.019] | -0.006 [-0.010, -0.001] | 0.011 [0.009, 0.013] | 0.264 | -0.799 [-0.806, -0.792] | 0.31 [0.28, 0.34] | 0.0 |
| home cells (each owner reading its own bank) | 0.703 [0.691, 0.716] (task-only [0.691, 0.715]) | 0.000  | 0.121 [0.112, 0.130] | 0.002 [0.000, 0.003] | 0.019 [0.015, 0.023] | 0.010 [0.008, 0.012] | 0.051 [0.044, 0.058] | 0.009 [0.008, 0.010] | 0.181 | -0.690 [-0.698, -0.683] | 1.00 [1.00, 1.00] | 0.0 |

### Every ordered pair, dev half (public)

| owner -> reader | kind | first-shown success | minus keep | minus wipe | regret | theta |
|---|---|---|---|---|---|---|
| sim-a-old -> sim-a-old | home | 0.717 [0.696, 0.739] | 0.000 | 0.139 | 0.176 | 1.00 |
| sim-a-old -> sim-a-new | same_maker_upgrade | 0.741 [0.719, 0.763] | 0.000 | 0.086 | 0.192 | 0.55 |
| sim-a-old -> sim-b-old | cross_maker | 0.548 [0.518, 0.579] | 0.000 | 0.024 | 0.304 | 0.27 |
| sim-a-old -> sim-b-new | cross_maker | 0.656 [0.628, 0.684] | 0.000 | 0.035 | 0.261 | 0.26 |
| sim-a-old -> sim-c-old | cross_maker | 0.400 [0.372, 0.428] | 0.000 | 0.024 | 0.307 | 0.26 |
| sim-a-old -> sim-c-new | cross_maker | 0.804 [0.779, 0.828] | 0.000 | 0.046 | 0.168 | 0.31 |
| sim-a-old -> sim-d-old | cross_maker | 0.648 [0.617, 0.679] | 0.000 | 0.049 | 0.248 | 0.34 |
| sim-a-old -> sim-d-new | cross_maker | 0.588 [0.561, 0.615] | 0.000 | 0.031 | 0.295 | 0.16 |
| sim-a-new -> sim-a-old | same_maker_downgrade | 0.689 [0.664, 0.715] | 0.000 | 0.114 | 0.200 | 0.87 |
| sim-a-new -> sim-a-new | home | 0.776 [0.751, 0.801] | 0.000 | 0.121 | 0.162 | 1.00 |
| sim-a-new -> sim-b-old | cross_maker | 0.552 [0.521, 0.583] | 0.000 | 0.039 | 0.279 | 0.39 |
| sim-a-new -> sim-b-new | cross_maker | 0.673 [0.644, 0.701] | 0.000 | 0.049 | 0.250 | 0.36 |
| sim-a-new -> sim-c-old | cross_maker | 0.400 [0.372, 0.428] | 0.000 | 0.051 | 0.289 | 0.39 |
| sim-a-new -> sim-c-new | cross_maker | 0.791 [0.769, 0.813] | 0.000 | 0.037 | 0.175 | 0.39 |
| sim-a-new -> sim-d-old | cross_maker | 0.624 [0.596, 0.653] | 0.000 | 0.054 | 0.274 | 0.41 |
| sim-a-new -> sim-d-new | cross_maker | 0.591 [0.564, 0.619] | 0.000 | 0.031 | 0.302 | 0.28 |
| sim-b-old -> sim-a-old | cross_maker | 0.659 [0.630, 0.688] | 0.000 | 0.066 | 0.244 | 0.48 |
| sim-b-old -> sim-a-new | cross_maker | 0.713 [0.688, 0.739] | 0.000 | 0.042 | 0.226 | 0.34 |
| sim-b-old -> sim-b-old | home | 0.643 [0.616, 0.671] | 0.000 | 0.138 | 0.204 | 1.00 |
| sim-b-old -> sim-b-new | same_maker_upgrade | 0.725 [0.696, 0.753] | 0.000 | 0.134 | 0.192 | 0.82 |
| sim-b-old -> sim-c-old | cross_maker | 0.404 [0.372, 0.436] | 0.000 | 0.037 | 0.305 | 0.33 |
| sim-b-old -> sim-c-new | cross_maker | 0.800 [0.777, 0.823] | 0.000 | 0.043 | 0.174 | 0.37 |
| sim-b-old -> sim-d-old | cross_maker | 0.632 [0.604, 0.660] | 0.000 | 0.050 | 0.262 | 0.41 |
| sim-b-old -> sim-d-new | cross_maker | 0.596 [0.570, 0.622] | 0.000 | 0.022 | 0.291 | 0.15 |
| sim-b-new -> sim-a-old | cross_maker | 0.597 [0.563, 0.631] | 0.000 | 0.014 | 0.293 | 0.25 |
| sim-b-new -> sim-a-new | cross_maker | 0.693 [0.665, 0.721] | 0.000 | 0.022 | 0.251 | 0.29 |
| sim-b-new -> sim-b-old | same_maker_downgrade | 0.638 [0.608, 0.668] | 0.000 | 0.106 | 0.225 | 0.79 |
| sim-b-new -> sim-b-new | home | 0.754 [0.729, 0.779] | 0.000 | 0.132 | 0.164 | 1.00 |
| sim-b-new -> sim-c-old | cross_maker | 0.426 [0.393, 0.458] | 0.000 | 0.052 | 0.299 | 0.36 |
| sim-b-new -> sim-c-new | cross_maker | 0.788 [0.762, 0.814] | 0.000 | 0.034 | 0.188 | 0.34 |
| sim-b-new -> sim-d-old | cross_maker | 0.613 [0.583, 0.642] | 0.000 | 0.039 | 0.270 | 0.34 |
| sim-b-new -> sim-d-new | cross_maker | 0.595 [0.570, 0.620] | 0.000 | 0.022 | 0.292 | 0.25 |
| sim-c-old -> sim-a-old | cross_maker | 0.609 [0.578, 0.640] | 0.000 | 0.039 | 0.279 | 0.32 |
| sim-c-old -> sim-a-new | cross_maker | 0.704 [0.678, 0.730] | 0.000 | 0.035 | 0.230 | 0.28 |
| sim-c-old -> sim-b-old | cross_maker | 0.564 [0.534, 0.594] | 0.000 | 0.043 | 0.283 | 0.37 |
| sim-c-old -> sim-b-new | cross_maker | 0.657 [0.628, 0.686] | 0.000 | 0.028 | 0.263 | 0.19 |
| sim-c-old -> sim-c-old | home | 0.504 [0.472, 0.536] | 0.000 | 0.136 | 0.213 | 1.00 |
| sim-c-old -> sim-c-new | same_maker_upgrade | 0.843 [0.823, 0.863] | 0.000 | 0.071 | 0.126 | 0.63 |
| sim-c-old -> sim-d-old | cross_maker | 0.647 [0.618, 0.676] | 0.000 | 0.058 | 0.259 | 0.30 |
| sim-c-old -> sim-d-new | cross_maker | 0.598 [0.572, 0.625] | 0.000 | 0.018 | 0.292 | 0.17 |
| sim-c-new -> sim-a-old | cross_maker | 0.616 [0.584, 0.648] | 0.000 | 0.031 | 0.272 | 0.43 |
| sim-c-new -> sim-a-new | cross_maker | 0.702 [0.677, 0.727] | 0.000 | 0.045 | 0.231 | 0.41 |
| sim-c-new -> sim-b-old | cross_maker | 0.554 [0.522, 0.586] | 0.000 | 0.030 | 0.303 | 0.46 |
| sim-c-new -> sim-b-new | cross_maker | 0.662 [0.630, 0.694] | 0.000 | 0.032 | 0.254 | 0.33 |
| sim-c-new -> sim-c-old | same_maker_downgrade | 0.518 [0.491, 0.546] | 0.000 | 0.126 | 0.213 | 1.23 |
| sim-c-new -> sim-c-new | home | 0.865 [0.848, 0.882] | 0.000 | 0.100 | 0.111 | 1.00 |
| sim-c-new -> sim-d-old | cross_maker | 0.616 [0.583, 0.649] | 0.000 | 0.042 | 0.271 | 0.36 |
| sim-c-new -> sim-d-new | cross_maker | 0.610 [0.583, 0.636] | 0.000 | 0.018 | 0.287 | 0.35 |
| sim-d-old -> sim-a-old | cross_maker | 0.631 [0.604, 0.658] | 0.000 | 0.057 | 0.253 | 0.27 |
| sim-d-old -> sim-a-new | cross_maker | 0.713 [0.684, 0.743] | 0.000 | 0.051 | 0.230 | 0.32 |
| sim-d-old -> sim-b-old | cross_maker | 0.563 [0.534, 0.592] | 0.000 | 0.033 | 0.296 | 0.21 |
| sim-d-old -> sim-b-new | cross_maker | 0.663 [0.635, 0.691] | 0.000 | 0.039 | 0.260 | 0.23 |
| sim-d-old -> sim-c-old | cross_maker | 0.422 [0.389, 0.455] | 0.000 | 0.037 | 0.319 | 0.26 |
| sim-d-old -> sim-c-new | cross_maker | 0.798 [0.775, 0.820] | 0.000 | 0.026 | 0.176 | 0.20 |
| sim-d-old -> sim-d-old | home | 0.717 [0.691, 0.743] | 0.000 | 0.141 | 0.178 | 1.00 |
| sim-d-old -> sim-d-new | same_maker_upgrade | 0.611 [0.587, 0.635] | 0.000 | 0.034 | 0.283 | 0.23 |
| sim-d-new -> sim-a-old | cross_maker | 0.567 [0.539, 0.595] | 0.000 | -0.003 | 0.314 | 0.11 |
| sim-d-new -> sim-a-new | cross_maker | 0.661 [0.633, 0.690] | 0.000 | 0.015 | 0.274 | 0.24 |
| sim-d-new -> sim-b-old | cross_maker | 0.564 [0.530, 0.597] | 0.000 | 0.023 | 0.308 | 0.34 |
| sim-d-new -> sim-b-new | cross_maker | 0.661 [0.632, 0.691] | 0.000 | 0.037 | 0.258 | 0.52 |
| sim-d-new -> sim-c-old | cross_maker | 0.389 [0.359, 0.419] | 0.000 | 0.026 | 0.313 | 0.33 |
| sim-d-new -> sim-c-new | cross_maker | 0.781 [0.757, 0.806] | 0.000 | 0.018 | 0.191 | 0.28 |
| sim-d-new -> sim-d-old | same_maker_downgrade | 0.579 [0.548, 0.610] | 0.000 | 0.008 | 0.306 | 0.24 |
| sim-d-new -> sim-d-new | home | 0.648 [0.626, 0.670] | 0.000 | 0.065 | 0.244 | 1.00 |

Per-stream values, the Brier scores, the uncorrected log score, Cw, both intervals of every number and the paper's rules' own values are in summary.csv and compare.csv; one row per cell is in cells.csv.
