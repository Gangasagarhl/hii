"""Run a command and copy its output with the elapsed seconds in front of every line.

    python docs/dress_rehearsal/tsrun.py <command ...>

Used by run_evaluate.sh so that the time of each evaluate job (one owner, stream and order: 8
cells) can be read from the log. The exit code is the command's.
"""
import subprocess
import sys
import time

t0 = time.time()
p = subprocess.Popen(sys.argv[1:], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
for line in p.stdout:
    sys.stdout.write(f"[{time.time() - t0:8.1f} s] {line}")
    sys.stdout.flush()
sys.exit(p.wait())
