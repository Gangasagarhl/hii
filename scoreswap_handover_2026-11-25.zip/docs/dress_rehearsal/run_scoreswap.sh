#!/usr/bin/env bash
# scoreswap on the rehearsal's release pack at the registered budget k = 64 (no model call).
set -u
cd "$(dirname "$0")/../.."
LOG=docs/dress_rehearsal/scoreswap_k64.txt
PY=".venv/bin/python -u docs/dress_rehearsal/tsrun.py .venv/bin/python -u"
run() { echo "=== $(date -Is) $*" >> "$LOG"; $PY "$@" >> "$LOG" 2>&1; echo "=== exit $?" >> "$LOG"; }
run -m scoreswap check scoreswap/reference_rules/keep.py --pack release/simfull --budget 64
run -m scoreswap check scoreswap/reference_rules/recal.py --pack release/simfull --budget 64
run -m scoreswap check examples/rank_focus_shrink.py --pack release/simfull --budget 64
run -m scoreswap score scoreswap/reference_rules/keep.py --pack release/simfull --budget 64 --out docs/dress_rehearsal/scores_k64
run -m scoreswap score scoreswap/reference_rules/recal.py --pack release/simfull --budget 64 --out docs/dress_rehearsal/scores_k64
run -m scoreswap score examples/rank_focus_shrink.py --pack release/simfull --budget 64 --out docs/dress_rehearsal/scores_k64
run -m scoreswap.parity --study simfull --pack release/simfull --only keep,recal_64 --workers 3
