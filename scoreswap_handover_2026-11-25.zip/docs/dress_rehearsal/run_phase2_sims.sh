#!/usr/bin/env bash
# Pipeline phase 2: the two small simulated studies end to end (free).
#   systemd-run --user --unit msr-p2-sims -p MemoryMax=8G -p CPUQuota=500% \
#     --working-directory=<project folder> bash docs/dress_rehearsal/run_phase2_sims.sh
set -u
cd "$(dirname "$0")/../.."
LOG=docs/dress_rehearsal/phase2_sims_log.txt
PY=".venv/bin/python -u docs/dress_rehearsal/tsrun.py .venv/bin/python -u"
step() { echo "=== $(date -Is) $*" >> "$LOG"; $PY "$@" >> "$LOG" 2>&1; echo "=== $(date -Is) exit $?" >> "$LOG"; }
step run.py --study config/sim_construct.yaml
step scripts/make_construct_assets.py --study sim_construct
rm -rf runs/sim_phase2
step run.py --study config/sim_phase2.yaml
step -m msr.analysis --study sim_phase2
