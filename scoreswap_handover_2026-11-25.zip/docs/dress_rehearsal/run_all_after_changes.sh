#!/usr/bin/env bash
# The ONE full re-run of the full-size rehearsal (config/sim_full.yaml, study `simfull`) after the
# revision-2 changes, as one command. Free: simulated models only, no key, no paid call.
#
# Start it only on the manager's word, as a capped user unit (the analysis needs up to 6.9 GB):
#   systemd-run --user --unit msr-simfull -p MemoryMax=8G -p CPUQuota=500% \
#     --working-directory=<project folder> bash docs/dress_rehearsal/run_all_after_changes.sh
# Stop it only by name:  systemctl --user stop msr-simfull     (every step can be started again)
#
# Options (environment variables):
#   FROM=<step>   start at this step (build, probe, probe_extra, judge, relearn, online, evaluate,
#                 truth, analysis, theory, sequential, forecast, construct, paper, export, parity);
#                 default build. Every calling step skips work already saved.
#   OLD=move|keep runs/simfull from the first rehearsal (3 passes, no new stage) cannot be mixed with
#                 the new design (run.py refuses). OLD=move (default) renames it to runs/simfull_rev1
#                 before the build; OLD=keep stops if it is still there.
#   PAPER_OUT=<folder>  where make_paper_assets.py writes (default runs/simfull/paper_assets; set
#                 paper/assets to feed the dry-run PDF).
#
# Order (manager, 24 Nov 2026): the calling stages, then evaluate, the analysis, theory / sequential /
# forecast, construct, paper assets, then `scoreswap export` with both packs, then the parity check.
# Each step's wall time, calls, disk and peak memory go to stage_metrics_rev2.tsv; output to
# run_all_log.txt (every line time-stamped).
set -u
cd "$(dirname "$0")/../.."
STUDY=config/sim_full.yaml
NAME=simfull
RUN=runs/$NAME
OUT=docs/dress_rehearsal/stage_metrics_rev2.tsv
LOG=docs/dress_rehearsal/run_all_log.txt
FROM=${FROM:-build}
OLD=${OLD:-move}
PAPER_OUT=${PAPER_OUT:-$RUN/paper_assets}
CG=/sys/fs/cgroup$(cut -d: -f3 /proc/self/cgroup | head -1)
PY=.venv/bin/python
STEPS=(build probe probe_extra judge relearn online evaluate truth analysis theory sequential forecast construct paper export parity)

lines() { [ -f "$RUN/calls.jsonl" ] && wc -l < "$RUN/calls.jsonl" || echo 0; }
dkb() { [ -d "$RUN" ] && du -sk "$RUN" | cut -f1 || echo 0; }
[ -f "$OUT" ] || printf 'step\tstarted\tseconds\texit\tcalls_added\tdisk_kb_after\tpeak_anon_mb\tunit_memory_peak_mb\n' > "$OUT"

step() {   # step <name> <command ...>: run it with time stamps, record its figures; stop on failure
  local name=$1; shift
  local c0 t0 started pid pa an rc
  c0=$(lines); t0=$(date +%s.%N); started=$(date -Is)
  echo "=== $started $name: $*" >> "$LOG"
  $PY -u docs/dress_rehearsal/tsrun.py "$@" >> "$LOG" 2>&1 &
  pid=$!; pa=0
  while kill -0 "$pid" 2>/dev/null; do
    an=$(awk '$1=="anon"{print $2}' "$CG/memory.stat" 2>/dev/null || echo 0)
    [ "${an:-0}" -gt "$pa" ] && pa=$an
    sleep 1
  done
  wait "$pid"; rc=$?
  printf '%s\t%s\t%.1f\t%s\t%s\t%s\t%.0f\t%.0f\n' "$name" "$started" "$(echo "$(date +%s.%N) - $t0" | bc)" "$rc" \
    "$(( $(lines) - c0 ))" "$(dkb)" "$(echo "$pa / 1048576" | bc -l)" \
    "$(echo "$(cat "$CG/memory.peak" 2>/dev/null || echo 0) / 1048576" | bc -l)" >> "$OUT"
  echo "=== $(date -Is) $name exit $rc" >> "$LOG"
  if [ "$rc" -ne 0 ]; then echo "step $name failed (exit $rc); see $LOG" >&2; exit "$rc"; fi
}

started=0
for s in "${STEPS[@]}"; do
  [ "$s" = "$FROM" ] && started=1
  [ "$started" = 1 ] || continue
  case "$s" in
    build)
      if [ -d "$RUN" ] && ! $PY -c "import sys; sys.path.insert(0, '.'); import run; from msr.study import load_study; sys.exit(1 if run._changed_sections(load_study('$STUDY')) else 0)"; then
        if [ "$OLD" = move ]; then
          [ -e runs/simfull_rev1 ] && { echo "runs/simfull_rev1 exists already; move it away first" >&2; exit 2; }
          mv "$RUN" runs/simfull_rev1
          [ -d release/simfull ] && mv release/simfull release/simfull_rev1
          [ -d release/simfull_private ] && mv release/simfull_private release/simfull_rev1_private
          echo "=== moved the first rehearsal to runs/simfull_rev1 (and its packs to release/simfull_rev1*)" >> "$LOG"
        else
          echo "runs/simfull is the first rehearsal's design; set OLD=move or move it yourself" >&2; exit 2
        fi
      fi
      step build $PY -u run.py --study $STUDY --stage build ;;
    probe|probe_extra|judge|relearn|online)
      step "$s" $PY -u run.py --study $STUDY --stage "$s" ;;
    evaluate)
      step evaluate $PY -u run.py --study $STUDY --stage evaluate ;;
    truth)       # the planted truth against the estimates (docs/dress_rehearsal/TRUTH.md, Parts B and C)
      step truth_candidates $PY -u docs/dress_rehearsal/truth.py candidates
      step truth_scores $PY -u docs/dress_rehearsal/truth.py scores ;;
    analysis)
      step analysis $PY -u -m msr.analysis --study $NAME ;;
    theory)
      step theory $PY -u -m msr.theory --study $NAME ;;
    sequential)
      step sequential $PY -u -m msr.sequential --study $NAME ;;
    forecast)
      step forecast $PY -u -m msr.forecast --study $NAME ;;
    construct)
      step construct $PY -u scripts/make_construct_assets.py --study $NAME ;;
    paper)
      mkdir -p "$PAPER_OUT"
      step paper $PY -u scripts/make_paper_assets.py --study $NAME --skip-analysis --out "$PAPER_OUT" ;;
    export)
      step export $PY -u -m scoreswap export --study $NAME --out release/$NAME --private-out release/${NAME}_private --force ;;
    parity)
      step parity $PY -u -m scoreswap.parity --study $NAME --pack release/$NAME --private release/${NAME}_private --workers 4
      step checks $PY -u docs/dress_rehearsal/check_results.py ;;
  esac
done
echo "=== $(date -Is) all steps done" >> "$LOG"
