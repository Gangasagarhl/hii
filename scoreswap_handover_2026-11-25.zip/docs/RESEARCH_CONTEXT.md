# Research context: the model-swap paper (read this first)

Written 17 November 2026 so the work can continue on another laptop.
If you are Claude reading this in a new session: this file is the hand-over. Read it fully, then read the files it lists before doing anything.

## 1. What the paper is

Working title: **"Do Memory Scores Survive a Model Swap? An Audit of Keep, Wipe and Discount Rules for Agent Memory"**. Target: ICML 2027 (abstract 14 Jan 2027, paper 22 Jan 2027).

Everyday story: a mechanic's helper keeps a box of repair tips, each with a score for how often it worked. The scores were earned with one helper. The garage hires a new helper (the AI model is replaced by the vendor). Are the old scores still right? On the day of the change, should we **keep** them, **wipe** them, trust them **halfway**, or **check a few cases first and then decide how much to trust them** (calibrated discount)?

The paper measures this on public benchmarks only (no company or customer data):
- **Streams:** StreamBench DDXPlus (medical diagnosis, 1,764 tasks) and BIRD (text-to-SQL, 1,534 tasks).
- **Released code:** MemRL's own code on the operating-system tasks.
- **Frozen score files:** RoMeRL's score files.
- **Models:** six, as three old-to-new pairs. That gives 12 ordered swaps: 3 upgrades, 3 downgrades and 6 cross-maker swaps.
- **Arms:** seven:
  - no memory
  - the new model's own memory
  - keep
  - wipe
  - fixed discount
  - calibrated discount (from 8, 16, 32 or 64 fresh checks)
  - re-scored (the ceiling)
- **Headline measure:** "retained validity". Among pairs of tips whose outcomes differ, how often does the tip with the higher old score really do better under the new model? 0.5 is a coin toss.

The full plan is in `reports/Model swap paper plan.html`, and a plain-words version is in `reports/Model swap paper explained.html`. Both are on GitHub in the Tempororay repo.

## 2. Where we are (17 Nov 2026)

The owner said: "now focus on implementing the research paper, real-world work. Plan first, then we discuss."

Four checks ran on 17 Nov. All four have finished, and their notes are in this folder.

### Repos and data: `repos_and_data.md`
- **Data:** fine.
  - The DDXPlus and BIRD counts match the plan.
  - The BIRD databases were downloaded and checked (330 MiB, MD5 OK, all 11 test databases present).
- **StreamBench must be patched before it runs on current models:**
  - It sends `temperature=0.0`, which current Claude models reject. The run then silently scores 0 after about 4 minutes of retries per call.
  - `logprobs=True` is hard-coded (`llms/oai_chat.py:24-29`).
  - The Claude wrapper reads the first block, which can be a thinking block (`claude.py:30`).
  - The SQL grader opens databases writable, so open them read-only.
  - It needs Python 3.10, while this machine has 3.12, so use conda.
- **MemRL:**
  - It needs the same temperature patch.
  - Use the train and validation files, not `os_interaction_data.json`.
  - The Q update is at `value_driven.py:195` (alpha 0.3, initial Q 0.5). Edit `q_cache.json` too, because it overrides the memory file.
  - It needs the Docker image `local-os/default`.
  - Claude works only through the OpenAI-compatible endpoint.
- **RoMeRL:**
  - Evaluation only, with no training code.
  - The scoring model is not stated.
  - It needs `text-embedding-3-large`.
- **Measured prompt sizes:**

  | Prompt | Tokens |
  |---|---:|
  | DDXPlus with one memory item | about 740 |
  | BIRD with one memory item | about 975 |
  | DDXPlus with 16 items | about 3,860 |

  The plan assumed 2,500 tokens per call. Probe calls (one item shown) are much cheaper than that.

### Models and prices: `models_and_prices.md` (read from vendor pages on 17 Nov)

| Maker | Pair | Price (USD per million tokens, input / output) |
|---|---|---|
| Anthropic | `claude-haiku-4-5-20251001` → `claude-haiku-5-5` | $1 / $5 → $0.10 / $0.50. Batch is 50% off. |
| OpenAI | `gpt-5.6-luna` → `gpt-6-luna` | $0.20 / $1.20 → $0.10 / $0.50. Batch is 50% off. |
| Qwen | `qwen3.5-27b` → `qwen3.8-27b` | Alibaba Model Studio first, DeepInfra as fallback. Together and Fireworks serve neither. Pin one provider and one precision. |

- **Embeddings:** `text-embedding-3-large` (OpenAI).
- **Risks:**
  - **Haiku 4.5 retirement:** it has no date guarantee. Anthropic's 60-day notice rule keeps it to about 16 Jan 2027 at the earliest. Check the deprecations page weekly. The fallback pair is `claude-sonnet-4-6` → `claude-sonnet-5-5`.
- **Control in every pair:**
  - Set thinking or reasoning on or off explicitly.
  - Compare cost per task, not per token (Haiku 5.5 counts about 30% more tokens).
  - There is no temperature on Claude, so repeats come from repeated runs.
  - Log the model and fingerprint fields of every response.
- **Self-hosting Qwen:** impossible on this machine (no GPU, 22 GB RAM).

### Design and cost: `design_and_cost_extract.md`
- **Calls per benchmark:** about 140,400 as planned, made up of:
  - build: 32,400
  - home probes: 28,800
  - no-memory runs: 7,200
  - cross probes: 57,600
  - live check: 14,400
- **MemRL leg:** about 36,000 calls.
- **Cost:**
  - **Plan's total:** about USD 700 at 2,500 tokens per call. The real prompt sizes are smaller for probes, so recompute with the measured sizes and the batch discounts.
  - **Uncounted controls:** about 90,000 calls and USD 150 per benchmark. These are the self-swap repeats, a second independent bank, separate helpful/harmful marking, and live arms.
- **Open design decisions** for the owner to settle before code. Details are in that file.
  1. Which embedding model, and whether to embed the task text or the lesson.
  2. Which score drives retrieval during the build: MemRL values or ACE counters.
  3. How ACE counters rank (for example helpful minus harmful), and whether marking is a separate call.
  4. How many items are shown per build attempt (one, or 3 to 5). This sets the bank size and whether the "150 items with 5+ visits" gate is reachable.
  5. Fresh checks for the calibrated rule must come from held-out probe tasks. The λ grid and the likelihood for MemRL values are unstated.
  6. The ceiling arm is too sparse to re-earn scores (about 800 probe slots over 600 to 1,200 items).
  7. Smaller choices:
     - how ties count in concordance
     - the units of the 3-point margin
     - whether scores keep updating on test tasks
  8. The same split per order is shared across all models. No-memory and home probes run once per model.

### Novelty re-check (finished 17 Nov): `novelty_recheck.md`
**The gap is still open in its exact form, but the claim must narrow.** No paper does all three of these:
- (a) carries earned per-item scores to a new model with the memory content held fixed
- (b) measures item-level rank validity after the swap
- (c) compares keep, wipe, fixed discount and power prior. No paper has a discount arm.

What was found:
- **"Does Your Agent's Memory Survive a Model Upgrade?"** is the Goyal and Ray paper (arXiv 2609.05339). It covers content only and has no per-item scores.
- **HEIRS (ICLR 2027 submission) is the closest.** After the model changes, it re-tests a few archived *skill versions* on 16+16 target tasks and beats both keep and rebuild. It works on whole skill versions, not per-item scores, and has no discount.
- **Also close (ICLR 2027 submissions):**
  - "When Can a Skill Library Trust Its Execution Records?" (abstract only): local trials against pooled records.
  - "Refreshing Agent Memory with Policy-Response Drift" (withdrawn): re-estimates each memory card's effect under a successor model, same-family Qwen only.
  - "Harmless Here, Harmful There": the same 6-model ordered-pair matrix design, but about safety.
  - ExpHarness.
  - MemCredit (arXiv 2611.15600) keeps scores without checking them.
- **Claims that are already taken, so don't make them:**
  - "memory does not port across models"
  - "re-testing a few on the new model beats keep or rebuild"
- **What is still new:**
  1. Scores, not content: the memory is frozen and only the per-item scores move.
  2. Item-level rank validity across 12 ordered swaps from 3 makers.
  3. The first keep / wipe / fixed discount / calibrated power prior comparison, with a curve of how many fresh checks are needed.
- **To do:**
  - Add a HEIRS-style "re-test the top few on the new model" rule as an extra arm.
  - Read the HEIRS, Execution Records, ExpHarness and Policy-Response Drift PDFs in a normal browser, because OpenReview blocks automated reading.
  - Search again in early January.

## 3. Next steps (not yet agreed with the owner)
1. Accept the narrowed claim from the novelty re-check (section 2), and add the HEIRS-style arm.
2. The owner settles the open design decisions in section 2.
3. **Accounts and keys:**
   - Anthropic exists already.
   - OpenAI (models and embeddings) is needed.
   - Alibaba Model Studio or DeepInfra is needed for Qwen.
   - Budget: about USD 700, with headroom to 1,400.
4. **Before the first paid run:** the dated prediction file. It holds:
   - the three predictions
   - the four primary comparisons
   - the margins: 5 points for a difference, 3 points either way for "no drop"
   - the go or no-go rule
5. Patch StreamBench and write the score layer: about 300 lines, with MemRL-style values, ACE-style counters, and the keep, wipe, discount and calibrated arms.
6. **Pilot:** DDXPlus, three models, 300 build tasks and 100 probe tasks, about 10,500 calls and about USD 24. Then the go or no-go on five numbers:
   - memory beats no memory by at least 5 points
   - home concordance is at least 0.60
   - repeat disagreement is under 15%
   - at least 150 items have five or more visits, and at least 30% of probe tasks have candidates whose outcomes differ
   - measured cost is within twice the estimate

   The plan's 22 Nov gate date will slip, so set a new date.
7. Log every call: prompt, raw answer, exact model ID, time, tokens, cost. The paper needs all of this, and the models retire.

## 4. Rules to keep (owner's standing rules)
- Plain, short words; an everyday story first.
- Use many agents in parallel and be fast.
- Deliver what was asked first.
- Push to GitHub only when the owner says so. In the repo <repository>, no assistant name and no Co-Authored-By line in commits.
- No names, emails or /home paths in public documents. Never put API keys in files or chat.
- The paper uses public benchmarks only. The project's hand-over files contain customer-derived column names, and none of that may enter the paper.
- Never promise acceptance. About one in four at ICML on the first try, with an experienced author.

## 5. Files in this bundle
- `research_notes/Model swap implementation/`: this file and the four check notes from 17 Nov, including novelty_recheck.md.
- `reports/Model swap paper plan.html` and `reports/Model swap paper explained.html`: the plan.
- `reports/Top venue niche and roadmap.md`, `reports/Final verified paper plan.md`, `reports/One month top venue paper idea.md`, `reports/Reinforced memory and harness research gaps.md`, `reports/research.html`: background and source links.
- `research_notes/Top venue niche and roadmap/`, `research_notes/Model swap idea leadership pitch/`, `research_notes/One month top venue paper idea/`, `research_notes/Reinforced memory and harness research gaps/`: the research notes behind them.
- `claude_memory/`: the assistant's memory files from the old laptop. These are the owner's working preferences and project history. Copy them into the new laptop's Claude memory folder (see HOW_TO_USE.txt).
