# Master plan: the model-swap benchmark paper (ICML 2027)

Written 23 November 2026 by the managing agent (Fable 5.2) after the deep research of the same day.
This file holds the decisions. The evidence behind them is in `reports/Model swap benchmark ICML plan.md`
and the five notes in `research_notes/Model swap benchmark ICML plan/`.
If this file and an older file disagree, this file wins.

## 0. The story, so everyone holds the same picture

A garage keeps a box of repair tips. Each tip has a score: how often it worked. The scores were
earned while one helper worked there. The helper is replaced (the vendor retires the AI model).
Are the old scores still right for the new helper? On the day of the change, what should the
garage do with them?

We build the test that answers this for any pair of AI models, run it on eight models, and give
the test away so others can run it on their own models and their own scoring methods.

## 1. What we claim, and what we do not

**Working name of the benchmark:** ScoreSwap. The name must be checked for clashes before use.

**The claim (new as of 23 Nov 2026):**
1. **The measurement.** With the memory content frozen, we measure whether per-item usefulness
   scores earned under one model still rank the items correctly under another model. We do this
   item by item, for every ordered pair of eight models from four makers.
2. **The rules.** We give the first head-to-head comparison of swap-day rules, each with its
   cost and a curve of how many fresh checks it needs:
   - keep
   - wipe
   - fixed discount
   - calibrated discount (power prior, and level-plus-slope recalibration)
   - re-test the top few
   - audit, then decide
   - pooled evidence
   - fresh-only evidence
3. **The benchmark.** We release it as a reusable benchmark:
   - frozen probe tables, so new rules can be scored offline with no API calls
   - a neutral file format for score banks
   - an adapter for outside memory systems
   - a one-command runner

**We do not claim** the following. We cite these results and include them as arms or controls:
- Keeping old memory helps the new model. Sources: MemRL appendix C.1, RoMeRL, EvoKernel.
- A model's own history beats other models' history on average. Sources: CHIME, Beyond Semantic Relevance.
- Re-testing a few candidates beats keep and rebuild. Source: HEIRS, for whole skill versions.
- Keep versus rescore versus audit after a change. Source: the judge-replacement paper.
- Per-example usefulness differs between models. Sources: Chang and Jia 2023, Nguyen and Wong 2023.
- The discount rule itself. It is the power prior of Ibrahim and Chen 2000, which is one step of
  discounted Thompson sampling at a known change point.

**Words to avoid:**
- "memory survives"
- "human feedback"
- "Q-learning". A reviewer of EvoKernel called this kind of update "an EMA-style value estimate", so
  we call it a reward moving average.

## 2. The benchmark design

### 2.1 Models: eight, as four old→new pairs, and every ordered pair is run

| Maker | Old → new | Route | Why |
|---|---|---|---|
| Anthropic | `claude-haiku-4-5-20251001` → `claude-haiku-5-5` | Anthropic API | Closed pair. Run first: Haiku 4.5 has no guaranteed life beyond 60 days' notice. |
| OpenAI | `gpt-5.6-luna` → `gpt-6-luna` | OpenAI API | Closed pair. |
| Qwen (open weights) | `Qwen3.5-27B` → `Qwen3.8-27B` | One pinned host (DeepInfra, fp8) | Never retires. Same size, Apache-2.0. |
| Google (open weights) | `gemma-3-27b` → `gemma-4-31b` | One pinned host (Parasail, fp8) | Never retires. A fourth family. |

- **Why four families and two open pairs:**
  - Reviewers' most common complaint about memory papers is "one model family".
  - Four families turned ACE's reviews, with one reviewer moving from 4 to 8.
  - Open weights keep the benchmark runnable after the closed models retire.
- **Every ordered pair** means 8 × 8 = 64 cells: 56 swaps plus 8 "home" cells. The picture on page 1 is this grid.
- **Thinking and reasoning are off on every model.** The setting is part of the model's identity and is logged.
  No temperature is sent on the closed models. On open hosts, sampling values are set explicitly, because the hosts'
  defaults differ.
- **Optional fifth pair** if time allows: `gemini-3.1-flash-lite` → `gemini-3.5-flash-lite`, using exact IDs only.

**Keys needed** (owner): Anthropic (held), OpenAI, and OpenRouter. One OpenRouter key reaches both open pairs,
with the host pinned and fallbacks off.

### 2.2 Tasks

| Leg | Task | Role | Status |
|---|---|---|---|
| L1 | DDXPlus (medical diagnosis, StreamBench) | Core, full grid | Data ready |
| L2 | BIRD (text-to-SQL). If the pilot shows no memory gain, DS-1000 replaces it. | Core, full grid | Data ready; gated on the pilot |
| L3 | LifelongAgentBench OS tasks, run on **MemRL's own released code** | Outside-code check on the 4 upgrade pairs, both directions | To build |
| L4 | AppWorld (multi-step agent task), reduced size | Stretch: answers "only simple tasks" | Only if L1–L3 are done by 12 Dec |
| L5 | "Beyond Gain" released skill scores under 4 models | Free outside check, no API calls | To build now |

- **BIRD grader:** StreamBench's grader marks answers that start with `WITH` or lowercase `select` as wrong. That
  would punish some models more than others. Our primary grading fixes this (`faithful=False`), and we report the
  original as a sensitivity check.
- **BIRD licence:** the terms conflict (BY-SA on the site, BY-NC in the datasheet). We release task IDs and model
  outputs, not BIRD's text.
- **Dropped, with reasons in the research note:** HLE, ALFWorld, ToolBench, Spider, tau2, WebArena.

### 2.3 Splits

Three stream orders, seeds 0, 1 and 2. Each is cut into parts that share no task:
- 750 build tasks: 250 "write" tasks that become the memory items, then 500 "score" tasks that earn the scores.
- 500 probe tasks: 400 for evaluation and 100 used only to draw "fresh checks".
- 250 test tasks, for the run after the swap.

That is 1,500 tasks, which fits both streams (BIRD has 1,534).

The pilot uses seed 99, and its data never enters the main analysis.

The probe size changed from the old plan's 200 tasks. The power simulation showed 200 per order is too weak
to show "no drop". At 400 per order and 2 repeats:
- Power to see a 5-point drop is about 0.96 after correction.
- Power for the one-sided "no drop" test is about 0.80 to 0.86.

### 2.4 Building the memory (per model, stream and order)

Revised on 23 Nov after the first dry run. That run showed that when items are written and scored in the same
pass, each item is shown about once, which is far too few times to pin a score down.

- **Write phase (250 tasks):** the model answers with no memory. Each task and its answer becomes one memory
  item. After this the content is frozen.
- **Score phase (500 tasks × 3 passes):**
  - Retrieve the 4 most relevant items.
  - Show 1 of them. It is chosen by the mix 0.5 × score + 0.5 × relevance, with 30% exploration.
  - Answer, get graded by program, and update that item's scores.

  That gives about 1,500 visits over 250 items, around 6 per item. One item is shown at a time so the credit is
  clean; the dry run showed that showing 3 together made the scores worse.
- **Item content:** the task plus the model's answer, **without** a right/wrong label (StreamBench's plain "shot"
  style). All items are stored, right or wrong.
  - **Why unlabelled:** this is the setting where a score matters, because the score is the only sign of an
    item's quality. With labelled items the content already says whether to trust it.
  - **Sensitivity check:** the labelled style ("memprompt") is run in the pilot and on two pairs.
- **Selection probability:** every selection logs its probability, so the scores can be corrected for the fact that
  popular items get shown more.
- **No-memory run:** a run of the same tasks with no memory gives the baseline.
- **Second bank:** an independent bank for two models, built with a different exploration seed, measures how
  repeatable scores are.

### 2.5 Five score families, all kept on every item at once

| Family | Rule | Stands for |
|---|---|---|
| `ema_grade` | Moving average of the program's grade (step 0.3, start 0.5, reward 1 or 0). **This one drives retrieval during the build.** | MemRL, RoMeRL, EvoKernel, ExpHarness |
| `beta_grade` | Counts of graded successes and failures, as a Beta(1,1) posterior | Memp, ReMe, EvolveR |
| `tags_self` | The model's own helpful or harmful tag for each shown item, given **without** seeing the grade | ACE; ExpeL and CHIME rank by self-given scores |
| `credit` | Success with the item minus success without it, on the same task | MemCredit, Causal Memory Policy |
| `visits` | How often the item was shown. This is a baseline with no usefulness signal. | — |

Two things the paper must state:
- **MemRL's starting value.** MemRL's paper lists a start of 0 with rewards in [−1, 1], while its released code for
  these tasks uses 0.5 with rewards 1 and 0. The two differ only by a shift and scale, so they give the same ranking.
- **ACE's counters.** ACE's released code never ranks by its counters. Ranking by them is our choice.

### 2.6 The probe table (the heart of the benchmark)

For each bank owner and each reader model, on each of the 500 probe tasks:
- Take the owner's 4 most relevant items.
- Run the reader twice with exactly one item shown, and twice with none.
- Grade every answer by program.

The table then holds the true result of every choice. Any rule, including rules invented later by other people,
is scored by looking up the item it would pick, with no new model calls.

Extra pieces:
- **Noise floor:** home cells get two more repeats. That is the same model, same scores, fresh runs.
- **Realism check:** on 100 probe tasks for the upgrade pairs, all 16 subsets of the 4 candidates are run. This gives
  exact Shapley values and shows whether "one item at a time" agrees with "items shown together". No paper has
  reported this comparison.
- **Second prompt wording:** run on a subset, for the Haiku and Qwen pairs.

### 2.7 Swap-day rules (arms)

| Arm | What it does | Fresh checks |
|---|---|---|
| `none` | No memory | 0 |
| `relevance` | Most relevant item, scores ignored | 0 |
| `keep` | Old scores as they are | 0 |
| `wipe` | Scores reset to the start value | 0 |
| `fixed_λ` | Old evidence counted at weight λ (0.1 to 0.9) | 0 |
| `shuffled` | Old scores handed to the wrong items. This is the **content-only control**. | 0 |
| `powerprior_k` | Weight chosen from k fresh checks, with the prior fitted to the old bank | k |
| `recal_k` | Level and slope refitted from k fresh checks | k |
| `retest_k` | Re-test the top candidates on a screen set, then confirm (HEIRS style) | k |
| `audit_k` | Check k cells, then choose keep or wipe | k |
| `pooled_k`, `fresh_k` | Old plus fresh evidence at full weight; fresh evidence only | k |
| `own` | The reader's own bank and scores | built by the reader |
| `oracle` | Best candidate by the reader's own measured results (cross-fitted) | upper bound |

- k is 8, 16, 32 or 64.
- Fresh checks come only from the 100 calibration tasks.
- **The power prior must not use a flat prior.** The simulation showed a flat prior gives a weight near 0.2 even when
  nothing changed.

### 2.8 What is measured

1. **Validity of the old scores (the headline).**
   - **Measure:** a concordance within each task, weighted by how much the outcomes differ. This is Harrell's C. 0.5 is chance.
   - **Where:** at home and after the swap.
   - **What we report:** the drop, and the **retained-validity ratio** (C_swap − 0.5) / (C_home − 0.5).
   - **Noise limit:** with 2 repeats, outcome noise caps the observable value near 0.75, so the split-half noise
     ceiling is always shown beside it.
2. **Decision quality of each rule.** The success of the item the rule would show first, and the regret against the best candidate.
3. **Held-out log score and Brier score** of each rule's predicted success. This is how the discount rules are
   judged. A single global discount does not change the ranking of a moving-average score, so it cannot be judged by concordance.
4. **The run after the swap.** The reader carries on with the 250 test tasks, starting from each rule's scores and
   still learning (content frozen, no exploration). We measure mean success, success in the first 100 tasks, and tasks needed to reach 95% of its own bank's level.
   This is run for the 8 same-family swaps and 4 cross-family swaps: each maker's old model to the next maker's
   new model, in the order Anthropic → OpenAI → Qwen → Gemma → Anthropic.
5. **Agreement on the top item and the top two.** Reported apart from concordance.
6. **Cost per rule:** calls, tokens and dollars.

### 2.9 Statistics (fixed before any paid main run)

- **Per-pair reporting.** Every result is reported for each ordered pair, never only as a pooled average.
- **Intervals:**
  - Paired comparisons on the same tasks.
  - Intervals by resampling tasks within each stream order. With only three orders, resampling the orders themselves is not valid.
- **Tests:**
  - A drop is claimed only if it is beyond the self-swap noise floor.
  - "No drop" is claimed only with a one-sided non-inferiority test, with a margin of one quarter of the home signal above chance.
  - Holm correction over the four primary comparisons.
- **The four primary comparisons**, all on the `ema_grade` family:
  1. The drop in validity from home to after the swap.
  2. Keep against wipe, on the success of the first-shown item.
  3. Fixed discount (weight 0.5) against keep, on held-out log score.
  4. Recalibration from 64 fresh checks against both keep and wipe, on log score.
- **Three groups of swaps.** Each comparison is tested on three groups, giving 12 tests under Holm:
  - the 4 same-family upgrades
  - the 4 same-family downgrades
  - the 48 cross-family swaps

  Every single pair is still shown with its own interval and a forest plot. The spread inside each group is
  reported too, so an average can never hide opposite effects.
- **Headline family fallback.** If `ema_grade` fails the pilot's gate 2, the headline family becomes the first that
  passes, in this fixed order: `beta_grade`, `credit`, `tags_self`.
- **Not independent pairs.** The 56 swaps are not independent, so the summary model has separate source-model and
  target-model effects, and results are re-checked leaving one model out.
- **Released data.** All per-task outputs are released.

### 2.10 Predictions registered in advance

- **P1:** retained validity rises with how often the two models agree on the same task-and-item cells.
- **P2:** the gap between keep and wipe shrinks as the new model's no-memory success rises.
- **P3:** self-given tags lose more validity than program-graded scores.
- **P4:** same-family upgrades retain more validity than cross-family swaps.

The prediction file (`prediction/PREREGISTRATION.md`, drafted 23 Nov) follows the ten-part layout in the statistics note.
Where it is more exact than this plan, it wins. It is frozen,
dated and hashed before the first paid main run, and reported pass or fail.

### 2.11 Two additions that make the paper more than a measurement (decided 23 Nov, evening)

A second deep research run (`reports/Paper upgrade options research.md`; 104 agents, every claim checked by three
verifiers) looked for something new to add. Two additions were chosen. Both are computed from the probe tables the
benchmark already builds, so they add almost no model calls.

**Addition 1: a law of score transfer, with a forecast before the swap.**
- **The story.** How well the old helper's scores work for the new helper depends on two things: how alike the two
  helpers are in which tips help them, and how noisy each helper's results are.
- **The law.** The part of the old scores' ranking value that reaches the new model equals the old value times one
  number, the "transfer slope": how strongly the new model's item usefulness follows the old model's.
- **A test with nothing to tune.** The slope can be measured without using the scores at all. So for every pair of
  models we can predict the after-swap validity from the home validity and the slope, and compare it with what we
  measure. A miss tells us the old scores carry something other than real usefulness.
- **What the law explains.**
  - Why the plain "retained" ratio moves with each model's noise, and how to correct for it.
  - Why one common discount cannot change a ranking.
  - How many fresh checks it takes before fresh evidence beats old evidence.
- **The forecast.** A cheap check with no memory at all (do the two models get the same tasks right and wrong?) is
  used to predict the slope before the swap. It is tested on models left out of the fit.
- **Honest limits.**
  - The textbook part (Kendall's formula, the attenuation correction) is cited, not claimed.
  - Eight models give few pairs, so the forecast may come out weak.
  - Verified papers do the pieces in other settings (classifiers under data shift, fine-tuning gain, jailbreak
    transfer). None was found for memory scores.

**Addition 2: a swap-day check that stops when it is sure.**
- **What it does.** It takes fresh checks one task at a time and stops as soon as it can say "keep" or "do not keep",
  with a controlled error rate.
- **Why.** It turns the paper's weak spot, that 8 to 64 fresh checks pin little down, into a measured answer: how
  many checks a keep-or-not decision really needs.
- **Honest limit.** The statistical technique is already used in LLM evaluation (ICLR 2025, ICML 2026, NeurIPS 2026),
  so we claim only the new question and decision.

**Not chosen.**
- Choosing which items to re-test: the evidence says it does not reliably beat random checks when the old model
  mispredicts the new one.
- Translating scores through anchor items, a wider "executor shift" taxonomy, and journal requirements: the run
  found no verified evidence on these, so they are neither chosen nor ruled out.

**Before the freeze.** Both additions are written into the pre-registration, from `docs/theory_prereg_text.md` and
`docs/forecast_sequential_prereg_text.md`, before any paid main run. Repeat the novelty search for both just before submission.

## 3. The pilot and its gate

- **Run:** DDXPlus and BIRD, seed 99, Haiku 4.5 and Haiku 5.5, at the main build size (250 write tasks, then
  500 score tasks × 3 passes), 200 probe tasks, 100 test tasks.
- **Cost:** about USD 25 to 40. The pipeline prints the exact estimate before it runs.
- **It also measures** real token counts and latency.

Go only if all five hold:
1. Memory beats no memory by at least 3 points for the old model at home, with an interval that excludes 0.
2. Home concordance is at least 0.58 for at least one score family, with the interval's lower end above 0.5.
3. Repeats of identical cells disagree in under 40% of cases. This is a check for broken settings, and the number
   is always reported.
4. At least 150 items have 5 or more visits, and at least 30% of probe tasks have candidates whose outcomes differ.
5. Measured cost per 1,000 calls is within twice the estimate.

- **Which model:** gates 1, 2 and 4 are judged on the old model (Haiku 4.5). Gate 2 counts the four usefulness
  families, not `visits`.
- **If gate 2 or 4 fails:** re-run once with 6 score passes and the same exploration. Nothing else changes.
- **If it fails twice:** the finding becomes "scores are weak even before a swap". That is a different, smaller paper,
  for TMLR or NeurIPS.
- **BIRD:** it stays only if memory gains at least 3 points with an interval that excludes 0. Otherwise DS-1000 is
  checked the same way. If both fail, the main study runs on DDXPlus plus the MemRL-code leg, logged as a deviation.

## 4. Budget

| Part | Rough cost (USD) |
|---|---|
| Probe tables, two streams, full grid | 280 |
| Builds (3 epochs, tags, no-memory runs) | 80 |
| Runs after the swap | 70 |
| Realism check, second prompt wording, noise floor | 60 |
| MemRL-code leg | 50–220 |
| Pilot and re-runs | 60 |
| **Total** | **about 600–800; ask for a cap of 1,000** |

- **By key:** Anthropic about 400, OpenAI about 150, OpenRouter about 250.
- **Haiku 4.5** is the largest single cost.
- **Guard:** the code stops at the cap in `config/models.yaml`. The cap is raised in steps: 30 for the pilot, then per leg.

## 5. Timetable (today is 23 November 2026)

| Dates | Work | Done when |
|---|---|---|
| 23–26 Nov | Framework complete; full dry run with simulated models; prediction file drafted; keys in place | `python run.py --study config/sim.yaml` recovers the simulation's known truth |
| 27–30 Nov | Pilot on DDXPlus and BIRD; build settings fixed; prediction file frozen | Five gate numbers; dated, hashed file |
| ~1 Dec | Re-read ICML's "late November" process update | Rules section updated |
| 1–8 Dec | L1 DDXPlus, full grid. **All Haiku 4.5 calls first.** | Probe tables for 64 cells × 3 orders |
| 6–13 Dec | L2 second stream; L5 outside check; realism check; second wording | Main table and Figure 1 on two streams |
| 10–18 Dec | L3 MemRL-code leg; runs after the swap; L4 only if on time | All arms scored |
| 16 Dec | ICLR 2027 decisions: re-check the closest papers | Related-work table updated |
| 18–20 Dec | Experiments frozen; analysis; figures | `results/` final |
| 20 Dec–5 Jan | Paper draft; every reference opened and logged; three rounds of mock review and revision | Full draft |
| 6–13 Jan | Release package (anonymous code, data, datasheet); AI disclosure; OpenReview profiles; author list | Abstract in by **14 Jan** (author list freezes) |
| 15–22 Jan | Final checks; submit | Paper in by **22 Jan** |

If the timetable slips by more than three days, cut in this order: L4, the fifth pair, the second wording, L3 down to two pairs.
Never cut the full grid on L1, the noise floor, or the content-only control.

## 6. The paper

- **Type:** ICML "Datasets, Evaluations and Benchmarks".
  - It needs no new algorithm.
  - It must state what the benchmark's results support, under what assumptions and limits.
  - It must address licences, provenance, contamination and intended use.
- **Title (working):** "Do Memory Scores Survive a Model Swap? A Benchmark of Keep, Wipe and Recalibrate Rules for Agent Memory". It says "scores", not "memory".
- **Abstract:** five sentences:
  1. The forced swap.
  2. The untested belief.
  3. What was measured, with its scale.
  4. The headline, per kind of swap.
  5. The rule and the release.
- **Page 1:** MemRL's untested sentence and the CHIME cell as the motivating example. The limits are stated plainly:
  program-graded and model-tagged scores, single-call tasks plus one agent leg, one item shown at a time with the realism check.
- **Figure 1:** the 8 × 8 grid of retained validity, with the home diagonal as the noise floor.
- **Main table:** one row per ordered pair, one column per rule, with intervals.
- **Related work:** a table of what each close paper measured and left out, and a paragraph on the classic methods our arms come from.
- **Pre-empting known reviewer complaints:** each has a named answer in the paper:
  - Four model families.
  - Intervals everywhere.
  - A cost table.
  - Simple baselines: relevance, visits, shuffled.
  - A formal definition of the metric.
  - Equal budgets across rules.
  - "A stronger model may not need memory", answered by P2.
  - An identifiability check before the swap.
- **Limitations section:** up front and specific. The ICML form tells reviewers to reward this.
- **AI Disclosure Statement (mandatory in 2027):**
  - Describe in detail the use of AI in ideas, design, code, analysis and drafting.
  - Specify every model that is part of the experiment.
  - The human authors are fully responsible.
- **References:**
  - Every one is opened and logged in `paper/reference_ledger.md` (link, quoted line, date) before it enters the paper.
  - One invented reference can mean desk rejection.
- **Not promised:** acceptance. Published rates are about one in four. The plan removes avoidable reasons for rejection;
  it cannot remove chance.

## 7. The release (what makes it a benchmark, not just a paper)

1. One-command runner: change a model name and a key, run, and get tables and figures.
2. Frozen probe tables with every raw answer, exact model ID, time, tokens and cost.
3. Score-bank file format: item text, embedding model, each score, visits, and the model and date that earned it.
4. Adapter interface, so an outside memory system can be scored.
5. Leaderboard definition, with two boards:
   - Score learners, by retained validity.
   - Swap-day rules, by regret, recovery and cost.
6. A script that rebuilds every number and figure in the paper from the released files.
7. Datasheet, licences per source, a contamination note and a canary string.
8. Open-weight pairs as the core that anyone can re-run.
9. Versioning and a maintenance note.
10. Anonymous hosting at submission. Croissant metadata is prepared for the NeurIPS fallback.

## 8. Risks

| Risk | Answer |
|---|---|
| Haiku 4.5 retirement notice | Run all its calls first; fallback pair Sonnet 4.6 → Sonnet 5.5 |
| Scores weak even at home | The pilot gate; a pre-agreed change to the build; otherwise the smaller paper |
| A close paper appears, or ICLR accepts HEIRS with new experiments | Re-check on 16 Dec and in early January; our arms already include theirs |
| ICML process changes (due late November) | Re-read about 1 Dec and before 14 Jan |
| Team without an eligible reviewer | Allowed for one paper; odds are lower. A co-author with a prior top-venue paper must be added before 14 Jan |
| Employer clearance and company data | Clearance in writing before any preprint or submission; public benchmarks only |
| Reading blocked on OpenReview | Owner opens four PDFs in a normal browser: HEIRS, Execution Records, ExpHarness, Harmless Here |

## 9. What only the owner can do

1. **Keys:** put the Anthropic, OpenAI and OpenRouter keys into `.env`.
2. **Spending cap:** agree to USD 1,000 in total, raised in steps.
3. **People and permissions:**
   - Publication clearance from the employer.
   - The author list, with real contributors and ideally one author with a prior top-venue paper.
   - An OpenReview profile for every author.
4. **Four PDFs:** open them in a browser and save them into `docs/papers/`.

## 10. How the work is run

- **Roles:**
  - Manager: Fable 5.2. It writes the plan, the decisions, the briefs and the reviews.
  - Workers: Opus 5.5 at extra-high effort. They do the research, code, tests, runs, analysis and drafting.
- **Per piece of work:** a brief, then a build with tests, then the manager's check, then the next piece.
- **Status** is kept in `docs/STATUS.md` and updated at each milestone.
- **Spending:** nothing paid runs without the cap covering it, and the cost is stated first.
