# Pre-registration text for the two additions (ready to insert before the freeze)

Drafted 23 Nov 2026 for `prediction/PREREGISTRATION.md`. Proposed place: a new **Part 8.4 (secondary, pre-specified,
always reported)** with its own Holm family, so that Parts 3, 5.1 and 7 do not change. Notation is that of Part 2.
Code: `msr/forecast.py`, `msr/sequential.py` (constants at the top of each file; the values below are those
constants). Nothing here may read a swap result before the freeze; the simulated study (`config/sim.yaml`) was used
only to choose the bet (A2.4) and to check the code.

---

## 8.4 Two additions (secondary, pre-specified)

### 8.4.0 The per-task statistic shared by both

For one cell (owner s, reader t, stream b, order o), headline family, task τ with candidate set K(τ) of n present
candidates (n ≥ 2), score x(i), and outcome values v(i):

```
a(τ; v) = Σ_{i<j in K(τ)} sgn(x(i) − x(j)) · (v(i) − v(j)) / M_n,     M_n = ⌊n/2⌋·⌈n/2⌉
sgn(d) = 0 if |d| ≤ 1e−12
```

- a ∈ [−1, 1]. A candidate with no valid repeat is left out (n counts the others); a task with n < 2 has no value.
- **Population values.** μ_home(s, b, o) = mean over evaluation tasks of a(τ; ȳ_home) (owner's own repeats 1–2);
  μ_swap(s→t, b, o) = mean over evaluation tasks of a(τ; ȳ) (reader's repeats 1–2). Means are over tasks with equal
  weight. Pooled over orders within a stream: mean over the stream's evaluation tasks. Over streams: the plain mean.
- **Retained share.** θ = T = μ_swap / μ_home (at each level of pooling).
- **Reportability.** T is reported only if μ_home ≥ 4 × SE(μ_home), SE from the bootstrap of Part 4.1, at the same level
  of pooling (the rule of Part 2.4). Otherwise "undefined: home signal too weak".

### 8.4.A Addition 1: a forecast before the swap

**A1.1 Predictor data.** For each model and order: every graded answer given with **no memory item** on the 250 write
tasks (write phase), the 500 score tasks (the no-memory run of Part 0.3), and the 100 calibration tasks (no-memory
probe repeats 1–2). Evaluation tasks are never used. Each model's answers to the same task are compared.

**A1.2 Predictors per ordered pair (A = owner s, B = reader t),** per stream from counts summed over the three orders,
then the mean over streams:
- error consistency ec = (c_obs − c_exp) / (1 − c_exp), with every run of A compared with every run of B on the same
  task; c_obs = share of comparisons where both are right or both wrong; p_A, p_B = success shares over the same
  comparisons; c_exp = p_A p_B + (1 − p_A)(1 − p_B);
- raw agreement agree = c_obs;
- no-memory success X_A, X_B over A1.1; gap = X_B − X_A; abs_gap = |gap|; x_owner = X_A; x_reader = X_B;
- same_maker = 1 if A and B are of one maker (Part 0.2), else 0.

**A1.3 Targets per ordered swap** (headline family; each pooled over orders, then the mean over streams):
T (primary, 8.4.0, where reportable); C_swap (Part 2.2); D = C_home − C_swap (Part 2.3); R (Part 2.4, where reportable).

**A1.4 Models** (ordinary least squares with an intercept; no tuning, no selection):

| Name | Predictors | Role |
|---|---|---|
| F-1 | ec | forecast |
| F-2 | ec, gap | forecast |
| grand_mean | none | baseline |
| same_maker | same_maker | baseline |
| gap | gap | baseline |
| agree, abs_gap, x_owner, x_reader | one each | descriptive |
| subsample_20 | none (direct estimate) | post-swap baseline |

subsample_20: for each bank (owner, reader, stream, order), 5 calibration tasks drawn without replacement, all
candidates checked once (one of the two stored repeats, uniformly): 20 checks. μ̂_swap = mean of a over the 5 tasks;
Ĉ_swap = Cw over them (0.5 if no informative pair); pooled over orders and streams as the target; T̂ = μ̂_swap / μ_home,
R̂ and D̂ with the evaluation-task home values. 200 draws per bank; seeded by (evaluate.seed, owner, reader, stream, order).

**A1.5 Validation: leave one model out.** For each model m: fit on the swaps that involve neither owner m nor reader m
(and whose target is reportable); predict every swap that involves m. Each swap is predicted twice (with its owner
and with its reader left out); all predictions count. A fold in which a model cannot be fitted (fewer training swaps
than coefficients + 1, or a constant predictor) gives no prediction and is counted in `folds_not_fitted`.
Out-of-fold metrics over all predictions:
- R²_oof = 1 − MSE(model) / MSE(grand_mean), where grand_mean is also fitted leaving the same model out;
- Spearman's ρ between predictions and targets; MAE.
For subsample_20 the same metrics are computed per draw over the swaps (one estimate per swap) against the same
grand-mean predictions averaged per swap; the value is the mean over draws, with the 5th–95th percentile.

**A1.6 Intervals.** Tasks resampled within each (stream, order), B = 10,000: evaluation tasks with the draws of Part 4.1,
predictor tasks with their own seeded draws. Every predictor, target, fit and metric is recomputed in each draw.
95 % percentile intervals. The set of swaps with a reportable target is fixed by the point estimate.

**A1.7 Reliability of each predictor** (reported, not tested): between-pair SD; mean bootstrap SE;
reliability = max(0, 1 − mean SE² / between-pair variance); split-half correlation over a fixed hash split of the
predictor tasks and its Spearman–Brown value; and each model's test-retest kappa (no-memory repeat 1 against
repeat 2 on calibration tasks), the noise ceiling of ec.

**A1.8 Tests (family F, Holm at 0.05 over F1 and F2; one-sided):**
- **F1:** ρ_F1 = Spearman(ec, T) over the ordered swaps with T reportable. H1: ρ_F1 > 0.
- **F2:** ρ_F2 = out-of-fold Spearman of F-2's predictions of T (A1.5). H1: ρ_F2 > 0.
- Both by permuting model labels in the predictor data (ec and X relabelled together; targets keep their labels):
  all n! relabelings up to 8 models, else the identity plus 49,999 random ones (seed 0).
  p = share of relabelings with a statistic ≥ the observed one (the identity included).
- **Testability.** The smallest attainable p is (number of relabelings that leave the predictor data unchanged) / n!,
  which is 1/n! in practice. A test whose smallest attainable p exceeds 0.05 / 2 = 0.025 is reported as
  "not testable with n models" and given no p-value. This needs **at least 5 models** (1/120); with 4 models
  1/24 = 0.042 > 0.025; with 8 models 1/40,320. If a model is retired (Part 1.7), n drops accordingly.
- **Pass (each test):** testable, Holm rejects, and the statistic is > 0. **Fail:** testable and not pass.
- **Forecast judged useful** (wording, secondary): "the memory-free check forecasts retained validity" only if F1 or F2
  passes **and** F-1 or F-2 has a higher R²_oof than each of same_maker and gap, with a 95 % interval of the difference
  that excludes 0. If the forecast passes but subsample_20 has a lower MAE, the paper says so in the same sentence.
  Otherwise: "no evidence that a memory-free check forecasts retained validity". A failed test is never reported as
  "the check does not work".

**A1.9 Power (design aid, synthetic, not a result).** Positive control `positive_world` in `tests/test_forecast.py`:
8 models, error consistency measured from 2,250 simulated no-memory tasks, target correlated with the hidden model
similarity at rho. Pass rates over 100 worlds (F1 / F2): rho 0: 0.02 / 0.02-0.05; rho 0.3: 0.53-0.66 / 0.34-0.43;
rho 0.6: 1.00 / 0.96-1.00 (ranges over all-pair-level and half-model-level noise). A failed F1/F2 therefore rules out
a strong relation, not a weak one.

### 8.4.B Addition 2: a stop-when-sure check on the swap day

**B2.1 Unit.** One fresh-check task: one probe task of the test stream (B2.6), every candidate checked once with the
reader. Its value is a(τ; y) with y the single check of each candidate. Tasks, not item pairs, are the independent units.

**B2.2 Thresholds** (fixed now): τ_keep = 0.75 · μ_home and τ_drop = 0.25 · μ_home, with μ_home of the same owner,
stream and order (the owner's own outcomes on every evaluation task, known before the swap) and treated as fixed. 0.75 is the non-inferiority margin of
PC1 (Part 6.1): KEEP certifies "no material loss"; 0.25 places DROP symmetrically. Cells whose μ_home (per order) fails
the 4-SE rule are replayed but reported apart ("home signal too weak") and left out of the headline rates
(kind `all_home_ok` in `sequential_rules.csv`).

**B2.3 Error level.** α = 0.05 for each of the two errors.

**B2.4 Test martingales.** Observations u = (a + 1)/2 ∈ [0, 1]; thresholds m = (τ + 1)/2.
- KEEP test, H0: E[u] ≤ m_keep. Wealth K_t = (1/20) Σ_{d=1..20} Π_{i≤t} (1 + λ_d (u_i − m_keep)), λ_d = d/40.
- DROP test, H0: E[u] ≥ m_drop. Wealth K_t = (1/20) Σ_d Π_{i≤t} (1 − λ_d (u_i − m_drop)).
- A test rejects at the first t with K_t ≥ 1/α. Under its H0 each K_t is a nonnegative supermartingale with K_0 = 1,
  so by Ville's inequality the chance of ever rejecting is at most α, at any data-dependent stopping time.
- Because the bets are fixed, K_t is monotone in m, so "the KEEP test rejects" is the same event as "τ_keep lies
  below the running lower bound of the one-sided confidence sequence" (and likewise for DROP and the upper bound).
- This bet was chosen on simulated data before any real data existed; Waudby-Smith and Ramdas' predictable plug-in
  bets and aGRAPA bets (truncated at 0.5/m or 0.5/(1 − m)) are sensitivity analyses.

**B2.5 Decision rule.** Tasks are taken one at a time. At the first task where the KEEP test rejects: **KEEP** (old scores
unchanged). At the first task where the DROP test rejects: **DROP** (recalibrate, `recal` with the checks collected, or
wipe). Both at the same task: DROP. Neither by the **cap, the number of tasks in the test stream** (B2.6; 300 tasks =
1,200 checks per order in the main study): the default, **recalibrate** from the checks collected (`recal` of Part 2.6).

**B2.6 Replay on the frozen tables (no calls).**
- **Truth half.** The 400 evaluation tasks of each (stream, order) are split once into two halves of 200: the tasks
  sorted by sha256("truth-half|evaluate.seed|stream|order|task id"), the first half is the truth half. The same split
  serves every pair of that stream order. The truth of a pair is θ = μ_swap / μ_home, μ_swap from the reader's
  repeats 1–2 on the truth half only, μ_home as in B2.2, with a 95 % task-bootstrap interval. Home cells have θ = 1
  by definition. The truth half never enters the test stream.
- **Test stream.** Every other probe task of the cell: the other 200 evaluation tasks plus the 100 calibration tasks
  (300 tasks), in uniformly random order without replacement, one stored repeat per candidate drawn uniformly.
  The cap is the number of tasks in the stream (300).
- 1,000 replays per (owner, reader, stream, order), seeded by (evaluate.seed, owner, reader, stream, order). The
  content-only control (scores permuted within each task, θ = 0) is replayed too.
- **Reported result: the share of pairs undecided within the table.** A (pair, stream, order) counts as undecided when
  at least half of its replays reach the cap without a decision; reported over all swaps, over the swaps whose
  μ_home passes the 4-SE rule, over home cells and over shuffled controls, with the mean share of undecided replays
  (`sequential_pairs.csv`).

**B2.7 Reported per rule** (per cell and per kind of swap: home, same-maker, cross-maker, shuffled):
- false-keep rate = share of replays that KEEP among cells with θ < 0.75; also among cells whose whole θ interval is
  below 0.75 ("clear");
- false-drop rate = share of replays that DROP by the test among cells with θ > 0.25 (and "clear");
- the undecided (default) share; tasks and calls used: mean, 10th, 50th, 90th percentiles and maximum.
Rules: the sequential rule; the same rule cut at 8, 16, 32 and 64 checks (2, 4, 8, 16 tasks); `audit_k` at those
budgets (KEEP if Cw on the checks > 0.5, no informative pair → KEEP, else WIPE); a fixed-budget plug-in rule (KEEP if
mean a / μ_home ≥ 0.5, else DROP); and both fixed rules at the sequential rule's mean cost (equal expected cost).

**B2.8 Checks of the guarantee** (reported; failure means a defect to fix before any claim):
- Synthetic streams whose mean is exactly τ_keep (or τ_drop): the empirical distribution of a on home cells mixed
  with its reflection, a two-point ±1 law, and a Beta law; 5,000 streams of 1,000 tasks. Pass: the share rejecting by
  task t is ≤ α + 2.33 Monte-Carlo SE for every t.
- The simulated study with known truth (simulator probabilities, tasks drawn with replacement, fresh Bernoulli
  checks, 1,000 streams per cell): false keep ≤ α + 2.33 MC SE wherever θ < 0.75, false drop likewise wherever θ > 0.25.

**B2.9 Stopping time against θ.** Synthetic streams (the reflection law, scaled to the study's own μ_home and spread)
at θ ∈ {−0.6, −0.4, −0.2, 0, 0.1, 0.25, 0.4, 0.5, 0.6, 0.75, 0.9, 1}, 2,000 streams of up to 1,000 tasks: decision
shares and the 10/25/50/75/90th percentiles of tasks used, and the share decided by 2, 4, 8, 16, 100 and 300 tasks.

**B2.10 Sensitivity.** (τ_drop, τ_keep) / μ_home ∈ {(0.25, 0.75), (0, 0.5), (0.25, 0.5), (0.5, 0.5)}; α = 0.10;
the plug-in and aGRAPA bets.

**B2.11 Wording.** The empirical rates are conditional on one finite test stream per cell and on an estimated truth
(200 tasks); the guarantee itself is marginal over random tasks. Allowed claims:
- "KEEP and DROP decisions were wrong at most α of the time" only if B2.8 passes;
- "a controlled keep-or-drop decision needs about N tasks (4N checks) when θ = …", N = the median of B2.9 at the
  study's μ_home, always with the share of pairs undecided within the table (B2.6);
- "fixed budgets of 8 to 64 checks decide but do not control errors", with their false-keep and false-drop rates.
The rule is not claimed to be new; the anytime-valid technique is cited, not claimed.

---

## Settled by the worker who drafted this (for the manager to confirm or overrule before the freeze)

1. T is the primary forecast target because it is linear in the outcomes (outcome noise does not bias it) and is
   exactly the quantity the swap-day check tests. C_swap, D and R are secondary targets.
2. F1 and F2 form their own two-test Holm family, separate from P1–P4. Joining P1–P4 instead would make it a
   five-test family (smallest threshold 0.01): still testable from 5 models (1/120 = 0.0083).
3. Thresholds 0.75 / 0.25 of μ_home. They make KEEP and DROP slow; (0, 0.5) roughly halves the tasks needed.
4. The cap is every probe task outside the truth half: 300 tasks per order in the main study (the earlier draft
   used only the 100 calibration tasks). In the small simulated practice study it is 52 (28 + 24).
5. The default at the cap is recalibrate, not keep, so that a KEEP only ever comes from the controlled test.
