# Status

Updated 23 Nov 2026 (evening).

## Done
- Deep research (five notes), combined report `reports/Model swap benchmark ICML plan.md`, and `docs/MASTER_PLAN.md`.
- Pre-registration drafted with the manager's rulings: `prediction/PREREGISTRATION.md` (not yet frozen).
- Framework: call layer, data and grading, five score families, all swap-day rules, metrics, local embeddings,
  retrieval, simulated models, and the one-command pipeline (`run.py`: build, probe, extra home repeats, evaluate,
  run after the swap). 107 tests pass. Nothing has been spent.
- Free practice run (`python run.py --study config/sim.yaml`) recovers the simulation's known truth:
  home validity 0.66–0.75, after a same-family swap 0.64, after a cross-family swap 0.54, shuffled control 0.50,
  self-swap drop about 0.
- Leg L5, the free outside check on the "Beyond Gain" data (`legs/beyond_gain/`): see "First real result" below.
- Name check: SwapBench is taken; ScoreSwap is free (SwapDay is the free alternative).

## Running (Opus, extra-high effort)
- Code made to match the pre-registration exactly, and the scoring stage made fast.
- Confirmatory analysis, figures, and the paper's numbers and tables.
- Paper workspace: ICML 2027 template, reference ledger (every citation opened and logged), drafts of the sections
  that need no results.

## Next
1. Manager's review of the three pieces above; full practice run through to paper assets on simulated data.
2. Smoke test of each real model (needs keys), then the three pilots (about USD 29 in total by the pipeline's estimate).
3. Gate decision, freeze of the pre-registration (dated, hashed), then the main runs. Haiku 4.5 calls go first.
4. Leg L3 (MemRL's own code on the operating-system tasks).

## Cost estimates printed by the pipeline (`run.py --estimate`)
- Full study, 8 models, 56 swaps, 2 streams: 2,240,400 calls, about USD 670 (cached repeats will lower it).
- Pilots: about USD 8 (DDXPlus), 8 (DDXPlus, labelled items), 13 (BIRD).
- Labelled-item sensitivity study: about USD 175 (to be cut down to two pairs).

## Waiting on the owner
- Keys in `.env` (copy `.env.example`): Anthropic, OpenAI, OpenRouter.
- Spending cap: the plan asks for USD 1,000 in total, raised in steps. The code's cap is 30 now.
- Clearance, author list (freezes 14 Jan 2027), OpenReview profiles.
- Four PDFs opened in a browser and saved into `docs/papers/`: HEIRS, Execution Records, ExpHarness, Harmless Here.

## Rulings to write into the pre-registration at the freeze
- Point 21: accepted. If DS-1000 is piloted, it uses its smaller build with 200 probe tasks.
- Point 22: if the headline family is not `ema_grade`, the run after the swap ranks and learns with the headline family's own update rule.
- Point 19: fill the per-model fields (sampling values, reasoning setting, OpenRouter route) from the smoke test.
- From leg L5: add, as a secondary measure, a retained-validity ratio that allows for BOTH models' noise.
- Cite ZenML's "SwapBench" (Oct 2026) in related work.

## First real result (free, no API calls): leg L5, "Beyond Gain" released skill scores, 4 open models, 12 ordered pairs
- Old scores rank skills under another model at concordance 0.65–0.74 (0.5 = chance); Spearman 0.40–0.62.
- The one true version upgrade (Qwen3.6-27B → Qwen3.8-27B) is the weakest pair: Spearman 0.40.
- Keep beats wipe on every pair (67–77% vs 45–54% matching retire/keep decisions).
- "Re-test a few, then refit" did worse than keep in 47 of 48 cases.
- Limits: LLM-judged scores, skills not memory items, not our models.

## Facts corrected by the reference ledger (23 Nov)
- MemRL and EvoKernel are cited as preprints: their arXiv records do not state NeurIPS 2026 / ICML 2026.
- MemRL's "generalizes beyond any single model" sentence is in its main text, not appendix C.1.
- MemRL's paper gives rewards in [-1, 1]; "±1" is our inference, so the start-value equivalence must be worded with care.
- Still to check by a human: Holm 1979 (not reachable), the author order of the power prior paper, seven classics
  opened by registry title only, six OpenReview papers known from saved API copies only.
- ICML sources disagree on file size (10 MB vs 50 MB: stay under 10) and on the AI statement's name.

## Update, 23 Nov (night)
- Code now matches the pre-registration (11 differences fixed). 151 tests pass. The scoring stage for the full study
  takes about 7 minutes on 8 cores (it would have taken 6-8 hours).
- Analysis, figures, tables and number macros are built (`python scripts/make_paper_assets.py --study <name>`).
  Practice outputs carry the banner "SIMULATED DATA" and the macro prefix \Sim.
- Paper workspace: `paper/main.pdf` compiles in the ICML 2027 template; 90 references logged, 75 fully verified.
- Keys: the Anthropic key held by opencode is REJECTED by Anthropic (401). No Claude model can be called until the
  owner supplies a working key. `providers.anthropic.key_from_opencode` is therefore off.
- Running: a real-model PRELIMINARY run through opencode's free models (`config/prelim_opencode.yaml`), and the
  analysis follow-up (new secondary outputs, any study shape, labels per study kind).

## More rulings to write into the pre-registration at the freeze
- Fresh checks are always program-graded outcomes, also for the `tags_self` family (say so).
- `powerprior` is not defined for `credit` and `visits`; those families skip it.
- Reword "b = 1 is keep": with a standardised score, compare the fitted slope with the slope fitted at home.
- Starting counts for the run after the swap: helpful = p(n+2) - 1, harmful = (1-p)(n+2) - 1, so the smoothed mean is p.
- The z-scored mix is computed within each task's 4 candidates (sensitivity only).
- Visit thirds: terciles of visits over the owner's bank; a pair is classed by its lower-visit item. The standardising
  SD is the population SD over items with at least one visit.
- Per-pair PC1 flag: 2 x min(p_drop, p_NI) before Holm. Heterogeneity by least squares (amends Part 8.2.12).
- Remove open point 20 (the code checklist is done).
- Secondary measure added: noise-adjusted retained validity.

## Free opencode models: route built, run stopped (23 Nov, night)
- The route works (`msr/opencode_route.py`, provider `opencode_cli`, 20 tests with a fake opencode), and the model sees
  only "You are a helpful assistant." plus our prompt. Details: `runs/prelim_opencode/ROUTE_NOTES.md`.
- But the free allowance is small (it ran out after a few dozen calls), is shared by all the free models, resets once
  a day, and is the same allowance the owner's other application's agent uses. A 12,300-call run would take very long
  and would block that application. The unit `msr-prelim` was therefore STOPPED. Do not restart it without the owner's word.
- Consequence: no real model can be called until the owner supplies a working key (Anthropic, OpenRouter or OpenAI).
- Cheapest useful key: OpenRouter with about USD 20 of credit. It reaches the Qwen and Gemma open-weight pairs
  (hosts pinned), which are the part of the benchmark that never retires. The three pilots cost about USD 29 in total
  on the Haiku pair; on the Qwen pair they cost less.

## Two additions adopted (see MASTER_PLAN 2.11)
- A law of score transfer with a pre-swap forecast; a stop-when-sure swap-day check. Workers are building both.

## Analysis follow-up done (23 Nov, night)
- 182 tests pass. The analysis handles any study shape, labels simulated / preliminary / real studies, and its
  per-pair numbers equal the pipeline's exactly.
- Ruling: the noise-adjusted ratio uses each model's home repeats 1-2 against repeats 3-4 as its noise reference
  (confirmed). Write this into the pre-registration at the freeze.
- Not possible yet: the variance due to prompt wording (needs raw results under the second wording); k = 128 or 256.

## The two additions are built (24 Nov, early)
- Transfer law (`msr/theory.py`, `docs/theory_note.md`, proofs in `paper/sections/A8_proofs.tex`): all seven statements
  proved or corrected; 231 tests pass. On the practice data the law predicts after-swap validity with error 0.030
  against 0.111 for "assume no change", and the transfer slope recovers the simulator's truth (same family 0.60 vs
  true 0.69; cross family 0.27 vs true 0.30). Its real content is one assumption: old scores predict the new model's
  results only through the old model's usefulness. The test treats items as sampled, not only tasks.
- Forecast and stop-when-sure check (`msr/forecast.py`, `msr/sequential.py`): the error guarantee held (worst 3.4% at a
  5% limit); a keep-or-not decision needed a median of about 560 tasks on the practice data; the quick 8-64-check
  audit rule kept wrongly about half the time. The forecast needs at least five models to be testable.
- Running: merging both into the pre-registration; wiring them into the paper assets; integrating the new sections
  into the paper, verifying about 20 new references, and producing two PDFs (submission layout, and a watermarked
  dry run with simulated numbers).

## Code alignment round 2 done (24 Nov)
- 246 tests pass. Fresh-check budgets now go up to 128 and 256. The second-wording check has home cells.
- Estimates after the changes: full study 2,240,400 calls, about USD 670; pilots about USD 8, 13 and 8.
- The labelled-item sensitivity study as configured (4 models, 2 streams, 3 orders) is about USD 261.
  Ruling: run it on DDXPlus with seed 0 only (about USD 45); change the config and the pre-registration line at the freeze.
- Still to write into the pre-registration at the freeze: the "SD is 0, level only" rule in 2.6; refresh open points 24-26.
- Not built: DS-1000 (only needed if BIRD fails the pilot); the wording variance component.
- Paper: `paper/main.pdf` (submission layout, results pending) and `paper/dryrun.pdf` (watermarked, simulated numbers).
  Ledger: 110 references, 91 verified, 19 partial, 0 not found.
- Running: four mock reviews (`paper/reviews/round1/`), and the wiring of the two additions into the paper assets.

## Mock review round 1 (24 Nov): all four reviewers scored the draft 3 of 6 or "advance"; revision under way
Reviews are in `paper/reviews/round1/`. The area chair would advance the paper to full review. The three reviewers
each gave Overall 3 (weak reject) as written, rising to 4-5 if their fixes are made. They agree on the core fixes.

Decisions taken by the manager:
1. Headline measure becomes the noise-free retained share theta = V_swap / V_home. The plain ratio R is secondary
   (our own decomposition shows R is confounded by the new model's noise). The 0.75 margin sits on theta.
2. No "law", no "mediation". It is a transfer decomposition (an identity) with a linear-transfer specification test.
   The weighted concordance is (1 + Gini correlation) / 2, which is classical and cited as such.
3. Errors found by the theory reviewer and being fixed: the mediation wording (counter-example with a monotone,
   non-linear relation); the main-text sentence on discounting counts; a wrong "reduces to arcsin" sentence; the
   stop-when-sure guarantee when the home value is treated as known (false keeps of 0.16-0.32 near the boundary);
   the forecast's permutation test (rejects 47% of the time when it adds nothing beyond the same-maker flag).
4. New result to add: an information lower bound on the number of fresh-check tasks ANY valid keep-or-drop test needs.
5. Statistics: the min-p device inside Holm is replaced by two separate one-sided tests per group; primary intervals
   cluster on task ID across orders and treat items as sampled; the prediction-quality comparisons become
   swap-minus-home contrasts with a common level correction; stakes are shown in success points.
6. Equal sampling: open models at temperature 1.0 and top_p 1.0, to match the closed models' fixed default.
7. Paper: new title "ScoreSwap: Do Agent-Memory Usefulness Scores Still Rank Items After a Model Swap?"; a
   "what we found" paragraph and Figure 1 on pages 1-2; honest framing as experience memory with learned usefulness
   scores, linked to in-context example selection; 13 missed papers to verify and place; forecast and P1-P4 to the appendix.
8. The MemRL-code leg on multi-step tasks becomes a required confirmatory leg (`legs/memrl/`, being prepared).
9. Still to build after the statistics revision: a rule interface and offline scorer so outsiders can submit a rule.
10. Owner's action added: deposit the frozen pre-registration on a public time-stamped registry (for example OSF).

## Real-agent leg (L3) is ready to run (24 Nov)
- `legs/memrl/`: MemRL's code pinned at c1b322c with four small patches, an isolated Python 3.10 environment, the
  Docker image, a rehearsal mode. 14 tests pass. A full fake run (2 trainings, 14 evaluation cells) completed.
- Verified in their code: keep, wipe and shuffled copies differ only in the Q values; a single global discount picks
  the same memories as keep on 150 of 150 tasks, so it is not run.
- Estimate: about USD 176 for all eight models (Haiku pair 90, GPT 25, Qwen 44, Gemma 18), 10 epochs, 2 repeats;
  plan for 0.7x to 2.5x. One validation task (359) is broken in the dataset, so the ceiling is 149 of 150.
- Embeddings: MemRL expects text-embedding-3-large (needs the OpenAI key; under 1 cent). The free local bge model
  works but picks only 67% of the same top-10 memories. Use text-embedding-3-large if an OpenAI key exists; else bge, and say so.
- Commands: `legs/memrl/README.md` section 7. The spending cap must be raised before a real run.

## Statistics and pre-registration revision done (24 Nov, later)
Code, configs and Parts 0-10 of the pre-registration now follow the round-1 decisions. 285 of 286 tests passed, and the
one failure (a rename by the theory worker) was fixed afterwards. Checks are in `docs/power/`.
- Headline: theta = V_swap / V_home, defined once in `msr/metrics.py`. Figure 1 is `fig1_theta_grid`; new `fig_forest_theta`.
- Holm: the old min-p device had a familywise error of 0.143 (and 0.757 for the per-pair flag). The new device, separate
  one-sided tests, is at 0.0499 (15 group tests) and 0.0492 (112 per-pair tests). So the primary family is now 15 tests, not 12.
- Intervals: two-way (task id pooled over orders x items), Fieller for theta. Coverage 0.939-0.955 (old: 0.905-0.938).
- Power at home Cw 0.66: the drop test reaches 80% at a theta loss of 0.12 / 0.115 / 0.08 (upgrades / downgrades /
  cross-maker); "no material drop" reaches 80% at theta 0.85 / 0.85 / 0.79. With a weak home signal (Cw 0.56) the
  4-swap groups never reach 80%. So the pilot gate on home Cw (0.58) matters; a home Cw near 0.56 means the
  same-maker claims will be inconclusive.
- OPEN, being fixed: the "no material drop" test is about one point too lenient at the boundary (0.059-0.070 at a
  nominal 0.05). The statistics worker is finding the smallest correction; result goes to `docs/power/size_theta_boundary.md`.
- Prediction-quality comparisons (PC3, PC4): swap-minus-home on level-corrected log scores. Every arm gets the same
  level information (the reader's no-memory success), so a shared level error remains and cancels in the contrasts.
  The paper must say "same level information for every arm", not "calibrated".
- Names: `split_half` (was oracle), `ceiling` (in-sample), "self-swap reference", "maker". Macros: `paper/assets/MACROS.md`.
- Sampling: open-weight models at temperature 1.0, top_p 1.0, no top_k. A Qwen run at 0.7 is a sensitivity study
  (`config/study_temperature.yaml`, about USD 18). Labelled-item study: DDXPlus, seed 0, about USD 31.
- L3 leg registered as its own family.
- Practice-data headline (simulated, two-way 95% intervals): theta upgrades 0.73 [0.47, 1.08], downgrades 0.75 [0.52, 1.08],
  cross-maker 0.20 [0.01, 0.37]. Keep-minus-wipe in success points, home -> after swap: 10.3 -> 6.9, 8.3 -> 5.6, 9.3 -> 1.5.
- Passed to the theory worker: Family T's min-p device fails the same way (0.1445 against 0.0499), and Part 11 still said 12 tests.

## Rule interface and offline scorer built (24 Nov, night)
Package `scoreswap/`; guide `docs/BENCHMARK_GUIDE.md`; examples in `examples/`; tiny practice study
`config/scoreswap_fixture.yaml`. 35 new tests; whole suite 335 passed after one fix. Nothing under `msr/` changed.
- Commands: `python -m scoreswap check <rule.py> --pack <folder>`; `... score <rule.py> --pack <folder> --budget 64`;
  `... leaderboard <entries/> --pack <folder> --budgets 0,8,16,32,64`; `... export --study <name> --out release/<name>`.
- `check` runs the entry sealed in a child process that never gets the evaluation file, and repeats it with the
  evaluation outcomes permuted: the output must be byte-identical. Cheating rules (open the file, go over budget, ask a
  cell a third time, NaN, network, writes) are caught. The sealing is a Python audit hook, not an OS sandbox.
- Parity: the paper's own rules, written as ordinary entries, reproduce `arms.csv`, `validity.csv` and `retained.csv`
  exactly (differences 0 to 1e-14) on the fixture study and on `runs/sim`.
- Found: `runs/sim/results` is STALE for the level-corrected log and Brier columns (written before the last change to
  `msr/metrics.py` and `msr/evaluate.py`; `EVAL_RULES` was not bumped, so a plain run skips Stage C).
  To do once the theory and statistics workers hand back: bump `EVAL_RULES`, re-run `--stage evaluate`, rebuild assets,
  then `python -m scoreswap export --study sim --out release/sim`.
- Rulings: (1) no Croissant file for ICML (not asked for); build it only for a NeurIPS fallback or the public release.
  (2) Outside rules that draw at random use recal_k's seeded draws by default. (3) Item text stays off in the release
  pack (ids and hashes only) until the licences and the model providers' output terms are checked at release time.
- Appendix A14 needs six wording fixes (two-way intervals primary; level-corrected log and Brier; which seeded draws;
  a second answer is the other stored repeat, and a check may carry the reader's no-item result; the exact theta
  definition; two more things that cannot be scored offline). They go to the paper worker in the synchronising pass.
- Noticed: the practice study `sim` is small (240/80/60 tasks, 24 calibration tasks, 4 models), so the registered
  budget k = 64 is never exercised. Planned: a full-size dress rehearsal with 8 simulated models from 4 makers
  (free, local), to test the registered sizes, measure run time and disk use, and give the dry-run PDF the final shape.

## Theory revision done (24 Nov, after midnight)
336 tests pass (plus 12 in `legs/memrl`). Every finding of the theory reviewer was reproduced and fixed.
Hand-over note for the paper: `docs/handover/theory_to_paper_2026-11-24.md`.
- The "law" is now a transfer decomposition with a linear-transfer specification test. The estimate of the transfer
  slope crosses home repeats 1-2 with 3-4 (no caching bias) and is decided on calibration tasks only.
- Keep-or-drop check: a new paired design, valid with the home value estimated. False keeps at most 0.030 and false
  drops at most 0.039 at a 0.05 limit (the old rule reached 0.17-0.33).
- New result, an information lower bound: at the practice study's signal ANY valid rule needs at least 114 / 262 / 327
  tasks for power 0.5 / 0.8 / 0.9; with 16 tasks (64 checks) a fully retained swap can be kept at most 15-18% of the
  time. Our check's median is about twice the bound. This is the "no cheap valid shortcut exists" claim.
- Forecast: one test of incremental value beyond same-maker and capability; level 0.045-0.051 (0.095 if capability
  acts non-linearly); power at 8 models 0.63-0.68 for a weak relation, 0.99 for a strong one. Moved to the appendix.
- Holm family T: 9 separate members. Family F: 1 test.
- Rulings made after the hand-back: the two primary tests are linear contrasts and take no "is it defined" gate; theta
  and its interval are always reported; the status flag is decided on the calibration tasks (at least 2 SE), because the
  same-task 4-SE rule selects on the estimate's own noise. The statistics worker is writing this into the code and Parts 0-10.

## Statistics follow-up done; paper synchronised (24 Nov, about 01:30)
- Size of the theta tests, measured with 5,000 replications per configuration (`docs/power/size_theta_boundary.md`):
  worst 0.0546 at a nominal 0.05 (the earlier 0.059-0.070 was a coarse estimate). A t reference and a CR1 correction
  moved it by under 0.0005. Fix: every two-way standard error is multiplied by a fixed factor of 1.03
  (`TWOWAY_SE_FACTOR` in `msr/metrics.py`), equal to testing at 0.045. Worst size is then 0.0494; power cost at most 0.04.
- No gate on either primary test (a gate had sat on the no-material-drop test). Theta and its interval are always
  written. The status flag uses the calibration tasks (at least 2 SE): it fails 2.3% of the time at home Cw 0.56 and
  never from 0.58 up (pooled over streams); the median theta among flagged-OK draws is 0.751 against a true 0.752.
- Part 5.4: family T has 9 members, family F has 1. `EVAL_RULES` bumped; practice study re-evaluated; assets rebuilt.
- Tests: 345 passed and 1 expected failure. The expected failure is a real fault the dress rehearsal found and
  wrote down as a test: `msr/llm.py` writes the answer-cache file in place, so a stop in the middle of a write can
  leave a broken cache entry. To fix before any paid run (write to a temporary file, then rename).
- Paper: both PDFs build with no undefined references; the body ends on page 8 with about 12 lines to spare;
  `main.pdf` 29 pages, `dryrun.pdf` 33 pages. Ledger: 127 references, 104 verified, 22 abstract-only (Hausman 1978,
  Angrist and Imbens 1995 and Wald 1945 are among them: a person must check those), 0 not found.
- Release pack for outsiders: `release/sim` (3 MB, built in 5 seconds); `python -m scoreswap check` passes on it.

## Paper fully synchronised; mock review round 2 started (24 Nov, about 02:30)
- The two final statistics sentences are in; the nine family-T members have macros and a table (`table_family_t`).
  Both PDFs build clean; body ends on page 8.
- Weak points the paper worker flagged in the dry run, to watch in real results (the paper already says them):
  the decomposition's error (0.030) equals the simple baseline R = rho-hat (0.030); the keep-or-drop check decides no
  swap within the small practice table; the forecast's control models cannot be fitted with 4 models; "mostly across
  makers" rests on point estimates.
- Still missing in the CSVs: an interval for the family-T equivalence tests, and the group readings of 11.2.4.
- Round 2 (`paper/reviews/round2/`): R4 benchmark reviewer who also tries the outsider tool from the guide alone;
  R5 agent-memory reviewer who checks novelty against the live literature; R6 statistics and theory reviewer with own
  computations; and an area-chair audit of every round-1 concern (fixed / partly / not) with predicted scores.

## Round 2, first review in: R5 (agent memory, novelty) scores Overall 3 again (24 Nov, about 03:00)
Review: `paper/reviews/round2/R5_memory_novelty.md`. Soundness 3, Presentation 2, Significance 2, Originality 2.
Nothing found takes "a lot" from the contribution, but the framing is too large and the first baselines an operator
would try are missing. Manager's decisions (to be merged with the other three round-2 reviews, then built):
1. ACCEPT W1 (the most important): the score may mostly detect "the stored answer is right", which helps every reader.
   Free to check, no new calls: add a reference score "stored answer's grade"; report the share of V_home and V_swap
   it explains, theta of the score residualised on it, and theta within correct-only and incorrect-only pairs. If most
   of the signal is correctness, the abstract must say so.
2. ACCEPT W4, new baselines. Free and offline: (a) re-answer agreement (the reader's own no-memory answer to the
   item's task against the stored answer; charged 250 calls), (d) a score type that uses the logged selection
   probabilities. New calls, so new pipeline stages before the freeze: (b) the new model as judge of each item, and an
   owner's write-time self-rating (W6); (c) "relearn": re-run the score phase on the frozen content with the new
   model, at least for the four upgrade pairs; (e) a re-exploration arm in the run after the swap. Cost to estimate.
3. ACCEPT W5: one cost table that charges every rule for everything (pre-swap owner calls, swap-day reader calls,
   the level information), and a PC3/PC4 version where keep gets no level information.
4. ACCEPT W3: tie the keep-or-drop decision to the operator's loss. Report the break-even theta* where keep and wipe
   give the same first-shown success, test against it, show the bound against the home signal strength, and keep the
   bound out of the abstract unless it survives that plot. The 0.75 margin stays only as the reporting margin of PC1.
5. ACCEPT W2 for the agent leg: state its minimum detectable effect, require the home contrast before reading the
   swap contrast, add a shuffle within visit-count strata, run at least two pairs.
6. ACCEPT W9: report theta against capability gap and error consistency with maker as a separate term; say "pairs
   that are more alike keep more" unless maker survives the control.
7. ACCEPT W7 and section 2.2-2.3: fix seven mis-statements about cited work (StreamBench shares one memory across
   three makers; the example-selection literature does ask the question; ACE does not rank by its counters; Goyal and
   Ray's 20 probes; the Beyond Gain pair's confound; SwapBench reached the same few-checks conclusion; "has not been
   measured" is too strong). Verify and cite the missed work: SkillEval (arXiv 2608.06891), LLM-Specific Utility for
   RAG (2510.11358), Peng et al. (2401.12087), MDR (NAACL 2024), Zhang-Feng-Tan (2211.04486), CompSkill (2611.01115),
   UpgradeBench (2608.20918), and five more of less weight. Each must pass the ledger's verification first.
8. ACCEPT W8 in part: release the task text and the open-weight models' outputs so content-aware rules can be
   scored; closed models' outputs only after their terms are checked. The scorer then needs a text-reading mode.
9. ACCEPT W10: the body is too dense. Cut to three questions (does the order survive, what is at stake, what should
   an operator do), one subsection for decomposition and bound, and a decision table by kind of swap and budget.
10. OWNER: the six OpenReview papers (HEIRS, the judge-replacement paper and four more) still cannot be opened by a
   program. Two of them may overlap the swap-day-rules contribution. A person must read them in a browser.
11. Title: decide after all four reviews ("memory-item scores" was suggested in place of "agent-memory").

## Round 2, area-chair audit in (24 Nov, about 03:30)
File: `paper/reviews/round2/AC_resolution_audit.md` (279 round-1 concerns, each marked; section 5 is a ranked action list).
- Counts: 155 fixed, 62 partly, 48 not fixed, 5 fixed in code but not in the paper, 3 made worse, 6 no longer apply.
  Of the ten points of substance, seven are fixed and verified; three are partly fixed (headline measure, related
  work, agent leg).
- Predicted scores if real results look like the practice ones: R1 3 -> 4, R2 3 -> 3 (4 if the agent leg reports),
  R3 3 -> 4. As it stands today: not submittable (no real results, 45 TODO markers, pre-registration not frozen).
- If real results show no drop at all: borderline 3-4. If the scores carry no signal even at home: reject (the pilot
  gate is meant to stop the main run before that).
Manager's decisions on its new points (N1-N15), to be merged with the rest of round 2:
1. N1 ACCEPT, the main one: theta mixes two things, whether the ORDER survives and how much the new model's success
   depends on which item it sees (same order with half the spread gives theta 0.51, a "material drop"). Decision:
   report theta as "retained value" and beside it a scale-free "retained order" (the noise-corrected rank agreement,
   R_std = theta x sqrt(S_oo / S_nn), already in Part 11.2.2), and state theta = order x stakes. Which of the two
   carries the registered margin is settled with the statistics reviewer's findings (R6, still running).
2. N2 ACCEPT: the bound holds for checks on whole tasks drawn at random; say so, give it with an interval, drop
   "any rule"; say that the paired test needs the old model's results collected before it retires; fix "about twice".
3. N3 ACCEPT: P1 must use the maker-preserving permutation test, like F1.
4. N4, N6 ACCEPT: report family T by the registered group readings; explain or fix the transfer slope that is 20-25%
   below the simulator's truth (now 0.521 against 0.69) before printing it.
5. N5 ACCEPT: the decomposition shrinks in the body to the identity and one paragraph; the rest moves to the appendix.
6. N7 ACCEPT (with R5's W2): agent leg power analysis, many shuffles, a cross-maker pair.
7. N8-N15 ACCEPT: the visible slips (figure captions and labels, the SD column, stale wording, decimals).
8. Body: stakes table, per-pair plot and P4 move INTO the body; a schematic of the probe table; one line of cost.

## Round 2, R4 in (benchmark reviewer who used the tool): Overall 3 (24 Nov, about 04:00)
File: `paper/reviews/round2/R4_benchmark_user.md`; their test files in `paper/reviews/round2/r4_user_test/`.
Soundness 2, Presentation 2, Significance 2, Originality 3. Point values of the scorer do match the paper (1e-14).
- The scorer could be cheated three ways: (1) the evaluation answers ship in the public pack, so a small entry that
  memorises them reaches the ceiling with 0 checks and passes every check; (2) the check budget leaks, because one
  process serves every cell and draw and a caching rule sees the whole calibration pool; (3) the board ranked
  `visits`, a no-signal score, first across makers, because theta is a ratio.
- Also: theta is a slope, not an order measure (same point as the audit's N1); the title says "agent memory" for a
  one-item example-selection experiment; four wrong statements in the paper; datasheet, licences, prompts are stubs;
  the guide does not document the interface; an entry that imports scipy crashes the check; the tool is slow
  (22 minutes for the parity check on the small pack; the real pack is about 84 times bigger).
Manager's decisions (sent to the scorer's builder, now running):
1. A held-out TEST half of the evaluation tasks. The public pack holds the DEV half's outcomes only; the test half is
   kept private with its sha256 published as a commitment; maintainers score submitted entries on it; it is replaced
   when new model pairs are added. The board shows dev and test separately.
2. No state may survive between draws: a fresh process per draw (fork), ids re-salted per draw.
3. The board shows home concordance beside every retained number and puts no-home-signal entries in their own block.
4. Board intervals equal the paper's. Full interface documentation and a `describe` command. Speed targets set.
5. Optional text fields in the pack, off until licences are cleared.

## Round 2 complete: all three fresh reviewers score Overall 3 (24 Nov, about 04:45)
R6 (statistics and theory): `paper/reviews/round2/R6_statistics_theory.md`, checks in `r6_checks/`. Soundness 2.
What held up: all 1,158 traceable numbers match their CSV; the identities and the bound's constants; Fieller coverage
0.94-0.98; the Holm family once each test's size is right; the paired test under its stated conditions.
What R6 found wrong: (1) the tests and Prop 3.3 need a POSITIVE home signal and never check it (with a negative home
value the code prints "no material drop"); (2) the paired check needs a FRESH home result for every task (re-using a
300-task home table gives false keeps of 0.13-0.20); (3) the factor 1.03 is not a small-sample correction, and when a
few items carry the variance the size is 0.057-0.088; (4) the "home signal too weak" flag is three different rules in
the code; (5) "material drop" is printed on a point estimate with no test behind it; (6) the bound sentence drops four
qualifiers, and with margin 0 the bound is only 43 checks; (7) the decomposition is an in-sample check that ties the
simple baselines; (8) PC3/PC4 contrasts move by 0.012 nats even with perfect transfer.

### What three reviewers agree on, and the manager's decisions for revision 2
The paper is over-built. Each addition (decomposition, sequential check, forecast) opened a new attack surface and did
not raise Significance or Originality (2 from every fresh reviewer). The revision SIMPLIFIES and re-centres.
D1. Title and question: "ScoreSwap: Are Learned Memory Scores Worth Keeping After a Model Swap?". The abstract says
    plainly that the main study is exemplar memory (one stored example shown per task) and that the multi-step agent
    leg is the bridge. Claims are about "these pairs", with the between-pair spread and a prediction interval.
D2. Measure: three numbers, one identity. Retained VALUE theta = V_swap / V_home (what the operator keeps, in
    success terms). Retained ORDER = theta x sqrt(S_owner / S_reader) (scale-free; S = noise-free spread of a model's
    item effects from cross-repeat products). STAKES ratio = sqrt(S_reader / S_owner). theta = order x stakes exactly.
    Primary tests stay on theta; retained order is the registered secondary and is "not identifiable" when the
    reader's spread cannot be told from zero. Boards rank by value after the swap, with theta and order beside.
D3. Inference repaired: a positive home signal is part of every claim (intersection-union: home signal > 0 AND the
    contrast); no label without a test; ONE flag rule in all code; a variance that is valid when a few items dominate
    (jackknife/CR3 or wild cluster bootstrap over items), with item share of variance and effective item count
    reported; the 1.03 factor is dropped or named honestly; size shown in worlds we did not tune on (R6's simulator).
D4. Primary family shrinks to PC1 (theta per group: drop / no material drop) and PC2 (keep minus wipe per group).
    PC3/PC4 (log-score comparisons of the discount and recalibration rules) become secondary.
D5. Decomposition leaves the body (one identity stays: D2). In the appendix it is a "measurement check", compared with
    R = rho-hat and R = gamma-hat, without "parameter-free" or "accounts for". The low transfer slope is explained or fixed.
D6. Keep-or-drop is re-centred on the operator's break-even: "is keeping still better than wiping?" (margin 0, no home
    value needed, a plain one-sample betting test; R6's own number: about 43 checks at this signal). The 0.75 question
    ("lost at most a quarter?") needs hundreds of tasks, with the bound stated for its observation scheme, margin,
    signal and as an estimate with an interval. Message: you CAN cheaply check "better than nothing"; you CANNOT
    cheaply check "lost at most a quarter".
D7. Construct checks and baselines. Free: stored-answer-correct reference score, answer-match and near-duplicate
    shares (theta inside the strata), re-answer agreement, a propensity-weighted score type, capability gap against
    maker. New calls (new pipeline stages, built after the dress rehearsal): new model as judge, owner's write-time
    self-rating, relearn on the frozen content, re-exploration after the swap. One cost table charges every rule.
D8. Agent leg strengthened: power analysis, many shuffles and a shuffle within visit strata, the home contrast
    required first, both directions, one cross-maker pair. New cost estimate to come.
D9. Models: the 8-model grid stays. To grow the 4-pair same-maker groups cheaply, look for two or three more
    open-weight same-maker pairs to run as same-maker cells only (about +12% cost). To be researched and costed.
D10. Scorer: held-out test half, per-draw isolation, home signal on the board, docs, speed (builder running).
D11. Paper: body rebuilt around three questions (is the order kept, what is at stake, what should an operator do);
    stakes table, per-pair plot and the maker test in the body; related-work corrections; about 15 references to
    verify and add; stubs (datasheet, licences, prompts, checklist) filled; every slip in the audit's list fixed.
D12. Money: the new stages and the stronger agent leg will raise the estimate above USD 925. A new total goes to the
    owner before any paid run. The pre-registration is frozen only after this revision and a third review.

## Re-check of models, retirement and ICML rules (24 Nov, about 05:30)
Files: `docs/checks_2026-11-24/` (extension_pairs.md, retirement_status.md, icml_2027_rules_update.md).
- Ruling on D9: add TWO extension pairs as same-maker cells only (each model on its own bank, plus the two swaps
  between them); each adds 241,800 calls. (1) Mistral Small 3 -> 3.2 on DeepInfra fp8, about USD 15. (2) DeepSeek
  V4.1-Flash -> V4.1-Flash-1017 on DeepInfra fp8, about USD 28; the maker calls it a minor update, which is the low
  end of "what changed". Same-maker groups then have 6 pairs. A third (Qwen3.5-35B-A3B -> 3.6, about USD 35) only if
  money allows. All run at temperature 1.0 like the other open models (Mistral advises 0.15: say so in the paper).
- Config to fix before any paid run (pipeline worker): pin `only: ["deepinfra/fp8"]` (the plain `deepinfra` pin also
  reaches a priority endpoint at ten times the price for Qwen3.5-27B); record the Gemma commits (005ad3404e59,
  842da3794eaa); confirm thinking is OFF for Qwen3.8 at the smoke test (OpenRouter now shows it on by default);
  stop a run when the served model differs from the pinned one (DeepInfra forwards retired models after one week).
- Retirement: Haiku 4.5 is active, "not sooner than October 15, 2026", 60 days' notice, so the earliest possible
  retirement is about 23 Jan 2027, one day after the paper deadline. Opus 4.5 got its notice on 23 Nov. Haiku 5.5:
  not sooner than October 7, 2027. The Luna models are not on OpenAI's list (6 months' notice promised).
  So: every Haiku 4.5 call must run first, and a key is needed soon.
- ICML 2027: the "late November" process update is not posted yet (change log ends 20 Nov); re-check about 1 Dec.
  New since 17 Nov: authors without an eligible reviewer may be on at most 2 submissions. Gaps in our plan, now sent
  to the paper worker: licence files and author names out of the submitted code, on a branch frozen at the deadline;
  the held-out test half must stay out of the supplement (it becomes public on acceptance); the pre-registration is
  cited through an anonymous link; the section is called "AI Disclosure Statement"; a financial conflict-of-interest
  disclosure is required at submission (owner).

## Paper revision 2, phase 1 done (24 Nov, morning)
- New title in place; abstract is five sentences. Body rebuilt around the three questions: introduction, related
  work (corrected against the sources), benchmark (with a probe-table schematic and value = order x stakes), setup
  (what changed in each of the six same-maker pairs), Q1 order and value, Q2 stakes (table in the body), Q3 operator
  (one cost table; the two check questions), agent leg, using ScoreSwap, limitations. The decomposition, the
  keep-or-drop propositions and bound, PC3/PC4 are in the appendix.
- Both PDFs build clean: `main.pdf` 32 pages, `dryrun.pdf` 36; the body ends on page 7, about 0.8 page free for results.
- Ledger: 142 references, 118 verified, 23 abstract-only, 0 not found. All 15 new works placed.
- Waiting on the other workers: 63 marked lines (statistics 38, theory 12, agent leg 3, scorer 7) and 26 requested
  macros plus 2 tables in `paper/assets/REQUESTED_MACROS.md`.
- Open: no deployed system that keeps learned per-item scores is cited (the text says research memories are the
  target); the output licences of the Qwen and Gemma models; the six OpenReview papers (owner).

## Running now (revision 2)
- Statistics core (D2, D3, D4); construct checks and free baselines (D7, new module); theory (D5, D6);
  paper (D1, D11 first part); agent leg (D8); model and rules re-check (D9); scorer fixes (D10).
- Full-size dress rehearsal on 8 simulated models (unit `msr-simfull`); its worker builds the new pipeline stages after.
Next: integrate, rebuild the practice results, paper body with the new numbers, review round 3, cost statement to the owner.

## Agent leg, revision 2 handed back (24 Nov, about 06:00)
Files: `legs/memrl/` (README is the full write-up; sentences for the paper in README section 11); Part 8.4 of the
pre-registration rewritten. No paid call.
- Smallest difference the leg can detect (keep minus within-visit shuffle, 150 tasks, 80 % power, home gate and
  swap both under Holm over 12 directed swaps): 4.1 to 7.1 success points, 5.5 in the central case. The round-1
  design could see only 5.9 to 10.0. MemRL's own held-out gain over its strongest baseline (MemP) was 2.6 points on these tasks, so
  some pairs may come out "uninformative". The paper must say this plainly.
- Shuffle: within-visit (scores re-dealt among memories shown about equally often), a fresh permutation on each of
  8 repeats. The home gate is read first; four registered readings (uninformative / survives / lost / undetermined).
- Three costed designs: minimum USD 177 (124-442), recommended USD 356 (249-889), full USD 806 (565-2,016).
- Manager's ruling: plan on the RECOMMENDED design (all 4 pairs both directions, 4 cross-maker swaps, relearn).
  Blocks run Anthropic first (Haiku 4.5 is USD 153 of it), then OpenAI, Qwen, Gemma; each block carries one
  cross-maker swap, so a cut after any block still leaves both kinds of swap. The leg stays a secondary check, never
  a headline. The money needs the owner's yes with the rest of the cost statement.
- Tests: 30 unit tests pass; the 34-run pair flow passes after a re-run (the 50-minute limit was hit on the loaded
  machine and was raised); the training-resume test passes.

## Construct checks and free baselines handed back (24 Nov, about 06:20)
Files: `msr/construct.py`, `scripts/make_construct_assets.py`, `tests/test_construct_pure.py`, `tests/test_construct_sim.py`,
`runs/sim/analysis/construct_*.csv` + `CONSTRUCT.md`, `docs/construct_sim_patch.diff` (not applied). 26 new tests pass.
- The practice simulator has NO way for a stored answer's correctness to matter (success = hash of the item id plus a
  same-diagnosis bonus), so the practice numbers only prove the code runs. With the patch on (scratch copy) the
  grade's share of the home signal rises from 0.02 to 0.45 and the reference's home concordance from 0.51 to 0.73:
  the code detects the effect when it exists.
- Practice numbers, headline score: learned score concordance 0.68 at home, theta 0.38 (0.21 to 0.53); 21 % of
  candidates' stored answers equal the probe's answer, 29 % near-duplicates (on DDXPlus that mostly means "same
  diagnosis"); 4-13 % of items never shown. First-shown success: keep 0.606, wipe 0.576, stored-answer-correct
  0.568, re-answer 0.569, propensity-weighted 0.592 / 0.588.
- Cost faults found (real study, per swap day): the level-corrected log/Brier score needs 200 new-model calls nobody
  is charged for; the paired keep-or-drop check needs 800 OLD-model calls (before retirement); the forecast needs
  1,150 calls but shows 0; `own` is charged 27,000 where 3,750 is right. Sent to the statistics and theory workers.
- Rulings:
  1. Simulator: add the correctness effect as a config switch, OFF by default (so `sim` and `simfull` numbers and
     the scorer parity stay), and one small practice study with it ON for the paper's dry-run construct tables.
     Pipeline worker.
  2. Must be logged in the real run (pipeline worker, before any paid call): keep `store: all`; a second no-memory
     answer to each write task per model (about 12,000 cheap calls, add to the cost); every candidate's selection
     probability in each score-phase episode; rerun the construct module under BIRD's original grading.
  3. `test_bird_with_prefix_quirk` fails when the machine is busy because a SQL query times out. A grade must never
     depend on machine load: the grader must record "timed out" and retry, never count it as wrong. Pipeline worker.
  4. Three paper tables (correctness, baselines, the one cost table) are written by the statistics worker.

## Full-size dress rehearsal handed back (24 Nov, about 09:30)
Files: `docs/dress_rehearsal/` (`TRUTH.md` and `FAULTS.md` first; `DIFF.md`, `PROJECTION.md`, `stage_metrics.tsv`,
`checks.txt`), `config/sim_full.yaml`, `runs/simfull` 6.6 GB, `release/simfull` + `release/simfull_private`.
- All 2,240,400 simulated calls finished; Stage C ran all six k on all 384 cells. Resume test: stopped 89 s into
  the probe stage, exactly 3,465 calls redone, identical answers; repeats come from the cache, never paid twice.
- NOT finished: `msr.analysis` was stopped after 3 h 23 min (`arms_tables` alone 2.2 h), so the primary family has
  never been produced at full size. Sent to the statistics worker (must finish well under an hour).
- Against the planted truth: shuffled control 0.5001; self-swap drop -0.0005; theta per swap mean absolute error
  0.031, intervals cover the truth in 98 %; groups: upgrades 0.555 (true 0.549), downgrades 0.824 (0.801),
  cross-maker 0.319 (0.322).
- Scorer at k = 64: keep and recal_64 reproduce `arms.csv` with difference 0 on all 384 cells. But the sealed
  score takes 1.5 to 7 h per entry (trusted: 3 min) and the parity check needs 3 GB. Sent to the scorer builder.
- Paid-run projection: about 47 / 84 / 162 h at 16 / 8 / 4 calls at once if a call takes 1 s; disk 16-18 GB.
- Faults (none stopped the run): cache, prompt and spend files written in place; SQL timeouts cached for ever;
  online stage never above 6 calls at once (about 10 h); BIRD graded one by one; big results never cached;
  a needless BIRD re-run in evaluate (+57 min).
- Gate 4 failed in the simulation at 3 passes (106-121 items with 5+ visits, 150 needed).
- Rulings: fix all six pipeline faults before any paid run; gate 4 keeps the registered pilot rule (first pass in
  3..6 that reaches 150), the cost is budgeted at 5 passes and the rehearsal config moves to 5; online cells run
  in parallel; ONE full re-run of simfull only after the statistics and scorer changes have landed.

## Running now (24 Nov, 09:40)
- Pipeline phase 2 (same worker as the rehearsal): the six faults; new stages (new model as judge, owner's
  write-time self-rating, relearn on frozen content, re-exploration after the swap, second no-memory answer,
  selection probabilities logged, fresh home result per task); simulator correctness switch + `config/sim_construct.yaml`;
  explicit (owner, reader) cell list and the two extension pairs; config fixes; new cost in `docs/COST_2026-11-24.md`.
- Statistics core (plus the three construct tables, the cost-table fixes, the analysis speed fault).
- Theory (plus the true call counts of the keep-or-drop check and the forecast).
- Scorer fixes (plus full-size speed and parity memory).
Done and waiting for paper phase 2: agent leg, construct checks.

## Theory, revision 2 handed back (24 Nov, about 10:30)
Files: `msr/theory.py`, `msr/sequential.py`, `msr/forecast.py`, Part 11; paste-ready text in
`docs/handover/theory_round2.md` (9 sections). Whole suite at its end: 444 passed, 1 skipped, 1 xfailed.
All statements were re-checked in reviewer R6's own simulator, which they were not tuned on.
- Break-even question (is keep still better than wipe?): a one-sample betting test on the NEW model's checks only,
  no old-model call. Error at the exact boundary at most 0.039 in four worlds. At the practice signal it needs a
  median of 281 checks in the first-shown form (lower bound 100) and 364 in the ranking form (bound 69).
  "A few dozen checks" does NOT survive: 43 was right only under R6's variance model. Never write it.
- 0.75 question (was at most a quarter of the value lost?): holds with two conditions enforced in code (home signal
  shown positive by the one flag, else "not testable"; a stored home result per task used once, stream stops when
  they run out). False keeps 0.030 / 0.015. Median need 731 tasks (2,924 checks); bound 262 tasks [198, 366].
  It needs 8 old-model calls per task, before retirement. The study holds 400 evaluation tasks, so at the practice
  signal this check will often end "undetermined". That is the registered hard case.
- Lower bound holds with four qualifiers, now also for rules that choose cells (that lowers it 1.24-1.56 times).
  Wording: "any rule that checks whole tasks drawn at random".
- Forecast: "which model of a maker is newer" added to the controls; level 0.050-0.059; power at 8 models
  0.57-0.68 at rho 0.3; costs 1,150 calls per swap day.
- Decomposition: appendix measurement check only. It ties the plain baseline when both models are equally noisy
  and loses to "no change" when the reader is less noisy. Transfer slope at full size tracks the truth
  (correlation 0.968, all 56 intervals cover); printed only with its interval, and beside the truth only for simfull.
- Removed: "parameter-free", "accounts for", "about twice the bound" (true ratios 2.0-5.3), the 4-SE rules.
- Rulings: (1) lead the operator section with the break-even test; the 0.75 question is the hard case with its
  bound. (2) No new paid stage for home results: the probe stage's home cells already hold them; an optional
  extension to more tasks is priced as an option only. (3) P1 uses the forecast's test and controls (statistics
  worker pastes it). (4) New abstract sentence 5 accepted as written in the handover.
- Open for paper phase 2: six citation keys to add to the ledger; new macros (statistics worker).

## Paper phase 2a handed back (24 Nov, about 11:30)
- Theory, agent leg and construct text are in. `main.pdf` 35 pages, body ends in the left column of page 8;
  `dryrun.pdf` 39 pages. 0 undefined references. Page room is now tight: new tables must REPLACE text.
- Markers left: statistics 67, scorer 7, theory 0, leg 0. In the dry run 27 requested macros and 3 tables
  (`table_stakes_body`, `table_strata`, `table_agent_leg`) still print "missing".
- Ledger: 143 entries, 118 verified, 24 abstract-only (Berger 1982 added from two index records), 0 not found.
- Faults it found, sent to the statistics worker: `table_baselines.tex` has an unescaped "%" and breaks the build;
  `table_cost_one.tex` charges the paired check 800 old-model calls (true: 8 per task plus 800, about 6,650 to
  reach its median) and has no rows for judge, owner's rating, relearn, re-explore; P1 wording in A9 and A13
  still names the old permutation scheme.
- Corrected by the manager: the leg's README called MemRL's baseline "similarity-only memory"; the paper's
  Table 2 says the gain is over its strongest baseline (MemP), 2.6 points on the operating-system tasks, 2.8 overall.

## Statistics core, revision 2 handed back (24 Nov, about 13:00)
Files: `msr/metrics.py`, `msr/analysis.py`, `msr/evaluate.py`, `scripts/make_paper_assets.py`, Parts 0-10,
`tests/test_revision2_stats.py` (18). Final test runs and a second full-size timing were still going at hand-back.
- Three measures: value theta = V_swap / V_home, stakes = sqrt(S_reader / S_owner), order = theta / stakes
  (theta = order x stakes exactly). Medians within 0.011 of the truth. Coverage in our simulator 0.939-0.972;
  in the reviewer's simulator stakes 0.950-0.981, order 0.966-0.997, but THETA UNDER-COVERS where a few items
  dominate (0.902-0.946). Order is "not identifiable" when the reader's spread on calibration tasks is under z = 2.
- Variance: two-way delete-one-cluster jackknife, items coded by identity across orders. The 1.03 factor is
  withdrawn. Worst size 0.107 -> 0.063 in the reviewer's worlds, 0.0554 -> 0.0525 in ours. Every primary test
  reports its item share and effective item count; at full size the item share is 0.61-0.86 (concern mark 0.5).
- Tests: every PC1 member is an intersection-union test (home sign and the contrast); size at most 0.043 even
  with no home signal. One label function (`pc1_label`); "material drop" and "no material drop" can never both show.
- Primary family = 12 tests in one Holm family: PC1-drop, PC1-MD, PC1-NI and PC2, in each of three swap groups
  (upgrade, downgrade, cross-maker), pooled over streams. Worst family-wise error 0.046. PC3/PC4 secondary.
  Power with 6 same-maker swaps instead of 4: drop test at theta 0.85, 0.74 -> 0.93; PC2 at 1 point, 0.45 -> 0.68.
- Full-size analysis: 52.5 min on 8 processes (was unfinished after 3 h 23 min), 6.9 GB peak. The 12-test family
  was produced at full size for the first time. Practice study: under 2 min.
- Separate-session repeats are needed: same-session repeats inflate the stakes about 1.32 times at a cache rate
  of 0.1.
- Paper: specials escaped with a lint test; 0 macros missing; the 3 new tables exist; the dry run compiles.
- Rulings:
  1. Coverage where items dominate: try a t reference with effective-cluster degrees of freedom on top of the
     jackknife; targets worst size <= 0.055 and theta coverage >= 0.94 in every world; if not reached, the paper
     states the measured level as a limitation. (Statistics worker, follow-up running.)
  2. Open point 29: P1 and the forecast's test use the CORE grid only (8 models, 4 makers); extension pairs enter
     only the same-maker group estimates, the spread summaries and descriptive tables.
  3. Separate sessions: repeat 2 of every cell runs in a later session, no extra calls; logged and enforced by the
     pipeline; the definition of "a later session" goes into the pre-registration.
  4. One flag: the scorer (`scoreswap/export.py`) and the construct module still had their own rules; both sent back.
- Sentences for the paper (P1, P2/P4, P3, PC1, PC2, spread, theta interval) are in the worker's report, passed on.

## Construct follow-up done (24 Nov, about 13:40)
- `msr/construct.py` now uses the one flag (`msr.metrics.home_signal_flag`) everywhere; its z values equal the
  analysis's exactly. Every theta row carries order and stakes too (headline, all swaps, practice study:
  theta 0.383, order 0.429, stakes 0.893).
- `construct_costs.csv` reads the same functions as `table_cost_one.tex`; the duplicated "charged now" columns are
  gone. With 5 passes budgeted in `config/study.yaml`, one registered build is 5,750 calls (was 3,750); the cost
  table shows it once regenerated.
- 30 construct tests pass. No reading or baseline number moved by more than 0.01.

## Owner asked why a key is needed; opencode re-tested (24 Nov, about 14:30)
- `opencode models` lists 18 Anthropic models and 10 free ones. A one-word test to `anthropic/claude-haiku-4-5`
  through opencode returns "Error: invalid x-api-key": the list is a catalogue; the Anthropic key stored in opencode
  is still rejected. A one-word test to a free model answered. The free allowance is small (ran out after a few
  dozen calls on 23 Nov), shared, and used by the owner's other application.
- Told the owner: fix with `opencode auth login` (Anthropic, a valid key with credit), or keys in `.env`.

## Paper phase 2b handed back (24 Nov, about 14:45)
- `main.pdf` 37 pages, `dryrun.pdf` 41 pages; both bodies end on page 8 with every table in (decision table moved
  to the appendix); 0 undefined references, 0 "missing" macros or tables. Ledger 145 entries, 120 verified,
  24 abstract-only. Markers left: scorer 7, statistics-final 3.
- Dry-run switch: one line, `\newcommand*{\PracticeStudy}{sim}` in `paper/dryrun.tex` (change to `simfull`).
- Ten disagreements between the pre-registration and the paper/code, all sent to the statistics worker with rulings:
  relevance embeds the task text only; the added baselines and construct checks are REGISTERED as secondary (not
  "exploratory"); terciles stay registered, fixed visit bins as sensitivity; paired-check cost; passes fixed by
  the pilot rule (budget 5); P1 leave-one-out 8 times; maker-term fit as coded if well conditioned; later-session
  repeats for EVERY cell including home cells; the release split registered; method-validation numbers allowed in
  the submission only through macros from `docs/power/`.
- For the paper's last pass (2c, after statistics-final and the scorer): scorer lines; "exploratory" -> "registered
  secondary"; abstract outcome words ("barely better than wiping") must not follow the dry run in `main.pdf`.

## Scorer fixes handed back (24 Nov, about 15:15)
Files: `scoreswap/`, `docs/BENCHMARK_GUIDE.md`, `tests/test_scoreswap_*.py`, `release/sim` re-exported in the new format.
- Cheating routes closed: the test half's outcomes exist only in the private pack (sha256 commitment in the public
  manifest; boards rank on test; `check --private` fails an entry that leads much more on development than on test);
  an entry is one file; on Linux the kernel (Landlock + seccomp) lets a call read only Python, `scoreswap/` and
  `msr/`, with no writes, pipes, sockets, shared memory or new processes; every (cell, draw) call is a fresh
  process; names are drawn anew per call. Not guaranteed: off Linux (audit hook only), kernel bugs, timing
  channels, conditioning on model names. Tuning on the development half is allowed.
- Sealed speed at full size (76,800 calls): 19-22 min per entry (was 1.5-7 h), peak 1.3 GB, measured on a loaded
  machine. Parity under 2 GB: all match, peak 1.04 GB, 25 min.
- Non-square grids work; incomplete cells are left out and listed in the manifest. One flag everywhere
  (`msr.metrics.home_signal_flag`). Boards show theta, order and stakes.
- New commands: `describe --pack`; `--private`, `--split dev|test|all`, `--workers`, `--timeout`.
- Tests: scorer's own 55 pass; 7 parity tests held until the statistics worker's final pass. Whole suite 535 passed,
  4 failed (`test_dress_rehearsal` x2, `test_pipeline_sim`, `test_prereg_alignment`), from the pipeline worker's
  config edits in progress; sent to the pipeline worker.
- Ruling: "Every number in this paper comes from released files" is false with a private test half. New sentence:
  "Every number in this paper is rebuilt by one script from the two packs together; the public pack alone
  reproduces every board on the development half." Paper worker (phase 2c part 1, running) puts in the 7 scorer lines.

## Running now (24 Nov, 15:20)
- Statistics follow-up: t reference for item-heavy worlds; open point 29; ten pre-registration alignment items.
- Pipeline phase 2: faults, new stages, extension pairs, config, cost; then the one-command re-run script.
- Paper phase 2c part 1: scorer lines, the reproducibility sentence, no practice outcome words in `main.pdf`.
Then: one simfull re-run, re-export of both packs, parity, dry run on simfull, review round 3, cost statement.

## Paper phase 2c part 1 handed back (24 Nov, about 15:50)
- Scorer lines in; the reproducibility sentence corrected; `main.pdf` (37 pages) has no practice-data outcome words
  (checked by text search: 0 hits); `dryrun.pdf` 41 pages; both bodies end on page 8; 0 "missing".
- Markers left: 3 `WAIT-STATS-FINAL` only. Ledger unchanged: 145 entries, 120 verified, 24 abstract-only.
- Ruling for part 2: abstract sentence 5 gets the same split as sentence 4. What stays in the submission version is
  the design fact (the break-even question needs only the new model's checks; the strict question needs both
  models); the sizes ("a few hundred", "hundreds of tasks") are practice-signal numbers and become placeholders.
- Part 2 waits for the statistics worker's final pass: 3 marked lines, "exploratory" -> "registered secondary",
  abstract sentence 5, then the dry run switches to the full-size rehearsal.

## A WORKING ANTHROPIC KEY EXISTS (24 Nov, about 16:30)
- The owner pasted an Anthropic key and said: use all the Anthropic models and all the opencode models now.
  It is in `.env` (owner-only file). `scripts/check_keys.py`: ANTHROPIC present; OpenAI, OpenRouter, DashScope
  missing. THE KEY EXPIRES ON 24 DEC 2026: every Anthropic call of the study must be done before then, or a new key.
- Tested through the SDK: the key lists 14 models (Haiku 4.5, 5.5; Sonnet 4.6, 5, 5.5; Opus 4.5 to 5.5; Fable 5 to
  5.2). One-word calls to `claude-haiku-4-5-20251001` and `claude-haiku-5-5` both answered; served model = asked model.
- On the owner's instruction the same key was put into opencode's credential store (the old, rejected key is kept
  in a backup file beside it). `opencode run -m anthropic/claude-haiku-4-5` now answers. In this folder opencode
  starts on `anthropic/claude-sonnet-5-5` (`opencode.json`) and reads `AGENTS.md` (the hand-over for an agent that
  continues here when this session's weekly limit ends).
- The owner says about USD 150 of credit is on the account. That credit pays for the study AND for the owner's
  coding agent in opencode.
- Prices confirmed: Haiku 4.5 USD 1 / 5, Haiku 5.5 USD 0.10 / 0.50 per million tokens.
- Estimates (nothing called): pilots USD 7.88 + 13.14 + 7.88 = 28.90 (inside the USD 30 cap). Full 12-model study at
  5 passes with the new stages: USD 855.68.
- Free opencode models: the owner's word to use them is given. The allowance is the limit, not permission: about
  33 calls on the one day it was measured, shared by all free models and by the owner's other application, daily
  reset. One study cell needs thousands of calls, so they cannot carry a study.
- Ordered (pipeline worker): finish the fixes a paid run needs, smoke test on the two Haiku models, then the three
  pilots one after another with an interim report after the first; cost document with "what can run with the
  Anthropic key alone" (option A Haiku pair; option B plus the Sonnet pair), list price and Batches price;
  `config/study_anthropic.yaml` whose calls are all reused by the full study. Nothing beyond USD 30 without the
  owner's yes.

## Running now (24 Nov, 16:40)
- Pipeline worker: paid-run fixes -> smoke test -> pilots (Haiku pair) -> rest of phase 2 -> cost document.
- Statistics worker: t reference for item-heavy worlds; ten pre-registration alignment items; final test counts.
Waiting for those: paper phase 2c part 2 (3 marked lines, "exploratory" -> "registered secondary", abstract
sentence 5, dry run on simfull); one simfull re-run with `docs/dress_rehearsal/run_all_after_changes.sh`;
re-export of both packs; scorer parity; mock review round 3; cost statement to the owner.

## Owner-only items (kept current)
1. Money: yes or no on spending beyond the USD 30 cap, once the cost document is ready.
2. Keys for the other makers: OpenRouter (Qwen, Gemma, Mistral, DeepSeek; about USD 20 to start) and OpenAI (Luna
   pair). Without them the paper has only Anthropic models and cannot make its cross-maker claim.
3. A new Anthropic key before 24 Dec 2026 if the runs are not finished by then.
4. Employer clearance; author list and OpenReview profiles by 14 Jan 2027 (authors without an eligible reviewer may
   be on at most 2 submissions); financial conflict-of-interest disclosure at submission.
5. Read six OpenReview papers in a browser (ids in the section "Round 2 complete"); verify the 24 abstract-only
   references; edit the AI Disclosure Statement; deposit the frozen pre-registration at an anonymous registry.
6. The key was pasted into a chat: consider making a fresh key after the runs and deleting this one.

## Smoke test passed; pilot start blocked by the permission check (24 Nov, about 17:00)
- Smoke test on `haiku-4.5` and `haiku-5.5`: spend USD 0.000038. Served model = pinned id on both; tokens and price
  in `runs/spend.json` match list prices; a second run came from the cache at no cost; thinking off on 5.5.
  Anthropic returns 0 cached tokens: we never ask it to cache and it does not cache on its own, so the provider
  cache rate is 0 for Anthropic.
- The pipeline worker's command to start the paid `pilot_shot` run (USD 7.88) was DENIED by this session's
  permission check. Nobody worked around it. It needs the owner: either the owner runs the command, or the owner
  says yes to that run in their own words. The pilot configs are ready (gap 0, 4 calls at once).
  Command (from the project root):
  mkdir -p runs/pilot_logs && systemd-run --user --unit msr-pilot-shot -p MemoryMax=6G -p CPUQuota=500% \
    --working-directory="$PWD" bash -c '.venv/bin/python -u run.py --study config/pilot_shot.yaml --yes --workers 4 > runs/pilot_logs/pilot_shot.txt 2>&1'
- Meanwhile the pipeline worker continues with `config/study_anthropic.yaml` and the Anthropic-only cost section.

## Statistics follow-up: final report (24 Nov, about 17:30)
- Tests after its last edit: 557 passed, 1 failed (`test_stopped_probe_resumes_from_the_cache`: the probe resume
  code the pipeline worker is editing).
- Coverage where items dominate: SOLVED without a new method. With the registered two-way jackknife the worst test
  level is 0.052 at nominal 0.05 and theta's 95 % set covers 0.940-0.978, in every world, including two new
  item-heavy worlds (item share 0.73-0.90). The earlier 0.902-0.946 and 0.063 came from the round-1 variance.
  The t reference was tried and not adopted (it never moves a number by more than 0.004). The code now also shows
  a t p-value when df < 100 and an item note when the item share is 0.5 or more. `docs/power/coverage_items_t.*`.
  Still to refresh: order and stakes coverage under the final variance.
- Open point 29 closed: P1 and the forecast's test run on the core grid only (code and Parts 7, 11.3.8).
- "A later session" defined (Part 2.4): at least 6 h after the earlier repeat, new process and HTTP session,
  provider caches off where possible, same prompt and settings; for repeat 2 of every cell, home cells included.
- All ten paper/pre-registration disagreements fixed in Parts 0-10 (new Parts 1.8 and 8.2.18-8.2.25).
- Second full-size analysis timing: 70.9 min under load 55-84 (about 35-40 min on a quiet machine). Ruling: keep
  the registered 10,000 bootstrap draws for the secondary intervals.
- Open point 30 (new): analysis code for the judge, self-rating and relearn scores and re-answer's home value does
  not exist yet; it follows the pipeline worker's new stages.
- Ordered: paper phase 2c part 2 (final text, registered secondaries, abstract sentence 5, round-3 reviewer
  folder); scorer parity tests on the practice study.

## Paper text complete for revision 2; mock review round 3 started (24 Nov, about 18:15)
- Paper phase 2c part 2 done: `main.pdf` 37 pages, `dryrun.pdf` 41 (still on `sim`), both bodies end on page 8;
  0 markers of any kind, 0 "missing", 0 undefined references. `main.pdf` holds no practice outcome words and no
  practice numbers; method-validation numbers print through `\MethodRes{...}`. Ledger 145 / 120 verified / 24
  abstract-only. Reviewer folder: `paper/reviews/round3/README.md`.
- Left for the pass AFTER review round 3 (bundle with the reviewers' fix list; do not start separately):
  1. Pre-registration open points 23 and 28 are stale (ledger state); three works named in the pre-registration
     are not cited in the paper (MacKinnon-Nielsen-Webb, Viechtbauer, Ville).
  2. Part 8.2.24 registers fixed reading words for the construct checks; no macro or table carries the word.
  3. Open point 24: for the z-scored mix, `recal_k`'s standardising SD and the post-swap starting counts, the code
     differs from my earlier rulings; the paper follows the code. Decide per item: keep the code and change the
     text unless the code is statistically wrong.
  4. Method-check numbers from the theory hand-over (A8, A15, A3b) and the 1.32 caching factor are plain text in
     `main.pdf`; move them behind `\Method*` macros generated from the simulation outputs.
  5. Refresh order and stakes coverage under the final variance (statistics).
  6. Open point 30: analysis code for the judge, self-rating, relearn scores and re-answer's home value.
- Mock review round 3: two fresh reviewers started (statistics and theory; novelty and positioning). They may not
  read earlier reviews or this file. Reports go to `paper/reviews/round3/R7_statistics_theory.md` and
  `R8_novelty_positioning.md`. The third reviewer (benchmark user, runs the scorer) starts when the scorer's
  parity check has finished re-exporting `release/sim`.

## Scorer parity under the final statistics: passes (24 Nov, about 18:45)
- `runs/sim` re-evaluated and re-analysed with the final code; `release/sim` and `release/sim_private` re-exported.
- All 7 parity tests pass, including theta, order, stakes and their intervals against `theta_pairs.csv` (160 rows,
  largest difference 5e-7 = file rounding; flags match on every row). 63 scorer tests pass.
- One rule decides the home signal in `scoreswap/`: `msr.metrics.home_signal_flag`. A new test fails if another
  threshold comes back. The held-out over-fitting alarm is a named constant (`HELD_OUT_SE = 3.0`).
- Third reviewer of round 3 (benchmark user) started; report to `paper/reviews/round3/R9_benchmark_user.md`.

## Pipeline phase 2 handed back; cost known; simfull re-run started (24 Nov, about 19:15)
- Whole suite: 561 passed, 0 failed. All six pipeline faults fixed with tests (`docs/dress_rehearsal/FAULTS.md`):
  atomic cache/prompt/spend writes; SQL limit counts the query's own CPU time, timeouts never stored, retried,
  else "ungraded: timeout"; online cells in parallel; grading as calls return; big results cached by fingerprint;
  no needless BIRD re-run. Every call stops the run if the served model or host differs from the pin.
- New stages built, cached, resumable, each in the estimate: judge, write-time self-rating (does not overlap
  `tags_self`), relearn, `reexplore_25/50`, second no-memory answer; all candidates' selection probabilities
  logged. No new stage for home results (the probe stage holds them). Simulator correctness switch off by default;
  `config/sim_construct.yaml` ran (grade carries 0.44 of the home signal with the switch on).
- Repeat sessions enforced as registered (6 h gap, new process, logged). Anthropic: prompt caching off, 0 cached tokens.
- Extension pairs added as same-maker cells only (groups 6/6/48). `config/sim_phase2.yaml` (every new stage on) ran
  end to end twice: 94,420 calls = the plan. DeepInfra pins `deepinfra/fp8`; Gemma commits recorded.
- COST (`docs/COST_2026-11-24.md`): main study 3,330,000 calls, USD 850.91; with pilots and side studies USD 948
  (805 to 1,346); Haiku 4.5 is USD 424 of it. Agent leg not included: USD 356 (249 to 889).
  With the Anthropic key alone: option A (Haiku pair, whole design) USD 225 list / 162 with batches; A on DDXPlus
  only USD 86 / 62; A on one order USD 75 / 54; A on DDXPlus one order USD 29 / 21; option B (plus Sonnet pair)
  USD 1,657 / 1,122. The Batches route is not built (about one day of work).
- Rulings: `check_store` extension not funded now (if ever: without the extra home repeats, USD 119). Recommend
  to the owner: pilots (28.90), then option A on DDXPlus only (86 at list price). Both need the owner's yes.
- The paid pilot start is still blocked by the permission check; waiting for the owner's own word.
- simfull re-run STARTED by the manager: unit `msr-simfull` (MemoryMax 8G, CPUQuota 300 %, nice 10),
  `docs/dress_rehearsal/run_all_after_changes.sh`; log `docs/dress_rehearsal/run_all_log.txt`, figures
  `stage_metrics_rev2.tsv`. The first rehearsal was moved to `runs/simfull_rev1`. When it ends: read the log's
  last lines, then set `\PracticeStudy` to `simfull` in `paper/dryrun.tex` after rebuilding `paper/assets` with
  `PAPER_OUT=paper/assets FROM=paper`.

## Round 3, first review in: R8 novelty and positioning (24 Nov, about 19:45)
File: `paper/reviews/round3/R8_novelty_positioning.md` (+ `r8_notes/evidence_excerpts.md`).
- Overall: (a) as it stands 1 (no results; the ICML call warns that placeholder abstracts risk removal);
  (b) with dry-run-like results 3 as written, 4 once the novelty claim and the wrong prior-work sentences are fixed;
  (c) no signal even at home 2. Soundness 2, Presentation 2, Significance 2, Originality 2. 1 fatal, 6 major, 4 minor.
- No hallucinated reference found: every cited work exists.
- Major points: W2 the "has not been measured" claim is overstated (Chang & Jia 2023 and Nguyen & Wong 2023
  measured cross-model agreement of per-example usefulness; both in our bib, not cited; Yang et al. 2026,
  arXiv 2611.03930, concurrent); W3 seven wrong or unsupported sentences about prior work; W4 the title is
  broader than the setting (one item of four, single-call tasks, reasoning off) and the agent leg will likely be
  uninformative (detects 5 points, MemRL's gain is 2.6); W5 the model set cannot support conclusions about kinds
  of swap (6 same-maker pairs, cheap tiers, reasoning off, open vs closed confounded with maker); W6 significance
  rests on research systems (only one product keeps such a weight, off by default); W7 the benchmark is not yet
  adoptable (no item text, licences and datasheet TODO, no Croissant metadata, closed-model board freezes).
- Ordered now (paper worker, phase 3a): narrow the novelty claim, cite and describe the 2023 and concurrent work
  correctly, fix the seven sentences against their sources, ledger entries. Title, abstract claims and
  limitations wait for the other two reviews.

## Round 3, second review in: R9 benchmark user (24 Nov, about 20:15)
File: `paper/reviews/round3/R9_benchmark_user.md`; every attack is runnable in `paper/reviews/round3/r9_user_test/`.
- Overall: (a) as it stands 2; (b) with dry-run-like results 4 only if W1-W4 are fixed, 3 with the tool as it is;
  (c) 2. Soundness 2, Presentation 3, Significance 2, Originality 3. 1 fatal, 6 major, 8 minor.
- The tool is easy to pick up, and the file sandbox held (private pack, `.env`, `/proc`, `/etc` refused by the
  kernel). But two central promises fail:
  W1 (fatal, fixable): the check budget cannot be enforced, because the results checks are drawn from are public;
  an entry carrying the public calibration results ranks first with 0 checks used.
  W2: information passes between calls (resource limits set on the launcher; file access times), so "nothing
  reaches the next call" is false; pooling the checks of all 200 draws passes `check`.
  W3: a sealed call changed a limit of a process in another unit and counted the user's processes; no memory or
  total-time limit. W4: an entry can tell `check` from `score` (3 draws vs 200), so a pass certifies nothing.
  W5: no submission channel, rate limit, public log or plan to open the commitments. W6: the board labels keep
  and the paper's rules "no home signal" wrongly. W7: score-type boards rank by a ratio, so the no-signal control
  `visits` ranks first.
- Rulings (scorer builder, running): (1) calibration tasks split into a public development pool and a PRIVATE
  ranked pool; the ranked board = private check pool + private test half, run by maintainers; the public pack
  gives a development board only. (2) The whole entry run goes inside a bubblewrap namespace jail (read-only minimal
  root, own PID/network/IPC namespaces), fork-per-call inside, seccomp extended, memory and time limits, messages
  from a call authenticated; no jail means no ranked result. (3) `check` and `score` indistinguishable to an entry;
  the alarm runs on the full score. (4) Board bug fixed; score-type boards rank by the value after the swap, with
  the controls in their own block. (5) Governance text for the guide and the paper.
- Note: the reviewer saw `release/simfull` disappear; that was the re-run script moving the first rehearsal's
  packs to `release/simfull_rev1*`.

## Round 3 complete: with real results and the fixes, all three reviewers say 4 (24 Nov, about 20:45)
Third review: `paper/reviews/round3/R7_statistics_theory.md` (+ `r7_checks/`, the reviewer's own simulator).
| Reviewer | (a) as it stands | (b) real results like the dry run | (c) no signal at home |
|---|---|---|---|
| R7 statistics and theory | 2 | 4 if the variance flaw is fixed | 2 |
| R8 novelty and positioning | 1 | 3 as written, 4 once prior work is fixed | 2 |
| R9 benchmark user | 2 | 4 if W1-W4 of the tool are fixed, else 3 | 2 |
Round 2 was 3 / 3 / 3. "As it stands" is a reject for all three for one reason: there are no real results.

R7's findings (1 fatal = no results; 4 major; 7 minor):
- W2 (major, real): items are clustered per owner, but every owner's items come from the same write tasks. In
  tests that pool owners the variance is too small: null z spread 1.67; false rejections 0.158-0.225; theta
  coverage 0.727; family error 0.147 against our stated 0.046. Clustering by write task restores nominal levels.
  Our simulators give each owner its own items, so they could not see it.
- W3: group results describe a few model-sharing pairs; the prediction interval treats 48 cross-maker swaps as
  independent. W4: the 0.75 margin's conversion to success points has no derivation; "retained order" is a
  correlation-type measure (0.896-0.995 when the order is fully kept). W5: operator advice rests on selected,
  unadjusted comparisons (winner's curse).
- Held up: both swap-day tests valid in the reviewer's worlds; the lower bound's proof correct; the jackknife holds
  its level where items are not shared between owners.
- Minor: the 0.75 proposition's text says a drop needs no home-sign check (the code is right, the text wrong); the
  lower bound is a second-order approximation (exact bound 1.7-3.6 times larger when outcomes are near
  deterministic) and is compared with medians; checks taken in topic order break the break-even test (0.749 wrong
  keeps); the home gate leaves half of swap days untestable at sparse signal; copying between repeats breaks the
  stakes; forecast and P1 fragile; ten pre-registration / code / paper mismatches.

REVISION 3 DECISIONS (manager)
E1. Item cluster = WRITE TASK within stream for every statistic that pools more than one owner. Our simulators get
    a write-task effect shared across owners. All power figures recomputed. (statistics; theory in its files)
E2. Scope: inference holds the models fixed; crossed (owner, reader) prediction interval or none; same-maker groups
    reported with and without the two extension pairs; unweighted mean of per-pair theta as a registered sensitivity.
E3. Names: "retained order" -> "retained agreement" (a noise-corrected correlation); value = agreement x stakes; a
    rank-based companion (Cw) beside it; "not identifiable" -> "not estimated (reader's spread below z = 2)".
    The 0.75 margin: derive its conversion to success points or state it as a convention.
E4. Operator advice: the best rule is estimated by cross-fitting; the decision table uses registered tests and
    cross-fitted estimates only, labelled descriptive.
E5. Swap-day theory: the home-sign condition covers drops too (text follows code); exact lower bound beside the
    approximation, compared with means; random-order condition stated and enforced; forecast's fragility stated.
E6. A registered check of the later-session condition from the data (copying between repeats).
E7. Scorer (R9): private check pool for the ranked board; bubblewrap jail; `check` = `score` for an entry; board
    fixes; governance text. (scorer builder, running)
E8. Prior work (R8): narrow the novelty claim; cite Chang & Jia 2023, Nguyen & Wong 2023, Yang et al. 2026 and the
    two swap-day analogues; fix seven sentences. (paper worker, running)
E9. Title gets its scope: "ScoreSwap: Are Learned Exemplar-Memory Scores Worth Keeping After a Model Swap?"
    (paper worker, after 3a); limits of the model set (cheap tiers, reasoning off, open vs closed confounded with
    maker) and of the agent leg stated in the introduction, not only in limitations.
E10. Benchmark adoption (R8 W7): item text in the pack where licences allow, a datasheet, Croissant metadata,
     licence files, a maintenance and versioning statement, what happens when closed models retire.
E11. The pre-registration's open points must reach zero before the freeze (30 today).
E12. Nothing fixes "no results" except the paid runs: pilots, then the Haiku pair, as soon as the owner says yes.

Running now: statistics revision 3; theory revision 3; scorer fixes; paper phase 3a; simfull re-run (probe stage).

## Paper phase 3a handed back: prior work corrected (24 Nov, about 21:15)
- `main.pdf` 38 pages, `dryrun.pdf` 42; both bodies end on page 8; 0 undefined, 0 missing, 0 markers.
- Ledger 149 entries: 122 verified, 25 abstract-only, 0 not found. New: Yang et al. 2026, the two swap-day
  analogues (abstract-only), Cognee (code checked at a commit).
- Novelty claim narrowed: "This has been measured before" for fixed items across models (Chang & Jia Table 4
  confirmed; Nguyen & Wong; Selection via Proxy; Yang et al.); what is new is the object (scores learned from use)
  and the operator's question (worth after a swap, at a stated cost, net of repeat noise).
- All seven sentences re-checked against sources and corrected. Two disagreements with the reviewer, both sourced:
  the own/pooled/donor wording did come from that submission's author response (removed anyway: not archival);
  MemRL's paper lists a start of 0 with rewards in [-1, 1], its released configuration for operating-system tasks
  uses 0.5 with rewards 0/1, and the two rules give the same order (both now stated).
- 62 attributed sentences in Sections 1, 2 and 6 re-checked: 59 confirmed, 2 corrected (ACE, ExpHarness).
- Next paper pass (3b) is ONE pass after statistics, theory and scorer revision 3 land: new title (E9), the names
  of E3, scope statements (E2, E9), cross-fitted advice (E4), theory text (`docs/handover/theory_round3.md`),
  scorer guarantees and governance (E7), benchmark adoption items (E10).

## Scorer round-3 fixes handed back; one design ruling (24 Nov, about 21:45)
- Every attack the reviewer ran is now blocked or (model/cell detection) stated as not stoppable: carried check
  pool 0.000 on the ranked board; launcher limits refused; pooled checks refused; access times unchanged
  (read-only mounts); `check` and `score` look the same to a rule; other processes invisible (own PID namespace);
  `stat` outside the jail fails; forged messages rejected; memory cap and time budget per entry. Each launcher runs
  under `bwrap --unshare-all` with read-only binds only; Landlock kept as a second layer; without bubblewrap a
  ranked result is refused. New tests: `tests/test_scoreswap_r9.py` (18), fixtures in `tests/scoreswap_r9/`.
- Board bug cause: the paper's rules came from a cache without the arrays the flag needs; they now run through the
  same harness. Score-type boards rank by value after the swap; controls in their own block.
- Governance text written (guide + paragraph for the paper). Rate limit accepted: 2 ranked runs per team per
  month, 10 per pack. Pack format is now `scoreswap-release/3`.
- STILL OPEN at hand-back, found by the builder itself: an entry that carries what PUBLIC results say about each
  stored item gains +0.098 on the ranked board (honest 16-check rule: +0.006), because the same items appear on
  public tasks.
- RULING: hold out WHOLE BANKS. The private side is a set of owners (all their banks, every reader's results on
  them); the public side is the other owners, complete. Owners drawn by a seeded, stratified rule (each side gets a
  closed and an open maker in the real study). Ranked board = cells whose owner is private. No item text and no
  write-task identity for private banks. Rejected: handing every entry the public per-item evidence (it would
  change the question the board asks). Builder is implementing; its test runs were unfinished at hand-back.

## After a network failure and a restart: where things stand (24 Nov, 20:30 by the machine's clock)
(Earlier time stamps in this file were the manager's guesses and run several hours ahead; file dates are the truth.)
- At about 11:40 the network failed and cut off the statistics, theory and scorer workers in the middle of
  revision 3. The full-size re-run went on alone: build, probe, judge, relearn, online, evaluate and the truth steps
  finished; its `analysis` step was killed by the 8 GB memory limit at 16:01 ("arms, k-curves, equal budgets").
  The machine restarted at 20:08.
- The owner said "complete the remaining". Three fresh workers were started with full briefs to finish
  statistics revision 3 (and the full-size analysis, under 7 GB), theory revision 3 (`docs/handover/theory_round3.md`)
  and scorer revision 3 (three failing attack tests first, then the whole-bank private side, datasheet,
  Croissant metadata). Each appends its own section here.
- FIRST PAID PILOT STARTED by the manager on the owner's word: unit `msr-pilot-shot`, `config/pilot_shot.yaml`
  (Haiku 4.5 and 5.5, DDXPlus, estimate USD 7.88, cap USD 30), log `runs/pilot_logs/pilot_shot.txt`, spend in
  `runs/spend.json`. Next: `pilot_bird` (13.14) and `pilot_memprompt` (7.88), one after another.
- After the three workers: ONE paper pass (3b: new title, "retained agreement", scope, cross-fitted advice, theory
  text, scorer guarantees and governance, adoption items), dry run on the full-size rehearsal, then the pilot
  gates, the pre-registration freeze, and the Haiku pair on DDXPlus (USD 86) if the owner says yes.

## Theory, revision 3 handed back (24 Nov, about 21:30 by the machine's clock)
Nothing of the cut-off worker's revision 3 had reached my files (all dated from revision 2; their tests passed, 119),
so revision 3 was done from that state. Files: `msr/sequential.py`, `msr/theory.py`, `msr/forecast.py`, their tests,
Part 11 ("What changed in revision 3"), `docs/handover/theory_round3.md` (changed LaTeX only, old -> new by label),
`docs/power/forecast_r7_w11.json`. Each module landed in one step (temporary file, then rename).
- W6 (drop and the flag): the code was right. Proposition, proof and Part 11 now say both decisions need the flag:
  a keep (drop) is wrong with probability at most max(alpha, alpha_flag) whenever theta <= 0.75 (>= 0.25) or
  Abar_home <= 0. Counter-example now in `sequential_gate.csv` (part drop_counter_example): reader at theta = 1 against
  a reversed home order, ungated drop 0.999 of 1,000 streams, gated rule 0 keeps, 0 drops, 1.000 not testable.
  "Not testable" means: answer the break-even question instead (NOT_TESTABLE_ACTION).
- W7 (the bound): the theorem bounds the MEAN; means are now compared with it at the rule's measured power, medians
  apart and labelled. The exact bound is solved where the chances are known, with a two-way interval (the per-task
  Lagrangian is K's influence; task id x write task); on real data it cannot be estimated from a few repeats per cell
  (the exact bound on the table of observed means was about 0.5 x the truth with two repeats where chances are spread,
  2-30 x where cells are near 0 or 1), so real-data rows give the second-order value as an approximation plus a new
  GUARANTEED FLOOR: exact >= (1 - x - x^2/4) x second order, x = c_max |theta_1 - theta_0| Abar / E sigma^2 < 0.83
  (proof in the module docstring and Part 11.4.10; checked <= exact in R7's four worlds and ours). Practice study,
  margin 0.75, power 0.8: exact at the simulator truth 262 tasks [169, 405]; second order 257 (truth) / 262 (plug-in,
  two-way [140, 491]; the revision-2 bootstrap [198, 366] was too narrow: write tasks carry 86 % of the variance);
  floor 207 [100, 425]. Margin 0: exact 17.3 tasks [11.4, 26.1]; no useful floor (x = 0.81). Paired test at theta = 1:
  mean 803 tasks = 1.95 x the bound at its power (median 730.5 = 2.79 x the bound at 0.8); reviewer model 1.54
  (median 2.1). Ranking break-even test: mean 3.5 x; decision form 1.94 x.
  Also fixed: margin-0 "needed" rows on a REAL (plug-in) study table used the exact bound on observed means (biased);
  they now report the second-order value from unbiased moments (`bound_basis` column); a 0/0 in the least-favourable
  root for cells observed at 0 is fixed.
- W8 (order): the random-order condition is in Propositions M0 and 1, Part 11.4.0 and the operator text ("checks must be
  drawn at random by the harness, not chosen or ordered by the operator"). The replay draws its own order
  (`harness_order`) and raises `NonRandomOrderError` for a given order unless `diagnostic=True` (rows then say so).
  R7's topic-block case is a test (his own script, read-only) and `sequential_order.csv`: false keeps 0.961 in topic
  blocks against 0.024 in random order (our hetero world, 1,000 streams).
- W11 (forecast): numbers in `docs/power/forecast_r7_w11.json`. F1 and P1 detect pair- and model-level association
  alike: a model property raising both ec and theta gives 0.085 / 0.17 / 0.45 false rejections as it grows (0.06
  without); owner + reader fixed effects fix it (0.046-0.056) but power at rho 0.3 falls 0.60 -> 0.48; curved capability
  0.106 (0.102 with fixed effects); selection by the flag does not raise the level. The docstring's earlier
  fixed-effect numbers had no code behind them (corrected). RECOMMENDATION: F1 becomes exploratory (sentence in the
  handover, 2f and 7); P1 uses the same test and has the same limits (Part 7 is the statistics worker's).
- E1 (item clusters): `msr/theory.py` codes items by write task within stream (`ITEM_CLUSTER`, `write_task_key`);
  per-swap numbers identical (checked byte for byte); pooled family-T rows change and carry the owner coding as
  `se_owner_coding`. The swap-day plug-in bound now uses a two-way interval with write tasks. The forecast pools no
  owner through an item cluster (its intervals hold write tasks fixed; stated).
- Margin translation 0.25 x (keep - shuffled): WITHDRAW (no derivation in the theory material; it holds only if the
  reader's within-task differences are a fixed multiple of the owner's on every task).
- Mismatches: replay cap 200 tasks per order is right (11.4.6 said 300); old-model calls for the median stop 6,644 =
  8 x 730.5 + 800 is right (Part 6.4's number; the docstring's 5,850 left out the flag's 800); the drop gate (code
  right). Not mine, left for the statistics worker: Part 2.4 lines 474-475 and open points 27(a), 27(d) still say
  Part 11.1 names the 4-SE rule (it does not since revision 2).
- New macros for the paper (statistics worker): CheckBoundKeepFloorTasks(/Lo/Hi), CheckPairedMeanTasks,
  CheckMarginZeroRankingMeanChecks, CheckMarginZeroFirstShownMeanChecks; drop MarginPointsAllSwaps (handover 8).
- To regenerate the dry-run tables: `python -m msr.sequential --study <study>` (and msr.theory, msr.forecast) after the
  statistics worker's analysis; the sim practice tables in runs/sim/analysis are still revision 2's.
- Tests at hand-back (whole suite, landed code): 608 passed, 1 failed, 0 skipped. The failure (test_embed_retrieval_sim, cache file count) is a race with the running pilot writing runs/_cache; it passes alone and does not touch these modules. msr.metrics was unchanged at hand-back (07:22): every call into it (robust_variance, calibration_z, signed_validity_parts, theta_status_calibration, home_signal_flag) matches; re-check after the statistics worker lands, and switch msr.theory.write_task_key to a metrics helper if one appears.

## Scorer revision 3 finished: whole banks held out (24 Nov, about 21:45 by the machine's clock)
Worker: scorer revision 3, after the cut-off. Hand-over text for the paper: `docs/handover/scorer_round3.md`.
- The three failing R9 tests: at the cut-off `scoreswap/export.py` was half-way into a new format (it referenced
  an undefined variable) and `pack.py` could read neither format, so the old failures could not be re-run as
  they were. With the finished code all three pass unchanged (A5 sealed: check and score show a rule the pack's
  draw count; A12: through `score`, 16 of 16 predicted on the development board, chance on the ranked board;
  W7: score types ranked by value after the swap, controls apart). Test-side fixes in the other files, none
  weakening: the alarm's code moved to `commands.py` (a test looked in `check.py`); short runs now pick random
  draws, so two runs compared call by call must pass the same `draw_pick`, and parity needs the paper's first
  draws (`first_draws=True`, fixed a real parity break of `shuffled` on the fixture); in the jail a symlink's
  target is invisible, so the refusal names the link; memorising attacks find tasks by relevance values
  (positions are now secret); the theta parity test scores every bank (`board="all"`).
- RULING DONE, whole banks: format `scoreswap-release/4`. Owners split a whole maker at a time by a seeded draw
  stratified by kind of maker (closed / open / extension pairs / other), rule and seed in the public manifest,
  the private owner list committed by sha256, every private file committed by sha256. Split drawn for `sim`:
  PUBLIC sim-a-old, sim-a-new (maker a); PRIVATE sim-b-old, sim-b-new (maker b). Full study: public anthropic,
  gemma, deepseek pair; private openai, qwen, mistral pair (each side one closed, one open, one extension).
  Ranked board = the 8 cells with a private owner (2 home, 1 upgrade, 1 downgrade, 4 cross-maker on `sim`).
- Task split DROPPED (a bank is wholly public or wholly private): simpler, and the check pool is whole again:
  96 cells per bank on both boards, budgets up to 64 = the paper's tables (format 3 ranked board: 44, k <= 32).
- FOUND: positions were aligned across owners (items sorted by write task id; the same probe tasks in the same
  order; IDENTICAL candidate lists and relevance values in every bank, since retrieval uses the write task's
  embedding). Fixed what can be fixed: a private bank's items and tasks reach a call in an order drawn from the
  secret seed (by_task follows it; outputs mapped back). What cannot be fixed: the relevance table identifies a
  private candidate's write task exactly, so "owner pooling" (public results of the same reader with other
  owners' items of the same write task) stays possible. Measured, not blocked.
- Attacks, ranked board of `release/sim` (first-shown success minus keep, cross-maker; development board in
  brackets): A1 carried check pool 0.000 (+0.053) BLOCKED by construction; A10 memorised outcomes 0.000 (+0.294)
  BLOCKED, alarm raised; item transfer 0.000 (+0.202) BLOCKED, alarm raised; owner pooling by position -0.009
  (-0.008) BLOCKED by the secret order; owner pooling by relevance -0.040 [-0.115, +0.035] (+0.185) NOT
  STOPPABLE, gains nothing here only because simulated owners' items are drawn independently, alarm raised;
  honest template k = 16: +0.007 (+0.009). A12 predicted random checks: chance on the ranked board (16/16 on the
  development board by design). Tests: `test_item_transfer_and_owner_pooling_gain_nothing_on_the_ranked_board`,
  `test_a_private_bank_reaches_a_call_in_a_secret_order`, `test_the_owner_split_of_the_real_design_is_stratified`.
- R9's attack table now: A1 blocked (construction; `test_a1_*`); A2, A3, A4 blocked (jail; `test_a2/a3/a4_*`);
  A5 blocked (construction; both `test_a5_*`); A6 blocked (jail; `test_a6_*`); A7 blocked (kernel; cheats
  `test_a2/a3/a4_reading_*`, `test_the_dev_file_cannot_be_read_*`); A8 blocked (jail; `test_a8_a9_*`); A9 partly
  (the hook can be switched off, the kernel still refuses, silently; `test_a8_a9_*`, `test_tampering_*`); A10
  blocked on the ranked board, alarm raised (`test_a10_*`, cheats `test_a1_a_memorised_*`); A11 not stoppable
  (named models and cells); A12 blocked on the ranked board (`test_a12_*`); A13 blocked (`test_more_checks_*`,
  `test_asking_a_cell_a_third_time_*`); A14 blocked (new `test_a14_a_hanging_call_*`, `test_a14_a_run_has_a_time_
  budget`); A15, A16 blocked (`test_a15_a16_*`); A17 blocked with a plain message (`test_a17_*`); A18 blocked
  (`test_an_entry_inside_the_pack_is_refused`, `test_an_entry_that_is_too_big_*`, `test_bad_outputs_*`).
- Held-out alarm: development board (public owners' swaps) against ranked board (private owners' swaps) on the
  full `score` runs; one jackknife over both boards (they share tasks and write tasks). On `sim` it flags A10,
  item transfer and owner pooling, not A1 (gap 0.038, allowed 0.046): a flag, not a proof.
- Governance (accepted) in the guide and the paper paragraph: 2 ranked runs per team per month, 10 per pack,
  failed and withdrawn included; public append-only log (entry sha256, date, pack and board version, both
  boards' numbers, alarm); packs replaced never edited; a retired pack's private half published. Board format
  `scoreswap-board/4`. README mentions `describe`. W13: licences read at source (DDXPlus CC BY 4.0, BIRD
  CC BY-SA 4.0), model output terms per model, our data CC BY 4.0 (owner may change), code licence still open.
- E10 done: every pack has `DATASHEET.md` and `croissant.json` (Croissant 1.0, every public file with sha256,
  record sets; not run through an official validator, `mlcroissant` is not installed), task text, and item text
  for public banks of models whose output terms allow it (simulated, Mistral, DeepSeek). Closed makers', Qwen's
  and Gemma's answers stay ids and sha256. Never text for a private bank or on the ranked board.
- Boards and guide use "retained agreement" and "not estimated (reader's spread below z = 2)".
- `release/sim` and `release/sim_private` re-exported. Parity with runs/sim (analysis of 10:06): arms.csv 0 for
  every rule, per-task values <= 1.0e-14; validity.csv and retained.csv 0; arms_groups.csv 5e-7 (162 numbers);
  theta_pairs.csv 5e-7 (160 rows, every flag equal). 7 parity tests pass.
- Timing (laptop shared with other jobs, load 5 to 11, two cores): one jailed, sealed `score` of
  rank_focus_shrink at k = 16 on `sim`: 38 s (development board), 1 min 31 s with `--private` (both boards and
  the alarm); `check` 11 s; about 0.1 GB per process.
- `docs/dress_rehearsal/run_all_after_changes.sh`: its export and parity lines work unchanged (same command
  line; export of `simfull` checked without the reference step, 2 min 10 s). No line changed.
- Note to the statistics worker: its 20:29 test run (`msr-stat3-tests0`) failed on scorer tests only because the
  scorer was half-way through this revision; they pass now.

## Manager's rulings on theory revision 3 (24 Nov, about 22:00)
- F1 (forecast test) and P1 become EXPLORATORY: a model-level property that raises both error consistency and theta
  gives up to 0.45 false rejections; fixed effects cure that but curved capability still gives about 0.10.
- The conversion of the 0.75 margin to success points is withdrawn; the margin is a registered convention.
- Accepted: the lower bound now bounds the MEAN, with the exact value beside the approximation and a proved floor;
  the revision-2 interval [198, 366] was too narrow and is replaced ([140, 491] for the estimate; exact at the
  simulator's truth 262 tasks [169, 405]); the 0.75 test's drop needs the home-signal flag in the text too;
  "not testable" means: answer the break-even question instead; checks must be drawn at random by the harness.
- Relayed to the statistics worker (Part 7 and stale lines in Parts 0-10, macros for the new theory outputs).
- Tests: 83 scorer tests pass (export 10, harness 15, cheats 18, parity 7, R9 attacks 21; 5 new); whole suite
  609 passed, 0 failed, 0 not run (29 min 50 s, low priority). runs/sim did not change after my parity run, so
  that run is also the final one.
- GUARANTEE SENTENCES (guide "What is guaranteed", and for A14 in the handover file). Stopped by construction:
  the harness alone answers and counts checks (k per call, two per cell); random checks come from a generator the
  rule cannot steer, secret-seeded on the ranked board; no public file holds a result, score, log, candidate list
  or text of a private owner's bank, each private file committed by sha256; a private bank reaches a call in a
  secret order; check and score tell a rule the same draw count. Stopped by the jail (Linux x86_64, bubblewrap,
  Landlock, seccomp; ranked result refused without it): fresh process per call from a launcher that never runs
  entry code, own namespaces with read-only binds only; no other process, no other file, no access-time change,
  no limit change, no process or thread, no note to a later call, one relayed answer per call, memory cap and
  time budget. Not stopped: anything public (including owner pooling by relevance and the readers' public no-item
  results), special-casing named models and cells, timing between calls running at the same time, kernel bugs.
- GOVERNANCE PARAGRAPH for the paper: in `docs/handover/scorer_round3.md` (2 ranked runs per team per month, 10
  per pack, failed and withdrawn included; append-only public log; packs replaced not edited, old entries
  re-run; retired private half published; co-maintainer outside the authors once one has agreed).
- OPEN: (1) owner pooling by relevance cannot be blocked while every owner shares write tasks; re-measure it on
  the real pack before it opens; if it gains, the remedy is a two-way hold-out (private owners x private probe
  tasks), which halves the ranked check pool (full study k <= 128): manager's decision. (2) When the statistics
  worker moves item clusters to the write task (E1), `scoreswap/stats.py` (Clusters, the `imap` key) must follow;
  the parity tests will show it. (3) `simfull` is all simulated, so its split (public c, d, e; private a, b, f)
  does not follow the closed/open strata of the real study (config/models.yaml not touched while the pilot runs).
  (4) croissant.json not run through an official validator. (5) Code licence open; derived data set to CC BY 4.0
  (owner may change). (6) Paper 3b: A14, governance, A2_datasheet.tex (item text is no longer ids only). (7) The
  alarm did not flag A1 on `sim`. (8) Full-size timings in the guide predate the hold-out.

## Manager's rulings on scorer revision 3 (24 Nov, about 23:00)
- Accepted: whole banks held out by maker (full study: public Anthropic, Gemma, DeepSeek pair; private OpenAI, Qwen,
  Mistral pair); ranked board = cells with a private owner; private banks reach a call in a secret order; no text on
  the ranked board; the item-transfer attack gains 0.000 there. Rate limit and public log as written.
- Owner pooling by relevance cannot be stopped while all owners write on the same tasks. Ruling: it is re-measured
  on the REAL pack before the ranked board opens; if it gains, the board moves to a two-way hold-out (private owners
  and private probe tasks; budgets then up to 128). The paper states this as a registered step, not as solved.
- The scorer's item-cluster key must follow the statistics worker's write-task clustering (sent to that worker).
- For the owner: the licence of the code is undecided; the derived data are set to CC BY 4.0 for now.
- For paper pass 3b: `docs/handover/scorer_round3.md` (guarantees, governance), the datasheet appendix (text policy).

## FIRST REAL DATA: pilot 1 finished (25 Nov, 02:30)
`runs/pilot_shot/results/SUMMARY.md`. Haiku 4.5 and 5.5, DDXPlus, 200 probe tasks, one order: a pilot, not a result.
- 17,900 calls, no rate limiting, no refusals, 122 unparseable answers. SPENT USD 15.80; the estimate was 7.88.
  USD 14.20 is left under the USD 30 cap. Pilots 2 and 3 were NOT started (they would pass the cap at this rate).
- Gates: 1 FAIL on its interval (memory helps +3.5 points [-2.8, +9.5]); 2 PASS (home concordance 0.63 [0.55, 0.71];
  Haiku 5.5's own bank 0.68); 3 PASS (repeats differ 8.2 %); 4 FAIL (104 items with 5+ visits after 3 passes, 150
  needed: the registered rule says go on to passes 4-6); 5 FAIL (USD 1.004 per 1,000 calls against 0.440 estimated:
  Haiku 4.5 writes about 245 output tokens per call on about 1,000 input tokens).
- First look at the question itself (wide intervals): keep beats wipe by 5.0 and 3.3 points at home, by 3.3 points
  after the upgrade 4.5 -> 5.5, by 0.6 after the downgrade 5.5 -> 4.5 (concordance 0.69 at home, 0.58 after;
  value kept 0.45 [-0.01, 1.15]).
- Consequence: every price with Haiku 4.5 in it is about 2.3 times too low (Haiku pair on DDXPlus: about USD 190,
  not 86). A pipeline worker is writing the pilot report, fixing the estimator from measured tokens, re-pricing
  (`docs/COST_2026-11-25.md`), looking at why the answers are long and how to cut the cost, and building the
  registered pass rule; the manager starts any paid command.
- Still running: the statistics worker (revision 3 and the full-size analysis).

## Owner's orders, 25 Nov about 02:45: no more dollars; use the free opencode models
- The owner will NOT give OpenAI or OpenRouter keys and does not want to spend more. NO FURTHER PAID CALL without
  a new, explicit yes. Spent in total: USD 15.80 (pilot 1). Pilots 2 and 3 and every paid run are off.
- Free opencode models, measured today on the owner's order: 10 free models; 50 one-word calls sent, six at a
  time; 39 answered (about 4 per model), then every model stopped answering. opencode's log: "Free usage limit
  reached ... subscribe to OpenCode Go" (35 times). So the free allowance is about 40 calls a day in all, shared by
  every free model, however many are sent at once.
- On the owner's word the free-model run was started again: unit `msr-prelim`
  (`runs/prelim_opencode/launch.sh`; state in `runs/prelim_opencode/STATE`). It uses each day's allowance, waits
  for the reset at 00:05 UTC and resumes; answers are cached, nothing is asked twice. Its tiny slice is 356 calls
  (about 9 days at 40 a day); the small study is 12,300 calls (about 10 months).
- Open models on this laptop (no graphics card, i5-8250U; Ollama has llama3.2 1b and 3b): one call of real length
  (938 prompt tokens) took 37 s on the 1b model and 105 s on the 3b model with the machine busy. About 800 to
  2,300 calls a day: also far too slow for a study in two days.
- What exists that is REAL today: pilot 1 (Haiku 4.5 and 5.5, 17,900 calls, already paid).

## EVERYTHING STOPPED on the owner's order (25 Nov, about 03:00)
- The owner said: "stop everything, stop running everything." Stopped: the statistics worker and its helper, the
  pilot follow-up worker, the free-model run (unit `msr-prelim`) and the statistics worker's job
  (`msr-stat3-mem-4`). Nothing of this project is running. Total spent: USD 15.80. No paid call is authorised.
- Left unfinished (do not assume done): statistics revision 3 (write-task clustering in `msr/metrics.py` /
  `msr/analysis.py`, the scorer's cluster key, renames, cross-fitting, the full-size analysis, which last died at
  8 GB of memory); the pilot report, the corrected cost estimates and the pass rule; paper pass 3b. The workers were
  stopped mid-edit: run the test suite before trusting `msr/` (`.venv/bin/python -m pytest -q`).
- Finished and on disk: theory revision 3 (`docs/handover/theory_round3.md`), scorer revision 3
  (`docs/handover/scorer_round3.md`), pilot 1's real data (`runs/pilot_shot/results/SUMMARY.md`), the three
  round-3 reviews, the paper as of phase 3a (`paper/main.pdf`, `paper/dryrun.pdf`).
- Do not restart anything without the owner's word.

## Hand-over zip for another machine (25 Nov, about 03:30)
- The owner will run the study on another machine that has free model calls and an agent, and will give a GitHub
  repository to push the zip to. Built: `~/Desktop/Model_Swap_Handover/scoreswap_handover_2026-11-25.zip` (51.2 MB,
  6,911 files) and its `.sha256`. Instructions for the agent there: `HANDOVER_NEW_MACHINE.md` (in the zip's root).
- In the zip: code, config, docs, pre-registration, paper, frozen splits, pilot 1's real data, the practice pack.
  Not in it: the key file, the Python environment, downloaded benchmarks, simulated runs, the LaTeX tool.
  Every file in the zip was scanned: no key.
- NOT pushed: waiting for the repository address. (This zip was made after this section was written, so the copy
  of this file inside the zip ends one section earlier.)
