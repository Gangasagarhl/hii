# Theory, revision 3 (24 Nov 2026): changed LaTeX only, for paper pass 3b

Review round 3, R7 (W6, W7, W8, W11, W2 for theory's files, W4 margin translation, section 6). Manager's decisions
E1, E3, E5. Code: `msr/sequential.py`, `msr/theory.py`, `msr/forecast.py` and their tests; registered text:
`prediction/PREREGISTRATION.md` Part 11 ("What changed in revision 3"). Every plain number below comes from a stated
synthetic world or the practice (simulated) study; real-study values are `\Res{...}` macros. Each item is
OLD (exact current text) -> NEW, grouped by file and label. Sentences not listed stay as they are.

Words for the whole pass (E3): "retained order" -> "retained agreement"; "not identifiable" -> "not estimated
(reader's spread below z = 2)". None of the theory text below uses the old words.

---

## 1. `A15_keep_or_drop.tex` (`sec:forecast-check`, `prop:margin0`, `prop:check`, `thm:bound`)

### 1a. `prop:margin0`, statement (W8: the random-order condition where the test is defined)
OLD:
```latex
If the check tasks are drawn independently from the stream (for the fixed bank) and each is checked afresh, keeping is chosen
```
NEW:
```latex
If the check tasks are drawn independently and at random by the harness from a fixed held-out pool (for the fixed bank; not chosen or ordered by the operator) and each is checked afresh, keeping is chosen
```

### 1b. The sentence before `prop:check` (W6)
OLD:
```latex
and keeps only if the betting test of $\mathbb E D\le0$ rejects \emph{and} the home-signal flag shows $\bar A_{\mathrm{home}}>0$; the drop test uses 0.25 in place of 0.75.
```
NEW:
```latex
and keeps only if the betting test of $\mathbb E D\le0$ rejects \emph{and} the home-signal flag shows $\bar A_{\mathrm{home}}>0$; it drops only if the mirror test with 0.25 in place of 0.75 rejects \emph{and} the same flag is positive, and otherwise answers ``not testable''.
```

### 1c. `prop:check`, statement (W6: the condition covers both decisions)
OLD:
```latex
If check tasks are drawn independently, each with its own fresh result of the old model, the decision keeps with probability at most $\max(\alpha,\alpha_{\mathrm{flag}})$ whenever $\theta\le0.75$ or $\bar A_{\mathrm{home}}\le0$, and drops with probability at most $\alpha$ whenever $\theta\ge0.25$, at every stopping time.
```
NEW:
```latex
If check tasks are drawn independently and at random by the harness, each with its own fresh result of the old model, and both decisions require the home-signal flag, then at every stopping time the decision keeps with probability at most $\max(\alpha,\alpha_{\mathrm{flag}})$ whenever $\theta\le0.75$ or $\bar A_{\mathrm{home}}\le0$, and drops with probability at most $\max(\alpha,\alpha_{\mathrm{flag}})$ whenever $\theta\ge0.25$ or $\bar A_{\mathrm{home}}\le0$; $\alpha_{\mathrm{flag}}$ is the flag's size at $\bar A_{\mathrm{home}}=0$.
```

### 1d. The paragraph after `prop:check` ("Both conditions bite.")
OLD (first sentence pair):
```latex
Both conditions bite. Without the sign condition a reversed home order ($\bar A_{\mathrm{home}}=-0.10$) is kept in 0.999 of streams; re-using a stored table of 300 tasks' home results beyond its size gives false keeps of 0.11 by 3,000 tasks.
```
NEW:
```latex
All three conditions bite. Without the sign condition a reversed home order ($\bar A_{\mathrm{home}}=-0.10$) is kept in 0.999 of streams, and a reader that keeps all of that reversed order ($\theta=1$) is dropped in 0.999 of streams when the drop test is not gated; re-using a stored table of 300 tasks' home results beyond its size gives false keeps of 0.11 by 3,000 tasks; and checks taken in topic order (200 tasks with a positive keep-minus-wipe value, then 200 with a non-positive one) make the break-even test keep falsely in 0.96 of streams at its exact boundary, against 0.024 in random order. Check tasks must therefore be drawn at random by the harness, not chosen or ordered by the operator, and our replay refuses any other order. When the answer is ``not testable'' the old scores showed no positive signal even for the old model, so the 0.75 question has no meaning for that bank and the operator answers the break-even question instead.
```

### 1e. `thm:bound`, statement: add the guaranteed floor (W7)
OLD (last sentence of the theorem):
```latex
For whole tasks drawn uniformly at random and checked in full, to second order $K^\star=(\theta_1-\theta_0)^2\bar A_{\mathrm{home}}^2/(8\,\mathbb E\sigma_\tau^2)$ per check, $\sigma^2_\tau$ the within-task Bernoulli variance of $A_\tau$.
```
NEW:
```latex
For whole tasks drawn uniformly at random and checked in full, to second order $K^\star=(\theta_1-\theta_0)^2\bar A_{\mathrm{home}}^2/(8\,\mathbb E\sigma_\tau^2)$ per check, $\sigma^2_\tau$ the within-task Bernoulli variance of $A_\tau$; and, with $x=c_{\max}|\theta_1-\theta_0|\bar A_{\mathrm{home}}/\mathbb E\sigma^2_\tau<0.83$ ($c_{\max}=3/4$, the largest weight of a candidate in $A_\tau$), the exact bound is at least $1-x-x^2/4$ times this second-order one.
```

### 1f. The bound at the study's signal (W7: approximation, its interval, the exact bound)
OLD:
```latex
At this study's signal ($\alpha=0.05$, power 0.8) and for whole tasks drawn at random, it is about \Res{CheckMarginZeroRankingBoundChecks} checks for margin 0 and \Res{CheckBoundKeepTasks} tasks of four checks (95\% interval \Res{CheckBoundKeepTasksLo}--\Res{CheckBoundKeepTasksHi}) for margin 0.75; it scales as $1/\bar A_{\mathrm{home}}^2$, and choosing cells adaptively lowered it by a factor of only 1.24--1.56 in our task models.
Our tests needed medians of \Res{CheckMarginZeroRankingChecks} checks (margin 0, ranking form), \Res{CheckMarginZeroFirstShownChecks} checks (decision form, against a bound of \Res{CheckMarginZeroFirstShownBoundChecks} for its observation scheme) and \Res{CheckPairedMedianTasks} tasks (margin 0.75, at $\theta=1$).
```
NEW:
```latex
At this study's signal ($\alpha=0.05$, power 0.8) and for whole tasks drawn at random, the second-order value is about \Res{CheckMarginZeroRankingBoundChecks} checks for margin 0 and \Res{CheckBoundKeepTasks} tasks of four checks for margin 0.75 (95\% interval \Res{CheckBoundKeepTasksLo}--\Res{CheckBoundKeepTasksHi}, with tasks and write tasks as clusters; an interval for the approximation, not for the exact bound). The exact bound needs each cell's success chance, which a few repeats cannot give; it is at least \Res{CheckBoundKeepFloorTasks} tasks at margin 0.75 (interval \Res{CheckBoundKeepFloorTasksLo}--\Res{CheckBoundKeepFloorTasksHi}). Where chances are spread out the two forms agree within 2\%; where most cells are near 0 or 1 the exact bound was 1.7 (margin 0.75) and 3.6 (margin 0) times the second-order one. The bound scales as $1/\bar A_{\mathrm{home}}^2$, and choosing cells adaptively lowered it by a factor of only 1.24--1.93 in the task models we and a reviewer checked.
The theorem bounds the mean. Our tests needed on average \Res{CheckMarginZeroRankingMeanChecks} checks (margin 0, ranking form), \Res{CheckMarginZeroFirstShownMeanChecks} checks (decision form, against about \Res{CheckMarginZeroFirstShownBoundChecks} for its observation scheme) and \Res{CheckPairedMeanTasks} tasks (margin 0.75, at $\theta=1$); their medians were \Res{CheckMarginZeroRankingChecks}, \Res{CheckMarginZeroFirstShownChecks} and \Res{CheckPairedMedianTasks}.
```
Dry run only (practice study, put under `\ifdryrun\ifsmallpractice`), NEW sentence after the paragraph above:
```latex
At the practice study's simulator truth the exact bound at margin 0.75 is 262 tasks (95\% interval 169--405) against 257 to second order; the paired test's mean, 803 tasks with every stream keeping, is 1.95 times the bound at that power.
```
The existing `\ifsmallpractice` sentence ("from about 65 to 30 checks ... from about 1,050 to 470 checks") stays.

---

## 2. `A8_proofs.tex` (`app:proofs`)

### 2a. Paragraph `\Cref{prop:margin0}`, condition (ii)
OLD:
```latex
(ii) the check tasks are drawn independently from the stream;
```
NEW:
```latex
(ii) the check tasks are drawn independently and at random by the harness from the stream (a fixed held-out pool), not chosen or ordered by the operator;
```

### 2b. Paragraph `\Cref{prop:check}`: the drop sentence (W6)
OLD:
```latex
A drop needs no sign: $P(\text{drop})\le\alpha$ whenever $\bar A_{\mathrm{swap}}\ge0.25\,\bar A_{\mathrm{home}}$.
```
NEW:
```latex
A drop needs the flag too. When $\bar A_{\mathrm{home}}>0$, $\theta\ge0.25$ is $\mathbb E D_d\ge0$, so the drop test fires with probability at most $\alpha$. When $\bar A_{\mathrm{home}}\le0$, $\mathbb E D_d=\bar A_{\mathrm{swap}}-0.25\,\bar A_{\mathrm{home}}$ can be negative whatever $\theta$ is (at $\theta=1$ it is $0.75\,\bar A_{\mathrm{home}}<0$), so an ungated drop test can drop almost always; with the flag a drop, like a keep, happens with probability at most $\alpha_{\mathrm{flag}}$, the flag's tasks being disjoint from the stream.
```

### 2c. The "Checked with the home value estimated afresh" sentence: append
NEW (append after "... and 0.000 when the test stops at the store."):
```latex
With the reader at $\theta=1$ against a reversed home order the ungated drop test dropped in 0.999 of 1,000 streams and the gated rule in none (all ``not testable''); with the tasks in topic order the break-even test kept falsely in 0.961 of 1,000 streams at its exact boundary, and in 0.024 with the tasks in random order.
```

### 2d. Paragraph `\Cref{thm:bound}`: the floor and the interval (W7)
OLD:
```latex
What the theorem does not cover: observations other than fresh checks of the reader on a cell (the old model's self-ratings, a judge, log-probabilities), smaller null sets, repeated checks that are not fresh, and targets defined on a finite pool. The bound is an estimate: $\bar A_{\mathrm{home}}$ and $\mathbb E\sigma^2_\tau$ come from the owner's two home repeats (unbiased $\mu(1-\mu)=\bar y-y_1y_2$ per cell), and its 95\% interval is a task bootstrap (an owner-level bootstrap is reported beside it).
```
NEW:
```latex
The floor: with $t=|\theta_1-\theta_0|\bar A_{\mathrm{home}}/\mathbb E\sigma^2_\tau$ the null $q_c=\mu_c-t\,c_c\,\mu_c(1-\mu_c)$ is feasible and meets the constraint exactly; since $\mathrm{kl}(p\|q)\le(p-q)^2/(2\min_{r\in[p,q]}r(1-r))$ and $q(1-q)\ge p(1-p)(1-x-x^2/4)$ with $x=t\,c_{\max}$, the per-task divergence of the least-favourable null is at most the second-order one divided by $1-x-x^2/4$. $\square$
What the theorem does not cover: observations other than fresh checks of the reader on a cell (the old model's self-ratings, a judge, log-probabilities), smaller null sets, repeated checks that are not fresh, and targets defined on a finite pool. The bound is an estimate: $\bar A_{\mathrm{home}}$ and $\mathbb E\sigma^2_\tau$ come from the owner's two home repeats (unbiased $\mu(1-\mu)=\bar y-y_1y_2$ per cell), and its 95\% interval is a two-way jackknife with tasks and write tasks as clusters (the plug-in pools the owners, who share write tasks), for the second-order value and for the floor. The exact bound is solved numerically wherever the chances are known (our worlds, a simulator's truth, with a two-way interval from the per-task Lagrangian); on real data it cannot be estimated from a few repeats per cell, since it depends on how close each cell's chance is to 0 or 1: computed on the table of observed home means it was about half the exact bound where chances were spread out and 2--30 times it where cells were near 0 or 1.
```

### 2e. The median-ratio sentence (W7: means)
OLD:
```latex
The ratio of a test's median stopping time to the bound depends on the setting (2.04 for the paired test in the Bernoulli-noise model\ifdryrun\ifsmallpractice, 2.8--2.9 at the practice study's signal\fi\fi), so it is always stated with its setting; a fixed-sample paired $z$ test needs about 900 tasks in the Bernoulli-noise model.
```
NEW:
```latex
The theorem bounds the expected number of checks, so a test is compared with it through its mean stopping time at its own power: the paired test's mean is 1.54 times the bound in the Bernoulli-noise model\ifdryrun\ifsmallpractice{} and 1.95 times it at the practice study's signal\fi\fi{} (medians, reported apart: 2.1 and 2.8 times the bound at power 0.8); the ratio depends on the setting and is always stated with it. A fixed-sample paired $z$ test needs about 900 tasks in the Bernoulli-noise model.
```

### 2f. Paragraph `The forecast before the swap` (`app:forecast`; W11)
OLD:
```latex
Its level stayed within 0.050--0.060 in the null worlds we report and in those of an independently written simulator, and power at eight models is 0.57--0.68 for a partial correlation of 0.3 and 0.98 for 0.6; a capability effect curved in both arrays raises the level to 0.12. Agreement (P1) is tested the same way, and both use the core grid only (8 models, 4 makers, 56 swaps).
```
NEW (if the manager rules F1 exploratory, the theory recommendation; otherwise drop the last clause "and we report it as exploratory"):
```latex
Its level stayed within 0.048--0.061 in the null worlds we report and in those of an independently written simulator, and power at eight models is 0.60--0.67 for a partial correlation of 0.3 and 0.99 for 0.6. It is fragile in two ways. It detects association at the level of single models as well as of pairs: error consistency is symmetric and the relabellings move whole models, so a property of a model that raises both its error consistency and $\theta$ passes as incremental value (false rejections 0.085, 0.17 and 0.45 as that property grows, 0.06 without it); owner and reader fixed effects remove this (0.046--0.056) but cut power at 0.3 to 0.48. And a capability effect curved in both arrays raises its level to about 0.10 with either set of controls. Selecting swaps by the home-signal flag did not raise it (0.050--0.062). A pass therefore means that error consistency and $\theta$ move together beyond the same-maker flag, capability and the newer model, not that a pair's own error consistency predicts its $\theta$, and we report it as exploratory. Agreement (P1) is tested the same way, and both use the core grid only (8 models, 4 makers, 56 swaps).
```

---

## 3. `05c_q3_operator.tex` (`sec:q3`)

### 3a. Line 5 (break-even test; W8 operator text)
OLD:
```latex
compares, on check tasks drawn at random, the item keeping would show first with the one wiping would show first, and controls its error at every stopping time (\cref{prop:margin0}).
```
NEW:
```latex
compares, on check tasks drawn at random, the item keeping would show first with the one wiping would show first, and controls its error at every stopping time (\cref{prop:margin0}). Checks must be drawn at random by the harness, not chosen or ordered by the operator: live traffic in arrival order or checks grouped by topic void the guarantee.
```

### 3b. Line 6 (W7: the bound bounds a mean)
OLD:
```latex
At this signal it decided after a median of \Res{CheckMarginZeroFirstShownChecks} checks; no rule that checks those two items on tasks drawn at random can do it in fewer than about \Res{CheckMarginZeroFirstShownBoundChecks} (\cref{thm:bound}).
```
NEW:
```latex
At this signal it decided after a median of \Res{CheckMarginZeroFirstShownChecks} checks (\Res{CheckMarginZeroFirstShownMeanChecks} on average); no rule that checks those two items on tasks drawn at random can do it in fewer than about \Res{CheckMarginZeroFirstShownBoundChecks} on average (\cref{thm:bound}).
```

### 3c. Line 11 (W6)
OLD:
```latex
so it is valid only when the home signal is shown positive and every check task has its own home result; the test stops, undetermined, when the stored home results run out.
```
NEW:
```latex
so it is valid only when the home signal is shown positive and every check task has its own home result; without a shown home signal it neither keeps nor drops (``not testable'', and the break-even test decides), and it stops, undetermined, when the stored home results run out.
```

### 3d. Line 12 (W7)
OLD:
```latex
When nothing was lost it needed a median of \Res{CheckPairedMedianTasks} tasks of four checks, and no rule that checks whole tasks drawn at random can reach power 0.8 in fewer than \Res{CheckBoundKeepTasks} tasks (95\% interval \Res{CheckBoundKeepTasksLo}--\Res{CheckBoundKeepTasksHi}) at this signal; choosing which cells to check lowers the bound only slightly (\cref{thm:bound}).
```
NEW:
```latex
When nothing was lost it needed \Res{CheckPairedMeanTasks} tasks of four checks on average (median \Res{CheckPairedMedianTasks}), and no rule that checks whole tasks drawn at random can reach power 0.8 with fewer than \Res{CheckBoundKeepFloorTasks} tasks on average at this signal (a guaranteed floor; about \Res{CheckBoundKeepTasks} to second order, 95\% interval \Res{CheckBoundKeepTasksLo}--\Res{CheckBoundKeepTasksHi}); choosing which cells to check lowers the bound only slightly (\cref{thm:bound}).
```

---

## 4. `00_abstract.tex` (sentence 5, dry-run branch) and `01_introduction.tex` (line 45)

Abstract OLD:
```latex
\ifdryrun A few hundred fresh checks of the new model alone can show whether keeping the old scores still beats wiping them, but showing that at most a quarter of their value was lost takes hundreds of tasks checked on both models, for any rule that checks whole tasks drawn at random\else
```
Abstract NEW:
```latex
\ifdryrun A few hundred fresh checks of the new model alone, on tasks drawn at random, can show whether keeping the old scores still beats wiping them, but showing that at most a quarter of their value was lost takes hundreds of tasks checked on both models, on average, for any rule that checks whole tasks drawn at random\else
```
(The `\else` branch: "needs \TODO{how many} tasks" -> "needs \TODO{how many} tasks on average".)

Introduction OLD:
```latex
while showing that at most a quarter of the value was lost needs at least \Res{CheckBoundKeepTasks} tasks (\Res{CheckBoundKeepTasksLo}--\Res{CheckBoundKeepTasksHi}) of four checks each for any rule that checks whole tasks drawn at random, and the old model's results on all of them, collected before it retires.
```
Introduction NEW:
```latex
while showing that at most a quarter of the value was lost needs, on average, at least \Res{CheckBoundKeepFloorTasks} tasks of four checks each (about \Res{CheckBoundKeepTasks} to second order) for any rule that checks whole tasks drawn at random, and the old model's results on all of them, collected before it retires.
```

---

## 5. `05b_q2_stakes.tex` line 5 (R7 W4, decision E3): WITHDRAW the margin's translation
OLD:
```latex
In success points, the margin $\theta=0.75$ means giving up \Res{MarginPointsAllSwaps} at home.
```
NEW:
```latex
The margin $\theta=0.75$ is a statement about the ranking signal; what keeping and wiping are worth in success points, at home and after the swap, is measured directly in \cref{tab:stakes}.
```
Why: no derivation exists in the theory material. "0.25 x (keep - shuffled)" holds only if, on every task, the reader's
usefulness differences between candidates are the same multiple of the owner's (then every within-task contrast,
theta's pairs and the first-shown gain alike, is scaled by that multiple, and the loss is exactly a quarter of the
home gain over shuffled scores). That is the assumption a theta below 1 calls into question (R7's monotone reader keeps
every pair's order with "retained agreement" 0.896 and theta 2.17), so the sentence and the macro `MarginPointsAllSwaps`
go.

---

## 6. `08_limitations.tex` lines 17-18
OLD:
```latex
Both swap-day tests assume check tasks drawn independently and checked afresh; the 0.75 test also needs a positive home signal and the old model's result on every checked task, and its lower bound covers only fresh checks of the reader.
The measurement check of \cref{app:measurement} is in-sample and can fail for reasons other than leakage, and with eight models the forecast's single test has low power (\cref{app:forecast}).
```
NEW:
```latex
Both swap-day tests assume check tasks drawn independently and at random by the harness and checked afresh (an order chosen by the operator, such as live traffic or topic batches, voids them); the 0.75 test also needs a positive home signal for either decision and the old model's result on every checked task, and its lower bound covers only fresh checks of the reader and, on real data, is known only to second order and as a guaranteed floor.
The measurement check of \cref{app:measurement} is in-sample and can fail for reasons other than leakage, and with eight models the forecast's single test has low power and cannot tell a link between the two models of a pair from a property of single models (\cref{app:forecast}).
```

## 7. `A13_secondary_results.tex` line 79 and `A9_statistics.tex` line 35 (only if F1 becomes exploratory)
A13 OLD: `The registered test of incremental value, F1 (\cref{app:forecast}), is the partial correlation of $\theta$ and error consistency given the same-maker flag, both capabilities and their gap:`
A13 NEW: `The exploratory test of incremental value, F1 (\cref{app:forecast}), is the partial correlation of $\theta$ and error consistency given the same-maker flag, both capabilities, their gap and which model is the newer one:`
A9 OLD: `the forecast has one test of incremental value (\cref{app:forecast});`
A9 NEW: `the forecast's test of incremental value is exploratory (\cref{app:forecast});`
If F1 stays registered: A13 only gains ", their gap and which model is the newer one" (the controls were already in the code).

---

## 8. New macros (statistics worker, `scripts/make_paper_assets.py`)
- `CheckBoundKeepFloorTasks`, `...Lo`, `...Hi`: `sequential_bound.csv` setting=table_plugin, decision=keep, power=0.8, columns
  `bound_tasks_floor`, `bound_tasks_floor_lo`, `bound_tasks_floor_hi` (also on `sequential_bound_curve.csv` curve=margin,
  theta_0=0.75).
- `CheckBoundKeepTasks/Lo/Hi`: same source as before; `bound_tasks_chi2_lo/hi` are now the two-way interval (task id x
  write task); the revision-2 bootstrap is in `bound_tasks_chi2_boot_lo/hi`.
- `CheckPairedMeanTasks`: `sequential_curve.csv` theta=1, column `tasks_mean_capped`.
- `CheckMarginZeroRankingMeanChecks`, `CheckMarginZeroFirstShownMeanChecks`: `sequential_margin0.csv` world=study,
  part=needed, theta=1, version=ranking / first_shown, column `checks_mean`.
- `CheckMarginZero*BoundChecks` keep their column `bound_checks`; on real data it is now the second-order value from
  unbiased moments (column `bound_basis` says so); at a simulator's truth it stays the exact bound.
- Drop the macro `MarginPointsAllSwaps` (section 5).

## 9. Practice-study values behind the dry run (sim; power 0.8, alpha 0.05; `docs/handover` numbers re-made with the new code)
| quantity | value |
|---|---|
| margin 0.75: exact at the simulator truth | 262 tasks [169, 405] (two-way) |
| margin 0.75: second order at the truth / plug-in | 257 / 262 tasks; plug-in two-way [140, 491]; old bootstrap [198, 366] |
| margin 0.75: guaranteed floor (plug-in) | 207 tasks [100, 425]; kappa 0.79 |
| margin 0 (ranking): exact at the truth / plug-in | 17.3 tasks (69 checks) [11.4, 26.1] / 16.4 [8.7, 30.7]; floor not useful (x = 0.81) |
| paired test at theta = 1 | mean 803 tasks (all keep), 1.95 x the bound at that power (412); median 730.5, 2.79 x the bound at 0.8 |
| ranking break-even test | mean 95 tasks (380 checks), 3.5 x the bound at its power; median 91 (364 checks) |
| decision form | mean 306 checks, 1.94 x the bound at its power (158 checks); median 281 |
| old-model calls for the median stop | 8 x 730.5 + 800 = 6,644 |
The two-way interval is wider than the revision-2 bootstrap because 86 % of the variance of the pooled home values is
carried by write tasks shared by the owners (148 write-task and 156 task clusters).
