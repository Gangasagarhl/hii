# Theory, revision 2 (24 Nov 2026): ready-to-paste text for the paper worker

Code: `msr/sequential.py`, `msr/theory.py`, `msr/forecast.py` (tests: `tests/test_sequential.py`,
`tests/test_theory.py`, `tests/test_forecast.py`). Notes: `docs/forecast_and_sequential_note.md`,
`docs/theory_note.md`. Registered rules: `prediction/PREREGISTRATION.md` Part 11. Every number below is
from the practice (simulated) study or from a stated synthetic world, checked in the named test; numbers
that will come from the real study are written as `\Res{...}` macros with their CSV source.

Decisions behind this text (manager, STATUS.md D5, D6): the swap-day question is the operator's break-even
(margin 0); the 0.75 question is the hard case; the decomposition leaves the body.

---

## 1. Abstract (sentence 5) and body summary sentence

Abstract, sentence 5 (replaces the `% WAIT-THEORY` sentence; one number):
```latex
A few hundred fresh checks of the new model alone can show whether keeping the old scores still beats wiping them, but showing that at most a quarter of their value was lost takes hundreds of tasks checked on both models, for any rule that checks whole tasks drawn at random; a multi-step agent leg on MemRL's released code tests whether the order matters there too.
```
Body ("What we found", one sentence; numbers from the practice study, to be replaced by macros on the real study):
```latex
On the swap day the cheap question has a cheap answer and the strict one does not: whether keeping still beats wiping is decided after a median of \Res{CheckMarginZeroFirstShownChecks} checks of the new model (no call to the old one; no valid rule can do it in fewer than about \Res{CheckMarginZeroFirstShownBoundChecks}), while showing that at most a quarter of the value was lost needs at least \Res{CheckBoundKeepTasks} tasks (95\% interval \Res{CheckBoundKeepTasksLo}--\Res{CheckBoundKeepTasksHi}) of four checks each for any rule that checks whole random tasks, and the old model's results on every one of those tasks collected before it retires.
```
Practice-study values (sim): first-shown keep-vs-wipe test, median 281 checks (209 tasks; arms differ on 67% of tasks), lower bound 100 checks; ranking version 364 checks (91 tasks), bound 69 checks (plug-in 65 [49, 91]); 0.75 question: bound 262 tasks [198, 366] = 1,048 checks, our test median 731 tasks.
Macro sources (to be wired by the statistics worker in `scripts/make_paper_assets.py`):
- `CheckMarginZeroFirstShownChecks`: `sequential_margin0.csv`, world=study, version=first_shown, part=needed, theta=1, column checks_median;
- `CheckMarginZeroFirstShownBoundChecks`: same row, column bound_checks;
- `CheckMarginZeroRankingChecks` / `...BoundChecks`: version=ranking, same columns;
- `CheckBoundKeepTasks`, `...Lo`, `...Hi`: `sequential_bound_curve.csv`, curve=margin, theta_0=0.75 row of the study plug-in (if absent: `sequential_bound.csv` setting=table_plugin, decision=keep, power=0.8, columns bound_tasks_chi2 and its bootstrap interval columns);
- `CheckPairedMedianTasks`: `sequential_curve.csv` theta=1, tasks_q50.

Do NOT write "a few dozen checks": that is the information floor at margin 0 (69 checks [49, 91]) in the ranking version, not what any registered test needs (364). Do NOT write "any rule needs": write "any rule that checks whole tasks drawn at random" (or the adaptive version, Theorem below).

---

## 2. Section "What should an operator do on the swap day?" (body, about half a column)

```latex
\section{The Keep-or-Drop Decision on the Swap Day}
\label{sec:forecast-check}
For a task $\tau$ whose candidates are each checked once with results $y_i$, $A_\tau=\sum_{i<j}\operatorname{sgn}(x(i)-x(j))(y_i-y_j)/4$ lies in $[-1,1]$ and has mean $V(\tau)/4$; one task costs four checks.
The operator's question is whether keeping the old scores still beats wiping them.
Its ranking form is $H_0\colon\mathbb E A^{\mathrm{swap}}_\tau\le0$ (the old order is no better than a random order); its decision form compares the item each rule would show first, $d_\tau=y(\text{keep's first item})-y(\text{wipe's first item})$, with $H_0\colon\mathbb E d_\tau\le0$ (two checks per task where the two rules differ, none where they agree).
We test either with a betting test martingale \citep{waudbysmith2024betting}: keep once its wealth reaches $1/\alpha$, wipe once the mirror test does.

\begin{proposition}[Keep beats wipe]\label{prop:margin0}
If the check tasks are drawn independently from the stream (for the fixed bank) and each is checked afresh, keeping is chosen with probability at most $\alpha$ whenever the tested mean is in truth at most zero (keeping no better than wiping in the decision form; the old order no better than a random one in the ranking form), at every stopping time. No result of the old model is needed.
\end{proposition}

The stricter question asks whether at most a quarter of the home value was lost, $\theta>0.75$.
It pairs each check task with the old model's result on the same task, $D_\tau=A^{\mathrm{swap}}_\tau-0.75\,A^{\mathrm{home}}_\tau$, and keeps only if the betting test of $\mathbb E D\le0$ rejects \emph{and} the home-signal flag shows $\bar A_{\mathrm{home}}>0$.

\begin{proposition}[Error control for the 0.75 question]\label{prop:check}
If check tasks are drawn independently, each with its own fresh result of the old model, the decision keeps with probability at most $\max(\alpha,\alpha_{\mathrm{flag}})$ whenever $\theta\le0.75$ or $\bar A_{\mathrm{home}}\le0$, and drops with probability at most $\alpha$ whenever $\theta\ge0.25$, at every stopping time.
\end{proposition}
Both conditions bite. Without the sign condition a reversed home order ($\bar A_{\mathrm{home}}=-0.10$) is kept in 0.999 of streams; re-using a stored table of 300 tasks' home results beyond its size gives false keeps of 0.11 by 3,000 tasks. The test therefore stops when the stored home results run out, and on a real swap day the old model's results on every check task must be collected before it retires: $4\times2$ old-model calls per task.

\begin{theorem}[Information limit]\label{thm:bound}
Let a decision keep with probability at most $\alpha$ under every reader with $\theta\le\theta_0$ and at least $1-\beta$ under a reader at $\theta_1$, observing one fresh Bernoulli check per chosen (task, candidate) cell. Then the expected number of checks at $\theta_1$ is at least $d(1-\beta\,\|\,\alpha)/K^\star$, with $d$ the binary Kullback--Leibler divergence and $K^\star$ the largest, over rules for choosing cells, of the smallest per-check divergence between the reader at $\theta_1$ and any reader with $\theta\le\theta_0$. For whole tasks drawn uniformly at random and checked in full, to second order $K^\star=(\theta_1-\theta_0)^2\bar A_{\mathrm{home}}^2/(8\,\mathbb E\sigma_\tau^2)$ per check, $\sigma^2_\tau$ the within-task Bernoulli variance of $A_\tau$.
\end{theorem}
The bound depends on four things: the observation scheme, the margin, the signal and the error levels.
At the practice study's signal ($\bar A_{\mathrm{home}}=0.22$, $\alpha=0.05$, power $0.8$) and whole random tasks, it is about 65 checks for margin 0 (95\% interval 49--91) and 1,050 checks (262 tasks, interval 198--366) for margin 0.75; choosing cells adaptively lowers it by a factor of only 1.3, and scores learned to their limit (true item usefulness, $\bar A_{\mathrm{home}}=0.32$) would lower it to 30 and 470 checks.
Our tests need 364 and 2,900 checks (medians), 5.3 and 2.8 times the bound; the decision form needs 281 checks against a bound of 100.
```
Notes for this section:
- Figure suggestion: `fig_sequential_bound_curve` (bound in checks against the margin theta_0 from 0 to 0.9 at the study's signal, with its interval; second panel: against Abar_home, margins 0 and 0.75, with markers "current scores" and "long score phase"). Data: `sequential_bound_curve.csv` (curve = margin / signal / marker). Not yet drawn; the statistics worker or the paper worker may draw it from the CSV.
- "8" in the closed form: per CHECK (4 checks per task); per task it is 2.
- The fixed paired z test needs 899 tasks in the reviewer model (the 701 quoted in round 1 was the known-home z test).
- 896/439 = 2.04 (reviewer model), 731/262 = 2.79 (practice study, paired), 749/262 = 2.86 (fresh draws). Never write "about twice the bound" without the setting.

---

## 3. Appendix: proofs of the swap-day results

```latex
\paragraph{\Cref{prop:margin0}.}
Let $u_\tau=(A^{\mathrm{swap}}_\tau+1)/2\in[0,1]$ (or $(d_\tau+1)/2$ for the decision form). Conditions: (i) the bank (items, scores, candidate sets) is fixed, so the target is the bank's value $\theta_{\mathrm{bank}}$, not the item-population value; (ii) the check tasks are drawn independently from the stream; (iii) every check is a fresh call, independent of earlier checks given the task; (iv) the statistic is bounded. Under $H_0$, $\mathbb E[u_\tau]\le\tfrac12$, so for the registered mixture of constant bets $\eta_k=k/40$, $k=1,\dots,20$, the wealth $\Psi_t=\tfrac1{20}\sum_k\prod_{s\le t}(1+\eta_k(u_s-\tfrac12))$ is a nonnegative supermartingale with $\Psi_0=1$ (each factor is at least $0.75$), and Ville's inequality gives $P(\sup_t\Psi_t\ge1/\alpha)\le\alpha$. No home value enters. $\square$
Checked at the exact boundary in four worlds (the reviewer model, a world with task heterogeneity, review R6's simulator, and the practice study's own tables), 2,000 streams each: the largest share keeping (or wiping) by any task up to 3,000 was 0.026--0.039 (ranking) and 0.024--0.039 (decision form).

\paragraph{\Cref{prop:check}.}
With $D_\tau=A^{\mathrm{swap}}_\tau-cA^{\mathrm{home}}_\tau\in[-(1+c),1+c]$, $c\in\{0.75,0.25\}$, and $A^{\mathrm{home}}_\tau$ the old model's result on the same task, conditions (i)--(iv) and (v) a fresh home result for every task drawn make the pairs $(A^{\mathrm{swap}}_\tau,A^{\mathrm{home}}_\tau)$ independent and identically distributed (they may depend on each other within a task), so $D_\tau$ has mean $\bar A_{\mathrm{swap}}-c\bar A_{\mathrm{home}}$ and the same martingale argument on $(D+1+c)/(2+2c)$ bounds the chance that the test of $\mathbb E D\le0$ ever rejects by $\alpha$. The event $\mathbb E D\le0$ is $\theta\le c$ only when $\bar A_{\mathrm{home}}>0$; the decision therefore also requires the home-signal flag (the owner's signed validity on its calibration tasks at least two standard errors above zero, tasks disjoint from the stream). By the intersection--union principle \citep{berger1982multiparameter} a keep is wrong with probability at most $\alpha$ when $\bar A_{\mathrm{home}}>0$ and $\theta\le0.75$, and at most the flag's size when $\bar A_{\mathrm{home}}\le0$ (0.015--0.032 at $\bar A_{\mathrm{home}}=0$ with 100 and 24 calibration tasks). A drop needs no sign: $P(\text{drop})\le\alpha$ whenever $\bar A_{\mathrm{swap}}\ge0.25\,\bar A_{\mathrm{home}}$. If home results were re-used, the $D_\tau$ would no longer be independent and the guarantee would hold for the stored table, not for the stream; the test stops at the store. $\square$
Checked with the home value estimated afresh in each replication (2,000): false keeps at $\theta=0.75$ by 6,000 tasks 0.030 (reviewer model and heterogeneous model) and 0.015 (R6's simulator), false drops at $\theta=0.25$ 0.039, 0.039 and 0.014; the counter-examples (negative home: keep 0.999 without the flag, 0 with it; a 300-task store re-used: 0.035, 0.113, 0.169 by 1,000, 3,000, 6,000 tasks, 0.000 when the test stops at the store).

\paragraph{\Cref{thm:bound}.}
Let $\mathbb P_0$ and $\mathbb P_1$ differ only in the reader's success table, with $\theta\le\theta_0$ under $\mathbb P_0$ and $\theta=\theta_1$ under $\mathbb P_1$. For any rule that chooses the next (task, candidate) cell from the past, stops at a stopping time $N$ with $\mathbb E_1N<\infty$ and then decides, the divergence of everything observed is $\sum_c\mathbb E_1[N_c]\,\mathrm{kl}(\mu_{1c}\|\mu_{0c})$ (Wald's identity per cell; \citealp{kaufmann2016complexity}, Lemma~1), and by data processing on the event \textsc{keep} it is at least $d(\mathbb P_1(\textsc{keep})\,\|\,\mathbb P_0(\textsc{keep}))\ge d(1-\beta\,\|\,\alpha)$. Writing $w_c=\mathbb E_1[N_c]/\mathbb E_1[N]$ and minimising over feasible $\mathbb P_0$ (one linear constraint, since $\mathbb E A_\tau$ is linear in the success chances) gives $\mathbb E_1N\ge d(1-\beta\|\alpha)/\sup_w\inf_{\mathbb P_0}\sum_cw_c\,\mathrm{kl}(\mu_{1c}\|\mu_{0c})$. For whole tasks drawn uniformly, $w$ is fixed and the inner problem has the per-cell solution $(q-p)/(q(1-q))=-\nu c_{\tau i}$; to second order $K^\star=\Delta^2/(2\sum_c w_c^{-1}c_c^2v_c)$ with $\Delta=(\theta_1-\theta_0)\bar A_{\mathrm{home}}$ and $v_c=\mu_c(1-\mu_c)$, maximised by $w_c\propto|c_c|\sqrt{v_c}$. $\square$
What the theorem does not cover: observations other than fresh checks of the reader on a cell (the old model's self-ratings, a judge, log-probabilities), smaller null sets, repeated checks that are not fresh, and targets defined on a finite pool. The bound is an estimate: $\bar A_{\mathrm{home}}$ and $\mathbb E\sigma^2_\tau$ come from the owner's two home repeats (unbiased $\mu(1-\mu)=\bar y-y_1y_2$ per cell), and its 95\% interval is a task bootstrap (198--366 tasks at margin 0.75; an owner-level bootstrap gives 175--422).
Gains from choosing cells: 1.24--1.31 in our task models and 1.56 in R6's model with many near-deterministic tasks.
```

---

## 4. Appendix: the transfer decomposition as a measurement check (D5; out of the body)

Title: "A measurement check: does the retained value agree with the transfer slope?" Labels kept: `app:proofs`
for the appendix that holds it, `eq:law` (now the identity of R), `prop:law`, `prop:linear`.

```latex
\paragraph{Two identities.}
$\Cw=\tfrac12+\sum_\tau V(\tau)/(2\sum_\tau W(\tau))=(1+\Gamma)/2$, with $\Gamma$ the pooled within-task Gini correlation of outcomes with score ranks (a ratio of covariances pooled over tasks, weighted by the candidates per task; \citealp{schechtman1987gini}); and, on the same pairs,
\begin{equation}
\Cswap-\tfrac12=\theta\,\frac{W_{\mathrm{home}}}{W_{\mathrm{swap}}}\Bigl(\Chome-\tfrac12\Bigr),
\label{eq:law}
\end{equation}
so the concordance ratio $R$ moves with the reader's outcome noise and $\theta$ does not. Both are exact for any data.

\paragraph{The check.}
Let $\gamma=\mathbb E[\delta^s\delta^t]/\mathbb E[(\delta^s)^2]$, the least-squares slope of the reader's within-task usefulness differences on the owner's, estimated without scores by $\hat\gamma=\sum\Delta\ybar^{s,12}\Delta\ybar^t/\sum\Delta\ybar^{s,12}\Delta\ybar^{s,34}$ (two time-separated home sessions, so that dependence between repeats inside a session cannot bias it), and $\hat\rho=\sum\Delta\ybar^{s,12}\Delta\ybar^t/(\sum\hat d^{\,2}_s\sum\hat d^{\,2}_t)^{1/2}$ the corresponding correlation corrected for outcome noise \citep{spearman1904proof}. Identically $\mathbb E[a\delta^t]=\gamma\,\mathbb E[a\delta^s]+L$, so $\theta\to\gamma+L/\mathbb E[a\delta^s]$ when $\mathbb E[a\delta^s]\neq0$ and tasks are independent. $L=0$ says that the instrumental-variable slope $\theta$ (instrument $a$, the sign of the score difference) equals $\gamma$, a specification restriction \citep{hausman1978specification}; we test it through $Q=V_{\mathrm{swap}}\sum\Delta\ybar^{s,12}\Delta\ybar^{s,34}-V_{\mathrm{home}}\sum\Delta\ybar^{s,12}\Delta\ybar^t$, which needs no ratio, with the variance of \cref{app:statistics}. It is an in-sample consistency check of $\hat\theta$ against $\hat\gamma$ on the same tasks: $\hat\gamma$ is a fitted slope and uses the reader's results, so it is not a prediction.

\paragraph{What a rejection means.}
$L\neq0$ whenever the scores' signal sits where transfer is better or worse than average: leakage of the reader's own item effects into the scores, task-specific usefulness that transfers at a different rate from the items' (R6's worlds: $L$ of $+0.125$ and $-0.075$ in $\theta$ with item usefulness transferring exactly linearly), or a monotone but curved relation between the two models' chances. For a reader whose chance is an increasing function of the owner's, the miss depends on where the owner's chances sit: within one logit of the owner it ranged from 0.00 to 0.035 in three of our owner worlds and reached 0.10--0.14 in worlds with hard or easy tasks.

\paragraph{Against simple baselines.}
Its error in the swap concordance is the sampling error of $\hat\theta-\hat\gamma$, so mean absolute errors measure noise, not an account. In our linear worlds it tied $R=\hat\gamma$ whenever owner and reader were equally noisy (0.025 against 0.025 at 900 tasks; 0.015 against 0.015 with a strong signal), beat it only when the reader was less noisy (0.026 against 0.048), beat $R=\hat\rho$ when the reader's spread differed (0.023 against 0.077), and lost to ``no change'' when the reader's lower noise offset the loss (0.026 against 0.019); review R6 found the same in his worlds. In the practice study it ties $R=\hat\rho$ (\Res{DecompMaeDecompAllSwapsValue} against \Res{DecompMaeRhoOnlyAllSwapsValue}).

\paragraph{Readings.}
Family T (nine members, Holm at 0.05): in each swap group the specification test and the equivalence test of the weighted gap within $\pm0.02$ in $\Cw$, and three score-family differences. Each group reads \emph{specification supported} (equivalence shown), \emph{fails} (specification test rejects and the gap is at least $0.02$), \emph{departure within the margin}, or \emph{inconclusive}.
```
Practice-study reading: all three groups "inconclusive" (`decomp_summary.csv`, group family_T, metrics T1_reading_upgrade / _downgrade / _cross; the 90% Fieller interval of each weighted gap is in lo/hi).

Transfer slope: see section 6 of this file (decision: whether to print gamma-hat beside the simulator truth).

---

## 5. Appendix: the forecast (one paragraph; body: one pointer sentence)

Body pointer: `The pre-swap forecast and its test are in \cref{app:forecast}.`
```latex
\paragraph{The forecast before the swap.}
\label{app:forecast}
No-memory runs of both models (write, score and calibration tasks; 950 calls of the new model and 200 of the old per swap day, made before the swap) give their error consistency \citep{cohen1960kappa,geirhos2020error}, their capabilities and the same-maker flag. The single test asks whether error consistency adds to the same-maker flag, the two models' capabilities, their gap and which model of a maker is the newer one: the partial correlation of $\theta$ with error consistency given these, with a null by double semi-partialling \citep{dekker2007sensitivity} over the 384 relabellings that permute models within makers and makers among themselves. Its level stayed within 0.050--0.060 in the null worlds we report and in review R6's, and power at eight models is 0.57--0.68 for a partial correlation of 0.3 and 0.98 for 0.6; a capability effect curved in both arrays raises the level to 0.12. Agreement (P1) is tested the same way.
```

---

## 6. The transfer slope (round-2 decision)

See `docs/theory_note.md` section "Round 2". In the practice study gamma-hat is below the simulator's truth in
10 of 12 swaps (same maker 0.52 against 0.69). Cause: each owner's cross-session denominator comes from 56
tasks per order; three of the four owners' denominators came out 12-37 % above their truth, and every swap of an
owner shares its denominator, so the 12 swaps are four draws, not twelve. In our synthetic worlds with the same
estimator the median gamma-hat sits within 0.03 of the truth at 900 tasks (0.573 against 0.600) and the mean
within 0.01; at the practice study's size it is heavy-tailed (median 0.68, mean 0.79 against 0.60). On the
full-size simulated study (8 models, 400 evaluation tasks per order; `msr.theory.slope_truth_rows("simfull")`)
it tracks the truth: upgrades 0.541 against 0.540, downgrades 0.642 against 0.660, cross-maker 0.280 against
0.294; over all 56 swaps mean difference -0.013, median -0.005, correlation 0.968, and every Fieller interval
covers the truth.
Decision: print gamma-hat with its Fieller interval; compare it with a simulator's truth only on the full-size
simulation; on the practice study write "the practice study is too small for the slope: each owner's
denominator rests on 56 tasks per order and is shared by its three swaps".
Ready-to-paste (appendix, dry run only):
```latex
On the full-size simulated study the cross-session slope tracks the simulator's truth (upgrades 0.54 against 0.54, downgrades 0.64 against 0.66, cross-maker swaps 0.28 against 0.29; every 95\% Fieller interval of the 56 swaps covers its truth); the four-model practice study is too small for it, since each owner's denominator rests on 56 tasks per order and is shared by its three swaps.
```

---

## 7. Labels, citations, macros

- Labels defined in this text: `sec:forecast-check`, `prop:margin0` (new), `prop:check`, `thm:bound`,
  `app:forecast`, `eq:law` (now the identity of R in the appendix), `prop:linear`, `prop:law` (keep them if
  the appendix keeps Propositions; otherwise point the two outside references (05_results) to `eq:law`).
- Citations used: waudbysmith2024betting, kaufmann2016complexity, berger1982multiparameter (check the key in
  references.bib; it is cited in A9 as Berger 1982), schechtman1987gini, spearman1904proof,
  hausman1978specification, dekker2007sensitivity, cohen1960kappa, geirhos2020error.
- New macros needed (statistics worker, `make_paper_assets.py`): CheckMarginZero* and CheckBoundKeepTasks*
  (section 1), DecompMaeRhoOnlyAllSwapsValue (exists: metric mae_rho_only).
- Cost rows for the single cost table: `msr.sequential.swap_day_calls(rule, n_tasks, store_tasks)` and
  `msr.forecast.forecast_calls()`; see section 8.

## 8. Cost accounting (manager's two faults)

1. The 0.75 (paired) test is not free: 4 candidates x 2 repeats = 8 OLD-model calls per stored check task, plus
   the home flag's calibration tasks (100 x 4 x 2 = 800), all before the old model retires. With the replay's
   store (200 tasks per order) that is 2,400 old-model calls; to reach its median stopping time at the practice
   signal (about 730 tasks) the store must hold about 730 tasks: about 6,650 old-model calls. The margin-0
   tests need NO old-model call: 4 new-model checks per task (ranking) or 2 per task where keep and wipe differ
   (decision form). Function: `msr.sequential.swap_day_calls`.
   Sentence for the paper: "The 0.75 test needs the old model's results on every check task, eight calls per
   task, collected before it retires; the break-even test needs none."
2. The forecast costs 1,150 calls per swap day (950 new-model no-memory calls on the write, score and
   calibration tasks; 200 old-model calls on the calibration tasks), none of them a check of a memory item.
   Function: `msr.forecast.forecast_calls`. Sentence: "The forecast is not free: it needs 1,150 no-memory calls
   per swap day, 950 of them by the new model."

## 9. For the statistics worker: P1 with F1's test (AC audit N3)

In `msr/analysis.py` `predictions()`, replace the `p1_stat` / `_perm_p` lines for P1 by (forecast agent's call):
```python
from msr.forecast import newer_coding, pair_controls, pair_incremental_test
p1_all = [c for c in swaps if np.isfinite(Kg[mi[c[0]], mi[c[1]]])]
si1 = np.array([mi[c[0]] for c in p1_all], int); ti1 = np.array([mi[c[1]] for c in p1_all], int)
Xcap = np.nanmean(np.stack([X[b] for b in E.streams]), axis=0)
r1 = pair_incremental_test(Kg[si1, ti1], Rg[si1, ti1], si1, ti1, [design.family[m] for m in models],
        controls=pair_controls(si1, ti1, Xcap, newer_coding(models, design.upgrades)), alpha=design.alpha)
```
and take obs, p (one-sided), p_opposite and min_p1 from `value`, `p_one_sided`, `p_opposite`, `min_attainable_p`.
F1's controls rather than the maker flag alone: over 800 null worlds the maker flag alone passes wrongly in
0.099 (capability world), 0.20 (capability level) and 0.13 (newer-model position in both arrays); F1's
controls give 0.056, 0.048 and 0.07, at a power cost of 0.67 -> 0.61 at rho 0.3.
