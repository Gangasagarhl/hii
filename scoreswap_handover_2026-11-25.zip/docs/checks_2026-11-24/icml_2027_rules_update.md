# ICML 2027 rules: what changed since 17 Nov, and does our plan meet them? (checked 24 Nov 2026)

Every ICML page below was downloaded on 24 Nov 2026 local time (23 Nov 2026, about 21:35 UTC) and read as text. The quotes
are verbatim. The style kit was not re-opened. Its file on the server is dated 10 Nov 2026 (HTTP `Last-Modified`), so the
23 Nov reading of it still stands.

The everyday picture: before sending a dish to a cooking contest, read the latest rule sheet. Then tick each rule against
what we plan to bring.

## 1. What is new

**The promised update is not out yet.** The Call for Papers still says:

> "Note: ICML is planning to make some updates to the submission process (but not the submission format). We will
> announce them by late November, please stay tuned."

Its change log ends at 20 November:

> "# Nov. 13th: initial version
> # Nov. 17h: clarification added "Since serving on the program committee in any role requires meeting the reciprocal
> reviewer eligibility criteria, an author who does not meet them may appear on at most 2 submissions."
> # Nov. 20th: call for position papers is out. Added position paper as contribution type."

Source: https://icml.cc/Conferences/2027/CallForPapers

So since 17 Nov there are only two things:
- **(a) A two-submission cap** (the 17 Nov line) for any author who is not an eligible reciprocal reviewer.
- **(b) Position papers** now go "through the main track by selecting 'Position Paper' as the Contribution Type". This does
  not touch us.

Nothing else has changed in what we read: dates, page limit, the contribution type text, the AI policy, the quotas, the
code and data rules, and the reviewer timeline. Three pages are still placeholders: Area Chair Instructions ("will be
published before the review period"), Peer Review FAQ and Research Ethics.

**Next step:** re-read the CFP about 1 Dec 2026 and again before 14 Jan 2027.

## 2. Rules and our plan

The plan as checked:
- an 8-page body;
- an anonymous code and data release, with a held-out test half kept by the maintainers;
- a public pre-registration deposit;
- an AI-use statement.

| # | Rule (quote) | Source | Does our plan meet it? |
|---|---|---|---|
| 1 | Dates: "Abstract submission deadline: January 14, 2027 11:59 PM AOE"; "Full paper submission deadline: January 22, 2027 11:59 PM AOE"; "In no circumstances will extensions be given." Dates page: First-Stage Rejection Notification "Feb 23 '27"; final decisions "May 03 '27" | [CFP](https://icml.cc/Conferences/2027/CallForPapers), [Dates](https://icml.cc/Conferences/2027/Dates) | Yes. The timetable submits the abstract by 14 Jan and the paper by 22 Jan. |
| 2 | Page limit: "8 pages for the main paper, with unlimited pages for references, the impact statement, and appendices"; "any submission whose main body goes over the 8 page limit will be automatically rejected"; "The submission PDF has a maximum size of 50MB" | [CFP](https://icml.cc/Conferences/2027/CallForPapers), [Author Instructions](https://icml.cc/Conferences/2027/AuthorInstructions) | Yes: 8-page body. Keep the PDF under 10 MB, because the style kit says 10 MB (23 Nov reading). |
| 3 | Contribution type: "Authors should clearly state what scientific claims the dataset, benchmark, or evaluation supports and explain the assumptions and limitations under which those claims hold. When relevant, authors should address issues such as licensing, privacy, consent, data provenance, annotation practices, potential biases, contamination, intended use, and limitations." | [Contribution Types](https://icml.cc/Conferences/2027/ContributionTypes) | Yes in plan: the datasheet, licences per source, contamination note and limitations section (Master Plan 6 and 7). The datasheet and licences are still stubs (STATUS, D11). |
| 4 | Data hosting and metadata: **no ICML 2027 page names a hosting platform, Croissant or any machine-readable metadata.** The only data text: "Data submissions (provided that the authors have the right to do so) in anonymous repositories are welcome." At camera-ready: "they are responsible for providing an archival link to a suitable repository." | [Author Instructions](https://icml.cc/Conferences/2027/AuthorInstructions) | Yes. The plan's "no Croissant file for ICML" ruling stands. Plan an archival link (for example a DOI) for the camera-ready. |
| 5 | Code anonymity: "we expect authors to anonymize the submitted code. This means that author names and licenses should be removed. Submission of code through anonymous GitHub repositories is also allowed; however, they have to be on a branch that will not be modified after the submission deadline. Please enter the GitHub link in a standalone text file in a submitted zip file." Also: "Authors should not include links to non-anonymized repositories" and "refrain from including acknowledgements, grant numbers, or links to public code repositories". | [Author Instructions](https://icml.cc/Conferences/2027/AuthorInstructions) | **Partly.** The plan says "anonymous code, data". It does not yet say to **remove the licence files** and author names from the submitted copy, or to freeze the branch at 22 Jan with the link in a text file inside the zip. Add these to the 6–13 Jan release step. |
| 6 | The supplement becomes public: "For accepted papers, the originally submitted manuscript and supplementary material will become publicly available on OpenReview." | [Author Instructions](https://icml.cc/Conferences/2027/AuthorInstructions) | **Conflict to manage.** If the held-out test half goes into the supplement, it becomes public on acceptance and is no longer held out. Keep the test half out of the supplement. Submit only its sha256 commitment and the dev half. |
| 7 | Reproducibility: "Reproducibility of results and easy availability of code will be taken into account in the decision-making process." "All claims must be clearly stated and supported by reproducible experiments". | [Author Instructions](https://icml.cc/Conferences/2027/AuthorInstructions), [CFP](https://icml.cc/Conferences/2027/CallForPapers) | **Watch.** No ICML rule forbids a private test half. But the plan also promises "A script that rebuilds every number and figure in the paper from the released files" (Master Plan 7.6). Then every number in the paper must come from released files, the dev half and the probe tables. Test-half numbers belong only on the leaderboard, and the paper should say so. |
| 8 | Pre-registration: **no ICML 2027 page mentions pre-registration** (searched on all 13 pages read). The anonymity rules still apply: "Note that anonymizing the submissions is mandatory, and papers that explicitly or implicitly reveal the authors’ identities will be rejected." ([Author Instructions](https://icml.cc/Conferences/2027/AuthorInstructions)), and "If the authors have posted or plan to post a non-anonymized version of the paper online before the ICML decisions are made, the submitted version must not refer to the non-anonymized version." | [CFP](https://icml.cc/Conferences/2027/CallForPapers) | **Not yet met.** A public deposit is allowed, but the deposit will carry the authors' names. Cite it in the submission only through an anonymous view, or by its hash and time stamp. The plan's pre-registration header ("registry ____, identifier ____, URL ____") does not say this yet. |
| 9 | AI statement: "All submissions must include an AI Disclosure Statement at the end of the paper, before or after the references. The AI Disclosure Statement does not count toward the paper page limit." It "does not replace methodological reporting". When AI is "a component of an experimental pipeline", "its use must be described in the main paper with sufficient detail to allow readers to understand and, where appropriate, reproduce the methodology." | [GenAI policy](https://icml.cc/Conferences/2027/UseOfGenerativeAIByAuthors) | **Mostly.** The plan has the statement (Master Plan 6), and `paper/main.tex` already has a section. Two gaps: (i) the paper heading says "AI Use Statement" (the style kit's name) while the policy says "AI Disclosure Statement", so use the policy's name or both; (ii) the eight models and any new-model-as-judge stage (D7) are part of the method, so describe them in the main body, not only in the statement. |
| 10 | Impact statement: "Authors are required to include a statement of the potential broader impact of their work ... in a separate section at the end of the paper". | [CFP](https://icml.cc/Conferences/2027/CallForPapers) | Yes. `paper/main.tex` has an Impact Statement section. |
| 11 | Conflicts: "As part of the submission process, authors must disclose any financial or other substantive conflicts of interest that could reasonably be perceived to influence the submission". At camera-ready: "One typical case is when the paper evaluates a model developed by the company that employs one or several of the authors. This must be disclosed." | [Peer Review Ethics](https://icml.cc/Conferences/2027/PeerReviewEthics), [Author Instructions](https://icml.cc/Conferences/2027/AuthorInstructions) | **Not in the plan.** We evaluate models from four makers. Add a submission-form check to the 6–13 Jan step. |
| 12 | References: "Hallucinated references." is a listed ground for desk rejection of a single submission. | [Peer Review Ethics](https://icml.cc/Conferences/2027/PeerReviewEthics) | Yes in plan: every reference is opened and logged in `paper/reference_ledger.md`. |
| 13 | Quotas: "Each author may appear as a co-author on at most one submission in which no author is an eligible reciprocal reviewer"; "an author who does not meet them may appear on at most 2 submissions" (new 17 Nov); "each submission must designate one of its authors as its reciprocal reviewer when the abstract is registered"; reviews due "(February 24–March 16, 2027)"; "Eligibility is determined from OpenReview profiles ... Incorrect profile information may lead to desk rejection." | [Reciprocal Reviewing](https://icml.cc/Conferences/2027/ReciprocalReviewingAndSubmissionQuotas), [CFP](https://icml.cc/Conferences/2027/CallForPapers) | **An owner decision.** If no author is eligible, this is the team's one submission and no reviewer is designated. If an author is eligible, name them at abstract time and they must review from 24 Feb to 16 Mar. Profiles must be complete by 14 Jan. The plan lists "OpenReview profiles; author list" for 6–13 Jan. |
| 14 | Checklist: **no reproducibility checklist or other checklist appears on any ICML 2027 page read.** Other required items: the lay summary at camera-ready and the self-ranking for authors with several submissions. | [CFP](https://icml.cc/Conferences/2027/CallForPapers) | Nothing to do now. |
| 15 | Author list: "The author list cannot be changed after the abstract deadline. After the abstract deadline, authors may be reordered, but not added or removed." | [CFP](https://icml.cc/Conferences/2027/CallForPapers) | Yes in plan: the author list is fixed by 14 Jan. |

## 3. What to add to the plan (no change made here)

1. Release step (6–13 Jan): strip the licence files and author names from the submitted code. Freeze the anonymous branch
   at the deadline, with its link in a text file inside the zip.
2. Keep the held-out test half out of the supplement. Make sure every paper number comes from released files.
3. Pre-registration: deposit publicly as planned, but cite it in the paper only through an anonymous view or its hash and
   time stamp.
4. Name the section "AI Disclosure Statement", and describe the models used as part of the method (subjects and any
   judge) in the main body.
5. Add the conflict-of-interest disclosure to the submission checklist.
6. Re-read the CFP change log about 1 Dec for the "late November" update.

## 4. Pages read (all on 24 Nov 2026)

- https://icml.cc/Conferences/2027/CallForPapers
- https://icml.cc/Conferences/2027/AuthorInstructions
- https://icml.cc/Conferences/2027/ContributionTypes
- https://icml.cc/Conferences/2027/Dates
- https://icml.cc/Conferences/2027/UseOfGenerativeAIByAuthors
- https://icml.cc/Conferences/2027/ReciprocalReviewingAndSubmissionQuotas
- https://icml.cc/Conferences/2027/LLM-Policy
- https://icml.cc/Conferences/2027/PeerReviewEthics
- https://icml.cc/Conferences/2027/ReviewerInstructions (its tentative timeline is unchanged and still differs from the
  reciprocal page: reviewing "February 12 - March 12, 2027" against "February 24–March 16, 2027")
- https://icml.cc/Conferences/2027/CallForPositionPapers
- https://icml.cc/Conferences/2027/AreaChairInstructions, https://icml.cc/Conferences/2027/PeerReviewFAQ and
  https://icml.cc/Conferences/2027/ResearchEthics (placeholders)
- The style kit (https://media.icml.cc/Conferences/ICML2027/styles/icml2027.zip): headers only (`Last-Modified: Tue,
  10 Nov 2026`)
