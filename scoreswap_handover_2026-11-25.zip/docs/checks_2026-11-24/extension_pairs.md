# Extension pairs: more open-weight, same-maker swaps (checked 24 Nov 2026)

All pages were read on 24 Nov 2026 local time (23 Nov, 21:15 to 21:40 UTC). No model was called. Prices are US dollars
per million tokens, input / output. "OR" means OpenRouter's public listing (an aggregator, not the host's own page).

The everyday picture: we have four garages, and each swaps an old helper for a newer helper of the same brand. Four is too
few to say much about "same brand" swaps. So we look for two or three more garages with cheap helpers that never retire,
and run only the two same-brand swaps in each one.

## 1. Recommendation

| Rank | Pair (old -> new) | OR model IDs | Host, precision | Price old -> new | Released (old / new) | Cost of the pair* |
|---|---|---|---|---|---|---|
| 1 | Mistral Small 3 -> Mistral Small 3.2 (24B dense) | `mistralai/mistral-small-24b-instruct-2501` -> `mistralai/mistral-small-3.2-24b-instruct` | DeepInfra fp8 (`deepinfra/fp8`) | 0.05 / 0.08 -> 0.075 / 0.20 | 30 Jan 2025 / 20 Jun 2025 | about $15 (2.2 %) |
| 2 | DeepSeek V4.1-Flash -> V4.1-Flash-1017 (763B MoE) | `deepseek/deepseek-v4.1-flash` -> `deepseek/deepseek-v4.1-flash-1017` | DeepInfra fp8 (`deepinfra/fp8`); spare fp8 hosts: Parasail, SiliconFlow, Novita | 0.14 / 0.42 -> 0.098 / 0.294 (discounted; list 0.20 / 0.60 for both) | 10 Sep 2026 / 17 Oct 2026 | about $28 (4.2 %); $48 at list price |
| 3a | Qwen3.5-35B-A3B -> Qwen3.6-35B-A3B (36B MoE) | `qwen/qwen3.5-35b-a3b` -> `qwen/qwen3.6-35b-a3b` | DeepInfra fp8 (`deepinfra/fp8`) | 0.14 / 1.00 -> 0.10 / 0.95 | 25 Feb 2026 / 27 Apr 2026 | about $35 (5.3 %) |
| 3b | GLM-4.6 -> GLM-4.7 (357B MoE) | `z-ai/glm-4.6` -> `z-ai/glm-4.7` | Z.AI, the maker's own API (OR lists fp4); or DeepInfra fp4 | Z.AI 0.60 / 2.20 for both; DeepInfra 0.50 / 2.00 -> 0.40 / 1.75 | 30 Sep 2025 / 22 Dec 2025 | $113 (DeepInfra) to $148 (Z.AI): 17 to 22 % |

*Cost of one extension pair = both models built on their own banks, the two home cells and the two swaps, both streams,
three orders, all current stages. Share = cost / $670 (today's full-study estimate). The OpenRouter credit fee (5.5 %) is
extra, as in the main estimate.

**Advice.** Take ranks 1 and 2: two new makers (Mistral, DeepSeek) for about $43, or 6.4 % of the money. Each pair adds
241,800 calls (10.8 % of the 2,240,400 calls), but these models are cheap. For a third pair:
- take 3a if money decides: $35, the total is then about $78 (11.7 %), close to the "+12 %" in D9. But it is a second Qwen
  pair, so it adds swaps, not a new maker;
- take 3b if a fifth maker matters more: it costs three to four times more.

**What to watch in each recommended pair:**
- Mistral Small:
  - Mistral's own API has retired both models: Small 3.0 on 30 Nov 2025 and Small 3.2 on 31 Jul 2026. The weights
    remain, but only third parties serve them.
  - On OpenRouter, only DeepInfra serves Small 3.0, with a 32,768-token context. Our prompts fit easily.
  - Mistral's model card advises "a relatively low temperature, such as `temperature=0.15`". The study runs at 1.0 (decision
    S6). The answers may be noisier and the home signal weaker. Check this in the pilot.
  - Small 3.1 (2503) sits between the two. DeepInfra no longer serves it: it was deprecated on 11 Sep 2025 and replaced
    by 3.2.
- DeepSeek:
  - The card calls 1017 "a minor update to DeepSeek-V4.1-Flash". The step is small, five weeks apart, so expect a swap
    close to a self-swap. That is a useful contrast, but it is not a new version number.
  - Its recommended sampling is temperature 1.0 and top_p 1.0, exactly decision S6.
  - Reasoning is on by default (effort "high"). "none" is a listed effort, so set it on both models.
  - The maker's own route on OR now lists only 1017. That makes the older model the likelier one to be dropped, so run
    it first.
  - If a numbered version step is required, use DeepSeek V3.1 -> V3.2 instead (section 2).

## 2. Every candidate checked

| Pair | Same size? (HF parameters) | Common host at one precision (OR) | Thinking off? | Older model's status | Licence (HF) | Cost of pair | Verdict |
|---|---|---|---|---|---|---|---|
| Mistral Small 3 (2501) -> 3.2 (2506) | 23.57B -> 24.01B (3.2 adds a vision encoder) | DeepInfra fp8 only | no thinking in either | Mistral API: retired 30 Nov 2025. DeepInfra: not deprecated | Apache-2.0 / Apache-2.0 | $15 | **Rank 1** |
| DeepSeek V4.1-Flash -> V4.1-Flash-1017 | 763.2B both | DeepInfra, Parasail, SiliconFlow, Novita, Baidu: all fp8 | yes, effort "none" | no date found anywhere | MIT / MIT | $28 ($48 list; $75 Parasail) | **Rank 2** (small step) |
| Qwen3.5-35B-A3B -> Qwen3.6-35B-A3B | 35.95B both | DeepInfra fp8; SiliconFlow fp8 (0.24 / 1.80 for both) | yes (not mandatory) | none found | Apache-2.0 / Apache-2.0 | $35 | **Rank 3a** (same maker as the main Qwen pair) |
| GLM-4.6 -> GLM-4.7 | 356.8B -> 358.3B | Z.AI fp4; DeepInfra fp4 | yes: `thinking: {type: disabled}`. 4.7 thinks by default | Z.AI pricing page: no notice. GLM-4.7 is Legacy on Amazon Bedrock (end 30 Mar 2027) | MIT / MIT | $113 to $148 | **Rank 3b** (new maker, costly, fp4) |
| DeepSeek V3.1 -> V3.2 | 684.5B -> 685.4B | SiliconFlow fp8 (only fp8 host for both); DeepInfra fp4 | yes (V3.2 off by default) | V3.1 is Legacy on Bedrock, end 30 Mar 2027. SiliconFlow shows no recent uptime figure for V3.1 | MIT / MIT | $60 to $65 | Alternative to rank 2 (true version step; new attention, new chat template) |
| DeepSeek V4-Flash -> V4-Flash-0731 | 290.9B -> 304.2B | DeepInfra fp8, Parasail fp8, Baidu fp8 | yes, effort "none" | none found | MIT / MIT | $17 | Weak: sizes differ by 4.6 %; a dated refresh |
| Kimi K2 (0711) -> K2-0905 | 1.03T both | Novita fp8 only | no thinking in either | DeepInfra deprecated both on 7 Sep 2026 (forwarded to K2.6) | modified MIT | $148 | Reject: one host, costly, already fading |
| Llama 3.1 70B -> Llama 3.3 70B | 70.55B both | Amazon Bedrock only (precision "unknown") | no thinking | DeepInfra deprecated it on 3 Nov 2026 (forwarded to 3.3). Bedrock: Legacy since 30 Sep 2026, end 30 Mar 2027, "New customers can't use Legacy models" | Llama 3.1 / 3.3 community (gated) | $158 | Reject: a new account cannot reach the old model |
| Gemma 2 27B -> Gemma 3 27B | 27.2B -> 27.4B | none: Gemma 2 is on NextBit int4 only | n/a | DeepInfra deprecated Gemma 2 27B (forwarded to Gemma 3 27B) | Gemma (gated) | – | Reject |
| Nemotron 3 Nano -> 3.5 Lightning (30B-A3B) | 31.6B both | none (Nebius fp8 vs DeepInfra bf16) | – | DeepInfra deprecated Nano (forwarded to Lightning) | NVIDIA / OpenMDW | – | Reject |
| GLM-5.2 -> GLM-5.3 | 753.3B both | Z.AI fp8, Novita fp8, SiliconFlow fp8 | **no**: Z.AI says 5.3 uses "forced thinking and cannot be disabled" | Mistral's catalogue retired its GLM 5.2 route on 31 Oct 2026 | MIT / "glm-5.3" licence | – | Reject |
| Cohere Command R -> A -> A Plus | 32B -> 111B -> 219B | – | – | – | CC-BY-NC / Apache | – | Reject: sizes differ |
| Ling 3.0 -> 3.1 flash; Inkling-Small -> Inkling-2-Small; Hy3 -> Hy4 | 127B -> 572B; 266B -> 594B; 299B -> 774B | – | – | – | – | – | Reject: sizes differ |
| Phi-4; Granite 4.2 8B; gpt-oss | – | – | – | no successor of the same size on OR or DeepInfra | – | – | No pair exists |
| Mistral Small 3.2 -> Small 4 (2603) | 24B -> 119B | – | – | – | – | – | Reject: sizes differ |

Notes for the table:
- **Sizes.** HF parameter counts come from the Hugging Face model API (`safetensors.total`).
- **Prices and precision.** From the OR endpoint lists. DeepInfra's own model list agrees on the list prices:
  - Mistral Small 3: 0.05 / 0.08. Mistral Small 3.2: 0.075 / 0.20.
  - DeepSeek V4.1-Flash and its 1017 update: 0.20 / 0.60 each, with discounts of 30 % and 51 % and no end date shown.
  - Qwen 35B-A3B: 0.14 / 1.00 -> 0.10 / 0.95.
- **Settings.** Temperature and top_p are listed as supported on every host named in the table.

## 3. What every open host now adds: silent forwarding

DeepInfra's docs say: "You'll receive at least 1 week's advance notice before the deprecation date" and "after
deprecation, inference requests are automatically forwarded to a recommended replacement model."

Its model list shows this already happening:
- Llama 3.1 70B -> Llama 3.3 70B Turbo
- Nemotron 3 Nano -> Nemotron 3.5 Lightning
- Gemma 2 27B -> Gemma 3 27B
- DeepSeek V3.1-Terminus -> DeepSeek V4-Flash-0731

So on a pinned host, an old model can quietly become a new one. That is exactly the swap we study, but unannounced.

What to do (no change made here):
- Run the older model of each pair first.
- Compare the served model name and OpenRouter's `provider_name` and `upstream_id` with the request on every call. Stop
  on any mismatch.
- On DeepInfra directly, the docs offer `MODEL_NAME:VERSION`.

Parasail's deprecation policy was searched for and not found.

## 4. Do the four existing pairs in config/models.yaml still match? (differences)

The closed models match their vendors' own pages: `claude-haiku-4-5-20251001` $1 / $5, `claude-haiku-5-5` $0.10 / $0.50
(prompts up to 100,000 tokens), `gpt-5.6-luna` $0.20 / $1.20, `gpt-6-luna` $0.10 / $0.50. The fallback pair is also
unchanged: Sonnet 4.6 at $3 / $15 and Sonnet 5.5 at $2 / $10. The OpenAI model pages still list only one snapshot each
(the bare name), and reasoning effort "none" is still offered.

The open models also match: Qwen3.5-27B on DeepInfra fp8 at 0.26 / 2.60, Qwen3.8-27B on DeepInfra fp8 at 0.15 / 1.875,
Gemma 3 27B on Parasail fp8 at 0.08 / 0.45 and Gemma 4 31B on Parasail fp8 at 0.15 / 0.40. All four OR IDs and both
host slugs exist, and every endpoint reports uptime 100 % over the last 30 minutes.

Differences and new facts:
1. **The pin is looser than intended for Qwen3.5-27B.** OR now lists three DeepInfra fp8 endpoints for it:
   - `deepinfra/fp8` at 0.26 / 2.60;
   - `deepinfra/fp8/flex` at 0.208 / 2.08;
   - `deepinfra/fp8/priority` at 0.39 / 3.90.

   OR's routing page says "Tier endpoints already in the routing pool, such as priority endpoints of open-weight models,
   do match their base slug". So `only: [deepinfra]` can reach the priority endpoint. It is the same weights at the same
   precision, but the price and the logged identity differ.

   The same page says "dropping the tier never matches a tier endpoint". So `only: ["deepinfra/fp8"]` would pin the
   standard endpoint.

   The same applies to the Qwen3.8-27B entries and to both `-t07` entries. For Qwen3.8-27B, OR lists one DeepInfra
   endpoint today, but DeepInfra's own list gives the model flex and priority rates. For Gemma, `parasail/fp8` would be
   the exact slug; Parasail has one endpoint per Gemma model today.
2. **The Qwen3.8-27B price is still a discount with no end date.** DeepInfra's list price is 0.20 / 2.50 with
   `discount: 0.25` and `discount_ends_at: null`, which gives 0.15 / 1.875. The config is right, and its note to fall
   back to 0.20 / 2.50 still holds.
3. **Reasoning defaults on OR.** Qwen3.8-27B now shows reasoning on by default at effort "xhigh". Its listed efforts are
   xhigh, medium, low and none. The config's `reasoning: {enabled: false}` is still the right intent; confirm it at the
   smoke test. Gemma 4 31B shows reasoning off by default.
4. **Model commits.** The Qwen commits are unchanged: 3.5-27B `81a287ca484a` and 3.8-27B `37561816e66b`. The 3.5-27B
   record shows a last change on 20 Nov 2026 with the same head commit. The config records no Gemma commits. Today's
   heads are `google/gemma-3-27b-it` `005ad3404e59` and `google/gemma-4-31B-it` `842da3794eaa`.
5. **The Gemma 3 27B warning sign is elsewhere.** It is Legacy on Amazon Bedrock (end 30 Mar 2027). That is not our host,
   and Parasail still serves it.
6. **DashScope alternative (not in `pairs`).** The `qwen3.8-27b` Singapore price of $0.50 / $3.00 is confirmed (page
   updated 5 Nov 2026). Batch is "Unsupported". The page does not mention `qwen3.5-27b`, so its $0.30 / $2.40 was not
   re-checked.

## 5. Sources (all opened 24 Nov 2026)

- OpenRouter models JSON: https://openrouter.ai/api/v1/models
- OpenRouter endpoint lists, `https://openrouter.ai/api/v1/models/<id>/endpoints`, for every OR ID named above
- OpenRouter provider routing: https://openrouter.ai/docs/guides/routing/provider-selection
- OpenRouter reasoning tokens: https://openrouter.ai/docs/guides/best-practices/reasoning-tokens
- DeepInfra model list (JSON): https://api.deepinfra.com/models/list
- DeepInfra models and deprecation: https://docs.deepinfra.com/models
- Hugging Face model API, `https://huggingface.co/api/models/<repo>`, for every repository named above
- Model cards (README):
  - https://huggingface.co/mistralai/Mistral-Small-3.2-24B-Instruct-2506
  - https://huggingface.co/mistralai/Mistral-Small-24B-Instruct-2501
  - https://huggingface.co/deepseek-ai/DeepSeek-V4.1-Flash-1017
  - https://huggingface.co/deepseek-ai/DeepSeek-V4-Flash-0731
  - https://huggingface.co/deepseek-ai/DeepSeek-V3.2
  - https://huggingface.co/deepseek-ai/DeepSeek-V3.1
  - https://huggingface.co/zai-org/GLM-4.7
- Mistral models and retirements: https://docs.mistral.ai/getting-started/models/
- Amazon Bedrock model lifecycle:
  - https://docs.aws.amazon.com/bedrock/latest/userguide/model-lifecycle-legacy.html
  - https://docs.aws.amazon.com/bedrock/latest/userguide/model-lifecycle.html
- Z.AI pricing: https://docs.z.ai/guides/overview/pricing
- Z.AI thinking mode: https://docs.z.ai/guides/capabilities/thinking-mode
- Anthropic pricing: https://platform.claude.com/docs/en/about-claude/pricing
- OpenAI pricing: https://developers.openai.com/api/docs/pricing.md
- OpenAI model pages:
  - https://developers.openai.com/api/docs/models/gpt-6-luna.md
  - https://developers.openai.com/api/docs/models/gpt-5.6-luna.md
- Alibaba qwen3.8-27b: https://www.alibabacloud.com/help/en/model-studio/qwen3-8-27b
- Cost basis: the project's own free estimate (`run.py --estimate`) on `config/study.yaml`, and on a two-model copy
  (one same-maker pair, no cross-maker extra run, no second wording) kept outside the project.

## 6. Gaps

- The hosts' own pages were not read for SiliconFlow, Novita or Parasail; their prices are OR's.
- Hosts outside OR and DeepInfra (for example Together or Fireworks direct) were not checked for Mistral Small 3.
- The output terms of service of DeepInfra and OpenRouter were not read. The licence types come from Hugging Face
  metadata only.
- Whether `reasoning` effort "none" gives zero thinking tokens on DeepSeek V4.1 and GLM-4.7 needs a smoke test.
- Costs assume thinking is truly off: about 44 output tokens per call on average.
