# Retirement status of the eight models (checked 24 Nov 2026)

All pages were read on 24 Nov 2026 local time (23 Nov, about 21:30 UTC). Quotes are copied from the page text.

The everyday picture: each helper has a "last day" that its agency may announce. We want to know which ones have announced
a day, how much warning each agency promises, and whether the open-weight helpers' agencies still send them.

## 1. Summary

| Model | Status today | Date on the page | Promised notice | Earliest retirement if a notice came today |
|---|---|---|---|---|
| `claude-haiku-4-5-20251001` | Active, not deprecated | "Not sooner than October 15, 2026" (already passed) | "at least 60 days" | about 23 Jan 2027 (arithmetic) |
| `claude-haiku-5-5` | Active | "Not sooner than October 7, 2027" | at least 60 days | not before 7 Oct 2027 |
| `gpt-5.6-luna` | not on the deprecations list | none | GA models: "At least 6 months" | about 24 May 2027 (arithmetic) |
| `gpt-6-luna` | not on the deprecations list; it is the named replacement for several retiring models | none | "At least 6 months" | about 24 May 2027 (arithmetic) |
| Qwen3.5-27B, Qwen3.8-27B (DeepInfra fp8) | served; status normal; not deprecated in DeepInfra's own list | none | DeepInfra: "at least 1 week", then requests are **forwarded** to a replacement | about 1 Dec 2026 (arithmetic) |
| Gemma 3 27B, Gemma 4 31B (Parasail fp8) | served; status normal | none | Parasail's policy was not found | unknown |

**The reviewer's claim is confirmed.** Anthropic's status table lists `claude-haiku-4-5-20251001` as Active, Deprecated
"N/A", tentative retirement date "Not sooner than October 15, 2026". That date has passed, so only the 60-day notice
protects the model now.

## 2. Anthropic

Source: https://platform.claude.com/docs/en/about-claude/model-deprecations (read 24 Nov 2026).

- Policy: "Anthropic notifies customers with active deployments for models with upcoming retirements, providing at least
  60 days' notice before model retirement for publicly released models."
- Status table rows, verbatim:
  - `claude-haiku-5-5 | Active | N/A | Not sooner than October 7, 2027`
  - `claude-haiku-4-5-20251001 | Active | N/A | Not sooner than October 15, 2026`
  - `claude-sonnet-4-6 | Active | N/A | Not sooner than February 17, 2027` (the fallback pair's old model)
  - `claude-sonnet-5-5 | Active | N/A | Not sooner than September 28, 2027`
- **New since the 23 Nov check:** `claude-opus-4-5-20251101 | Deprecated | November 23, 2026 | January 22, 2027`.
  - The history says: "On November 23, 2026, Anthropic notified developers using Claude Opus 4.5 of its upcoming
    retirement on the Claude API."
  - That notice gave exactly 60 days. Its "not sooner than" date was 24 Nov 2026, and the notice came one day before it.
  - Haiku 4.5 is the same 4.5 generation and is now 40 days past its own date. A notice could come any week.
  - If one comes, expect exactly the 60-day minimum.
- The dates apply to Anthropic-operated platforms only: "Partner-operated platforms, Claude Models on Google Cloud (Google
  managed) and Amazon Bedrock, set their own retirement schedules". Use the Claude API directly, as planned.

What to do (no change made here):
- Keep the rule "all Haiku 4.5 calls first". The plan's Haiku window (1 to 8 Dec) would finish inside even a notice
  posted today.
- Check the page weekly, as `CLAUDE.md` says.

## 3. OpenAI

Sources, read 24 Nov 2026:
- https://developers.openai.com/api/docs/deprecations.md
- https://developers.openai.com/api/docs/models/gpt-6-luna.md
- https://developers.openai.com/api/docs/models/gpt-5.6-luna.md

What the pages say:
- Policy: "Unless safety or compliance concerns require a faster timeline, we provide the following minimum notice periods
  before model retirement: Generally available models: At least 6 months."
- Neither Luna model appears under "Upcoming deprecations".
  - `gpt-6-luna` is the listed replacement for these retiring models:
    - `gpt-5-nano` (shutdown 11 Dec 2026)
    - GPT-4o, GPT-4o mini, GPT-4.1 and GPT-4.1 mini (shutdown 14 Jan 2027)
    - `gpt-5.4-nano` (shutdown 1 Apr 2027)
  - `gpt-5.6-luna` appears once, as the listed replacement for `gpt-4.1-nano`, which shut down on 23 Oct 2026.
- Each model page lists one snapshot, the bare name (`gpt-6-luna`, `gpt-5.6-luna`). So no dated pin exists; log the
  served model name on every call.

The OpenAI notice rule was not in the 17 or 23 Nov notes. It gives far more cover than Anthropic's: any notice posted now
would still leave the Luna pair until about late May 2027.

## 4. Open-weight models: do the pinned hosts still serve them?

Sources, read 24 Nov 2026:
- OpenRouter endpoint lists: https://openrouter.ai/api/v1/models/qwen/qwen3.5-27b/endpoints, and the same address for
  `qwen/qwen3.8-27b`, `google/gemma-3-27b-it` and `google/gemma-4-31b-it`
- DeepInfra model list: https://api.deepinfra.com/models/list
- DeepInfra docs: https://docs.deepinfra.com/models

| Model | Pinned host (config) | Served today? | Notes |
|---|---|---|---|
| Qwen3.5-27B | DeepInfra fp8 | yes: `deepinfra/fp8` status 0, uptime 100 % (last 30 min) | DeepInfra's own list: `deprecated: null`. Also flex and priority endpoints exist (see extension_pairs.md, section 4) |
| Qwen3.8-27B | DeepInfra fp8 | yes: `deepinfra/fp8` status 0, uptime 100 % | `deprecated: null`; 25 % discount, no end date |
| Gemma 3 27B | Parasail fp8 | yes: `parasail/fp8` status 0, uptime 100 % | Legacy on Amazon Bedrock (end 30 Mar 2027). That is not our host |
| Gemma 4 31B | Parasail fp8 | yes: `parasail/fp8` status 0, uptime 100 % | – |

**Risk new to this check:** DeepInfra forwards the calls of a deprecated model to another model.
- The docs say: "You'll receive at least 1 week's advance notice before the deprecation date" and "after deprecation,
  inference requests are automatically forwarded to a recommended replacement model." They add: "Your applications won't
  break."
- So a deprecated Qwen3.5-27B would keep answering, but as a different model.
- DeepInfra has already done this for:
  - Llama 3.1 70B (3 Nov 2026)
  - Nemotron 3 Nano (8 Oct 2026)
  - Gemma 2 27B (1 Apr 2025)
  - Kimi K2 (7 Sep 2026)
- Guard: on every open-weight call, compare the served model and OpenRouter's `provider_name` and `upstream_id` with the
  request. Stop on any mismatch.

Amazon Bedrock is not on our route, but its page shows how fast hosts drop older open models. On 30 Sep 2026 it moved
many of them to Legacy, with end of life on 30 Mar 2027:
- Llama 3.1 70B and Llama 3.3 70B
- DeepSeek-V3.1
- Gemma 3 27B
- GLM 4.7

It also says: "New customers can't use Legacy models." Source:
https://docs.aws.amazon.com/bedrock/latest/userguide/model-lifecycle-legacy.html (read 24 Nov 2026).

## 5. Gaps

- Parasail's own deprecation policy was searched for and not found.
- Whether OpenRouter delists a model that DeepInfra deprecates, or passes the forwarded answer through, is not documented
  on the pages read.
