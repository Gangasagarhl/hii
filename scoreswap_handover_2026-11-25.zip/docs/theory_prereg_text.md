# Text for the pre-registration: the law of score transfer

Drafted 23 Nov 2026 by the theory worker, for the research manager to place (suggested: a new
section 8.4 "The transfer law (secondary, its own Holm family)", plus one line in Part 0.3 for the
new constants). Nothing below changes the four primary comparisons. Theory and proofs:
`docs/theory_note.md`; code: `msr/theory.py` (`python -m msr.theory --study <study>`), which writes
`runs/<study>/analysis/law_pairs.csv` and `law_summary.csv`. The code was run end to end on the
simulated study before the freeze.

---

## 8.4 The transfer law (secondary; its own Holm family "T")

### 8.4.1 Estimands

For owner s, reader t ≠ s, family f, stream b (and level "all": every sum below taken over both
streams), over the evaluation tasks of the three orders. A task enters only if the missing-cell
rule (1.6) keeps it in both the home cell (s, s) and the swap cell (s → t). For a candidate pair
i < j of a task, Δx = x(i) − x(j), sgn = sign of Δx with 0 when |Δx| ≤ 1e−12, and Δȳ_m is the
difference of model m's mean results over repeats 1–2 (the owner's own home results for m = s,
the reader's for m = t).

- Signed validity: V_home = Σ sgn·Δȳ_s, V_swap = Σ sgn·Δȳ_t.
- Outcome spread: W_home = Σ |Δȳ_s|, W_swap = Σ |Δȳ_t| (so Cw = 1/2 + V/(2W) exactly).
- Noise-free retained ratio: R_V = V_swap / V_home.
- Unbiased squared difference per pair and model: d̂² = U_i + U_j − 2 ȳ_i ȳ_j, with
  U = ȳ² − S²/n for a cell with n ≥ 2 valid repeats (S² the sample variance of its repeats).
- Transfer slope (score-free): γ̂ = Σ Δȳ_s Δȳ_t / Σ d̂²_s over pairs where both owner cells have
  2 valid repeats and both reader cells at least 1.
- Cross-model correlation: ρ̂ = Σ Δȳ_s Δȳ_t / sqrt(Σ d̂²_s Σ d̂²_t) over pairs with 2 valid repeats
  on both sides; standardised retained ratio R_std = R_V · sqrt(Σ d̂²_s / Σ d̂²_t) (same pairs).
- Prediction (no fitted parameter): Ĉ_swap = 1/2 + γ̂ V_home / (2 W_swap).
- Gap: G = C_swap − Ĉ_swap.
- Outcome-spread ratio: (W_home / pairs) / (W_swap / pairs).

Rules: R_V is reported only if V_home ≥ 4 task-bootstrap SEs; γ̂ only if Σ d̂²_s ≥ 4 SEs (else
"undefined: old-model outcome variance too weak"). With fewer than 2 repeats of the owner, γ is
not estimable and the law is not tested for that pair.

### 8.4.2 Intervals

- Task bootstrap exactly as in 4.1 (the same count matrices, 10,000 draws, percentile intervals).
- **Primary for the law:** the two-way linearised variance in which pairs that share a task or
  share an item are dependent (V_task + V_item − V_both; items coded per bank, i.e. per owner,
  stream and order), normal 95% intervals and two-sided p-values. Reason: the law is a statement
  about the population of items; with a finite bank the score's noise lines up with the reader's
  own item effects by chance, which a task bootstrap cannot see (theory note, Remark 2b).
- Across pairs, the mean of a statistic over swaps uses the same two-way variance on the stacked
  influence values (rows share tasks; rows of one owner share items).

### 8.4.3 Tests (family T, Holm at 0.05 over the tests listed here)

Headline family, level "all".

- **T1 (the law, per swap stratum a, b, c): mean gap Ḡ(g) over the stratum's swaps.**
  - "Law supported in stratum g": the TOST equivalence test with margin 0.02 (Cw units) rejects,
    i.e. the 90% two-way interval of Ḡ(g) lies inside (−0.02, 0.02), **and** the law's mean absolute
    error over the stratum's swaps is below that of "no change" (Ĉ_swap = C_home).
  - "Law fails in stratum g": the two-sided test of Ḡ(g) = 0 rejects after Holm **and** |Ḡ(g)| ≥ 0.02.
    Ḡ < 0 is read as "the old scores' signal sits in what transfers worse than average (for example
    the owner's own quirks)"; Ḡ > 0 as "the old scores carry information about the new model beyond
    the owner's results". These readings are fixed now.
  - Otherwise "inconclusive".
  - Three tests (one per stratum).
- **T2 (family invariance, all 56 swaps): for each of `beta_grade`, `tags_self`, `credit`, the pooled
  R_V (Σ V_swap / Σ V_home over the swaps) minus that of the headline family.** The law predicts 0
  for every family. Two-sided, two-way variance. A rejection is "family-specific leakage". Three
  tests. (P3 is unchanged and still tested; under the law it expects no difference.)

### 8.4.4 Reported, not tested

- Per swap: G with both intervals, γ̂, ρ̂, R, R_V, R_std, the spread ratio, and whether the two-way
  interval of G contains 0; the share of swaps whose interval excludes 0 (about 5% expected under
  the law; the swaps are dependent, so this share is descriptive).
- The law's mean absolute error against three reference predictions: no change; R = γ̂ (spreads
  ignored); R = ρ̂.
- The OLS line of C_swap − 1/2 on Ĉ_swap − 1/2 over swaps (slope, intercept, R²), labelled
  "attenuated by noise in the prediction".
- A model-label permutation test of the law's specificity: statistic = mean absolute error, over
  all 8! relabellings of the models (p = share of relabellings with an error at most the observed).
- Leave-one-model-out: the mean gap and the mean absolute error without each model's 14 swaps.
- The noise dials: R, R_V and the spread ratio recomputed with the reader (or the owner) cut to its
  first repeat. The law predicts that R moves with the spread ratio and R_V does not.
- Sensitivity: γ̂ with all four home repeats of the owner (repeats 1–4), reported only if the
  self-swap drop of that owner is inside its noise floor (4.4).

### 8.4.5 Exploratory (labelled as such)

- The Gaussian corollary (unweighted C = 1/2 + arcsin(r)/π with attenuated r) and its error.
- The home ceilings: 1/2 + sqrt(mean d̂²)/(2 · mean |Δȳ|) (an upper bound) and its Gaussian version.
- The break-even number of fresh checks k* = c ρ̂² n / (c + (1 − ρ̂²) n), with c estimated from the
  owner's `beta_grade` counts; illustrative, not a decision rule.

### 8.4.6 New design constants (for Part 0.3)

| Constant | Value |
|---|---|
| Equivalence margin of the law (T1) | 0.02 in Cw |
| Repeats used by γ̂ (primary) | owner 1–2, reader 1–2; sensitivity owner 1–4 at home |
| Intervals for the law | two-way (task and item) linearised variance, normal 95%; task bootstrap reported beside it |
| Definedness rule for R_V and γ̂ | denominator ≥ 4 task-bootstrap SEs (as 2.4) |
| Holm family T | T1 (3 strata) + T2 (3 families) = 6 tests at 0.05 |

Why these values: at the main study's size per pair (2,400 tasks, about 1,500 items over the six
banks, 2 repeats), the simulated SD of the gap is about 0.010–0.013 Cw per swap, so a stratum mean
over 4 swaps has an SE below about 0.007 when the swaps' errors are independent, and 0.02 is about
three SEs; leaks of 0.07–0.08 Cw were detected in every simulated world (theory note, Result 3).
The margin is a design choice, not a measured quantity, and is stated here before any main-study
data exist.

---

## Open points for the manager (not part of the text above)

1. Placement: secondary family T as drafted, or exploratory throughout. The drafted version keeps
   the 12 primary tests untouched.
2. P1 uses Cohen's κ on outcomes, which mixes shared task difficulty with item usefulness. The law
   says the matching agreement measure is ρ̂ (within-task, noise-corrected), with the exact
   prediction R_std = ρ. Adding "P1′: R_std against ρ̂, identity line" as a secondary check is
   suggested; P1 itself should not change after the freeze.
3. The stratum mean in T1 is over only 4 swaps in strata a and b, which share models; the two-way
   variance handles shared tasks and items but not model-level dependence. The model-label
   permutation and leave-one-model-out rows are the check on that.
