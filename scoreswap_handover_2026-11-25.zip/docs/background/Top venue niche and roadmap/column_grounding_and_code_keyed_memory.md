# Two candidate niches checked against the literature on 15 November 2026: (A) sourced column meanings for very wide machine exports, (B) agent memory whose key is computed by code and not by the model

How to read these notes.

- These notes extend four earlier files and do not repeat them: `wide_table_grounding_literature.md` (12 November), `agent_memory_feedback_literature.md` (12 November), `red_team_objections_and_idea_ranking.md` and `novelty_recheck_november_2026.md` (both 15 November). Where an earlier file already holds a fact, this file only points to it.
- "Full text" means I downloaded the arXiv HTML on 15 November 2026 and searched the whole text. "Abstract only" means the arXiv or OpenReview abstract was read. OpenReview forum pages returned HTTP 403; only the OpenReview search endpoint worked, so no review or paper body of an ICLR 2027 submission was read.
- Venue labels: "peer-reviewed" is used only when the arXiv comment field or an official page names an accepted venue. Everything else is a preprint.
- Two different papers are called "Rosetta". "Rosetta Memory" (arXiv 2606.07711) is about agent memory across models. Helwig's "Rosetta" system (arXiv 2608.07946) is about column meanings. They are unrelated.
- Numbers copied from HTML tables should be checked against the PDF before they are printed.

## A1. Column typing, column meaning and schema matching with language models: what accuracy is reached on cryptic headers, domain tables and very wide tables, and which benchmarks exist?

### Takeaway
The earlier file already has the main numbers (near-solved on web tables, 0.07 to 0.34 F1 on SAP tables, no public typing benchmark wider than 193 columns). What it missed is a group of 2026 preprints that work on exactly the "cryptic names, no documentation" case with free-text meanings, and they agree on one result: without readable names a strong model is right on roughly a quarter of columns, and downstream query accuracy falls by about half or more.

### Cited Findings

#### New since the 12 November file: free-text meanings for undocumented columns
- Helwig, "Metadata Reconstruction from Values Alone: Recovering Column Semantics in Undocumented Warehouses" (arXiv, 8 August 2026; single author; preprint, no venue). Full text read. The system puts a model inside a harness: a code profiler computes value fingerprints and a 26-pattern library, the model proposes a meaning, and "every fact carries provenance and a confidence bounded by its evidence class". — [arXiv 2608.07946](https://arxiv.org/abs/2608.07946)
- Its headline numbers: on 680 paired columns from eleven BIRD databases with identifiers destroyed, the harness is "0.475 accurate on the 42% of columns it commits to, against 0.223 on 94% for the same model used directly". On the 283 columns where both arms answer, the harness writes no better text than the plain model; "the gain is selection". — [arXiv 2608.07946](https://arxiv.org/abs/2608.07946)
- Its downstream measure is query correctness, not text overlap: "under full schema opacity a naive translator falls from 0.92 to 0.42 execution accuracy while our gate answers at 86% accuracy over 59% coverage" (Spider, 11 databases, 1,082 questions). — [arXiv 2608.07946](https://arxiv.org/abs/2608.07946)
- It validates its text metric: 180 blinded judgements track the token metric at Spearman 0.642, and a second rater from another model family agrees with the judge at kappa 0.737. — [arXiv 2608.07946](https://arxiv.org/html/2608.07946)
- TACO, "Task-Aware Column Description Generation Using LLMs" (arXiv, 19 June 2026; preprint, no venue). Full text searched. Three steps: abbreviation expansion, description generation, revision "using simulated downstream tasks". It uses names only, no values ("we restrict our inputs to metadata"). It reports "improving downstream entity linking performance by up to 52%" and has a human-in-the-loop step that asks a person about low-confidence expansions and spreads the answer. — [arXiv 2606.21685](https://arxiv.org/abs/2606.21685)
- DBAutoDoc (arXiv, 24 March 2026; preprint). Abstract and method read. It documents undocumented databases where "column names are cryptic abbreviations" by passing descriptions through the schema graph over several rounds. Its 96.1% score is a composite that weights key discovery (65%) above descriptions (35%); column descriptions count for 15% and are scored on coverage. A code pipeline adds 23 F1 points over model-only foreign-key detection. — [arXiv 2603.23050](https://arxiv.org/abs/2603.23050)
- Glyph (arXiv, 9 September 2026; preprint; a production system). Full text searched. Column descriptions are grounded "in the pipeline source code that produces each column", retrieved from an enterprise GitHub. The catalog has about 3.4 million columns in about 98,000 tables. Every tag carries "per-tag provenance" (source, score, reasoning). Weekly steward acceptance of its tags "rises from 63.3%" to 99.8% over six weeks (figure text). — [arXiv 2609.10430](https://arxiv.org/html/2609.10430)
- Polaris (arXiv, 17 August 2026; preprint) trains a model to write table descriptions from retrieval feedback and expands abbreviated names first; it reports beating AutoDDG. — [arXiv 2608.17171](https://arxiv.org/abs/2608.17171)

#### How much opaque names cost, measured downstream
- "Disentangling Structure and Semantics" (arXiv, 17 June 2026; "work in progress"). Full text searched. A 6 by 3 design on 397 BIRD questions with anonymous, abbreviated and descriptive identifiers, nine models. For Qwen2.5-Coder-14B a single wide denormalised table "collapses to 0.0%" execution accuracy with anonymous names and reaches 19 to 21% with abbreviated or descriptive names. Almost all of the gain is the step from anonymous to abbreviated (+42.3 of +43.0 points on simple questions); abbreviated to descriptive adds little. — [arXiv 2608.20356](https://arxiv.org/html/2608.20356)
- The same paper: descriptive names on a flat wide table beat a fully normalised schema with opaque names on every model (+18.2 points on Gemini 2.5 Flash, +10.6 on Qwen-14B). — [arXiv 2608.20356](https://arxiv.org/html/2608.20356)
- SAP result already recorded: column typing F1 0.07 to 0.34 with names and 0.02 to 0.05 without; chunking a wide table into 10 to 50 columns helps. See the earlier file. — [Bodensohn et al., PVLDB 19(2)](https://www.vldb.org/pvldb/vol19/p196-bodensohn.pdf)

#### Closed-list typing and matching: 2026 additions and venue updates
- StraTyper (arXiv, 3 February 2026; preprint) drops the fixed label list: the model discovers types and allows several types per column. It notes that proprietary models "produce inconsistent outputs across similar columns". — [arXiv 2602.04004](https://arxiv.org/abs/2602.04004)
- LakeHopper (arXiv, 9 February 2026; preprint) adapts a trained annotator from one data lake to another, because annotators "degrade sharply once deployed on a new" lake. — [arXiv 2602.08793](https://arxiv.org/abs/2602.08793)
- SymCA (arXiv, 28 July 2026; preprint) turns column annotation into a symbolic decision tree built by a model. — [arXiv 2607.25228](https://arxiv.org/abs/2607.25228)
- A header-only framework maps headers to 39 types with curated word lists and "token-level traceability", evaluated on about 120,000 headers (Workshop on Quality of Knowledge Graphs at ESWC 2026, by arXiv comment). — [arXiv 2610.10541](https://arxiv.org/abs/2610.10541)
- SemStruct is "Accepted to KDD 26 Research Track": frozen language model plus a small graph network for schema matching on Valentine and SOTAB-SM. — [arXiv 2605.30729](https://arxiv.org/abs/2605.30729)
- ConStruM, listed in the earlier file as a January 2026 preprint, is now "Accepted for publication in PACMMOD (SIGMOD 2027)". — [arXiv 2601.20482](https://arxiv.org/abs/2601.20482)
- Columbo, listed earlier as arXiv only, is "Accepted to Findings of EMNLP 2025". — [arXiv 2508.09403](https://arxiv.org/abs/2508.09403)
- MaDI-Bench (Mannheim; arXiv, 29 June 2026; preprint) is an end-to-end data integration benchmark that includes schema matching as one step. — [arXiv 2606.30371](https://arxiv.org/abs/2606.30371)
- TabEmb is in the ACL 2026 main proceedings. — [ACL Anthology](https://aclanthology.org/2026.acl-long.757.pdf)

#### Width
- Glyph's catalog is large in total but the paper does not report accuracy by table width. — [arXiv 2609.10430](https://arxiv.org/html/2609.10430)
- BudgetSchemaBench (arXiv, 8 September 2026; preprint) pools 80 databases and sweeps how much schema text fits a budget; raising the budget from 2.5% to 50% of the catalog improves execution accuracy on 1,279 questions by 18 points under lexical retrieval. It is about SQL, not about meanings. — [arXiv 2610.00092](https://arxiv.org/abs/2610.00092)
- OmniTable is a wide-table storage system ("VLDB 2026 Best Industry Paper" by arXiv comment); title and comment only, it is not about column meaning. — [arXiv 2609.11148](https://arxiv.org/abs/2609.11148)

### Inferences
- The owner's design is no longer alone. Helwig's preprint already combines five of the owner's parts: a code profiler, a model that only proposes, a source and evidence class on every meaning, a human acceptance step as the top evidence class, and a downstream correctness measure. It also swaps the backbone. A reviewer in data management will know or find it.
- What these papers measure is text overlap with human documentation, steward acceptance, entity linking, or SQL execution accuracy. None measures the correctness of analysis rules written on the columns.
- None uses a single table wider than BIRD or SAP tables. The owner's 113 to 1,598 column exports remain outside every benchmark found (the width table is in the earlier file).
- "Abbreviated is almost as good as descriptive, anonymous is a collapse" (the June 2026 factorial) matters for the owner: vendor headers are abbreviated, not anonymous, so a plain model may already do most of the work on many columns. The hard residue will be vendor-only terms, as the earlier file inferred from the building-sensor results.

### Gaps
- No accuracy figure was found for any model on protocol-analyzer, instrument or telemetry export headers. Search terms are listed under A2.
- Glyph's, TACO's and Polaris's result tables were not read in full; only abstracts and the lines quoted.
- Venues for Helwig, TACO, DBAutoDoc and Glyph are unknown; all are preprints on 15 November 2026.
- The earlier file's list of unverified venues (Sherlock, Sato, Doduo, TURL, TaBERT) was not re-checked here.

## A2. Is there work on citable sources for column meanings, abbreviation expansion, schema drift between exports, reuse keyed by a header fingerprint, or instrument, telemetry, vehicle-bus and network-capture columns?

### Takeaway
Sources attached to each meaning now exist in three 2026 preprints (evidence class, verbatim span, or source code), but none scores whether a quoted manual passage supports the meaning, and none had real documentation to cite in its main test. Nothing was found on reuse keyed by a header fingerprint, on column-set drift between exports of one tool, or on protocol-analyzer columns.

### Cited Findings

#### Sources and provenance on column meanings
- Helwig's ladder has eight evidence classes with confidence caps. Two are documentation classes: "DOC_CITED_WEAK" (cap 0.70, "a 0.30–0.80 documentation snippet was cited, graded only 'related'") and "DOC_CITED_STRONG" (cap 0.90, "a ≥0.80 snippet directly asserts the meaning"). Above them sit "QUERY_VALIDATED" ("≥3 downstream queries accepted the column with no rejections") and "SME_AFFIRMED" (cap 1.00, "a human reviewer explicitly accepted the value"). — [arXiv 2608.07946](https://arxiv.org/html/2608.07946)
- In that paper's main study the documentation classes were not exercised by real retrieval: BIRD columns were stripped of names and documents, and the "oracle-documented condition" overlays the true description on every column as "an upper bound, clearly labeled, because it injects the true semantics rather than inferring them". Coverage and accuracy rise from cold (0.51, 0.82) through human-affirmed (0.59, 0.86) to oracle-documented (0.68, 0.89). — [arXiv 2608.07946](https://arxiv.org/html/2608.07946)
- BatteryLake (arXiv, 6 July 2026; preprint). Abstract and method read. Agents extract dataset metadata, "grounding every output in verbatim evidence and abstaining when none supports a value"; human review is framed as selective prediction; admitted data pass 26 schema, statistical and physical rules; 41 public battery datasets. Each extracted field stores an evidence span, its source index and a confidence. — [arXiv 2607.09762](https://arxiv.org/abs/2607.09762)
- A pharmaceutical industry preprint (23 October 2026) extracts study metadata from legacy reports and returns "verbatim evidence with page and section reference"; over 400 documents; review time fell from 25 minutes to 1.6 minutes. It extracts fields from reports, not meanings of table columns. — [arXiv 2610.32616](https://arxiv.org/abs/2610.32616)
- Glyph grounds descriptions in producing source code and keeps provenance per tag. — [arXiv 2609.10430](https://arxiv.org/html/2609.10430)
- Citation scoring for question answering (ALCE) and the finding that models ignore supplied documentation on SAP data are in the earlier file. — [ALCE](https://arxiv.org/pdf/2305.14627.pdf); [Bodensohn et al.](https://www.vldb.org/pvldb/vol19/p196-bodensohn.pdf)

#### A model-made decision does not survive a backbone change; a code-made one does (from the column-meaning literature)
- Helwig re-ran the study on a second backbone. The text quality result reproduced, but "prompt-requested abstention does not transfer": the harness's coverage "nearly doubles, from 0.422 to 0.823", and the evidence-tracking gap goes from +0.257 to −0.089. — [arXiv 2608.07946](https://arxiv.org/html/2608.07946)
- The fix was to "move the decision into code, refusing to commit a prose claim whose grounding tier is INTERPRETER_ONLY, instead of asking for that judgement in a prompt", with six predictions registered first. With the gate off, 44 drug codes "draw 0 attempts from Gemini, 25 from Haiku, and 43 from Sonnet"; with the gate on, "all three attempt 0 of 44". — [arXiv 2608.07946](https://arxiv.org/html/2608.07946)
- The same paper measured run-to-run stability with the cache bypassed: "Only 38.5% of predictions come back byte-identical", yet the speak-or-abstain decision moved on one column in ninety-six. — [arXiv 2608.07946](https://arxiv.org/html/2608.07946)

#### Reuse and caching
- Helwig's system caches every model call "keyed on sha256(prompt + model + prompt version + schema)". This is a call cache with the model in the key, not reuse of approved meanings when a file with the same header set returns. — [arXiv 2608.07946](https://arxiv.org/html/2608.07946)
- TACO spreads a human-corrected abbreviation expansion to other columns in the dataset. — [arXiv 2606.21685](https://arxiv.org/abs/2606.21685)
- An arXiv abstract search for "schema fingerprint", "header fingerprint", "schema hash" or "schema signature" together with language-model, cache or reuse terms returned zero results on 15 November 2026. — [arXiv API](https://export.arxiv.org/api/query)

#### Schema drift
- EvoSchema ("Accepted by VLDB 2025" by arXiv comment) is a benchmark of ten kinds of column-level and table-level schema change for text-to-SQL; table-level changes hurt most. It concerns database schema evolution, not column sets that differ between exports. — [arXiv 2603.10697](https://arxiv.org/abs/2603.10697)
- WarehouseReliabilityBench (arXiv, 10 August 2026; preprint) has 400 tasks that include "deprecated columns after a schema change"; a 7B agent with "rules derived from a semantic layer and physical catalog" and code checks after execution beats a directly prompted 32B model by +0.237 on its Business Truth Rate. Two synthetic warehouses. — [arXiv 2608.09254](https://arxiv.org/abs/2608.09254)

#### Rules and checks written on columns
- PrismaDV ("Accepted as a demo paper at CIKM 2026") writes data unit tests from the data and from the downstream task code, and links each generated constraint back to the code. — [arXiv 2608.09376](https://arxiv.org/abs/2608.09376)
- The header-only framework above activates validation rules from the assigned type (missing data, duplicates, domain violations). — [arXiv 2610.10541](https://arxiv.org/abs/2610.10541)

#### Machine data: captures, telemetry, vehicle bus
- PROBE (arXiv, 5 June 2026; preprint) diagnoses 802.11 packet captures with "deterministic PCAP-to-text normalization with frame-level verifiability" and a code-computed reliability score "without LLM self-assessment". On 87 enterprise captures, single-pass model analysis misses critical frames in 35% of cases. It diagnoses captures; it does not assign meanings to export columns. — [arXiv 2606.06871](https://arxiv.org/abs/2606.06871)
- HYVE (arXiv, 7 April 2026; preprint) reshapes logs, metrics and traces into column and row views for a model. UModel (arXiv, 3 June 2026; preprint) builds an ontology layer over observability data and reports +8% root-cause precision on the AIOps 2025 Challenge data. Neither infers the meaning of unknown columns. — [arXiv 2604.05400](https://arxiv.org/abs/2604.05400); [arXiv 2606.04799](https://arxiv.org/abs/2606.04799)
- Vehicle bus: ByCAN (IEEE Internet of Things Journal by arXiv comment, 2024) reverse-engineers CAN messages by clustering and template matching with no language model; a search summary gives 80.21% slicing accuracy and 68.72% labeling accuracy (not checked in the paper). The only language-model example found is a vendor blog post. — [arXiv 2408.09265](https://arxiv.org/abs/2408.09265); [CSS Electronics blog](https://www.csselectronics.com/pages/can-bus-reverse-engineering-ai-llm-claude)
- Earlier neighbours (building-sensor names, clinical variables, the automotive test case, the CAN question-answering paper) are in the earlier file. — [Brick-DICL](https://arxiv.org/html/2606.17637)

### Inferences
- "Attach a source to every meaning and let a person approve" is now published as a design (Helwig, BatteryLake, Glyph). It cannot be the claimed novelty.
- Still not found: (a) a score for whether the quoted passage supports the meaning (citation precision and recall on column meanings); (b) real manuals as the source, with page and quote, on a domain where the manual is a public standard; (c) reuse of approved meanings keyed by a header fingerprint with a measured false-reuse rate; (d) column-set drift between exports and tools; (e) rule correctness as the outcome.
- Helwig's backbone result is a warning for the owner's Grounder too: anything the Grounder asks the model to decide (for example "say so if the manual does not cover this column") may change with the model. The quote check should be code: the quoted string must occur on the cited page.

### Gaps
- Not found, with search terms used on arXiv abstracts: ("protocol analyzer" or "packet capture" or pcap or NVMe or PCIe) with language-model and column, field, schema or trace terms (7 results, none on column meaning); (OpenTelemetry or DICOM or "semantic conventions") with language-model and mapping terms (2 results, both unrelated); ("CAN bus" or "CAN signals" or DBC) with language-model and signal terms (7 results, none on signal naming); (telemetry or "sensor metadata" or "point names" or "tag names") with language-model and schema terms from July 2025 on (12 results, none on naming columns); ("machine-generated" or instrument or "log files" or sensor) with column, meaning and header terms (0 results).
- Not found: any paper that scores citation support for generated column meanings (terms: column with provenance, citation, "evidence span" or verbatim and description, semantics or metadata; 4 results, only Glyph relevant).
- Google Scholar, the ACM Digital Library and IEEE Xplore were not searched directly; a workshop or industry paper outside arXiv could exist.

## A3. Which venues and tracks publish this, and is "sourced column meanings on machine-generated wide tables, measured by the correctness of rules written on them" an open gap?

### Takeaway
Partly open. The parts (sources, human approval, downstream measurement, backbone swap) are each published as preprints in 2026; the combination on very wide machine exports with rule correctness as the outcome was not found. It is an evaluation contribution that fits data-management venues and tabular workshops; no evidence was found that SIGIR, ICML or NeurIPS main tracks publish this topic.

### Cited Findings
- Data-management venues carry the topic in 2025 to 2027: PVLDB (SAP study, ArcheType, Magneto), SIGMOD 2026 (REVEAL), SIGMOD 2027 (ConStruM), ICDE 2026 (ZTab), VLDB 2025 (EvoSchema). — [Bodensohn et al.](https://www.vldb.org/pvldb/vol19/p196-bodensohn.pdf); [REVEAL](https://arxiv.org/abs/2508.17203); [ConStruM](https://arxiv.org/abs/2601.20482); [EvoSchema](https://arxiv.org/abs/2603.10697)
- KDD: SemStruct in the KDD 2026 Research Track (schema matching). — [arXiv 2605.30729](https://arxiv.org/abs/2605.30729)
- Language venues: Columbo in Findings of EMNLP 2025; TabEmb at ACL 2026. — [arXiv 2508.09403](https://arxiv.org/abs/2508.09403); [ACL Anthology](https://aclanthology.org/2026.acl-long.757.pdf)
- CIKM 2026 took a demo paper on data unit tests (PrismaDV). — [arXiv 2608.09376](https://arxiv.org/abs/2608.09376)
- Workshops: TaDA 2026 at VLDB lists semantic table annotation among its topics (submission 18 May 2026, notification 15 June 2026). The Table Representation Learning workshop accepted 24 of 30 at ACL 2025. — [TaDA 2026](https://tabular-data-analysis.github.io/tada2026); [TRL at ACL 2025](https://table-representation-learning.github.io/ACL2025)
- VLDB 2027 monthly deadlines up to 1 March 2027 are in the earlier file. — [VLDB 2027 dates](https://vldb.org/2027/important-dates.html)
- A web search for SIGIR 2026 papers on column annotation or schema matching found none confirmed at SIGIR; the hits were arXiv preprints and the ACL paper. — [RACT preprint, cs.IR subject](https://arxiv.deeppaper.ai/papers/2606.07843v1)

### Inferences
- Verdict for (A): partly addressed, with a real but narrow remainder. Closest work and what each leaves out:
  - Helwig (preprint, August 2026): has evidence classes, human acceptance, SQL execution accuracy, backbone swap, registered predictions. Leaves out real documentation retrieval, quote-support scoring, wide tables, machine exports, reuse across files, rules.
  - Bodensohn et al. (PVLDB 2025, peer-reviewed): has width and chunk-size curves on SAP tables for closed-list typing. Leaves out free-text meanings, sources, downstream outcome.
  - TACO (preprint, June 2026): has task-aware descriptions and a downstream measure (entity linking). Leaves out values, sources, width, rules.
- Sharpest open question for (A): "On very wide machine exports whose columns are defined in a written standard or manual, how much does a code-verified source quote on each column meaning reduce errors in the analysis rules later written on those columns, compared with unsourced model meanings, and what does it cost in coverage and human approvals?"
- Smallest credible experiment for (A), one person, four weeks:
  1. Data: the owner's synthetic exports with known column truth and injected defects, at least two tool families so that column sets differ; a public second leg using Helwig's protocol (BIRD with identifiers destroyed, 680 paired columns) so that numbers can be compared with a published baseline.
  2. Arms: raw headers only; model meanings from values; model meanings with manual text in the prompt; the same with a code check that the quoted string occurs on the cited page, abstaining otherwise; oracle meanings as the upper bound.
  3. Outcomes: meaning accuracy against truth; quote support (precision and recall in the ALCE sense, scored by code plus a human-checked sample); rule correctness, meaning the share of a fixed set of 30 to 50 rule requests whose generated rule fires on the injected defects and not elsewhere; false-reuse rate when a stored meaning is reused on a file with the same header fingerprint but a different tool or decode level; rule survival when columns are renamed, dropped or added.
  4. Three frozen models, paired bootstrap intervals over files, columns per call as one figure.
- Venue fit (judgement): PVLDB experiment-and-analysis paper or TaDA at VLDB 2027 are realistic; KDD applied track is plausible only with real data; SIGIR, ICML and NeurIPS main tracks would not value it as stated. This matches the earlier file's verdict and does not improve it.
- The link to niche (B) is real and usable: Helwig's "decision in code survives the backbone, decision in the prompt does not" is the same principle as code-computed keys, shown on a different object.

### Gaps
- KDD 2027, SIGIR 2027 and TRL 2027 calls and deadlines were not looked up.
- Whether the PCI Express and NVMe specification text may be quoted in a public dataset is unknown (also flagged in the earlier file).
- No count exists of how many of the owner's columns have a checkable passage in a manual; the experiment depends on it.

## B1. How do published agent-memory systems compute the key or index of a memory item: by the model or by fixed code?

### Takeaway
Almost every well-known system lets a model make the key: the language model writes the text that is indexed (summary, description, intent, title, label), an embedding model turns it into a vector, and often the language model also writes the retrieval query. Keys fixed by code or schema exist in a few 2026 systems (a fixed-schema graph, content hashes, typed stores, model-free read paths), but only one of those was tested across a model change, and none of them carries experience scores.

### Cited Findings

#### Key made by the language model (the model writes what is indexed, or chooses the label, or writes the query)
- Voyager: "The key is the embedding vector of the program description (generated by GPT-3.5), while the value is the program itself"; retrieval uses "the embedding of self-generated task plans and environment feedback". Full text. — [arXiv 2305.16291](https://arxiv.org/abs/2305.16291)
- Generative Agents: retrieval score combines recency, relevance (embedding) and importance, where importance comes from "directly asking the language model to output an integer score", fixed "at the time the memory object is created". Full text. — [arXiv 2304.03442](https://arxiv.org/abs/2304.03442)
- MemGPT (Letta): "MemGPT provides function calls that the LLM processor to manage its own memory"; the model decides what to move to archival storage and issues the searches. Full text. — [arXiv 2310.08560](https://arxiv.org/abs/2310.08560)
- Mem0: an extraction phase where the model creates candidate facts, then "retrieves the top s semantically similar memories using vector embeddings" and lets the model choose an operation through a tool call. The graph variant "uses LLMs to convert conversation messages into entities and relation triplets". Full text. — [arXiv 2504.19413](https://arxiv.org/abs/2504.19413)
- A-MEM: for each memory the model writes notes with "structured textual attributes" and "embedding vectors for similarity matching", with "autonomous generation of contextual descriptions" and model-made links. Full text. — [arXiv 2502.12110](https://arxiv.org/abs/2502.12110)
- Zep (Graphiti): the model extracts entities; names are embedded "into a 1024-dimensional vector space"; candidates "are then processed through an LLM using our entity resolution prompt". The write to the graph uses "predefined Cypher queries. We chose this approach over LLM-generated database queries to ensure consistent schema formats and reduce the potential for hallucinations". So nodes are model-made and the storage statement is code-made. Full text. — [arXiv 2501.13956](https://arxiv.org/abs/2501.13956)
- HippoRAG: a model does open information extraction to build the graph; at query time the system "identifies the key concepts in the query and runs the Personalized PageRank (PPR) algorithm". Nodes and query seeds are model-made; ranking is code. Full text. — [arXiv 2405.14831](https://arxiv.org/abs/2405.14831)
- GraphRAG: entities and relations are extracted by a model and community summaries are written by a model (section titles "Entity and Relationship Extraction Approach", "Graph Communities → Community Summaries"). Section headings only. — [arXiv 2404.16130](https://arxiv.org/abs/2404.16130)
- ReasoningBank: each item has "a title, which serves as a concise identifier", a description and content, all written by the model; retrieval is "embedding-based similarity search". Full text. — [arXiv 2509.25140](https://arxiv.org/abs/2509.25140)
- MemRL: an "Intent-Experience-Utility triplet"; "Candidates are recalled via similarity, then re-ranked using learned Q-values". The Q-value hangs on an item reached through an embedded intent. Full text. — [arXiv 2601.03192](https://arxiv.org/html/2601.03192v2)
- RoMeRL: utility is "combined with semantic similarity" from an embedding encoder. Full text searched. — [arXiv 2608.02508](https://arxiv.org/abs/2608.02508)
- CHIME: planning and execution banks, "similarity retrieval and value-based reranking". Full text searched. — [arXiv 2609.02074](https://arxiv.org/abs/2609.02074)
- ACE: a bullet has "a unique identifier and counters tracking how often it was marked helpful or harmful"; "the Generator highlights which bullets were useful or misleading". The bullet text is model-written and the credit is model-assigned; only the merge is "lightweight, non-LLM logic". Full text. — [arXiv 2510.04618](https://arxiv.org/html/2510.04618)
- MemCollab: each entry carries a task category; "a base LLM classifier assigns" the test task a category and subcategory, and retrieval is conditioned on it. This is a model-chosen key from a fixed list. It beat two variants without classification (embedding similarity; the model picks relevant tasks), each tested with one model at a time. Full text. — [arXiv 2603.23234](https://arxiv.org/abs/2603.23234)
- "When Continual Learning Moves to Memory" (preprint, 29 April 2026) models each memory as a key-value pair to separate "the representation of experience from the mechanism used to retrieve it"; one condition uses "key = a when_to_use descriptor generated alongside the insight". All conditions use one backbone (Qwen-Plus), two runs per condition. — [arXiv 2604.27003](https://arxiv.org/html/2604.27003)
- GenMem (ICLR 2027 submission; abstract only) names "addressing invariance" as a problem and gives each memory a "Symbolic Identifier" so that "memory evolution rewrites the payload at a fixed address". The addresses are generated by a trained memory agent, and the invariance is against content edits, not against a model change. — [OpenReview](https://openreview.net/forum?id=fZ8fTtjnGH)

#### Key made by a separate embedding model from raw input (no language model in the key)
- ExpeL: "Faiss vectorstore ... kNN retriever and all-mpnet-base-v2 embedder to obtain top-k successful trajectories that have the maximum inner-product task similarity"; extracted insights are not retrieved at all, the "full list" is concatenated. Full text. — [arXiv 2308.10144](https://arxiv.org/abs/2308.10144)
- Dynamic Cheatsheet (retrieval variant): "We used OpenAI's text-embedding-3-small model to map input queries (raw questions) to embedding vectors"; the cheatsheet itself is curated by the model. Full text. — [arXiv 2504.07952](https://arxiv.org/html/2504.07952)

#### No retrieval key at all
- Agent Workflow Memory "incorporates all induced workflows into the agent memory at inference time"; workflows are grouped by website. Full text. — [arXiv 2409.07429](https://arxiv.org/html/2409.07429v1)
- Rosetta Memory: the reader operator "rewrite[s] the bank into a prompt-ready context"; there is no index. Full text. — [arXiv 2606.07711](https://arxiv.org/html/2606.07711)
- RPMem: memory is a latent state decoded into LoRA weights; there is no text key. Full text. — [arXiv 2609.23466](https://arxiv.org/html/2609.23466)

#### Key or read path fixed by code or schema
- Goyal and Ray, KG-fixed format: "The schema fixes the keys, relation names, source fields, and reading rules; the model fills in only the values. We created this schema directly from the workload's event fields". Full text. — [arXiv 2609.05339](https://arxiv.org/html/2609.05339)
- Portable Agent Memory: "The id field is the BLAKE3 hash of the entry's canonical JSON serialization". This is an integrity identifier. Retrieval relevance still uses "embedding cosine distance" with recency, salience and depth. Full text. — [arXiv 2605.11032](https://arxiv.org/html/2605.11032)
- Eywa (preprint, 29 May 2026): "deterministic multi-route retrieval ... without LLM calls on the retrieval path"; it adds that this "does not mean memories were written" without a model. One route is vector similarity. Full text searched. — [arXiv 2605.30771](https://arxiv.org/html/2605.30771)
- MOSS (preprint, 5 July 2026): retrieval "is symbolic and reproducible (once a query is formulated, no LLM participates in the retrieval loop)"; it calls itself "model-agnostic" and reports one year of use by one scholar over "four successive infrastructure generations". The agent still formulates the query, and concept annotations are derived from the corpus. No cross-model measurement. Full text searched. — [arXiv 2607.04391](https://arxiv.org/abs/2607.04391)
- DMF (preprint, 2 June 2026): "a fully deterministic pipeline" for conversational memory, compared with Mem0, with "zero tokens to prepare the memory context". One-model evaluation by its abstract. — [arXiv 2606.03463](https://arxiv.org/abs/2606.03463)
- Memanto (preprint, 23 April 2026): "thirteen predefined memory categories" and "deterministic retrieval"; abstract only, and the abstract does not say who assigns the category. — [arXiv 2604.22085](https://arxiv.org/abs/2604.22085)
- CommitDistill (preprint, 18 May 2026): mines git history into typed units "using deterministic regex" with a TF-IDF retriever, "no embeddings". — [arXiv 2605.18284](https://arxiv.org/abs/2605.18284)
- Reusable issue memory for coding agents (single-author preprint, 30 April 2026) stores a "pattern-variant-episode schema" and turns retrieval evidence into "a fixed 16-feature contextual state"; it warns that "superficial similarity in stack traces, terminal errors, paths, or configuration symptoms can lead to unsafe memory injection". — [arXiv 2604.27283](https://arxiv.org/abs/2604.27283)
- OM-RAG ("accepted at IEEE SMC 2026") indexes resolved issues "as structured symptom-root cause-resolution triples" and retrieves "via single-hop embedding"; 1,172 issues. The structure is typed, the key is an embedding. — [arXiv 2607.21911](https://arxiv.org/abs/2607.21911)
- Case-based reasoning for language-model agents: a 2025 review formulates case retrieval, adaptation and learning; DS-Agent is "Accepted by ICML 2024". Abstracts only; neither abstract states a symbolic, code-computed index. — [arXiv 2504.06943](https://arxiv.org/abs/2504.06943); [arXiv 2402.17453](https://arxiv.org/abs/2402.17453)

### Inferences
- Three kinds of "model in the key" must be kept apart, because they behave differently when the language model is replaced: (1) the language model writes the indexed text or picks the label (Voyager, ReasoningBank, MemRL, A-MEM, Mem0, MemCollab, ACE); (2) only a separate embedding model touches raw input (ExpeL, Dynamic Cheatsheet retrieval); (3) the language model writes the query (Voyager, MemGPT, MOSS). Kind 2 does not change when the language model changes, as long as the embedding model is kept.
- Every scored memory found (MemRL, RoMeRL, CHIME, EvoKernel in the recheck file, ACE counters) hangs its score on a kind-1 item. No system found hangs a learned score on a code-computed key.
- Goyal and Ray's fixed-schema graph is not a pure code key. The schema lists the keys, but the model decides which slot a fact goes into and what the value is. In the owner's terms it is the "model picks from a fixed list" arm, not the "code computes the key" arm.
- Reflexion keeps reflections per task in a buffer and has no learned index; this is from my knowledge of the paper, not re-read here.

### Gaps
- Xia et al. (trainable graph memory) and EvoKernel were not re-read for how keys are made.
- Letta, Mem0 and Graphiti product documentation was not read; classification rests on the papers. Graphiti's custom entity types were not checked.
- Classic case-based reasoning systems with symbolic indices (pre-2020) were not searched; only the two language-model-era items above.
- Search terms that returned nothing relevant on arXiv abstracts: memory with agent and "embedding-free" (0); memory with "LLM", key and "model-written" (0); memory with agent and "who writes" (0); "case-based reasoning" with agent and index terms (0).

## B2. Has anyone measured that memory keyed or embedded by one model degrades when another model reads it, and attributed the loss to the key or retrieval step and not to the content?

### Takeaway
Partly. One preprint (Goyal and Ray) splits migration loss into writing, retrieval and reading, and the embedding-migration literature has firm numbers for vector keys. Nobody found has held the stored content fixed, changed only the language model that writes keys, labels or queries, and measured the change in what is retrieved or in whether stored scores still rank items correctly.

### Cited Findings

#### The three papers named in the task, read in full
- Rosetta Memory (arXiv 2606.07711, 5 June 2026; preprint, "19 pages, 7 figures", no venue in the arXiv record). It trains two small operators (both "initialized from the google/flan-t5-small checkpoint") that rewrite memory at write time and at read time, conditioned on a profile of the model. Tasks: HotpotQA, 2WikiMultihopQA, MuSiQue. — [arXiv 2606.07711](https://arxiv.org/html/2606.07711)
- What Rosetta Memory measured about mismatch: a 7 by 7 writer-reader matrix on 34 examples per dataset; "Under raw memory ... the diagonal/off-diagonal F1 gaps are 13.7 points on HotpotQA and 25.9 points on 2WikiMultihopQA"; with its operators the gaps are "−0.4 and −0.2 points" and average F1 rises "from 29.7 to 57.3" and "from 38.8 to 75.1". It also swaps in up to six unseen models and reports F1 against two baselines. Four seeds, means only. — [arXiv 2606.07711](https://arxiv.org/html/2606.07711)
- What Rosetta Memory did not measure: retrieval or keys (there is no index; the whole bank is rewritten for the reader), scores on memory items, or any task beyond "controlled multi-hop QA episodes"; its limits section says it "does not fully cover open-ended web navigation, tool use, dialogue, or very long-horizon planning". — [arXiv 2606.07711](https://arxiv.org/html/2606.07711)
- RPMem (arXiv 2609.23466, 20 September 2026, v2 22 September; preprint with code). Memory is parametric: each session is compiled into "a model-independent latent memory" and "mapped to backbone-specific low-rank adaptation (LoRA) parameters". — [arXiv 2609.23466](https://arxiv.org/abs/2609.23466)
- What RPMem measured about transfer: it reuses "the frozen Qwen3-8B session encoder with Qwen3-4B, Ministral-3-8B, Qwen3.5-9B, and Qwen3.5-35B-A3B, adapting only the model-specific decoder"; "transfer improves all 28 backbone–setting combinations over compilers trained from scratch and raises the cross-model average from 75.97% to 89.64%". It needs open weights and training of a decoder per target. No text key, no scores. — [arXiv 2609.23466](https://arxiv.org/html/2609.23466)
- Portable Agent Memory (arXiv 2605.11032, 10 May 2026; single author; "8 pages, 28 references"; preprint). A protocol: five typed components, content-hash identifiers in a Merkle graph, signatures, access control, injection-resistant loading. — [arXiv 2605.11032](https://arxiv.org/abs/2605.11032)
- What Portable Agent Memory measured: a pilot on 50 tasks and three model pairs. Transfer continuity (target success over source success) is 0.88, 0.84 and 0.86 against 0.35 with no memory; a fidelity score falls from 0.91 to 0.71 as the token budget is cut to 25% (one pair, 30 probe questions); tamper detection over 1,000 mutations; 200 injection patterns. The authors call the results "directional rather than definitive". No own-memory column, no repeated runs, no key or score analysis. — [arXiv 2605.11032](https://arxiv.org/html/2605.11032)

#### Loss split by stage
- Goyal and Ray define four roles, "the actor ... the writer W ... the reader R ... and the embedder E", and state "A reader swap needs no re-indexing if E stays fixed. An embedder swap requires full re-embedding because old and new vectors occupy different spaces, even when their dimensions match". — [arXiv 2609.05339](https://arxiv.org/html/2609.05339)
- Their stage split: for model-written notes "the writing stage contributes 0.467±0.014 of the 0.584±0.013 pooled mean deficit, or roughly 80% ... Retrieval within the notes contributes only 0.036±0.009"; for chunk retrieval "Retrieval contributes 0.364±0.012 of the 0.450±0.012 pooled mean deficit, a descriptive share of 81%". The paper says this diagnostic "was not part of the four planned hypothesis tests". — [arXiv 2609.05339](https://arxiv.org/html/2609.05339)
- Their fixed-schema result: accuracy "changes by only +0.0004±0.0020 when the writer changes, while own-store accuracy remains high (0.845–0.988)". Their caution: "This does not show that every knowledge graph is portable. The schema fits this synthetic task, and KG-fixed uses a different reading method from NOTES". Two models of 7 to 8 billion parameters, one pair. — [arXiv 2609.05339](https://arxiv.org/html/2609.05339)
- A workshop paper (MemAgents Workshop at ICLR 2026) crosses three write strategies with three retrieval methods on LoCoMo: "average accuracy spans 20 points across retrieval methods (57.1% to 77.2%) but only 3-8 points across write strategies". It varies methods, not the model. — [arXiv 2603.02473](https://arxiv.org/abs/2603.02473)

#### Vector keys after the embedding model changes
- Goyal and Ray, bge-large-en v1.0 to v1.5: "Full re-embedding gains 11.90 points, whereas the mixed index gains only 4.96"; "the system continues running and fails silently". — [arXiv 2609.05339](https://arxiv.org/html/2609.05339)
- Drift-Adapter (EMNLP 2025 main by arXiv comment): a small learned map from new queries into the old space "recovers 95-99% of the retrieval recall (Recall@10, MRR) of a full re-embedding" and "reduces recompute costs by over 100 times". — [arXiv 2509.23471](https://arxiv.org/abs/2509.23471)
- ETBench (ICLR 2027 submission; abstract only): across "24 directed encoder pairs and four corpora", "high alignment accuracy can coexist with poor retrieval of translated documents". — [OpenReview](https://openreview.net/forum?id=kCX4PotiVu)
- Backward-compatible training began in vision: features of a new model that "can be compared directly to 'old' features", avoiding "backfilling" (CVPR 2020 oral by arXiv comment). A 2025 preprint gives an alignment bound and a Procrustes recipe for text embeddings. — [arXiv 2003.11942](https://arxiv.org/abs/2003.11942); [arXiv 2510.13406](https://arxiv.org/abs/2510.13406)

#### Content written by one model and read by another (no key analysis)
- MemCollab: memory from a 32B agent "degrades the performance of the 7B-based agent on MATH500 (50.6% vs. 52.2%) and HumanEval (34.1% vs. 42.7%)". — [arXiv 2603.23234](https://arxiv.org/html/2603.23234)
- Eywa, with its model-free read path held fixed: "When Qwen3 32B writes and answers over its own memory store, the reviewed C1–C4 pass rate is 1,064 / 1,540 = 69.09%. When the same Qwen3 32B answer model reads a Sonnet-written memory store, the reviewed pass rate rises to 1,227 / 1,540 = 79.68%". — [arXiv 2605.30771](https://arxiv.org/html/2605.30771)
- AgingBench (already in the earlier file): after the maintaining model is replaced, loss is non-zero only for memories that rewrite themselves and 0.00 for six retrieval-style stores. — [arXiv 2605.26302](https://arxiv.org/html/2605.26302v2)

#### Labels chosen by a model are unstable (evidence about model-chosen keys from a fixed list)
- A study of failure-category labels across twelve models (IEEE CogMI 2026 by arXiv comment; single author): "50.1% of failures carry evidence for more than one category", and across the six orderings of the classifier's tests one category's share "spans 26.4% to 76.4%". Humans and the model inspector agree at kappa 0.932 on answer correctness but 0.093 on the category; re-running with the human instructions raises kappa from 0.147 to 0.636, "so the gap is largely attributable to the prompt, not the model". — [arXiv 2611.13140](https://arxiv.org/abs/2611.13140)
- Helwig's three-backbone abstention result (0, 25 and 43 attempts of 44 for the same prompt) is a second measured case of a model-made decision moving with the model. — [arXiv 2608.07946](https://arxiv.org/html/2608.07946)
- Item-level churn between model versions (21 to 28% of items) is in the red-team file. — [Cacioli, arXiv 2604.27405](https://arxiv.org/html/2604.27405v1)

### Inferences
- The attribution asked for in the task has been done for content against the vector index (Goyal and Ray), with the embedding model treated as a part separate from the language model. It has not been done for the language model's own part in the key: the description it writes, the label it picks, the query it writes.
- Published numbers cut both ways for the owner's claim. Against it: a fixed list of keys filled by the model moved by +0.0004 across two models, and scored memories reached through model-written intents still helped other models in every transfer table (recheck file). For it: label choice by a model can swing widely with prompt and model, and a model-made speak-or-abstain decision spanned almost its full range across three backbones.
- The study must therefore measure key agreement directly and report loss as a function of it. Where two models file the same traces under the same key, no loss should be expected, whoever computes the key.

### Gaps
- Not found: an experiment that swaps only the language model that writes keys or queries while content and embedding model stay fixed, and reports retrieval hit rate or score-rank validity. Terms used on arXiv abstracts: memory, agent, writer and reader with mismatch, compatibility or "cross-model" (2 results, unrelated); memory, agent, index with "model-specific" or "backbone-specific" and transfer, swap or replace (0); memory, agent with "key drift", "label drift", "index drift" or "retrieval drift" (0); agent, memory and "retrieval key" (4, unrelated). OpenReview term searches: "deterministic memory key agent model swap", "symbolic index agent memory portable across models", "memory index embedding model upgrade agent", "schema-bound memory language model replaced", "who writes the memory key", "model-agnostic memory retrieval deterministic keys" (20 results each; relevant hits are cited above).
- No published number was found for agreement between different models when filing a trace or incident under a fixed list of fault types.
- Rosetta Memory's ICLR 2027 submission status (stated in the recheck file) was not re-verified; the arXiv record names no venue.

## B3. Is "keep the model out of the key" already stated as a design principle, and is it backed by a cross-model experiment?

### Takeaway
The principle is stated, in several wordings, in 2026 preprints: fix the keys by schema, keep the model out of retrieval, move the decision from the prompt into code. Two of them back it with a model swap (two models for memory content; three backbones for a commit decision). None tests it for experience scores, and none compares a code-computed key with a model-chosen key from the same list.

### Cited Findings
- Schema-fixed keys, with a swap: "The schema fixes the keys, relation names, source fields, and reading rules; the model fills in only the values", and "a stable structure can reduce dependence on the model that wrote the memory". Two models, one pair, content accuracy on synthetic question answering. Its design advice includes "Keep the retrieval system fixed". — [arXiv 2609.05339](https://arxiv.org/html/2609.05339)
- Decision in code, with a swap: "move the decision into code ... instead of asking for that judgement in a prompt"; with the gate on, the behaviour is "now a property of the code"; measured on three backbones and held-out databases with predictions registered first. The object is committing column meanings, not memory keys. — [arXiv 2608.07946](https://arxiv.org/html/2608.07946)
- Model-free read path: "The read path ... uses zero LLM calls inside memory retrieval", and separating retrieval from answering "allow[s] the same memory substrate to be evaluated across frontier, budget, and local answer models". Writes are still by a model. — [arXiv 2605.30771](https://arxiv.org/html/2605.30771)
- Model-free retrieval execution: "once a query is formulated, no LLM participates in the retrieval loop". No cross-model test. — [arXiv 2607.04391](https://arxiv.org/abs/2607.04391)
- Model-free memory management: "it is possible to eliminate LLM calls from the memory-management loop". Motivation is cost and determinism, not model change. — [arXiv 2606.03463](https://arxiv.org/abs/2606.03463)
- Code-made graph writes in a product paper: "predefined Cypher queries ... over LLM-generated database queries to ensure consistent schema formats". Entities are still extracted and merged by a model. — [arXiv 2501.13956](https://arxiv.org/abs/2501.13956)
- Stable addresses under content change (not model change): "the addressing interface consumed by learned retrieval policies must remain stable". — [OpenReview](https://openreview.net/forum?id=fZ8fTtjnGH)
- Scores tied to the model that earned them, stated without a key analysis: MemRL's convergence proof assumes a frozen model (recheck file); a practitioner blog says memory scored by a model judge is tied to the model version. — [arXiv 2601.03192](https://arxiv.org/html/2601.03192v2); [tianpan.co](https://tianpan.co/blog/2026-05-10-agent-memory-eviction-lru-survives-model-upgrade-salience-doesnt)
- In the owner's code the principle is already written down: "The DEFECT TERM is built by code from what the recording shows, never typed and never chosen by the model". — `<other project>/13_production_app/nvme_hier/terms.py` (as quoted in `red_team_objections_and_idea_ranking.md`)

### Inferences
- The owner cannot claim the principle. It can claim the measurement of the principle for scored experience: nobody found has put a number on what a code-computed key buys, or costs, when the model changes.
- The cost side is unpublished too. A code key can be wrong in its own way; the red-team file records that rule-decided causes were wrong for 6 of 7 timeout errors on one sample before repair. A paper that reports both the validity kept and the coverage or accuracy lost would be new.
- Goyal and Ray's fixed-schema arm differs from their notes arm in two things at once (format and reading method), as they say. A clean test needs one store, one reader, and only the keyer changed.

### Gaps
- Not searched: knowledge-graph question-answering and neuro-symbolic planning literature before 2024, where symbolic state keys are standard; a reviewer from that field may cite older work on symbolic indices.
- Bodies of GenMem and of the ICLR 2027 submissions listed in the recheck file were not read.

## B4. Verdict for (B), the two papers a reviewer would cite against it, and a public task for the second ground

### Takeaway
Partly addressed. The design principle is stated and has small cross-model support for content; the measurement the owner proposes (score validity under code-computed keys against model-chosen keys, across several models, with loss tied to measured key agreement) was not found. The two papers a reviewer will cite are Goyal and Ray (a fixed schema already survives a swap) and MemRL (scores under model-made keys already transfer); neither compares who computes the key, and neither tests whether scores still rank correctly.

### Cited Findings
- Reviewer citation 1, Goyal and Ray (preprint, "under review", 4 September 2026). Did: four formats, two models, both directions, 48 histories, registered tests; fixed-schema graph +0.0004±0.0020; notes +9.91 or −13.28 points by direction. Leaves out: experience scores; a code-computed key (the model still fills the slots); a model-chosen key and a code key over the same store and reader; more than one model pair; any measure of key agreement between models. — [arXiv 2609.05339](https://arxiv.org/html/2609.05339)
- Reviewer citation 2, MemRL (NeurIPS 2026 poster, peer-reviewed; details in the recheck file). Did: a Q-valued bank reached through embedded intents, built by one model, given frozen to three others on one benchmark, 0.150 to 0.531, 0.347 to 0.583, 0.354 to 0.571. Leaves out: any test that the Q-values still rank items correctly under the new model, an own-memory column, a wipe run, a key analysis, repeated runs. CHIME (preprint) adds the own-memory column and shows one cell where transfer adds 0.78 points against 6.24 for own memory. — [arXiv 2601.03192](https://arxiv.org/html/2601.03192v2); [arXiv 2609.02074](https://arxiv.org/abs/2609.02074)
- A third a specialist may raise, Helwig (preprint): code-made decision holds on three backbones while the prompt-made one does not; different object, no memory, no scores. — [arXiv 2608.07946](https://arxiv.org/html/2608.07946)
- Candidate public tasks where both kinds of key are natural:
  - RCAEval: "735 failure cases collected from three microservice systems", open source, with labelled fault types (11 per the earlier root-cause file) and root-cause services. Code key: system plus the metric family flagged by a fixed detector. Model key: the fault type a model picks from the list. — [arXiv 2412.17015](https://arxiv.org/abs/2412.17015)
  - Cloud-OpsBench: "754 runtime-verified cases across 57 fault types", each "captured as a state snapshot and replayed", so every model sees identical evidence. Code key: a signature computed from the snapshot. Model key: one of the 57 fault types chosen by the model. Preprint, v3 on 6 November 2026. — [arXiv 2603.00468](https://arxiv.org/abs/2603.00468)
  - BigCodeBench (ICLR 2025 oral by arXiv comment): 1,140 tasks using "139 libraries", with tests; MemRL uses it. Code key: the set of libraries parsed from the task. Model key: a model-written intent, embedded. The tests give a ground-truth verdict for each reused solution. — [arXiv 2406.15877](https://arxiv.org/abs/2406.15877)
  - LifelongAgentBench: "skill-grounded, interdependent tasks across three interactive environments, Database, Operating System, and Knowledge Graph, with automatic label verification"; MemRL and RoMeRL report on it. Code key: the task's skill labels. Model key: embedded intent. — [arXiv 2505.11942](https://arxiv.org/abs/2505.11942)
  - Loghub-2.0 (ISSTA 2024, per the earlier root-cause file): 14 log datasets with labelled templates. It can measure key agreement (template identity by a code parser against a model-written template) but has no fix or outcome to score. — [arXiv 2308.10828](https://arxiv.org/abs/2308.10828v2)
- SWE-bench is a weak choice for a new study: the earlier file records leakage and flawed tests. — [OpenAI post](https://openai.com/en/index/why-we-no-longer-evaluate-swe-bench-verified)
- The owner's code base already holds both arms: the shipped code-computed defect term, and an older prompt in which the model picks a cause key from the fixed list, with no caller outside one test. — `<other project>/13_production_app/nvme_hier/isolate.py` (as quoted in `red_team_objections_and_idea_ranking.md`)

### Inferences
- Verdict: partly addressed; the open part is about one experiment wide, the same width the recheck file gave for score transfer in general. This file narrows what is distinct: the keyer as a separate role (Goyal and Ray name actor, writer, reader and embedder, and no keyer), and a dose-response between key agreement and score validity.
- Sharpest open question for (B): "When the language model is replaced, how much of the loss in validity of stored experience scores is explained by the new model filing cases under different keys, and does a code-computed key remove that loss at an acceptable cost in filing accuracy?"
- A prediction that makes the paper more than a demonstration: under a code key, cross-model key agreement is 1 by construction and score validity should equal the within-model value; under a model key, the drop in validity should grow with measured key disagreement across the model pairs. If validity drops although keys agree, the loss lies in the content or the reader, and the claim is wrong. Either result is reportable.
- Smallest credible experiment for (B), one person, four weeks:
  1. Four keyer arms over one store and one reader prompt: (a) code key (shipped dictionary); (b) model picks from the same fixed list (the old prompt); (c) model writes a free description that is embedded; (d) control, raw evidence embedded by a fixed embedding model with no language model. Arm (d) answers the objection "just keep the embedder fixed".
  2. Four frozen models from two vendors, one of them open-weight; all twelve ordered pairs; three repeats per model and case so that cross-model disagreement can be reported net of same-model disagreement (the red-team file's design change).
  3. Measures: key agreement per pair; rank agreement between tallies stored under model A's keys and per-key success of fixes under model B against injected truth; top-1 correct fix under "keep"; a swap of only the keyer with content and reader fixed, and of only the reader with keys fixed, to split the loss; the code key's own filing error and coverage.
  4. Two grounds: the PCIe and NVMe traces, and one public task. RCAEval or Cloud-OpsBench is closest in kind (fault types, replayable evidence). BigCodeBench or LifelongAgentBench allows direct comparison with MemRL and has executable verdicts. Choose by which one runs on one laptop.
- Honest risks: (1) arm (b) may show almost no loss when filing is easy, as the fixed-schema result suggests; (2) on the owner's traces the number of distinct keys is small (red-team file), so rank statistics may be weak and the public task must carry the result; (3) a reviewer may call the code-key result true by construction, so the paper's weight must rest on the dose-response and on the cost of the code key; (4) about fifteen related ICLR 2027 submissions exist (recheck file) and any scored-memory group could add a keyer ablation in a revision.
- What must not be claimed: that fixed or symbolic keys are a new idea; that structured memory surviving a swap is new (Goyal and Ray); that model-free retrieval is new (Eywa, MOSS, DMF); that scored memory fails to transfer (five tables say it helps).
- Value to a top venue (judgement): as a measurement paper with a mechanism, ICML or NeurIPS main track is possible but not likely from one domain plus one public task; the model-swap framing has an audience, shown by the September 2026 submission wave. Results by 15 December 2026 are feasible for the trace leg and one public leg at pilot scale; the full twelve-pair grid with repeats is the part most likely to slip.

### Gaps
- Whether RCAEval or Cloud-OpsBench offers enough distinct keys with repeated cases per key to accumulate scores was not checked in the data; Cloud-OpsBench's public release and licence were not verified.
- No pilot number exists for key agreement between models on the owner's traces or on any public root-cause set.
- The verdict rests on not finding a paper. Unread: bodies of HEIRS, "When Can a Skill Library Trust Its Execution Records?" and "Beyond Semantic Relevance" (all ICLR 2027 submissions named in the recheck file); any of them could contain a keyer or index ablation.
- Deadlines for ICML 2027 and other venues were not re-checked here; see `venues_deadlines_rules.md`.
