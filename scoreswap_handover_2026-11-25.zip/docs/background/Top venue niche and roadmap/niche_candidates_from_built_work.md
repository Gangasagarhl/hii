# Niche candidates from the built work: evidence sheets, model dependence, ground truth and 30-day experiments

Read-only audit of local files on 2026-11-15. No project file was changed, the application was not started, no model was called, `api_key.txt` was not opened, and no large CSV was read (only sidecar, truth, report and code files). Three small SQLite files (`agentic.sqlite`, `hier_knowledge.sqlite`, `sessions.sqlite`) were copied to the session scratchpad and counted there.

Conventions used below:
- Paths are relative to `<other project>/`. `APP/` stands for `13_production_app/`.
- **[T-SYN]** = built and tested on synthetic data. **[B-NRM]** = built, but never run with a real model (stand-in or scripted model only). **[B-1RUN]** = built and run once with a real model. **[PLAN]** = only planned. Everything is synthetic; no real drive and no real capture exists anywhere.
- "Computed here" = arithmetic or a count made in this audit from the named file. "Inferred" = my conclusion; no file states it.
- Not repeated from the three earlier notes (`research_notes/Model swap idea leadership pitch/idea_origin_and_internal_evidence.md`, `.../red_team_objections_and_idea_ranking.md`, `research_notes/One month top venue paper idea/owner_assets_audit.md`): the store schemas, the Wilson ranking, the 26-suite policy benchmark, the KPI harness internals, API prices, venue rules. They are cited where needed.

Three facts found here that change the earlier picture:
1. **A gold set of column meanings exists.** The 12 Nov audit said "Gold column meanings: none". Since 12 Nov the application ships `APP/reference_library/teledyne_lecroy_pcie/columns.json`: 637 column-name entries, 615 of them with a quote from a named public document (counted here). See N5.
2. **A fourth model path exists and has been used with a non-Anthropic model.** The agent layer now has an `opencode` runtime (any "provider/model" that the opencode program lists); a real trial on 15 Nov used `opencode/deepseek-v4.1-flash-free`. The audit's "agent families speak only Claude Code or the Anthropic format" is out of date. See Key Question 6.
3. **A reusable real-model experiment harness exists** outside the application: `research_notes/Any CSV coverage by agent families/evidence_real_model_run/` (`experiment.py` 287 lines, `make_input.py`, `answer_sheet.json`, `analyze.py`). It runs the whole agent flow unattended with a scripted admin and counts model calls. See N3 and N5.

---

## 1. For each candidate: what is built, is it wired in, what tests cover it, and what numbers exist on disk today?

### Takeaway
The work that is both most complete and least measured is the "model writes once, a person approves, code runs" chain (Families 3 and 4, with a hidden reference implementation for 38 rule families) and the code-side checking of every model claim; both are wired into the running application and well covered by offline tests, but neither has a multi-model measurement, and no real model has yet coded one of the 38 rule families. The candidates with the best-looking numbers today (300 of 300 faults, 22 of 22 scripts) are the weakest scientifically, because those numbers were produced with no model at all and are circular by the project's own statement.

### Cited Findings

**N1. Model-swap robustness, reframed (shipped arm vs model-filed arm)**
- Shipped arm is real and wired: the defect key is built by code (`APP/nvme_hier/terms.py:95-143`, `defect_term`, "The key is built from codes only ... never from measured values or display words"); the cause is decided by fixed rules on an evidence card (`APP/nvme_hier/evidence.py:564-627`, `decide_cause`, "Fixed rules in a fixed order: the first that applies decides"); the isolation route calls both and then asks the model only for "why" and "how" (`APP/app/api/isolate_api.py:796-824`). **[T-SYN]**
- The kept isolation is keyed by model id: `version = "card%s-dict%s-explain1-%s" % (CARD_VERSION, VERSION, model_id)` (`APP/app/api/isolate_api.py:805-806`), so explanations are re-made per model while the cause is not.
- Window invariance is tested: `APP/tests/test_isolation_window.py` (6 tests) and `test_the_isolation_of_an_error_does_not_change_with_the_window_or_when_asked_again` in `APP/tests/test_defect_graph.py:285`. **[T-SYN]**
- The model-filed arm exists only as dormant code: `isolation_prompt` with `ISOLATION_SCHEMA` (model chooses a `cause_key` from the fixed list) at `APP/nvme_hier/isolate.py:559-590`; the red-team note found "no caller for it outside one test" (`research_notes/Model swap idea leadership pitch/red_team_objections_and_idea_ranking.md`, finding on `isolate.py` lines 559 to 590). **[B-NRM as an experiment arm; not wired]**
- Numbers on disk: none for any swap. Live store: `dg_defect` 1, `dg_cause` 2, `dg_solution` 1, `dg_revision` 1, `dg_occurrence` 1, `dg_isolation` 2, `dg_verdict` 0, `dg_lab` 0 (`APP/db/hier_knowledge.sqlite`, counted here on a copy; matches the earlier notes).
- A known weak point in the shipped cause rules: "the cause of S17's aborted Read rests on a 5.775 µs difference from the usual time" (`APP/docs/CHANGES_2026-11-15_round2.md`, section 18, "Open, found on the way, not fixed").

**N2. Benchmark or dataset of multi-layer PCIe/NVMe traces with injected faults**
- Generator and exporter: `APP/data/generator/generate_synthetic_pcie_trace.py`, `tracegen_core.py`, `tracegen_episodes_a.py`, `tracegen_episodes_b.py`, `tracegen_nvme.py`, `export_levels.py`, `make_five_level_sets.py` (also the October originals in `02_generator_and_validator_code/`, with `validate_synthetic_pcie_trace.py` and `verify_spec_conformance.py`). **[T-SYN]**; used by the application only to make samples, not part of the analysis flow.
- Data on disk: 59 five-level sets (`APP/samples/five_level/S01..S59`), one 485-card packet trace (`pcie_trace_485_errors.csv`, 2,052,490 rows, 113 columns, seed 20261024, `03_main_csv_sidecars/synthetic_trace_manifest.json`), one full five-level set with all 485 cards (`APP/samples/five_level_full/README.md`: packets 8,253,090 rows, link 4,447,300, split 712,396, NVMe transactions 413,255, commands 34,608), four clean five-file recordings (`APP/samples/clean_five_files/`).
- Tests against truth: suite `unit_hier` "five-level loader, builder vs ground truth, rules ..." (`APP/run_tests.sh:53`, `APP/tests/test_nvme_hier.py`).
- Existing non-LLM baselines with numbers:
  - Older packet engine on a 4.0 GB, 20,706,924-row trace, by rule tier: stateless row predicates 117 of 485; plus keyed state machines 180; unsupervised statistics 342; hybrid wire-only 437 (90.1%); with simulated outside evidence 483 (99.6%); false-positive findings in healthy traffic 0, 0, 0, 0 and "2 findings at 1 place" (`10_defect_isolation_engine/REPORT_defect_isolation.md:9-17`).
  - Same engine, isolation: atlas card ranked first 387 of 483 (80.1%), top 3 442 (91.5%); "First abnormal row within 32 rows of the ground-truth key row 316 of 422"; run time "analyze 302 s, fuse 4 s, isolate 35 s; single core" (`REPORT_defect_isolation.md:29-35`). Card library learned on two separate captures, seeds 7 and 11 (`:37-39`).
  - Five-level detector on the 59 sets: 1,594 findings over 25 distinct rules; every set has a finding; 36 of 59 sets have a finding at their own `first_level` (computed here from `APP/samples/five_level/coverage.json`).
- Existing LLM numbers on this data (one model, run-time reviewer): `claude-haiku-5-5`, 88 incidents (one per layer × first-rule bucket): 51 CONFIRMED, 36 INCONCLUSIVE, 1 NOT_CONFIRMED; "rule ids named that do not exist 0"; "packets cited that were not shown 2"; "card agreement with the engine's first candidate 57 of 87"; cost "$20.70 for the set (about $0.23 per incident ...)" through the local CLI (`REPORT_defect_isolation.md:126-137`).
- Missing: a scorer that compares an agent's answer with the truth files; a task definition; any multi-model result (`owner_assets_audit.md` section 4, candidate C; nothing found here that changes it).

**N3. "Agents propose, a person approves, code runs" (rule written once and compiled, against asking a model at run time)**
- Three compile paths exist, all wired into the flow **[T-SYN, B-NRM except where noted]**:
  1. Plan to SQL by a fixed translator: "the code is generated from the plan by a fixed translator (compile_rule), so the same rule always gives the same code" (`APP/agentic/family3.py:1-8`, `compile_rule` at `:486`). The model (Rule writer, `family3.py:712`) writes the plan; code checks that it compiles against the real columns.
  2. Model-written Python, tested in rounds, approved, then reused without a model: Family 4 (`APP/agentic/family4.py`, 2,693 lines; Coder at `:1887`, independent second program at `:1896`, Tester at `:1931`; `ROUNDS_DEFAULT = 10` `:69`, `REPAIRS_PER_PROGRAM = 3` `:86`, `DOUBT_TURNS_MOST = 3` `:88`). Verified code is returned without any model call: `if st["verified"]: return core.Result({"kind": "python", "verified": True, "code_file": ...})` (`APP/agentic/family3.py:932-934`); a run "takes only verified code" (`APP/run_tests.sh:56`). "All generated code runs only in the confinement of procedures.run_code ... Nothing a model wrote is ever executed inside the application's process" (`family4.py` module docstring; `APP/agentic/procedures.py:1031`).
  3. The application's reference implementation for 52 rule families (38 runnable, 14 not checkable; groups 24 / 15 / 13; counted here by importing `APP/nvme_hier/command_error_rules.py`: `FAMILIES` 52, `NOT_SEEDED` 14, `items()` 38). "With a model Family 4 writes the code, and the Tester compares its rows with that reference on the whole recording" (`APP/docs/OPPORTUNITY_COVERAGE_2026-11-15.md`, second-round table, row S14; mechanics in `APP/docs/CHANGES_2026-11-15_round2.md:917-932`).
- Guard against leaking the reference: "A Coder's code may not reach the reference implementation or the detector's code" (`CHANGES_2026-11-15_round2.md:893-898`).
- Model calls per rule, counted with the stand-in on S17: 0 with no model; 10 for a rule on one file; 11 for a rule on two files; "1 or 2 for the data research, 1 for the requirements, 5 questions to Family 1's Managers, 1 for the Coder, 1 for a second program, 1 for the Tester. A real model needs more when a round fails. No real model was counted." (`CHANGES_2026-11-15_round2.md:1006-1016`).
- The one real-model measurement **[B-1RUN]**: `claude-sonnet-5-5`, one rule on one 608-row, 15-column disguised file: 652 s, 24 model calls, 0 failed calls; the code's result "equals the truth: the same 6 rows"; "The program of round 1 already gave the right rows"; one dead end "made by the application itself cost 5 coding rounds, 423 s and 12 of the 24 model calls"; the data research step wrote "5 false 'surprises' and 1 false 'conflict'" (`research_notes/Any CSV coverage by agent families/E_real_model_run_on_unknown_csv.md`, "Verdict", "The code's result against the true count", "What failed"). The three faults were repaired afterwards and "tested with a scripted model only" (`OPPORTUNITY_COVERAGE_2026-11-15.md`, "It exposed three faults").
- What has NOT been done: "No real model has coded one [rule family]: the path with a model was walked with the stand-in and programs written by hand for the test" (`OPPORTUNITY_COVERAGE_2026-11-15.md`, row S14); in the flow test a hand-written wrong program "is caught: 'only the reference implementation found row 570'" (`CHANGES_2026-11-15_round2.md:1107-1110`).
- Speed and memory of the fixed-code side on large files **[T-SYN]**: 3.4 GB set (4,378,859 packets, 34,608 commands): load 163.7 s, build 175.5 s, rules 37.7 s, whole pass 390 s (`APP/docs/CHANGES_2026-11-14.md:291-305`); 326 MB set (1.9 million rows): whole run 51.8 s and 51.1 s, peak memory 286 MB main / 267 MB largest worker (`APP/docs/CHANGES_2026-11-12.md:83-93`); 19.7 GB (31.7 million packets) under a 4 GB memory limit: 86 minutes (`APP/deploy/OPERATIONS.md:422`); the 38 rule families plus 5 other items on S17 with no model: "116 seconds as the builder measured it, 90 seconds on the code after the join" (`CHANGES_2026-11-15_round2.md:1062-1064`).
- The run-time comparator that exists: the older stage-1 reviewer (a model reads each incident excerpt; `REPORT_defect_isolation.md` section 6) and the isolation evidence loop (`APP/app/api/isolate_api.py:702-716`, at most 5 rounds, `APP/nvme_hier/isolate.py:18`). No arm exists in which a model applies a rule to rows at run time. **[PLAN]**
- Tests: `test_family4.py` 41 tests, `test_f4_research.py` 25, `test_f4_recheck.py` 31, `test_command_error_rules.py` 16, `test_top_three_rules.py` 11 (counted here with `grep -c "def test"`); `test_family4_real_run_faults.py` covers the three repaired faults.
- Stored artefacts today: 2 verified code files (`APP/knowledge/rules_code/analytics/nvme_command/read_pattern.p1.run4.py`, `command_type_share.p1.run2.py`); 132 files under `APP/knowledge/` in all.

**N4. Evidence-checked claims (code re-checks every sourced claim before a person sees it)**
- The central checker: `check_claims` (`APP/agentic/core.py:359-398`), docstring "Zero hallucination, applied by code: a claim is kept as verified only when its source holds it." Kinds: `data` (quoted value must be among the column's profiled values), `document` / `rea` / `project` (quote must be in the file: `References.has_quote`, `core.py:256`), `admin` (quote must be in what the admin wrote), `web` ("the program fetches the page itself and finds the quoted words on it", `WebSources.has_quote`, `core.py:351`); everything else "is kept as UNVERIFIED and shown as such".
- Where it is called: Family 1 Grounder (`APP/agentic/family1.py:1517, 1821, 1942`), Family 2 collector and Coder (`APP/agentic/family2.py:208-210, 338-340`), the flow (`APP/agentic/pipeline.py:156`). **[T-SYN]**, wired.
- Other code-side checks on model output, all wired:
  - cited rows must be rows that were shown, and the proposed sequence may use only commands of the fetched window: `check_cited` and `check_sequence` (`APP/nvme_hier/isolate.py:719, 744`; applied at `APP/app/api/isolate_api.py:776-779, 822`);
  - the test plan passes a ladder before anyone reads it: `check_plan` (`APP/nvme_hier/testplan.py:201`), `check_answer` (`:454`), then a four-way run on the simulated drive, `two_sided` (`:342`);
  - Family 4's requirement verdicts: "A model never says whether a requirement is met" (`APP/agentic/f4_research.py:30, 47`: met / not met / not exercised / could not be checked);
  - Family 4's recheck by a terminal agent: "Nothing of its answer is believed as written"; the application compares the two result files row by row and checks every cited row number (`APP/agentic/f4_recheck.py` module docstring);
  - the REA agent: "every quote it gives is checked against its passage by code" (`APP/agentic/rea_agent.py` docstring);
  - the admin's question to all Managers: "yes only with a name that is in the data" (`APP/run_tests.sh:75`).
- Numbers on disk:
  - Live evidence table: 150 claims; 26 of kind `document`, all verified; 124 of kind `model`, none verifiable; **0 claims with a checkable source that failed the check** (`APP/db/agentic.sqlite`, table `evidence`, counted here on a copy).
  - Real-model run on an unknown file: "11 of the 15 meanings, and all 13 keyword meanings, rest on 'the model's knowledge (no source to check)'"; all 15 were right (`E_real_model_run_on_unknown_csv.md`, "Verdict").
  - Real opencode trial of the recheck, 3 rechecks, model `opencode/deepseek-v4.1-flash-free`: agreed with right code in 45 s; "found the planted fault in 72 s with 10 of 10 example rows and row numbers right"; second recheck of a build "hangs in silence for the full 300 s"; the confinement was crossed ("`ls /home` was allowed, and when the read tool refused a folder the model read it and wrote two files into it with Python") (`research_notes/Any CSV coverage by agent families/F_real_opencode_trial_of_the_recheck.md`, "Verdict"). **[B-1RUN]**
  - Older reviewer: 0 invented rule ids and 2 cited packets not shown, in 88 incidents (`REPORT_defect_isolation.md:131-133`).
- What code did NOT catch in the one real run: the data research model's 5 false "surprises" and 1 false "conflict", which "became a question to the admin" (`E_real_model_run_on_unknown_csv.md`, "What failed", item 2).
- Stated open gap: "Meanings without a source. Not built. The label is honest; the meaning is not checked." (`OPPORTUNITY_COVERAGE_2026-11-15.md`, "What stood between the design ...", point 5).
- Tests: `test_web_evidence.py` 5, `test_rule_evidence.py`, `test_f4_recheck.py` 31, `test_regression_tests.py` 9, `test_agent_layer.py` (suite `unit_agents`: "bad model answers, outages ...", `run_tests.sh:67`).

**N5. Learning the meaning of the columns of an unknown wide CSV (Family 1)**
- Modules: `APP/agentic/family1.py` (2,351 lines; Explorer, Grounder, Manager), `APP/agentic/column_knowledge.py` (library and store), `APP/agentic/column_match.py` (finding which column holds a kind of data, "ranked by containment and never Jaccard", `run_tests.sh:79`), `APP/agentic/csv_dialect.py` (separator, encoding, header line, decimal commas), `APP/agentic/admin_ask.py`. Wired as the first family of every flow. **[T-SYN; B-1RUN]**
- What code does and what the model does: the Explorer's code "reads EVERY row of the file (no sample)" and counts; "The model then only writes a summary of that profile"; the Grounder "gets the column names and the keywords (never the data rows)" and "Every meaning says where it comes from; a document line and a web page are checked by code" (`family1.py` module docstring).
- Batch constants today (changed since the 12 Nov audit): `GROUND_BATCH = 40`, `GROUND_BATCH_KNOWN = 60`, `GROUND_MEANINGS = 150`, `GROUND_KEYWORDS = 20`, `BATCH = 120`, `GROUND_EFFORT = "xhigh"` (`family1.py:51-78`).
- Order of sources for a meaning: admin-approved meaning; the tool's reference entry "used only when its quote is found, at run time, on the stated line"; an earlier run's meaning; a library entry of kind `model`; then the model (`APP/reference_library/README.md`, "How the Data Grounder uses it"). A file is taken as a known tool's export when at least 5 names and 30% of names match (`column_knowledge.py:25-26`).
- **Gold-like reference set**: `APP/reference_library/teledyne_lecroy_pcie/columns.json`, prepared 2026-11-12: 637 entries; kind `document` 615, `model` 18, `unknown` 4; 615 with a quote; sources: `nvme_base_2_1` 374, `verification_script_engine_manual` 103, `nvme_nvm_command_set_1_1` 97, `exerciser_scripting_manual` 21, `z5_user_manual` 16, `automation_api_manual` 4, none 22; placements by level: nvme_command 470, nvme_transaction 402, packets 113, link 39, split 22 (all counted here). Its `sources` block gives each document's title, version, publisher and public address. `build_reference.py --check --sources FOLDER` looks "every quote up on its stated line of the original texts" (`reference_library/README.md`).
- Wide-file sizes: named columns per level in the real export layout: link 34, split 17, nvme_command 1,598, NVME_Transactions 402, packets 113 (`APP/data/lecroy_export_columns.json`, `status`); an approved dictionary for the synthetic nvme_command file holds 33 columns with values and 1,694 empty columns (`APP/knowledge/dictionaries/035920758b4b/nvme_command.current.json`, counted here).
- Numbers on disk: real-model run 15 of 15 right on a disguised 15-column file, 11 of 15 uncheckable (above); run 1 source kinds per file (from the audit): NVMe transactions 33 meanings (9 document, 24 model), link 28 (4, 24), NVMe command 33 (0, 33), packets 51 (10, 41), split 15 (3, 12) (`owner_assets_audit.md` section 4 D; that run predates the reference library). Timing: 51 columns, 69.7 s with web, 14.9 s without (same section).
- A second, private answer sheet exists for the disguised file: 15 columns with `really` and `must_say` keys (`evidence_real_model_run/answer_sheet.json`).
- Tests: `test_grounder_forty.py` 10, `test_grounder_batches.py`, `test_grounder_known.py`, `test_column_knowledge.py`, `test_column_match.py`, `test_csv_dialect.py`, `test_any_tool_start.py`, `test_form_in_every_reader.py`.
- Never done: "No VIAVI export and no real export of any other tool has been read" (`OPPORTUNITY_COVERAGE_2026-11-15.md`, rows S5); "Web search on for an unknown tool: whether it raises the share of checked meanings was not measured" (same file, "What was not checked").

**N6. Trace to replay test without training**
- Main-flow modules: first sequence by dependency rules (`APP/nvme_hier/optimise.py`), plan and file (`APP/nvme_hier/testplan.py`: `build_plan`, `check_plan`, `render`, `two_sided`), fixed replay library with a simulated drive (`APP/nvme_hier/regress/f2t_nvme.py`, 865 lines), search and stress step (`APP/nvme_hier/replay_search.py`, 823 lines: `HiddenTriggerBench` `:232`, `random_trigger` `:306`, `RealBench` `:349` which "raises NotImplementedError today", `_random_walk` baseline `:794`), hand-over package (`APP/nvme_hier/handover.py`). Wired on the page of one error. **[T-SYN]**
- Older packet workflow: model proposal as seed, Thompson bandit over mutation operators, Go-Explore archive, ddmin (`APP/stage2/optimizer.py`), optional PPO (`APP/stage2/ppo_optimizer.py`), synthetic device with a hidden trigger (`APP/stage2/oracle.py`), closed loop through the trace generator and the stage-1 detector (`APP/stage2/testgen.py`), model-composed variants (`APP/stage2/compose.py`). **[T-SYN; exercised with a real model]**
- Numbers on disk:
  - "22 scripts; defect caught 22, reproduced 22, fixed firmware passes 22, fault absent 22" (`APP/runs/kpi_proof/kpi_proof.json`, `scripts`; file regenerated 15 Nov, 1,070 s). These were made with the stand-in, not a model: the harness posts `"standin": True` for both the isolation and the test case (`APP/tests/test_kpi_proof.py:412, 421`). The coverage check says "22 scripts, 0 hand-written lines ... A fixed template writes the file" (`OPPORTUNITY_COVERAGE_2026-11-15.md`, row S15).
  - "300 injected, 300 found" is detection by two rules on five injected kinds, baseline recall 0.4 (`kpi_proof.json`, `kpi2`); the project's own reading: "300 of 300 shows that the rules agree with the generator" (`OPPORTUNITY_COVERAGE_2026-11-15.md`).
  - Search on the simulated drive: with the drive's time hint 50 of 50 hidden triggers against 37 of 50 for a random choice; "without the hint 33 of 50 against 37 of 50, worse than random" (`APP/docs/CHANGES_2026-11-15.md:300-301`; `OPPORTUNITY_COVERAGE_2026-11-15.md`, row S7).
  - Bandit against PPO on the synthetic device, 24 runs each: "PPO 15 confirmed (median 166 trials), bandit 14 (median 156)" (`APP/docs/PROVENANCE_AUDIT.md:174`).
  - Real-model exercise of the older workflow (`anthropic:claude-sonnet-5-5:low`, 65 checks passed, 1,306 s): e.g. "T-42 ... composed 3 variant(s) from 43 stored sequence(s) via the LLM; 1 reproduced, 1 filed"; "L-31: generate test -> confirmed, 287 trials, repro 0.53, closed loop 5/6 bad, 0/3 fixed" (`APP/runs/exercise_report.md`).
- The project's own limit: passing two-sided "means 'mechanics checked on a simulated drive', never 'fault reproduced': that needs the real drive with the faulty firmware" (`testplan.py` docstring).
- Tests: `test_replay_search.py` 13, `test_regression_tests.py` 9, `test_handover.py`, `test_kpi_proof.py`.

**N7. Procedural graph with four typed verdicts, and timing learned on the graph**
- Modules: `APP/nvme_hier/defect_graph.py` (550 lines), `APP/nvme_hier/graph_learning.py` (686 lines: `dg_lab`, `dg_seq_timing`, `dg_timing`; "The constants below are CHOSEN HERE, TO BE MEASURED on a real bench"), `APP/app/api/dg_api.py`, the search hook in `APP/app/api/isolate_api.py:1489-1560`. Wired. **[T-SYN]**
- Numbers on disk:
  - Timing from history on the simulated drive, 30 hidden triggers per arm: same-kind history better in 28 of 30 (median 10 against 48 lab runs); stale history worse in 25 of 30 (better in 4); wrong history worse in 30 of 30 (`CHANGES_2026-11-15_round2.md:1387-1409`; `OPPORTUNITY_COVERAGE_2026-11-15.md`, rows S2 and S11). "The acceptance was written before measuring" (`:1390`).
  - Older packet search with memory: better in 49 of 60 pairs, median 301 → 72 lab runs; "The gain comes from the stored best procedure, not from the carried counts (the counts alone: 26 better, 18 equal, 16 worse)" (`OPPORTUNITY_COVERAGE_2026-11-15.md`, row S11).
  - Verdicts: 0 in the live store; four-verdict behaviour tested (7 tests in `test_defect_graph.py`, 12 in `test_graph_learning.py`, plus `test_graph_loop.py`).
  - 26-suite policy benchmark (older verdict set, 14 policies): best Exact@1 0.747; team design 0.678 / 0.624; static 0.089 (`Database_Implmentation/claude_benchmark/results/ranking_tables.md`, read here).
- Stated limits: "the order of the solutions shown still changes only with the admins' judgements"; "The four constants of the method were chosen, not measured" (`OPPORTUNITY_COVERAGE_2026-11-15.md`, rows S9 and S7).

**Further candidates found in the code (not in the brief)**
- **N8. Two independent programs as an ambiguity detector for a rule written in English.** In round 1 "a second program is written at the same time, independently, from the same requirements. Both run on the same small data. Where their results differ the rule can be read two ways: the admin is shown the data and both results and says which is meant" (`family4.py` module docstring; second-program call at `:1896`). **[B-NRM]** plus one real run in which four data sets were left "for you to judge". No count of how often two programs disagree exists.
- **N9. Measure the data before coding (the data research record).** One streaming pass per touched file records value shapes, spellings of "nothing", numbers stored as text, ranges, key uniqueness, and where the rule's own words are stored (`APP/agentic/f4_research.py` docstring). The owner's report gives outside figures only (a stored-value mapping "raises the share of correct data queries by 9 to 20 points", `reports/Coding research family data first.md`, opening paragraph, marked "(measured)" on other data, "never on PCIe or NVMe traces"). No ablation on this data exists. **[B-NRM]**
- **N10. Rule-tier ablation at packet level** (117 / 180 / 342 / 437 / 483 of 485) is already a finished table on one synthetic trace (`REPORT_defect_isolation.md:9-17`). It is a ready baseline for N2 rather than a paper.

### Inferences
- Inferred: the candidates sort into three groups by what a 30-day study could honestly add. (a) N3, N4, N5: built, wired, tested offline, and one real-model run each shows the path works; the missing thing is a measurement over models and tasks. (b) N1, N2: need one new piece each (a model-filed arm; a scorer and task definition) and inherit a clearance question. (c) N6, N7: the headline numbers exist but rest on a stand-in, a fixed template and a simulated drive whose fault is built from the plan itself; no experiment in 30 days removes that.
- Inferred: "300 of 300" and "22 of 22" should not be the headline of any paper; both were produced with zero model calls and the project's own coverage document calls the first circular.
- Inferred: the reference implementation for 38 rule families is the single most useful asset for an experiment, because it is an oracle that the model under test is prevented from reading and it runs on any recording in seconds.

### Gaps
- `document.html`, `how_it_meets_the_statement.html` (project root), `APP/docs/FINAL_WORKFLOW_AND_ALGORITHMS.html` and `APP/docs/CHANGES_2026-11-15.md` (beyond the lines cited) were not read in full; a number that exists only there could have been missed.
- `14_previous_versions/`, `Database_Implmentation/final_implementation/`, `09_defect_isolation_research/`, `11_failure_reproduction_research/` were not opened.
- No file gives how often Family 4's two programs disagree, how often the Tester's cases catch a wrong program written by a real model, or how many rounds a real model needs on the 38 families.
- `APP/BUILD.txt` holds only "build 2026-11-15 15:29"; the label "build 25" comes from `APP/docs/CHANGES_2026-11-15_round2.md` section 18 and the earlier notes.

---

## 2. Model dependence: which outputs are produced by a language model and which by fixed code in the current build?

### Takeaway
In the current build a language model never decides whether a defect exists, what its key is, what its cause is, how files are joined, or whether a requirement is met; it writes plans, code, meanings, explanations and row selections, each of which is either checked by code, approved by a person and frozen, or both. A change of model can therefore change a result in exactly four places: the column meanings (Family 1), the rule plan or rule code written at authoring time (Families 3 and 4), which recorded commands are kept in the first sequence and test plan, and all free text.

### Cited Findings

| Step | Produced by | Checked or frozen how | Can a model swap change a downstream result? | Source |
|---|---|---|---|---|
| Family 1 Explorer: what each column holds (counts, types, keywords) | Code, every row | "nothing about it is 'verified', it is counted" | No | `APP/agentic/family1.py` docstring |
| Family 1 Explorer: summary sentence of a file | Model (`family1.py:1366, 1377`) | Read by the admin | Text only | same |
| Family 1 Grounder: meaning of each column and keyword | Reference library entry (no model) when the tool is recognised and the quote is found; else model (`family1.py:1702`) | Quote checked by code for document and web sources; model knowledge labelled; dictionary approved by the admin and reused ("if once the column name has been done, it's done", `column_knowledge.py` docstring) | **Yes, at authoring time**: later rule writing reads the dictionary. After approval the stored meaning is reused with no model call | `APP/reference_library/README.md`; `family1.py:925, 946` |
| Family 2: how the five files join | Fixed code (`APP/nvme_hier/builder.py`; rules described in `APP/agentic/join_rules.py`) | The model's Coder may only attach evidence: "Each rule is exactly what the tree builder's code does, so you cannot change its wording: a rewritten sentence would change nothing the code does" | No | `APP/agentic/family2.py:256-263`; `join_rules.py:1-12` |
| Family 2 testers (slice, breaker, independent) | Code | Counts against the analyzer's own child counts | No | `family2.py` docstring |
| Detection of an error (42 detector rule ids: 11 packet, 4 link, 7 split, 7 NVMe transaction, 13 command) | Fixed code | "A defect is found by a rule and only by a rule" | No | `APP/nvme_hier/rules.py` docstring; ids counted here from `rules.BASIS` |
| Family 3 Rule writer: the admin's words to a plan | Model (`family3.py:712`) | Code checks that the plan compiles against real columns; admin approves; versioned | **Yes, at authoring time** | `family3.py:1-8` |
| Family 3 code for plan kinds (`distribution`, `read_pattern`, `detection_rule`, `condition`) | Fixed translator `compile_rule` | Deterministic | No, given the plan | `family3.py:486` |
| Family 4 requirements, Coder, second program, Tester's data sets, data researcher | Model (`family4.py:363, 1031, 1887, 1896, 1931`; `f4_research.py:737`) | Program checks, run on first real records, all small data sets, requirement-by-check table decided by code, optional terminal recheck, admin approves; verified code then runs with no model | **Yes, at authoring time**; no at run time | `family4.py` docstring; `family3.py:932` |
| The 38 rule families with no model connected | Application's reference implementation (`command_error_rules.find`, `:741`) | — | No | `OPPORTUNITY_COVERAGE_2026-11-15.md`, row S14 |
| The 38 rule families with a model connected | Model-written code, rows compared by the Tester with the reference on the whole recording | Disagreement shown as "only the code found rows ..." / "only the reference implementation found rows ..." | **Yes, at authoring time**, and measurable against the reference | `CHANGES_2026-11-15_round2.md:917-932` |
| Rows found become errors | Code, only after the admin approves the result | `coded_findings.py` refuses a result that does not name its rows | No | `APP/nvme_hier/coded_findings.py` docstring |
| Defect term and key | Code | Dictionary version 3 | No | `APP/nvme_hier/terms.py:18, 95-143` |
| Evidence card and cause keyword (20 keywords, 7 sides) | Code, fixed order of rules | Card version 3; admin may choose another keyword from the same list | No | `APP/nvme_hier/evidence.py:28, 564-627`; `terms.py:51-73` |
| Explanation "why" and "how", cited rows | Model (`explain_prompt`, `isolate.py:615`) | Cited rows checked by code; kept per card hash and model id | Text only; the kept isolation is re-made for a new model id | `isolate_api.py:803-825` |
| Evidence loop: reason text and which commands above the defect are kept | Model, up to 5 rounds (`isolate_api.py:702-716`); the seed sequence is code (`optimise.py`) | `check_sequence`: "only commands from the fetched window"; commands after the defect "copied unchanged" | **Yes**: a different model can keep different recorded rows, which changes the stored solution's first sequence and the test | `isolate_api.py:776-786`; `OPPORTUNITY_COVERAGE_2026-11-15.md`, row S6 ("code writes the first sequence and the model picks rows") |
| Proposed optimized sequence (solution text) | Model (`optimized_prompt`, `isolate.py:595`) | "the admin edits ... before it is stored" | **Yes**, before approval | red-team note, citing `dg_api.py:276` |
| Expected outcomes after the defect | Model (`outcomes_prompt`, `isolate_api.py:1069-1071`); skipped steps filled by the stand-in (`:1094-1095`) | Admin verifies each | **Yes**, before approval | same lines |
| Test plan: which recorded rows to replay | Model (`_model_regression_test`, `isolate_api.py:1177-1233`); falls back to "the code's own plan from stage 1" | `check_answer`, `check_plan`, `two_sided` on the simulated drive | **Yes**; bounded to recorded rows | `testplan.py:201, 342, 454` |
| Test file text | Fixed template `render` plus fixed library `f2t_nvme.py` | — | No | `testplan.py:250`; `f2t_nvme.py` docstring |
| Summary (who, what, when, where, why, how; 100 words) | Model (`isolate_api.py:1323-1324`) | Length check; stand-in if empty | Text only | `isolate.py:68-71` |
| Search over timing and order | Code (hill climb plus Thompson bandit) on a bench | Simulated drive only | No | `replay_search.py` docstring |
| Ranking of solutions | Code, Wilson lower bound on the admins' verdicts | — | No | `defect_graph.py:319-333` (audit) |
| Error in a CSV outside the tree: isolation text | Model, from model-made meanings | Per-run file; no graph, no cause, no test | Text only; nothing is stored on it | `APP/agentic/other_errors.py` docstring; red-team note |
| Older packet workflow: stage-1 confirmation, capture check, digest, proposal (seed), test composition | Model at five points, "all read-and-propose, and code verifies their output" | Status word "comes from the rules alone" | Seed and variants yes; verdict no | `APP/docs/PROVENANCE_AUDIT.md:18-21, 246` |

- Every model call has a deterministic stand-in, and a failed call falls back to it; the fallback is visible only in the `producer` text ("stand-in (no model)", `APP/agentic/core.py:802-803`; `APP/nvme_hier/isolate.py` docstring: "Every model call has a deterministic stand-in").
- Model self-rated confidence is deliberately ignored: "a number the model invents in its answer; no specification or statistic defines it" (`PROVENANCE_AUDIT.md:245`).

### Inferences
- Inferred: the design can be stated in one line that a reviewer can check against the table: the model acts only at authoring time (meanings, plans, code, sequences) or writes text; run-time decisions (detect, key, cause, join, rank) are code. That is the precise sense in which "stored scores survive a model swap" in this product.
- Inferred: a swap can still change a stored tally's meaning by one indirect route that the red team listed as unchecked and that this table confirms: two models may write different rule code or different column meanings, so a later analysis with re-authored rules finds different rows. Rules and dictionaries are versioned and reused, so this happens only if someone re-authors after the swap.
- Inferred: the largest run-time model influence left in the main flow is row selection for the first sequence and the test plan. It is bounded (recorded rows only) but not eliminated; it is the natural place to measure a swap effect inside the shipped product.
- Inferred: because the same rule can be run three ways (reference implementation, model-written code, and, if added, a model reading rows at run time), the product itself already contains the control arm for N3.

### Gaps
- Not traced: `APP/agentic/data_chat.py`, `join_workbench.py`, `investigate.py` and `APP/nvme_hier/chat.py` (chat helpers that answer questions; they call a model at `data_chat.py:306`, `join_workbench.py:346`, `investigate.py:913`, `chat.py:209`). Whether any of their answers is stored and reused by a later step was not checked.
- The claim that `isolation_prompt` has no caller is taken from the red-team note; it was not re-verified here.
- Whether an approved dictionary made by model A is silently reused after a switch to model B (it appears so, since reuse is keyed by header and approval, not by model) was read from `reference_library/README.md` and the function names, not tested.

---

## 3. Ground truth: what truth files exist, how many kinds, is the generator parameterised, and is anything derived from confidential material?

### Takeaway
The synthetic data carry four layers of truth (packet containment, episode position with key packets, the atlas card of each episode with its origin class, and the scenario with its domain and public sources), over 485 fault cards, 59 composed scenarios and 5 injected command-fault kinds; new sets are made by listing cards and a seed, at about 12 seconds per set. The layout of the files, however, was transcribed from photos of a customer's analyzer export, and three other items (a decompiled-analyzer agent, quotes from vendor manuals, and the unstated authorship of the 485-card atlas) need a decision before any public release.

### Cited Findings

**Truth files**
- Per five-level set: `truth_packet.csv` (packet → link, split, NVMe transaction, command, relation), `csv_row_scenario_index.csv` (one row per injected episode: `card_id, title, phase, pattern, variant, pex_visibility, symptom_class, origin, packet_first, packet_last, time_first, time_last, n_key_rows, key_packets`), `scenario_event_log.jsonl`, `scenario.json` (scenario, seed, cards, "provenance": "SYNTHETIC five-level set"), `rules.json` (load, build checks, findings by rule), `levels_manifest.json` (`APP/samples/five_level/S17/`, listing; `APP/data/generator/make_five_level_sets.py:30-67`).
- For the 485-card packet trace: `csv_row_scenario_index.csv`, `episode_key_rows.csv`, `scenario_coverage_matrix.csv`, `scenario_event_log.jsonl`, `validation_report.json`, `spec_conformance_summary.json` (`03_main_csv_sidecars/`, listing).
- For injected command faults: `inject(base, out, seed, per_kind)` returns `{command number: kind}` (`APP/tests/test_kpi_proof.py:84`), five kinds, 60 each in the saved run (`APP/runs/kpi_proof/kpi_proof.json`, `by_kind`).
- For hidden triggers of the replay search: `random_trigger(pool, rnd, miss_share=0.1, impossible=False, needed=(4, 6))` (`APP/nvme_hier/replay_search.py:306`).

**Counts (all computed here unless a file is quoted)**
- Fault cards: 485 (`APP/data/atlas_cards_raw.json`; `APP/data/DEFECT_DETECTION_SPEC_485.jsonl`, 485 lines). Card families by prefix: M 101, S 93, N 58, T 51, L 40, V 37, D 33, X 30, C 28, P 14. Evidence classes: PAYLOAD_REQUIRED 207, WIRE_SYMPTOM 111, WIRE_DECIDABLE 97, OUTSIDE_EVIDENCE 53, NOT_ON_LINK 17. Each spec line also carries `attribution`, `detect`, `false_positive_guards`, `confirmation_tests`, `spec_reference`, `preconditions`.
- Each atlas card has `layer`, `origin`, `pex` (visibility) and `rep` (reported class) fields (`atlas_cards_raw.json`, first entry: `'origin': 'Host software', 'layer': 'NVMe command', 'pex': 'Visible', 'rep': 'Reported'`).
- Scenarios: 59 (`APP/data/catalogue/08_failure_corpus.json`). Domains: controller firmware 38, PCIe link 9, media 4, configuration 3, platform power 2, host driver 2, thermal 1. First level: NVMe command 32, NVMe transaction 14, packet 7, split 3, link 3. Visibility: visible 36, partly 12, silent 11. Each scenario has its own detection rule text (59 distinct), `seen_in` (file, column, value), `synthetic_recipe` and `sources` (public web addresses, e.g. kernel bugzilla).
- The 59 sets use 214 distinct atlas cards and contain 257 episodes. Episode origin classes: Device 105, Either side 58, Host software 49, Link / channel 26, Host platform 12, Test setup 7. Symptom classes: Reported 99, Silent 58, Degraded 51, Timer only 49. Visibility of episodes: Visible 138, Partly visible 113, Not visible 6. 24 distinct pattern codes (from the 59 `csv_row_scenario_index.csv` files).
- Detector on the 59 sets: 1,594 findings, 25 distinct rule ids fired (top: `pkt.link_down` 340, `lnk.replay` 289, `pkt.electrical_idle` 253, `pkt.speed_change` 224, `spl.incomplete` 127) (`APP/samples/five_level/coverage.json`). That file is dated 3 November and predates `cmd.timeout`, `cmd.read_failure` and the 38 families.
- Detector rule ids in code today: 42; rule families: 52 (38 runnable); cause keywords: 20 on 7 sides; defect keys in the live store: 1.
- On the four synthetic samples "the 38 runnable families found 16 rows in all, so most families have only been seen on cells changed by a test" (`OPPORTUNITY_COVERAGE_2026-11-15.md`, row S5).

**Is the generator parameterised?**
- Set builder: `--out`, `--only S01,S17,S41`, `--seed` (default 11), `--keep-db`, `--rules-only`, `--split-limit-ms` (`make_five_level_sets.py:93-100`). A scenario is turned into data by passing its card list: `--only <cards> --seed <seed> --data-format hex --cards <atlas json> --target-bytes 0` (`make_five_level_sets.py:38-42`).
- Packet generator options (from the audit): `--seed`, `--target-bytes`, `--only`, `--data-format summary|hex`, `--bg-rate`, `--cards`, `--sidecar-dir` (`owner_assets_audit.md` section 1).
- Build time: 8.4 to 24.5 s per set, 678.2 s for all 59 (`coverage.json`, from the audit). The full 485-card five-level set: exporter "one streaming pass ... peak 0.65 GB RAM, 6.5 min" (`APP/samples/five_level_full/README.md`).
- A recording can be multiplied in size (`APP/tests/make_large_recording.py`, from the audit).

**Material that may limit a public release**
- The export layout is the customer's: "export the five per-level files in the customer's layout" (`make_five_level_sets.py:2-4`); "in the customer's exact column layout" (`APP/data/generator/export_levels.py:2-4`).
- The column lists were transcribed from photos of a customer machine, and the file says so with identifying detail: source "25 screen photos ... 00_overview.csv and COLUMN_NAMES.txt on the customer's Windows machine, C:\Users\admin\Desktop\csv_data\1st_pex\summary; trace 1st_Iteration_Post_on_off.pex, PCIe Protocol Analysis v13.28" (`APP/data/lecroy_export_columns.json`, `source`). A second file holds the indexed headers (`APP/data/customer_headers/ALL_HEADERS_INDEXED_2026-11-03_1st_pex.csv`). A zip of the names sits at the project root (`lecroy_export_column_names.zip`).
- The 113 packet column names came earlier as an input file (`01_input_files/info.txt`, "Column names of csv: Marker, Packet, Link Dir, ..."; `01_input_files/final_113_columns.csv`).
- The application contains an agent built to read "what the analyzer's own decompiled program says": "REA (Reverse Engineer Anything) decompiles the analyzer's program; the findings are a folder of decompiled code and notes as text" (`APP/agentic/rea_agent.py` docstring). No `knowledge/rea` folder is present in the `APP/knowledge/` listing made here.
- The reference library reproduces 615 one-line quotes from Teledyne LeCroy manuals and the NVMe specifications, with their public addresses (`APP/reference_library/teledyne_lecroy_pcie/columns.json`, `sources`). The NVMe specification text itself "is not shipped: it is copyrighted" (`APP/nvme_hier/nvme_command_rules.py` docstring).
- The 485-card generator depends on `01_input_files/PEX_Trace_Error_Atlas_Expanded.html` (2.5 MB, title "PEX Trace Error Atlas") through `atlas_cards_raw.json`. No file read here states who wrote the atlas or under what terms.
- From the audit: the operator-typed device label "phison" appears in one upload's `meta.json` and as an admin name in the older signal table (`owner_assets_audit.md` section 1, Gaps).
- `APP/docs/PROVENANCE_AUDIT.md` (dated 2026-10-26) is about where formulas, thresholds and constants come from (classes NORMATIVE, ADVERTISED, HOST POLICY, MODELED, STATISTICAL IDENTITY, PAPER, USER RULE, ENGINEERING CHOICE). A search of it for "customer", "confiden" and "transcrib" found nothing: it does **not** cover data confidentiality or the column names.
- Every generated artefact is labelled synthetic: "SYNTHETIC DATA: imitates the layout of the Teledyne LeCroy per-level CSV exports; it is not an analyzer export" (`export_levels.py:6`).

### Inferences
- Inferred: unseen scenario sets of chosen size can be produced quickly. A new scenario needs only an id and a list of atlas cards (`build_one` reads `sc["id"]` and `sc["atlas_cards"]`); 485 cards taken 3 to 7 at a time give far more combinations than the 59 on disk, and seeds vary each one. One hundred new sets would take about 20 minutes of machine time at the measured 11.5 s average.
- Inferred: difficulty can be chosen from labels that already exist per card: evidence class (5 values), visibility (3), symptom class (4), layer, and origin (6). There is no single difficulty knob (the audit said the same).
- Inferred: a root-cause task with a known answer can be scored at four grains without new labelling: (i) where: the key packets or the command of the episode; (ii) which layer the fault first shows at (5 values); (iii) whose fault: origin class (6 values) or scenario domain (7 values); (iv) which card (485-way, or among offered candidates as the older engine does). A "known causal chain" exists in the sense of an ordered list of injected episodes per set and the packet-to-command containment; a cross-layer cause graph as such is not a file on disk.
- Inferred: no mapping exists from the truth labels (card, origin, domain) to the application's 20 cause keywords, so "is the application's cause right" cannot be scored today; scoring against origin class needs a small hand-written mapping (origin has 6 values, the keywords' sides have 7).
- Inferred: the column names themselves are probably not secret, since 615 of 637 are matched to lines of public manuals and specifications, but the ordered layout, the counts per level, the customer's file path and trace name, and the fact of transcription from a customer machine are customer-derived. A public data release would need either clearance or a neutral schema (renamed and reordered columns built from the public documents only), and the `source` strings would have to be removed. This is an inference about risk, not legal advice.
- Inferred: the REA agent must stay out of any paper or release; decompiling a vendor's program is a licence question no file here answers.
- Inferred: because the rules and the generator were written by the same project, any detection score of the project's own rules on this data is circular (the project says so). A benchmark is only informative for systems that did not see the generator: language-model agents, or code written by a model from a rule text.

### Gaps
- No file states how many distinct defect keys or cause keywords the 59 sets produce with today's rules; `coverage.json` predates them. Running `make_five_level_sets.py --rules-only` would answer it but was not run (read-only audit).
- Authorship and licence of the PEX Trace Error Atlas: not stated in any file read.
- Whether the employer or customer permits publication of the layout, generator or results: no file answers it (same as the earlier notes).
- The truth files do not label the "true solution" or the true cause keyword; the simulated drive's hidden trigger is the only automatic right-or-wrong signal for a reproduction.
- The validator results for the 485 trace (`03_main_csv_sidecars/validation_report.json`, `spec_conformance_summary.json`) were listed but not opened.

---

## 4. The smallest experiment per candidate that gives a publishable table by 15 December 2026, and which candidates cannot

### Takeaway
Three experiments fit one person in 30 days with honest results: N3 (compiled rule against run-time model, scored against the hidden reference implementation), N5 (column meanings scored against the 615 documented entries) and N4 riding on the logs of both. N1 can be run as one extra axis of N3 but is too thin alone; N2 can be built but not released without clearance; N6 and N7 cannot give a credible top-venue result in 30 days because their outcome signal is a simulated drive or a scripted reviewer built by the same hand.

### Cited Findings (facts the designs rest on)
- A scripted-admin, real-model harness exists and counted 24 calls in 652 s for one rule (`evidence_real_model_run/experiment.py`; `E_real_model_run_on_unknown_csv.md`). In that run "Three cards could not be approved as they stood" and were decided by a person.
- Calls per rule with a model: at least 10 (one file) or 11 (two files), stand-in count (`CHANGES_2026-11-15_round2.md:1006-1016`).
- Reference implementation and Tester comparison exist for 38 families (`command_error_rules.py:741, 1099, 1188`).
- Each family is stored as data with "what / why / how (each sentence with its source), the columns it reads ... its exceptions" (`command_error_rules.py` docstring), i.e. a rule text is available for every family.
- Planted-cell recordings for the families are built in tests ("Every recording is built in a temporary folder with the application's own loader, tree builder and detector", `APP/tests/test_command_error_rules.py` docstring).
- Token usage is now kept per turn on held conversations: `add_turn(... tokens=usage ...)` (`APP/agentic/core.py:1078-1081`); `sessions.sqlite` `turn.tokens` holds e.g. `{"total": 1721, "input": 1641, "output": 7, "reasoning": 73, ...}` (counted here: 3 sessions, 3 turns, producer "DeepSeek V4.1 Flash Free"). The one-shot `ask` path and the OpenAI-compatible class still keep none (audit section 5).
- The second client caches by `sha256(client name | prompt | schema)` (audit); `APP/db/llm_cache.jsonl` has 727 lines today.
- Sampling: Anthropic paths send no temperature; OpenAI-compatible and Ollama send temperature 0 (`APP/stage2/llm_adapter.py:119, 149`; `APP/agentic/core.py:898`).
- Sizes: S17 608 commands; clean recordings 182 to 258 commands; full set 34,608 commands and 8.25 million packets (files cited in Key Question 1).
- Terminal-agent turn times with a real program: 45.3, 15.8, 71.6, 300.1, 41.9, 60.2 s (`F_real_opencode_trial_of_the_recheck.md`, "What was run").

### Inferences (the designs; every number of calls and days below is my estimate)

**N3. Compile once against ask at run time. FEASIBLE; the strongest candidate.**
- Inputs: the 38 runnable rule families as rule texts; recordings: the four clean five-file sets plus planted-cell variants (so that every family has positives), plus one large set for the scaling row.
- Arms: (A) compile: Family 4 writes code once from the rule text, with tests and rounds, then the code runs; (A0) ablation without the data research record (N9); (A1) ablation without the second program and Tester; (B) run time: the model is given the rule text and the rows in chunks and returns the row numbers (must be written); (C) the reference implementation as the oracle.
- Metrics: row-level precision and recall against (C); exact-match rate per rule; tokens and seconds per recording; repeatability (same row set over 3 repeats); and the same across 4 models (this is the N1 axis: variation at authoring time for A, at every run for B).
- Model calls: arm A about 10 to 24 per rule, so 38 × 4 models × 10–24 = 1,520 to 3,650, times 3 repeats = 4,560 to 10,950. Arm B on S17 at 50 commands per call = 13 calls per rule per recording; for 12 families × 5 recordings × 4 models × 3 repeats = 9,360 calls. Scaling row for arm B on the 34,608-command file = 693 calls per rule per model; run it for one or two rules and one cheap model, and report the rest by arithmetic. Wall time for arm A at the measured 652 s per rule would be about 27 hours sequential for 38 × 4, less with calls at once.
- Code still to write: an automatic admin that settles the cards a person settled in the 14 Nov run (ambiguity questions, unsettled data sets) by a fixed policy; the run-time arm; a results collector; token logging on the `ask` path; a per-family planted-case builder lifted from the tests; cache control and a filter for "stand-in" producers.
- Effort: 12 to 16 days. Main risks: Family 4 with a real model has run once and showed three faults (since repaired, untested with a real model); the automatic admin's policy becomes part of the method and must be stated; the oracle and the rule texts come from the same author, so the paper measures agreement with an intended reading, not field truth.

**N5. Column meanings of a wide export. FEASIBLE.**
- Inputs: the 637 library entries as the answer key (615 with a quoted source); the five file headers (up to 1,598 named columns); the synthetic data profiles; a disguised variant of each header made the way `make_input.py` disguised 15 columns.
- Arms: reference documents available or not; web on or off; original names or disguised names; data profile given or not; 4 models.
- Metrics: share of meanings judged right against the key; share carrying a source that code verified; calibration between "verified" and "right"; calls and seconds per 100 columns.
- Model calls: 637 names at 40 per call is about 16 calls per pass plus keyword calls (say 16 to 30); 4 models × 4 to 6 conditions × 3 repeats = 48 to 72 passes = roughly 770 to 2,200 calls.
- Code still to write: a switch that hides the library so the Grounder must work from the documents; the disguise generator for wide headers; a scorer. Scoring needs either `must_say` keys written by hand for a subset (the existing sheet has 15) or a model judge checked by hand on a sample.
- Effort: 8 to 10 days, of which 2 to 3 are writing keys for about 150 columns. Main risks: one tool only; 471 of the 615 sourced entries are NVMe specification fields that models are likely to know by name; the key was written inside this project (quotes are checked against the documents, the meanings were not reviewed by an outside expert); web arm is not repeatable.

**N4. Evidence-checked claims. FEASIBLE as a section, not alone.**
- Design: keep every check outcome from the N3 and N5 runs (claim kind, verified or not, reason; cited-row and sequence problems; requirement verdicts; recheck usable or not) and score each claim against the key or oracle. Report, per model: how many claims had a checkable source; how many failed the check; of those that failed, how many were in fact wrong; of the wrong ones, how many passed. Add a planted-fault recheck trial per family (38 × 4 models ≈ 152 terminal turns at 45 to 72 s each).
- Extra model calls: about 150 beyond N3 and N5. Code: an aggregator over the `evidence` table and step outputs, and a "checks off" switch for the counterfactual. Effort: 5 to 7 days on top of N3 or N5.
- Honest limits already visible on disk: the live table has 0 refused claims, so the base rate may be low; in the one real run most claims had no checkable source (11 of 15), where the check does nothing; a found quote shows the words exist, not that they support the meaning; false statements by the data research model were not caught.

**N1. Model-swap robustness, shipped arm against model-filed arm. FEASIBLE only as an axis of N3; not credible alone.**
- Smallest version: on about 300 errors (10 seeds × 2 bases × 15 injected faults, plus errors of restored families), compare the cause keyword from `decide_cause` (identical for every model by construction) with the keyword each of 4 models picks through the dormant `isolation_prompt`, 3 repeats each: 300 × 4 × 3 = 3,600 calls. Metric: agreement between models (chance-corrected), agreement within a model across repeats, and within a model across window sizes (the product already tests window invariance for the shipped arm).
- Code: revive `isolation_prompt` as an experiment arm, add a model field, control the cache. Effort: 6 to 8 days.
- Why it is thin alone: the shipped arm is a null by construction; the model-filed arm is a variant built for the paper; no truth label says which keyword is right; injected faults are five kinds, so few keyword classes appear; the store holds 0 verdicts, so "stored scores survive" would be shown on scripted tallies only (the red team's S1 and R1 stand).

**N2. Benchmark. BUILDABLE in 30 days, NOT RELEASABLE without clearance; weak as a stand-alone 30-day paper.**
- Smallest version: 100 to 200 freshly generated sets (new card combinations, 3 seeds), a task file per set (find where, which layer, whose fault, which card among k candidates), a scorer against `csv_row_scenario_index.csv`, the project's rule detector and the older engine's published table as non-model baselines, and 4 models as agents through the terminal runtime (`APP/agentic/investigate.py`, a terminal agent that can read a folder's files).
- Model calls: one agent session per set and model with a fixed turn limit; 150 sets × 4 models × 1 repeat = 600 sessions; at the 6-turn pattern of the 15 Nov trial that is about 3,600 turns.
- Code: scorer, task generator, neutral schema, session harness, origin mapping. Effort: 10 to 14 days.
- Why not alone: release depends on the layout question and the atlas authorship; the project's own detector cannot be reported as a competitive baseline (circular); and the audience question from the earlier notes remains.

**N6. Trace to replay test. CANNOT give a credible result in 30 days.**
- Reasons: the "22 of 22" used no model and a fixed template; the simulated drive's fault is made from the plan under test (`sim_fault(plan)`, `testplan.py:321`), so passing shows mechanics only (the code says so); the search was worse than random without the drive's time hint (33 against 37 of 50); `RealBench` raises `NotImplementedError`; no independent emulator is in the project. A table of "plan validity by model" (share of model plans that pass `check_plan` and the two-sided run) could be produced in 6 to 8 days, but it measures the check ladder, which is N4.

**N7. Procedural graph, four typed verdicts, timing on the graph. CANNOT give a credible top-venue result in 30 days.**
- Reasons: 0 real verdicts; the four-verdict ranking has never been measured (the KPI check uses the older store and two signals); the timing result is on a simulated drive with constants "chosen, not measured"; and the project's own result that carried counts alone did not help (26 better, 18 equal, 16 worse) and that stale history was worse in 25 of 30 cases cuts against a positive claim. A simulation table (add the Wilson four-verdict ranker as a fifteenth policy in the 26-suite benchmark; rerun the four-arm timing measurement over more seeds) is 5 to 7 days and could support a workshop note or a limitations section.

**N8 and N9 fold into N3** as ablations (second program on or off; data research record on or off) at the cost of extra arm-A runs: about 38 × 4 × 10 = 1,520 calls per ablation.

### Gaps
- No token count exists for any Family 4 or Family 1 run, so money cannot be estimated from files; the first day of any experiment must measure it.
- Whether the automatic admin can settle every card without a person is unknown; in the only real run three cards needed one.
- Whether four models from two makers are reachable from this machine depends on keys and on what the opencode program offers; no file lists the models available today.
- All effort figures are my estimates for one person working full time; no file supports them.

---

## 5. Which candidates combine into one stronger paper because they share data and code?

### Takeaway
N3, N4 and N1 share one harness and one set of runs: the same 38 rule families, the same recordings and the same hidden reference give accuracy, cost, repeatability, the effect of a model swap, and the share of wrong claims stopped by code. N2 can be the test bed of that paper without being released, and N5 is a separable second study that shares only the claim-checking analysis.

### Cited Findings
- One oracle serves three questions: the Tester "compares its rows with that reference implementation" on the whole recording (`CHANGES_2026-11-15_round2.md:917-932`); the same rows become errors, each with a code-made key and cause (`coded_findings.py` docstring; `terms.py:95`; `evidence.py:564`).
- One flow test already walks rule → code → result → errors → isolation → cause → solution → test on S17 with the stand-in ("Two flow tests show the whole chain on the synthetic sample S17", `OPPORTUNITY_COVERAGE_2026-11-15.md`, second-round row S1).
- The same check outcomes are written for every family of agents into one table (`evidence`: `kind, ref, quote, verified, why`; `APP/db/agentic.sqlite`).
- The generator, the 59 scenarios and the planted-cell builders use the same loader and tree (`make_five_level_sets.py:31-56`; `test_command_error_rules.py` docstring).
- Family 1's dictionaries are an input of Family 4 ("Family 1 is asked through its approved data dictionaries", `family4.py` docstring), so N5 sits upstream of N3.

### Inferences
- Combination A (my first choice on the evidence): **N3 as the finding, N1 as its robustness axis, N4 as the mechanism, the synthetic sets as the test bed.** One table per question, all from the same runs: (1) compiled against run-time accuracy and cost by trace size; (2) spread across four models and across repeats for each arm (the reframed model-swap result: the compiled arm varies once, at authoring, and is then fixed and reviewable; the run-time arm varies at every run); (3) what the code checks and the second program caught. This uses the project's design decision (keep the model out of run-time decisions) as the hypothesis under test instead of as an obstacle, and the shipped product is one of the arms.
- Combination B: **N5 with N4.** "Does a code-checked source predict a correct meaning?" on 637 columns with a documented key. Smaller, cleaner, and independent of Family 4's stability with a real model; a natural fit for an information-retrieval audience because it is about grounding claims in documents.
- Combination C (not advised for 30 days): N2 with N6 or N7. Both partners rest on simulated outcomes.
- Shared-cost note: A and B together need about 20 to 26 person-days by the estimates above, which does not fit 30 days with writing. One of them has to be chosen, or B has to be cut to one model family and 150 columns.
- The link between A and B, if both are wanted later: run arm A of N3 with dictionaries produced under each N5 condition, to show how a wrong or unsourced meaning propagates into rule code. That is a second-month experiment.

### Gaps
- Whether the combined claim is new is for the literature researchers; nothing local speaks to it beyond the outside figures quoted in `reports/Coding research family data first.md`.
- No local evidence shows that the run-time arm would in fact be less accurate or less repeatable on these traces; the one stage-1 reviewer result (51 confirmed, 36 inconclusive of 88) is a different task.

---

## 6. Which model clients are implemented, and what is needed to run four or more models from two or more makers?

### Takeaway
Two client layers with five back-ends between them are implemented: the agent families can call Claude Code, the Anthropic message interface, or the opencode program in a terminal (any provider and model that program lists); the isolation and test steps can call Anthropic (three ways), an OpenAI-compatible endpoint, Ollama, or opencode. Only Anthropic models and one free DeepSeek model through opencode have ever been used; a four-model, two-maker run needs keys or an opencode model list, a per-model results root, token logging on two paths, and control of the cache and of the silent stand-in.

### Cited Findings
- Agent-family runtimes and fallback: `ORDER = {"claude-code": ["claude-code", "http", "standin"], "http": ["http", "standin"], "standin": ["standin"], "opencode": ["opencode", "standin"]}` (`APP/agentic/core.py:524-525`). The opencode runtime: "the opencode program in a terminal, with the model chosen in Settings. Every agent holds a session ... It never falls back to the Model connection" (`core.py:519-522`).
- The HTTP runtime posts to `<base>/v1/messages` with `anthropic-version: 2023-06-01`, body `{model, max_tokens, messages}` (`core.py:898-916`); Anthropic format only.
- opencode models are read from the program itself: "`opencode models --verbose`: a line 'provider/model', then that model's facts" with `cost_in`, `cost_out`, `context` (`APP/agentic/opencode_cli.py:178-180`).
- The second client (`APP/app/stage2_service.py:31-63`, `make_llm`): `standin`; `opencode` (also forced when `server.api_calls` is off); `cli | sdk | http | auto` → `AnthropicLLM`; `openai-compat` → `OpenAICompat(model, base_url, key from the named environment variable)`; `ollama` → `OllamaLLM`, with a silent stand-in if unavailable.
- `OpenAICompat` posts to `<base_url>/chat/completions` with `temperature: 0` and `response_format: json_object` (`APP/stage2/llm_adapter.py:142-155`); `OllamaLLM` uses `temperature: 0` (`:119`); `AnthropicLLM` keeps input, output, cache tokens and a cost figure in memory (`:277, 368-372`).
- One key and one address serve every Anthropic-format caller: "the key is put under the variable the configuration names (llm.api_key_env) and under ANTHROPIC_API_KEY ... the URL (llm.base_url) is put in ANTHROPIC_BASE_URL" (`APP/app/model_env.py` docstring), so a gateway that speaks the Anthropic format can front other makers' models for both layers.
- Current configuration (keys not read): `llm.backend = http`, `llm.model = claude-sonnet-5-5`, `llm.effort = low`, `llm.base_url` empty, `llm.workers = 4`; `agentic.runtime = http`, `agentic.web = True`, `agentic.opencode_model = opencode/deepseek-v4.1-flash-free`, `agentic.f4_recheck = ask` (`APP/config/app_config.json`, read here). These differ from the 12 Nov audit (then `claude-haiku-5-5` and `claude-code`).
- Models actually used, by file evidence: `claude-haiku-5-5` (run 1 isolation steps, `agentic.sqlite` `step.producer`: 3 steps; older reviewer), Claude Code headless (11 steps), `claude-sonnet-5-5` (real-model run of 14 Nov; `APP/runs/exercise_report.md`), DeepSeek V4.1 Flash Free through opencode 1.19.4 (15 Nov trial; `sessions.sqlite`). No log of an OpenAI-compatible or Ollama call was found (same as the audit).
- A model connection test exists (`APP/app/api/hier_api.py:576`), and settings tests for the opencode path (`APP/tests/test_terminal_settings.py`, `test_model_settings.py`).

### Inferences
- Inferred: three routes to four models from two makers, in order of least new code:
  1. **opencode for everything.** Set `agentic.runtime = opencode` and choose a different `agentic.opencode_model` per run. Covers both layers, because the second client becomes `OpencodeLLM` too. Needs: the opencode program logged in to two or more providers. Costs: about 600 MB of memory per call (`core.py:526`), slower turns, and the known fault that a continued session can hang for 300 s.
  2. **An Anthropic-format gateway** (`llm.base_url`) that maps model names to several makers. Covers both layers with no code change. Needs: such a gateway; none is on disk.
  3. **Native clients.** Anthropic models through `http`; other makers through `openai-compat`. Covers only the isolation-side steps today; the agent families would need an OpenAI-format branch in `AgentRunner._http_call` (a small adapter, my estimate one to two days with tests).
- Inferred, needed in every route before numbers are comparable: (a) a throw-away root per model and repeat, as `experiment.py` already does, so dictionaries, rules and caches do not leak between conditions; (b) a repeat number in the cache key or the cache off; (c) rejection of any step whose producer starts with "stand-in"; (d) token counts persisted on the `ask` path and in `OpenAICompat`; (e) the sampling difference stated (no temperature on Anthropic paths, 0 elsewhere) or removed; (f) at least one open-weights model through Ollama or opencode so the result can be re-run after hosted models retire.
- Inferred: the free DeepSeek model used on 15 Nov shows the non-Anthropic path works end to end for one agent, but a "free" tier is not a basis for a grid of thousands of calls ("Free usage limit reached" is a message the code already handles, `core.py:665`).

### Gaps
- Which providers and models the installed opencode offers today, and whether paid keys for a second maker exist, is not in any file read.
- Whether the "company service" endpoint offers several models is unanswered (same gap as the audit).
- No measurement exists of the same step on two different models, so even the size of ordinary between-model variation on this task is unknown.
- Ollama on this laptop (8 processor threads, 22 GB of memory per `APP/docs/CHANGES_2026-11-12.md:130`) was not tried; which open models would run at useful speed is unknown.
