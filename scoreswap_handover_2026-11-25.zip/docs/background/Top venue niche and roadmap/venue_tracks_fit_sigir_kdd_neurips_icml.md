# Realistic tracks at SIGIR 2027, KDD 2027, ICML 2027 and NeurIPS 2027 for a paper with results complete on 15 December 2026 (checked 15 November 2026)

How to read these notes:

- "Verified" = the official page was opened in this pass (15 November 2026). "Counted locally" = an official accepted-paper list was downloaded and counted by script; matches are by title keywords only, so the papers themselves were not read unless a source says otherwise. "Search summary" = a figure returned in a search tool's summary of a page that could not be opened (the ACM Digital Library returned "403 Forbidden"). "Aggregator" = unofficial tracker, cross-check only. "Derived" = my arithmetic on sourced numbers.
- Days are counted from 15 November 2026. AoE = Anywhere on Earth.
- ICML 2027 and TMLR rules, odds and the conditions checklist are in the earlier notes (`Model swap idea leadership pitch/venue_acceptance_path_and_odds.md`) and are not repeated here.
- Paper types: (a) benchmark or dataset for language-model agents doing root-cause analysis on hardware protocol traces; (b) measurement of "model writes an approved rule once, code runs it" against "model answers at run time"; (c) study of evidence-checked agent claims; (d) learning the meaning of columns in unknown wide tables; (e) whether stored human-feedback scores in agent memory survive a change of model.

## 0. Consolidated calendar: every track a paper finished on 15 December 2026 can still enter

### Takeaway

Six doors at the four named venues are open and dated: SIGIR 2027 full papers (21 January), ICML 2027 (22 January), SIGIR 2027 perspectives (4 February), SIGIR 2027 resource, reproducibility and demo tracks (11 February), and two not yet dated but expected in February (KDD 2027 cycle 2 for all tracks; SIGIR 2027 short papers and industry track). NeurIPS 2027 has no page at all; its deadline is an estimate of May 2027.

### Cited Findings

| Venue and track | Abstract / paper deadline | Days left (paper) | Decision | Status of the date | Source |
|---|---|---|---|---|---|
| VLDB 2027 research track (Athens, 23–27 Aug 2027); categories include Experiment, Analysis & Benchmark and Scalable Data Science | Abstract on the 25th of the previous month; paper on the "1st of every month until March 2027", so 1 Jan, 1 Feb, 1 Mar 2027 remain | 47 / 78 / 106 | "15th of the next month following the deadline" | Verified | [VLDB 2027 important dates](https://vldb.org/2027/important-dates.html); [VLDB 2027 research call](https://vldb.org/2027/call-for-research-track.html) |
| DAC 2027 Engineering Track (San Jose, 11–14 Jul 2027) | 11 Jan 2027 (abstract of 100–200 words plus six slides, no paper) | 57 | 8 Mar 2027 | Verified | [DAC 2027 engineering track](https://dac.com/2027/program/back-end-track-submissions) |
| **SIGIR 2027 full papers** (San Jose, 19–24 Jul 2027) | 14 Jan / **21 Jan 2027** AoE; "Full paper submission is not possible without a previously submitted abstract." | 67 | 5 Apr 2027 | Verified | [SIGIR 2027 full-paper call](https://sigir2027.org/pages/submit-full.html) |
| **ICML 2027** main track, six contribution types (Rio de Janeiro, 31 Jul–6 Aug 2027) | 14 Jan / **22 Jan 2027** AoE | 68 | First-stage rejection 23 Feb; final 3 May 2027 | Verified (re-confirmed) | [ICML 2027 Dates](https://icml.cc/Conferences/2027/Dates) |
| SIGIR 2027 workshop proposals (not papers) | 15 Jan 2027; notification 15 Feb 2027 | 61 | — | Verified | [SIGIR 2027 tracks](https://sigir2027.org/pages/submit-tracks.html) |
| SIGIR 2027 perspectives | 28 Jan / 4 Feb 2027 | 81 | 12 Apr 2027 | Verified | [SIGIR 2027 tracks](https://sigir2027.org/pages/submit-tracks.html) |
| **KDD 2027 cycle 2**: research, applied data science, datasets and benchmarks, AI for sciences (San Jose, 1–5 Aug 2027) | Not posted. Estimate: about 31 Jan / 7 Feb 2027 (KDD 2026 cycle 2 was 1 / 8 Feb 2026; KDD 2025 was 3 / 10 Feb 2025) | about 84 | Estimate: mid-May 2027 (2026: 16 May) | Estimate from last two years | [KDD 2027 research call](https://kdd2027.kdd.org/research-track-call-for-papers/); [KDD 2026 research call](https://kdd2026.kdd.org/research-track-call-for-papers/); [KDD 2025 February-cycle call](https://groups.google.com/g/ml-news/c/dWM_vhknfAw) |
| **SIGIR 2027 resource track** | 4 Feb / **11 Feb 2027** | 88 | 5 Apr 2027 | Verified | [SIGIR 2027 resource call](https://sigir2027.org/pages/submit-resource.html) |
| SIGIR 2027 reproducibility and replicability track | 4 Feb / 11 Feb 2027 | 88 | 5 Apr 2027 | Verified | [SIGIR 2027 tracks](https://sigir2027.org/pages/submit-tracks.html) |
| SIGIR 2027 demonstrations | 4 Feb / 11 Feb 2027 | 88 | 5 Apr 2027 | Verified | [SIGIR 2027 tracks](https://sigir2027.org/pages/submit-tracks.html) |
| SIGIR 2027 short papers | "TBD". Estimate: about 4 / 11 Feb 2027 (SIGIR 2026: 5 / 12 Feb 2026) | about 88 | Estimate: early April | Estimate | [SIGIR 2027 tracks](https://sigir2027.org/pages/submit-tracks.html); SIGIR 2026 dates from the site's key-dates data, see section 1 |
| SIGIR 2027 industry track (SIRIP) | "TBA". Estimate: about 18 / 25 Feb 2027 (SIGIR 2026: 19 / 26 Feb 2026) | about 102 | Estimate: early April | Estimate | [SIGIR 2027 industry page](https://sigir2027.org/pages/submit-industry.html); [SIGIR 2026 industry track](https://sigir2026.org/en-AU/pages/submissions/industry-track) |
| IEEE International Test Conference 2027 (San Antonio, 10–15 Oct 2027) | Title and abstract 5 Mar 2027; final PDF 9 Apr 2027; posters 9 Jul 2027 | 110 | 1 Jun 2027 | Verified (call PDF read) | [ITC 2027 call](https://www.itctestweek.org/wp-content/uploads/2026/10/ITC_2027_CFP_v2026Oct10.pdf) |
| SIGIR 2027 workshop papers (workshop day 23 Jul 2027) | "Suggested workshop paper submission: 17 April 2027 (recommended)" | 153 | 17 May 2027 (recommended) | Verified; list of workshops not known before 15 Feb 2027 | [SIGIR 2027 tracks](https://sigir2027.org/pages/submit-tracks.html) |
| **NeurIPS 2027** main and Evaluations and Datasets tracks | No 2027 page (address returns "404"). Estimate: early to mid May 2027 (2026: 4 / 6 May; one tracker projects 14 / 21 May 2027) | about 170–185 | Estimate: late Sep 2027 (2026: 24 Sep) | Estimate | [NeurIPS future meetings](https://neurips.cc/Conferences/FutureMeetings); [NeurIPS 2026 E&D call](https://neurips.cc/Conferences/2026/CallForEvaluationsDatasets); [tracker](https://www.opencurious.com/ai-conference-deadlines/neurips-2027) |

Closed for a mid-December paper (confirmed): KDD 2027 cycle 1 (abstract 19 July, paper 26 July, notification 14 November 2026) — [KDD 2027 research call](https://kdd2027.kdd.org/research-track-call-for-papers/); WWW 2027 (paper 25 October 2026, aggregator) — [tracker](https://mldeadlines.com/conference/www-2027/); SIGMOD 2027 research (round 4 was 17 October 2026) — [SIGMOD 2027 dates](https://2027.sigmodconf.hosting.acm.org/calls_papers_important_dates.shtml); ICDE 2027 round 2 (11 November 2026, aggregator) — [tracker](https://www.myhuiban.com/conference/135).

### Inferences

- From results on 15 December there are 37 days to the SIGIR full-paper deadline and 38 to ICML; the SIGIR resource track and KDD cycle 2 give 55 to 58 days. The February group is the realistic writing window for one person.
- SIGIR full papers (21 January) and ICML (22 January) forbid parallel submission of the same work, so one manuscript can use only one of them; two different papers (for example type (c) at SIGIR and type (e) at ICML) could use both, but that is two papers in five weeks.
- Three conferences sit in San Jose within four weeks (DAC 11–14 July, SIGIR 19–24 July, KDD 1–5 August 2027). ICML's main days in Rio (2–4 August) overlap KDD (1–5 August); one person cannot present in person at both.

### Gaps

- KDD 2027 cycle 2, SIGIR 2027 short papers, SIGIR 2027 industry track and all of NeurIPS 2027 have no posted dates. Every value marked "Estimate" comes from the previous year.
- SIGIR 2026's short-paper dates come from a key-dates block embedded in the 2026 site data whose own page is unpublished ("Page Not Found"); the public 2026 resource and industry pages confirm the neighbouring dates.

## 1. SIGIR 2027: location, tracks, scope and the desk-rejection risk

### Takeaway

SIGIR 2027 is the 50th conference, in person in San Jose, 19–24 July 2027; the full-paper, resource, reproducibility, perspectives, demo, tutorial and workshop calls are posted, the short-paper and industry calls are not. Agentic retrieval, retrieval-augmented generation, grounding and attribution, table search ("Search in structured data") and agent simulators are in scope, but the call says the retrieval or access problem must drive the work and lists "Clear lack of topical fit for SIGIR" as a desk-rejection ground, so a paper with no retrieval component is at real risk of desk rejection.

### Cited Findings

**Place and dates**

- Signia by Hilton San Jose, California; tutorials 19 July, main conference 20–22 July, workshops 23 July, ICTIR 24 July 2027; doctoral colloquium 18 July. — [SIGIR 2027](https://sigir2027.org/); [SIGIR 2027 tracks](https://sigir2027.org/pages/submit-tracks.html)
- Posted calls and dates are in the calendar in section 0. Camera-ready and author registration for all posted tracks: 30 April 2027. No low-resource-environments call is listed for 2027. — [SIGIR 2027 tracks](https://sigir2027.org/pages/submit-tracks.html)
- SIGIR 2026 values used as estimates: full 15 / 22 January; reproducibility, perspectives, short, demo, resource 5 / 12 February; industry 19 / 26 February; all announcements 2 April 2026; conference 20–24 July 2026, Melbourne. — [SIGIR 2026 resource track](https://sigir2026.org/en-AU/pages/submissions/resources-track); [SIGIR 2026 industry track](https://sigir2026.org/en-AU/pages/submissions/industry-track)

**Full-paper rules (2027, verified)**

- 9 pages including appendices, unlimited references, double-anonymous, ACM two-column format. Each submission needs one author who agrees to serve as a reviewer. No per-author cap is stated. Concurrent submission to other venues or other SIGIR 2027 tracks is prohibited. — [SIGIR 2027 full-paper call](https://sigir2027.org/pages/submit-full.html)
- Desk-rejection grounds include an incomplete OpenReview profile, author changes after the abstract deadline, "Clear lack of topical fit for SIGIR." and "Obvious anonymity violations." — [SIGIR 2027 full-paper call](https://sigir2027.org/pages/submit-full.html)
- "All submissions must comply with the ACM policy on the use of Artificial Intelligence." — [SIGIR 2027 full-paper call](https://sigir2027.org/pages/submit-full.html)
- The 2027 policies page (in-person or hybrid policy, pre-print and anonymity policy, author FAQ) is "TBA". — [SIGIR 2027 policies](https://sigir2027.org/pages/policies.html)

**Topics in the 2027 call (verified)**

- Changes this year: "Agentic IR is now a standalone topic area."; "New topic area: Information Access through Generative AI."; "The emphasis is on models that advance retrieval and access, not on general model research evaluated on IR benchmarks." — [SIGIR 2027 full-paper call](https://sigir2027.org/pages/submit-full.html)
- Agentic IR bullets: "Tool-augmented and API-augmented retrieval."; "Multi-step search planning and execution."; "Autonomous web agents for information tasks."; "Agentic RAG, including orchestrating retrieval, reasoning, and action."; "Intelligent personal assistants and agents." — [SIGIR 2027 full-paper call](https://sigir2027.org/pages/submit-full.html)
- Evaluation bullets include "Evaluation frameworks for agentic and multi-step IR.", "Measuring groundedness, hallucination, and factual accuracy in generative retrieval.", "Evaluation of agentic IR systems (correctness, safety, cost, latency)." and "Simulation for evaluation." — [SIGIR 2027 full-paper call](https://sigir2027.org/pages/submit-full.html)
- Foundation-models area includes "Retrieval Augmented Generation (RAG) and retrieval-augmented reasoning."; the systems area includes "Inference cost optimization for neural retrieval and generative components."; the domain-specific area includes "Search in structured data." and "Other applications and domains." — [SIGIR 2027 full-paper call](https://sigir2027.org/pages/submit-full.html)
- Not named anywhere in the call: agent memory, logs, traces, hardware. (Page-reader statement.) — [SIGIR 2027 full-paper call](https://sigir2027.org/pages/submit-full.html)

**Resource track (2027, verified)**

- Listed resource kinds include "Test collections and relevance judgments for information retrieval and access tasks.", "Datasets and corpora for training, adapting and evaluating models for retrieval and information access, including foundation models." and "Environments and simulators for information retrieval and access tasks." — [SIGIR 2027 resource call](https://sigir2027.org/pages/submit-resource.html)
- "Resources created partly or entirely with generative AI are eligible."; "Resources for the two new areas of SIGIR 2027, agentic IR and information access through generative AI, are particularly welcome." — [SIGIR 2027 resource call](https://sigir2027.org/pages/submit-resource.html)
- Single-anonymous; "Papers must not exceed 6 pages" plus references; criteria are novelty, availability, utility and predicted impact; no rebuttal; the resource must be reachable by reviewers "from submission until notification, through a link given in the paper." — [SIGIR 2027 resource call](https://sigir2027.org/pages/submit-resource.html)
- "At least one author must register for the conference by April 30, 2027 and present the paper at the conference." — [SIGIR 2027 resource call](https://sigir2027.org/pages/submit-resource.html)

**Industry track (2026 text; the 2027 page says only "TBA.")**

- Proposals "should be 2-4 pages (excluding references)", with author names and a presenter biography; categories include "Innovative approaches used in deployed systems and products, domain specific challenges are welcome.", "Open problems and challenges in industry, from industry research to production." and "Novel applications of LLM and IR in agentic workflows." — [SIGIR 2026 industry track](https://sigir2026.org/en-AU/pages/submissions/industry-track)
- "A condition of acceptance is that at least one author commits to registering and attending Industry Track 2026 (in-person) to present the work." Accepted proposals are included in the proceedings. — [SIGIR 2026 industry track](https://sigir2026.org/en-AU/pages/submissions/industry-track)

**Acceptance figures**

| Year | Track | Accepted | Submitted | Rate | Kind of source | Source |
|---|---|---|---|---|---|---|
| 2026 | Full papers | 234 | 1,271 | 18% | Accepted count official; rate from ACM Digital Library (search summary); aggregator gives 233 of 1,271 = 18.3% | [SIGIR 2026 accepted papers](https://sigir2026.org/en-AU/pages/program/accepted-papers); [ACM DL SIGIR '26](https://dl.acm.org/doi/proceedings/10.1145/3805712); [stats site](https://csconfstats.xoveexu.com/conferences/sigir/2026/) |
| 2026 | Short / resource / reproducibility / perspective / demo / industry / low-resource | 151 / 61 / 28 / 12 / 24 / 131 / 15 | not found | not found | Official legend ("A total of 656 papers will be presented") | [SIGIR 2026 accepted papers](https://sigir2026.org/en-AU/pages/program/accepted-papers) |
| 2026 | Unlabelled second track | 149 | 455 | 32.7% | Aggregator, via search summary; track name not given | [stats site](https://csconfstats.xoveexu.com/conferences/sigir/2026/) |
| 2025 | Full papers | 239 (counted locally) | 1,071 | 22.3% | Aggregator for rate and submissions; count from the official list | [SIGIR 2025 accepted papers](https://sigir2025.dei.unipd.it/accepted-papers.html); [stats site](https://csconfstats.xoveexu.com/conferences/sigir/2026/) |
| 2025 | Short / resource and reproducibility / demo / perspectives / low-resource / industry (SIRIP) | 106 / 71 / 26 / 10 / 10 / 51 | not found | not found | Counted locally from the official list | [SIGIR 2025 accepted papers](https://sigir2025.dei.unipd.it/accepted-papers.html) |

**Cost note**

- From 1 January 2026 ACM proceedings are fully open access; authors whose institutions are not in ACM Open "will need to pay an APC", and the SIGIR 2026 policy page lists a "$USD250 APC for ACM/SIG members" tier. This applies to SIGIR and KDD alike (both ACM). — [SIGIR 2026 submission policies](https://sigir2026.org/en-AU/pages/submissions/submission-policies-and-information)

### Inferences

- Scope answer: types (c) and (d) can be written as retrieval papers (finding and citing the evidence rows that support a claim; finding the right columns in an unknown wide table is "Search in structured data"). Types (a), (b) and (e) have no retrieval problem at their centre. Given the stated desk-rejection ground and the "not on general model research" sentence, I judge that (a), (b) and (e) submitted to the full-paper track unchanged would probably be desk-rejected or scored as out of scope. No source gives a count of scope desk rejections, so this is judgement.
- Every SIGIR 2025 and 2026 title that matched my keyword lists (tables, memory, traces, incidents) is tied to search, recommendation, conversation or retrieval-augmented generation (section 6). That is consistent with the scope reading above.
- The resource track is the lowest bar at SIGIR for a solo author: six pages, single-anonymous, no rebuttal, synthetic and generated resources explicitly eligible, simulators named. It still needs an information-access framing (for example "a test collection for evidence retrieval over protocol traces").
- The unlabelled 149 of 455 (32.7%) is close to the official count of 151 short papers, so it is probably the short-paper track; this is a guess and should not be quoted as a documented short-paper rate.
- The industry track grew from 51 accepted (2025) to 131 (2026). Its wording ("as deployed in companies") favours deployed systems, but "Open problems and challenges in industry" does not require deployment.

### Gaps

- SIGIR 2027 short-paper and industry calls, and the attendance, pre-print and satellite-presentation policy pages, are not posted.
- No submitted counts for any SIGIR track other than full papers in 2025 or 2026; the proceedings front matter could not be opened.
- The SIGIR 2025 rate rests on an aggregator. The ACM Digital Library page for SIGIR '25 shows only a cumulative series figure ("1,134 of 5,797 submissions, 20%", search summary) and no 2025 paper rate. — [ACM DL SIGIR '25](https://dl.acm.org/doi/proceedings/10.1145/3726302)

## 2. KDD 2027: cycles, tracks, deployment rule and sole authors

### Takeaway

KDD 2027 is in San Jose, 1–5 August 2027, with four tracks (research, applied data science, datasets and benchmarks, AI for sciences); cycle 1 closed in July 2026 and a mid-December paper can only enter cycle 2, whose dates are not posted (expected early February 2027). The applied track desk-rejects anything not deployed with post-launch numbers, so synthetic-only work is shut out there; the datasets and benchmarks track is open to data generators and synthetic data but requires that representativeness be quantified.

### Cited Findings

**Place, tracks, cycles**

- "ACM KDD 2027, San Jose, United States", 1–5 August 2027, San Jose McEnery Convention Center. Calls exist for the Research Track, Applied Data Science (ADS) Track, Datasets and Benchmarks Track and AI for Sciences Track. — [KDD 2027](https://kdd2027.kdd.org/)
- Cycle 1 (all three calls read): abstract 19 July 2026, paper 26 July 2026, rebuttal 29 September to 13 October, notification 14 November 2026. No cycle 2 dates on any call; the ADS call mentions a "Jan/Feb 2027 deadline" only in its resubmission text. — [KDD 2027 research call](https://kdd2027.kdd.org/research-track-call-for-papers/); [KDD 2027 ADS call](https://kdd2027.kdd.org/applied-data-science-ads-track-call-for-papers/); [KDD 2027 datasets and benchmarks call](https://kdd2027.kdd.org/datasets-and-benchmarks-track-call-for-papers/)
- KDD 2026 cycle 2 for comparison: abstract 1 February, paper 8 February, rebuttal from 4 April, notification 16 May 2026; conference 9–13 August 2026, Jeju. — [KDD 2026 research call](https://kdd2026.kdd.org/research-track-call-for-papers/)

**Research track rules (verified)**

- Double-blind; "8 (eight) content pages as main paper, followed by references and an optional Appendix that has no page limits."; preprints allowed; at most 7 submissions per author per cycle. — [KDD 2027 research call](https://kdd2027.kdd.org/research-track-call-for-papers/)
- "Every submission must nominate at least one author who is a qualified reviewer", meaning "authors with at least three papers in KDD or other related conferences". No rule on sole authors is stated. — [KDD 2027 research call](https://kdd2027.kdd.org/research-track-call-for-papers/)
- Topics name large language models and "time series, text, graphs, Internet of Things (IoT) data"; language-model agents, AIOps and anomaly detection are not named. (Page-reader statement.) — [KDD 2027 research call](https://kdd2027.kdd.org/research-track-call-for-papers/)

**Applied data science track (verified)**

- "Submissions must include a quantification of the post-launch performance of the described system or solution." "Submissions that do not provide this quantification will be desk-rejected without review." "This is a strict requirement." — [KDD 2027 ADS call](https://kdd2027.kdd.org/applied-data-science-ads-track-call-for-papers/)
- Desk-rejected: "Applications that are tested offline on real-world data, but have not been deployed live to users." For blocked deployments, "we are open to alternative definitions of deployment, such as controlled or limited-scale pilots". — [KDD 2027 ADS call](https://kdd2027.kdd.org/applied-data-science-ads-track-call-for-papers/)
- Single-blind: "author names and affiliations should be listed." The call does not mention synthetic data. — [KDD 2027 ADS call](https://kdd2027.kdd.org/applied-data-science-ads-track-call-for-papers/)

**Datasets and benchmarks track (exists in 2027; verified)**

- Scope: "The Datasets and Benchmarks Track is dedicated to fostering the development, sharing, and evaluation of datasets and benchmarks that are valuable for the KDD community." Accepted kinds include new datasets, benchmarks and benchmarking tools, and "Data generators and environments". — [KDD 2027 datasets and benchmarks call](https://kdd2027.kdd.org/datasets-and-benchmarks-track-call-for-papers/)
- "Synthetic data must be accompanied with a quantification and a discussion of its representativeness". — [KDD 2027 datasets and benchmarks call](https://kdd2027.kdd.org/datasets-and-benchmarks-track-call-for-papers/)
- "Datasets should be easily accessible to the research community without requiring personal requests." Code and tools must be open source. Croissant is not mentioned; "Documentation should include metadata, data collection methods, and any preprocessing steps." — [KDD 2027 datasets and benchmarks call](https://kdd2027.kdd.org/datasets-and-benchmarks-track-call-for-papers/)
- "The review process for the Datasets & Benchmarks Track will be single-blind." Eight content pages. Criteria: accessibility, quality and documentation, impact, ethics and fairness. Same reviewer-nomination rule; if no author qualifies, nominate the best-qualified author. — [KDD 2027 datasets and benchmarks call](https://kdd2027.kdd.org/datasets-and-benchmarks-track-call-for-papers/)

**Presentation (all tracks, verified)**

- "Every accepted paper must be presented at the conference." "Only a portion of accepted papers will be selected to present orally at the conference." "No-show papers may be withdrawn from the conference program and proceedings where it applies." Registration must be "Full Conference (5-day) registration" at the "standard (non-student) in-person rate"; "This registration requirement applies universally, regardless of attendance or presentation mode." — [KDD 2027 research call](https://kdd2027.kdd.org/research-track-call-for-papers/); [KDD 2027 ADS call](https://kdd2027.kdd.org/applied-data-science-ads-track-call-for-papers/)

**Acceptance figures**

| Year | Scope | Accepted | Submitted | Rate | Kind of source | Source |
|---|---|---|---|---|---|---|
| 2025 | Research track | 552 | 2,955 | 18.68% | Community database; accepted count matches the official list (counted locally) | [OpenAccept KDD](https://openaccept.org/c/dm/kdd/); [KDD 2025 research papers](https://kdd2025.kdd.org/research-track-papers-2/) |
| 2025 | Applied data science | 155 | 816 | 19.00% | Community database; count matches the official list | [OpenAccept KDD](https://openaccept.org/c/dm/kdd/); [KDD 2025 ADS papers](https://kdd2025.kdd.org/applied-data-science-ads-track-papers-2/) |
| 2025 | Datasets and benchmarks | 64 (counted locally) | not found | not found | Official list | [KDD 2025 datasets and benchmarks papers](https://kdd2025.kdd.org/datasets-and-benchmarks-track-papers-2/) |
| 2026 | Cycle 1, all tracks | 256 | 1,215 | 21% | ACM Digital Library (search summary); the official list also has 256 cycle-1 entries | [ACM DL KDD '26 V.1](https://dl.acm.org/doi/proceedings/10.1145/3770854); [KDD 2026 papers](https://kdd2026.kdd.org/papers/) |
| 2026 | Cycle 2, all tracks | 1,157 | 5,395 | 21% | ACM Digital Library (search summary); the official list has 1,159 cycle-2 entries | [ACM DL KDD '26 V.2](https://dl.acm.org/doi/proceedings/10.1145/3770855); [KDD 2026 papers](https://kdd2026.kdd.org/papers/) |
| 2026 | Cycle 1 research / ADS | 183 / 44 (official list) | 912 / 205 | "approximately 20%" / "approximately 22%" | Low-reliability wiki, via search summary | [Baidu Baike KDD 2026](https://baike.baidu.com/en/item/KDD%202026/3363165) |
| 2026 | Accepted per track, both cycles | Research 787, ADS 186, datasets and benchmarks 182, AI for sciences 243, blue sky 17 | not found | not found | Counted locally from the official list (7 titles appear twice and are not removed: 2 research, 5 AI for sciences) | [KDD 2026 papers](https://kdd2026.kdd.org/papers/) |

### Inferences

- A December 2026 paper enters KDD 2027 only through cycle 2. Planning date: first week of February 2027, to be confirmed on the official call.
- Applied data science track: shut. The rule rejects even offline tests on real data; synthetic-only work sits below that line. The only opening is the "limited-scale pilots" exception, which would need real use by engineers with measured results.
- Datasets and benchmarks track: open in principle to a fault-injecting generator plus benchmark, but the representativeness sentence is a direct obstacle for data that is "all synthetic with known ground truth". Some comparison against real analyzer recordings (even private ones, reported as statistics) would be needed to meet it.
- Derived, low confidence: if the wiki's cycle-1 counts are right, datasets and benchmarks had about 1,215 − 912 − 205 = 98 cycle-1 submissions and 29 acceptances, about 30%. This mixes an ACM total with wiki figures and should not be quoted as documented.
- The reviewer rule does not bar a first-time sole author (nominate the best-qualified author), but the track's accepted lists show how rare that is: zero sole-author papers in the applied track in 2025 and 2026, and one in two years of the datasets track (section 6).

### Gaps

- Cycle 2 dates for KDD 2027 are not posted; the datasets and benchmarks call still contains the placeholder "<INSERT DATES>".
- No official per-track acceptance rate for the datasets and benchmarks track in any year, and none for any 2026 track; the proceedings front matter could not be opened.
- No accepted applied-track paper was checked for data provenance, so "synthetic-only industrial work has never been accepted there" is not proven; the call's wording makes it very unlikely.
- Oral-versus-poster shares at KDD are not published in the calls.

## 3. NeurIPS 2027: status, and the 2026 Evaluations and Datasets rules

### Takeaway

Nothing is posted for NeurIPS 2027 except the region ("Europe"). The 2026 Evaluations and Datasets track (renamed from Datasets and Benchmarks) is the best guide: double-blind by default, Croissant metadata mandatory for datasets, hosting on a public machine-learning data host, code mandatory when the contribution is an executable artifact such as a data generator, no rule against synthetic data, and an acceptance rate that tracked the main track at about 25% when last published.

### Cited Findings

- The NeurIPS 2027 conference address returns "404 Not Found"; the future-meetings page lists 2027 as Europe and 2028 as Western United States, with no city or dates; the official blog (posts to 8 November 2026) says nothing about 2027. — [NeurIPS future meetings](https://neurips.cc/Conferences/FutureMeetings); [NeurIPS blog](https://blog.neurips.cc/)
- 2026 track dates: portal opened 15 April 2026; abstract "May 4, 2026 (AoE)"; full paper "May 6, 2026 (AoE)"; notification "September 24, 2026 (AoE)". — [NeurIPS 2026 E&D call](https://neurips.cc/Conferences/2026/CallForEvaluationsDatasets)
- Scope: evaluation is "an object of scientific study in its own right." Accepted work includes "New datasets and dataset collections" and "Data generators and reinforcement learning environments." "Submissions need not introduce a new model or outperform prior work." — [NeurIPS 2026 E&D call](https://neurips.cc/Conferences/2026/CallForEvaluationsDatasets)
- Review mode: "The default review mode for the E&D Track is now double-blind."; authors whose datasets cannot be anonymised select single-blind. — [NeurIPS 2026 E&D call](https://neurips.cc/Conferences/2026/CallForEvaluationsDatasets)
- Hosting and metadata: "New datasets should remain available long-term."; hosts named are "Dataverse, Kaggle, Hugging Face, or OpenML."; datasets over 4GB must include "a small sample of the data"; "Authors of datasets must use the Croissant machine-readable format to document their datasets." with "both core and Responsible AI (RAI) fields of the Croissant format." — [NeurIPS 2026 E&D call](https://neurips.cc/Conferences/2026/CallForEvaluationsDatasets)
- Reviewer side: "All submissions that contribute datasets are required to provide a valid Croissant file."; "Datasets should be available to all reviewers, ACs, and SACs at the time of submission."; for reusable artifacts "such as an evaluation toolkit, benchmarking platform, or data generator." "code release is mandatory at the time of submission". — [NeurIPS 2026 E&D reviewer guidelines](https://neurips.cc/Conferences/2026/EvaluationsDatasetsReviewerGuidelines)
- Criteria: quality, clarity, significance, originality; "Originality does not necessarily require introducing an entirely new method."; "Negative results are valuable when rigorously supported."; "You do not have to match the conference acceptance rate." — [NeurIPS 2026 E&D reviewer guidelines](https://neurips.cc/Conferences/2026/EvaluationsDatasetsReviewerGuidelines)
- Synthetic data: neither the call nor the reviewer guidelines has a statement on synthetic or simulated data. (Page-reader statements on both pages.) — [NeurIPS 2026 E&D call](https://neurips.cc/Conferences/2026/CallForEvaluationsDatasets); [NeurIPS 2026 E&D reviewer guidelines](https://neurips.cc/Conferences/2026/EvaluationsDatasetsReviewerGuidelines)
- Presentation: accepted papers are "presented at the conference alongside main track papers." — [NeurIPS 2026 E&D call](https://neurips.cc/Conferences/2026/CallForEvaluationsDatasets)
- Rates: 2024 Datasets and Benchmarks 25.3%, which "closely mirror[ed] the main program's 25.8% rate"; 2025 "the track received 1,995 submissions this year." (no accepted count in the post). — [NeurIPS blog, D&B chairs 2025](https://blog.neurips.cc/2025/09/30/reflecting-on-the-2025-review-process-from-the-datasets-and-benchmarks-chairs/)
- Counted locally: the official NeurIPS 2025 list has 497 unique titles from the Datasets and Benchmarks track; the official NeurIPS 2026 list has 971 unique titles from the Evaluations and Datasets track. — [NeurIPS 2025 data](https://neurips.cc/static/virtual/data/neurips-2025-orals-posters.json); [NeurIPS 2026 data](https://neurips.cc/static/virtual/data/neurips-2026-orals-posters.json); contradicted for 2026 by an aggregator showing 697 accepted with "submission total … unavailable" — [Paper Copilot](https://papercopilot.com/venue-overview/neurips-2026-venue-overview-evaluations-datasets-track/)
- 2026 accepted titles in the track with "synthetic", "simulat…", "generator", "generated" or "procedural" in the title: 47 of 971; in 2025: 23 of 497 (counted locally). — [NeurIPS 2026 data](https://neurips.cc/static/virtual/data/neurips-2026-orals-posters.json); [NeurIPS 2025 data](https://neurips.cc/static/virtual/data/neurips-2025-orals-posters.json)

### Inferences

- Derived: 497 of 1,995 gives about 24.9% for the 2025 Datasets and Benchmarks track, in line with 25.3% in 2024. This assumes the official list is complete for the track.
- The track nearly doubled in accepted papers from 2025 to 2026 (497 to 971 on the official lists). Without a 2026 submission count no 2026 rate can be stated.
- Synthetic data is not a rule problem at NeurIPS. The accepted synthetic-data benchmark closest to this author's domain (SLS-Bench, section 6) derived its synthetic logs from real incident reports and compared them statistically with real log streams, so reviewers there do expect a realism argument.
- For a fault-injecting generator the practical checklist is: public repository with the generator (mandatory at submission), a hosted sample dataset on Hugging Face or Kaggle with a valid Croissant file including the Responsible AI fields, and an anonymised version for double-blind review. Employer clearance must come before May 2027.

### Gaps

- NeurIPS 2027 city, dates, tracks and whether the Evaluations and Datasets track continues: not posted.
- No official 2026 statistics for the track (submissions, rate). The accepted count conflicts between the official list (971, my count) and an aggregator (697).
- The 2026 attendance rule for the track was not on the pages read; the earlier pass recorded that one author had to register for the main conference.

## 4. ICML 2027: dates and contribution types re-confirmed

### Takeaway

Nothing has changed since the earlier pass: abstract 14 January, paper 22 January 2027, six contribution types, and "Datasets, Evaluations and Benchmarks" is a contribution type inside the single main track, not a separate track.

### Cited Findings

- Dates: paper submission opens "Jan 08 '27"; abstract "Jan 14 '27 (Anywhere on Earth)"; full paper "Jan 22 '27 (Anywhere on Earth)"; first-stage rejection notification "Feb 23 '27"; final decisions "May 03 '27"; main conference Monday 2 to Wednesday 4 August, workshops 5–6 August 2027. — [ICML 2027 Dates](https://icml.cc/Conferences/2027/Dates)
- The six types: "General", "Theory", "Application-driven", "Concept and Feasibility", "Negative Results", "Datasets, Evaluations and Benchmarks". — [ICML 2027 Contribution Types](https://icml.cc/Conferences/2027/ContributionTypes)
- Meaning of the sixth type: chosen "when the primary contribution advances the resources, methods, or scientific understanding used to evaluate machine learning systems." Listed examples include "introducing a new benchmark or substantially redesigning an existing benchmark", "auditing or stress testing machine learning systems" and "conducting substantive data centric or evaluation focused empirical analyses that lead to new scientific understanding". — [ICML 2027 Contribution Types](https://icml.cc/Conferences/2027/ContributionTypes)
- "A Datasets, Evaluations and Benchmarks contribution does **not** need to introduce a new learning algorithm."; "A new dataset or benchmark should not be evaluated primarily according to whether it enables a new state of the art result." — [ICML 2027 Contribution Types](https://icml.cc/Conferences/2027/ContributionTypes)
- Reviewer treatment: "Reviewers should evaluate the submission according to the Contribution Type selected by the authors"; "The review form may differ across Contribution Types"; "A paper should not be penalized for lacking a form of evidence that is not necessary to establish its primary contribution." — [ICML 2027 Contribution Types](https://icml.cc/Conferences/2027/ContributionTypes)

### Inferences

- ICML has no Croissant or hosting rule in what was read, so for type (a) it is lighter on mechanics than NeurIPS, and it is the only dated top machine-learning door before May 2027.
- Types (b) and (e) match the "auditing or stress testing" and "evaluation focused empirical analyses" wording; type (a) matches "introducing a new benchmark".

### Gaps

- Per-type review forms and the reviewer guidance are still not posted, so how reviewers will weigh a single-domain synthetic benchmark under this type is unknown.

## 5. Other A-grade venues with deadlines from mid-December 2026 to March 2027

### Takeaway

Three venues not named by the author fit specific paper types better than SIGIR does: VLDB 2027 (monthly deadlines to 1 March 2027; a named category for experiment-and-analysis papers) for types (b) and (d), the IEEE International Test Conference 2027 (abstract 5 March 2027; "LLM- & Agent-Assisted Test" and "Protocol-Aware Test" are listed topics) for the storage-analysis tool itself, and the DAC 2027 Engineering Track (11 January 2027; six slides, no paper) as the cheapest way to stand in front of a hardware audience.

### Cited Findings

| Venue | Deadline and track | Fit in one line | Source |
|---|---|---|---|
| VLDB 2027 (Athens, 23–27 Aug 2027) | 1 Jan, 1 Feb, 1 Mar 2027 (last three); decisions on the 15th of the following month. Categories: Regular Research; Experiment, Analysis & Benchmark; Scalable Data Science; Vision. "All papers accepted for Volume 20 by July 1, 2027 will form the Research Track". "At least one author of each accepted paper must attend the VLDB 2027 Conference." | Good for (b) as an experiment-and-analysis paper on millions-of-rows tables and for (d) as data management research; "LLM-assisted data processing" is a listed topic; Scalable Data Science expects real deployment | [VLDB 2027 research call](https://vldb.org/2027/call-for-research-track.html); [VLDB 2027 important dates](https://vldb.org/2027/important-dates.html) |
| ACL 2027 via ACL Rolling Review (Kyoto, 17–22 Aug 2027) | ARR 4 Jan 2027 (earlier pass) | Only (c) fits (attribution, faithfulness); 20 days after results; review not guaranteed without a qualified service contributor | [ACL 2027](https://2027.aclweb.org/); [ARR call](https://aclrollingreview.org/cfp) |
| IJCAI 2027 (Kyoto, 7–13 Aug 2027) | Abstract 4 Jan, paper 11 Jan 2027 (earlier pass) | Possible for (a) or (e) but lower rate, 7-page body, strict rule that LLMs may only polish the author's own text | [IJCAI 2027 call](https://2027.ijcai.org/ijcai-2027-call-for-papers-main-track/) |
| DAC 2027 Engineering Track (San Jose, 11–14 Jul 2027) | 11 Jan 2027; notification 8 Mar 2027; abstract plus six slides; 15-minute talk plus poster, or poster only; topic "Manufacturing test and silicon debug"; not in the proceedings | A talk to hardware engineers about the tool; no archival paper, so it does not block any later submission | [DAC 2027 engineering track](https://dac.com/2027/program/back-end-track-submissions) |
| DAC 2027 research track | Abstract 11 Nov 2026 (earlier pass) | Closed | [DAC 2027](https://dac.com/2027/program/research-manuscript-submissions) |
| ACM SIGOPS ATC 2027 (Rennes, 28 Jun–1 Jul 2027) | 19 Jan 2027 (earlier pass) | Poor: systems research with no experience track | [ATC 2027](https://atc.sigops.org/2027/) |
| USENIX FAST '27 / FAST '28 | FAST '27 closed 15 Sep 2026; FAST '28 spring deadline about mid-March 2027 by pattern, no call (earlier pass) | Storage systems research; an analysis tool for protocol traces is at the edge of scope | [FAST '27 call](https://www.usenix.org/conference/fast27/call-for-papers) |
| FSE 2027 Industry Papers (Shenzhen, 12–16 Jul 2027) | 23 Jan 2027 (earlier pass) | Fits the "agents draft, person approves, fixed code runs" tool as an industry experience paper; deployment not required | [FSE 2027 Industry Papers](https://conf.researchr.org/track/fse-2027/fse-2027-industry-papers) |
| ICSE 2028 | No date found; the steering committee is reported to have dropped the spring deadline from ICSE 2027 onwards, leaving a summer deadline (search summary) | Not in the December-to-March window | [ICSE news](http://www.icse-conferences.org/news.html) |
| SIGMOD 2027 | Research round 4 was 17 Oct 2026 (closed); Industrial Track paper deadline 24 Nov 2026 (nine days away, before results exist) | Closed for this paper | [SIGMOD 2027 dates](https://2027.sigmodconf.hosting.acm.org/calls_papers_important_dates.shtml); [SIGMOD 2027 industrial call](https://2027.sigmodconf.hosting.acm.org/calls_industrial_track_papers.shtml) |
| ICDE 2027 (Copenhagen) | Research round 2 was 11 Nov 2026; notification 10 Feb 2027 (aggregator, via search summary) | Closed | [tracker](https://www.myhuiban.com/conference/135) |
| WWW 2027 (Dublin, 10–14 May 2027) | Abstract 18 Oct, paper 25 Oct 2026 (aggregator) | Closed, as expected | [tracker](https://mldeadlines.com/conference/www-2027/) |
| CIKM 2027 (Sydney, 25–29 Oct 2027) | "Tentative" 21 May 2027 (aggregator); official site did not respond | Outside the window; a later home for (c) or (d) with applied and resource tracks | [tracker](https://trybibby.com/conference-deadlines/cikm-2027) |
| IEEE International Test Conference 2027 (San Antonio, 10–15 Oct 2027) | "Paper title/abstract due: March 5, 2027"; "Paper final PDF due: April 9, 2027"; "Author notification: June 1, 2027"; posters 9 Jul 2027 | Best domain fit for the tool; see quotes below | [ITC 2027 call](https://www.itctestweek.org/wp-content/uploads/2026/10/ITC_2027_CFP_v2026Oct10.pdf) |

- ITC 2027 call, opening paragraph: "AI is entering the test engineer's own toolbox, from pattern generation and data analytics to agent-assisted debugging." Listed topics include "High-Speed I/O, RF & Jitter Test", "Memory Test & Repair", "System Test", "Silicon case studies", "Silicon Debug & Field Monitoring", "Diagnosis & Defect Analysis", "Protocol-Aware Test", and under "AI for Test Efficiency & Innovation": "LLM- & Agent-Assisted Test" and "AI-Driven Diagnosis & Test Flows". — [ITC 2027 call](https://www.itctestweek.org/wp-content/uploads/2026/10/ITC_2027_CFP_v2026Oct10.pdf)
- ITC 2027 format: "a complete paper of up to 10 pages"; "For AI-focused papers, an appendix of up to 6 pages may be submitted in addition to the main paper."; papers may "advance fundamental research or report hands-on industrial experience."; "Submissions shorter than 4 pages are rarely accepted." — [ITC 2027 call](https://www.itctestweek.org/wp-content/uploads/2026/10/ITC_2027_CFP_v2026Oct10.pdf)

### Inferences

- ITC 2027 is the only venue found whose call names this author's exact subject (agent-assisted debugging, protocol-aware test, field failure diagnosis) and welcomes industrial experience. It is the natural home for the application paper, with the abstract due 80 days after results.
- VLDB's monthly cycle means a paper not ready on 1 February can go on 1 March with no penalty, which suits a solo author; a paper accepted after 1 July 2027 moves to VLDB 2028.
- The DAC Engineering Track and an ITC paper do not conflict with a machine-learning or data-mining paper on a different claim, because the DAC track has no proceedings.

### Gaps

- Acceptance rates for VLDB (by category), ITC and the DAC Engineering Track were not found in this pass.
- VLDB page limits and its revision process were not read. The CIKM 2027 site could not be reached. ICSE 2028 dates are not posted.
- Whether ITC requires in-person presentation is not stated on the call page read.

## 6. Evidence of taste: what the 2025 and 2026 accepted lists contain

### Takeaway

The NeurIPS 2026 Evaluations and Datasets track accepted the closest neighbours of paper type (a): benchmarks for agents doing incident and fault diagnosis, including one built on fully synthetic logs by a three-author team with an industry first affiliation, and one sole-author benchmark on counterfactual traces. KDD accepts root-cause and AIOps work every year, but its applied-track examples are deployed systems from cloud companies; SIGIR accepted nothing on root-cause, log or hardware analysis that is not tied to search or recommendation. Sole-author papers are 0 to 3% of every track examined, and no paper about storage-device analysis from a storage company appears in any list.

### Cited Findings

Sources for every row and count in this section, unless another is given: [NeurIPS 2025 data](https://neurips.cc/static/virtual/data/neurips-2025-orals-posters.json); [NeurIPS 2026 data](https://neurips.cc/static/virtual/data/neurips-2026-orals-posters.json); [KDD 2025 research](https://kdd2025.kdd.org/research-track-papers-2/); [KDD 2025 ADS](https://kdd2025.kdd.org/applied-data-science-ads-track-papers-2/); [KDD 2025 datasets and benchmarks](https://kdd2025.kdd.org/datasets-and-benchmarks-track-papers-2/); [KDD 2026 papers](https://kdd2026.kdd.org/papers/); [SIGIR 2025 accepted papers](https://sigir2025.dei.unipd.it/accepted-papers.html); [SIGIR 2026 accepted papers](https://sigir2026.org/en-AU/pages/program/accepted-papers). All counted locally by title keywords. "Data" and "Deployed" are filled only where a second source was read; "not checked" means title only.

**Root-cause analysis, incidents, logs, traces, AIOps**

| Paper | Venue, track | Authors | Data | Deployed | Extra source |
|---|---|---|---|---|---|
| "SLS-Bench: A Benchmark for Incident Log Summarization with Synthetic Observability Data" | NeurIPS 2026, Evaluations and Datasets | 3 (Dynatrace; Johannes Kepler Universität Linz) | Synthetic: 90 tasks; logs and answers "fully synthetic", derived from public incident postmortems by an LLM pipeline and compared statistically with real log streams; 14 LLMs tested | No (benchmark) | [poster page](https://neurips.cc/virtual/2026/poster/139743); [dataset card](https://hf-proxy-en5.pages.dev/datasets/anon-sls-bench/SLS-Bench) (both via search summary) |
| "SREGym: A Live Benchmark for AI SRE Agents with High-Fidelity Failure Scenarios" | NeurIPS 2026, Evaluations and Datasets | 8 (UIUC and others) | Real cloud-native software stacks with injected faults; 90 problems | No (benchmark; open source) | [arXiv 2605.07161](https://arxiv.org/abs/2605.07161) (search summary) |
| "Where Root Cause Analysis Fails: A Retrieval-Reranking Decomposition" | NeurIPS 2026, Evaluations and Datasets | 6 (UNSW; Baker Hughes) | Audit of four existing benchmarks; no new data | No | [poster page](https://neurips.cc/virtual/2026/poster/139698) (search summary) |
| "CTE-Bench: Audited Counterfactual Trace Evaluation for Stateful Software Simulators" | NeurIPS 2026, Evaluations and Datasets | **1** (Arga Labs) | Programmatic: 255 items over six deterministic Python services with an executable oracle | No | [poster page](https://neurips.cc/virtual/2026/poster/139020) (search summary) |
| "DistDebug-Bench: Can LLM Agents Diagnose Bugs in Distributed Systems?" | NeurIPS 2026, Evaluations and Datasets | 9 (Michigan; Tsinghua) | not checked | not checked | — |
| "EnvFaultBench: Benchmarking LLM Agents on Software Environment-Fault Troubleshooting" | NeurIPS 2026, Evaluations and Datasets | 5 (Peking University) | not checked | not checked | — |
| "DiagnosticIQ: A Benchmark for LLM-Based Industrial Maintenance Action Recommendation from Symbolic Rules" | NeurIPS 2026, Evaluations and Datasets | 11 (IBM Research; RPI) | not checked | not checked | — |
| "OpenClawBench: Benchmarking Process-side Anomalies in Real-world Agent Execution Trajectories" | NeurIPS 2026, Evaluations and Datasets | 7 | not checked | not checked | — |
| "PRISM: Asymmetric Precision-Recall Optimization for Million-Scale Root Cause Analysis"; "PRIM: Meta-Learned Bayesian Root Cause Analysis" | NeurIPS 2026, main track | 5 (Alibaba, Ant); 6 (Trinity College Dublin, IBM Research) | not checked | not checked | — |
| "DualLane: Fast and Reliable LLM Agents for Interactive AIOps via Dual-Path Planning" | KDD 2026, applied data science | 11 (all Alibaba Cloud) | Real production tickets | Yes; press reports more than a year in production; a fast path answers known problems from a template and only uncommon ones go to the agent | [Techzine](https://www.techzine.eu/news/infrastructure/143542/alibaba-cloud-reduces-llm-use-in-support-ticket-handling/); [Xenospectrum](https://xenospectrum.com/en/alibaba-duallane-ecs-aiops-agent/) (both secondary, search summary; the paper was not read) |
| "TSLoc: Self-Supervised Faulty Node Localization Framework in Large-scale Training Clusters" | KDD 2026, applied data science | 11 | not checked | not checked (track requires it) | — |
| "LMID: A Comprehensive Multimodal Dataset for Failure Prediction in Cloud Computing Systems" | KDD 2026, datasets and benchmarks | 7 (Alibaba Cloud; HUST) | Real: about 100 million log entries from about 220,000 machines, per a secondary listing | Dataset from production | [listing](https://chatpaper.com/paper/280873) (secondary, search summary) |
| "StaR: Stateful Dynamic-Graph Root Cause Analysis through Memory-Enhanced Causality Discovery"; "CAVIAR: Disentangling Root Causes with an ICA-based VAE for Large-Scale Microservice Systems" | KDD 2026, research | 7; 4 | not checked | not checked | — |
| "State Machine Guided Multi-Relational Synthetic Data from Logs for Anomaly Detection" | KDD 2026, research | 2 (University of Western Ontario) | Synthetic, per title | not checked | — |
| "FlowXpert: Expertizing Troubleshooting Workflow Orchestration with Knowledge Base and Multi-Agent Coevolution"; "M^2-MFP: A Multi-Scale and Multi-Level Memory Failure Prediction Framework for Reliable Cloud Infrastructure" | KDD 2025, applied data science | 15 (Nankai; Huawei Cloud); 7 (USTC; Huawei) | not checked | not checked (track requires it) | — |
| "REDUCE: Budgeted Verification Retrieval for Rare Incident Monitoring" | SIGIR 2026, industry | 6 | not checked | not checked | — |

- NeurIPS 2025 Datasets and Benchmarks: no title on logs, traces, AIOps or system root-cause analysis (0 of 497); the "incident" and "diagnos…" matches are medical, traffic or remote sensing.
- SIGIR 2025: no title on root-cause, incident, log-analysis or hardware topics; the only "log" match is click logs.

**Hardware and chip benchmarks**

- NeurIPS 2026 Evaluations and Datasets: "Is Agentic AI Ready for Real-World Hardware Engineering? A Deep Dive with Phoenix-bench" (6, National University of Singapore); "HierSVA: A Synthesis Pipeline, Dataset, and Benchmark for LLM-Driven Hierarchical Hardware Formal Verification" (8, University of Washington, AMD); "HSCO-Bench: An Agent-Driven End-to-End Hardware-Software Co-design Benchmark for Systems-on-Chip" (5, Columbia, IBM Research); "VeriScope" (7); "HDL-RepoBench" (5); "SOL-ExecBench" (30, NVIDIA).
- NeurIPS 2025 Datasets and Benchmarks: "VeriThoughts" (7, NYU); "LithoSim" (8); "Benchmarking End-To-End Performance of AI-Based Chip Placement Algorithms" (14, USTC, Huawei).
- KDD: "TransPlace" (2025 research, 6); "VeriHGN" (2026 research, 4); "SQChip-EM" and "QuaMap" (2026 datasets and benchmarks, 8 and 3); "AnalogAgent" (2026 AI for sciences, 8); "EDA Job Scheduling Using Reinforcement Learning with Adaptive Macro Actions" (2026 applied, 5, IBM).
- All are design, verification or placement. None is about post-silicon debug, protocol analysis, or storage-device failure analysis.

**Anomaly, time-series and event-sequence benchmarks**

- KDD datasets and benchmarks: 2025 "EBES: Easy Benchmarking for Event Sequences" (5), "TimeGraph: Synthetic Benchmark Datasets for Robust Time-Series Causal Discovery" (3), "TSFM-Bench" (11); 2026 "In a Streaming World, Should You Stand Still? A Comprehensive Benchmark of Anomaly Detection in Streams" (6, EDF R&D, ENS), "Rethinking Weak Supervision in Anomaly Detection: A Comprehensive Benchmark" (9), "TemporalBench: A Benchmark for Evaluating LLM-Based Agents on Contextual and Event-Informed Time Series Tasks" (5, USC), "FinStressTS: A Parametric Synthetic Benchmark for Time-Series Forecasting in Finance" (6), "DyGADBench" (6, BNP Paribas).
- NeurIPS: 2026 "Detect, Explain, Interpret: An End-to-End Benchmark for Time Series Anomaly Detection, Explainability and Interpretability." (5; ENS, Scality, EDF R&D), "The BV4 Benchmark for Unsupervised Anomaly Detection in High-Dimensional Spectral Data Streams" (3); 2025 "NoBOOM: Chemical Process Datasets for Industrial Anomaly Detection" (19), "SynTSBench" (6).

**Language-model agents for data analysis; tables and schemas**

- NeurIPS 2026 Evaluations and Datasets: "SpreadsheetBench 2" (14), "fxBench" (5, Microsoft), "EnterpriseBench" (12), "Be CARE-ful with Text-to-SQL Benchmarks" (11), "STRABLE: Benchmarking Tabular Machine Learning with Strings" (11; INRIA, SAP), "TRL-Bench" (13). NeurIPS 2025: "MMTU: A Massive Multi-Task Table Understanding and Reasoning Benchmark" (9, Microsoft), "RADAR: Benchmarking Language Models on Imperfect Tabular Data" (20, Google), "Sheetpedia" (4).
- KDD 2026 research: "SemStruct: Contextualizing Semantic Embeddings with Structural Information for Schema Matching" (7; RPI, IBM Research), "ProfiliTable: Profiling-Driven Tabular Data Processing via Agentic Workflows" (8), "AutoSchema" (3), "EvoDS: Self-Evolving Autonomous Data Science Agent with Skill Learning and Context Management" (4), "From Rows to Reasoning: A Retrieval-Augmented Multimodal Framework for Spreadsheet Understanding" (4, Patronus AI). KDD 2026 datasets and benchmarks: "DTBench: A Synthetic Benchmark for Document-to-Table Extraction" (6), "MultiTab" (8). KDD 2025: "ToolSQL" (research, 4), "NL2SQL-BUGs" (datasets, 5).
- SIGIR: 2025 "Reasoning and Retrieval for Complex Tables via Reinforced Relational Data Transformation" (full, 3), "HAETAE: In-domain Table Pretraining with Header Anchoring" (short, 2), "Retrieving Tables via Inter- and Intra-Content Contrastive Representation Learning" (short, 2), "NLCTables" and "Wiki-TabNER" (resource, 5 each); 2026 "Corpus-Centric Learning for Zero-Shot Table Retrieval" (full, 5), "FollowTable: A Benchmark for Instruction-Following Table Retrieval" (full, 10), "TReB" (resource, 12), "RAPO: Reason-Aware Preference Optimization for Factual Table Question Answering over Structured Data" (industry, 3).

**Agent memory**

- NeurIPS 2026 Evaluations and Datasets has 14 agent-memory evaluation titles, among them "MEMAUDIT" (2, Purdue), "MemLeak" (2, Georgia Tech), "MemArena" (2, MBZUAI), "When Stored Evidence Stops Being Usable: Scale-Conditioned Evaluation of Agent Memory" (4), "GroupMemBench" (6; Microsoft, UCSB), "Harness the Memory: A Holistic Evaluation of Memory Substrates in Memory Agents" (15), "EvoMemBench" (10). The 2025 track had none.
- KDD 2026: "Hierarchical Long-Term Semantic Memory for LinkedIn's Hiring Agent" (applied, 10, LinkedIn); "MemGraphRAG" (research, 6); "Personalizing Large Language Models with User Profile Memory" (research, 4).
- SIGIR 2026: "Dynamic Memory Forest: Constructing and Tracing Conversational Trajectories for Long-Term Conversation" (full, 6), "EvoMem: Timeline-Grounded Validity Adjudication for Non-Monotonic Multi-Agent Memory" (short, 5), "Efficient Memory Alignment for Long-term Conversational Information Seeking" (short, 7), "AgentSim: A Platform for Verifiable Agent-Trace Simulation" (resource, 3).

**Sole-author papers (counted locally; doctoral papers excluded)**

| Venue, year | Track: sole-author papers of accepted |
|---|---|
| SIGIR 2025 | full 1 of 239; short 3 of 106; resource and reproducibility 0 of 71; demo 2 of 26; perspectives 2 of 10; low-resource 0 of 10; industry 4 of 51. Total 12 of 513 (2.3%) |
| SIGIR 2026 | full 2 of 234; short 5 of 151; resource 3 of 61; reproducibility 0 of 28; perspective 2 of 12; demo 1 of 24; industry 3 of 131; low-resource 2 of 15. Total 18 of 656 (2.7%) |
| KDD 2025 | research 4 of 552; applied 0 of 155; datasets and benchmarks 1 of 64 |
| KDD 2026 | research 12 of 787; applied 0 of 186; datasets and benchmarks 0 of 182; AI for sciences 0 of 243; blue sky 1 of 17 |
| NeurIPS 2025 Datasets and Benchmarks | 1 of 497 (0.2%); median 8 authors |
| NeurIPS 2026 Evaluations and Datasets | 21 of 971 (2.2%); median 6 authors; 9 of the 21 list a company or "independent" affiliation (for example Aleph Alpha, Facebook, Arga Labs, Eon Systems PBC, Otsuka Shokai) |

- Sole-author examples close to this author's profile: SIGIR 2026 industry track "What's in a Name? Product Normalization for Enterprise RAG at NetApp" (a storage company named in the title); SIGIR 2026 short "Numerical Hallucinations in Retrieval-Augmented Generation: Detection and Analysis"; SIGIR 2025 full "Measuring Text-Image Retrieval Fairness with Synthetic Data"; KDD 2026 research sole authors from NTT, Fujitsu and Netflix; NeurIPS 2026 Evaluations and Datasets "CTE-Bench" (Arga Labs) and "Build-and-Find: An Effort-Aware Protocol for Evaluating Agent-Managed Codebases".

**Hardware and storage companies (affiliation strings matched by pattern; SIGIR lists carry no affiliations)**

- Storage-device and storage-system makers searched for: Samsung, SK hynix, Micron, Western Digital, Seagate, Kioxia, Solidigm, SanDisk, NetApp, Pure Storage, Dell, HPE. KDD: 1 paper in 2025 (Samsung, research) and 1 in 2026 (Samsung, research); none in the applied or datasets tracks. NeurIPS Datasets and Benchmarks 2025: 4 (Samsung AI; Samsung Semiconductor on "CLEAR: Command Level Annotated Dataset for Ransomware Detection"; HPE on two data-centre benchmarks). NeurIPS Evaluations and Datasets 2026: 5 (four Samsung research labs, one HPE). No paper from SK hynix, Micron, Western Digital, Seagate, Kioxia, Solidigm, SanDisk, NetApp or Pure Storage in any KDD or NeurIPS dataset-track list. One 2026 NeurIPS benchmark lists Scality, a storage-software company.
- Chip companies (Intel, NVIDIA, AMD, Qualcomm, Arm and similar): NeurIPS dataset tracks 16 papers in 2025 (15 NVIDIA) and 37 in 2026 (31 NVIDIA, 2 Intel, 2–3 AMD, 2 Qualcomm); KDD 3 in 2025 and 2 in 2026.
- None of the storage-company papers found is about storage devices, protocol traces or failure analysis.

### Inferences

- Paper type (a) has direct, recent precedent at exactly one place: the NeurIPS 2026 Evaluations and Datasets track (SLS-Bench, SREGym, EnvFaultBench, DistDebug-Bench, plus six hardware-design benchmarks). The 2025 track had none, so this is a 2026 development.
- SLS-Bench is the single most useful model: three authors, industry first affiliation, fully synthetic logs, many models compared. Its realism argument (synthetic data derived from real incident reports and checked statistically against real streams) is the part this author's generator-only data lacks.
- DualLane at KDD 2026 is close to paper type (b)'s idea (answer known cases from a fixed template, send the rest to the agent) and shows the idea is publishable, but as a deployed system with a year of production numbers from an 11-author company team. A measurement-only version of (b) on synthetic traces is a different kind of paper and cannot go to that track.
- For type (e) the fourteen agent-memory evaluation papers in one NeurIPS track show strong reviewer appetite and also crowding; the earlier pass's finding that none of them studies a change of model still stands on a title search.
- Hardware "niche" is not a barrier at NeurIPS or KDD (chip-design benchmarks get in), but every accepted hardware benchmark is on design or verification, where public artefacts exist. Post-silicon protocol analysis would be new, which helps novelty and hurts reviewer familiarity.
- Sole authorship is unusual but present in every research track; it is absent from the KDD applied track in both years, which fits that track's company-team character.

### Gaps

- Only titles were matched. Papers whose titles avoid the keywords are missed, and "not checked" rows carry no information about data or deployment.
- SIGIR lists have no affiliations, so hardware and storage companies at SIGIR could not be counted.
- Affiliation matching by pattern can miss spellings and subsidiaries; the company counts are lower bounds.
- Parsing notes: the SIGIR 2026 parse found 233 of the 234 full papers; seven KDD 2026 titles appear twice on the official page.
- The SLS-Bench "Dynatrace" affiliation comes from the official NeurIPS list; the web search for the paper did not independently confirm it.

## 7. Fit table: paper type against track

### Takeaway

On documented scope and precedent, type (a) fits the NeurIPS Evaluations and Datasets track best (ICML's benchmark contribution type is the earlier door), types (b) and (e) fit ICML 2027 under "Datasets, Evaluations and Benchmarks", type (c) is the one paper that fits SIGIR 2027, and type (d) fits KDD's research track or VLDB. None of these carries a documented rate above about 27%, and every "best chance" below is judgement resting on those group rates.

### Cited Findings

Documented facts used in the table (sources in sections 1 to 6 and in the earlier notes):

- SIGIR 2026 full papers 18%; SIGIR 2025 22.3% (aggregator). — [ACM DL SIGIR '26](https://dl.acm.org/doi/proceedings/10.1145/3805712); [stats site](https://csconfstats.xoveexu.com/conferences/sigir/2026/)
- KDD research 18.68% (2025); KDD 2026 all tracks 21% in each cycle. — [OpenAccept KDD](https://openaccept.org/c/dm/kdd/); [ACM DL KDD '26 V.2](https://dl.acm.org/doi/proceedings/10.1145/3770855)
- NeurIPS Datasets and Benchmarks 25.3% (2024); 1,995 submissions in 2025. — [NeurIPS blog, D&B chairs 2025](https://blog.neurips.cc/2025/09/30/reflecting-on-the-2025-review-process-from-the-datasets-and-benchmarks-chairs/)
- ICML 26.6% (2026), 26.9% (2025), secondary sources. — [RIKEN AIP](https://aip.riken.jp/news/icml2026/)
- KDD datasets track: "Synthetic data must be accompanied with a quantification and a discussion of its representativeness". — [KDD 2027 datasets and benchmarks call](https://kdd2027.kdd.org/datasets-and-benchmarks-track-call-for-papers/)
- KDD applied track: no deployment, desk rejection. — [KDD 2027 ADS call](https://kdd2027.kdd.org/applied-data-science-ads-track-call-for-papers/)
- SIGIR: "Clear lack of topical fit for SIGIR." is a desk-rejection ground. — [SIGIR 2027 full-paper call](https://sigir2027.org/pages/submit-full.html)

### Inferences

Everything in this table is my judgement; the last column alone is documented. "Rate" is the track's overall rate, not a forecast for this paper; the earlier notes derive a lower figure (about one in nine) for first-time solo authors at ICML-class venues.

| Paper type | Best single track | Main reason | Main obstacle | Runner-up | Documented rate of the best track |
|---|---|---|---|---|---|
| (a) Benchmark for agents doing root-cause analysis on hardware protocol traces | NeurIPS 2027 Evaluations and Datasets (if the track continues; about May 2027) | Only track with direct 2026 precedent (SLS-Bench with synthetic logs, SREGym, hardware-agent benchmarks); data generators named in scope; 21 sole-author papers accepted in 2026 | All data synthetic from the author's own generator, with no realism check against real recordings; Croissant file, public hosting and code at submission need employer clearance; a May deadline means waiting five months | ICML 2027, type "Datasets, Evaluations and Benchmarks" (22 Jan 2027), or KDD 2027 datasets and benchmarks cycle 2 (about Feb 2027; must quantify representativeness) | 25.3% (2024); about 24.9% (2025, derived); 2026 not published |
| (b) "Rule written once, code runs it" against "model answers at run time" | ICML 2027, type "Datasets, Evaluations and Benchmarks" | Type definition covers "auditing or stress testing machine learning systems" and evaluation-focused empirical analyses; no new model needed | One private domain and synthetic traces; needs a public task and several models to read as more than a case study (earlier notes, conditions 1 to 5); the closest accepted neighbour (DualLane) is a deployed system | VLDB 2027 Experiment, Analysis & Benchmark (1 Feb or 1 Mar 2027) if the story is cost and scale on millions of rows | 26.6% (2026, secondary); VLDB rate not found |
| (c) Evidence-checked agent claims | SIGIR 2027 full papers (21 Jan 2027), areas "Information Access through Generative AI" and evaluation ("Measuring groundedness, hallucination, and factual accuracy") | The only type whose core (find and cite the supporting evidence) is an information-access problem; grounding and attribution are a new named area in 2027 | Must be written with retrieval of evidence as the driver, on at least one public collection; sole author must also serve as a reviewer; 18% is the lowest rate in this table | SIGIR 2027 short papers (dates not posted; 4 pages in 2026) or NeurIPS 2027 Evaluations and Datasets | 18% (2026); 22.3% (2025, aggregator) |
| (d) Meaning of columns in unknown wide tables | KDD 2027 research track, cycle 2 (about Feb 2027) | Schema matching, table profiling and schema induction papers are on the 2026 research list (SemStruct, ProfiliTable, AutoSchema); double-blind | Needs public table corpora and published baselines beside analyzer exports; reviewer-nomination rule; cycle 2 dates not posted | VLDB 2027 regular research (1 Feb or 1 Mar 2027), or SIGIR 2027 full under "Search in structured data" if framed as column retrieval | 18.68% (2025 research); 21% (2026, all tracks per cycle) |
| (e) Do stored human-feedback scores in agent memory survive a model change | ICML 2027, type "Datasets, Evaluations and Benchmarks" or "General" (earlier notes; unchanged) | Dated door in January; audit and stress-test wording; no accepted paper found on this question | First-time solo author discount and new first-stage screen (earlier notes); crowded agent-memory field (14 evaluation papers in one NeurIPS 2026 track) | NeurIPS 2027 Evaluations and Datasets as second attempt; TMLR remains the highest documented odds (earlier notes) | 26.6% (2026, secondary) |

- Tracks that are shut regardless of paper type: KDD applied data science (no deployment); SIGIR full papers for (a), (b), (e) unless rebuilt around retrieval.
- The application itself (agents draft, a person approves, fixed code runs, on PCIe/NVMe recordings) is a sixth paper not on the list. Its best homes are ITC 2027 (abstract 5 March 2027) and the DAC 2027 Engineering Track (11 January 2027); a SIGIR 2027 demo (11 February 2027) would need a working link reviewers can open, which the 2026 demo call enforced by desk rejection. — [ITC 2027 call](https://www.itctestweek.org/wp-content/uploads/2026/10/ITC_2027_CFP_v2026Oct10.pdf); [DAC 2027 engineering track](https://dac.com/2027/program/back-end-track-submissions); [SIGIR 2026 demonstrations track](https://sigir2026.org/en-AU/pages/submissions/demonstrations-track)
- One person, 37 to 58 days: realistically one January submission (SIGIR full with (c), or ICML with (b) or (e)) and one February or March submission (KDD cycle 2 or VLDB with (d); or ITC with the tool), then NeurIPS in May with (a). This sequencing is my suggestion, not a sourced fact.

### Gaps

- No track publishes rates by number of authors, by industry affiliation, or for synthetic-only data. The table cannot say how much lower this author's chance is than the track rate.
- KDD datasets and benchmarks, SIGIR short, resource and industry tracks, VLDB and ITC have no documented rate in this pass, so none could be named "best chance" on evidence even where the fit looks good.
- Whether NeurIPS 2027 keeps the Evaluations and Datasets track and its 2026 rules is unknown.

## 8. Which targets let the author present in person to a large audience

### Takeaway

SIGIR, KDD and VLDB require an author to attend and present in person; SIGIR gives full papers an oral slot and puts short, resource and industry papers in poster sessions; KDD guarantees a presentation but an oral slot only for "a portion"; ICML does not require attendance at all, and NeurIPS presents accepted track papers alongside the main track. None of the four named venues was found to offer remote-only presentation as the normal mode in 2026 or 2027.

### Cited Findings

| Venue and track | In-person rule | Format | Remote option | Source |
|---|---|---|---|---|
| SIGIR 2027, all posted tracks | "The 50th ACM SIGIR conference will be run as an in-person conference in July 2027 in San Jose, California."; at least one author must register and attend | 2026 practice: short and resource papers "will be delivered as posters during one of two poster sessions"; industry papers "will primarily be delivered as posters"; full papers had oral slots (the 2026 proxy notice refers to papers that "will have an oral slot allocated") | "Presenting authors who are unable to obtain a visa may apply to present at a satellite location instead."; "Requests are reviewed through an approval process." In 2026: proxy presenters allowed, "Online/video presentations will not be permitted." | [SIGIR 2027 full-paper call](https://sigir2027.org/pages/submit-full.html); [SIGIR 2026 guidance for presenters](https://sigir2026.org/en-AU/pages/program/guidance-for-presenters) |
| SIGIR 2026 policy (model for 2027) | "All accepted papers (across all tracks) to the main conference and workshops are expected to be presented in-person."; "No pre-recorded videos will be permitted." | — | None | [SIGIR 2026 submission policies](https://sigir2026.org/en-AU/pages/submissions/submission-policies-and-information) |
| KDD 2027, all tracks | "Every accepted paper must be presented at the conference."; "No-show papers may be withdrawn from the conference program and proceedings where it applies." | "Only a portion of accepted papers will be selected to present orally at the conference." | Not described; the registration rule applies "regardless of attendance or presentation mode", which implies another mode may exist | [KDD 2027 research call](https://kdd2027.kdd.org/research-track-call-for-papers/); [KDD 2027 ADS call](https://kdd2027.kdd.org/applied-data-science-ads-track-call-for-papers/) |
| NeurIPS 2026 Evaluations and Datasets (model for 2027) | One author must register for the main conference (earlier notes) | "presented at the conference alongside main track papers."; the 2026 list shows posters, with orals for a small share (131 oral events among 9,276 entries, all tracks) | 2026 ran at three sites (Sydney, Paris, Atlanta) | [NeurIPS 2026 E&D call](https://neurips.cc/Conferences/2026/CallForEvaluationsDatasets); [NeurIPS 2026 data](https://neurips.cc/static/virtual/data/neurips-2026-orals-posters.json); [NeurIPS blog](https://blog.neurips.cc/) |
| ICML 2027 | "Attendance for authors of accepted papers is optional." (earlier notes) | Poster in Rio for those who attend; proceedings-only allowed with virtual registration | Yes (proceedings-only) | [ICML 2027 Call for Papers](https://icml.cc/Conferences/2027/CallForPapers) |
| VLDB 2027 | "At least one author of each accepted paper must attend the VLDB 2027 Conference." | Not read | Not read | [VLDB 2027 research call](https://vldb.org/2027/call-for-research-track.html) |
| DAC 2027 Engineering Track | Presenter must register by 10 April 2027 | 15-minute talk plus poster, a 7-minute "poster gladiator" slot plus poster, or poster only; not in proceedings | Not described | [DAC 2027 engineering track](https://dac.com/2027/program/back-end-track-submissions) |
| SIGIR 2027 workshops | Workshop day 23 July 2027, in person under the 2026 policy | Set by each workshop | — | [SIGIR 2027 tracks](https://sigir2027.org/pages/submit-tracks.html) |

### Inferences

- Guaranteed stage time in front of a large audience: a SIGIR full paper (oral, judging by 2026) and a DAC Engineering Track presentation (15-minute talk) are the only two found where a talk, not a poster, is the normal outcome. KDD, NeurIPS and ICML mostly mean a poster; an oral is a minority selection.
- Guaranteed poster in person: SIGIR short, resource and industry tracks; KDD all tracks; NeurIPS; ICML if the author chooses to travel to Rio.
- No guaranteed slot: none of the four; each presents every accepted paper. The uncertainty is acceptance, not the slot.
- San Jose hosts DAC (11–14 July), SIGIR (19–24 July) and KDD (1–5 August) in 2027. For an author who needs a visa, SIGIR's satellite-presentation fallback is the only written safety net; KDD's call warns that no-shows may be withdrawn.
- ICML in Rio (main days 2–4 August) and KDD in San Jose (1–5 August) overlap, so acceptances at both could not both be presented in person by one author.

### Gaps

- SIGIR 2027's in-person or hybrid policy and its satellite-presentation policy pages are "TBA"; the oral-for-full-papers reading comes from 2026 practice, not a 2027 rule.
- KDD does not publish the share of papers given oral slots. NeurIPS 2027 presentation rules do not exist yet.
- ITC 2027's attendance rule was not on the call page read.
