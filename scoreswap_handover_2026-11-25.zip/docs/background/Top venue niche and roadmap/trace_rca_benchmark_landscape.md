# Landscape of root-cause and failure-diagnosis benchmarks for language-model agents, and whether a multi-layer PCIe / NVMe protocol-trace benchmark fills an open gap

State of the field as read on 15 November 2026. This pass re-checks and extends the 12 November 2026 notes (`One month top venue paper idea/root_cause_benchmarks_literature.md`).

Reading rules. "Read" means the page was fetched in this pass through a page-summarising fetch tool, which limits verbatim quotes to short phrases, so most figures are the tool's reading of the page and quotes are short. "Search summary" means only a search-engine summary was seen. "Carried" means the item comes from the 12 November pass and was not re-read. OpenReview review threads could not be read (the site returned a challenge page), so no reviewer's own words appear below. Nothing here predicts acceptance.

## 1. Root-cause benchmarks for agents in software and cloud operations

### Takeaway
The 12 November pass's main claims hold on re-reading, but it missed at least eight 2025 to 2026 works, and three of them weaken the novelty of "we label the causal chain": OpenRCA 2.0, RCA100 and a trajectory-level study of RCABench all carry propagation-path ground truth already. Scores are no longer uniformly low: they range from 10% (ORCA-bench Hard) to 90% Acc@1 (Claude Sonnet 4.6 on RCABench), so a new benchmark cannot assume frontier agents will fail.

### Cited Findings

#### Verification of the 12 November pass (re-read on 15 November)
- OpenRCA 2.0: confirmed. v1 25 June 2026, v2 30 June 2026, comment field "work in progress", 500 instances, 11 frontier LLMs, exact root-cause set recovered in 20.7% of cases on average; at least one correct service in 76.0%, of which 61.5% are grounded in a verified propagation path. Authors include Pinjia He. — [arXiv 2606.27154](https://arxiv.org/abs/2606.27154)
- ORCA-bench: confirmed. v3 29 September 2026, no venue; 1,079 tasks, 50 GB, six days; best RCA accuracy 25.3% (Medium) and 10.0% (Hard); weighted kappa 0.91; weakest model gives an implausible cause in 40% of reports. New detail: the page says the gap persists "even with Claude Fable 5", and removing source-code access lowers accuracy for every model. — [arXiv 2607.28545](https://arxiv.org/abs/2607.28545)
- Cloud-OpsBench: confirmed. v3 6 November 2026, "28 pages, 6 figures", no venue; 754 runtime-verified cases, 57 fault types, eleven LLMs, joint RCA accuracy up to 0.78 (OnlineBoutique) and 0.68 (TrainTicket); GPT-5 names the right cause without evidence closure in 33.1% and 29.4% of cases. Labels include "diagnostic evidence graphs". — [arXiv 2603.00468](https://arxiv.org/abs/2603.00468)
- SREGym: confirmed as a NeurIPS 2026 poster (8 December 2026); the poster page still does not state the track. arXiv v3 is dated 30 July 2026. "SREGym currently includes 90 realistic, challenging SRE problems." Results vary by "40+%" across problem kinds; no per-agent success rate is on either page. — [NeurIPS 2026 poster](https://neurips.cc/virtual/2026/poster/139695); [arXiv 2605.07161](https://arxiv.org/abs/2605.07161)
- AIOpsLab: the earlier pass had only a secondary score summary. Primary table (arXiv v1, 48 problems): detection 23.07% to 100% (Flash 100%); localization Acc@1 30.77% to 61.54%; root-cause analysis 9.09% to 45.45% (ReAct best); mitigation 0% to 54.55% (Flash best). Agents were GPT-4 with shell, GPT-3.5 with shell, ReAct and Flash. — [arXiv 2501.06706](https://arxiv.org/html/2501.06706v1)
- Not re-read in this pass (carried): OpenRCA's ICLR 2025 figures (335 failures, 68 GB, best 11.34%), ITBench (ICML 2025; 11.4% SRE, 25.2% CISO, 25.8% FinOps), RCAEval (WWW Companion 2025; 735 cases, no LLM baselines), Loghub-2.0 (ISSTA 2024; 14 datasets, 3.6 million lines each on average), LogEval, TeleLogs, RCACopilot, RCAgent, D-Bot. — [OpenRCA](https://proceedings.iclr.cc/paper_files/paper/2025/file/d29b8d53678015079e1d245c023e49d2-Paper-Conference.pdf); [ITBench](https://proceedings.mlr.press/v267/jha25a.html); [RCAEval](https://arxiv.org/html/2412.17015v5); [Loghub-2.0](https://arxiv.org/abs/2308.10828v2)

#### Works the 12 November pass did not have

| Work | Status and date | Data | Size and faults | Causal chain labelled? | Synthetic? | Best reported result |
|---|---|---|---|---|---|---|
| RCABench, "Rethinking the Evaluation of Microservice RCA with a Fault Propagation-Aware Benchmark" | Peer-reviewed: "directly accepted at FSE'26 (87 of 920 submissions)"; arXiv Oct 2025 | Multi-modal microservice telemetry (TrainTicket topology) | 1,430 validated cases from 9,152 injections; 25 fault types in 6 categories | Hierarchical root-cause labels, service down to code; no process labels | Injected faults in a running system | 11 non-LLM SOTA models: average Top@1 0.21, best 0.37 |
| "Beyond Fault Localization" (trajectory study on RCABench) | Preprint, 21 Aug 2026 | Same | 500 of the 1,430 cases annotated; 3,500 agent trajectories | Yes: service-level fault propagation graph per case | Injected | Acc@1 from 42.6% (mABC) to 90.0% (Claude Sonnet 4.6) |
| AIOps2025 and RCA100 multi-dataset benchmark | Preprint, 28 June 2026 | Metrics, logs, traces; RCA100 adds events, alerts, topology | 400 cases (9 categories, 18 types, about 11.9 GB) and 103 cases (28 root-cause types, about 3.4 GB) | RCA100: yes, cause, propagation, impact chains (91 three-step, 12 four-step) plus 661 evidence checkpoints | Chaos-injected | No model results on the page read |
| CUJBench | Preprint, 25 Apr 2026, single author (Snowflake) | Browser-to-backend snapshots (Playwright, HAR, DOM, traces, logs, metrics) | 87 labelled scenarios; models run on a 25-scenario subset (446 runs) | Three-layer label process; cross-layer evidence partition | Faults injected in demo apps; scenarios LLM-generated | Best cell 52.0% A@1; overall 19.7% |
| DistDebug-Bench | Preprint, 2 Nov 2026 (Univ. of Michigan) | Issue reports, logs, stack traces, pre-fix repositories | 120 real incidents, 11 systems, 218 gold root-cause blocks | Root-cause code blocks, no chain | Real historical bugs | GPT-6 Astra with Mini-SWE-Agent: 67.7% block coverage, 42.7% block precision |
| NIKA network arena | Preprint, 18 Dec 2025 | Live emulated networks with tools over MCP | 54 issue kinds, "hundreds" of incidents, five scenarios | Not stated | Emulated networks | Larger models detect more but "struggle to localize faults and identify root causes" |
| NetArena (earlier name NetPress) | Peer-reviewed: Microsoft Research lists it under ICLR 2026; arXiv June 2025, v2 Mar 2026 | Generated network queries checked in emulators | Unlimited queries on demand | Ground truth derived automatically (search summary) | Generator plus emulators | Agents average 13% to 38%, some as low as 3% |
| TraceBench | Preprint, 27 Aug 2026 (cs.LG) | Time series from three simulated mechanical systems | Count not in abstract | Which parameter was altered; no chain | Fully simulated | Four LLM agents; no headline number in abstract |

Sources for the table: [RCABench, arXiv 2510.04711](https://arxiv.org/abs/2510.04711); [Beyond Fault Localization, arXiv 2608.21310](https://arxiv.org/html/2608.21310v1); [multi-dataset benchmark, arXiv 2606.29193](https://arxiv.org/html/2606.29193v1); [CUJBench, arXiv 2604.23455](https://arxiv.org/html/2604.23455v1); [DistDebug-Bench, arXiv 2611.03523](https://arxiv.org/html/2611.03523v1); [NIKA, arXiv 2512.16381](https://arxiv.org/abs/2512.16381); [NetArena, arXiv 2506.03231](https://arxiv.org/abs/2506.03231) and [Microsoft Research page](https://www.microsoft.com/en-us/research/publication/netpress-dynamically-generated-llm-benchmarks-for-network-applications/); [TraceBench, arXiv 2608.27182](https://arxiv.org/abs/2608.27182)

#### Findings that bear directly on the proposed benchmark
- Rule engines already embarrass public RCA benchmarks. RCABench reports that simple rule-based methods performed comparably to or better than state-of-the-art models on four widely used public benchmarks, and treats that as proof those benchmarks are oversimplified. — [arXiv 2510.04711](https://arxiv.org/abs/2510.04711)
- The "causal chain" label is already claimed. OpenRCA 2.0's abstract says existing datasets label "only the root cause, not the propagation path", and presents itself as the first cross-system RCA benchmark with step-wise causal annotations for LLM agents, built from known fault-injection interventions (wording as reported by the fetch tool). — [arXiv 2606.27154](https://arxiv.org/abs/2606.27154)
- The same group states the gap for RCABench: it "provides final root-cause labels but not these process-level annotations", and current evaluations "uniformly assess diagnostic performance by endpoint correctness". — [arXiv 2608.21310](https://arxiv.org/html/2608.21310v1)
- Chain depth is already a measured axis. On RCABench, a Qwen-backed agent falls from 85.5% Acc@1 at depth 2 to 57.1% at depth 5; Claude Sonnet 4.6 holds at 85.7% to 96.8% (the depth-5 cell is a small sample). Edge F1 trails node F1 in every row. — [arXiv 2608.21310](https://arxiv.org/html/2608.21310v1)
- Chaos-injected data is called too clean by its own authors: the RCA100 paper lists as limits that injected faults "are cleaner than real failures" and that demo systems have about a dozen services. — [arXiv 2606.29193](https://arxiv.org/html/2606.29193v1)
- More tools can hurt. In CUJBench, browser-only agents (28.0% A@1) beat full-toolset agents (19.9%); Gemini 3.1 Pro fell from 52% to 12%. The paper names cross-modal synthesis as the main bottleneck: agents retrieve the decisive evidence but attribute it to the wrong component. — [arXiv 2604.23455](https://arxiv.org/html/2604.23455v1)
- Counts for the same benchmark differ between papers. The RCA100 paper's comparison table lists AIOpsLab at 88 cases, ITBench at 94 and SREGym at 114; their own pages give 48, 102 (final version, carried) and 90. — [arXiv 2606.29193](https://arxiv.org/html/2606.29193v1); [AIOpsLab](https://arxiv.org/html/2501.06706v1); [SREGym](https://arxiv.org/abs/2605.07161)
- Nezha (FSE 2023) was seen only second-hand: other papers describe it as built on TrainTicket and OnlineBoutique with logs, metrics and traces, and as limited in size with missing monitoring data (search summaries). — [LEMMA-RCA, arXiv 2406.05375](https://arxiv.org/pdf/2406.05375); [AnoMod, arXiv 2601.22881](https://arxiv.org/abs/2601.22881)
- A fault-is-always-present assumption is a known flaw: FaulT-Bench (Aug 2026) adds false fault reports to NIKA-style tasks and its summary says agents degrade sharply on healthy networks (search summary). — [arXiv 2608.27021](https://arxiv.org/pdf/2608.27021)

### Inferences
- "Known causal chain from symptom to cause" is necessary but no longer novel on its own. Three 2026 works have it for cloud telemetry. What none has is a chain that crosses decode layers of one event stream, with rows linked by identity.
- Low scores cannot be promised. The late-2026 range runs from 10% to 90% depending on benchmark and model. A pilot is the only way to know where this benchmark sits.
- The rule-engine result is double-edged: FSE reviewers have just accepted a paper whose thesis is "if rules match the models, the benchmark is too easy". A rule engine that finds most injected faults will be read the same way unless the scored task is the part rules do not do.
- Include fault-free traces and report false-alarm rates; FaulT-Bench shows reviewers now look for this.
- The name "TraceBench" is taken (August 2026), and so is "TRAIL". The benchmark needs a different name.

### Gaps
- OpenRCA's OpenReview thread could not be read, so reviewer reactions to that paper are still unknown.
- Nezha, LogHub and LogPAI primary sources were not read in this pass.
- No model results were on the page read for RCA100 / AIOps2025.
- SREGym's track at NeurIPS 2026 remains unstated on the pages read.
- Model names such as "Claude Fable 5", "GPT-6 Astra" and "Claude Opus 5.5" are reported as the pages gave them; they were not checked against vendor announcements.

## 2. Hardware, chip and protocol-level sets

### Takeaway
A third and fourth round of differently worded searches again found no public PCIe or NVMe trace corpus with labelled faults and no paper applying language models to protocol-analyzer captures. The nearest hardware neighbours are a waveform question-answering benchmark (WaveformQA, 360 questions), repository-level RTL bug repair (HWE-Bench, 70.7% solved), and an unlabelled synthetic PCIe packet generator (Phantom, DAC 2026).

### Cited Findings

#### Null results from this pass
- An extended search for an LLM benchmark on PCIe / NVMe protocol-analyzer traces with root-cause labels returned vendor pages (Teledyne LeCroy, Prodigy), a patent, and adjacent papers; no such benchmark. — [Teledyne LeCroy](https://www.teledynelecroy.com/protocolanalyzer/nvm-express/pcie-compliance-testing); [Prodigy](https://www.prodigytechno.com/pcie-protocol-analysis); [US patent 11836059](https://image-ppubs.uspto.gov/dirsearch-public/print/downloadPdf/11836059)
- An extended search for LLM agents on SSD firmware, NVMe debug logs, link-training state or protocol analyzers returned an IoT firmware fuzzing paper (FirmAgent, NDSS 2026), a study of LLM workloads' block I/O on NVMe, and a practitioner blog; nothing on analyzer captures. — [FirmAgent](https://github.com/vul337/FirmAgent); [ACM I/O study](https://dl.acm.org/doi/10.1145/3719330.3721230)
- A search for an open-source PCIe analyzer or decoder found only header-level libraries (a Perl TLP header tool, the Rust crate rtlp-lib, Google's go-pcie-tlp), an educational RTL design (SmolPCIe), and commercial analyzers. No Wireshark dissector for PCIe TLPs or DLLPs was found. — [rtlp-lib](https://docs.rs/crate/rtlp-lib/0.5.1); [go-pcie-tlp](https://pkg.go.dev/github.com/google/go-pcie-tlp); [pcie-tlp-header](https://sourceforge.net/projects/pcie-tlp-header/); [SmolPCIe](https://github.com/OmGupta28/SmolPCIe/wiki)

#### Closest hardware and bus work
- **The Phantom of PCIe.** Confirmed: v3 11 April 2026, "Accepted by DAC'26". A generative model plus a filter that enforces PCIe ordering and causality rules on synthesized transaction-layer packet traces; validated on a real network card. "The prototype implementation has been made open-source." The abstract mentions no fault injection, no labels, and no NVMe. — [arXiv 2411.06376](https://arxiv.org/abs/2411.06376)
- **WaveformQA** (22 July 2026; abridged version at the IEEE International Conference on LLM-Aided Design 2026). 360 questions with programmatically generated ground truth over waveforms simulated from open-source designs; eight categories including multi-signal correlation and event ordering. Models degrade on complex temporal and multi-step questions; an event-time JSON form beats the raw value-change-dump format. A search summary gives in-context error rates of 67.9% for the raw format against 21.2% for JSON. It tests reading a waveform, not finding a fault's cause. — [arXiv 2607.20638](https://arxiv.org/abs/2607.20638)
- **HWE-Bench.** Confirmed: 417 tasks from real bug-fix pull requests in six open hardware projects; seven LLMs and four agent frameworks; best agent resolves 70.7%; above 90% on small cores, below 65% on SoC-level projects; failures fall into fault localization, hardware-semantic reasoning and cross-artifact coordination. No venue on the page (v3 5 May 2026). — [arXiv 2604.14709](https://arxiv.org/abs/2604.14709)
- **ChipBench** (preprint, Jan 2026). 44 hierarchical modules, 89 debugging cases, 132 reference-model samples; Claude 4.5 Opus reaches 30.74% on Verilog generation. A search summary says supplying waveform files helped 8 models and hurt 13. — [arXiv 2601.21448](https://arxiv.org/abs/2601.21448)
- **"Towards LLM-based Root Cause Analysis of Hardware Design Failures"** (IEEE COINS 2025, 6 pages). 34 buggy scenarios from synthesis and simulation; o3-mini is correct in 100% of cases under pass@5; other models usually above 80%. Small and already saturated. — [arXiv 2507.06512](https://arxiv.org/abs/2507.06512)
- FVDebug (NVIDIA): causal graphs from formal counterexample traces; 38 real failures, 95.6% hypothesis quality, 71.1% Pass@1 for fixes (search summary). VCDiag: a waveform classifier that maps failing dumps to modules, 77% top-1 (search summary). Neither is a public agent benchmark. — [FVDebug, arXiv 2510.15906](https://arxiv.org/pdf/2510.15906); [VCDiag, arXiv 2506.03590](https://arxiv.org/pdf/2506.03590)
- VerilogEval, RTLLM, CVDP, AssertSolver, LLM4DV: code generation, verification or assertion-repair sets, not trace diagnosis (carried). — [CVDP](https://arxiv.org/pdf/2506.14074); [AssertSolver](https://arxiv.org/html/2503.04057v1)

#### Network, wireless and telecom traces
- **PROBE** (preprint, 5 June 2026, authors Henry, Pradhan, Popovic). LLM ensemble diagnosis of 87 enterprise Wi-Fi captures (104 capture-reviewer pairs). Weighted evidence F1: expert baseline 0.871, single-pass LLM 0.912 but it misses critical frames in 35% of cases, reconciled ensemble 0.957. Self-reported confidence is uninformative (71% of reports at exactly 0.95). Private captures, not a benchmark. — [arXiv 2606.06871](https://arxiv.org/abs/2606.06871)
- 5G: AI5GTest uses a capture analyzer and a debugging LLM on 15 O-RAN test cases; TACO answers questions over core-network captures; MM-Telco's comparison table says earlier telecom benchmarks do not include capture analysis; an RRC trace corpus with an ASN.1 question-answering set exists (all search summaries). No standard public capture-based root-cause benchmark was found. — [AI5GTest review](https://www.themoonlight.io/review/ai5gtest-ai-driven-specification-aware-automated-testing-and-validation-of-5g-o-ran-components); [MM-Telco](https://arxiv.org/html/2511.13131v1); [TACO](https://fpvn.arrowhead.eu/wp-content/uploads/sites/3/2026/04/TACO_-_A_Generative_AI_Copilot_for_Intent-Based_Telecommunication_Core_Network_Analysis.pdf)
- PLUME, CFA-Bench, CyberSleuth, NetLLM, NetConfEval, TeleLogs, CAN-QA: as in the 12 November pass (carried, not re-read). — [PLUME](https://arxiv.org/abs/2603.13647); [TeleLogs](https://huggingface.co/datasets/netop/TeleLogs); [CAN-QA](https://arxiv.org/pdf/2604.24935)

#### Storage telemetry
- Alibaba released the NVMe SSD data behind its ATC 2022 study (over one million drives; SMART logs, failure tickets, iostat logs) on Tianchi, and the FAST 2021 correlated-failure data (about one million SATA/SAS SSDs, 11 models) on GitHub under `alibaba-edu/dcbrain/ssd_open_data` (search summary; link status not checked). The usual task is binary failure prediction within a window such as 30 days. — [ATC 2022 paper](https://www.usenix.net/system/files/atc22-lu.pdf); [dcbrain repository](https://github.com/alibaba-edu/dcbrain/tree/master/ssd_open_data); [FAST 2021](https://www.usenix.org/conference/fast21/presentation/han)
- These are per-drive fleet statistics. None is a wire-level capture, and no LLM benchmark built on them was found in this search. — [ATC 2022 paper](https://www.usenix.net/system/files/atc22-lu.pdf)

### Inferences
- The domain slot is still open after eleven searches across two passes. That is evidence of absence in the public literature only.
- Two neighbours set the bar for hardware traces. WaveformQA shows a venue for "LLMs reading hardware traces" exists but is a specialist one (ICLAD); Phantom shows DAC accepts synthetic PCIe trace work. Neither is an ML top venue.
- HWE-Bench at 70.7% and the COINS paper at 100% pass@5 are warnings: hardware debugging is not automatically hard for late-2026 models. Difficulty must come from scale and cross-layer linking, not from the domain being unfamiliar.
- WaveformQA's format result (structured event form beats raw dump) suggests the benchmark should fix and justify one input representation, or report both.

### Gaps
- Backblaze drive statistics were not searched for LLM use in this pass.
- CAN-bus fault-diagnosis sets were not re-searched; the 12 November entry (CAN-QA, intrusion-focused) stands unverified.
- Patents, DVCon, Flash Memory Summit talks and vendor white papers were not searched; internal use of language models on analyzer traces by SSD makers or analyzer vendors may exist unpublished.
- Phantom's repository and licence were not inspected.

## 3. Long and wide structured input

### Takeaway
Evidence that models fail on large tables still exists but has aged fast: Spider 2.0, which the 12 November pass used as its main proof (about one task in five solved), now shows 96.70 on its Snowflake setting. The surviving, current evidence is on multi-turn industrial table work (best agent covers 53.4%), million-row public data (scores under 0.4), raw trace formats (67.9% error) and cross-layer evidence synthesis; no benchmark was found that varies row count, column count and number of linked levels independently.

### Cited Findings
- **Correction to the 12 November pass.** The Spider 2.0 leaderboard read on 15 November 2026 shows top scores of 96.70 on Spider 2.0-Snow (Genloop Sentinel Agent v2 Pro), 76.23 on Spider 2.0-Lite (a Tencent data agent with GLM 5.2) and 65.6 on Spider 2.0-DBT (SignalPilot Agent). The page gives no submission dates. The 21.3% figure was the 2024 paper's baseline. The dataset still has 632 problems over databases that often exceed 1,000 columns. — [Spider 2.0 site](https://spider2-sql.github.io/)
- **TableAgent-Bench, ICML 2026 poster.** 2,275 industrial tables, 1,310 multi-turn dialogues, 25 agents; the best model, Gemini-3-Pro-Preview, reaches 53.4% information coverage. The poster page does not break results down by table size. — [ICML 2026 poster](https://icml.cc/virtual/2026/poster/66187)
- **DataGovBench** (preprint, July 2026; search summary only). Tables average about 210K rows and 18 columns, the largest about 11.9M rows; agent pipelines were needed because tables exceed context; scores in the "Whole" setting stay under 0.4. — [arXiv 2607.06482](https://arxiv.org/html/2607.06482)
- **Trace format matters.** WaveformQA: raw value-change-dump input gives a 67.9% in-context error rate against 21.2% for an event-time JSON form (search summary); the abstract page confirms the direction. — [arXiv 2607.20638](https://arxiv.org/abs/2607.20638)
- **Cross-layer attribution.** CUJBench: agents often retrieve the decisive evidence but assign it to the wrong component; wider evidence access lowered accuracy. — [arXiv 2604.23455](https://arxiv.org/html/2604.23455v1)
- **Depth of chain.** Accuracy falls with propagation depth for a weaker backbone and much less for a stronger one (85.5% to 57.1% against 88.2% to 85.7%). — [arXiv 2608.21310](https://arxiv.org/html/2608.21310v1)
- **Synthetic time-series reasoning.** TimeSeriesExam (arXiv Oct 2024) uses synthetic series with fully known properties across five categories; its follow-up TimeSeriesExamAgent is in the ICLR 2026 proceedings and extends generation to real healthcare, finance and weather data. TraceBench finds agents lean on numeric console output over plots and do worse when asked to write a labelling script than when predicting directly. — [TimeSeriesExam](https://arxiv.org/html/2410.14752v1); [TimeSeriesExamAgent, ICLR 2026](https://proceedings.iclr.cc/paper_files/paper/2026/hash/8b6dd6597c2edeb9ee62468ccea6f512-Abstract-Conference.html); [TraceBench](https://arxiv.org/abs/2608.27182)
- NeedleInATable (NeurIPS 2025), RUST-BENCH, T2R-bench, MMQA (ICLR 2025), TRAIL (best joint accuracy 11%): as in the 12 November pass (carried, not re-read). — [NeedleInATable](https://arxiv.org/abs/2504.06560v4); [TRAIL](https://arxiv.org/html/2505.08638v3)

### Inferences
- Do not cite Spider 2.0's 2024 baseline as proof that wide schemas defeat current agents; a reviewer who checks the leaderboard will see 96.70. Cite it as a benchmark that saturated within two years, which supports a generator that can mint fresh cases.
- The claim that would be new: scaling curves for one task along three controlled axes (rows, columns, linked levels), with identity-linked rows. No paper found does this. It is a hypothesis until measured.
- Agents with code execution turn "long and wide" into a tool-use problem. The hard part that remains in the cited results is deciding which evidence belongs to which component and following a chain, so the benchmark's difficulty should be designed there.

### Gaps
- No per-size breakdown was obtained for TableAgent-Bench or DataGovBench.
- BIRD's current top scores were not checked.
- No benchmark was found that tests joining rows across levels by identity against joining by time; this stays an unproven idea (same gap as on 12 November).
- The engineer's table width is given as about 113 columns in this brief and as 1,598 columns in the 12 November notes; which figure describes the released data was not resolved.

## 4. Reviewer demands

### Takeaway
ICML 2027 is the only target with a confirmed deadline inside reach: abstract 14 January and full paper 22 January 2027, with "Datasets, Evaluations and Benchmarks" as a contribution type in the main track. KDD and SIGIR tracks are single-blind and care most about access, documentation and impact; NeurIPS demands hosted data, Croissant with responsible-AI fields and a declared synthetic flag. No review text on synthetic benchmarks could be read, so the treatment of synthetic data is inferred from accepted papers.

### Cited Findings

#### Dates and rules read on 15 November 2026
- **ICML 2027 (correction to the 12 November pass, which said dates were not posted).** Submission site opens 8 January 2027; abstract 14 January; full paper 22 January (AoE); first-stage rejection notices 23 February; final decisions 3 May 2027. Eight pages main text. One contribution type is "Datasets, Evaluations and Benchmarks"; topics include "evaluation (methodology, meta studies, replicability and validity, human-in-the-loop, etc.)". The call states no dataset-hosting or Croissant rule. Substantive generative-AI use must be disclosed in an AI Disclosure Statement. — [ICML 2027 call](https://icml.cc/Conferences/2027/CallForPapers)
- ICML 2027 reciprocal reviewing: each submission names one eligible author as reciprocal reviewer; authors with no eligible reciprocal reviewer among their co-authors may appear on at most one submission; papers can be desk-rejected if the reviewer fails to review. — [ICML 2027 quotas page](https://icml.cc/Conferences/2027/ReciprocalReviewingAndSubmissionQuotas)
- **KDD 2027 Datasets and Benchmarks track** (San Jose, 1 to 5 August 2027). The track page lists abstract 19 July 2026, paper 26 July 2026, notification 14 November 2026. No second-cycle dates are on the page. Single-blind; at least three reviews; 8 content pages. "Datasets should be easily accessible to the research community without requiring personal requests." "Clear, detailed descriptions of how data was collected, curated, and organized are required." "Any associated code or tools must be open source and well-documented." Croissant and a specific licence are not mentioned. — [KDD 2027 track page](https://kdd2027.kdd.org/datasets-and-benchmarks-track-call-for-papers/); [KDD 2027 home](https://kdd2027.kdd.org/)
- KDD 2026 ran this track in its second cycle (abstract 1 February, paper 8 February 2026, notification 16 May 2026). Scope includes "data generators and environments". Criteria: accessibility, quality and documentation, impact, ethics. At most two submissions per author per cycle. — [KDD 2026 track page](https://kdd2026.kdd.org/datasets-and-benchmarks-track-call-for-papers/)
- **SIGIR 2027** (San Jose, 19 to 24 July 2027). Full papers: abstract 14 January, paper 21 January 2027, notification 5 April. Resource and reproducibility deadlines are "TBA". — [SIGIR 2027 site](https://sigir2027.org/)
- SIGIR 2025 resource criteria (latest full text found): novelty; availability ("The resource must be available to reviewers at the time of submission", links "publicly accessible without requiring logins", licence "sufficiently open to allow most academic and industry researchers access"); utility; documentation; predicted impact, which asks which information-retrieval research the resource enables. Single-blind; at most 9 pages. — [SIGIR 2025 call](https://sigir2025.dei.unipd.it/call-res-repro-papers.html)
- **NeurIPS 2026 Evaluations and Datasets** (search summary re-confirming the 12 November reading): renamed track; data generators in scope; review as stringent as the main track; datasets hosted and documented at submission with Croissant files; responsible-AI metadata mandatory; reviews ran 29 May to 25 June 2026; notification 24 September 2026. Detailed rules (4 GB sample rule, hasSyntheticData field, private hold-out wording) are carried from the 12 November pass. — [NeurIPS 2026 call](https://neurips.cc/Conferences/2026/CallForEvaluationsDatasets); [reviewer guidelines](https://neurips.cc/Conferences/2026/EvaluationsDatasetsReviewerGuidelines); [responsible-AI metadata post](https://blog.neurips.cc/2026/05/04/responsible-ai-metadata-requirements-for-the-evaluations-and-datasets-track-neurips-2026/)

#### What accepted or prominent benchmarks reported (the working standard)
- Models and set-ups: HWE-Bench, seven LLMs and four agent frameworks; OpenRCA 2.0 and Cloud-OpsBench, eleven LLMs each; DistDebug-Bench, thirteen models on one harness plus two harness comparisons; ORCA-bench, five frontier agents; CUJBench, six models under three tool settings on a 25-scenario subset; TraceBench, four agents. — [HWE-Bench](https://arxiv.org/abs/2604.14709); [OpenRCA 2.0](https://arxiv.org/abs/2606.27154); [Cloud-OpsBench](https://arxiv.org/abs/2603.00468); [DistDebug-Bench](https://arxiv.org/html/2611.03523v1); [ORCA-bench](https://arxiv.org/abs/2607.28545); [CUJBench](https://arxiv.org/html/2604.23455v1); [TraceBench](https://arxiv.org/abs/2608.27182)
- Label checks: three annotators per issue with reconciliation (DistDebug-Bench, which also admits agreement was measured on only 51 of 120 incidents); expert SREs plus human re-scoring of the LLM judge (ORCA-bench); injection spec, then multi-agent review, then human SRE checks on a sample (CUJBench); only cases with expert-traceable footprints kept (RCA100). — [DistDebug-Bench](https://arxiv.org/html/2611.03523v1); [ORCA-bench](https://arxiv.org/abs/2607.28545); [CUJBench](https://arxiv.org/html/2604.23455v1); [arXiv 2606.29193](https://arxiv.org/html/2606.29193v1)
- Solvable-but-hard evidence: RCABench validated that every case has a visible effect on user-facing indicators (1,430 kept of 9,152 injections). — [arXiv 2510.04711](https://arxiv.org/abs/2510.04711)
- Statistical care is now an explicit selling point: NetArena reports cutting confidence-interval overlap between agents from 85% to 0 by generating more queries; DistDebug-Bench lists "only three attempts per bug" among its limits. — [NetArena](https://arxiv.org/abs/2506.03231); [DistDebug-Bench](https://arxiv.org/html/2611.03523v1)
- Contamination: NetArena argues static benchmarks risk contamination and generates queries at run time; DyVal (ICLR 2024 spotlight) generates reasoning samples on the fly for the same reason; DistDebug-Bench concedes contamination "cannot be fully ruled out". — [NetArena](https://arxiv.org/abs/2506.03231); [DyVal, ICLR 2024](https://iclr.cc/virtual/2024/poster/18134); [DistDebug-Bench](https://arxiv.org/html/2611.03523v1)

#### How synthetic or generated benchmarks argued realism

| Benchmark | Venue | What is synthetic | Realism argument |
|---|---|---|---|
| NetArena | ICLR 2026 (per Microsoft Research) | All queries, generated at run time | Actions executed in network emulators (Mininet, Kubernetes) for correctness, safety, latency |
| TimeSeriesExamAgent / TimeSeriesExam | ICLR 2026 (follow-up) | Series and questions from templates | Templates curated with time-series experts and cross-verified; follow-up adds real datasets |
| DyVal | ICLR 2024 spotlight | Reasoning items from graphs | No realism claim; sold on contamination resistance and controllable complexity |
| The Phantom of PCIe | DAC 2026 | PCIe packet traces | Protocol-rule filter plus validation against a real network card |
| WaveformQA | ICLAD 2026 (abridged) | Questions and answers | Waveforms simulated from open-source designs |
| CRMArena | NAACL 2025 (carried) | Records in a real Salesforce org | Ten domain users; 90% rated it realistic or better |
| RCABench, RCA100, Cloud-OpsBench | FSE 2026; preprints | Fault injection | Real software stack underneath; cases filtered for visible, traceable effects |
| TeleLogs, TraceBench | Preprints, no venue found | Fully simulated | Simulator of the physical or radio system; no peer-reviewed acceptance found |

Sources: [NetArena MSR page](https://www.microsoft.com/en-us/research/publication/netpress-dynamically-generated-llm-benchmarks-for-network-applications/); [TimeSeriesExamAgent](https://proceedings.iclr.cc/paper_files/paper/2026/hash/8b6dd6597c2edeb9ee62468ccea6f512-Abstract-Conference.html); [DyVal](https://iclr.cc/virtual/2024/poster/18134); [Phantom](https://arxiv.org/abs/2411.06376); [WaveformQA](https://arxiv.org/abs/2607.20638); [CRMArena](https://arxiv.org/html/2411.02305v2); [RCABench](https://arxiv.org/abs/2510.04711); [TraceBench](https://arxiv.org/abs/2608.27182); [TeleLogs](https://huggingface.co/datasets/netop/TeleLogs)

### Inferences
- Venue fit, plainly: ICML 2027 (22 January) is reachable with results by 15 December but is a main-track bar with no separate dataset track. NeurIPS 2027 Evaluations and Datasets (about May 2027 if the 2026 pattern repeats, unconfirmed) is the best-matched track. KDD 2027's track page shows only the July 2026 cycle. SIGIR is a poor fit: its resource criteria ask what information-retrieval research the resource enables, and this benchmark is not a retrieval resource unless framed as evidence retrieval over traces.
- Generator-only benchmarks have been accepted at ICLR when sold on control and contamination resistance (DyVal, NetArena), not on realism. Fully simulated diagnosis sets with no second source (TeleLogs, TraceBench) had no peer-reviewed venue that this pass could find.
- Every accepted case in the table has one of: real software or hardware underneath, an emulator that executes the output, expert-curated templates, or validation against one real device. "The author's generator alone" has no accepted precedent found here.
- A sole industry author must check ICML's reciprocal-reviewer eligibility early; the page read does not define eligibility.

### Gaps
- No OpenReview review of any synthetic benchmark was read; the site blocked automated access. How reviewers actually worded realism objections is unknown.
- SIGIR 2027 resource-track criteria and deadline are not published. KDD 2027 second-cycle dates for this track were not on the page read.
- NeurIPS 2027 dates and rules are not out.
- The NeurIPS 2025 and 2026 acceptance rates for the track were not found.
- NetArena's ground-truth derivation and ICLR status rest on the Microsoft Research page and a search summary; the arXiv page lists no venue.

## 5. Realism without real captures

### Takeaway
A second, independent source is available for the NVMe command and transaction levels within weeks: QEMU's NVMe model has about 225 trace events carrying command identifiers, queue identifiers, opcodes and status, the Linux driver has submission and completion tracepoints plus a fault-injection facility, and Wireshark decodes NVMe over TCP. For the PCIe link, packet and split-transaction levels no open capture or decode path was found, so those three levels can only be defended by specification rules, a simulation framework, or expert review.

### Cited Findings
- **NVMe specifications are publicly downloadable.** NVM Express states its specifications are available for download on its site; the set includes the Base specification, command-set specifications and transport specifications including the PCIe Transport specification, whose PDF is directly reachable. — [NVM Express release](https://nvmexpress.org/?p=19725); [NVMe PCIe Transport specification 1.1](https://nvmexpress.org/wp-content/uploads/NVM-Express-PCI-Express-Transport-Specification-Revision-1.1-2024.08.05-Ratified.pdf)
- **PCI Express specifications are not public.** Per the PCI-SIG specifications page as summarised by search, members read specifications online at no cost and non-members may only purchase copies; a 2017 report put a non-member copy at $4,500 and a secondary source gives a $4,000 annual membership fee (both dated, unverified). — [PCI-SIG specifications page (mirror)](https://2.gy-118.workers.dev/:443/https/pcisig.com/specifications); [2017 report](https://bit-tech.net/news/pci-sig-finalises-pcie-40-specification-teases-early-adoption/1); [Wikipedia, PCI-SIG](https://en.wikipedia.org/wiki/PCI-SIG)
- **QEMU NVMe model.** The emulated controller "implements version 1.4 of the NVM Express specification", with multiple namespaces, subsystems, zoned namespaces, flexible data placement, metadata, end-to-end protection and experimental SR-IOV. Known gaps: SMART counters reset on power cycle; no interrupt coalescing. The documentation page does not mention tracing or error injection. — [QEMU NVMe documentation](https://www.qemu.org/docs/master/system/devices/nvme.html)
- **QEMU NVMe trace events.** The `hw/nvme/trace-events` file defines roughly 225 events (approximate count): about 130 normal, about 73 error (`pci_nvme_err_*`), about 23 guest-error (`pci_nvme_ub_*`). `pci_nvme_io_cmd` carries cid, nsid, sqid, opcode and an operation name; `pci_nvme_err_req_status` carries cid, nsid, status and opcode; `pci_nvme_enqueue_req_completion` records completions. — [QEMU trace-events file](https://raw.githubusercontent.com/qemu/qemu/master/hw/nvme/trace-events)
- **Linux NVMe fault injection.** A debugfs facility forces errors at command completion, with parameters for status code, retry permission, probability, count, Nth command and target opcode. Documented outcomes include a write failing with "Invalid Command Opcode (sct 0x0 / sc 0x1) DNR" on a QEMU Q35 machine, and a failed admin command after reset producing "Could not set queue count". — [kernel documentation](https://docs.kernel.org/fault-injection/nvme-fault-injection.html)
- **Linux NVMe tracepoints.** `nvme_setup_cmd` and `nvme_complete_rq` were added for kernel 4.16; `nvme_async_event` covers asynchronous event notices. A 2026 patch notes that on a host path error the setup event was skipped, so completions logged with cmdid=0 could not be matched to commands. — [2018 patch series](https://lore.kernel.org/all/20180116142821.11693-1-jthumshirn@suse.de/T/); [2026 patch](https://lkml.iu.edu/hypermail/linux/kernel/2603.3/04516.html)
- **Wireshark.** An NVMe over TCP dissector (`packet-nvme-tcp.c`) was added in May 2019 on top of a fabric-agnostic NVMe dissector (`packet-nvme.c`), tested against Linux 5.0 host and target drivers, with a sample capture attached to the bug report. This decodes NVMe commands and completions carried over TCP, not over PCIe. — [Wireshark commit](https://lists.wireshark.org/archives/wireshark-commits/201905/msg00130.html); [packet-nvme.h](https://www.wireshark.org/docs/wsar_html/packet-nvme_8h_source.html)
- **PCIe side.** cocotbext-pcie is an open simulation framework covering enumeration, configuration space, memory reads and writes, and interrupts, with models of Xilinx hard cores; it "currently only support[s] operation as a device, not as a root port" per the summary read. Phantom's prototype is open source and enforces protocol rules on generated packet traces. No open tool was found that emits link-level (training state, data-link packet) traces. — [cocotbext-pcie on PyPI](https://pypi.org/project/cocotbext-pcie/0.2.6); [Phantom](https://arxiv.org/abs/2411.06376)
- **FEMU and NVMeVirt.** No fault-injection feature or fault trace output was found for either; NVMeVirt is a kernel module that presents a native NVMe device (search summary, source trees not inspected). — [NVMeVirt tutorial](https://csl.snu.ac.kr/courses/4190.568/2026-1/nvmevirt-tutorial.pdf)
- **Precedents for this style of argument.** Phantom validated synthetic PCIe traces against rule compliance and one real card (DAC 2026). WaveformQA grounded its waveforms in open-source designs. NetArena executes outputs in emulators. — [Phantom](https://arxiv.org/abs/2411.06376); [WaveformQA](https://arxiv.org/abs/2607.20638); [NetArena](https://arxiv.org/abs/2506.03231)

### Inferences
- A practical cross-check that fits a few weeks: run a Linux guest on QEMU's NVMe device, drive I/O, inject faults with the kernel facility, and record three independent views (QEMU `pci_nvme_*` events, kernel `nvme_setup_cmd` / `nvme_complete_rq` events, and nvme-cli error-log pages). Then show that the generator's NVMe command and transaction levels agree with these on field ranges, command-to-completion pairing, status codes and retry behaviour, and that baseline models rank the same way on both sources. This is an inference about feasibility; it was not tested.
- This covers two of five levels. The link, packet and split-transaction levels would rest on rule conformance and expert rating only. The paper should say so directly. Because the PCIe specification is a member document, conformance claims for those levels cannot be checked by an outside reviewer; the NVMe levels can.
- "Conforms to the public specification" is a correctness argument, not a realism argument. It shows traces are legal, not that their faults look like field faults. No accepted paper found here rested on specification conformance alone; each added a real device, real software, an emulator or experts.
- NVMe-over-TCP captures decoded by Wireshark give a third-party decoder for the NVMe layer, which helps answer "one vendor's export format".

### Gaps
- SPDK's tracing and error-injection facilities were not checked.
- Whether QEMU's NVMe model can inject completion errors without the guest kernel facility was not established; its documentation page is silent.
- Linux PCIe error-reporting tracepoints and the `aer-inject` tool returned nothing in the search run; they may give a partial second source for link-level error events.
- Whether reproducing an analyzer vendor's column layout in a public dataset is permitted remains unanswered.
- Current PCI-SIG prices and the NVM Express membership terms for implementers were not confirmed on the official pages.

## 6. The verdict

### Takeaway
The gap is open in domain and data shape, but narrower than the 12 November notes implied: causal-chain ground truth, controlled synthetic generation for diagnosis, and synthetic PCIe traces each already exist separately. The benchmark is defensible only as the first to combine them in one identity-linked, multi-layer, long and wide event stream, and only if a pilot shows current agents fall well short while a rule engine does not solve the scored task.

### Cited Findings

#### The three works a reviewer would cite as "this already exists"
- **OpenRCA 2.0** (preprint, "work in progress", June 2026). How close: step-wise causal propagation paths built from known fault-injection interventions, 500 instances, 11 LLMs, and the "ungrounded diagnosis" finding. What it lacks: it is cloud microservice telemetry; no hardware or protocol layers; no single wide table; no rows of one event linked across decode levels; not peer-reviewed. — [arXiv 2606.27154](https://arxiv.org/abs/2606.27154)
- **TraceBench** (preprint, August 2026). How close: a "simulation-based framework" for "controlled evaluation of LLM agents" on root-cause attribution, with data, trajectories and a leaderboard released; it owns the name and the "controlled synthetic diagnosis" framing. What it lacks: low-dimensional time series from three mechanical systems; the answer is one altered parameter, not a chain; no event tables, layers or scale. — [arXiv 2608.27182](https://arxiv.org/abs/2608.27182)
- **The Phantom of PCIe** (DAC 2026). How close: synthetic PCIe transaction-layer traces that obey protocol rules, open-source prototype. What it lacks: no injected faults, no labels, no diagnosis task, no NVMe, one packet level only. — [arXiv 2411.06376](https://arxiv.org/abs/2411.06376)
- Likely secondary citations: RCA100 (four-layer ground truth with cause, propagation, impact chains and 661 evidence checkpoints, but 103 cloud cases); Cloud-OpsBench (evidence graphs, 754 cases); WaveformQA (hardware temporal reasoning, 360 questions, no faults); HWE-Bench (hardware debugging by agents, code repair not trace diagnosis); CUJBench (cross-layer diagnosis, browser to backend, 87 scenarios). — [arXiv 2606.29193](https://arxiv.org/html/2606.29193v1); [Cloud-OpsBench](https://arxiv.org/abs/2603.00468); [WaveformQA](https://arxiv.org/abs/2607.20638); [HWE-Bench](https://arxiv.org/abs/2604.14709); [CUJBench](https://arxiv.org/html/2604.23455v1)

#### Facts that set the size of a credible baseline package
- Smallest evaluated set among the 2026 works read: CUJBench ran six models under three tool settings on 25 scenarios (446 runs) as a single-author preprint; TraceBench ran four agents. Largest: DistDebug-Bench with thirteen models. — [CUJBench](https://arxiv.org/html/2604.23455v1); [TraceBench](https://arxiv.org/abs/2608.27182); [DistDebug-Bench](https://arxiv.org/html/2611.03523v1)
- Process metrics in use: node F1 and edge F1 over the propagation graph; grounded against ungrounded correct answers; evidence closure; block coverage with precision. — [arXiv 2608.21310](https://arxiv.org/html/2608.21310v1); [OpenRCA 2.0](https://arxiv.org/abs/2606.27154); [Cloud-OpsBench](https://arxiv.org/abs/2603.00468); [DistDebug-Bench](https://arxiv.org/html/2611.03523v1)
- Non-ML baselines are expected and can sink a benchmark: rule-based methods matched or beat state-of-the-art models on four public benchmarks. — [RCABench](https://arxiv.org/abs/2510.04711)
- Run-to-run disagreement is a reported result in its own right (12% to 17% flaky diagnoses for the leading configuration), and only 21.0% of runs recover from an early wrong hypothesis. — [DistDebug-Bench](https://arxiv.org/html/2611.03523v1)
- The nearest confirmed deadline is ICML 2027: abstract 14 January, full paper 22 January 2027. — [ICML 2027 call](https://icml.cc/Conferences/2027/CallForPapers)

### Inferences

#### Is the gap open?
- Yes for the domain: no public PCIe or NVMe trace corpus with labelled faults, and no language-model work on protocol-analyzer captures, in eleven searches across two passes.
- Yes for the shape: no benchmark found has several decode levels of the same events, linked by identity, in one long and wide table with the chain known across levels.
- No for three single ingredients: causal-chain labels (OpenRCA 2.0, RCA100, the RCABench trajectory study), synthetic controlled diagnosis (TraceBench, TeleLogs), synthetic PCIe traces (Phantom). Claiming any of these as a first would be an overstatement.
- Whether a top venue would value it is not settled by the gap. It depends on measured difficulty and on a realism argument stronger than "my generator".

#### Sharpest one-sentence statement of the gap
- "Existing diagnosis benchmarks label the causal chain only across services in cloud telemetry, and existing hardware-trace sets have no faults with known causes; none tests whether an agent can follow one fault through several protocol layers of a single long, wide event stream whose rows are linked by identity, where the full chain from wire-level cause to command-level symptom is known by construction and difficulty can be dialled along length, width, depth and fault count."

#### Positioning so it reads as general
- Lead with the data shape and the control knobs, not with solid-state drives: "hierarchical event traces" with PCIe and NVMe as the instantiation, the way NetArena leads with a state-and-action abstraction and treats three network applications as instances.
- Name the same shape elsewhere in the related work: network stacks (frames, packets, flows, sessions), cellular signalling, distributed tracing spans, CAN frames to diagnostic sessions. Do not claim results there.
- Report scaling curves on four axes (rows, columns exposed, levels crossed, concurrent faults) plus fault-free traces. That is the ML result; the domain is the testbed.
- Sell the generator as the contamination answer, citing the saturation of Spider 2.0 and the DyVal and NetArena precedents.
- State the synthetic nature up front, and give the QEMU and Linux cross-check for the NVMe levels and the limits for the PCIe levels.

#### Smallest credible baseline set
- Models: five or six, including two open-weight models and at least two current frontier models.
- Set-ups: (1) direct prompting on a sampled or truncated window, to show the context limit; (2) a code-executing tool agent over the full files; (3) one off-the-shelf coding agent. Run the two costly set-ups on a stratified subset of about 100 to 150 cases, three seeds each.
- Non-ML: the rule engine, random, majority-class, and a "do nothing / always healthy" baseline on fault-free traces.
- Metrics: fault location accuracy; root-cause accuracy; chain node F1 and edge F1 per level crossed; share of correct answers that are grounded; false-alarm rate on clean traces; tokens, tool calls and cost per case; confidence intervals and run-to-run agreement.
- Breakdowns: per fault kind, per chain depth, per scale setting; never one pooled number.
- Validation: the QEMU and Linux agreement study for NVMe levels; two or three engineers other than the author to check a label sample and rate realism blind.

#### Is that achievable in 30 days by one person?
- The model runs, metrics, scaling curves and the QEMU cross-check are scripting and compute; with the generator and truth files already built, 30 days is plausible if the costly agent runs are kept to a subset. This is a judgement, not a measured estimate.
- Not within one person's control: colleagues' hours for label checks and realism ratings, and employer clearance to release the generator and layout. These are the schedule risks, as the 12 November notes also said.
- A first-week pilot (about 50 cases, two models, the rule engine) decides whether to proceed. If the best agent already exceeds roughly the 70% to 90% seen on HWE-Bench and RCABench, the scored task must be made harder before anything else is built; if the rule engine solves the scored task, the same applies.
- Venue timing: results by 15 December 2026 leave five weeks to the ICML 2027 full-paper deadline of 22 January 2027. The better-matched NeurIPS 2027 track would allow time for the expert-validation items.

### Gaps
- Difficulty for late-2026 models on this data is unmeasured; every statement about value depends on it.
- No evidence was found on how single-author, single-company benchmark papers fare at these venues.
- Employer clearance and the legal status of the analyzer export layout are unknown and decide whether any public release is possible.
- The brief gives 59 scenario sets and 113 columns; the 12 November notes give 17 scenarios, 1,598 columns and a rule engine finding 437 of 485 errors. The current figures for the rule engine on the scored task were not available to this pass.
- NeurIPS 2027, KDD 2027 second-cycle and SIGIR 2027 resource-track dates are unpublished.
