# Public-benchmark design for the model-swap study of stored memory scores: code, benchmarks, models, arms, statistics, budget and calendar (state of 15 November 2026)

How to read these notes.

- Everything was read on 15 November 2026. "Read" means the page, file or API response was fetched and its text inspected in this pass. "Abstract only" means only the OpenReview abstract and TL;DR were reachable.
- GitHub facts (licence, last push, stars) come from the GitHub REST API on 15 November 2026. Prices come from the makers' own price pages on the same day.
- No paid model call was made and no project file was changed. Every dollar figure built on an assumed token count is marked **estimate** and the arithmetic is shown.
- The three earlier notes (novelty recheck, red team, venue path) were read first and their literature review is not repeated. Where this pass corrects or sharpens them it says so.
- Short answer: a credible study can be finished by 15 December 2026 by one person, but only if the main experiments run on cheap single-call stream tasks with a thin, published-rule score layer, with the released MemRL code used as one confirming leg on LifelongAgentBench. A study built on re-running MemRL, CHIME or RoMeRL end to end on HLE, BigCodeBench or ALFWorld cannot be finished in the time or budget.

## 1. Released code: which scored-memory systems are public and runnable, and which is the best base?

### Takeaway
Only MemRL has a full, public, runnable implementation of a numeric per-item score with export and reload; CHIME has no code in its repository, RoMeRL ships evaluation-only code plus two frozen score checkpoints, and EvoKernel and MemCollab have no official repository that could be found. The best base is a pair: MemRL's code on LifelongAgentBench (DB or OS) as the "released system" leg, and a thin re-implementation of MemRL's Q rule and ACE's helpful/harmful counters on single-call stream tasks as the main ground, because MemRL's own maintainers report multi-day runs and about USD 1,000 for one benchmark.

### Cited Findings

**Per-system facts (GitHub API and READMEs, read 15 November 2026)**

| System | Repository, licence, last push | Model interface | Score storage and export | Benchmarks covered by scripts | Reported cost or tokens |
|---|---|---|---|---|---|
| MemRL | [MemTensor/MemRL](https://github.com/MemTensor/MemRL), MIT, pushed 18 July 2026, 202 stars, 5 open issues | OpenAI-compatible only (`provider: "openai"`, `base_url`); temperature always sent | `q_value` and `q_visits` in each memory's metadata; JSON q-cache; snapshot save and load | HLE, BigCodeBench, ALFWorld, LifelongAgentBench DB and OS | About 32K tokens per HLE question; BigCodeBench "close to USD 1,000" with GPT-4o |
| RoMeRL | [YOUNG-fnxm/RoMeRL](https://github.com/YOUNG-fnxm/RoMeRL), MIT, pushed 14 August 2026, 10 stars | OpenAI-compatible (`base_url`, `model` in YAML) | `q_cache.json` ("memory ID to its frozen scalar Q estimate"), read-only | LifelongAgentBench DB and OS, ALFWorld (evaluation only) | No dollar figure; paper says fewer LLM calls than MemRL |
| CHIME | [ATH-MaaS/Marco-DeepResearch](https://github.com/ATH-MaaS/Marco-DeepResearch), Apache-2.0, pushed 9 September 2026 | not applicable | No CHIME code present | none | none |
| ACE | [ace-agent/ace](https://github.com/ace-agent/ace), Apache-2.0, pushed 24 August 2026, 1,457 stars | `sambanova`, `together`, `openai`, `commonstack` | Plain-text playbook, one line per item: `[str-00001] helpful=5 harmful=0 :: ...` | FiNER and XBRL Formula (finance); AppWorld described | Online FiNER: ACE USD 2.9 against Dynamic Cheatsheet USD 17.7 |
| Dynamic Cheatsheet | [suzgunmirac/dynamic-cheatsheet](https://github.com/suzgunmirac/dynamic-cheatsheet), MIT, pushed 12 March 2026, 280 stars | OpenAI, Anthropic, Gemini, Together, DeepSeek, Ollama (`provider/model` names) | Free-text cheatsheet; no per-item number | GameOf24, AIME sets, GPQA Diamond, MMLU-Pro Physics and Engineering, MathEquationBalancer | see ACE row |
| ReasoningBank | [google-research/reasoning-bank](https://github.com/google-research/reasoning-bank), Apache-2.0, pushed 5 August 2026, 645 stars | GPT through OpenAI key; Gemini and Claude through Vertex AI | Text memory items; no per-item number | WebArena (Docker sites), SWE-bench (mini-swe-agent) | none in README |
| ExpeL | [LeapLabTHU/ExpeL](https://github.com/LeapLabTHU/ExpeL), Apache-2.0, pushed 20 December 2024, 252 stars | not read | Insight list (README sections: experience gathering, insights extraction, evaluation) | ALFWorld, WebShop (README table of contents) | not read |
| Agent Workflow Memory | [zorazrw/agent-workflow-memory](https://github.com/zorazrw/agent-workflow-memory), Apache-2.0, pushed 22 December 2025, 484 stars | not stated in README | Workflows as text; no per-item number | WebArena, Mind2Web | none |
| Memp | [zjunlp/MemP](https://github.com/zjunlp/MemP), MIT, pushed 30 January 2026, 42 stars | OpenAI-compatible (`OPENAI_API_BASE`) | Procedural text memory; no score described in README | TravelPlanner, ALFWorld | none |
| HEIRS (ICLR 2027 submission) | [anonymous.4open.science/r/HEIRS](https://anonymous.4open.science/r/HEIRS), no licence stated | user supplies an evaluator function | `source_score` per archived skill in `history.json` | adapters not shipped ("benchmark adapters ... are not redistributed here") | none |

**MemRL in detail**
- The README gives four runners (`run/run_hle.py`, `run_alfworld.py`, `run_llb.py`, `run_bcb.py`) and says all benchmarks read "LLM + embedding settings from YAML configs", with optional `llm.base_url` "for OpenAI-compatible endpoints (vLLM, etc.)". — [MemRL README](https://github.com/MemTensor/MemRL/blob/main/README.md)
- Scores are stored per item: the updater's docstring is "Persist and update memory Q-values in MemOS textual memory metadata"; new items get `"q_value"` and `"q_visits": 0`. — [value_driven.py](https://github.com/MemTensor/MemRL/blob/main/memrl/service/value_driven.py); [memory_service.py](https://github.com/MemTensor/MemRL/blob/main/memrl/service/memory_service.py)
- Export and reload exist: `save_checkpoint_snapshot` writes `<ck_dir>/snapshot/<id>/` with `cube`, `qdrant`, `snapshot_meta.json` and a `local_cache` holding the q-cache as JSON; `load_checkpoint_snapshot` restores it. This closes the gap in the novelty note ("the snapshot format in the code was not inspected"). — [memory_service.py](https://github.com/MemTensor/MemRL/blob/main/memrl/service/memory_service.py)
- A maintainer confirms the values can be read offline "by parsing either: 1. the q-cache stored under `local_cache`, or 2. the final `textual_memory.json` dumped into Cube." — [MemRL issue 7](https://github.com/MemTensor/MemRL/issues/7)
- Most scores never move. The maintainer's own ALFWorld bank had 33,463 items at exactly Q = 0 out of about 35,185 (my sum of the posted bins); a user's run showed 50.6% of items at zero after epoch 1 and 69.1% after epoch 6, with 0.56% positive. — [MemRL issue 7](https://github.com/MemTensor/MemRL/issues/7)
- Retrieval has no exploration: "You're right that the retrieval path is deterministic given a fixed M"; "`epsilon=0` in the ALF config reflects that we didn't implement ε-greedy on retrieval." — [MemRL issue 11](https://github.com/MemTensor/MemRL/issues/11)
- Run time and cost, from the maintainers: the BigCodeBench runner "is effectively task-serial"; "a full run can indeed take multiple days"; "even when using gpt-4o, the total cost for BCB alone was already close to USD 1,000"; HLE is "even more expensive by a very large margin". A user reported 12 to 24 hours per BigCodeBench epoch and "about 300 USD on Gemini 2.5 Flash" spent in trial and error; the ALFWorld runner froze repeatedly from connection-pool contention. — [MemRL issue 10](https://github.com/MemTensor/MemRL/issues/10)
- An independent reproduction on BigCodeBench with `gpt-4o-2024-11-20` found almost no held-out gain: no-memory validation 46.0%, best validation with MemRL 46.8% (epoch 8), last-epoch training 50.1%, against the paper's 48.5%, 50.8% and 59.5%. — [MemRL issue 12](https://github.com/MemTensor/MemRL/issues/12)
- Open bug reports that touch score handling: a stale retrieval cache after a Q update, loss of an updated Q after cache eviction, and "Retrieval currently has no source-task exclusion argument, so an evaluation query can select a memory from the same task." — [issue 16](https://github.com/MemTensor/MemRL/issues/16); [issue 17](https://github.com/MemTensor/MemRL/issues/17); [issue 18](https://github.com/MemTensor/MemRL/issues/18)
- Default settings in the released HLE config: `temperature: 0.6`, `num_sections: 10`, `alpha: 0.3`, `weight_sim: 0.5`, `weight_q: 0.5`, `q_init_pos: 0`, `epsilon: 0`. — [rl_hle_config.yaml](https://github.com/MemTensor/MemRL/blob/main/configs/rl_hle_config.yaml)
- The paper's HLE cost: "the average total token consumption per question for MemRL is approximately 32K", over "2,500 questions per epoch" and 10 epochs. — [MemRL v2](https://arxiv.org/html/2601.03192v2)
- The paper's held-out ("transfer learning") table shows how little the score adds over similarity-only retrieval on the same benchmarks: BigCodeBench 0.508 (MemRL) against 0.479 (RAG) and 0.485 (no memory); LifelongAgentBench OS 0.746, 0.713, 0.673; DB 0.942, 0.920, 0.841; ALFWorld 0.979, 0.950, 0.836. — [MemRL v2](https://arxiv.org/html/2601.03192v2)
- Splits: LifelongAgentBench OS and DB 500 tasks each with a 7:3 split (seed 42); BigCodeBench 1,140 tasks; ALFWorld 3,553 training tasks and 140 `valid_seen` tasks. The repository ships the LifelongAgentBench data files (350/150 OS, 361/139 DB). — [MemRL v2](https://arxiv.org/html/2601.03192v2); [MemRL README](https://github.com/MemTensor/MemRL/blob/main/README.md)

**RoMeRL in detail**
- "RoMeRL is the public, evaluation-only task-slot runtime for LifelongBench and ALFWorld ... The release contains no code for training a model, learning Q values, building new memories, promoting slot roles, or saving an updated checkpoint." — [RoMeRL README](https://github.com/YOUNG-fnxm/RoMeRL)
- Two frozen checkpoints are public: OSInteraction "500 tasks and 679 readable active memories" and DBBench "500 tasks and 1,051 readable active memories", each with `q_cache.json`, `mem_cache.json`, `dict_memory.json`, `query_embeddings.json`, `task_slot_index.json` and a `manifest.json`. — [RoMeRL checkpoints README](https://github.com/YOUNG-fnxm/RoMeRL/blob/main/checkpoints/README.md)
- Retrieval mixes similarity and Q with equal weight in the shipped config (`weight_similarity: 0.5`, `weight_q: 0.5`, `use_z_score: true`); the embedding model "must match the model used to create the checkpoint's `query_embeddings.json`" (`text-embedding-3-large` in the config). — [RoMeRL README](https://github.com/YOUNG-fnxm/RoMeRL); [config](https://github.com/YOUNG-fnxm/RoMeRL/blob/main/configs/lifelongbench_task_slot.yaml)
- The paper's cross-model table: OS, GPT-5.4-mini 67.0 to 81.6 and Gemini-3.5-flash 74.0 to 81.4; DB, 93.0 to 96.8 and 96.2 to 97.6; average steps per task between 2.0 and 4.5. — [RoMeRL v3](https://arxiv.org/html/2608.02508v3)

**CHIME, EvoKernel, MemCollab**
- The CHIME paper says "Code will be released at https://github.com/ATH-MaaS/Marco-DeepResearch". The repository's news line announces CHIME, but its file tree (622 paths) has no path containing "chime"; the memory code present is UMEM. — [CHIME](https://arxiv.org/html/2609.02074v1); [repository tree](https://github.com/ATH-MaaS/Marco-DeepResearch)
- CHIME's main table is "averaged over three random instance orderings (Avg@3)". This fills the novelty note's gap on run counts for the main table; the transfer table's run count was still not found. — [CHIME](https://arxiv.org/html/2609.02074v1)
- EvoKernel's abstract points to a project page; that page holds a title and no repository link, and a GitHub search for "EvoKernel" returned only unrelated or third-party prototypes. A search for "MemCollab" returned no official repository. — [EvoKernel project page](https://evokernel.zhuo.li); [GitHub search](https://github.com/search?q=EvoKernel&type=repositories); [GitHub search](https://github.com/search?q=MemCollab&type=repositories)

**ACE**
- "Curator converts lessons into structured delta updates with helpful/harmful counters"; the playbook file is plain text with `helpful=X harmful=Y` per line, and `--mode eval_only --initial_playbook_path ...` evaluates a saved playbook. — [ACE README](https://github.com/ace-agent/ace)
- In the paper the counters are set by the model: "the Generator highlights which bullets were useful or misleading". Cost on online FiNER: Dynamic Cheatsheet USD 17.7, ACE USD 2.9. — [ACE paper](https://arxiv.org/html/2510.04618)
- A third-party implementation exists with more recent activity (Apache-2.0, pushed 24 September 2026, 2,612 stars); its README was not read. — [kayba-ai/agentic-context-engine](https://github.com/kayba-ai/agentic-context-engine)

### Inferences
- Best base 1, the released-system leg: MemRL on LifelongAgentBench DB (or OS). Reasons: the only public code that learns, stores, saves and reloads a numeric score; the data is in the repository; tasks are 500 short episodes (2 to 4.5 steps in RoMeRL's table) on a laptop with Docker; held-out memory gains are the largest MemRL reports outside ALFWorld (+10 points DB, +7 points OS). Wiping is a one-line edit of the q-cache JSON and item metadata; discounting is a multiplication. The paper's own held-out numbers warn that the score adds only about 2 to 3 points over similarity-only retrieval, so a keep-against-wipe gap in task success on 150 validation tasks will be inside the noise. This leg can confirm direction, not carry the statistics.
- Best base 2, the main ground: a thin score layer (about 300 lines) on StreamBench-style single-call streams that implements two published rules unchanged, MemRL's update (step 0.3, initial value 0, equal weight on normalised similarity and score) and ACE's helpful and harmful counters. This keeps the scored object faithful to accepted papers while making every episode one cheap call with a programmatic grade. It also gives two kinds of evidence, tallies from an environment reward (MemRL) and tallies assigned by the model itself (ACE), which the mechanism test needs.
- A third, nearly free ground: RoMeRL's two public checkpoints are third-party Q-values that the author did not train. Running them under three or four target models with scores kept, zeroed (the retriever then ranks by similarity only) and shrunk is a clean test on someone else's scores. Two cautions: the checkpoints cover all 500 tasks, so same-task memories must be filtered out by task key for a held-out reading; and the source model of the public checkpoints is not stated in the README (the paper used DeepSeek-V4-flash for LifelongAgentBench).
- Not usable as bases in the time available: CHIME (no code), EvoKernel and MemCollab (no code found), RoMeRL training (not released), ReasoningBank and Agent Workflow Memory (no numeric score; WebArena and SWE-bench are too expensive, see section 2), ExpeL (stale since 2024), Dynamic Cheatsheet (no per-item score).
- Three properties of MemRL's released scores must shape the design. First, most items sit at the initial value and were never re-tested, so any rank statistic must be restricted to items with a minimum number of visits and the build phase needs forced exploration. Second, retrieval is greedy, so stored values are selection-biased before any swap. Third, MemRL's default code sends a temperature on every call, which current Claude models reject (section 3), so the provider layer needs a small patch.
- MemRL's original backbones (GPT-4o, GPT-4o-mini, GPT-5-mini) are all scheduled to shut down between 11 December 2026 and 14 January 2027 (section 3). MemRL's tables cannot be re-run with the original models after the ICML deadline, which is itself a concrete illustration of the paper's motivation.

### Gaps
- No code was executed. "Runnable" is judged from READMEs, file trees and issue threads, not from a test run.
- ExpeL, Agent Workflow Memory and Memp READMEs were skimmed for interface and benchmarks only; their memory formats were not inspected in code.
- The source model and embedding model recorded in RoMeRL's `manifest.json` were not opened.
- Whether the CHIME authors will release code before 15 December is unknown.
- Reported token use was found only for MemRL (HLE), ACE (FiNER) and StreamBench (section 2). No figure exists for MemRL on LifelongAgentBench or ALFWorld.

## 2. Benchmarks: which public tasks suit a cheap, automatically graded, scored-memory study?

### Takeaway
The benchmarks that fit one person, an API key and one month are the single-call streams of StreamBench (BIRD or Spider text-to-SQL, DDXPlus diagnosis, ToolBench, DS-1000) and the short-episode LifelongAgentBench DB and OS tasks; all have programmatic grading, a standard sequential setting, and published memory gains of 6 to 27 points. HLE, BigCodeBench at ten epochs, ALFWorld at MemRL's scale, SWE-bench, WebArena, GAIA and τ-bench are too expensive or too noisy for a grid of models, arms and repeats.

### Cited Findings

**StreamBench (arXiv 2406.08747, version 2 of 31 October 2024; code Apache-2.0, last push 28 October 2024; venue not re-verified in this pass)**
- It "simulates an online learning environment where LLMs receive a continuous flow of feedback stream"; feedback is binary correctness; streams are shuffled with a fixed seed and the released sequence is published; robustness was checked on five shuffles. — [StreamBench paper](https://arxiv.org/html/2406.08747); [repository](https://github.com/stream-bench/stream-bench)
- Test sizes: Spider 2,147; CoSQL 1,007; BIRD 1,534; DS-1000 1,000; ToolBench 750; DDXPlus 1,764; HotpotQA 1,500. Metrics: execution accuracy, pass@1, accuracy, exact match. — [StreamBench paper](https://arxiv.org/html/2406.08747)
- Memory gains averaged over three 2024 models, zero-shot against Self-StreamICL: Spider 67.89 to 74.63; BIRD 29.60 to 35.31; DS-1000 37.70 to 41.30; ToolBench 61.38 to 71.33; DDXPlus 52.85 to 70.56; HotpotQA 48.49 to 54.80. — [StreamBench paper](https://arxiv.org/html/2406.08747)
- Gains persist on stronger models: gemini-1.5-flash on DDXPlus 58.90 to 86.34, BIRD 33.83 to 41.20, Spider 69.63 to 77.83; gpt-4o-2024-08-06 on BIRD 34.42 to 42.63 and Spider 73.54 to 80.58. — [StreamBench paper](https://arxiv.org/html/2406.08747)
- Token use for one full pass of Self-StreamICL with gpt-3.5-turbo-0125, in millions of input/output tokens: Spider 2.156/0.063; CoSQL 0.966/0.021; BIRD 2.688/0.066; DS-1000 1.765/0.073; ToolBench 5.756/0.019; DDXPlus 7.833/0.013; HotpotQA 10.46/0.013. — [StreamBench paper, Appendix E](https://arxiv.org/html/2406.08747)

**LifelongAgentBench**
- Repository has no licence file (GitHub reports none), last push 30 May 2025; DB tasks are checked "automatically (e.g., result matching, MD5 hashing of database states)"; OS tasks run in "disposable Docker containers running Ubuntu". — [repository](https://github.com/caixd-220529/LifelongAgentBench); [paper](https://arxiv.org/html/2505.11942)
- MemRL and RoMeRL both use 500 OS and 500 DB tasks with a 7:3 split; MemRL's held-out gain over no memory is +7.3 points (OS) and +10.1 points (DB) with GPT-4o-mini. — [MemRL v2](https://arxiv.org/html/2601.03192v2); [RoMeRL v3](https://arxiv.org/html/2608.02508v3)

**Benchmarks that are too expensive or too noisy**
- HLE: 2,500 questions; MemRL used 10 passes at about 32K tokens per question. — [HLE](https://arxiv.org/abs/2501.14249); [MemRL v2](https://arxiv.org/html/2601.03192v2)
- HLE gains in MemRL are memorisation of the same questions ("the gain in HLE stems from Runtime Memorization"), as quoted in the novelty note. — [MemRL v2](https://arxiv.org/html/2601.03192v2)
- BigCodeBench: 1,140 tasks; the official repository is archived (last push 3 January 2026); MemRL's maintainers report multi-day serial runs and about USD 1,000 with GPT-4o; an independent reproduction found a held-out gain under 1 point. — [BigCodeBench](https://arxiv.org/abs/2406.15877); [repository](https://github.com/bigcode-project/bigcodebench); [MemRL issue 10](https://github.com/MemTensor/MemRL/issues/10); [MemRL issue 12](https://github.com/MemTensor/MemRL/issues/12)
- ALFWorld: MIT, last push 8 February 2026; MemRL's setting is 3,553 training games per epoch; a user notes "the success rate is already very high on alfworld with the backbone model of GPT-5-mini" and that train and test tasks are very similar. — [ALFWorld repository](https://github.com/alfworld/alfworld); [MemRL issue 11](https://github.com/MemTensor/MemRL/issues/11)
- Per-run costs on the Holistic Agent Leaderboard (one run, one model): SWE-bench Verified Mini USD 463.90 to 1,351.35 for the top three entries; GAIA USD 178.20 to 562.24; Online Mind2Web USD 171.07 to 1,609.92; τ-bench Airline (50 tasks) from USD 0.31 (Gemini 2.0 Flash, 28%) to USD 180.49 (Claude Opus 4.1), with USD 5 to 43 typical. Every τ-bench entry has a run count of 1, and the page warns that costs "may be overstated, by exactly 2×" for some models. — [HAL](https://hal.cs.princeton.edu/); [HAL τ-bench Airline](https://hal.cs.princeton.edu/taubench_airline)
- τ²-bench: MIT, pushed 10 November 2026, uses LiteLLM ("any supported provider works"); 50 frozen tasks per text domain. τ-bench's authors report low run-to-run consistency ("pass^8 <25% in retail"), and the red-team note cites a 9-point swing from the choice of user simulator. — [τ²-bench README](https://github.com/sierra-research/tau2-bench); [τ-bench](https://arxiv.org/abs/2406.12045)
- WebArena needs self-hosted Docker web sites; ReasoningBank's WebArena code needs BrowserGym plus an LLM judge "for obtaining correctness signal for trajectories". — [ReasoningBank README](https://github.com/google-research/reasoning-bank)
- OpenRCA: MIT, pushed 4 November 2026, scripted grading against `query.csv`, but it asks for "at least 80GB of storage space and 32GB of memory". RCAEval has "735 failure cases collected from three microservice systems". Neither has a standard stream setting or a published memory gain. — [OpenRCA README](https://github.com/microsoft/OpenRCA); [RCAEval](https://arxiv.org/abs/2412.17015)
- LongMemEval ("500 meticulously curated questions") and LoCoMo (conversations of "300 turns and 9K tokens on avg.") test recall of facts from chat history; items there carry no success tally. — [LongMemEval](https://arxiv.org/abs/2410.10813); [LoCoMo](https://arxiv.org/abs/2402.17753)
- AppWorld has 750 tasks; RoMeRL and ACE use it; RoMeRL's split is "105 train / 60 dev". — [AppWorld](https://arxiv.org/abs/2407.18901); [RoMeRL v3](https://arxiv.org/html/2608.02508v3)

### Inferences

Suitability table (my judgement from the findings; per-run costs are **estimates** with arithmetic).

| Benchmark | Tasks | Stream setting standard? | Auto grade | Known memory gain | Tokens per episode | One pass, one model, at USD 0.10/0.50 and at USD 1/5 per million | Verdict |
|---|---|---|---|---|---|---|---|
| StreamBench DDXPlus | 1,764 | Yes | Yes | +18 to +27 points | about 4,440 in, 7 out (2024 measurement); assume 4,500 in, 300 out today | 1,764 × (4,500 × 0.10 + 300 × 0.50)/10^6 = USD 1.06; at 1/5: USD 10.6 | Use (largest gain) |
| StreamBench BIRD | 1,534 | Yes | Yes (SQL execution) | +6 to +8 points | about 1,750 in, 43 out; assume 2,500 in, 500 out | 1,534 × (2,500 × 0.10 + 500 × 0.50)/10^6 = USD 0.77; at 1/5: USD 7.7 | Use (code-like, strict grade) |
| StreamBench Spider, ToolBench, DS-1000 | 2,147; 750; 1,000 | Yes | Yes | +7; +10; +4 points | 1,000 to 7,700 in | under USD 1 to about USD 5 | Reserve as third task |
| LifelongAgentBench DB / OS (MemRL code) | 500 each | Yes (MemRL, RoMeRL) | Yes | +10 / +7 points | assume 3 steps, 13,000 in and 1,100 out per episode including the write step | 500 × (13,000 × 0.10 + 1,100 × 0.50)/10^6 = USD 0.93; at 1/5: USD 9.3 | Use as released-code leg |
| BigCodeBench (MemRL code) | 1,140 | MemRL only | Yes | under 1 to 2.3 points held-out | not measured | maintainers: about USD 1,000 for the full protocol | Do not use |
| HLE (MemRL code) | 2,500 | MemRL only | LLM judge (GPT-4o in MemRL) | memorisation | 32K | 10 passes = 800M tokens; at USD 2/10 with 85% input about USD 2,560 per model | Do not use |
| ALFWorld (MemRL scale) | 3,553 train | MemRL, RoMeRL | Yes | +14 points (ceiling near 98%) | multi-step, not measured | not estimated | Do not use at full scale |
| τ-bench / τ²-bench | 50 per domain | No | Yes, with simulated user | CHIME: +0.8 to +6 points | multi-turn | USD 5 to 43 per run on HAL | Too small and noisy |
| SWE-bench Verified Mini, GAIA, WebArena | not read; 466; not read | No | Yes / partly judge | ReasoningBank reports gains | long | USD 180 to 1,350 per run | Out of budget |
| OpenRCA, RCAEval | not stated; 735 | No | Yes | none published | long telemetry | not estimated | Case-study candidates only |
| LoCoMo, LongMemEval | 500 questions (LongMemEval) | Partly | Judge or match | not about scored items | long | not estimated | Wrong object |

- The decisive constraint is statistical, not monetary. On MemRL's own held-out tables the score adds about 2 to 3 points of task success over similarity-only retrieval. Detecting a 3-point paired difference at 80% power needs roughly 1,300 paired tasks when 15% of pairs disagree and about 2,200 when 25% disagree (my arithmetic: n ≈ 7.85 × discordant share / difference²). No benchmark above has that many held-out tasks per run except by pooling across pairs and seeds. So task success cannot be the primary endpoint; an item-level endpoint is required (section 4).
- Single-call tasks make the item-level endpoint affordable: usefulness of one item for one task under one model is one call. On a multi-step benchmark the same cell costs a whole episode.
- StreamBench's stream uses the test set itself as the stream. For this study the stream must be cut into three disjoint parts (score building, fresh checks and probes, final test) so that no task's outcome is used both to earn a score and to judge it.
- Contamination risk: Spider, BIRD and HotpotQA are old and public, so newer models may have seen them. This threatens absolute accuracy, not the comparison between arms under one model, but it can shrink the memory gain. The pilot must confirm a gain of at least 5 points on current models before a benchmark is kept.

### Gaps
- Task counts for SWE-bench Lite and Verified, WebArena and OpenRCA were not re-read from primary sources in this pass; the table gives only what was read.
- StreamBench's token figures are from 2024 models without reasoning tokens. Current models may spend several times more output tokens; the pilot must measure this.
- No published memory gain on StreamBench exists for any 2026 model. Whether the gain survives is the first thing the pilot tests.
- The licence of each underlying dataset (DDXPlus, BIRD, Spider, ToolBench) was not checked; the StreamBench code is Apache-2.0.
- LifelongAgentBench has no licence file, which may matter for redistributing derived data.

## 3. Models: four to six models, eight to twelve swap pairs, prices, sampling control and retirement dates

### Takeaway
A six-model slate with three same-maker upgrade pairs is available at low list prices: Claude Haiku 4.5 to Haiku 5.5, GPT-5.6-luna to GPT-6-luna, and the open-weight chain Qwen3.5-27B to Qwen3.8-27B (Apache-2.0, hosted with temperature and seed). The open-weight pair is the reproducibility anchor, because temperature can no longer be set on current Claude models, seeds are best-effort or absent on closed APIs, and several widely used closed models shut down inside the study and review window (GPT-5 family on 11 December 2026, GPT-4o family on 14 January 2027, Claude Sonnet 4.5 on 30 November 2026).

### Cited Findings

**List prices, USD per million tokens, input / output (official pages, read 15 November 2026)**
- Anthropic: Haiku 5.5 0.10 / 0.50 for prompts up to 100,000 tokens; Haiku 4.5 1 / 5; Sonnet 5.5 2 / 10; Sonnet 5 2 / 10; Sonnet 4.6 3 / 15; Opus 5.5 4 / 20. "The Batch API allows asynchronous processing of large volumes of requests with a 50 percent discount on both input and output tokens." Cache reads cost 0.1 times base input (0.05 times on Sonnet 5.5 and Opus 5.5). "Claude 4.7 and later models ... use a newer tokenizer ... approximately 30% more tokens for the same text." — [Anthropic pricing](https://platform.claude.com/docs/en/about-claude/pricing)
- OpenAI: gpt-6-luna 0.10 / 0.50; gpt-6.1-terra 1 / 5; gpt-6.1-sol 2 / 10; gpt-5.6-luna 0.20 / 1.20; gpt-5.6-terra 2 / 12; gpt-5.4-mini 0.75 / 4.50; gpt-5.4-nano 0.20 / 1.25; gpt-4o-mini 0.15 / 0.60. Batch prices listed are half of standard for every model checked (for example gpt-6-luna 0.05 / 0.25); the page states no percentage. — [OpenAI pricing](https://developers.openai.com/api/docs/pricing)
- Google: gemini-2.5-flash-lite 0.10 / 0.40; gemini-3.1-flash-lite 0.25 / 1.50; gemini-3.5-flash-lite 0.30 / 2.50; gemini-3.6-flash and gemini-3.8-flash 0.75 / 3.75 until 31 December 2026, then 1.50 / 7.50; gemini-4-carbon 2 / 10 until 30 November 2026, then 4 / 20. "Batch API (50% cost reduction)". — [Google AI Studio pricing](https://aistudio.google.com/docs/pricing)
- Together (serverless): Qwen3.8 Flash 0.15 / 0.47; Qwen3.7-Plus 0.32 / 1.28; gpt-oss-120B 0.15 / 0.60; GLM-5.3-Flash 0.15 / 0.50; DeepSeek V4.1 Flash 0.30 / 1.20; Qwen3.5 9B 0.17 / 0.25. No Llama, Mistral or Gemma chat model is on the serverless list. — [Together pricing](https://www.together.ai/pricing)
- Fireworks: OpenAI GPT OSS 120B 0.15 / 0.60; GLM 5.3 Flash 0.15 / 0.50; DeepSeek V4.1 Flash 0.30 / 1.20; Qwen 3.8 Max 2 / 6. Batch is "50% off input and output for jobs that don't need an immediate answer." — [Fireworks pricing](https://fireworks.ai/pricing)
- OpenRouter model list (API, lowest listed route): qwen/qwen3.5-27b 0.26 / 2.60; qwen/qwen3.6-27b 0.32 / 3.20; qwen/qwen3.8-27b 0.15 / 1.875; qwen/qwen3.5-9b 0.029 / 0.042; deepseek/deepseek-v4-flash 0.09 / 0.18; deepseek/deepseek-v4.1-flash 0.051 / 0.203; dated snapshots deepseek-v4-flash-0731 and deepseek-v4.1-flash-1017; google/gemma-4-31b-it 0.20 / 0.40. Each of these lists both `temperature` and `seed` among supported parameters. — [OpenRouter models API](https://openrouter.ai/api/v1/models)

**Open weights confirmed on Hugging Face**
- Qwen/Qwen3.5-27B (created 24 February 2026), Qwen/Qwen3.6-27B (21 April 2026) and Qwen/Qwen3.8-27B (5 August 2026) exist, are not gated and carry `license:apache-2.0`. deepseek-ai/DeepSeek-V4-Flash (22 April 2026) and DeepSeek-V4.1-Flash (10 September 2026) are MIT. openai/gpt-oss-120b is Apache-2.0. — [Qwen3.5-27B](https://huggingface.co/Qwen/Qwen3.5-27B); [Qwen3.6-27B](https://huggingface.co/Qwen/Qwen3.6-27B); [Qwen3.8-27B](https://huggingface.co/Qwen/Qwen3.8-27B); [DeepSeek-V4-Flash](https://huggingface.co/deepseek-ai/DeepSeek-V4-Flash); [DeepSeek-V4.1-Flash](https://huggingface.co/deepseek-ai/DeepSeek-V4.1-Flash); [gpt-oss-120b](https://huggingface.co/openai/gpt-oss-120b)

**Sampling control**
- Anthropic: `temperature`, `top_p`, `top_k` are "Removed in API version `2026-10-21`" and return "a 400 error. Earlier API versions return it when set to a non-default value on Claude 4.7 and later models". — [Anthropic model deprecations](https://platform.claude.com/docs/en/about-claude/model-deprecations)
- OpenAI: only second-hand sources were found. A community thread says the `seed` field in Chat Completions is marked deprecated and the Responses API has no seed; a third-party post dated 6 November 2026 says the GPT-6 family accepts temperature only with reasoning off. Treat both as unverified. — [OpenAI community thread](https://community.openai.com/t/is-the-seed-parameter-getting-deprecated/1363139); [third-party post](https://www.datastudios.org/post/unsupported-parameter-temperature-openai-claude-gemini-api)
- Even "deterministic" settings vary: accuracy differed by up to 15% between identical runs in one study, and 11 of 31 hosted endpoints served different distributions from the reference weights in another (ICLR 2025). — [Atil et al.](https://arxiv.org/abs/2408.04667); [Model Equality Testing](https://proceedings.iclr.cc/paper_files/paper/2025/hash/d73234a13815fc1f9779dd17d89be9b4-Abstract-Conference.html)

**Retirement dates that affect reproducibility**
- Anthropic: `claude-sonnet-4-5-20250929` retires 30 November 2026; `claude-haiku-4-5-20251001` is Active with "Not sooner than October 15, 2026" (already past, so a 60-day notice could come at any time); `claude-opus-4-5-20251101` "Not sooner than November 24, 2026"; `claude-sonnet-4-6` not sooner than 17 February 2027; `claude-haiku-5-5` not sooner than 7 October 2027; `claude-sonnet-5-5` not sooner than 28 September 2027. Notice is "at least 60 days". — [Anthropic model deprecations](https://platform.claude.com/docs/en/about-claude/model-deprecations)
- OpenAI: gpt-5, gpt-5-mini, gpt-5-nano and o3 shut down 11 December 2026; gpt-4o, gpt-4o-mini, gpt-4.1 and gpt-4.1-mini shut down 14 January 2027 (replacement gpt-6-luna); gpt-5.1 and gpt-5.4-nano shut down 1 April 2027. No shutdown is listed for gpt-5.4-mini, gpt-5.6-luna or any gpt-6 model. — [OpenAI deprecations](https://developers.openai.com/api/docs/deprecations)
- Google: gemini-2.5-pro and gemini-2.5-flash route to other models from 1 December 2026; gemini-2.5-flash-lite "is not deprecated"; gemini-3.1-flash-lite shuts down 7 May 2027; gemini-3.5-flash and gemini-3.7-flash endpoints already route silently to 3.6 and 3.8. — [Google deprecations](https://aistudio.google.com/docs/deprecations)

**Rate and spend limits (Anthropic, as the example read)**
- Start tier: Haiku 5.5 at 4,000 requests, 2,000,000 input tokens and 400,000 output tokens per minute; Haiku 4.5 at 1,000 requests per minute with the same token limits; monthly spend cap USD 500 (Build USD 1,000). Batches: up to 100,000 requests per batch and 200,000 in the queue on the Start tier. — [Anthropic rate limits](https://platform.claude.com/docs/en/api/rate-limits)

### Inferences

**Proposed slate (six models, twelve ordered pairs)**

| Role | Old model | New model | Why |
|---|---|---|---|
| Same-maker upgrade, closed | claude-haiku-4-5 (1 / 5) | claude-haiku-5-5 (0.10 / 0.50) | The realistic forced migration; also crosses Anthropic's tokenizer change |
| Same-maker upgrade, closed | gpt-5.6-luna (0.20 / 1.20) | gpt-6-luna (0.10 / 0.50) | Neither has an announced shutdown |
| Same-maker upgrade, open weights | Qwen3.5-27B (0.26 / 2.60) | Qwen3.8-27B (0.15 / 1.875) | Apache-2.0 weights; temperature and seed supported; anyone can re-run it after the APIs change |

- Twelve pairs: the three upgrades, their three reverses (a downgrade control that separates "different" from "better"), and the six ordered cross-maker pairs among the three new models.
- Optional seventh and eighth models if money and time allow: Qwen3.6-27B (turns the open chain into two consecutive upgrades and tests whether the effect grows with version distance) or gemini-2.5-flash-lite to gemini-3.5-flash-lite (a third closed maker, 0.10 / 0.40 to 0.30 / 2.50).
- Models to avoid: anything that shuts down or re-routes before 22 January 2027 (gpt-4o, gpt-4o-mini, gpt-4.1, gpt-5, gpt-5-mini, o3, gemini-2.5-flash, gemini-2.5-pro, claude-sonnet-4-5), and "latest" aliases. Haiku 4.5 is past its "not sooner than" date; all Haiku 4.5 runs should be finished in November and every raw answer saved.
- Because sampling cannot be pinned on current Claude models and is uncertain on GPT-6, the design should not rely on determinism anywhere. It should treat every outcome as a random draw, repeat each cell, and measure the same-model repeat disagreement directly (section 4). On the open-weight pair, fix temperature 0 and a seed and pin one hosting provider, then still measure repeat disagreement, since hosted copies of the same weights can differ.
- Price asymmetry matters: on two of the three upgrade pairs the old model costs more than the new one (Haiku 4.5 is ten times Haiku 5.5). The budget in section 6 is dominated by the old models.
- Google's price rises on 1 December 2026 and 1 January 2027 do not touch the flash-lite models named above.

### Gaps
- Groq's price page returned only a marketing page; no Groq prices were read.
- OpenAI's official statement on `seed` and `temperature` for GPT-6 models was not found; the two sources are second-hand.
- OpenRouter prices are the lowest route per model and can change daily; which provider serves each Qwen 27B model, and at what quantisation, was not checked.
- OpenAI and Google rate limits were not read. Batch completion-time guarantees were not read on any provider.
- Whether the author's "company service" endpoint offers these models is unknown (same gap as in the red-team note).

## 4. Design: arms, metrics, noise floor, seeds, statistics, and measuring usefulness without circularity

### Takeaway
Make the primary endpoint an item-level one: on held-out probe tasks, force each candidate memory item into the prompt one at a time under the target model and record the programmatic grade, giving a full outcome table from which every arm (keep, wipe, fixed discount, calibrated discount) and every recovery curve can be scored offline with no further calls. Usefulness measured this way is not circular because the probe tasks never contributed to any stored score, the item shown is chosen by the experimenter and not by the score under test, and the grade comes from a program, not a model.

### Cited Findings
- MemRL defines the stored quantity as the expected reward of a task-memory pair under one frozen model, and its stability analysis assumes "Frozen Inference Policy". — [MemRL v2](https://arxiv.org/html/2601.03192v2)
- Stored scores are selection-biased before any swap: MemRL's retrieval is greedy with no exploration, and most items are never revisited. — [MemRL issue 11](https://github.com/MemTensor/MemRL/issues/11); [MemRL issue 7](https://github.com/MemTensor/MemRL/issues/7)
- RoMeRL names the resulting failure the "memory-reward trap": "a coincidental success may assign reward to the wrong retrieved context, which then increases the chance of retrieving that context again." — [RoMeRL README](https://github.com/YOUNG-fnxm/RoMeRL)
- CHIME checks that values track usefulness only under the model that learned them, by splitting retrieved memories into low, mid and high value groups and reporting task accuracy per group. — [CHIME](https://arxiv.org/html/2609.02074v1)
- The closest measurement paper on memory utility uses "paired evaluation with identical context filler", a writer that "never observes the future task", explicit noise floors ("outcome variation across seeds with everything else fixed, measured per benchmark with a bootstrap interval"), re-scoring of stored outputs, and a permutation test with 20,000 shuffles; it finds the headline contrast "remains positive ... under a second reader, although individual memory–task labels change." — [arXiv 2611.03930](https://arxiv.org/html/2611.03930v1)
- Goyal and Ray, the nearest portability study, used a signed analysis plan, one-sided tests with a 5-point action threshold, Holm correction over four tests, a follow-up bootstrap with 10,000 resamples, live repeats to measure read noise ("Repeated live reads vary by only 0.0016"), and reported the bootstrap as post hoc because it was run after the first tests. Their full third experiment took "1,440 evaluations in 98.2 GPU-hours, costing about USD 221". — [Goyal and Ray](https://arxiv.org/html/2609.05339v1)
- StreamBench reports robustness over five shuffled sequences with standard errors. CHIME averages over three orderings. MemRL reports a single seed (novelty note). — [StreamBench](https://arxiv.org/html/2406.08747); [CHIME](https://arxiv.org/html/2609.02074v1)
- Statistics guidance from accepted or widely used evaluation papers: report standard errors and use paired differences and clustered errors when questions are shared (Miller, 2024); use interval estimates and stratified bootstrap over runs instead of point estimates from few runs (Agarwal et al., NeurIPS 2021 outstanding paper); avoid normal-approximation intervals with fewer than a few hundred items and prefer Bayesian or exact intervals (Bowyer et al., ICML 2025 spotlight position paper); check power before running, since many NLP comparisons are underpowered (Card et al., EMNLP 2020). — [Miller](https://arxiv.org/abs/2411.00640); [Agarwal et al.](https://arxiv.org/abs/2108.13264); [Bowyer et al.](https://arxiv.org/abs/2503.01747); [Card et al.](https://arxiv.org/abs/2010.06595)
- Item-level change needs repeats: in a pre-registered study a single greedy run mislabelled a quarter of "changed" items, and between-version churn was 21 to 28% of items with a 1.6 to 2.8 point net gain. — [Cacioli](https://arxiv.org/abs/2604.27405)
- Interventional ground truth is the accepted standard for valuing a context item or a training example: remove or include it and re-measure (Data Shapley, datamodels, ContextCite, influences for in-context examples). — [Data Shapley](https://arxiv.org/abs/1904.02868); [Datamodels](https://arxiv.org/abs/2202.00622); [ContextCite](https://arxiv.org/abs/2409.00729); [Nguyen and Wong](https://arxiv.org/abs/2302.11042)
- The same-model noise that the design must beat: up to 15% accuracy variation across identical runs. — [Atil et al.](https://arxiv.org/abs/2408.04667)
- A separate line shows that non-inferiority has to be tested as such, not inferred from a failed difference test. — [arXiv 2609.13714](https://arxiv.org/abs/2609.13714)

### Inferences

**Data split (per benchmark, per stream order).** Shuffle with a recorded seed, then cut into three disjoint parts: a build stream (about 600 tasks) where the source model earns scores; a probe pool (about 200 tasks) used for the fresh checks and for item-level usefulness; a final test set (about 300 tasks) used only for end-to-end success. No task appears in two parts, and a memory item is never offered to the task that produced it.

**Build phase (per model, three stream orders).** The model solves the build stream twice. After each graded attempt an item is written (the task, the model's answer, a short model-written lesson, and the grade). Two score types are kept on the same items: a reward tally (successes and failures when the item was the one shown, MemRL's rule and also raw counts) and a model-assigned tally (the model marks each shown item helpful or harmful, ACE's rule). During building, the shown item is chosen at random among the top similarity candidates with probability 0.3 so that most items get several visits; the choice probability is logged.

**Arms on the day of the swap (target model T, source model S).**

| Arm | Content | Scores at swap |
|---|---|---|
| A0 No memory | none | none |
| A1 Own | T's own bank, built from nothing on the same build stream | T's own |
| A2 Keep | S's bank | S's scores unchanged |
| A3 Wipe | S's bank | reset to the initial value, so ranking is by similarity only |
| A4 Fixed discount | S's bank | tallies multiplied by 0.5 (and a sweep over 0.1 to 0.9 offline) |
| A5 Calibrated discount | S's bank | weight chosen from k fresh checks, k in {8, 16, 32, 64} |
| A6 Oracle re-score (ceiling) | S's bank | scores re-earned by T on the probe pool |

A2 to A6 hold content fixed, which is the separation MemRL, EvoKernel, RoMeRL and CHIME did not make. A1 against A2 to A6 measures content transfer and reproduces CHIME's "Self" column. A3 against A0 measures what content alone gives.

**The probe table.** For every probe task and each of its top four similarity candidates from the bank, run T with exactly that one item shown, twice, plus T with no item. This yields outcomes y(task, item, T, repeat). Because the table holds the outcome of every candidate, the choice made by any arm, any discount weight and any k can be scored by look-up. The same table is filled for S on its own bank (the home reference).

**Metrics.**
1. Rank validity (primary): within each probe task, the probability that the candidate with the higher carried score has the better outcome, over candidate pairs whose outcomes differ (a within-task concordance, 0.5 = chance). Report it at home (S's scores against S's outcomes), after the swap (S's scores against T's outcomes), and for the ceiling (T's re-earned scores against T's outcomes on a held-out half). The headline number is retained validity = (swap − 0.5) / (home − 0.5). Also report Spearman correlation between carried score and per-item success rate under T for items with at least five visits and at least three probe appearances.
2. Top-1 choice quality: success rate of the item each arm would show, and regret against the best candidate, on the probe pool.
3. Task success on the final test set, live, for A0 to A5 (secondary; expected to be underpowered per pair, reported pooled).
4. Fresh episodes to recover: replay the probe pool as a stream under T, start from each arm's scores, update with T's outcomes, and count episodes until top-1 quality reaches 95% of the A6 level. The replay draws outcomes from the probe table, so thousands of stream orders cost nothing. A small live run (four pairs) checks that replay agrees with reality.
5. Cost per arm in calls, tokens and dollars.

**Noise floor.** Three controls set it: (a) the self-swap S to S with fresh repeats, which gives the drop that appears with no model change; (b) repeat disagreement on identical (task, item) cells for each model, corrected for chance; (c) a same-model, second-bank control (scores from stream order 1 used with the bank from order 2 is impossible, so instead compare two independently built banks of S on the same probe pool) to show seed-to-seed spread. A cross-model drop is claimed only if it exceeds (a) with a confidence interval that excludes zero.

**Seeds and sizes.** Three stream orders per model and benchmark, two repeats per probe cell, 200 probe tasks, four candidates: 4,800 probe calls per (S, T) cell. Pooled over 12 pairs this is 7,200 task-bank units for paired arm contrasts; my arithmetic gives about 630 paired units to detect a 5-point difference at 20% discordance, so each pair is individually powered for 5 points and the pool for about 2 points. A Spearman correlation on 300 items has a 95% half-width of about 0.11.

**Statistics.**
- Pre-register, in a dated file committed before the first paid run: the primary endpoint (retained validity), four primary contrasts (keep against wipe, keep against own-score ceiling, fixed discount against keep, calibrated discount at k = 16 against the better of keep and wipe), the 5-point and 3-point margins, and the go or no-go rule.
- Paired analysis on the same probe tasks: exact McNemar or a paired permutation test for binary outcomes; a two-way cluster bootstrap (tasks and stream orders, 10,000 resamples) for intervals on concordance and regret; a mixed-effects logistic model with random effects for task and pair for the pooled estimate.
- Multiple comparisons: Holm across the four primary contrasts; Benjamini-Hochberg across the twelve per-pair tests, reported as exploratory.
- For a "no drop" claim, an equivalence test against the pre-set margin (two one-sided tests at ±3 points), so that a null is a positive statement and not an absence of evidence.
- Report every pair in a table, not only the pooled mean, since Goyal and Ray found opposite signs by direction.

**Why the usefulness measure is not circular.**
1. The tasks that judge a score are disjoint from the tasks that earned it.
2. The item shown in a probe is chosen by the experimenter (every top-four candidate is run), not by the score being judged, so no importance weighting or off-policy correction is needed for the ground truth.
3. The grade is a program (SQL execution, exact label match, database state hash), so the judge shares no bias with either model. HLE with an LLM judge would fail this test.
4. The ceiling is measured, not assumed: T's own re-earned scores are split in half, one half to score and one to judge.
5. The home reference is measured too. If the source's scores barely beat chance at home, the paper says so and the swap question becomes moot for that system, which is itself a reportable finding given the ICLR 2027 submission claiming top-k retrieval leaves values undetermined.

**What the design will not show.** It does not test human verdicts. It tests one item shown at a time, while MemRL shows three to five; interactions between items are ignored in the probe table and only appear in the live end-to-end runs. The replay for recovery ignores new items the target would write.

### Gaps
- No accepted paper was found that prescribes a number of seeds for agent-memory studies; "three orders, two repeats" follows CHIME and StreamBench practice and the budget, not a rule.
- The within-task concordance statistic is my choice; no neighbour uses exactly it. CHIME's value-bucket plot is the nearest published form and should be reproduced alongside for comparability.
- Whether four candidates per task give enough discordant pairs depends on how often outcomes differ across items for the same task; if items rarely change the outcome, the statistic has few usable pairs. Only the pilot can tell.
- The equivalence-test references (two one-sided tests) were not looked up in this pass.

## 5. Mechanism test: when do carried scores fail, and what makes the discount principled?

### Takeaway
The simplest testable account is that a carried score keeps its ranking value in proportion to how often the two models respond the same way to the same task-and-item cell, after removing agreement expected by chance and the compression caused by a stronger target's higher no-memory success. The calibrated discount is a power prior whose weight is chosen from the fresh checks by marginal likelihood; three citations make it principled: Ibrahim and Chen (2000) for the power prior, Gravestock and Held (2017) for choosing its weight from the data by empirical Bayes, and Schmidli et al. (2014) for the robust mixture alternative, with Zhang et al. (ICML 2019) as the machine-learning counterpart.

### Cited Findings
- Power prior: the historical likelihood is raised to a power a0 "where 0 ≤ a0 ≤ 1" (Statistical Science, 2000), as verified in the red-team note. — [Ibrahim and Chen](https://projecteuclid.org/journals/statistical-science/volume-15/issue-1/Power-prior-distributions-for-regression-models/10.1214/ss/1009212673.full)
- Gravestock and Held, "Adaptive power priors with empirical Bayes for clinical trials", Pharmaceutical Statistics 2017, DOI 10.1002/pst.1814: for binomial data, the prior weight is estimated by marginal likelihood; a 2019 follow-up in Biometrical Journal extends it to several historical studies. (Search summary; the paper itself was not opened.) — [record for DOI 10.1002/pst.1814](https://zendy.io/title/10.1002/pst.1814); [arXiv 1708.08239](https://arxiv.org/abs/1708.08239)
- Schmidli et al., Biometrics 2014: mixtures in which "one of the mixture components is usually vague", so the prior is heavy-tailed "and therefore robust" to conflict between historical and new data. (Search summary.) — [Schmidli et al.](https://typeset.io/pdf/robust-meta-analytic-predictive-priors-in-clinical-trials-58owrrzxq8.pdf)
- Warm-start bandits: ARRoW-CB chooses the relative weight of old supervised examples and new bandit feedback when the two distributions may differ (ICML 2019). — [Zhang et al.](https://arxiv.org/abs/1901.00301)
- Discounting and sliding windows for bandits whose rewards change, and the hazard of naive reuse of history ("spurious data and imbalanced data coverage"), are established. — [Garivier and Moulines](https://arxiv.org/abs/0805.3415); [Artificial Replay](https://arxiv.org/abs/2210.00025)
- Off-policy evaluation gives the vocabulary for selection bias in logged outcomes and the doubly robust estimator (ICML 2011). — [Dudík, Langford and Li](https://arxiv.org/abs/1103.4601)
- Using a few trusted labels to correct many cheap predictions with valid intervals is prediction-powered inference; PPI++ adds a data-chosen weight on the predictions. — [Angelopoulos et al.](https://arxiv.org/abs/2301.09633); [PPI++](https://arxiv.org/abs/2311.01453)
- Item-level responses differ across model versions even when averages barely move (21 to 28% of items), and different models' errors are correlated, so raw agreement must be chance-corrected (red-team note). — [Cacioli](https://arxiv.org/abs/2604.27405); [Kim et al., ICML 2025](https://proceedings.mlr.press/v267/kim25e.html)
- ACE's counters are assigned by the model ("the Generator highlights which bullets were useful or misleading"), whereas MemRL's values come from environment reward. — [ACE paper](https://arxiv.org/html/2510.04618); [MemRL v2](https://arxiv.org/html/2601.03192v2)
- "From Raw Experience to Skill Consumption" (NeurIPS 2026) reports that a model "can be a strong extractor yet a weak consumer, or vice versa, with skill utility independent of model scale or baseline task strength" (novelty note). — [arXiv 2605.23899](https://arxiv.org/abs/2605.23899)
- CHIME's one weak cell: transferred memory added 0.78 points where the target's own memory added 6.24 (novelty note). — [CHIME](https://arxiv.org/html/2609.02074v1)

### Inferences

**Framing.** A stored tally is logged evidence about E[reward | task, item] under the source model. After the swap the inputs (tasks, items) are the same but the conditional outcome has changed. That is concept shift, not covariate shift: no re-weighting of old inputs can repair it, and only fresh outcomes under the target carry information about the change. This is why the choices reduce to keep (assume no change), wipe (assume no relation), or borrow with a weight, which is the historical-data problem the power prior was built for.

**The account, as three testable hypotheses.**
- H1, response agreement. For each ordered pair compute chance-corrected agreement between S and T on the probe cells where both were run with the same item (the cross-probe gives T on S's items; a small extra probe runs S on the same cells). Prediction: retained validity rises with agreement across the twelve pairs and is highest on same-maker upgrades. Test: rank correlation across pairs with a bootstrap interval, and a mixed model at the cell level (does S's outcome on a cell predict T's outcome beyond the task's base rate?).
- H2, capability compression. When T is stronger, its no-memory success is higher and fewer tasks can be changed by any item, so score differences matter less whatever their validity. Prediction: the top-1 regret of every arm, including wipe, shrinks with T's no-memory success, and the keep-against-wipe gap is largest for downgrades and weak targets. Test: regress the keep-minus-wipe gap on T's no-memory success and on the S-minus-T capability gap.
- H3, who assigns the credit. Model-assigned tallies (ACE-style) depend on the source model's own judgement of helpfulness, so they should lose more validity than reward tallies (MemRL-style) on the same items. Test: paired comparison of retained validity between the two score types within each pair.
- A fourth, optional check on filing: let each model choose which of the four candidates it wants to use; the overlap between S's and T's choices is the "filing agreement" of the original pitch and can be related to the drop in the same way.

**The calibrated discount, stated exactly.** For reward tallies, item i has s_i successes and f_i failures under S. The carried belief is Beta(1 + λ s_i, 1 + λ f_i). λ = 1 is keep, λ = 0 is wipe, λ = 0.5 is the fixed discount. For the calibrated rule, spend k fresh checks under T on items chosen by stratifying on carried score, and set λ to the value on a grid that maximises the product of beta-binomial marginal likelihoods of the fresh outcomes (Gravestock and Held's empirical Bayes rule). The robust alternative is a two-part mixture, weight w on Beta(1 + s_i, 1 + f_i) and 1 − w on Beta(1, 1), with w updated by the fresh data (Schmidli et al.). For MemRL's running-average value the analogue is shrinkage toward the initial value: Q' = λ Q + (1 − λ) Q_init. One global λ per swap is the simplest form; a per-score-type λ is the first refinement.

**What the theory predicts about k.** The marginal likelihood of λ is flat when the fresh checks are few or fall on items with small tallies, so the calibrated rule should behave like the fixed discount at k = 8 and separate from it by k = 32 to 64 only when the true agreement is far from 0.5. If keep already retains most validity, the calibrated rule will pick λ near 1 and tie with keep; the paper should say in advance that this is the expected behaviour and not a failure of the rule.

**Honest limit on novelty.** As the red-team note already concedes, the rule is known statistics. The contribution is the measurement and the tested recipe. The mechanism test is what turns a table of twelve pairs into a finding, and it is also what ICML's wording on negative results asks for ("explains why the negative result matters").

### Gaps
- Hobbs et al. (Biometrics 2011, commensurate priors) could not be found as a direct record in the one search made; it is not relied on above.
- Gravestock and Held and Schmidli et al. were confirmed only through search summaries and index pages; the papers should be opened before they are cited.
- With twelve pairs, a correlation between agreement and retained validity has wide intervals (a correlation of 0.6 on 12 points has a 95% interval of roughly 0.04 to 0.87 by Fisher's transform). The cell-level mixed model is the stronger test; the pair-level plot is illustrative.
- No prior work was found that applies a power prior to agent-memory tallies; absence was checked only through the earlier notes' searches.
- H2 can masquerade as H1 if stronger models also agree more; the design separates them only partly, through the downgrade pairs.

## 6. Budget and calendar: cost, wall-clock time, week-by-week plan, minimum result at each checkpoint, go or no-go rule

### Takeaway
The recommended design costs roughly USD 700 at list price (low about USD 100, high about USD 3,000), and the API time is about two days of wall clock at modest concurrency; the binding resource is one person's engineering and analysis time, not money or rate limits. A sound two-benchmark, six-model, twelve-pair study with a small released-code leg can be finished by 15 December 2026 only if the pilot passes its gate by 22 November and nothing larger (HLE, BigCodeBench, ALFWorld at scale, human verdicts) is attempted.

### Cited Findings
- Token inputs used below: StreamBench BIRD about 1,750 input and 43 output tokens per item and DDXPlus about 4,440 and 7, measured on gpt-3.5-turbo in 2024. — [StreamBench paper, Appendix E](https://arxiv.org/html/2406.08747)
- LifelongAgentBench episodes average 2.0 to 4.5 steps in RoMeRL's table. — [RoMeRL v3](https://arxiv.org/html/2608.02508v3)
- Prices and batch discounts as in section 3. — [Anthropic pricing](https://platform.claude.com/docs/en/about-claude/pricing); [OpenAI pricing](https://developers.openai.com/api/docs/pricing); [OpenRouter models API](https://openrouter.ai/api/v1/models)
- Anthropic Start-tier limits: 2,000,000 input tokens per minute on Haiku models; monthly spend cap USD 500. — [Anthropic rate limits](https://platform.claude.com/docs/en/api/rate-limits)
- Reference spends: MemRL's maintainers, about USD 1,000 for BigCodeBench alone; a reproducer, USD 300 lost to trial and error; Goyal and Ray, USD 221 for 1,440 evaluations on rented GPUs. — [MemRL issue 10](https://github.com/MemTensor/MemRL/issues/10); [Goyal and Ray](https://arxiv.org/html/2609.05339v1)
- Dates: ICML abstract 14 January and paper 22 January 2027; ICLR 2027 final decisions 16 December 2026 (reviews were released 5 November, discussion runs to 18 November). — [ICML 2027 dates](https://icml.cc/Conferences/2027/Dates); [ICLR 2027 dates](https://iclr.cc/Conferences/2027/Dates)
- Dated hazards inside the window: Claude Sonnet 4.5 retires 30 November; Gemini 2.5 Flash and Pro re-route and Gemini 4 prices double on 1 December; GPT-5, GPT-5-mini and o3 shut down 11 December; GPT-4o and GPT-4o-mini shut down 14 January 2027. — [Anthropic deprecations](https://platform.claude.com/docs/en/about-claude/model-deprecations); [Google pricing](https://aistudio.google.com/docs/pricing); [OpenAI deprecations](https://developers.openai.com/api/docs/deprecations)

### Inferences

**Call counts for one single-call benchmark, recommended ("middle") size. All are estimates.**
- Build: 6 models × 3 orders × 600 tasks × 2 passes × 1.5 calls (solve, plus a write call on half the attempts) = 32,400.
- Home probes: 6 models × 3 orders × 200 tasks × 4 candidates × 2 repeats = 28,800.
- No-memory runs: 6 × 3 × 200 × 2 = 7,200.
- Cross probes: 12 pairs × 3 × 200 × 4 × 2 = 57,600.
- Live end-to-end check: 4 pairs × 4 arms × 3 orders × 300 tasks = 14,400.
- Total 140,400 calls. At an assumed 2,500 input and 500 output tokens per call: 351 million input and 70 million output tokens, about 23,400 calls per model if spread evenly.

**Cost of that benchmark at list price (estimate; per model = 23,400 × (2,500 × input price + 500 × output price) / 10^6).**
- Haiku 4.5: 23,400 × (2,500 × 1 + 500 × 5)/10^6 = USD 117.0
- Haiku 5.5: 23,400 × (250 + 250)/10^6 = USD 11.7
- gpt-5.6-luna: 23,400 × (500 + 600)/10^6 = USD 25.7
- gpt-6-luna: USD 11.7
- Qwen3.5-27B: 23,400 × (650 + 1,300)/10^6 = USD 45.6
- Qwen3.8-27B: 23,400 × (375 + 937.5)/10^6 = USD 30.7
- Sum: about USD 243 per benchmark. If real token use is twice the assumption, about USD 485.

**Released-code leg (MemRL on LifelongAgentBench DB), small size (estimate).** Two source models × 2 orders × 350 training tasks × 3 passes = 4,200 build episodes; 2 pairs × 5 arms × 2 orders × 150 validation tasks = 3,000 evaluation episodes; item probes (2 pairs + 2 home) × 150 × 4 × 2 = 4,800. Total 12,000 episodes at an assumed 13,000 input and 1,100 output tokens: USD 22 at 0.10 / 0.50, USD 48 on Qwen3.8-27B, USD 222 on Haiku 4.5. The RoMeRL-checkpoint variant needs no build and costs a third of this.

**Three budget levels (estimates, list price, before batch discounts).**

| Level | What is run | Arithmetic | Total |
|---|---|---|---|
| Low | One benchmark, four cheap models (Haiku 5.5, gpt-6-luna, Qwen3.5-27B, Qwen3.8-27B), 8 pairs, 2 orders, 150 probe tasks: 44,000 calls at 2,500 in and 400 out | USD 41 for the grid, plus pilot and waste | about USD 100 |
| Middle (recommended) | Two benchmarks at the size above, plus the small MemRL leg on cheap models, plus 30% for pilot, debugging and re-runs | (2 × 243 + 50) × 1.3 = USD 697 | about USD 700; about USD 1,400 if tokens are double ((2 × 485 + 100) × 1.3 = 1,391) |
| High | Three benchmarks at double tokens, the larger MemRL leg, one mid-tier pair (Sonnet 4.6 to Sonnet 5.5) on one benchmark, 30% waste | (3 × 485 + 153 + 243 + 162) × 1.3 = USD 2,617 | about USD 2,600 to 3,000 |

- Batch interfaces halve the cost of the probe calls on Anthropic and OpenAI (probes need no ordering); build streams are sequential and cannot be batched. A realistic saving is 20 to 30% of the total.
- The Anthropic Start tier's USD 500 monthly cap is enough for the middle level (Anthropic share about 2 × (117 + 12) plus the MemRL leg) but not for the high level without a tier increase. The cap resets on 1 December, which helps.

**Wall-clock (estimates).** The middle level is about 281,000 single calls plus about 36,000 calls inside 12,000 multi-step episodes. At 16 concurrent requests and 6 seconds per call, throughput is 9,600 calls an hour, so about 33 hours of API time. Rate limits are not binding (2,000,000 input tokens a minute is about 800 such calls a minute on one Anthropic model). Build streams are sequential inside a stream but the 18 streams per benchmark run in parallel; one stream of 1,200 attempts at 8 seconds is under 3 hours. The LifelongAgentBench leg is bound by Docker on a laptop: 12,000 episodes at an assumed 30 seconds with four in parallel is about 25 hours. The whole computation fits in roughly four to five days of machine time spread over three weeks.

**Week-by-week plan.**

| Dates | Work | Minimum viable result at the checkpoint |
|---|---|---|
| 15 to 22 November (week 1) | Day 1: dated pre-registration file; OpenReview profile; clearance request. Days 1 to 4: harness (stream splitter, two score rules, forced-injection prober, token and cost log, raw-answer store, repeat-aware cache). Days 5 to 7: pilot on DDXPlus with Haiku 4.5, Haiku 5.5 and Qwen3.8-27B, one order, 300 build tasks, 100 probe tasks. Read the two unread OpenReview bodies in a browser. | A measured memory gain, a measured home validity of the scores, a measured repeat disagreement, a measured cost per 1,000 calls. Go or no-go decision on 22 November |
| 23 to 29 November (week 2) | Full build and home probes on benchmark 1 for six models and three orders; finish all Haiku 4.5 calls; Docker and MemRL set-up on LifelongAgentBench DB with a 20-task smoke test; patch MemRL's temperature and cache issues | Home-validity table for six models on one benchmark; first three cross pairs. If nothing else is finished, this already supports a workshop paper |
| 30 November to 6 December (week 3) | All twelve cross pairs on benchmark 1; build, home and cross probes on benchmark 2 (BIRD); offline scoring of all arms, discount sweep and replayed recovery curves | The main table and figure on two benchmarks: retained validity, top-1 quality per arm, recovery curves. This is the minimum for a TMLR-grade paper |
| 7 to 15 December (week 4) | Live end-to-end check on four pairs; MemRL leg (two pairs) and RoMeRL frozen-checkpoint test; mechanism regressions; freeze experiments on 15 December | Released-code confirmation and the mechanism result. This is the ICML-grade version |
| 16 to 31 December | Read ICLR 2027 decisions (16 December) and adjust related work; figures; methods and results sections; one-page SSD case study; release package (code, prompts, raw answers) | Complete draft of sections 3 to 6 |
| 1 to 14 January | Introduction, related work with point-by-point differences, limitations, AI disclosure and impact statements; an outside reader; abstract submitted 14 January | Abstract in; full draft |
| 15 to 22 January | Reference check by hand; appendix; anonymised repository; submit 22 January | Submission |

**Go or no-go rule on 22 November (proposed).** Continue to the full grid only if all hold on the pilot:
1. Memory helps: the source model's success with its own memory beats no memory by at least 5 points, interval excluding zero.
2. Scores mean something at home: within-task concordance of the source's scores with its own probe outcomes is at least 0.60 with the lower bound above 0.55, for at least one of the two score types.
3. Noise is tolerable: same-model repeat disagreement on identical cells is below 15%.
4. Enough material: at least 150 items with five or more visits and at least 30% of probe tasks with candidates whose outcomes differ.
5. Cost is as planned: measured cost per 1,000 calls within twice the estimate.

If condition 2 fails on both score types, do not run the swap grid on that system; either increase exploration in the build and re-pilot for two days, or change the paper to "stored scores are barely valid even without a swap" and plan for TMLR. If condition 1 fails on DDXPlus, switch to ToolBench or Spider before spending more. If conditions 1 to 4 pass but the first cross pair shows retained validity within the self-swap noise, continue anyway: that is the "no drop" pattern and still needs the full grid to be a claim (section 7).

**What cannot be finished by 15 December by one person.**
- Any HLE run (800 million tokens per ten-pass build), BigCodeBench with MemRL's protocol (days per run, about USD 1,000), ALFWorld at 3,553 games per epoch across six models.
- SWE-bench, WebArena, GAIA or τ-bench grids.
- A CHIME replication (no code), RoMeRL training (not released), EvoKernel (no code).
- Human verdicts from real engineers, and anything on real SSD captures.
- More than about eight models, or five repeats everywhere.

**Largest version that can be finished.** Two single-call stream benchmarks, six models, twelve ordered pairs, three orders, two score types, the full arm set scored offline, replayed recovery plus a four-pair live check, and a two-pair MemRL leg on LifelongAgentBench DB with the RoMeRL checkpoints as an extra. If week 2 slips by more than three days, drop the MemRL leg to the RoMeRL-checkpoint test only and keep the two-benchmark grid intact.

### Gaps
- Every cost rests on assumed tokens per call. Reasoning tokens on current models could multiply output cost several times; the pilot measures this on day 5.
- No rate limits were read for OpenAI, Google or OpenRouter; open-weight throughput on OpenRouter for 27B models is unknown and could be the slowest link.
- The time to make MemRL's runner stable on a laptop is unknown; users report freezes and multi-day runs on other benchmarks, and no report exists for the LifelongAgentBench runner.
- Engineer hours are not estimated here; the plan assumes full-time work for four weeks, as the earlier ten-week plan did.
- Employer clearance timing (red-team note, objection M4) is outside this design and can stop a preprint or submission regardless of results.

## 7. Which result patterns are publishable, with headline and ICML 2027 contribution type

### Takeaway
All four patterns give a paper if the home validity, the noise floor and the mechanism test are in it, but they fit different contribution types and venues: a large drop fits "General", a mixed-by-pair result explained by response agreement fits "Datasets, Evaluations and Benchmarks", a small drop is a TMLR paper unless the recipe result is sharp, and a clean no-drop result fits "Negative Results" only if it is framed as overturning a specific expectation with an equivalence test. Accepted precedents with null or mixed headlines exist at ICML, NeurIPS and ICLR.

### Cited Findings
- ICML 2027 contribution types: "General (most papers)", "Theory", "Application-driven", "Concept and Feasibility", "Negative Results", "Datasets, Evaluations and Benchmarks"; reviewers "should evaluate the submission according to the Contribution Type selected by the authors." — [ICML 2027 Contribution Types](https://icml.cc/Conferences/2027/ContributionTypes)
- Negative Results: "The originality and significance bar for Negative Results contributions is high." "A failed experiment alone is not sufficient." "The paper should provide analysis, evidence, or theory that explains why the negative result matters." — [ICML 2027 Contribution Types](https://icml.cc/Conferences/2027/ContributionTypes)
- Datasets, Evaluations and Benchmarks: such a paper "does not need to introduce a new learning algorithm" and should "clearly state what scientific claims the dataset, benchmark, or evaluation supports." — [ICML 2027 Contribution Types](https://icml.cc/Conferences/2027/ContributionTypes)
- Accepted null or deflating headlines: multi-agent debate does "not reliably outperform other proposed prompting strategies" (ICML 2024); "Large Language Models Cannot Self-Correct Reasoning Yet" (ICLR 2024); "Chain of Thoughtlessness?" (NeurIPS 2024); "Are GANs Created Equal?" (NeurIPS 2018 per its arXiv comment). — [Smit et al., PMLR 235](https://proceedings.mlr.press/v235/smit24a.html); [Huang et al.](https://arxiv.org/abs/2310.01798); [Stechly et al.](https://arxiv.org/abs/2405.04776); [Lucic et al.](https://arxiv.org/abs/1711.10337)
- Other widely cited measurement papers whose headline was "the claimed gains mostly vanish under a fair protocol" or "it depends": "In Search of Lost Domain Generalization", "A Metric Learning Reality Check", "Descending through a Crowded Valley", "Do ImageNet Classifiers Generalize to ImageNet?". Their venues were not re-verified in this pass (the arXiv records carry no venue). — [Gulrajani and Lopez-Paz](https://arxiv.org/abs/2007.01434); [Musgrave et al.](https://arxiv.org/abs/2003.08505); [Schmidt et al.](https://arxiv.org/abs/2007.01547); [Recht et al.](https://arxiv.org/abs/1902.10811)
- A mixed-by-direction headline in the nearest neighbour: notes shift "by +9.91 or −13.28 percentage points depending on the specific migration direction" while a fixed schema moved +0.0004 (preprint, under review). — [Goyal and Ray](https://arxiv.org/abs/2609.05339)
- A mixed headline in the newest neighbour: the average contrast holds under a second reader "although individual memory–task labels change". — [arXiv 2611.03930](https://arxiv.org/html/2611.03930v1)
- The prior expectation a null would be measured against: MemRL asserts "the learned utility over memories generalizes beyond any single model's inherent strength" without a test that isolates scores; published transfers of scored memory all helped against no memory. — [MemRL v2](https://arxiv.org/html/2601.03192v2)
- TMLR does not require novelty or significance, and a study that "systematically studies the robustness or generalizability" of a published method can qualify (venue note). — [TMLR Acceptance Criteria](https://jmlr.org/tmlr/acceptance-criteria.html)

### Inferences

| Pattern | Definition (to be fixed in the pre-registration) | Headline | ICML 2027 type | Venue advice |
|---|---|---|---|---|
| Large drop | Retained validity below 0.5 on most pairs; keep loses to wipe or to the calibrated rule by 5 points or more in top-1 quality, beyond self-swap noise | "Stored memory scores do not survive a model swap: carried Q-values lose most of their ranking power, and k fresh checks recover it" | General (empirical finding plus a tested recipe) | ICML 2027; strongest case |
| Mixed by pair | Same-maker upgrades retain validity; cross-maker or downgrade pairs do not; response agreement predicts which | "When do memory scores survive an upgrade? Response agreement between models predicts it, and a calibrated discount is never worse than keep or wipe" | Datasets, Evaluations and Benchmarks (the probe protocol and released outcome tables are the artefact), or General | ICML 2027; the mechanism result is the paper |
| Small drop | Retained validity 0.7 to 0.9; arm differences of 1 to 3 points, significant only when pooled | "Carried scores are slightly stale: keep is near-optimal and a fixed discount buys little" | General at ICML is weak; Datasets, Evaluations and Benchmarks if the protocol is the contribution | TMLR first, or NeurIPS 2027 Evaluations and Datasets with more benchmarks |
| No drop | Equivalence within ±3 points on all primary contrasts; retained validity interval includes 1 | "Memory scores are portable across model swaps: an equivalence study of twelve swaps", with the explanation (reward tallies depend on the task and item more than on the reader) | Negative Results only if written as refuting the expectation that scores are model-bound (the frozen-model assumption, the item-level label changes of 2 November); otherwise Datasets, Evaluations and Benchmarks | TMLR is the planned home; ICML only if the equivalence is tight and the home validity is clearly above chance |
| Scores invalid at home | Home concordance near 0.5 for the released rule | "Greedy retrieval leaves memory scores uninformative even before a swap; what transfers is content" | Datasets, Evaluations and Benchmarks | TMLR or NeurIPS 2027 Evaluations and Datasets; overlaps with the ICLR 2027 submission on undetermined values |

- The no-drop case needs care about "surprise". Published tables already show that transferred scored memory helps, so "keeping is fine" agrees with MemRL's claim. What would be new is that the claim is finally tested with content held fixed, a wipe arm and an equivalence margin. A reviewer may still call it expected. The honest framing is confirmation with evidence, sent to TMLR, with ICML attempted only alongside a positive mechanism finding (for example, model-assigned tallies fail while reward tallies survive).
- The most publishable single outcome is probably a split by score type (H3): reward tallies survive, model-assigned counters do not, or the reverse. It gives a rule a practitioner can apply and a reason, whatever the average drop is.
- In every pattern the paper should report the same fixed set: home validity, self-swap floor, per-pair table, pooled estimate with interval, arm comparison, recovery curve, cost table, mechanism regressions, and the released probe tables. That set is what makes the result checkable and is the main defence against "one missing baseline in someone else's appendix".
- The SSD case study belongs in one page under any pattern: the product's keys are computed by code, so the paper's prediction for it is "tallies survive", and a small run on the synthetic traces either agrees or shows where a model-made decision leaks in.

### Gaps
- No accepted paper was found whose headline is an equivalence ("no change") result for agent memory specifically.
- The venues of four of the older measurement papers were not re-verified in this pass.
- ICML 2027's per-type review forms are not posted, so how "Negative Results" will be scored in practice is unknown.
- The thresholds in the table (0.5, 0.7 to 0.9, ±3 points, 5 points) are proposals to be fixed before data are seen; they have no external source.

## 8. The closest unread items: were the bodies reachable, and does any already contain keep, wipe and discount for numeric scores?

### Takeaway
The paper bodies of all three ICLR 2027 submissions remain unreachable from a script (OpenReview returns a challenge page for forum, API, PDF and attachment addresses, and none is on arXiv or matched on Semantic Scholar), but full abstracts and TL;DRs were read through OpenReview's search endpoint and the HEIRS code was read in full through its anonymous repository. From what was reachable, none contains a keep, wipe and discount comparison for numeric scores on memory items; the nearest is one sentence in "When Can a Skill Library Trust Its Execution Records?" comparing three local trials with pooled records from other models, on sixteen QA questions.

### Cited Findings
- Access attempts on 15 November 2026: `api2.openreview.net/notes?id=...`, `openreview.net/pdf?id=...`, the static `/pdf/<hash>.pdf` paths and `/attachment/...` all returned HTTP 403 "Challenge verification required" (the attachment returned 404). arXiv title searches for all three returned nothing; Semantic Scholar's title match returned "Title match not found" for two and a rate-limit error for one. — [OpenReview forum Ds8Nz1GuuQ](https://openreview.net/forum?id=Ds8Nz1GuuQ); [arXiv API](https://export.arxiv.org/api/query); [Semantic Scholar API](https://api.semanticscholar.org/graph/v1/paper/search/match)
- The OpenReview search endpoint did return the full abstract, TL;DR, keywords, primary area and file paths for each. — [OpenReview search](https://api2.openreview.net/notes/search?term=Beyond%20the%20Final%20Skill%20Revaluing%20Skill%20Evolution%20History%20After%20Executor%20Replacement&type=terms&content=all&source=forum&limit=3)

**HEIRS (Ds8Nz1GuuQ)**
- TL;DR: "HEIRS revalues archived Skill versions after an LLM executor change and selects one unchanged, recovering useful history with fewer target evaluations than fresh Skill optimization." The abstract names the two baselines: "Existing transfer approaches typically reuse the source-selected Skill or optimize a new target-specific Skill". Results: Qwen3.5 migrations and DeepSeek-to-GLM; ALFWorld +4.5 points over endpoint transfer; Spreadsheet +11.5 points; "52.4% fewer logical target evaluations than fresh SkillOpt". Code link: anonymous.4open.science/r/HEIRS. — [OpenReview search](https://api2.openreview.net/notes/search?term=Beyond%20the%20Final%20Skill%20Revaluing%20Skill%20Evolution%20History%20After%20Executor%20Replacement&type=terms&content=all&source=forum&limit=3)
- Code, read in full (README, `selection.py`, `core.py` header): each archived skill carries a "frozen source validation" `source_score`; selection under the target uses "a 16-task screening panel", keeps "the top two distinct score levels ... capped at four", then a disjoint 16-task confirmation with pre-frozen tie extensions; the release "does not include the manuscript, model weights, benchmark data, experimental logs". — [HEIRS anonymous repository](https://anonymous.4open.science/r/HEIRS)
- In the code the carried source score is used only as a secondary sort key and a last tie-break: `ranking` sorts by target score, then `-source_score`, then chronology, and the final fallback reason is `"source_score_then_chronology_tie"`. A search of the two source files for "discount", "prior", "weight", "decay" and "shrink" found nothing. — [HEIRS selection.py](https://anonymous.4open.science/api/repo/HEIRS/file/src/heirs/selection.py)

**"When Can a Skill Library Trust Its Execution Records?" (wSdg23aQOr)**
- TL;DR: "Execution records can transfer useful information, but predicting update effects, deciding deployment, and substituting shorter skills require separate evaluations."
- Abstract, beyond what the earlier note quoted: "That information raises the value of a fixed retrospective gate by 0.324 F1 points over its matched control, yet the gate's own value relative to rejecting every update is estimated at −0.591 points (95% interval [−1.425, 0.042]). Receiver-only and pooled histories also attain lower absolute prediction risk than same-proposal history. In a separate crossed study, three local trials beat pooled records in two settings and lose in two others as the balance of local execution noise and nonlocal error reverses." It also reports that substituting a shorter skill "changes answer distributions and source outcomes under GLM". A supplementary zip exists and was not reachable. — [OpenReview search](https://api2.openreview.net/notes/search?term=When%20Can%20a%20Skill%20Library%20Trust%20Its%20Execution%20Records&type=terms&content=all&source=forum&limit=3)

**"Beyond Semantic Relevance" (W5fHCH5rOE)**
- TL;DR: "We find that small and medium-sized language model agents often select unhelpful skills, and introduce ECSS to guide selection using each model's own execution experience." The abstract's method ("SkillCredit ValueFusion") "grounds semantic skill selection in the executor's own experience"; "Independent calibration adjusts the correction strength for each backbone and task domain"; experiments are on "question-answering benchmarks and model backbones". — [OpenReview search](https://api2.openreview.net/notes/search?term=Beyond%20Semantic%20Relevance%20Grounding%20Skill%20Selection%20in%20Model-Specific%20Execution%20Experience&type=terms&content=all&source=forum&limit=3)

**Timing**
- ICLR 2027 reviews were released on 5 November 2026, the discussion runs to 18 November, and final decisions come on 16 December 2026. — [ICLR 2027 dates](https://iclr.cc/Conferences/2027/Dates)

### Inferences
- HEIRS, on code evidence: no keep, wipe and discount comparison for numeric scores. Its three-way comparison is keep the source's chosen skill, re-select among archived versions with 32 or more fresh target evaluations, or rebuild. Re-selection ignores the carried number except to break ties, so in this study's vocabulary HEIRS is "wipe, then spend a fixed fresh budget", applied to about four candidate skill files, with no weighting of old against new evidence and no rank-agreement measurement. It strengthens the case that a fresh-check budget is the right axis, and it must be cited as the closest design. Its paper body could still contain an ablation that uses source scores as a prior; the code gives no sign of one.
- "When Can a Skill Library Trust Its Execution Records?" is closer than the earlier notes said. Its crossed study compares a small number of local trials (three) with pooled records from other receivers, which is fresh checks against carried evidence, and its result is mixed (two wins, two losses) with an explanation in terms of local noise against non-local error. That is the bias-variance trade the calibrated discount formalises. What the abstract does not show: a discount or mixture rule, a sweep over the number of fresh trials, memory items with tallies, more than sixteen questions, or rank agreement under the target. The proposed study should present itself as the scaled and formalised version of that one sentence, and cite it prominently.
- "Beyond Semantic Relevance" treats execution credit as belonging to the executing model and calibrates per backbone. By its abstract it never moves one model's credit to another, so it supports the premise and does not overlap the experiment.
- Net effect on novelty: the claim "no one has compared keep, wipe and a discount for stored numeric scores across a model swap, with rank agreement measured under the new model" still stands on everything reachable. The claim "no one has compared a few fresh local trials with carried records from other models" does not stand; one submission has, at small scale.
- Risk timing: decisions on all three arrive on 16 December, the day after the experimental freeze. Accepted versions may add experiments. The related-work section should be written after that date, and the two unread bodies should be read through a normal browser session in week 1.

### Gaps
- The bodies, reviews and rebuttals of all three submissions were not read. A score-transfer table could exist in any of them. This remains the largest unverified risk to the novelty claim, unchanged from the earlier note except that HEIRS's code now makes it unlikely for HEIRS.
- The supplementary zip of "When Can a Skill Library Trust Its Execution Records?" was unreachable; it may contain code and per-question tables.
- alphaXiv mirrors only arXiv papers and none of the three is on arXiv; no other mirror was found.
- The withdrawn "Refreshing Agent Memory with Policy-Response Drift" submission was not re-attempted in this pass.
