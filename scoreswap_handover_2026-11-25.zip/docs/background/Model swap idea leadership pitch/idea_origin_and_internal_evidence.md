# Idea 1 (model swap / "does experience survive the upgrade"): internal origin, selection history and evidence base

Local-file research only, done 2026-11-15. No web search, no test run, no model call, `api_key.txt` not opened, no large CSV read, no project file changed.
All paths are relative to `<other project>/` unless they start with `/`.
File dates are the modification times on disk (`ls --time-style=long-iso`), given as [date] after a path the first time it is used.
`research.html` [2026-11-10 04:28] and `reports/Reinforced memory and harness research gaps.md` [2026-11-10 04:28] carry the same text (same headings, same sentences); line numbers below are those of the `.md` twin, and the section heading is the same in `research.html`. An identical copy of `research.html` (112,396 bytes) is in `_github_copy_2026-11-15/` [2026-11-15 14:23].
Three labels are used throughout: **BUILT** (code exists), **TESTED ON SYNTHETIC ONLY** (measured, but on generated recordings, a simulated drive, a stand-in or scripted model), **PLANNED** (written in a document, nothing run). "Inferred" marks a conclusion no file states. "Computed here" marks arithmetic done in these notes.

Important for the writer: **the idea exists in two write-ups that differ in scope, schedule and closest rival.** Version A is `research.html` (10 Nov 2026, "Does experience survive the upgrade?"). Version B is `reports/One month top venue paper idea.md` [2026-11-12 01:21] ("Test whether feedback outlives a model swap"). The "four swap rules" named in the brief are stated in Version B; Version A states the same thing as three baselines plus one proposed rule. The differences are tabulated under question 7.

---

## 1. What exactly is Idea 1, what does the "Pitch for the manager" say, and what does "How far to trust this" caution?

### Takeaway
Idea 1 is a measurement, not a new method: when the LLM under the system is replaced, do the stored verdict tallies still rank procedures/fixes correctly, and should they be kept, wiped or discounted. Both write-ups say plainly that the experiment has not been run, that the effect could be near zero, and that the project's own numbers so far are synthetic.

### Cited Findings

**The question, as stated**
- Summary card: "Nobody has measured whether a procedure's verdict history still predicts its quality under a new LLM, or how much of it to keep; Goyal and Ray tested stored content and left procedures out." — `research.html`, section "Five ideas, most open gap first" (`.md` line 5 block)
- "the most open one is not where the project started: **no study in these notes measures whether a procedure's accumulated weight still predicts its quality after the LLM is upgraded**." — `reports/Reinforced memory and harness research gaps.md:3`
- The gap in one sentence: "Content portability is crowded; evidence portability is not... they ask whether stored content still works; nobody has asked whether stored evidence about that content is still true." — `research.html`, "Idea 1", paragraph "The gap" (`.md:160`)
- Why it matters: "In a never-retrain design the weights are the only thing the system learns, and the LLM underneath them will change... If weights do not transfer, the organisation must re-earn them from its scarcest resource, engineer reviews; if they are carried blindly, old evidence against a procedure raises the chance of retiring it wrongly after the upgrade. Either way every model upgrade is an unmanaged risk, and no published rule says what to do." — `research.html`, "Idea 1", "Why it matters" (`.md:162`)
- Version B's one-sentence form: "when the language model inside an agent is replaced by another, can the stored tallies of human verdicts ('this fix was judged correct 9 times out of 10') still be trusted to rank the fixes, or should they be kept, wiped, or counted at reduced weight until a few fresh checks confirm them?" — `reports/One month top venue paper idea.md:3`
- Version B's plain-language picture (useful for leadership): a repair workshop notebook with a score per fix; a new mechanic sorts incoming faults onto pages differently, so "The '9 out of 10' was earned on the faults the old mechanic put on that page". "In the application the mechanic is the language model: the model decides which defect a trace is filed under, while the tallies sit on links that describe the device. **Whether the tallies still rank the fixes correctly after the model changes is the question, and the mismatch in filing is the mechanism to test.**" — `reports/One month top venue paper idea.md:9`

**The claim (a hypothesis, not a result)**
- "The claim, a hypothesis to be tested: a procedure's accumulated weight predicts its post-upgrade quality when the procedure encodes the task, and predicts it poorly when it encodes the old model's prompt conventions, so a per-class discount estimated from a small replay beats keeping everything, resetting, and one global discount. The contribution is the first measurement found of evidence portability, a discount rule, and a reusable paired-run protocol. A null result, in which no discount beats the simple ones, is still a contribution" — `research.html`, "Idea 1", "What is claimed and contributed" (`.md:164`)
- Version B is stricter about what is new: "A reviewer will call the discount rule known statistics, and the reviewer will be right. **The contribution is the measurement, not the rule.**" — `reports/One month top venue paper idea.md:35`

**The four swap rules**
- Version B: "The paper compares four simple rules for the day of the swap: keep every tally, wipe them all, count the old tallies at a fixed reduced weight, or set that weight from a small batch of fresh checks." — `reports/One month top venue paper idea.md:11`
- Version A states the same four as: keep everything (a0 = 1), reset (a0 = 0), one global a0, and the proposed per-class a0 "estimated from a small replay"; an upgrade is treated "as one event that multiplies evidence above the prior by a factor a0 between 0 and 1, in the spirit of the power prior from classical statistics (Ibrahim and Chen 2000, UNVERIFIED)". — `research.html`, "Idea 1", "How to do it" (`.md:166`)
- Version A adds further baselines: no memory, similarity-only retrieval, discounted Thompson sampling, a MemRL-style value, a budget-matched plain agent. — same paragraph (`.md:166`)
- Origin of the "three obligatory baselines" wording: "A model upgrade can be treated as one large decay step: multiply the evidence above the prior by a0. Three named baselines are therefore obligatory: keep everything (a0=1), reset (a0=0), and one global a0." — `research_notes/Reinforced memory and harness research gaps/novelty_threats_statistics.md:247` [2026-11-10 04:01]

**The metrics**
- Version A: "rank correlation ... between pre-upgrade weight and measured post-upgrade success, wrong retirements after the upgrade, Goyal and Ray's Cost-to-Recover, the human verdicts needed to return to pre-upgrade quality, and tokens and latency." Five experiments: "predictiveness by procedure class and upgrade direction; a sweep of a0; per-class against global a0 at several replay budgets; re-testing retired procedures on the new model; and sensitivity to simulated reviewer noise." — `research.html`, "Idea 1", "How to do it" (`.md:166`)
- Version B: "For each rule it reports three numbers: how often the fix shown first is the right one, how well the old tallies agree with what really works under the new model, and how many fresh verdicts are needed before the ranking is as good as one rebuilt from nothing. It also reports how often two models file the same trace under the same defect, and tests whether low agreement predicts a large drop." — `reports/One month top venue paper idea.md:11`

**Expected outcomes (both directions are stated as publishable)**
- "Both outcomes are worth printing. If the tallies fail, the paper gives a warning and a rule. If they survive, the paper states when keeping them is safe: when the links describe the device and the filing agrees. **No such experiment has been run yet, and the effect could be close to zero**" — `reports/One month top venue paper idea.md:11`
- "The result may simply be that evidence transfers uniformly or not at all, which makes a shorter paper." — `research.html`, "Idea 1", "Risk" (`.md:172`)
- "If rank correlation is high and uniform across classes, the paper becomes a short 'keep everything' result for TMLR." — `research.html`, "First paper: measure whether experience survives the upgrade" (`.md:255`)
- "Whatever the result, we get a tested rule for every future model upgrade." — `research.html`, "Pitch for the manager" (`.md:261`)

**What evaluation Version A says is required**
- "The simulated drive contains no real model change, so it cannot speak to this. Every headline number must come from real model-version pairs on held-out tasks, with confidence intervals ... and a small real-reviewer subset must confirm that verifier outcomes stand in fairly for human verdicts." — `research.html`, "Idea 1", "New evaluation it needs" (`.md:168`)

**The existing "Pitch for the manager" (full text of the paragraph)**
- "Over the last seven months researchers have rushed into agent memory; abstracts on the topic rose about tenfold year on year. Our design, where engineers' verdicts change weights on a graph of procedures and the LLM is never retrained, sits close to many of those papers, and the formula itself is no longer new. One practical question has no published answer: when we upgrade the LLM, do the weights our engineers earned still mean anything? I propose a study of about five months that answers it on real model versions and public benchmarks. It uses compute more than engineer time. Whatever the result, we get a tested rule for every future model upgrade. In parallel, two senior engineers double-review a small stream of outputs, which gives us our first measurement of how consistent our reviewers are, and data no competitor can copy quickly. Today our numbers come from synthetic data and a simulated drive, so the study's first job is to replace them with real evidence. If another group publishes first or reviewers pass on it, the tools and the measurements stay with us." — `research.html`, "Pitch for the manager" (`.md:261`)
- The ask table is headed "Ask (my estimates, not from the notes)": one engineer, about half time for 5 months (paired runs, analysis, paper draft); two senior engineers, 1 to 2 hours a week each (double-reviewed verdicts, reviewer agreement); LLM and compute budget "To be sized after the week-8 run" (two model pairs, several seeds); legal review, one pass before any release. — `research.html`, "Pitch for the manager" (`.md:263-268`)
- "The checkpoint for the manager is week 8: a yes or no on continuing, based on a real measurement." — `.md:270`
- The "tenfold" figure rests on: "Abstracts containing the exact phrase 'agent memory' rose from 33 to 340 for the same April-to-November window a year apart (arXiv API counts)." — `research.html`, "The field turned from building to auditing..." 

**"How far to trust this" cautions**
- "**Treat every number as provisional until checked against the PDF.** The notes behind this report list 731 distinct URLs, but most pages were opened through a fetch tool that returns a model-written digest and reads only the first 100,000 characters of a long paper, so appendices often went unread and 'does not do X' means no X in the part read." — `research.html`, "How far to trust this, and what to read before claiming novelty" (`.md:274`)
- "Negative claims are the weakest part. Each note used one web-search tool with a limited budget, and none crawled OpenReview, ACL Anthology or arXiv listings end to end... Rerun the sweep ... immediately before any submission. Closed industrial systems cannot be seen at all." — `.md:276`
- Must-read-before-claiming list for Idea 1: "Portable Agent Memory (arXiv 2605.11032); Trace2Skill; Ibrahim and Chen 2000 power prior", all UNVERIFIED. — same section, table
- "Every 'not found' below means not found in the searches run for these notes up to 10 November 2026, so novelty must be rechecked just before submission." — `.md:3`
- Version B names three more unread items that could overlap: the MemRL code; the ICLR 2027 submission "When Can a Skill Library Trust Its Execution Records?" ("**This is the paper most likely to overlap; it must be read before the introduction is written**"); NeurIPS 2026 titles such as "Frozen Memory Is Not Enough". ICLR 2027 decisions arrive on 16 December 2026, "so the list of neighbours must be checked again that week." — `reports/One month top venue paper idea.md:30, 37`

### Inferences
- Inferred: the title in `research.html` ("Does experience survive the upgrade?", working paper title "Does Experience Expire?") sits very close to the rival preprint's title quoted in Version B ("Does Your Agent's Memory Survive a Model Upgrade?", Goyal and Ray). Version B itself warns: "The broad question 'does agent memory survive a model upgrade' is taken" (`reports/One month top venue paper idea.md:15`). A pitch should word the idea as *evidence/tallies* surviving, not *memory* surviving.
- Inferred: the two versions name different hypothesised mechanisms. Version A: procedures that "encode the task" keep their weight, procedures that encode "the old model's prompt conventions" do not. Version B: the tallies sit on device-describing links, and the model change matters through *which defect the model files a trace under*. They are compatible, but a pitch should pick one.

### Gaps
- No file contains a result for Idea 1. Everything in this section is a statement of intent (PLANNED).
- External literature facts quoted in these files (Goyal and Ray, MemRL, the 33-to-340 count) were not rechecked here; the files themselves label many of them provisional.

---

## 2. What are Ideas 2 to 5, and why does `research.html` rank Idea 1 first?

### Takeaway
The ranking criterion is "how open the gap is", judged by four tests in a fixed order; Idea 1 is the only gap where a dedicated attempt to break the novelty claim found no direct hit. The page also argues it is the cheapest to test and that its setup is reused by later ideas. It states that openness is not the same as value and that no acceptance can be promised.

### Cited Findings

**The ranking criteria**
- "Openness was judged by four tests, in this order: did a dedicated attempt to break the gap find a direct hit; is what remains a new question or a new application of a known tool; how many independent groups are converging; and how strong is the 'not found' evidence." — `research.html`, "Why the ranking is what it is" (`.md:128`)
- "Openness is not value. If this lab's costliest failure is retiring a procedure that still works, idea 5 is worth more than its rank suggests. No idea here can be promised acceptance at any venue" — `.md:138`

**Per-idea verdicts (from the table in "Why the ranking is what it is" and the five idea sections)**

| Rank | Idea (title in `research.html`) | Closest paper | Exact difference that remains | Why it ranks here | Evidence it needs that the project lacks | Stated scooping risk | Stated timeline and target |
|---|---|---|---|---|---|---|---|
| 1 | Does experience survive the upgrade? Measuring procedure weights across LLM versions | Goyal and Ray | "They test stored content; nobody tests stored evidence about that content" | "A dedicated attack found no direct hit. It is the only gap the novelty review calls open. Classical discounting supplies a baseline, not an answer." | Real model-version pairs on held-out tasks; small real-reviewer subset | "high because the study is cheap and Goyal and Ray have named the hole" | 16 to 18 weeks; TMLR rolling, or NeurIPS 2027 / EMNLP 2027 (about May 2027, projection) |
| 2 | Whose verdict counts? Shared weights as a channel between tenants | MemLeak and FedWorld | "They measure reading across boundaries and majority overwrite; neither has a number one tenant's verdicts move for another" | "No hit in targeted searches, but no dedicated attack was run, and hierarchical and corrupted-bandit tools exist, so part of it can read as application." | Real LLM runs across tenants, a proxy stream of real human reviews, explicit attackers; "No real multi-tenant verdict stream is available" | "moderate to high"; "its rank is the least certain of the top three" | 24 weeks; NeurIPS 2027 |
| 3 | The edit is the evidence: typed human verdicts on real reviewers | MSCE and SmartVector | "No edit classes, no real reviewers in the experiments, and nothing uses the edited step as evidence about one edge" | "The novelty review rates typed verdicts partly filled; coactive learning covers edits in theory, and one arXiv query failed, so the negative is weaker." | "Real reviewers are the whole paper"; 300 double-reviewed outputs is the planning figure | "lowest of the five, because human studies are slow to copy" | 28 weeks; EMNLP 2027 Industry or ICLR 2028 |
| 4 | Test the self-change on the logs first: evaluating harness and procedure changes before they ship | The Replay Gap | "It shows replay fails for model switches and offers no estimator; the methods have not been applied to memory or harness changes" | "The methods are filled (Dudík et al., Waudby-Smith et al.). Three setting-specific problems remain, and long-horizon evaluation was not surveyed." | Logged selection probabilities, real candidate changes, branched rollouts (none exist) | "high because statistical gating is the fastest-closing part of harness work" | 30 weeks; ICLR 2028 |
| 5 | Retire without false alarms: library-wide control under noisy human reviewers | Xu, Wang and Ramdas; Many Steps into One | "Unknown reviewer error with one reviewer per use; a rate-type statement for the decayed, capped rule; reversal" | "The largest part is a corollary of a 2021 result, two independent groups have worked here since May 2026, and an unread AAAI 2026 paper may close more." | Injected truth, real reviewer error, a statistician co-author | "the highest of the five" | 24 weeks; NeurIPS 2027 |

Sources for the table: `research.html`, "Why the ranking is what it is" (`.md:126-138`) and "The five ideas in full" (`.md:158-236`).

**Why Idea 1 is the first paper (the commitment)**
- "**Start with idea 1, and start idea 3's data collection in parallel.** Idea 1 is the most open gap and the cheapest to test. It runs on compute and public benchmarks, so it does not depend on the project's synthetic data or a reviewer panel at first, and its paired runs and injected-truth tasks are reused by ideas 4 and 5. Idea 3's double-reviewed verdicts are slow to gather and form the one asset competitors cannot produce quickly." — `research.html`, "First paper: measure whether experience survives the upgrade" (`.md:253`)
- The underlying research note's verdict table: gap "**D.** What to do with accumulated weights after an LLM upgrade | **Open** on evidence and weights; **partly filled** on content and representations". — `research_notes/Reinforced memory and harness research gaps/novelty_threats_statistics.md:268`
- The note's own pitch order: "(1) D as an empirical measurement: does a procedure's verdict history survive a model upgrade, and how much should be discounted. It is the only gap with no direct hit, it is cheap, and it fits a system that already stores per-procedure evidence." — `novelty_threats_statistics.md:285`
- Searches behind the "no direct hit": five named queries, "None returned a study of whether per-item success evidence transfers across versions." — `novelty_threats_statistics.md:253`

**Why "we combined them" and the formula itself are not the pitch**
- "No paper found combines real human verdicts, per-edge count weights, decay, error-controlled retirement, tenants and a self-changing harness, yet almost every part was published between April and November 2026, so 'we combined them' will not carry a paper." — `.md:3`
- Thirteen claims are listed as already published by others, including "First Beta-weighted graph memory", "First retirement on a posterior threshold", "Decay toward a prior", "Beta weights on procedures with a frozen LLM", "Human approvals move a Beta trust that triggers rollback". — `research.html`, "Thirteen attractive claims are already taken"
- "Model upgrades | Content crowded, evidence empty | ... | Whether accumulated evidence transfers." — `research.html`, trend table in "The field turned from building to auditing between April and November 2026"

**"Other gaps were considered and left out" (eight candidates)**

| Candidate | Reason given for leaving it out |
|---|---|
| Regret bound for discounted Beta Thompson sampling | "pure theory and does not use the project's strength" |
| Head-to-head against repeated fine-tuning on procedures | "A real gap ... It is expensive and belongs later as a control." |
| Stream-level drift control for harnesses | "Real ... but closing fast; include a global guard in idea 4." |
| One posterior over procedures and harness | "AEL supplies direct negative evidence; run it as an experiment in idea 4." |
| Reinstatement alone | "a weak hook on its own; folded into idea 5." |
| Cascading deprecation in a dependency graph | "Evidence so far is thin (PACMI: 11 errors against 3, p = 0.0574, not significant)." |
| Non-stationary path reliability | "a theory-only paper." |
| A deprecation benchmark for an evaluations track | "synthetic-only data invites the 'boutique' objection. It could follow idea 3's data." |

Source: `research.html`, "Other gaps were considered and left out" (`.md:238-249`).

**A second, independent selection two days later (Version B, 12 Nov) reached the same idea against a different candidate set**
- Version B rejects four other candidates "on the same test of 'still open, and provable by one person'": the broad "does agent memory survive a model upgrade" (taken by Goyal and Ray); graded credit for "correct with edits" (needs real engineers; PRELUDE already treats user edits as a signal); the Data Grounder (close published neighbours: Bodensohn et al., NameGuess); the five-level trace benchmark (slot empty, but a comparable telecom benchmark was rejected at ICLR 2026; kept as the fallback). — `reports/One month top venue paper idea.md:15`
- The audit behind Version B scored five candidate experiments A to E against the code; A is the model-swap experiment: "needs small to medium changes. No script runs it today." — `research_notes/One month top venue paper idea/owner_assets_audit.md`, section 4 [2026-11-12 00:41]

### Inferences
- Inferred: Idea 1 won two separate selections under two different constraints. On 10 Nov it won on "most open gap"; on 12 Nov it won on "still open and provable by one person in a month with frozen models and no field data". The second selection is the stronger argument for a manager, because it is about feasibility with the assets the team has.
- Inferred: of the five ideas, Idea 1 is the only one whose required evidence does not start with something the project lacks entirely (real reviewers for 3, a multi-tenant verdict stream for 2, logged probabilities for 4, a statistician and real reviewer error for 5). This follows from the "New evaluation it needs" paragraphs but no file states it as one sentence.

### Gaps
- `research.html` does not rank by business value, cost or fit to the opportunity statement; it says so ("Openness is not value"). No file ranks the five ideas on those criteria.
- Idea 2's rank is flagged by the page itself as uncertain ("never had a dedicated novelty attack").

---

## 3. How did the idea arise from the actual work? (dated timeline)

### Takeaway
The idea is a direct consequence of one design rule the owner set and repeated: reinforcement is *mimicked* by counts on a procedural graph from the admin's verdicts, and no model is ever trained. Once the tallies are the only thing the system learns, and the model is a rented, swappable part, "what are the tallies worth after the model changes" follows. The idea first appears in writing on 10 November 2026, in a novelty review the owner commissioned for a paper and a manager pitch, and that review notes it "is not where the project started".

### Cited Findings (timeline)

| Date (file date) | What happened | Source |
|---|---|---|
| 2026-10-24 | Synthetic PCIe trace generator written; the 485-error trace generated (seed 20261024; provenance "SYNTHETIC scenario-driven data; NOT a real Teledyne LeCroy capture"). | `02_generator_and_validator_code/` (files dated 2026-10-24); `03_main_csv_sidecars/synthetic_trace_manifest.json` [2026-10-24 20:00] |
| 2026-10-25 | Rule-based isolation engine measured on a 4.0 GB synthetic trace: 437 of 485 episodes (90.1%) wire-only with 0 false positives; 483 of 485 with simulated outside evidence. | `10_defect_isolation_engine/REPORT_defect_isolation.md:1-41` |
| 2026-10-25 04:18 | First research report on "RL without training": "Bandit-weighted case memory can replace the RL agent". It describes "the team's proposed design": "a weighted procedural graph with signature → cause → scenario → script, a top-5 retrieval, admin ranking, and three verdicts", and says "As written, though, the design covers only half of the 'RL-Powered Field-to-Test Loop'." It proposes "The 485 labelled episodes can act as a simulated admin." | `11_failure_reproduction_research/RL style failure reproduction without training - research report.md` (opening section and headings at lines 1-29, 485) |
| 2026-10-25 04:27 | The feedback-graph simulation written: "Simulate the admin-feedback procedural graph ('RL without training') with several implementations ... Each policy updates its graph only from that feedback - no training, no dataset." Three verdicts then (correct / partially correct / not correct), nine policies, a built-in "firmware change: the dominant cause moves for some cards" at a 20% rate. | `12_feedback_graph_simulation/simulate_feedback_graph.py:1-12, 47, 70-76, 213-368, 453-458` |
| 2026-11-02 | Owner's rule: "Exactly four reinforcement signals and nothing else: positive, positive with edits, negative, negative with edits." LLM only names the scenario; detection is deterministic. | `<assistant files>` [2026-11-02] |
| 2026-11-03 | Column names of a real analyzer export transcribed from 25 screen photos on the customer's machine; the export itself stayed there. | `owner_assets_audit.md` section 1 (citing `13_production_app/data/lecroy_export_columns.json`) |
| 2026-11-07 (file saved 2026-11-08 02:46) | The owner's own approach text: "Agentic Mutliverse with reccursive self improvement to isolate the defect carrying reinforcement signal to map the testcase to reproduce the error scenario." Family 3 is the "Recursive self improving Tracking Agent Family"; "the procedural graph to the test case generation by carrying the reinforcement signals on already found signals"; "Then fix the solution to it and figure out, then the second level of reinforcement learning , procedural graphs etc etc." | `Approach_statement_2026-11-07.md:29, 174, 255, 265` |
| 2026-11-08 | Reframing: "This is the 'recursive self-improvement': stored rules, reviewed again and again. No model is trained or fine-tuned." Rule 7 of "Rules that hold everywhere": "No model is trained or fine-tuned." | `Approach_reframed_and_plan_2026-11-08.md:93, 184` [2026-11-08 02:56] |
| 2026-11-08 | Plan for approval, principle P8: "**No training.** 'Self-improvement' means stored rules, strategies and the four signals, reviewed by the admin. No model is fine-tuned." P1: "Agents propose, the admin approves, code runs. No model decides a finding at run time." Stage 2 = "the procedural graph, the four signals on the stored procedures, and a test case that reproduces the error." | `Approach_plan_for_approval_2026-11-08.md:28, 35, 158` [2026-11-08 03:03] |
| 2026-11-08 | Same plan, decisions: D1 "Agent runtime: Claude Code, headless, **behind a swappable interface**"; D2 "Model and endpoint on the production machine: You name them (`<ENDPOINT URL>`, `<MODEL NAME>`, `<API KEY>` in env) — Only you know what that machine can reach." | `Approach_plan_for_approval_2026-11-08.md:187-188` |
| 2026-11-09 | "Owner, 2026-11-09: reinforcement learning is MIMICKED on procedural graphs: weights on nodes and edges change from the four signals, no model weights, no training infrastructure." KPI proof harness built the same day; reason recorded: "owner must defend the project to management; the honest line matters more than a green table." | `.../memory/graph-loop-and-kpi-proof-2026-11-09.md` |
| 2026-11-10 04:28 | `research.html` and its report written. Recorded trigger: "Owner wants a top-venue paper from the procedural-graph + four-signal idea and a pitch for their manager (2026-11-10)." Eight research notes (03:09 to 04:01). The model-upgrade gap surfaces in `novelty_threats_statistics.md` as gap D and is ranked first. | `.../memory/research-paper-ideas-2026-11-10.md`; `research_notes/Reinforced memory and harness research gaps/` (8 files); `novelty_threats_statistics.md:247-286` |
| 2026-11-11 00:11 to 05:08 | Three design reports on the graph itself: weights "start at the neutral Beta(1,1) and are shown as counts"; "Keep cause and sequence weights apart"; "the four judgement signals really do change what the next error sees, but the loop cannot yet honestly be called reinforcement learning and nothing measures whether it learns ... the live new store holds **0 judgements**." | `reports/Defect isolation and solution memory.md:3`; `reports/Procedural graph causes and solutions.md:3`; `reports/Procedural graph reinforcement and new causes.md:3` |
| 2026-11-11 | The current store is built: "The procedural graph as the owner defined it (2026-11-11): defect └ cause └ solution". "The admin's four signals (correct, correct with edits, wrong, wrong with edits) only change the ranking of what is retrieved and shown next time ('the reinforcement should be applied for the retrieval')." | `13_production_app/nvme_hier/defect_graph.py:1-17` [last modified 2026-11-15 04:08] |
| 2026-11-12 00:40 to 01:21 | Second research round with a one-month, one-person constraint: six notes and the report "Test whether feedback outlives a model swap". The asset audit checks candidate A (model swap) against the code. | `reports/One month top venue paper idea.md`; `research_notes/One month top venue paper idea/` (6 files) |
| 2026-11-14 | The official opportunity statement transcribed from four photographs; first coverage check: no statement fully covered. | `13_production_app/docs/OPPORTUNITY_STATEMENT.md:3` [2026-11-14 23:01]; `reports/Opportunity statement coverage check.md` [2026-11-14 22:40] |
| 2026-11-15 | Graph learns from lab runs: "owner, 2026-11-15: 'Reinforcement learning should learn from the previous things. That's where the procedural graph's mimicking of the reinforcement learning kicks in.'" "No model is trained here." Evidence from another firmware "is marked 'from an earlier firmware' and used only as a starting point". | `13_production_app/nvme_hier/graph_learning.py:1-24` [2026-11-15 04:09]; `reports/Timing parameters and graph learning.md` [2026-11-15 04:05] |
| 2026-11-15 | Coverage re-check (0 of 16 covered, 14 partly, 2 not); build 25; public hand-over copy whose README lists `research.html` as "research ideas that came out of the work". | `13_production_app/docs/OPPORTUNITY_COVERAGE_2026-11-15.md` [2026-11-15 06:45]; `13_production_app/BUILD.txt` ("build 2026-11-15 15:29"); `_github_copy_2026-11-15/README.md` ("What is here" table) |

**Statements in the files that tie the idea to the design**
- "In a never-retrain design the weights are the only thing the system learns, and the LLM underneath them will change." — `research.html`, "Idea 1", "Why it matters" (`.md:162`)
- "The application never trains a model. What it learns sits in a graph ... These tallies are the product's memory of human judgement, and they are the costly part, because each one takes an engineer's attention." — `reports/One month top venue paper idea.md:7`
- "The owner's two hardest limits, no model training and no field data, turn out to be the reason this idea is available at all: a memory that learns only from verdict tallies beside a frozen model is exactly the setting in which 'what happens to the tallies when the model changes' can be asked cleanly" — `reports/One month top venue paper idea.md:119`
- The design is close to published work and that is said openly: "Our design ... sits close to many of those papers, and the formula itself is no longer new." — `research.html`, "Pitch for the manager"
- The trend note in the same page flags a threat to the "never train" framing itself: "Joint evolution of weights and harness began moving away from the frozen-model setting, which is a direct threat to any 'never train the LLM' framing." — `research.html`, "The field turned from building to auditing..."

**What the 12 Oct-25 simulation simulated, and what its saved output is**
- World: built from the 485 atlas cards (`01_input_files/atlas_cards_raw.json`), signature → candidate causes → scenario variant; a hidden truth; 15% of cards have a real cause missing from the seeded graph; 20% of cards change their dominant cause at a "firmware change". Simulated admin gives three verdicts and can be wrong at noise 0, 0.1, 0.2. Defaults: 4,000 incidents, 3 seeds. — `12_feedback_graph_simulation/simulate_feedback_graph.py:47-76, 392-418, 453-458`
- Nine policies: "1 static (atlas order, no learning)", "2 random", "3 team design, literal (+1 / keep / x0.5, greedy top-5)", "3b team design, full", "4 tabular Q-learning (RL reference)", "5 UCB confidence bonus (deterministic)", "6 RECOMMENDED: Beta + Thompson + explore slot + localized blame + decay", "6b RECOMMENDED rules, ranked by Beta mean", "7 RECOMMENDED + Plackett-Luce update from the admin ranking". — same file, lines 213-368
- `run.log` holds two lines only: "seed 0 done (850s)" and "seed 1 done (1651s)". The script would print a third seed line and "wrote ..." at the end and would write `all_runs.csv`; neither is present. `results/` holds nine curve files (seed 0, admin noise 0.1, card id not known), `generated_incidents_seed0.csv` and `generated_world_seed0.json`. — `12_feedback_graph_simulation/run.log` [2026-10-25 04:55]; `12_feedback_graph_simulation/results/` (listing, files 04:28 to 04:37); script lines 484-513
- Saved curve values, last 250-incident window (incidents 3,751 to 4,000), share where the first shown item was right ("hit1"): static 0.316; random 0.080; team design literal 0.644; team design full 0.572; Q-learning 0.492; UCB 0.236; policy 6 0.520; policy 6b 0.656; policy 7 0.536. First window (1 to 250): static 0.336; team literal 0.404; 6b 0.476. — `12_feedback_graph_simulation/results/curve_1.csv, curve_2.csv, curve_3.csv, curve_3b.csv, curve_4.csv, curve_5.csv, curve_6.csv, curve_6b.csv, curve_7.csv`
- A later, larger benchmark of the same kind exists: 26 suites, 14 implementations, 2,489,438 incidents each; overall Exact@1 best Beta-mean policy 0.747, the team's literal design 0.678, the team's full design 0.624, tabular Q-learning 0.493, UCB 0.365, static order 0.089, random 0.027; suites include abrupt firmware change and gradual drift. — `owner_assets_audit.md` section 3 (citing `Database_Implmentation/claude_benchmark/results/ranking_tables.md`; not reopened for these notes)

**The project's own judgement of what those simulations prove**
- "The project's evidence is synthetic data and a simulated drive, and it should not be presented as real-world proof. Its simulation compares the learned choice with a static first choice across three procedures at 55, 70 and 90 percent success. That comparison is against the worst option by construction, and any standard bandit is expected to find the best arm on a stationary stream ... so the result does not separate this design from ordinary methods." — `research.html`, "The current evidence shows the machinery runs, not that the design wins" (`.md:120`)

### Inferences
- Inferred lineage, in one chain: (1) official statement asks for an "RL agent"; (2) Oct 25 research concludes a bandit-weighted case memory can stand in for it with no training; (3) the owner fixes four signals (2 Nov) and "no training" (8 Nov), and states on 9 Nov that RL is mimicked by graph weights; (4) the owner must defend this to management and asks for a paper and a pitch (9 to 10 Nov); (5) the novelty review finds the weighting formula already published thirteen times over, and finds the one question the design raises that nobody has measured; (6) a second round (12 Nov) confirms it is the only candidate one person can prove with frozen models and synthetic ground truth. No single file tells this chain end to end; each link is cited above.
- Inferred: the model swap is not hypothetical for this project. The plan of 8 Nov puts the agent runtime "behind a swappable interface" and leaves the production machine's model and endpoint for the owner to name (D1, D2), while the development machine's settings are `llm.model = claude-haiku-5-5` (`owner_assets_audit.md` section 5, citing `13_production_app/config/app_config.json`). So the model the tallies are earned under in development and the model on the production machine may differ. No file states which model the production machine will use.
- Inferred: the project already met a smaller version of the same question twice, with *firmware* in place of the *model*. The Oct 25 simulation has a firmware-change event and a metric `hit1_after_fw_change`; and `graph_learning.py` (15 Nov) caps evidence from another firmware (`STALE_CAP_RUNS = 2.0`, "chosen here, to be measured"). The 15 Nov measurement on the simulated drive found that stored history helped when it matched (better in 28 of 30) and hurt when stale or wrong ("worse in 25 of 30 and in 30 of 30 cases") — `13_production_app/docs/OPPORTUNITY_COVERAGE_2026-11-15.md`, section "After the second round of 15 November", rows S2 and S11. That is the project's own synthetic evidence that carried evidence can mislead when the thing underneath changes. It is about firmware and timing values, not about an LLM swap or verdict tallies; using it as an analogy is this note's reading.
- Inferred: the verdict vocabulary changed over time (three verdicts on 25 Oct; six action types in the older benchmark; four signals from 2 Nov), so none of the older simulations exercised exactly the four-signal mechanism now in `defect_graph.py`.

### Gaps
- No file records the owner's own words asking the model-upgrade question before 10 Nov. By the files, the question was raised by the research round, not by the owner; `research.html` says the most open gap "is not where the project started".
- The aggregate table of the Oct 25 simulation (`all_runs.csv`, summary) is not on disk in `12_feedback_graph_simulation/results/`; only seed-0 curves are. Whether the third seed finished is not recorded.
- `Approach_statement_2026-11-07.md` contains no sentence about model versions or upgrades (read in full).

---

## 4. What concrete assets exist today that the experiment would use?

### Takeaway
BUILT and usable: a seeded synthetic trace generator with ground truth at several layers (a 485-episode packet trace and 59 five-level scenario sets), a five-kind fault injector, a simulated drive that gives an objective pass/fail, the procedural-graph store with the four verdicts callable from plain Python, a model client that can already be pointed at three kinds of model service, and a large test suite. All measurements that exist were made on synthetic data; none is a measurement of Idea 1.

### Cited Findings

**Synthetic data with known ground truth (BUILT; synthetic by construction)**

| Asset | Count / size | Source |
|---|---|---|
| 485-error packet trace | 485 episodes; 2,052,490 rows; 113 columns; 394,165,136 bytes; capture span 1,841.7 s; seed 20261024; generated in 55.8 s; "SYNTHETIC ... NOT a real Teledyne LeCroy capture" | `03_main_csv_sidecars/synthetic_trace_manifest.json` |
| Its truth sidecars | `csv_row_scenario_index.csv`, `episode_key_rows.csv`, `scenario_coverage_matrix.csv`, `scenario_event_log.jsonl`, `validation_report.json`, `spec_conformance_summary.json` | `03_main_csv_sidecars/` (listing) |
| 485-case detection spec | 485 lines, one per atlas card | `owner_assets_audit.md` section 1 (citing `13_production_app/data/DEFECT_DETECTION_SPEC_485.jsonl`) |
| Generator code (packet level) | `generate_synthetic_pcie_trace.py`, `tracegen_core.py`, `tracegen_episodes_a.py`, `tracegen_episodes_b.py`, `tracegen_nvme.py`, validator and spec-conformance scripts | `02_generator_and_validator_code/` (listing, 2026-10-24/25) |
| Five-level scenario sets | 59 scenarios (S01 to S59), 2.2 GB; 3,387,398 packet rows; 15,060 commands; each set has five level files plus `truth_packet.csv`, `csv_row_scenario_index.csv`, `scenario_event_log.jsonl`, `scenario.json`; all 59 rebuilt in 678.2 s (8.4 to 24.5 s each) | `owner_assets_audit.md` section 1 (citing `13_production_app/samples/five_level/coverage.json` [2026-11-03]); folder listing shows 61 entries = 59 sets + two coverage files |
| Scenario mix | first shows at: NVMe command 32, NVMe transaction 14, packet 7, split 3, link 3; visibility: visible 36, partly 12, silent 11 | `owner_assets_audit.md` section 1 |
| Set builder options | `--only S01,S17,S41`, `--seed` (default 11), `--rules-only`, `--split-limit-ms` | `owner_assets_audit.md` section 1 (citing `13_production_app/data/generator/make_five_level_sets.py:93-100`) |
| Clean five-file recordings | 4 (`demo_225_commands`, `S08_interrupt_before_completion`, `S17_io_timeout_abort_reset`, `S27_lcrc_nak_replay`), 161 MB | `owner_assets_audit.md` section 1 (citing `13_production_app/samples/clean_five_files/`) |
| Single-file samples | `sample_T-42_L-21_C-16_seed11.csv`, `sample_T-42_L-21_M-039_seed12.csv`, `sample_nvme_commands_seed21.csv` with sidecar folders | `13_production_app/samples/` (listing) |
| Hand-over sample pack | "five small synthetic recordings for the tests and a first analysis" | `_github_copy_2026-11-15/README.md`, "What is here" |
| Fault injector | 5 fault kinds: never_completed, over_limit, slower, aborted, read_failed; returns `{command number: kind}` | `owner_assets_audit.md` section 1 (citing `13_production_app/tests/test_kpi_proof.py:84-100`) |

**The procedural graph and the four-verdict mechanism (BUILT; behaviour-tested; 0 live verdicts)**
- `SIGNALS = ("correct", "correct_with_edits", "wrong", "wrong_with_edits")`; `Z = 1.645` "one-sided 95 %: the lower bound used for the ranking". — `13_production_app/nvme_hier/defect_graph.py:35-37`
- Tables `dg_defect`, `dg_cause`, `dg_solution` (with free-text `producer`), `dg_revision`, `dg_occurrence` (device, firmware, admin), `dg_verdict` (signal, admin, device, firmware, edits), `dg_isolation`, `dg_occurrence_log`. — `defect_graph.py:39-58`
- Weights are the judgements: a solution is "judged correct s of n times (Beta(1, 1), the standard neutral start; ranked by the lower bound of the share judged correct, so one lucky judgement does not outrank a long good record)"; "rows are only ever added". — `defect_graph.py:12-16`
- An edited "correct" counts as a full success; `correct_with_edits` makes a new revision; `wrong_with_edits` makes a new solution with `parent` set; one judgement per (occurrence, admin) counts, the latest. — `owner_assets_audit.md` section 2 (citing `defect_graph.py:286-317, 423-475`)
- The store is callable without a server: `record_occurrence`, `add_solution`, `verdict`, `solutions`, `view`, exercised in `13_production_app/tests/test_defect_graph.py`. — `owner_assets_audit.md` section 2, Inferences; signatures at `defect_graph.py:240, 272, 498`
- Lab-run layer added 15 Nov: tables `dg_lab`, `dg_seq_timing`, `dg_timing`; "No row here changes one of the four verdict counts or the ranking by judgements"; four constants "CHOSEN HERE, TO BE MEASURED on a real bench". — `13_production_app/nvme_hier/graph_learning.py:1-45`
- Related test files on disk: `test_defect_graph.py` [2026-11-14], `test_graph_learning.py` [2026-11-15], `test_graph_loop.py` [2026-11-11], `test_kpi_proof.py` [2026-11-15]. — `13_production_app/tests/` (listing)
- Live content of the store on 15 Nov 2026 (read-only count made for these notes, database file dated 2026-11-15 11:28): `dg_defect` 1, `dg_cause` 2, `dg_solution` 1, `dg_revision` 1, `dg_occurrence` 1, **`dg_verdict` 0**, `dg_lab` 0, `dg_timing` 0, `dg_seq_timing` 0; older `signal` table 6 rows. — `13_production_app/db/hier_knowledge.sqlite` (counted here; matches the 12 Nov audit for the `dg_*` tables)
- Two older stores also exist: Beta counts with `EXPLORE = 0.15`, `DECAY = 0.02`, `CAP = 50.0`, `INHERIT = 0.7` (`13_production_app/nvme_hier/store.py:53-56`), and a stage-2 packet store with a Thompson exploration slot. — `owner_assets_audit.md` section 2

**An objective outcome without an engineer (BUILT; TESTED ON SYNTHETIC ONLY)**
- Simulated drive: "mechanics checked on a simulated drive, never fault reproduced". — `owner_assets_audit.md` section 3 (citing `13_production_app/nvme_hier/regress/f2t_nvme.py:1-22`)
- Saved proof run (file regenerated 2026-11-15 14:03): 10 seeds, 3 faults of each of 5 kinds; injected 300, found 300, recall 1.0, precision 1.0, 0 false alarms, baseline (status-column filter) recall 0.4; 22 test scripts: defect caught 22, reproduced 22, fixed firmware passes 22; recurrence: 22 known failures, 257 recurrences, 0 leaked; reading-effort proxy 0.934 minimum, "rows to read, not engineer hours"; 1,070 s total, 4.25 s per recording; limits line: "synthetic recordings with injected faults; simulated drive; KPI 1 is a proxy, not engineer hours". — `13_production_app/runs/kpi_proof/kpi_proof.json` (read here)
- Random-attack run: 179 recordings, 1,323 faults written, 39,759 commands, 0 failed, 0 crashed, 4 false alarms (0.1 per 1,000). — `13_production_app/runs/kpi_proof/fuzz_5000.json` [2026-11-15 12:35]
- Older packet engine: 437 of 485 (wire only), 483 of 485 (with simulated outside evidence), atlas card ranked first 387 of 483. — `10_defect_isolation_engine/REPORT_defect_isolation.md:11-33`

**Model plumbing (BUILT; only one kind of service ever used)**
- Two model clients. The isolation and test-design steps use a client chosen by `llm.backend`: `standin`, Anthropic (`cli | sdk | http | auto`), `openai-compat`, `ollama`. — `owner_assets_audit.md` section 5; `13_production_app/app/stage2_service.py:61-63` (the `openai-compat` and `ollama` branches, seen here)
- Answers are cached by `sha256(client name | prompt | schema)`, so a different model gets a different key. — `owner_assets_audit.md` section 5 (citing `13_production_app/stage2/llm_adapter.py:59-90`)
- Every agent call writes `prompt.txt` and `answer.json` into its run folder. — `owner_assets_audit.md` section 5 (citing `13_production_app/agentic/core.py:623-681`)
- "The model client for the isolation steps can already switch among three kinds of model service, although the logs show only one kind used so far." — `reports/One month top venue paper idea.md:78`

**Simulators for the reviewer-noise part (BUILT; simulated reviewers only)**
- Oct 25 simulation: 9 policies, admin noise 0 / 0.1 / 0.2, firmware change (see question 3). — `12_feedback_graph_simulation/simulate_feedback_graph.py`
- Older benchmark: 26 suites, 14 policies, 2,489,438 incidents each, "including reviewers who are wrong 10 or 25 percent of the time ... it is ready-made for the reviewer-noise test." — `reports/One month top venue paper idea.md:78`; `owner_assets_audit.md` section 3
- KPI harness learning check: three procedures at 0.55 / 0.70 / 0.90, 120 runs, 60 rounds, against a static first choice; uses the older store and two of the four signals; only pass/fail is saved. — `owner_assets_audit.md` section 3 (citing `13_production_app/tests/test_kpi_proof.py:299-322`)

**Test suite (BUILT; run on Linux, synthetic data)**
- 87 `test_*.py` files in `13_production_app/tests/`. — folder listing (counted here)
- "`run_tests.sh` held 60 offline groups after build 23. It now holds **66 offline groups**"; "All 66 offline groups passed" on 15 November, 06:32 to 07:17, Linux; after build 25 "every group touched (35 offline groups) passed; ... the whole suite was not run again". — `13_production_app/docs/CHANGES_2026-11-15_round2.md:1586, 2053-2057, 2184`
- Build 24 summary: "All 66 offline test groups pass on Linux; the 10 groups through a running application and the browser pass with the stand-in except six checks that need a real model's answer." — `_github_copy_2026-11-15/README.md`, "Build 24"

**Existing timing measurements usable for sizing (single runs)**
- One real-model flow on the S17 set: about 330 s of step time; the three isolation-side model steps 61.7 s; model was `anthropic:claude-haiku-5-5:low`. — `owner_assets_audit.md` section 6 (citing `13_production_app/db/agentic.sqlite`)
- One real-model run on 14 Nov on a disguised 608-row, 15-column file: 652 s and 24 model calls; 15 of 15 column meanings right; 11 of 15 with no checkable source. — `13_production_app/docs/OPPORTUNITY_COVERAGE_2026-11-15.md`, "What the one run with a real model proved, and what it did not"

### Inferences
- Inferred (taken from the audit, which marks it inferred): the smallest working version of the experiment is a script that (1) generates injected-fault recordings over several seeds, (2) lets model X propose solutions and test plans per defect, (3) scores each on the simulated drive and writes scripted verdicts into a fresh `dg_*` store, (4) repeats with model Y and measures whether X's ranking predicts Y's measured success. "Every part named exists except the script and the scripted reviewer." — `owner_assets_audit.md` section 4, Inferences
- Inferred: the assets fit Version B's design (project's own traces as primary ground) better than Version A's (public benchmarks AFTER, EvoMemBench, SkillShift-Bench as primary), because none of those public benchmarks is on disk (`owner_assets_audit.md` section 4, Gaps).
- Inferred: since the audit of 12 Nov, the number of available NVMe command rules changed twice (build 24 added 52 rule families, 38 runnable; build 25 keeps three under "NVMe command level errors" and moves the others to restorable "Deleted items" — `_github_copy_2026-11-15/README.md`, "Build 25", "Build 24"). The audit's "only two command rules feed the store" is therefore out of date in detail, but the underlying risk stands: "On the four synthetic samples the 38 runnable families found 16 rows in all" (`OPPORTUNITY_COVERAGE_2026-11-15.md`, second-round table, row S5).

### Gaps
- No file states how many distinct defect keys the 59 sets would produce with all rules on. — `owner_assets_audit.md` section 4, Gaps
- The older benchmark's files under `Database_Implmentation/claude_benchmark/` were not reopened for these notes; its figures are quoted from the 12 Nov audit.
- The KPI learning-curve numbers are not saved anywhere, only the pass rule. — `owner_assets_audit.md` section 3, Gaps

---

## 5. What is honestly not there yet?

### Takeaway
No experiment for Idea 1 has been run and no script for it exists. There is no real capture, no real drive, no real engineer verdict in the current store, no timed engineer, and the application has never run on Windows. Seven specific pieces of code or data named by the 12 Nov audit are missing, and by the files on disk today none of them has been added.

### Cited Findings

**No result for Idea 1**
- "**No such experiment has been run yet, and the effect could be close to zero**" — `reports/One month top venue paper idea.md:11`
- Candidate A verdict: "needs small to medium changes. No script runs it today." — `owner_assets_audit.md` section 4
- Checked here on 15 Nov: no file or script named for a swap, an upgrade experiment or a scripted reviewer exists in `13_production_app/`, `12_feedback_graph_simulation/` or `Database_Implmentation/` (file-name search; the only "upgrade" hits are an older, unrelated "Stage 2 LLM RAG upgrade" report). `defect_graph.py` still has no model field (search for `model_id`, `producer_model`, `llm_model`: no match); the `model` column added in `graph_learning.py` is the drive's model text, not the LLM.

**The seven missing pieces (Version B's list)**
- "There is no scripted reviewer. The memory store notes the producing model only as free text, not as a field that can be filtered on. No right-answer labels exist for causes or fixes, so the scripted verdict has to rest on the truth files and on the simulated drive's pass or fail. Token counts are not saved. Saved answers are reused by a cache that must be controlled when repeats are measured. A silent switch to a stand-in model must be detected and filtered out. And **by default only two command rules and five injected fault kinds feed the store, which gives too few distinct defects for sound statistics; this is the main technical risk and the first thing to widen**. The store also holds zero verdicts today." — `reports/One month top venue paper idea.md:80`
- Detail behind each: no automatic reviewer (verdicts enter only through the page route, `13_production_app/app/api/dg_api.py:136`); no model field (`defect_graph.py:39-58`); failed model call falls back to the stand-in silently (`13_production_app/nvme_hier/isolate.py:327-342`); no temperature or seed on the Anthropic paths; token use not persisted; no log of what was shown or with what probability. — `owner_assets_audit.md` sections 2, 4, 5, 7
- "No file shows the app having been run against a non-Anthropic model. The OpenAI-compatible and Ollama classes exist in code; no log of their use was found." — `owner_assets_audit.md` section 5, Gaps

**No real data, no real drive, no real reviewers**
- "**Be aware.** Every recording here is synthetic: made by the project's own generator, none from a real drive. The application was written and tested on Linux. **It has never run on Windows**; that is the next piece of work." — `_github_copy_2026-11-15/README.md`, opening
- "**Everything that is covered is covered on synthetic recordings and a simulated drive.** No row of a real capture of any tool was analysed. No generated test ran on a real drive. No engineer was timed." — `13_production_app/docs/OPPORTUNITY_COVERAGE_2026-11-15.md`, "The answer in six lines", item 2
- "**The verdict counts do not change: 0 of 16 covered, 14 partly covered, 2 not covered** (S2, faster reproduction in the lab; S11, learning from historical data)." — same section, item 1; repeated after the second round: "**No verdict changes: still 0 of 16 covered, 14 partly covered, 2 not covered (S2 and S11).**"
- "Nothing ran on Windows, on a real capture of any tool, or on a real drive." — same document, "The state of what was built on 14 and 15 November"
- Real engineer verdicts: 0 in the store the error page uses; 6 in the older store, "all 'correct', none with edits, from three admin names". — `owner_assets_audit.md` sections 2 and 7; recount here on 15 Nov gives the same `dg_verdict` 0 and `signal` 6
- Real data in the project is header names only; "The real export itself stayed on the customer's machine". — `owner_assets_audit.md` section 1
- "S9 ... Only the admin's judgements change the next result. Live store: 0 judgements" — `OPPORTUNITY_COVERAGE_2026-11-15.md`, table "The evidence and the gap of each statement, as measured on 14 November"
- Simulated reviewers cannot stand in for real ones: "A simulated reviewer cannot disagree with another reviewer, get tired, defer to automation or drift" — `research.html`, "Idea 3", "New evaluation it needs"; and for Idea 1 specifically "a small real-reviewer subset must confirm that verifier outcomes stand in fairly for human verdicts" — "Idea 1", "New evaluation it needs"
- "The strongest remedy is outside the laptop: three real engineers giving the four verdicts on a small set would change the picture more than any choice of venue. That needs the employer's consent, so the request belongs in week 1." — `reports/One month top venue paper idea.md:101`

**Known weaknesses in what was measured**
- "The generator writes five kinds of fault and the rules were written to find those five, so 300 of 300 shows that the rules agree with the generator. 'Zero leakage' is 0 of 257 by construction" — `OPPORTUNITY_COVERAGE_2026-11-15.md`, after the 14 November evidence table
- The learning check compares "against the worst option by construction" and "does not separate this design from ordinary methods". — `research.html`, "The current evidence shows the machinery runs, not that the design wins" (`.md:120`)
- "nothing measures whether it learns"; "the KPI harness and `/api/kpi` measure two older stores while the live new store holds **0 judgements**". — `reports/Procedural graph reinforcement and new causes.md:3`
- The search on the simulated drive: "with the drive's time hint it found 50 of 50 hidden triggers against 37 of 50 for a random choice; **without the hint 33 of 50 against 37 of 50, worse than random**". — `OPPORTUNITY_COVERAGE_2026-11-15.md`, 16-statement table, row S7
- "The four constants of the method were chosen, not measured. No model is trained, by the owner's rule: this mimics reinforcement learning with counts and a random draw, it is not a trained agent." — same document, second-round table, row S7
- One real-model run: "11 of 15 column meanings had no source the program can check. All 15 were right, on one easy file of 608 rows." "It was one run, one file"; "The person who answered the admin's cards knew the answer sheet." — same document, "The answer in six lines" item 6 and "What the one run with a real model proved, and what it did not"

**Unanswered non-technical questions**
- "whether the employer allows the paper, the generator and the column layout copied from a commercial analyzer to be published is unanswered, and it decides everything." — `reports/One month top venue paper idea.md:109`
- "No money figure and no token count per run was found in any file. Cost must be measured in a pilot before a budget is set." — `owner_assets_audit.md` section 6, Gaps
- "Three things remain unknown and are stated as such: the size of the effect, the money cost of the runs, and the employer's answer." — `reports/One month top venue paper idea.md:121`
- The file `api_key.txt` at the project root "and the settings under `~/.config/f2t/` must stay out of anything public." — `reports/One month top venue paper idea.md:74`

### Inferences
- Inferred: of Version B's week-1 tasks (12 to 18 November: clearance request, OpenReview account, dated predictions, model field, scripted reviewer, widened defect set, two-model pilot), the three that would leave a trace in the code (model field, scripted reviewer, pilot script) are not present on 15 Nov. The change records of 12 to 15 November (`13_production_app/docs/CHANGES_2026-11-12.md` through `CHANGES_2026-11-15_round2.md`) cover application builds 16 to 25. So by file evidence the paper schedule in Version B has not started. Whether the clearance request or the account were done cannot be told from files.
- Inferred: a manager should hear that the tallies whose survival is to be studied do not yet exist in real form (0 real verdicts in the current store). The study measures tallies produced by a scripted reviewer from ground truth; both write-ups say so, and both name the real-reviewer subset as the remedy.

### Gaps
- No file says whether the production (company) model endpoint offers more than one model, which the experiment needs. — `owner_assets_audit.md` section 5, Gaps
- No file records any decision by the employer or the customer on publication.
- This note did not read `13_production_app/deploy/REAL_ENVIRONMENT_WORK.md` or `deploy/WINDOWS.md`.

---

## 6. How does the idea connect to the official opportunity statement?

### Takeaway
No file links Idea 1 to the opportunity statement explicitly: `research.html` (10 Nov) predates the transcription of the statement (14 Nov) and never cites it. The link is nevertheless direct and can be argued from the files: the funded title is "RL-Powered Field-to-Test Loop", the team delivers the "RL" as verdict tallies on a graph with a rented LLM beside it, and Idea 1 measures whether that delivered learning survives a change of the LLM. It serves the learning and knowledge-base statements (S9, S10, S11, with S7 and S12 as context). It does not raise any of the 16 coverage verdicts.

### Cited Findings
- Project title: "RL-Powered Field-to-Test Loop: An Integrated Flow for Closed-Loop Quality Control". — `13_production_app/docs/OPPORTUNITY_STATEMENT.md:6` (transcribed from four photographs on 2026-11-14)
- S7: "A reinforcement-learning (RL) agent takes the LLM scenario as its seed and iteratively optimizes command sequences and timing parameters, guided by a reward function tied to reproducing the failure signature." — `OPPORTUNITY_STATEMENT.md:53`
- S9: "A self-optimizing analysis framework closes the loop between failure detection and reproduction." — line 55
- S10: "Validated results (PCIe traces, external workloads) are archived as a knowledge base." — line 56
- S11: "RL is applied to historical data to dynamically optimize test parameters and workload sequences." — line 57
- S12: "An integrated validation suite plus an AI pipeline (LLM seeds the baseline, then the RL agent optimizes the sequence)". — line 58
- S6: "A large language model (LLM) creates an initial baseline test scenario that mimics the observed failure." — line 52
- How the project delivers the "RL": "Owner, 2026-11-09: reinforcement learning is MIMICKED on procedural graphs: weights on nodes and edges change from the four signals, no model weights, no training infrastructure." — `.../memory/graph-loop-and-kpi-proof-2026-11-09.md`; "No model is trained, by the owner's rule: this mimics reinforcement learning with counts and a random draw, it is not a trained agent." — `OPPORTUNITY_COVERAGE_2026-11-15.md`, second-round table, row S7
- Current state of S9: "The loop closes only with the tree, and only the admin's judgements change the next result"; after round 2: "The lab counts change only what the search tries first; the order of the solutions shown still changes only with the admins' judgements." — `OPPORTUNITY_COVERAGE_2026-11-15.md`, rows S9 in both tables
- Current state of S11: "Not covered"; "**It would change to 'partly' only after a run on real data, and it stays 'not covered' here for that reason.**" — same document, second-round table, row S11
- Current state of S10: "65 solutions and 18 procedures stored"; "Two separate stores". — same document, 14 November evidence table, row S10
- The coverage document's rule: "a verdict changes only when the part is tested as a whole and, where the statement needs it, on real data." — same document, "The answer in six lines", item 5
- What would close the statement's gaps, in the document's order: a real drive behind the bench hook; one real LeCroy five-file capture with a confirmed defect; one real export of another tool; the second half for any CSV; sources for meanings; timed engineers; the owner's answers about the validation suite. — same document, "What would close each gap"
- The first research report already framed the graph as the stand-in for the statement's RL agent: "Bandit-weighted case memory can replace the RL agent"; "As written, though, the design covers only half of the 'RL-Powered Field-to-Test Loop'." — `11_failure_reproduction_research/RL style failure reproduction without training - research report.md:1-5`
- The design leaves the model swappable and unnamed on the production machine. — `Approach_plan_for_approval_2026-11-08.md:187-188` (D1, D2)

### Inferences
- Inferred mapping (no file states it):

| Statement | How Idea 1 serves it | Honest limit |
|---|---|---|
| S9 self-optimizing closed loop | The loop "self-optimizes" only through admins' judgements stored as tallies. Idea 1 tests whether that optimisation is durable when the LLM in the loop changes. | Does not test the loop on a real capture or drive. |
| S10 knowledge base of validated results | The tallies are the part of the knowledge base that says how far each stored cause/solution is trusted. Idea 1 gives a rule for keeping, wiping or discounting them at a model change. | The knowledge base holds 0 real verdicts today. |
| S11 RL applied to historical data | "Historical data" in this design is the verdict and lab-run history on the graph. Idea 1 asks under what condition history stays usable; the 15 Nov simulated-drive result already shows stale history can hurt. | S11 stays "not covered" until a run on real data. |
| S7 RL agent / S12 AI pipeline "LLM → RL agent" | The statement puts an LLM and a learner in series. Idea 1 measures the coupling between them: whether the learner's state is tied to one LLM version. | The statement's RL agent optimises sequences and timing; the tallies studied rank stored solutions. |
| S6 LLM writes the baseline | The LLM is a replaceable component (D1: "behind a swappable interface"). | — |

- Inferred: the strongest "funded work, not a side project" argument available from the files is operational, not academic. The statement commits the team to a learning loop and a knowledge base; the team chose to deliver them without training; the model on the production machine is not the development model and will be replaced over the life of the tool; so a keep/wipe/discount rule for the knowledge base at a model change is a deliverable the deployment needs anyway. `research.html` says the same in pitch form: "Whatever the result, we get a tested rule for every future model upgrade."
- Inferred caveat a manager will raise: the study moves none of the 16 verdicts, by the coverage document's own rule, and the top gap-closers (real drive, real capture, timed engineers) compete for the same people. `research.html` answers part of this ("It uses compute more than engineer time"), and the scripted reviewer and wider defect set it requires are also useful to the application's own KPI evidence (the audit notes "Nothing measures the `dg_*` loop"). That second point is this note's reading.
- Inferred: the paper's five "design rules [that] cost little" (hide the weight at review time; keep reviewer identifiers; filter deprecated procedures at retrieval; log selection probabilities; assert that weights actually move — `research.html`, "First paper", `.md:257`) are product improvements to S9/S10 independent of any publication.

### Gaps
- No document maps any research idea to S1 to S16. The mapping above is new in these notes.
- The statement's header ("the names of the people and the group") was left out of the transcription, and "Whether the statement continues below [the Productivity line] cannot be seen" (`OPPORTUNITY_STATEMENT.md:8, 40-41`), so funding owner, budget and any publication expectation in the statement are unknown from files.

---

## 7. What plan, timeline, cost and resources do the existing documents already propose?

### Takeaway
Two plans exist and they do not agree. `research.html` (10 Nov) proposes about five months with a half-time engineer, two model pairs, public benchmarks first and a go/no-go at week 8. The 12 Nov report proposes a single-author, laptop-scale, ten-week plan to an ICML submission on 22 January 2027 with four models and twelve swaps on the project's own traces plus one public task, with a result at the one-month mark. Neither has a money figure. All of it is PLANNED.

### Cited Findings

**The two plans side by side**

| Item | Version A: `research.html`, 10 Nov 2026 | Version B: `reports/One month top venue paper idea.md`, 12 Nov 2026 |
|---|---|---|
| Duration | "a study of about five months"; weeks 1 to 16, submit "at about week 18" (weeks count from 10 November 2026) | "the honest schedule to a top-venue submission is ten weeks, with one month as the checkpoint for the result and not for the submission" (line 95) |
| Checkpoints | "The go/no-go point is week 8" (computed here: about 5 January 2027) | Week 1 check (enough distinct defects, affordable price per case, else fallback); one-month mark about 12 December 2026: "result, draft, and, if cleared, a preprint" |
| Models | "at least two real pairs of model versions, one same-family upgrade and one cross-family" | "at least four frozen models from at least two makers, one of them with public model files ... and every ordered pair of them, which is twelve swaps" (line 72) |
| Ground | Public benchmarks "AFTER (382 enterprise tasks), the procedural group in EvoMemBench and SkillShift-Bench, with the project's PCIe and NVMe procedures as a clearly labelled case study" | The project's synthetic five-level traces with a scripted reviewer, plus "one public task besides the PCIe and NVMe traces", preferably one of MemRL's four (weeks 5 and 6) |
| Closest rival named | Goyal and Ray (preprint) | MemRL, NeurIPS 2026 poster ("the nearest accepted paper"); Goyal and Ray second |
| Venue | TMLR rolling; or NeurIPS 2027 main / Evaluations & Datasets, or EMNLP 2027 via ARR, about May 2027 (projection). "ACL 2027 via ARR on 4 Jan 2027 ... I would not aim for it." | "ICML 2027 first, then TMLR": abstract 14 January, paper 22 January 2027; first-stage notice 23 February; decisions 3 May 2027. A clean "nothing changes" result goes straight to TMLR. |
| People | One engineer about half time for 5 months; two senior engineers 1 to 2 hours a week each; one legal review pass ("my estimates, not from the notes") | One author ("a first paper by one author"); employer clearance asked in writing in week 1; "three real engineers giving the four verdicts on a small set" if the employer consents |
| Compute and cost | "LLM and compute budget: To be sized after the week-8 run" | "about one minute per defect with a small model, so 100 defects on 6 models is about ten hours run one after another; that figure is stretched from a single run, and no money figure exists anywhere, so a priced pilot comes first" (line 80) |
| Statistics | Confidence intervals; several seeds | "at least five different orders of the case stream, the same cases compared under each rule, 95 percent confidence ranges, and a correction for testing twelve pairs"; sample size "about 93 judged cases per rule when the cases differ, or about 57 to 85 when the same cases are compared" (lines 72, 80) |
| Stated odds | "No idea here can be promised acceptance at any venue" | "about one chance in eight to ten for a first paper by one author, as a group average and not a forecast" (line 3); TMLR accepted 51 percent of submissions in 2024 (line 64) |
| Fallback | Shorter "keep everything" paper for TMLR; stop or re-scope if the novelty sweep finds a direct hit or the weights "carry too little signal to study" | "a public benchmark built from the five-level traces, aimed at the NeurIPS 2027 call" (lines 3, 113-115) |

Sources: `research.html`, "Idea 1" paragraphs "How to do it", "When", "Risk", sections "First paper" and "Pitch for the manager" (`.md:166-172, 253-270`); `reports/One month top venue paper idea.md:3, 39-66, 68-95, 113-115`.

**Version A week plan** — "Weeks 1 to 2: rerun the novelty sweep and read the items listed for this idea at the end of the report. Weeks 3 to 8: one model pair, one benchmark, first predictiveness result, then a go/no-go decision. Weeks 9 to 16: second pair, discount comparison, reviewer subset, writing. Submit to TMLR, rolling (ANNOUNCED), at about week 18". — `research.html`, "Idea 1", "When" (`.md:170`)

**Version B week plan (table at lines 84-93)**

| Week | Dates | Work | Check |
|---|---|---|---|
| 1 | 12 to 18 Nov | Written clearance request to the employer (paper, code and generator, any real trace); OpenReview account; write and date the predictions; add the model field; build the scripted reviewer; widen the set of distinct defects; pilot with two models from two makers on about 50 cases (filing agreement, price per case) | Enough distinct defects and an affordable price per case; if not, switch to the fallback |
| 2 | 19 to 25 Nov | One memory per model for four models over five stream orders; no-memory and similarity-only comparisons; save token counts; filter stand-in answers; control the cache | Four memories with counts |
| 3 | 26 Nov to 2 Dec | All twelve swaps under the four rules; main table and recovery curves | The headline number exists |
| 4 | 3 to 9 Dec | Two switched-off tests; filing agreement against the drop; full first draft | One-month mark: result, draft, preprint by about 12 December if cleared |
| 5 and 6 | 10 to 23 Dec | Scored memory on the public task, keep against wipe; 16 December: check ICLR 2027 decisions | Result holds or fails on a second ground |
| 7 and 8 | 24 Dec to 6 Jan | More repeats; cost table; release folder; references checked by hand | Release complete |
| 9 | 7 to 13 Jan | Complete draft read by outsiders | Abstract sent by 14 January |
| 10 | 14 to 22 Jan | Final checks only | Paper sent by 22 January 2027 |

**Design choices that hold cost down**
- "wherever a model's answer does not depend on the tallies, it is computed once per model and case and saved, and the four rules are then compared by replaying the saved answers." — `reports/One month top venue paper idea.md:80`
- "the predictions are written down and dated before the first run, and the ones that fail are printed too." — line 72
- Machine-time facts for sizing: 59 sets rebuilt in 678.2 s; KPI pipeline 4.25 s per recording without a model (regenerated file) ; whole 32-suite test run about 86 minutes as of 11 Nov. — `owner_assets_audit.md` sections 1 and 6; `13_production_app/runs/kpi_proof/kpi_proof.json`

**Reviewer demands the plan is built to meet**
- "Reviewers will demand at least four models from two makers, a wipe-and-restart comparison, one public task besides the PCIe and NVMe traces, repeated runs with error ranges, a cost table and a full release." — `reports/One month top venue paper idea.md:3`
- Five objections with prepared answers: "MemRL already moved a scored memory across three models, and it worked"; "One niche domain, made-up traces, and a scripted reviewer in place of people"; "In your system the tallies describe the device, so of course they carry over"; "Too few cases, one run, no error ranges"; "The discount rule is old statistics, and closed models cannot be re-run." — lines 99-107
- Version A's expected objections: "an upgrade is just one large decay step", "verifier outcomes are not human verdicts", "empirical only". — `research.html`, "Idea 1", "Risk"

**Parallel track both versions recommend**
- "Start with idea 1, and start collecting idea 3's reviewer data alongside it." — `research.html`, "Five ideas, most open gap first"
- "In parallel, two senior engineers double-review a small stream of outputs, which gives us our first measurement of how consistent our reviewers are, and data no competitor can copy quickly." — `research.html`, "Pitch for the manager"
- "The two actions that most change the odds cost no computing time. One is the written request for clearance, sent on day one. The other is asking for three engineers to give real verdicts on a small set" — `reports/One month top venue paper idea.md:119`

### Inferences
- Inferred: the two plans describe one idea at two sizes. Version A is the "team" version (half-time engineer, five months, public benchmarks, journal or May 2027 conference). Version B is the "one person, own laptop, own traces" version aimed at ICML in January 2027. A pitch must choose one or present B as phase 1 (result and preprint in one month) and A as the full study; presenting numbers from both without saying so would mix "five months" with "ten weeks".
- Inferred: Version B's dates have slipped. Today is 15 November 2026, day 4 of its week 1, and the code-side week-1 items are not on disk (question 5). The ICML dates are fixed (abstract 14 January, paper 22 January 2027), so each week of delay comes out of weeks 5 to 8 (public task, repeats).
- Inferred: the resources a manager is being asked for differ sharply between the versions. Version A's ask is mainly people (about 0.5 engineer for 5 months plus 2 to 4 senior-engineer hours a week, computed here from the ask table). Version B's ask is mainly permissions: written clearance, model access to at least four models from two makers, and optionally three engineers for a small verdict set.
- Inferred: neither plan budgets time for the missing engineering listed in question 5 beyond Version B's week 1.

### Gaps
- No money cost exists in any file; both versions defer it to a pilot.
- No file says which four models would be used or whether the company's model service provides them.
- No file names a co-author, a second reader or a statistician for Idea 1 (the statistician is named only for Idea 5).
- Whether ICML 2027 dates and rules are as quoted was not rechecked (web search was out of scope); the report itself notes "The 2027 call for papers is not yet posted" (line 41).
