# Venue path, acceptance rates, precedent and odds for the model-swap measurement paper (checked 15 November 2026)

How to read these notes:

- "Verified" means the page was opened on 15 November 2026 and the text was read through a page reader. "Earlier pass" means the fact comes from the 12 November 2026 notes and was not re-opened. "Tracker" means an unofficial deadline site.
- "Derived" means a number I computed from sourced numbers; the arithmetic and assumptions are shown.
- Days are counted from 15 November 2026. AoE = Anywhere on Earth.
- Three official lists of accepted papers were downloaded and counted locally (NeurIPS 2026, ICML 2026, ICLR 2026). Counts from them are by unique title and include every track on the list.
- OpenReview pages could not be opened (browser check on both the forum page and the API), so no review text was read in this pass.

## 1. Calendar: every suitable venue with a deadline from 15 November 2026 to about June 2027

### Takeaway

ICML 2027 is confirmed from its now-posted call: abstract 14 January, paper 22 January 2027, Rio de Janeiro, attendance optional. It is still the only NeurIPS-level main-track deadline before May 2027. The other doors that are open and fit a measurement paper are TMLR (rolling), ICLR 2027 workshops (about 1 February 2027), and NeurIPS 2027 (about May 2027, dates not posted); the storage, test and industry venues are either closed, need a deployed system, or have no 2027 call yet.

### Cited Findings

**ICML 2027 (the earlier pass's main target) — confirmed, with new details**

- Dates, verified: submission site opens 8 January 2027; abstract 14 January 2027 AoE; full paper 22 January 2027 AoE; "First-Stage Rejection Notification" 23 February 2027; final decisions 3 May 2027; Expo Sat 31 July, tutorials Sun 1 August, main conference Mon 2 to Wed 4 August, workshops Thu 5 and Fri 6 August 2027. — [ICML 2027 Dates](https://icml.cc/Conferences/2027/Dates)
- The call for papers is now posted (the 12 November pass found only "will be posted here soon"). Location: Rio de Janeiro, Brazil, 31 July to 6 August 2027. Length: "8 pages for the main paper, with unlimited pages for references, the impact statement, and appendices." — [ICML 2027 Call for Papers](https://icml.cc/Conferences/2027/CallForPapers)
- Days left: 60 to the abstract, 68 to the paper (derived from the dates above).
- The position-paper call is still "coming soon", the Peer Review FAQ says only that it "will be published with the Call for Papers", and the call for workshops says it "will be posted here soon". — [ICML 2027 Call for Papers](https://icml.cc/Conferences/2027/CallForPapers); [ICML 2027 Peer Review FAQ](https://icml.cc/Conferences/2027/PeerReviewFAQ); [ICML 2027 Call for Workshops](https://icml.cc/Conferences/2027/CallForWorkshops)

**Calendar table (15 November 2026 to about June 2027)**

| Venue and track | Deadline | Days left | Status of the date | Fit for this paper | Source |
|---|---|---|---|---|---|
| AAAI-27 workshops | 20 Nov 2026 | 5 | Official (earlier pass) | No result exists yet. Skip | [AAAI-27 workshop program](https://aaai.org/conference/aaai/aaai-27/aaai-27-workshop-program/) |
| AGENT 2027 workshop at ICSE 2027 (agent memory, benchmarking, AgentOps and incident response are listed topics) | 20 Nov 2026 (extended from 13 Nov) | 5 | Official, verified | Too soon, and "Accepted workshop papers will be published by IEEE", so it is archival and would block a later ICML or TMLR submission of the same work | [AGENT 2027](https://conf.researchr.org/home/icse-2027/agent-2027) |
| DATE 2027 Late Breaking Results | 29 Nov 2026 | 14 | Official (earlier pass) | Two pages, in person in Dresden. Domain note only | [DATE 2027 call](https://date27.date-conference.com/call-for-papers) |
| TMLR | Rolling | open | Official, verified | Best fit and best odds (sections 2 and 6). No notice of a December 2026 pause yet; last year's pause (2 Dec 2025 to 5 Jan 2026) was announced on 15 Nov 2025 | [TMLR news](https://jmlr.org/tmlr/news/) |
| IJCAI 2027 main track (Kyoto 7–13 Aug; Hengqin 15–17 Aug) | Abstract 4 Jan, paper 11 Jan 2027, 23:59 AoE; summary reject 25 Feb; decision 21 Apr 2027 | 50 / 57 | Official, verified (call now online) | Possible but lower rate, strict LLM rule, in-person only | [IJCAI 2027 main-track call](https://2027.ijcai.org/ijcai-2027-call-for-papers-main-track/) |
| ACL 2027 via ACL Rolling Review (Kyoto, 17–22 Aug 2027; main conference 20–22 Aug) | ARR 4 Jan 2027; commitment and notification "TBA" | 50 | Official, verified | Weak topic fit; review not guaranteed for an author with no qualified service contributor (section 3) | [ACL 2027](https://2027.aclweb.org/) |
| ACM SIGOPS ATC 2027 (Rennes, 28 Jun–1 Jul 2027) | 19 Jan 2027 AoE, "No extensions"; notification 27 Apr 2027 | 65 | Official, verified (new; the earlier pass had only conflicting unofficial dates) | Systems venue with no experience or industry track. A study of agent memory is not a systems contribution. Poor fit | [ATC 2027](https://atc.sigops.org/2027/) |
| **ICML 2027 main track** | **Abstract 14 Jan, paper 22 Jan 2027 AoE** | **60 / 68** | **Official, verified** | **First top-venue attempt** | [ICML 2027 Dates](https://icml.cc/Conferences/2027/Dates) |
| FSE 2027 Industry Papers (Shenzhen, 12–16 Jul 2027) | 23 Jan 2027 AoE; notification 20 Mar 2027 | 69 | Official, verified | The one industry track that is open and does not demand deployment. Clashes with ICML (same paper cannot go to both) | [FSE 2027 Industry Papers](https://conf.researchr.org/track/fse-2027/fse-2027-industry-papers) |
| ICLR 2027 workshops | "Suggested Submission Deadline for Workshop Contributions: 1 Feb 2027"; accepted-paper notices no later than 26 Feb 2027; list of workshops due 29 Nov 2026 | about 78 | Official, verified | Feedback and a public date. Not a top-venue paper | [ICLR 2027 Workshop Guidelines](https://iclr.cc/Conferences/2027/WorkshopGuidelines) |
| KDD 2027 cycle 2, Research and Applied Data Science tracks (San Jose, 1–5 Aug 2027) | Not posted. The research call speaks only of a "February 2027 deadline", the applied call of a "Jan/Feb 2027 deadline" | — | Estimate: early February 2027 | Research track possible; applied track shut to this paper (section 3) | [KDD 2027 research call](https://kdd2027.kdd.org/research-track-call-for-papers/); [KDD 2027 applied call](https://kdd2027.kdd.org/applied-data-science-ads-track-call-for-papers/); [KDD 2027](https://kdd2027.kdd.org/) |
| UAI 2027 | Not posted; the 2027 site address returns "not found" | — | Estimate: mid to late February 2027 (UAI 2026 was 25 Feb 2026; one tracker projects 12 Feb 2027) | Weak fit (the paper is not about uncertainty methods) | [UAI 2026 call](https://auai.org/uai2026/call_for_papers); [tracker](https://www.opencurious.com/ai-conference-deadlines/uai-2027) |
| IEEE International Test Conference 2027 (San Antonio, 10–15 Oct 2027) | "paper submission title and abstracts due March 5, 2027"; full-paper date not on the page | 110 | Official, verified | A home for the storage-test story as an industrial case, not for the general measurement claim | [ITC](https://itctestweek.org/) |
| EASE 2027 Industry Papers | 1 Mar 2027 AoE | 106 | Official listing seen only in a search result | Minor software-engineering venue; listed for completeness | [EASE 2027 industry papers](https://conf.researchr.org/track/ease-2027/ease-2027-industry-papers) |
| COLM 2027 | Not posted; the site shows only COLM 2026 (6–9 Oct 2026, San Francisco) | — | Estimate: late March 2027 (COLM 2026: abstract 26 Mar, paper 31 Mar 2026) | Reasonable fit (language-model agents); no dates to plan on | [COLM](https://colm.cc/); [COLM 2026 announcement](https://groups.google.com/g/colm-announcements/c/2oPngEGMeMc) |
| NeurIPS 2027, main and Evaluations and Datasets tracks | Not posted. The future-meetings page says only "2027 -- Europe" | — | Estimate: early to mid May 2027 (2026: abstract 4 May, paper 6 May; trackers guess 14/21 May or 16 May 2027) | Natural second top-venue attempt | [NeurIPS future meetings](https://neurips.cc/Conferences/FutureMeetings); [NeurIPS 2026 dates](https://neurips.cc/Conferences/2026/Dates); [tracker](https://www.opencurious.com/ai-conference-deadlines/neurips-2027) |
| ICML 2027 workshops (5–6 Aug 2027) | Call not posted | — | Estimate: ICML 2026 workshop proposals were due 13 Feb 2026 with notices on 20 Mar 2026, so paper deadlines fall after late March | Feedback; useful if ICML main rejects | [ICML 2027 Call for Workshops](https://icml.cc/Conferences/2027/CallForWorkshops); [ICML 2026 Call for Workshops](https://icml.cc/Conferences/2026/CallForWorkshops) |
| EMNLP 2027 via ARR | Not on the ARR dates page | — | Tracker only: ARR about 28 May 2027, tentative; conference "tentatively" early November 2027 in Mexico or Central America, per a search summary of the joint call for workshops | Weak topic fit | [ARR dates](https://aclrollingreview.org/dates); [joint call for workshops 2027](https://www.aclweb.org/portal/content/joint-call-workshops-proposals-2027) |
| HotStorage 2027 | No call | — | Estimate: June 2027 (HotStorage '26 deadline was 12 Jun 2026, extended; held 28–29 Sep 2026 in Prague) | Short discussion papers on storage; not a home for an agent-memory measurement | [HotStorage '26 call](https://www.sigarch.org/call-contributions/hotstorage-sosp-2026/) |
| SYSTOR 2027 | No call | — | Estimate: May 2027 (SYSTOR 2026 deadline was 21 May 2026) | Same remark | [SYSTOR 2026 call](https://www.systor.org/2026/cfp/) |
| FAST '28 (Seattle, 28 Feb–1 Mar 2028) | No call | — | Estimate: spring deadline about mid-March 2027 (FAST '27 used 17 Mar and 15 Sep 2026) | Storage systems research; the paper is not one | [FAST '27 call](https://www.usenix.org/conference/fast27/call-for-papers); [USENIX conferences](https://www.usenix.org/conferences?page=1) |

**Closed (confirmed)**

- AAAI-27 main track: abstracts 21 July 2026, papers 28 July 2026; final notices 30 November 2026; Montréal, 16–23 February 2027. — [AAAI-27](https://aaai.org/conference/aaai/aaai-27/)
- KDD 2027 cycle 1: abstract 19 July, paper 26 July 2026, notification 14 November 2026. — [KDD 2027 research call](https://kdd2027.kdd.org/research-track-call-for-papers/)
- MLSys 2027: 30 October 2026, one deadline for both the Research Track and the Industrial Track (search summary of trackers; the earlier pass verified the date on the official page). — [MLSys 2027 dates](https://mlsys.org/Conferences/2027/Dates); [tracker](https://mldeadlines.com/conference/mlsys-2027/)
- ICSE 2027 Software Engineering in Practice: 23 October 2026 (search summary of the official track page). — [ICSE 2027 SEIP](https://conf.researchr.org/track/icse-2027/icse-2027-seip)
- EACL 2027 Industry Track: 11 September 2026. — [EACL 2027 Industry Track](https://2027.eacl.org/calls/industry/)
- ARR: the only cycle on the dates page is 12 October 2026 (NAACL 2027 and COLING 2027; commitment 23 December 2026). ACL 2027 is shown as "January, 2027". No 2027 cycle list and no EMNLP 2027 row. — [ARR dates](https://aclrollingreview.org/dates)
- Earlier pass, not re-opened: NeurIPS 2026 (6 May 2026), ICLR 2027 main (25 September 2026), FAST '27 (15 September 2026), DATE 2027 research (20 September 2026), DAC 2027 research (abstract 11 November 2026), SIGMOD 2027 Industrial Track (24 November 2026, still open for nine days but judged a poor fit). — [NeurIPS 2026 dates](https://neurips.cc/Conferences/2026/Dates); [ICLR 2027 dates](https://iclr.cc/Conferences/2027/Dates); [FAST '27 call](https://www.usenix.org/conference/fast27/call-for-papers); [DATE 2027 call](https://date27.date-conference.com/call-for-papers); [DAC 2027](https://dac.com/2027/program/research-manuscript-submissions); [SIGMOD 2027 industrial call](https://2027.sigmodconf.hosting.acm.org/calls_industrial_track_papers.shtml)

**Which venues have an industry or application track that welcomes a single-domain industrial case**

- FSE 2027 Industry Papers: the work must be "applied in an industrial context or" have its relevance to such a context "clearly identified and articulated". Criteria: industrial application, improvement over the state of practice, clarity of lessons learned, generality of results. Long papers 10 pages plus 2 for references. Review "can be double-blind" but need not be. Papers go to the companion proceedings. No industry author is required. — [FSE 2027 Industry Papers](https://conf.researchr.org/track/fse-2027/fse-2027-industry-papers)
- KDD 2027 Applied Data Science: single-blind; a submission without post-launch numbers "will be desk-rejected without review", and so are "Applications that are tested offline on real-world data, but have not been deployed live to users". — [KDD 2027 applied call](https://kdd2027.kdd.org/applied-data-science-ads-track-call-for-papers/)
- ICML 2027 has no industry track but has an "Application-driven" contribution type: "The use case should substantially inform the problem formulation, methodology, data, constraints." and "Merely applying an existing machine learning method to a new dataset would generally not be sufficient." — [ICML 2027 Contribution Types](https://icml.cc/Conferences/2027/ContributionTypes)
- ITC: the 2025 call had an industrial case-study track and short "Industrial Practices" papers (3 to 5 pages); the 2027 call was not read. This comes from a search summary. — [ITC 2025 call](https://itctestweek.org/wp-content/uploads/2024/11/ITC_2025_CFP_extended.pdf)
- ATC 2027 lists no operational or experience track. — [ATC 2027](https://atc.sigops.org/2027/)
- DMLR looks dormant: its newest news item is dated 27 July 2024 and it states no time to decision. — [DMLR](https://data.mlr.press/)

### Inferences

- The earlier calendar holds. Two things changed in three days: the ICML 2027 call is now posted, and ATC 2027 has an official date.
- Five January deadlines compete for the same manuscript: IJCAI (11 Jan), ATC (19 Jan), ICML (22 Jan), FSE Industry (23 Jan) and ARR (4 Jan). Every one forbids parallel submission, so only one can be used. ICML is the only one that is both top-level and a topic fit.
- No venue in the list both welcomes a single-domain industrial case and accepts work that has never been deployed, except FSE Industry Papers, and that track would publish the work as a companion-proceedings paper about lessons for software practice, not as a machine-learning result.
- The storage and test venues (FAST, HotStorage, SYSTOR, ATC, DATE, DAC, ITC) are homes for a later paper about the PCIe/NVMe tool itself. For the general question "do stored verdict tallies survive a model swap" their reviewers are the wrong audience.
- If ICML rejects on 3 May 2027 and NeurIPS 2027 keeps its 2026 dates (4 and 6 May), there would be one to three days to turn the paper round. A first-stage rejection on 23 February leaves ample time. The NeurIPS 2027 dates decide this and are not posted.
- An archival workshop (for example AGENT 2027, published by IEEE) should be avoided before the main submission. ICML allows only workshops "without published proceedings".

### Gaps

- NeurIPS 2027, COLM 2027, UAI 2027, KDD 2027 cycle 2, EMNLP 2027, HotStorage 2027, SYSTOR 2027 and FAST '28: no official dates. All values above are estimates from last year or from trackers.
- IEEE VLSI Test Symposium 2027 was not checked. The ITC 2027 call PDF (full-paper date, tracks) was not read.
- The list of accepted ICLR 2027 workshops appears on 29 November 2026; no workshop can be named yet. ICML 2027 workshop dates are not posted.
- MLSys 2027 conference dates differ between the earlier pass (22–24 June 2027) and a tracker (21–25 June 2027, Bellevue). The deadline is past either way.
- Whether TMLR will pause new submissions in December 2026 is not announced.

## 2. Acceptance rates for 2025 and 2026, and data by number of authors, industry authors and first-time authors

### Takeaway

The "26.6 percent" for ICML 2026 holds in every source found, though the official post itself could not be opened and two sources differ on the count of accepted papers. The "about half the usual rate" claim is real but was slightly misquoted: the ICLR chairs wrote that papers with no reviewer-qualified author were accepted at about half the rate of papers that had an author on the programme committee, not half the average rate; the group odds stay near one in nine, and for a sole first-time author the ICLR 2026 data give an upper bound of about one in nine.

### Cited Findings

**Overall rates**

| Venue | Year | Rate | Kind of source | Source |
|---|---|---|---|---|
| ICML main | 2026 | 26.6% (6,352 of 23,918) | Secondary pages that agree with each other; the official X post was not opened in this pass | [RIKEN AIP](https://aip.riken.jp/news/icml2026/); [WASP](https://wasp-sweden.org/strong-wasp-presence-at-icml-2026/); [ICML on X](https://x.com/icmlconf/status/2049919242862985559) |
| ICML main | 2025 | 26.9% (12,107 submitted) | Secondary | [RIKEN AIP](https://aip.riken.jp/news/icml2026/) |
| NeurIPS main | 2025 | 24.52% (5,290 of 21,575) | Official blog | [NeurIPS blog](https://blog.neurips.cc/2025/09/30/reflections-on-the-2025-review-process-from-the-program-committee-chairs/) |
| NeurIPS main | 2026 | 25.7% (7,900 of 30,709) | Secondary only (earlier pass) | [stats site](https://csconfstats.xoveexu.com/conferences/neurips/2026/) |
| NeurIPS Datasets and Benchmarks | 2024 | 25.3% (main track that year 25.8%) | Official blog | [NeurIPS blog](https://blog.neurips.cc/2025/09/30/reflecting-on-the-2025-review-process-from-the-datasets-and-benchmarks-chairs/) |
| ICLR main | 2026 | 27.4% (5,355 of 19,525), official; Paper Copilot shows 26.95% (5,340 of 19,814) | Official blog (earlier pass); aggregator | [ICLR blog](https://blog.iclr.cc/?p=1116); [Paper Copilot](https://papercopilot.com/statistics/iclr-statistics/iclr-2026-statistics/) |
| IJCAI main | 2026 / 2025 | 13.6% / 19.0% | Tracker (earlier pass) | [stats site](https://csconfstats.xoveexu.com/conferences/ijcai/2026/) |
| KDD research / applied | 2025 | 18.68% / 19.00% | Community database (earlier pass) | [OpenAccept KDD](https://openaccept.org/c/dm/kdd/) |
| TMLR | 2024 | 69% of submissions not withdrawn or desk-rejected; 51% of all submissions (2023: 66% and 50%) | Official annual report, verified | [2024 TMLR Annual Report](https://docs.google.com/document/d/1_lUT03lHtwLKnFaN_RYjxnG8MX5DGcFAbfUQY6YxQsI/mobilebasic) |
| TMLR | to Feb 2025 | Rejection "flat at approximately 28%" among 4,865 decided submissions | Outside audit by one author, verified | [TMLR audit](https://zrobertson466920.github.io/TMLRAudit) |

- ICML 2026 counts differ by source. A study of ICML 2026 reviewing reports 24,661 submissions (23,918 main track plus 743 position track) and 6,552 accepted (26.6%); Wikipedia gives 24,371 submitted. The rate rounds to 26.6% under either count. The first set of figures comes from a search summary of the paper, not from its abstract page, which says only "over 24,000 papers". — [Kim et al., arXiv 2609.19420](https://arxiv.org/abs/2609.19420); [Wikipedia: ICML](https://en.wikipedia.org/wiki/International_Conference_on_Machine_Learning)
- The official ICML 2026 list of accepted papers holds 6,646 unique titles (5,986 "Accept (regular)", 591 "Accept (spotlight)", 69 others). Counted locally from the downloaded list; it includes position papers. — [ICML 2026 accepted-papers data](https://icml.cc/static/virtual/data/icml-2026-orals-posters.json)
- TMLR time to decision: a median of 97 days for regular-length papers and 113 days for long ones in 2024, against 126 days for NeurIPS 2024; with every deadline met it would be 60 to 70 days. About 150 submissions a month. — [2024 TMLR Annual Report](https://docs.google.com/document/d/1_lUT03lHtwLKnFaN_RYjxnG8MX5DGcFAbfUQY6YxQsI/mobilebasic)
- TMLR, from third review to decision: median 45.2 days, 90th percentile 72.5 days. — [TMLR audit](https://zrobertson466920.github.io/TMLRAudit)

**First-time authors: the "half the rate" claim, verified at its source**

- Exact wording, from "Submission policies for ICLR 2027", posted 2 September 2026 by the ICLR 2027 programme chairs: "at ICLR 2026 about 20% of submissions had no reciprocal reviewer" "(computed by comparing the author lists to the final PC list)." "Within this set of "no-reviewer" submissions, about 15% are sole-author papers" "and about 40% have authors who submitted multiple "no-reviewer" papers." — [ICLR blog](https://blog.iclr.cc/?p=1150)
- "Last year, a quarter of "no-reviewer" submissions were desk-rejected." "Even among those papers that went to full review, they were accepted at about half the rate" "of submissions with authors on the program committee." "Thus papers in this group are much less likely to be accepted than the average ICLR submission". The post adds: "A the same time, many were excellent papers and accepted to the conference!" — [ICLR blog](https://blog.iclr.cc/?p=1150)
- The post says many such submissions "clearly do involve low-quality / AI-generated content", and that the goal of the new limit "is not to gate-keep based on academic qualifications". — [ICLR blog](https://blog.iclr.cc/?p=1150)
- ICML 2027 publishes no acceptance figure for such papers. It says they "are reviewed like all others". — [ICML 2027 quotas](https://icml.cc/Conferences/2027/ReciprocalReviewingAndSubmissionQuotas)

**Number of authors: counts from the official accepted-paper lists (computed locally)**

| Venue | Unique accepted titles on the list | Sole-author papers | Share | Median authors | Source |
|---|---|---|---|---|---|
| ICLR 2026 | 5,468 | 63 | 1.15% | 5 | [ICLR 2026 data](https://iclr.cc/static/virtual/data/iclr-2026-orals-posters.json) |
| ICML 2026 | 6,646 | 132 | 1.99% | 5 | [ICML 2026 data](https://icml.cc/static/virtual/data/icml-2026-orals-posters.json) |
| NeurIPS 2026 | 9,110 | 286 | 3.14% | 5 | [NeurIPS 2026 data](https://neurips.cc/static/virtual/data/neurips-2026-orals-posters.json) |

- Sole-author accepted papers on agents or language models by authors outside universities exist. NeurIPS 2026 examples, with the affiliation as printed on the list: "Masked Diffusion Language Models are Strong and Steerable Text-Based World Models for Agentic RL" (Patronus AI), "When Guessing is Rewarded: Rethinking Language Model Evaluation with Distributional Uncertainty Scoring" (Aleph Alpha), "Too Smart to Teach: The Articulability Ceiling in Language Models" (Apple), "Hidden Measurement Error in LLM Pipelines Distorts Annotation, Evaluation, and Benchmarking" (Google DeepMind), "Contrastive Pretraining Scales Agentic Exploration" (Independent), "Truth as a Compression Artifact in Language Model Training" (Independent Researcher). — [NeurIPS 2026 data](https://neurips.cc/static/virtual/data/neurips-2026-orals-posters.json)
- ICML 2026 example: "Reward Hacking Benchmark: Measuring Exploits in LLM Agents with Tool Use", sole author, "Independent Researcher". — [ICML 2026 data](https://icml.cc/static/virtual/data/icml-2026-orals-posters.json)
- These are shares of accepted papers. No venue publishes how many sole-author papers were submitted, so they are not acceptance rates.
- The list totals do not match the official main-track counts exactly: the ICLR 2026 list has 5,468 unique titles against 5,355 accepted in the official blog, and the ICML and NeurIPS lists include position and other tracks. The sole-author shares are therefore approximate. — [ICLR blog](https://blog.iclr.cc/?p=1116); [ICLR 2026 data](https://iclr.cc/static/virtual/data/iclr-2026-orals-posters.json)

**Industry authors and noise (earlier pass, not re-opened)**

- At ICLR 2017 to 2020, reviewer scores showed "no meaningful trend" by institution rank; the measured effects were at the area-chair step, including a penalty for one company's papers in 2020. — [Tran et al. 2020](https://arxiv.org/pdf/2011.12919)
- NeurIPS 2021: a second committee rejected 50.6% of the papers the first accepted, and accepted 14.9% of those it rejected. — [NeurIPS 2021 consistency experiment](https://blog.neurips.cc/2021/12/08/the-neurips-2021-consistency-experiment/)

### Inferences

- Derived correction to the earlier arithmetic. Let r be the ICLR 2026 acceptance rate of papers with an author on the programme committee. If 20% of submissions were "no-reviewer", a quarter of those were desk-rejected, and the rest were accepted at r/2, then the overall rate is 0.8r + 0.2 × 0.75 × r/2 = 0.875r. With the official 27.4% this gives r of about 31%, about 16% for no-reviewer papers that reached full review, and about 12% for all no-reviewer papers. Carried to ICML at 26.6%: about 30%, 15% and 11%. So the group odds are about one in six or seven after reaching full review and about one in nine overall. The earlier "one in eight" for papers that reach full review was a little too low; the earlier "one in ten" overall was about right. Assumptions: the three "about" figures are exact, both groups share the 27.4% denominator, and ICML behaves like ICLR.
- Derived upper bound for a sole first-time author. 20% of about 19,525 ICLR 2026 submissions is about 3,900 no-reviewer papers; 15% of those is about 590 sole-author no-reviewer papers. Only 63 sole-author papers were accepted at ICLR 2026 in total, and some of those 63 authors were surely qualified reviewers. So the acceptance rate of sole-author, no-reviewer papers at ICLR 2026 was at most about 63 / 590, or 11%, and probably lower. This is the closest thing to a documented rate for the author's exact situation.
- That bound is a group average over a pool the chairs themselves describe as containing much low-quality or machine-generated work. A careful paper sits above the pool's average, by an amount no source measures.
- One inconsistency limits these derivations: a quarter of about 3,900 is about 980 desk rejections, more than the 779 desk rejections ICLR reported for all of 2026. The blog's percentages must use a different base from the retrospective's counts. The derived figures are therefore rough.
- ICML 2027's first-stage rejection is new, so no rate exists for it. It adds a hazard that the ICLR figures do not capture.
- Sole authorship is rare among accepted papers (1 to 3%) but not disqualifying, and industry or independent sole authors do get in.

### Gaps

- The official ICML 2026 post with the 26.6% figure could not be opened; the number rests on agreeing secondary pages.
- No official NeurIPS 2026 statistics post was found, and no 2025 or 2026 rate for the NeurIPS Datasets and Benchmarks (now Evaluations and Datasets) track.
- No venue publishes acceptance by number of authors, by industry affiliation or by first-time status. The ICLR blog paragraph is the only official data point.
- No acceptance rate was found for FSE Industry Papers, ITC, ATC 2026, COLM, UAI 2026, or any ICLR or ICML workshop.
- No TMLR annual report for 2025 was found; the 2024 report is the newest.
- AAAI-27 results arrive on 30 November 2026.

## 3. Rules that affect a solo industry author in 2026 to 2027

### Takeaway

ICML 2027 lets a team with no qualified reviewer submit exactly one paper, reviews it "like all others", requires a new AI Disclosure Statement, and does not require travel. TMLR charges nothing, needs no reviewing service and now has a yearly per-author quota that one paper does not approach; ARR, KDD and IJCAI each put an extra obstacle in front of a first-time solo author.

### Cited Findings

**ICML 2027 (verified from the posted call)**

- Quota: "Each author may appear on at most one submission in which no author is an eligible reciprocal reviewer." "Submissions that do not meet these requirements will be desk rejected." — [ICML 2027 Call for Papers](https://icml.cc/Conferences/2027/CallForPapers)
- Eligible means "at least one paper accepted at one of the following venues" by 14 January 2027; the list includes ICML, NeurIPS, ICLR, UAI, AISTATS, JMLR, TMLR, ACL-family venues, AAAI, IJCAI, KDD and COLT. Excluded: "workshop papers, position papers, short papers, system demonstrations, industry papers and blog posts." Teams with no eligible author are exempt from reviewing, and their papers "are reviewed like all others". — [ICML 2027 quotas](https://icml.cc/Conferences/2027/ReciprocalReviewingAndSubmissionQuotas)
- First-stage rejection: "the area chair assigned to each paper decides whether it should proceed to the second stage." "Every proposed first-stage reject must be confirmed by a senior area chair, and when in doubt, papers go to full review." Authors "will be notified by February 23, 2027 with a short justification." No share or quota is given. — [ICML 2027 Call for Papers](https://icml.cc/Conferences/2027/CallForPapers)
- AI use: "All submissions must include an AI Disclosure Statement. The statement does not count toward the paper page limit." "Routine editorial assistance, such as spelling, grammar, formatting, and minor clarity edits, does not require disclosure." "When generative AI is part of the research methodology itself, its use must also be described in the paper with sufficient detail to understand and reproduce the work." — [ICML 2027 Call for Papers](https://icml.cc/Conferences/2027/CallForPapers)
- Preprints and workshops: posting on arXiv is allowed; the work must not be advertised as an ICML submission; workshop presentations without published proceedings do not break the dual-submission rule. (Page-reader summary of the call.) — [ICML 2027 Call for Papers](https://icml.cc/Conferences/2027/CallForPapers)
- Attendance: "Attendance for authors of accepted papers is optional." "For proceedings-only papers, at least one of the authors must obtain virtual registration." — [ICML 2027 Call for Papers](https://icml.cc/Conferences/2027/CallForPapers)
- Evidence and release: "All claims must be clearly stated and supported by reproducible experiments and/or sound theoretical analysis." The call states no code-release requirement, no rule on synthetic data and no fee. An impact statement is required, and accepted papers need a lay summary. — [ICML 2027 Call for Papers](https://icml.cc/Conferences/2027/CallForPapers)
- Contribution types (new for ICML 2027): "General (most papers)", "Theory", "Application-driven", "Concept and Feasibility", "Negative Results", and "Datasets, Evaluations and Benchmarks." Reviewers "should evaluate the submission according to the Contribution Type selected by the authors." — [ICML 2027 Call for Papers](https://icml.cc/Conferences/2027/CallForPapers); [ICML 2027 Contribution Types](https://icml.cc/Conferences/2027/ContributionTypes)

**TMLR (verified)**

- No fees, no deadline, double-blind, "at least three qualified reviewers"; an action editor is assigned "within a week". (The no-fee line is from the earlier pass.) — [TMLR editorial policies](https://jmlr.org/tmlr/editorial-policies.html)
- A yearly per-author submission budget now applies (the page calls it the Generalized Harmonic Quota Rule; desk-rejected papers count; reviewers and action editors get double). — [TMLR editorial policies](https://jmlr.org/tmlr/editorial-policies.html)
- "we do not accept submissions that are expanded versions of conference papers." Overlap with preprints and non-archival workshop versions is acceptable. A rejected paper may come back only as a new submission that links to the rejected version and lists the changes. — [TMLR editorial policies](https://jmlr.org/tmlr/editorial-policies.html)
- "LLMs may be used as general-purpose assistive tools." LLMs cannot be authors. A paper generated with little or no human involvement is "unlikely to meet this criterion" (the interest criterion). — [TMLR editorial policies](https://jmlr.org/tmlr/editorial-policies.html); [TMLR Acceptance Criteria](https://jmlr.org/tmlr/acceptance-criteria.html)
- A TMLR paper makes its author an eligible reciprocal reviewer at ICML. — [ICML 2027 quotas](https://icml.cc/Conferences/2027/ReciprocalReviewingAndSubmissionQuotas)

**ACL Rolling Review (verified)**

- "Submissions will only be guaranteed review if they bring a qualified service contributor". "Submissions not selected for review via lottery will be desk rejected." One person can be the contributor on at most 2 submissions. Caps: 20 papers per author, 5 as first author. — [ARR call](https://aclrollingreview.org/cfp)
- "Papers without a limitations section will be desk rejected." Submissions with "prompt injections intended to manipulate generative tools will be desk rejected." AI help with writing or code must be declared in the checklist. Non-anonymous preprints are allowed. A resubmission must link to the earlier version. — [ARR call](https://aclrollingreview.org/cfp)

**IJCAI 2027 (verified; the call is now online)**

- "Papers must be no longer than **9** pages in total" (7 of body, 2 of references). "every submission is subject to a fee of USD 100", waived when no author appears on another IJCAI 2027 submission. — [IJCAI 2027 main-track call](https://2027.ijcai.org/ijcai-2027-call-for-papers-main-track/)
- "Authors may use LLMs only to polish text they have written themselves." — [IJCAI 2027 main-track call](https://2027.ijcai.org/ijcai-2027-call-for-papers-main-track/)
- Two reviews in a first phase; if both are not positive enough the paper is rejected with no author response. Each submission names a qualified author as reciprocal reviewer "unless an exemption applies". One author must attend in Kyoto or Hengqin, or the paper leaves the proceedings. — [IJCAI 2027 main-track call](https://2027.ijcai.org/ijcai-2027-call-for-papers-main-track/)

**KDD 2027 (verified)**

- "Every submission must nominate at least one author who is a qualified reviewer." Qualified means "authors with at least three papers in KDD or other related conferences." If nobody qualifies, the best-qualified author is nominated "for the PC chairs' consideration". Up to 7 papers per author per cycle. An anonymised code repository is "highly recommended" though "not strictly required". — [KDD 2027 research call](https://kdd2027.kdd.org/research-track-call-for-papers/)

**ICLR 2027 and NeurIPS**

- "ICLR 2027 authors are permitted at most one publication in which no author is a qualified reciprocal reviewer." — [ICLR blog](https://blog.iclr.cc/?p=1150)
- ICLR 2027 workshops: short-paper tracks should "prioritize less-than-full-conference papers", and "AI-generated papers are not allowed for these formats." — [ICLR 2027 Workshop Guidelines](https://iclr.cc/Conferences/2027/WorkshopGuidelines)
- NeurIPS 2026 (earlier pass; the best guide to 2027): nine pages; a paper checklist is required; "At least one author of each accepted paper must register for the main conference" and a virtual pass was not enough; the Evaluations and Datasets track required code at submission. — [NeurIPS 2026 handbook](https://neurips.cc/Conferences/2026/MainTrackHandbook); [NeurIPS 2026 E&D reviewer guidelines](https://neurips.cc/Conferences/2026/EvaluationsDatasetsReviewerGuidelines)

### Inferences

- ICML 2027 is the friendliest top venue for this author on the rules: one paper allowed, no reviewing duty, no fee seen, no travel, preprint allowed.
- No venue read has a rule against synthetic data. The risk from synthetic traces is in how reviewers judge realism (section 5), not in any rule.
- The ICML AI Disclosure Statement has two parts for this paper: the language-model agents are the object of study and must be described well enough to reproduce, and any writing or coding help beyond routine editing must be declared.
- IJCAI's rule that LLMs may only polish the author's own text is the strictest found. An author who drafts with LLM help should not choose IJCAI.
- ARR's lottery and KDD's three-paper reviewer rule make ACL 2027 and KDD weaker choices for a first-time solo author than their acceptance rates suggest.
- A TMLR acceptance before the next cycle would move the author out of the "no eligible reviewer" group at ICML 2028 and similar venues.

### Gaps

- The share of papers ICML 2027 expects to reject at the first stage, and the grounds, are not published. The Peer Review FAQ is not out.
- NeurIPS 2027 has no handbook. Whether it will copy the one-paper rule for teams with no qualified reviewer is unknown.
- The exact numbers of the TMLR yearly quota were not understood from the page summary; one paper a year is well inside any reading of it.
- What KDD does when no author meets the three-paper rule is left to the chairs.
- arXiv's own rules for a first-time submitter (endorsement, moderation) were not checked.
- Employer clearance for the paper, the code and the trace generator is outside any source and gates every route.

## 4. Precedent: accepted measurement, audit and negative-result papers with no new model (2024 to 2026)

### Takeaway

Papers that only measure, with no new model, are accepted every year at ICML, NeurIPS, ICLR, ACL and TMLR, including studies showing that a popular agent technique does not hold up. What the verified examples share is a claim that reaches beyond one dataset, several models or systems, public benchmarks, and released code; none of them rests on a single private domain, and almost all have three or more authors.

### Cited Findings

**Verified examples**

| Paper | Venue | Authors | What it is | Source |
|---|---|---|---|---|
| "Should we be going MAD? A Look at Multi-Agent Debate Strategies for LLMs" | ICML 2024 (PMLR 235) | 5, from an industry lab | Benchmarks debate and prompting strategies on cost, time and accuracy; finds that "multi-agent debating systems, in their current form, do not reliably outperform other proposed prompting strategies"; no new model; open-source code | [PMLR](https://proceedings.mlr.press/v235/smit24a.html) |
| "Large Language Models Cannot Self-Correct Reasoning Yet" | ICLR 2024 | 7 | Negative result on self-correction without outside feedback | [ICLR 2024 poster page](https://iclr.cc/virtual/2024/poster/18956); [arXiv 2310.01798](https://arxiv.org/abs/2310.01798) |
| "Chain of Thoughtlessness? An Analysis of CoT in Planning" | NeurIPS 2024 | 3 | Shows chain-of-thought gains hold only when examples closely match the problem | [NeurIPS 2024 poster page](https://neurips.cc/virtual/2024/poster/93898) |
| "Model Equality Testing: Which Model is this API Serving?" | ICLR 2025 | 3 | Audit of hosted endpoints: "11 out of 31 endpoints serve different distributions than reference weights released by Meta" | [ICLR 2025 proceedings](https://proceedings.iclr.cc/paper_files/paper/2025/hash/d73234a13815fc1f9779dd17d89be9b4-Abstract-Conference.html) |
| "How Is ChatGPT's Behavior Changing over Time?" | Harvard Data Science Review, 2024 | 3 | Drift of two hosted models between March and June 2023 | [record with DOI 10.1162/99608f92.5317da47](https://www.infodocket.com/2024/03/19/journal-article-how-is-chatgpts-behavior-changing-over-time/); [arXiv 2307.09009](https://arxiv.org/pdf/2307.09009) |
| "AI Agents That Matter" | TMLR, May 2025 | 5 | Critique of agent evaluation (accuracy-only reporting, weak holdout sets, no cost control); no new model | [TMLR entry](https://mlanthology.org/tmlr/2025/kapoor2025tmlr-ai/); [arXiv 2407.01502](https://arxiv.org/abs/2407.01502) |
| "Establishing Best Practices in Building Rigorous Agentic Benchmarks" | NeurIPS 2025, Datasets and Benchmarks | about 25 | Audit of agent benchmarks; scoring flaws mis-state results by up to 100% in relative terms | [NeurIPS 2025 proceedings](https://proceedings.neurips.cc/paper_files/paper/2025/hash/f316275b44ee2de533102913828a8107-Abstract-Datasets_and_Benchmarks_Track.html) |
| "Why Do Multi-Agent LLM Systems Fail?" | NeurIPS 2025, Datasets and Benchmarks | not counted | 1,000+ annotated traces from 7 frameworks; 14 failure modes; inter-annotator agreement 0.88 | [NeurIPS 2025 proceedings](https://proceedings.neurips.cc/paper_files/paper/2025/file/b1041e52d3be19f0a9bc491657488e4a-Paper-Datasets_and_Benchmarks_Track.pdf) |
| "How Memory Management Impacts LLM Agents: An Empirical Study of Experience-Following Behavior" | ACL 2026, long paper | 8 | Empirical study of adding and deleting agent memory; three agents on three tasks; finds error propagation and misaligned replay; data and code released | [ACL Anthology](https://aclanthology.org/2026.acl-long.27/); [arXiv 2505.16067](https://arxiv.org/abs/2505.16067v2) |
| "Evaluating Memory in LLM Agents via Incremental Multi-Turn Interactions" (MemoryAgentBench) | ICLR 2026 | 3 | Memory benchmark; accepted with scores 4, 6, 8, 6 (earlier pass) | [ICLR 2026 proceedings](https://proceedings.iclr.cc/paper_files/paper/2026/file/fd1eff9dd295df50a41f2521942fa31d-Paper-Conference.pdf); [published reviews](https://cseweb.ucsd.edu/~jmcauley/reviews/iclr26c.pdf) |

**MemRL, the paper the pitch leans on**

- MemRL is on the official NeurIPS 2026 list as "Accept (poster)", with 14 authors and OpenReview forum id FBlIaSaXnX. — [NeurIPS 2026 data](https://neurips.cc/static/virtual/data/neurips-2026-orals-posters.json)
- Its arXiv record does not name the venue (comments field: "41 pages, 11 figures"; v1 6 January 2026, v2 12 February 2026). It reports experiments on HLE, BigCodeBench, ALFWorld and Lifelong Agent Bench, and its code is public. — [arXiv 2601.03192](https://arxiv.org/abs/2601.03192); [MemRL code](https://github.com/MemTensor/MemRL)

**Titles on the 2026 accepted lists that show the genre is alive (titles and author counts only; the papers were not read)**

- NeurIPS 2026: "The Illusion of Multi-Agent Advantage" (10 authors); "When and Why Does Multi-Agent Debate Fail and Does It Really Underperform?" (5); "Frozen Memory Is Not Enough: Rethinking External Memory as Extraction" (4); "MEMAUDIT: An Exact Package-Oracle Evaluation Protocol for Budgeted Long-Term LLM Memory Writing" (2); "Task Success Is Not Enough: Side-effect-Aware Evaluation of Tool-Using Language Model Agents" (8); "What Claims Do LLM Benchmark Scores Support?" (1); "Hidden Measurement Error in LLM Pipelines Distorts Annotation, Evaluation, and Benchmarking" (1). — [NeurIPS 2026 data](https://neurips.cc/static/virtual/data/neurips-2026-orals-posters.json)
- ICML 2026: "Position: ICML Should Treat Hosted LLM APIs as Versioned Dependencies and Require Drift-Audit Artifacts" (1 author, Stanford University). — [ICML 2026 data](https://icml.cc/static/virtual/data/icml-2026-orals-posters.json)
- The NeurIPS 2026 list has 58 titles containing both "agent" and "memory"; the ICML 2026 list has 30. A keyword search of both lists for swap, upgrade, drift, cross-model, migration and backbone found no title about what happens to an agent's scored memory when the model is replaced. — [NeurIPS 2026 data](https://neurips.cc/static/virtual/data/neurips-2026-orals-posters.json); [ICML 2026 data](https://icml.cc/static/virtual/data/icml-2026-orals-posters.json)

**TMLR's criteria, quoted from its site**

- First criterion: "Are the claims made in the submission supported by accurate and convincing evidence?" When evidence falls short, authors can add experiments, or "Another is for the authors to adjust (reduce) their claims." — [TMLR Acceptance Criteria](https://jmlr.org/tmlr/acceptance-criteria.html)
- Second criterion: "Would some individuals in TMLR's audience be interested in the findings of this paper," "and does the paper communicate those findings clearly to its intended audience?" "Generally, a reviewer who is unsure as to whether a submission satisfies this criterion should assume that it does." — [TMLR Acceptance Criteria](https://jmlr.org/tmlr/acceptance-criteria.html)
- On significance: "Crucially, it should not be used as a reason to reject work that isn't considered "significant"". Novelty "is not a necessary criterion for acceptance in TMLR." Work should not be rejected because it "isn't achieving a new state-of-the-art on some benchmark." — [TMLR Acceptance Criteria](https://jmlr.org/tmlr/acceptance-criteria.html)
- Impact is handled after acceptance: "TMLR instead relies on certifications (such as "Featured" and "Outstanding")." — [TMLR Acceptance Criteria](https://jmlr.org/tmlr/acceptance-criteria.html)
- A study that "systematically studies the robustness or generalizability" of a published method and draws lessons can qualify, while a bare re-run may not. — [TMLR Acceptance Criteria](https://jmlr.org/tmlr/acceptance-criteria.html)
- TMLR "emphasizes technical correctness over subjective significance." (Earlier pass.) — [TMLR editorial policies](https://jmlr.org/tmlr/editorial-policies.html)

**What the top venues say about this kind of paper**

- ICML 2027, "Negative Results": "The originality and significance bar for Negative Results contributions is high." "A failed experiment alone is not sufficient." "The paper should provide analysis, evidence, or theory that explains why the negative result matters." — [ICML 2027 Contribution Types](https://icml.cc/Conferences/2027/ContributionTypes)
- ICML 2027, "Datasets, Evaluations and Benchmarks": such a paper "does not need to introduce a new learning algorithm."; it "should not be evaluated primarily according to whether it enables a new state of the art result."; authors should "clearly state what scientific claims the dataset, benchmark, or evaluation supports." — [ICML 2027 Contribution Types](https://icml.cc/Conferences/2027/ContributionTypes)
- ICML 2027, "General": contributions "may include new methods, algorithms, empirical findings, conceptual insights, systems, applications." — [ICML 2027 Contribution Types](https://icml.cc/Conferences/2027/ContributionTypes)
- ICML 2027, across types: evidence "that would effectively require the authors to turn the submission into a different type of contribution" should generally not be demanded. — [ICML 2027 Contribution Types](https://icml.cc/Conferences/2027/ContributionTypes)
- NeurIPS 2026 Evaluations and Datasets track: "Negative results, critical analyses, and use-case-inspired evaluations are welcome." The track invites work that will "Provide rigorous reproduction, auditing, and stress-testing of prior evaluations", and submissions "need not introduce a new model or outperform prior work." — [NeurIPS blog, 23 March 2026](https://blog.neurips.cc/2026/03/23/introducing-the-evaluations-datasets-track-at-neurips-2026/)
- NeurIPS 2026 main track, negative results (earlier pass): "The negative result must be surprising or unexpected in some way." — [NeurIPS 2026 Reviewer Guidelines](https://neurips.cc/Conferences/2026/ReviewerGuidelines)

### Inferences

- What the verified precedents have in common: (1) the question is about a technique many people use, not about one product; (2) several models or systems are compared (seven frameworks, 31 endpoints, three agents, many prompting strategies); (3) public tasks that others can re-run; (4) code or data released; (5) a finding that corrects a common belief, with an explanation of when it holds. Reporting of seeds and confidence intervals was not checked in these papers.
- This paper matches (1) if it is framed as "any agent that keeps scored memory beside a rented model", and matches (2) to (4) only if the four-model, two-maker design, the public task and the release are all delivered. On PCIe/NVMe traces alone it has no accepted precedent in what was found.
- TMLR's criteria turn the author's weak points into non-issues on paper: no novelty bar, no significance bar, doubt about interest resolved in the author's favour, and a written route to narrow the claims in place of rejection. What TMLR does not relax is evidence. A sound measurement with error ranges, stated limits and claims no wider than the data is exactly what the first criterion asks for.
- The paper probes how far an accepted method's appendix result generalises (MemRL's transfer of a scored memory to other models). TMLR names that kind of study as one that can qualify.
- At ICML 2027 the safest contribution type is "General" or "Datasets, Evaluations and Benchmarks". "Negative Results" carries a stated high bar and should be chosen only if the result is a clear, surprising failure of kept tallies. This is my reading of the type definitions.
- The NeurIPS Evaluations and Datasets wording ("auditing, and stress-testing of prior evaluations", no new model needed) fits this paper better than any main track does, if NeurIPS 2027 keeps the track.
- A sole-author Stanford position paper at ICML 2026 arguing that hosted model versions must be tracked and drift audited shows that ICML reviewers accept the premise that swapping the model under a system is a real problem. It is a position paper, not a measurement, so it supports the motivation only.

### Gaps

- No accepted paper was found that measures what happens to scored or tallied agent memory across a model swap. That supports the "open question" claim but means there is no direct precedent for acceptance either. The check was a title search of two accepted lists, not a reading of papers.
- No accepted single-author, single-domain industrial measurement paper on agents was found at a top venue.
- The 2026 titles listed above were not read. Their methods, model counts and statistics are unknown.
- No TMLR measurement paper on agent memory specifically was found; "AI Agents That Matter" is the closest TMLR example.
- MemRL's reviews could not be read (OpenReview browser check), so what its reviewers asked for is unknown.
- An arXiv paper critical of ReAct prompting ("On the Brittle Foundations of ReAct Prompting for Agentic Large Language Models") was found only as a preprint; no venue could be confirmed, so it is not listed as precedent.

## 5. What reviewers demand of agent-memory and evaluation papers in 2026: the conditions checklist

### Takeaway

The demands are consistent across the written guidelines, the two sets of published reviews and the accepted precedents: more than one base model, a no-memory or restart control, public tasks, repeated runs with error ranges, a cost table, honest limits and a release. The pitch may say the paper "meets the stated bar if these conditions are met"; it may not say "will be accepted", because about half of accept-quality papers are rejected by a second committee.

### Cited Findings

- Claims and evidence (ICML 2027): "All claims must be clearly stated and supported by reproducible experiments and/or sound theoretical analysis." — [ICML 2027 Call for Papers](https://icml.cc/Conferences/2027/CallForPapers)
- Evaluation papers must "clearly state what scientific claims the dataset, benchmark, or evaluation supports" and address "licensing, privacy, consent, data provenance, annotation practices, potential biases, contamination." — [ICML 2027 Contribution Types](https://icml.cc/Conferences/2027/ContributionTypes)
- Application-driven work: "Merely applying an existing machine learning method to a new dataset would generally not be sufficient." — [ICML 2027 Contribution Types](https://icml.cc/Conferences/2027/ContributionTypes)
- Published reviews of MemoryArena (ICML 2026, accepted), from the earlier pass: "many main experiments fix the task agent to GPT 5.1 mini, so it is hard to judge robustness across base models"; "With small evaluation sets, performance may also be sensitive to decoding randomness or sampling seeds"; "Hypotheses without empirical validation." — [published reviews](https://cseweb.ucsd.edu/~jmcauley/reviews/icml26b.pdf)
- Published reviews of MemoryAgentBench (ICLR 2026, accepted), from the earlier pass: a task "appearing somewhat artificial with synthetic serial numbers and unclear real-world motivation"; reviewers asked for a zero-shot (no-memory) baseline and for API costs, and the authors added both in the rebuttal. — [published reviews](https://cseweb.ucsd.edu/~jmcauley/reviews/iclr26c.pdf)
- Statistics (earlier pass): the NeurIPS checklist asks "Does the paper report error bars suitably and correctly defined or other appropriate information about the statistical significance of the experiments?" — [NeurIPS Paper Checklist guide](https://neurips.cc/public/guides/PaperChecklist)
- Cost and holdout: "AI Agents That Matter" criticises a narrow focus on accuracy, inadequate holdout sets and missing standard evaluation practice. — [arXiv 2407.01502](https://arxiv.org/abs/2407.01502)
- Benchmark validity: flaws in task setup or reward design can skew agent results by up to 100% in relative terms. — [NeurIPS 2025 proceedings](https://proceedings.neurips.cc/paper_files/paper/2025/hash/f316275b44ee2de533102913828a8107-Abstract-Datasets_and_Benchmarks_Track.html)
- Scale of the accepted neighbours: MemRL used four public benchmarks; the ACL 2026 memory study used three agents on three tasks and released code; the ICML 2024 debate study compared many strategies on cost, time and accuracy and released code. — [arXiv 2601.03192](https://arxiv.org/abs/2601.03192); [arXiv 2505.16067](https://arxiv.org/abs/2505.16067v2); [PMLR](https://proceedings.mlr.press/v235/smit24a.html)
- AI use must be disclosed and, where it is the method, described "with sufficient detail to understand and reproduce the work." — [ICML 2027 Call for Papers](https://icml.cc/Conferences/2027/CallForPapers)
- Honest limits are protected in writing (earlier pass): "Authors should be rewarded rather than punished for being up front about the limitations of their work". — [ICML 2026 Reviewer Instructions](https://icml.cc/Conferences/2026/ReviewerInstructions)
- Noise: a second NeurIPS committee rejected 50.6% of the papers the first accepted (earlier pass). — [NeurIPS 2021 consistency experiment](https://blog.neurips.cc/2021/12/08/the-neurips-2021-consistency-experiment/)

### Inferences

The checklist below is my synthesis of the findings above. Each line names the evidence it rests on.

| # | Condition | Rests on | Needed for a top venue | Needed for TMLR |
|---|---|---|---|---|
| 1 | At least four frozen models from at least two makers, one with public weights; every ordered pair swapped | MemoryArena review on base models; precedents compare many systems | Yes | Yes, or the claim is narrowed to the models tested |
| 2 | Wipe-and-restart and keep baselines, plus a no-memory run and a similarity-only ranking | MemoryAgentBench reviewers asked for a zero-shot baseline; MemRL has no wipe comparison (earlier pass) | Yes | Yes; this is the paper's core comparison |
| 3 | At least one public task beside the PCIe/NVMe traces, ideally one MemRL used | "Merely applying ... to a new dataset would generally not be sufficient"; every verified precedent uses public tasks | Yes; without it the paper reads as a case study | Not strictly, but the claims must then be limited to the synthetic domain |
| 4 | Repeated runs (five or more stream orders), paired comparison, 95% intervals, a correction for testing many pairs | NeurIPS checklist; the "seeds" review comment | Yes | Yes; this is the "accurate and convincing evidence" test |
| 5 | Cost table: money, tokens, seconds per case | Reviewers asked for API cost; "AI Agents That Matter" | Yes | Helpful |
| 6 | A mechanism test: does disagreement between models on how a case is filed predict the drop? | ICML negative-results wording ("explains why the negative result matters"); "Hypotheses without empirical validation" | Yes; it is what lifts the paper from a table to a finding | Helpful |
| 7 | Scripted-reviewer noise varied on purpose; limits stated first (synthetic traces, simulated verdicts, one industrial domain) | "somewhat artificial with synthetic" comment; limits are protected | Yes | Yes |
| 8 | Full release: code, generator with seeds, prompts, logs, saved model answers | ICML "reproducible experiments"; precedents release code; NeurIPS E&D required code at submission | Yes | Yes (supplement up to 100 MB, earlier pass) |
| 9 | Related work that states the difference from MemRL and the transfer papers point by point; every reference checked by hand | ICML reviewer question on prior and concurrent work (earlier pass); desk rejections for invented references at ICLR 2026 (earlier pass) | Yes | Yes |
| 10 | Mechanics: OpenReview profile approved before 14 January, AI Disclosure Statement, impact statement, anonymity, one submission only | ICML 2027 call and quota page | Yes | Profile and anonymity only |
| 11 | A result that is not "nothing changes" | ICML and NeurIPS wording on negative results | Yes for ICML; a null result should skip ICML | No; TMLR does not ask for significance |
| 12 | Employer clearance for paper, code and generator | Not sourced; precondition for every route | Yes | Yes |

- What the conditions buy: they remove the reasons for a clear reject. They do not remove chance. The honest sentence for leadership is: "If conditions 1 to 12 are met, the paper satisfies TMLR's two written criteria and is a normal-strength ICML submission; acceptance at ICML still depends on a first-stage screen and on which reviewers it draws."
- Three real engineers giving verdicts on a small set would answer objection 7 better than any simulation (earlier pass's judgement, which I share). It is not sourced as a reviewer requirement.

### Gaps

- No 2026 or 2027 blog post by an area chair on agent-memory or evaluation papers was found. The NeurIPS 2025 programme chairs' reflections (earlier pass) are the nearest.
- The ICML 2027 reviewer instructions and per-type review forms are not posted.
- MemRL's reviews and those of every rejected neighbour were not read. The two review sets quoted come from one research group's public page and are a small sample.
- No source states a required number of models or seeds. "Four models, two makers, five orders" is a judgement from reviewer comments, not a rule.

## 6. The honest probability ladder, and the single best venue

### Takeaway

On documented rates, one top-venue attempt by a first-time solo author succeeds about one time in nine (judged range one in seven to one in twelve, which contains the earlier pass's "one in eight to ten"); a second attempt brings the cumulative chance of a top-venue paper to roughly one in four; TMLR is the only venue where the documented rate (51% of all submissions, 69% of those fully reviewed) supports the word "likely". TMLR is the single best venue for this exact paper, because its two written criteria are the two things a careful measurement paper can guarantee.

### Cited Findings

- ICML accepted 26.6% in 2026 and 26.9% in 2025. — [RIKEN AIP](https://aip.riken.jp/news/icml2026/)
- At ICLR 2026, no-reviewer papers were about 20% of submissions; a quarter were desk-rejected; the rest were accepted "at about half the rate" "of submissions with authors on the program committee." — [ICLR blog](https://blog.iclr.cc/?p=1150)
- Only 63 sole-author papers are on the ICLR 2026 accepted list, 132 on ICML 2026 and 286 on NeurIPS 2026. — [ICLR 2026 data](https://iclr.cc/static/virtual/data/iclr-2026-orals-posters.json); [ICML 2026 data](https://icml.cc/static/virtual/data/icml-2026-orals-posters.json); [NeurIPS 2026 data](https://neurips.cc/static/virtual/data/neurips-2026-orals-posters.json)
- NeurIPS accepted 24.52% in 2025; its Datasets and Benchmarks track accepted 25.3% in 2024. — [NeurIPS blog](https://blog.neurips.cc/2025/09/30/reflections-on-the-2025-review-process-from-the-program-committee-chairs/); [NeurIPS blog](https://blog.neurips.cc/2025/09/30/reflecting-on-the-2025-review-process-from-the-datasets-and-benchmarks-chairs/)
- Resubmissions did better at ICLR 2017 to 2020: papers online for more than three months had higher acceptance rates in each of four years (about 36 to 38% against about 25% in 2020, read from a chart). Earlier pass. — [Tran et al. 2020](https://arxiv.org/pdf/2011.12919)
- A second committee accepted 14.9% of papers the first rejected, and rejected 50.6% of those it accepted. Earlier pass. — [NeurIPS 2021 consistency experiment](https://blog.neurips.cc/2021/12/08/the-neurips-2021-consistency-experiment/)
- TMLR in 2024: 51% of all submissions accepted, 69% excluding withdrawn and desk-rejected; median 97 days to a decision. — [2024 TMLR Annual Report](https://docs.google.com/document/d/1_lUT03lHtwLKnFaN_RYjxnG8MX5DGcFAbfUQY6YxQsI/mobilebasic)
- TMLR's stated criteria exclude novelty and significance as grounds for rejection and let authors reduce claims. — [TMLR Acceptance Criteria](https://jmlr.org/tmlr/acceptance-criteria.html)
- A certified TMLR paper can be shown as a poster at NeurIPS, ICML or ICLR but is not in their proceedings; NeurIPS 2026 took 64 TMLR papers this way (earlier pass). — [Journal-to-Conference track](https://neurips.cc/public/JournalToConference); [NeurIPS blog, 15 October 2026](https://blog.neurips.cc/2026/10/15/announcing-the-neurips-2026-journal-track/)
- ICML dates that set the "when": first-stage notice 23 February 2027, final decision 3 May 2027. — [ICML 2027 Dates](https://icml.cc/Conferences/2027/Dates)

### Inferences

Everything below is judgement built on the cited rates. The numbers are group rates adjusted by stated assumptions, not forecasts for this paper, and none is a promise.

**The ladder**

| Rung | Venue and decision date | Documented base | Adjustment and assumption | Judged chance for this paper | Cumulative chance of the outcome named |
|---|---|---|---|---|---|
| 1 | ICML 2027 main track; first-stage notice 23 Feb 2027, final 3 May 2027 | 26.6% overall. Derived for teams with no qualified reviewer: about 15% after reaching full review, about 11% overall. Sole-author, no-reviewer papers at ICLR 2026: at most about 11% | Assumes all twelve conditions in section 5 are met and the result is not null. Up: the group average includes much low-quality work. Down: one author, one industrial domain, synthetic traces, a new first-stage screen with no published rate | About 8 to 15% (one in seven to one in twelve). Under 5% if the public task or the statistics are missing | Top-venue paper: about 8 to 15% |
| 2 | Second top-venue attempt: NeurIPS 2027 main or Evaluations and Datasets track (deadline about May 2027, decision about late September 2027, both estimated) | 24.5 to 25.7% overall; 25.3% for the datasets track in 2024; revised papers did better at ICLR 2017 to 2020 | Assumes the ICML reviews are answered with new experiments. The same first-time-author discount is assumed to apply; NeurIPS has published none. The track's wording fits the paper better than a main track | About 10 to 18%, given rung 1 failed | Top-venue paper after two tries: about 18 to 30% (for example 1 − 0.88 × 0.86 ≈ 0.24) |
| 3a | TMLR, sent after an ICML rejection (late February or May 2027); decision about 97 days later at the 2024 median, so June to August 2027 | 51% of all submissions; 69% of those not withdrawn or desk-rejected | Assumes claims are cut to fit the evidence, as the criteria allow. Up: criteria fit; reviews from ICML already answered. Down: thin single-domain evidence can still fail the first criterion; the median hides slow cases | About 55 to 70% | Any accepted peer-reviewed paper via ICML then TMLR: about 60 to 75% (for example 1 − 0.88 × 0.40 ≈ 0.65), by about August 2027 |
| 3b | Industry track: FSE 2027 Industry Papers (23 Jan 2027; decision 20 Mar 2027) or ITC 2027 (abstract 5 Mar 2027) | No acceptance rate found for either | Cannot be based on a documented rate. FSE clashes with ICML. Both would publish the storage-tool story, not the general finding | Not stated | Not stated |
| 4 | Public preprint plus a non-archival workshop paper (ICLR 2027 workshops, about 1 Feb 2027, notice by 26 Feb 2027; or ICML 2027 workshops, dates not posted) | No workshop acceptance rates found. A preprint is not peer review | Preprint depends only on employer clearance and the server's moderation. Workshop figure is judgement with no base rate | Preprint: near certain once cleared. Workshop: about 60 to 80%, unsourced | A public, dated, citable result: very likely by February 2027 if clearance is given |

- The rungs are not independent. A paper with a real flaw fails at every rung, and a strong one does better at each. Multiplying the rungs, as the examples do, overstates the spread a little in both directions.
- Rung 1 and rung 3a cannot overlap in time: the paper may be under review at one venue only.
- The route TMLR first (submitted in January 2027, decision about April 2027 at the median) gives the earliest accepted paper and the highest single-step chance, but gives up the ICML attempt for this version of the work, since TMLR rejects "expanded versions of conference papers" and ICML rejects work already published.

**Which single venue gives the best odds for this exact paper: TMLR**

1. Its first criterion (claims supported by evidence) is fully in the author's control; its second (some readers would be interested) is resolved in the author's favour when a reviewer is unsure.
2. It removes the three things that weigh on this paper at a conference: the novelty bar, the significance bar, and the first-time-author discount seen at ICLR 2026. No source shows any such discount at TMLR, though none shows its absence.
3. The documented rate is two to six times the conference rates: 51 to 69% against roughly 11 to 27%.
4. If the measured effect turns out to be "nothing changes", ICML and NeurIPS set a high bar for negative results, while TMLR does not ask for surprise.
5. Practicalities suit one industry author: rolling, free, no travel, no reviewing duty, authors may narrow claims during review, and an accepted paper makes the author an eligible reviewer for later ICML cycles.
6. Costs: it is a journal outside the conference rankings; the median wait is 97 days and can be much longer; it may pause over December; a top-conference poster through the journal track needs a further selective certification and is not a proceedings paper.

**What may be said to leadership, and what may not**

- Supported by documented rates: "A peer-reviewed publication is more likely than not within about nine months if the experiment is sound, with TMLR the most probable home, probably between June and August 2027 on the route ICML first, or about April 2027 if sent to TMLR directly."
- Supported: "ICML 2027 is a real but low-odds first attempt, about one in nine (range one in seven to one in twelve), with answers on 23 February or 3 May 2027."
- Not supported: "likely to be accepted at ICML or NeurIPS", any single date for acceptance, or any figure above the ladder's ranges. No source supports a claim that the paper "will be accepted" anywhere.
- The conditions sentence that holds up: "It meets the published acceptance criteria of TMLR if every claim is backed by the reported evidence and the limits are stated; at ICML it is a full-strength submission if the twelve conditions are met, and the outcome then depends on reviewers."

### Gaps

- Every "judged chance" is a range chosen by me around a documented group rate. No data exist for a solo industry author with this evidence profile.
- The ICML 2027 first-stage rejection rate is unknown; if it removes a large share of single-domain or first-time-author papers, rung 1 is lower than stated.
- The size of the measured effect is unknown. It decides between rung 1 and going straight to rung 3a.
- NeurIPS 2027 dates, tracks and rules are not posted; rung 2 assumes they resemble 2026.
- No acceptance rates for FSE Industry Papers, ITC or any workshop were found, so rung 3b and the workshop half of rung 4 have no documented base.
- TMLR's 2025 and 2026 acceptance rate and decision time are not published; the ladder uses 2024.
- Whether TMLR reviewers treat single-domain synthetic evidence as "convincing" for a general claim is untested; the safe reading is that the general claim needs the public task at TMLR too.
