"""Construct checks and free swap-day baselines for one study (msr/construct.py). No model call.

    python scripts/make_construct_assets.py --study sim
    python scripts/make_construct_assets.py --study study --real config/study.yaml

Writes runs/<study>/analysis/construct_*.csv and CONSTRUCT.md (or --out DIR).
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--study", required=True, help="study name (runs/<name>/study.yaml) or a study .yaml")
    ap.add_argument("--out", default=None, help="output folder (default runs/<study>/analysis)")
    ap.add_argument("--real", default="config/study.yaml", help="the real study's file, for the cost table's real column")
    ap.add_argument("--runs-dir", default=None, help="runs folder (default: runs/)")
    ap.add_argument("--measure", action="append", default=[], metavar="ROLE=FUNCTION",
                    help="use another msr.metrics function for a role of msr.construct.MEASURES, e.g. "
                         "--measure inference=theta_inference")
    a = ap.parse_args(argv)
    if a.runs_dir:
        from msr import llm as L
        L.RUNS = Path(a.runs_dir)
    from msr import construct as C
    measures = {}
    for m in a.measure:
        role, _, name = m.partition("=")
        if role not in C.MEASURES or not name:
            ap.error(f"--measure {m!r}: roles are {', '.join(C.MEASURES)}")
        measures[role] = name
    C.run(a.study, out_dir=a.out, real_study=a.real, measures=measures or None)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
