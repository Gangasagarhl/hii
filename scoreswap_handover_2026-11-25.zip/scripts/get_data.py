"""Download the study's data. Safe to run again: finished steps are skipped.

What it fetches (all free, no API keys):

1. The two StreamBench test streams from Hugging Face, pinned to one dataset
   commit, saved as  data/streambench/ddxplus.parquet  and  data/streambench/bird.parquet.
   Each file's sha256 is checked against the hash Hugging Face stores for it.
2. The BIRD dev databases zip (the same URL StreamBench's
   download_text2sql_data.py uses), checked by size and MD5, then only the
   SQLite files the bird test stream needs are unpacked to
   data/bird/dev_databases/<db_id>/<db_id>.sqlite .
3. data/MANIFEST.json: revision, file hashes, row counts, download dates.

Run:  python scripts/get_data.py            (from any folder, any OS)
      python scripts/get_data.py --verify   (re-hash everything, download nothing new)
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import shutil
import sys
import time
import urllib.request
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

REPO_ROOT = Path(__file__).resolve().parent.parent
DATA = REPO_ROOT / "data"
MANIFEST = DATA / "MANIFEST.json"

# ---- pins -----------------------------------------------------------------
HF_REPO = "appier-ai-research/StreamBench"
# Full commit of the dataset repo (main on 2024-08-14; still main on 2026-11-23).
HF_REVISION = "a387d5d86c4fab1b7cff724a3cdea0299a716b91"
# stream -> (file in the HF repo, sha256 stored by HF for that file, expected rows)
HF_FILES = {
    "ddxplus": ("ddxplus/test-00000-of-00001.parquet",
                "4bf0ef525749c07ce7a26e87e3d40d69a0396c100dc3294a0ca3da4eef1633c5", 1764),
    "bird": ("bird/test-00000-of-00001.parquet",
             "f4475340e411315add3e43b46eb916f0ea56f3607221c420e3a1640690ac4ccc", 1534),
}
STREAMBENCH_COMMIT = "cf72f26"  # github.com/stream-bench/stream-bench, the code the prompts copy

# From stream-bench/download_text2sql_data.py (download_bird).
BIRD_URL = "https://bird-bench.oss-cn-beijing.aliyuncs.com/dev.zip"
BIRD_SIZE = 346207293                          # Content-Length seen 2026-11-17
BIRD_MD5 = "04b4af221c9186361f09b16abfd917ec"  # Content-MD5 header, same day
BIRD_ZIP = DATA / "bird" / "bird_dev.zip"
BIRD_DB_DIR = DATA / "bird" / "dev_databases"


# ---- helpers --------------------------------------------------------------
def now_utc() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def file_hash(path: Path, algo: str = "sha256", chunk: int = 1 << 20) -> str:
    h = hashlib.new(algo)
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(chunk), b""):
            h.update(block)
    return h.hexdigest()


def load_manifest() -> dict:
    if MANIFEST.exists():
        try:
            return json.loads(MANIFEST.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            print("MANIFEST.json is not valid JSON; starting a new one.")
    return {}


def save_manifest(m: dict) -> None:
    m["updated_utc"] = now_utc()
    tmp = MANIFEST.with_suffix(".json.part")
    tmp.write_text(json.dumps(m, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(MANIFEST)


def parquet_rows(path: Path) -> int:
    import pyarrow.parquet as pq
    return pq.ParquetFile(path).metadata.num_rows


def parquet_column(path: Path, column: str) -> list:
    import pyarrow.parquet as pq
    return pq.read_table(path, columns=[column]).column(column).to_pylist()


# ---- step 1: StreamBench streams -----------------------------------------
def get_streams(manifest: dict) -> None:
    from huggingface_hub import hf_hub_download

    out_dir = DATA / "streambench"
    out_dir.mkdir(parents=True, exist_ok=True)
    sec = manifest.setdefault("streambench", {})
    sec.update({"hf_repo": HF_REPO, "revision": HF_REVISION,
                "streambench_code_commit": STREAMBENCH_COMMIT, "split": "test"})
    files = sec.setdefault("files", {})
    for name, (remote, want_sha, want_rows) in HF_FILES.items():
        dest = out_dir / f"{name}.parquet"
        if dest.exists() and file_hash(dest) == want_sha:
            print(f"[skip] {name}: {dest.relative_to(REPO_ROOT)} already present, sha256 ok")
            files.setdefault(name, {}).update({"path": dest.relative_to(REPO_ROOT).as_posix(),
                                               "sha256": want_sha, "rows": parquet_rows(dest),
                                               "source_file": remote})
            files[name].setdefault("downloaded_utc", now_utc())
            continue
        print(f"[get ] {name}: {HF_REPO}@{HF_REVISION[:8]} {remote}")
        tmp_dir = DATA / "_src" / "hf_download"
        tmp_dir.mkdir(parents=True, exist_ok=True)
        got = Path(hf_hub_download(repo_id=HF_REPO, filename=remote, repo_type="dataset",
                                   revision=HF_REVISION, local_dir=str(tmp_dir)))
        sha = file_hash(got)
        if sha != want_sha:
            raise SystemExit(f"{name}: sha256 {sha} != pinned {want_sha}. Not saved.")
        part = dest.with_suffix(".parquet.part")
        shutil.copyfile(got, part)
        part.replace(dest)
        rows = parquet_rows(dest)
        if rows != want_rows:
            raise SystemExit(f"{name}: {rows} rows, expected {want_rows}")
        files[name] = {"path": dest.relative_to(REPO_ROOT).as_posix(), "source_file": remote,
                       "sha256": sha, "rows": rows, "downloaded_utc": now_utc()}
        print(f"       saved {dest.relative_to(REPO_ROOT)} ({rows} rows, sha256 {sha[:12]}...)")
        save_manifest(manifest)
    try:  # informational only: where main points today
        from huggingface_hub import HfApi
        sec["main_head_at_check"] = HfApi().dataset_info(HF_REPO).sha
        sec["main_head_checked_utc"] = now_utc()
        if sec["main_head_at_check"] != HF_REVISION:
            print(f"note: dataset main is now {sec['main_head_at_check']}; we stay on the pin.")
    except Exception as e:  # offline is fine
        print(f"note: could not read the dataset's current head ({type(e).__name__}); pin kept.")
    save_manifest(manifest)


# ---- step 2: BIRD zip -----------------------------------------------------
def _remote_md5() -> str | None:
    try:
        req = urllib.request.Request(BIRD_URL, method="HEAD")
        with urllib.request.urlopen(req, timeout=60) as r:
            b64 = r.headers.get("Content-MD5")
            return base64.b64decode(b64).hex() if b64 else None
    except Exception:
        return None


def _download(url: str, dest: Path, size: int, tries: int = 4) -> None:
    part = dest.with_name(dest.name + ".part")
    for attempt in range(1, tries + 1):
        have = part.stat().st_size if part.exists() else 0
        if have > size:
            part.unlink()
            have = 0
        if have == size:
            break
        req = urllib.request.Request(url)
        if have:
            req.add_header("Range", f"bytes={have}-")
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                mode = "ab" if (have and r.status == 206) else "wb"
                if mode == "wb":
                    have = 0
                done, last, t0 = have, -1, time.time()
                with open(part, mode) as f:
                    while True:
                        block = r.read(1 << 20)
                        if not block:
                            break
                        f.write(block)
                        done += len(block)
                        pct = int(100 * done / size)
                        if pct // 10 != last:
                            last = pct // 10
                            print(f"       {pct:3d}%  {done / 2**20:7.1f} MiB  {time.time() - t0:5.0f} s",
                                  flush=True)
        except Exception as e:
            print(f"       download attempt {attempt} stopped: {type(e).__name__}: {e}")
            time.sleep(2 * attempt)
            continue
        if part.stat().st_size == size:
            break
    if not part.exists() or part.stat().st_size != size:
        raise SystemExit(f"download of {url} incomplete; run again to resume")
    part.replace(dest)


def get_bird_zip(manifest: dict) -> None:
    sec = manifest.setdefault("bird_dev_zip", {})
    if BIRD_ZIP.exists() and sec.get("md5") == BIRD_MD5 and sec.get("size") == BIRD_ZIP.stat().st_size:
        print(f"[skip] BIRD zip present ({BIRD_ZIP.relative_to(REPO_ROOT)}), checked earlier")
        return
    BIRD_ZIP.parent.mkdir(parents=True, exist_ok=True)
    remote_md5 = _remote_md5()
    if remote_md5 and remote_md5 != BIRD_MD5:
        raise SystemExit(f"server MD5 {remote_md5} differs from the pinned {BIRD_MD5}: "
                         "the upstream file changed. Stop and look before using it.")
    if not BIRD_ZIP.exists():
        print(f"[get ] BIRD dev zip {BIRD_URL} ({BIRD_SIZE / 2**20:.1f} MiB)")
        _download(BIRD_URL, BIRD_ZIP, BIRD_SIZE)
    print("       checking size and MD5 ...")
    size = BIRD_ZIP.stat().st_size
    md5 = file_hash(BIRD_ZIP, "md5")
    if size != BIRD_SIZE or md5 != BIRD_MD5:
        bad = BIRD_ZIP.with_name(BIRD_ZIP.name + ".bad")
        BIRD_ZIP.replace(bad)
        raise SystemExit(f"BIRD zip size {size} / md5 {md5} do not match the pins; moved to {bad.name}")
    sec.update({"url": BIRD_URL, "size": size, "md5": md5, "sha256": file_hash(BIRD_ZIP),
                "server_md5_header": remote_md5, "path": BIRD_ZIP.relative_to(REPO_ROOT).as_posix(),
                "downloaded_utc": sec.get("downloaded_utc") or now_utc(),
                "source": f"stream-bench@{STREAMBENCH_COMMIT}/download_text2sql_data.py"})
    save_manifest(manifest)
    print(f"       ok: md5 {md5}, sha256 {sec['sha256'][:12]}...")


# ---- step 3: unpack only the needed databases ----------------------------
def _safe_member(name: str) -> bool:
    p = PurePosixPath(name)
    return not p.is_absolute() and ".." not in p.parts and ":" not in name


def needed_db_ids() -> list[str]:
    return sorted(set(parquet_column(DATA / "streambench" / "bird.parquet", "db_id")))


def databases_complete(manifest: dict, db_ids: list[str]) -> bool:
    rec = manifest.get("bird_databases", {})
    for db in db_ids:
        p = BIRD_DB_DIR / db / f"{db}.sqlite"
        if db not in rec or not p.exists() or p.stat().st_size != rec[db].get("size"):
            return False
    return True


def unpack_databases(manifest: dict, verify: bool = False) -> None:
    db_ids = needed_db_ids()
    if databases_complete(manifest, db_ids):
        if verify:
            for db in db_ids:
                p = BIRD_DB_DIR / db / f"{db}.sqlite"
                if file_hash(p) != manifest["bird_databases"][db]["sha256"]:
                    raise SystemExit(f"{p} changed since it was unpacked (sha256 differs)")
            print(f"[ok  ] all {len(db_ids)} databases match their recorded sha256")
        else:
            print(f"[skip] all {len(db_ids)} BIRD databases already unpacked")
        return
    # Anything here is a partial or older unzip: remove it first.
    if BIRD_DB_DIR.exists():
        print(f"[clean] removing partial {BIRD_DB_DIR.relative_to(REPO_ROOT)}")
        shutil.rmtree(BIRD_DB_DIR)
    tmp = DATA / "bird" / "_unzip_tmp"
    if tmp.exists():
        shutil.rmtree(tmp)
    tmp.mkdir(parents=True)
    print(f"[unz ] {len(db_ids)} databases: {', '.join(db_ids)}")
    with zipfile.ZipFile(BIRD_ZIP) as outer:
        inner_names = [n for n in outer.namelist()
                       if PurePosixPath(n).name == "dev_databases.zip" and not n.startswith("__MACOSX")]
        if len(inner_names) != 1 or not _safe_member(inner_names[0]):
            raise SystemExit(f"expected one dev_databases.zip in the BIRD zip, found {inner_names}")
        inner_path = tmp / "dev_databases.zip"
        with outer.open(inner_names[0]) as src, open(inner_path, "wb") as dst:
            shutil.copyfileobj(src, dst, 1 << 20)
    record = {}
    with zipfile.ZipFile(inner_path) as inner:
        members = {}
        for info in inner.infolist():
            p = PurePosixPath(info.filename)
            if (not info.is_dir() and _safe_member(info.filename) and "__MACOSX" not in p.parts
                    and len(p.parts) >= 2 and p.name == f"{p.parent.name}.sqlite"
                    and p.parent.name in db_ids):
                members[p.parent.name] = info
        missing = sorted(set(db_ids) - set(members))
        if missing:
            raise SystemExit(f"databases missing from the zip: {missing}")
        BIRD_DB_DIR.mkdir(parents=True, exist_ok=True)
        for db in db_ids:
            info = members[db]
            out = BIRD_DB_DIR / db / f"{db}.sqlite"
            out.parent.mkdir(parents=True, exist_ok=True)
            part = out.with_name(out.name + ".part")
            with inner.open(info) as src, open(part, "wb") as dst:
                shutil.copyfileobj(src, dst, 1 << 20)
            if part.stat().st_size != info.file_size:
                raise SystemExit(f"{db}: unpacked size differs from the zip entry")
            part.replace(out)
            record[db] = {"path": out.relative_to(REPO_ROOT).as_posix(), "size": info.file_size,
                          "sha256": file_hash(out), "zip_member": info.filename}
            print(f"       {db:28s} {info.file_size / 2**20:8.1f} MiB")
    shutil.rmtree(tmp)
    manifest["bird_databases"] = record
    manifest["bird_databases_unpacked_utc"] = now_utc()
    save_manifest(manifest)


def verify_all(manifest: dict) -> None:
    for name, (remote, want_sha, want_rows) in HF_FILES.items():
        p = DATA / "streambench" / f"{name}.parquet"
        ok = p.exists() and file_hash(p) == want_sha and parquet_rows(p) == want_rows
        print(f"[{'ok  ' if ok else 'BAD '}] {p.relative_to(REPO_ROOT)}")
    if BIRD_ZIP.exists():
        ok = file_hash(BIRD_ZIP, "md5") == BIRD_MD5
        print(f"[{'ok  ' if ok else 'BAD '}] {BIRD_ZIP.relative_to(REPO_ROOT)} md5")
    if not (DATA / "streambench" / "bird.parquet").exists() or not databases_complete(manifest, needed_db_ids()):
        print("[BAD ] BIRD databases missing or incomplete; run without --verify")
        return
    unpack_databases(manifest, verify=True)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--verify", action="store_true", help="re-hash files; download nothing")
    ap.add_argument("--skip-bird-db", action="store_true", help="only the two Hugging Face streams")
    args = ap.parse_args(argv)
    DATA.mkdir(parents=True, exist_ok=True)
    manifest = load_manifest()
    manifest.setdefault("created_by", "scripts/get_data.py")
    if args.verify:
        verify_all(manifest)
        return 0
    get_streams(manifest)
    if not args.skip_bird_db:
        get_bird_zip(manifest)
        unpack_databases(manifest)
    save_manifest(manifest)
    print(f"done. manifest: {MANIFEST.relative_to(REPO_ROOT)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
