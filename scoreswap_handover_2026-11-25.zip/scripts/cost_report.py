"""The cost statement of the paid study, written from the pipeline's own call counts. No model is called.

    python scripts/cost_report.py                 # writes docs/COST_2026-11-24.md and prints the summary
    python scripts/cost_report.py --out OTHER.md  # somewhere else

Everyday picture: before a big catering job, the cook counts every plate on the menu, prices each one
from today's price list, and then asks two questions: what if the portions come out twice as big and
the special offers end (the high case), and what if they come out a bit smaller and some plates are
simply copies of plates already made (the low case)?

Every number comes from msr.study.plan_calls on the real config files. A variant (a stage switched off,
an extension pair left out, an option switched on) is a temporary copy of the YAML with that one change,
loaded with msr.study.load_study; the config files themselves are never changed. Each new stage's row
is the DIFFERENCE between the study with and without it, so nothing is counted twice; the script checks
that the rows add up to the full study's total and stops if they do not.
"""
from __future__ import annotations

import argparse
import copy
import sys
import tempfile
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from msr.study import STAGES, load_study, plan_calls, total_calls, total_usd  # noqa: E402

CONFIG = ROOT / "config"
DEFAULT_OUT = ROOT / "docs" / "COST_2026-11-24.md"

# --- the three cases ---------------------------------------------------------------------------------
#: High case: every discounted price at its list price (config/models.yaml notes; the extension check of
#: 24 Nov 2026). The Qwen3.8-27B entry at temperature 0.7 is the same model, so it gets the same list price.
LIST_PRICES = {
    "qwen3.8-27b": (0.20, 2.50),
    "qwen3.8-27b-t07": (0.20, 2.50),
    "deepseek-v4.1-flash": (0.20, 0.60),
    "deepseek-v4.1-flash-1017": (0.20, 0.60),
}
HIGH_OUT, HIGH_IN, HIGH_RETRY = 2.0, 1.1, 0.03     # output x 2, input x 1.1, 3 % of calls asked again
LOW_OUT, LOW_CACHE = 0.75, 0.10                    # output x 0.75, 10 % answered from the cache
OR_FEE = 0.055                                     # OpenRouter's fee when credits are bought
CASES = ("low", "central", "high")

# --- facts quoted in the text (not computed here) ------------------------------------------------------
EARLIER = {"usd": 670, "calls": 2_240_400}         # docs/STATUS.md: the estimate before revision 2
AGENT_LEG_USD = 356                                # the agent leg's recommended design (legs/memrl)
FORECAST_CALLS = 1_150                             # no-memory calls per swap day the forecast reads
HAIKU45_EARLIEST_RETIREMENT = "about 23 Jan 2027"

HOST_NAMES = {"deepinfra": "OpenRouter -> DeepInfra", "parasail": "OpenRouter -> Parasail"}
PROVIDER_NAMES = {"anthropic": "Anthropic", "openai": "OpenAI"}
NICE = {"haiku-4.5": "Haiku 4.5", "haiku-5.5": "Haiku 5.5", "gpt-5.6-luna": "GPT-5.6-Luna", "gpt-6-luna": "GPT-6-Luna",
        "qwen3.5-27b": "Qwen3.5-27B", "qwen3.8-27b": "Qwen3.8-27B", "gemma-3-27b": "Gemma 3 27B",
        "gemma-4-31b": "Gemma 4 31B", "mistral-small-3": "Mistral Small 3", "mistral-small-3.2": "Mistral Small 3.2",
        "deepseek-v4.1-flash": "DeepSeek V4.1-Flash", "deepseek-v4.1-flash-1017": "DeepSeek V4.1-Flash-1017"}


# ---------------------------------------------------------------------------------------------------
# Parts: {(stage, model): [calls, tokens_in, tokens_out]}
# ---------------------------------------------------------------------------------------------------


def part_of(plan: dict) -> dict:
    out = {}
    for s, per in plan["calls"].items():
        for m, n in per.items():
            out[(s, m)] = [n, plan["tokens_in"][s][m], plan["tokens_out"][s][m]]
    return out


def sub(a: dict, b: dict) -> dict:
    """a - b, dropping keys that cancel."""
    out = {}
    for k in set(a) | set(b):
        x, y = a.get(k, [0, 0.0, 0.0]), b.get(k, [0, 0.0, 0.0])
        d = [x[i] - y[i] for i in range(3)]
        if d[0] != 0 or abs(d[1]) > 1e-6 or abs(d[2]) > 1e-6:
            out[k] = d
    return out


def add(*parts: dict) -> dict:
    out: dict = {}
    for p in parts:
        for k, v in p.items():
            o = out.setdefault(k, [0, 0.0, 0.0])
            for i in range(3):
                o[i] += v[i]
    return out


def same(a: dict, b: dict) -> bool:
    return not sub(a, b)


def calls(p: dict) -> int:
    return int(sum(v[0] for v in p.values()))


def only(p: dict, *, models=None, stages=None) -> dict:
    return {k: v for k, v in p.items()
            if (models is None or k[1] in models) and (stages is None or k[0] in stages)}


# ---------------------------------------------------------------------------------------------------
# Prices
# ---------------------------------------------------------------------------------------------------


class Pricer:
    def __init__(self, mcfg: dict):
        self.m = mcfg["models"]

    def prices(self, model: str, case: str) -> tuple:
        if case == "high" and model in LIST_PRICES:
            return LIST_PRICES[model]
        mc = self.m[model]
        return float(mc.get("price_in", 0)), float(mc.get("price_out", 0))

    def usd_key(self, model: str, tin: float, tout: float, case: str) -> float:
        pin, pout = self.prices(model, case)
        if case == "central":
            return (tin * pin + tout * pout) / 1e6
        if case == "low":
            return (tin * pin + LOW_OUT * tout * pout) / 1e6 * (1 - LOW_CACHE)
        if case == "high":
            return (HIGH_IN * tin * pin + HIGH_OUT * tout * pout) / 1e6 * (1 + HIGH_RETRY)
        raise ValueError(case)

    def usd(self, p: dict, case: str) -> float:
        return sum(self.usd_key(m, v[1], v[2], case) for (_s, m), v in p.items())

    def triple(self, p: dict) -> dict:
        return {c: self.usd(p, c) for c in CASES}

    def is_openrouter(self, model: str) -> bool:
        return self.m[model].get("provider") == "openrouter"

    def fee(self, p: dict) -> dict:
        orp = {k: v for k, v in p.items() if self.is_openrouter(k[1])}
        return {c: OR_FEE * self.usd(orp, c) for c in CASES}

    def host(self, model: str) -> str:
        mc = self.m[model]
        prov = mc.get("provider")
        if prov == "openrouter":
            only_ = (((mc.get("extra_body") or {}).get("provider") or {}).get("only") or ["?"])[0]
            base = str(only_).split("/")[0]
            return HOST_NAMES.get(base, f"OpenRouter -> {base}")
        return PROVIDER_NAMES.get(prov, str(prov))


# ---------------------------------------------------------------------------------------------------
# Study variants (temporary copies of the YAML; the configs are never changed)
# ---------------------------------------------------------------------------------------------------


class Loader:
    def __init__(self, tmp: Path):
        self.tmp, self.n = tmp, 0

    def raw(self, name: str) -> dict:
        return yaml.safe_load((CONFIG / name).read_text(encoding="utf-8"))

    def plan(self, raw: dict) -> tuple:
        self.n += 1
        p = self.tmp / f"variant_{self.n:03d}.yaml"
        p.write_text(yaml.safe_dump(raw, sort_keys=False), encoding="utf-8")
        st = load_study(p)
        return st, plan_calls(st)

    def part(self, raw: dict) -> dict:
        return part_of(self.plan(raw)[1])


def without_new_stages(raw: dict) -> dict:
    """The study as it was before revision 2's new stages (passes and models unchanged)."""
    r = copy.deepcopy(raw)
    r["build"]["write_repeat"] = False
    r["build"]["self_rating"] = False
    r["judge"] = {**(r.get("judge") or {}), "enabled": False}
    r["relearn"] = {**(r.get("relearn") or {}), "enabled": False}
    r["online"]["arms"] = [a for a in r["online"]["arms"] if not str(a).startswith("reexplore_")]
    r["probe"]["check_store_extra_tasks"] = 0
    return r


def without_extension(raw: dict, keep: list | None = None) -> dict:
    r = copy.deepcopy(raw)
    if keep:
        r["extension"] = {**r["extension"], "pairs": [p for p in r["extension"]["pairs"] if p in keep]}
    else:
        r.pop("extension", None)
    return r


def with_new_stage(base: dict, full: dict, which: str) -> dict:
    """`base` (no new stages) with ONE new stage switched on exactly as in `full`."""
    r = copy.deepcopy(base)
    if which == "judge":
        r["judge"] = copy.deepcopy(full["judge"])
    elif which == "selfrate":
        r["build"]["self_rating"] = full["build"]["self_rating"]
        r["build"]["rating_scale"] = full["build"].get("rating_scale", 10)
    elif which == "relearn":
        r["relearn"] = copy.deepcopy(full["relearn"])
    elif which == "reexplore":
        r["online"]["arms"] = list(full["online"]["arms"])
    elif which == "write2":
        r["build"]["write_repeat"] = full["build"]["write_repeat"]
    else:
        raise ValueError(which)
    return r


# ---------------------------------------------------------------------------------------------------
# Formatting
# ---------------------------------------------------------------------------------------------------


def money(x: float) -> str:
    return f"{x:,.2f}"


def row(label: str, n, t: dict | None) -> str:
    if t is None:
        return f"| {label} | {n} | | | |"
    nn = f"{n:,}" if isinstance(n, int) else n
    return f"| {label} | {nn} | {money(t['low'])} | {money(t['central'])} | {money(t['high'])} |"


HEAD = "| | calls | low USD | central USD | high USD |\n|---|---:|---:|---:|---:|"


def add_t(*ts: dict) -> dict:
    return {c: sum(t[c] for t in ts) for c in CASES}


def pct(a: float, b: float) -> str:
    return f"{100 * a / b:.1f} %" if b else "-"


# ---------------------------------------------------------------------------------------------------
# The report
# ---------------------------------------------------------------------------------------------------


def build_report(tmp: Path) -> tuple:
    ld = Loader(tmp)
    full_raw = ld.raw("study.yaml")
    st_full, plan_full = ld.plan(full_raw)
    pr = Pricer(st_full.models_cfg)
    full = part_of(plan_full)
    checks = []

    # --- the main study, split into rows --------------------------------------------------------------
    main_raw = without_extension(full_raw)                 # 8 models, new stages on
    base_raw = without_new_stages(main_raw)                # 8 models, existing stages, 5 passes
    st_base, plan_base = ld.plan(base_raw)
    base = part_of(plan_base)
    new_rows = {}
    for key in ("judge", "selfrate", "relearn", "reexplore", "write2"):
        new_rows[key] = sub(ld.part(with_new_stage(base_raw, main_raw, key)), base)
    main = ld.part(main_raw)
    if not same(add(base, *new_rows.values()), main):
        raise SystemExit("the new-stage rows do not add up to the main grid with every new stage on")
    checks.append("the five new-stage differences (B1 to B5) add up exactly to the main grid with every new stage on")

    ext_pairs = [list(p) for p in full_raw["extension"]["pairs"]]
    ext_rows = []
    for p in ext_pairs:
        others = [q for q in ext_pairs if q != p]
        d = sub(full, ld.part(without_extension(full_raw, keep=others) if others else main_raw))
        alone = sub(ld.part(without_extension(full_raw, keep=[p])), main)
        if not same(d, alone):
            raise SystemExit(f"extension pair {p}: its cost depends on the other pair")
        if {m for (_s, m) in d} - set(p):
            raise SystemExit(f"extension pair {p}: its difference touches other models")
        ext_rows.append((p, d))
    if not same(add(main, *(d for _p, d in ext_rows)), full):
        raise SystemExit("the extension rows do not add up to the full study")
    checks.append("each extension pair costs the same whether the other pair is in the study or not, and touches "
                  "only its own two models")
    study_rows = add(base, *new_rows.values(), *(d for _p, d in ext_rows))
    if not same(study_rows, full):
        raise SystemExit("the study rows do not add up to config/study.yaml")
    if abs(pr.usd(full, "central") - total_usd(plan_full)) > 1e-6 or calls(full) != total_calls(plan_full):
        raise SystemExit("the central case does not reproduce plan_calls' own dollars")
    checks.append(f"the study rows add up to {calls(full):,} calls and USD {money(total_usd(plan_full))}, "
                  f"exactly the total of `python run.py --study config/study.yaml --estimate`")

    # --- pilots and side studies, as they are -----------------------------------------------------------
    pilots = []
    for name, label in (("pilot_shot.yaml", "Pilot, DDXPlus, plain items (`pilot_shot`)"),
                        ("pilot_memprompt.yaml", "Pilot, DDXPlus, labelled items (`pilot_memprompt`)"),
                        ("pilot_bird.yaml", "Pilot, BIRD (`pilot_bird`)")):
        raw = ld.raw(name)
        pilots.append((label, ld.part(raw), raw))
    mem_raw = ld.raw("study_memprompt.yaml")
    mem_cfg_says = (list(mem_raw["streams"]), list(mem_raw["seeds"]))
    mem_ruled = copy.deepcopy(mem_raw)
    mem_ruled["streams"], mem_ruled["seeds"] = ["ddxplus"], [0]          # the ruling, applied in memory
    tmp_raw = ld.raw("study_temperature.yaml")
    sides = [("Side study: labelled items, DDXPlus, order 0 (`study_memprompt`)", ld.part(mem_ruled), mem_ruled),
             ("Side study: temperature 0.7, Qwen pair (`study_temperature`)", ld.part(tmp_raw), tmp_raw)]

    # --- options (not in the total) ----------------------------------------------------------------------
    opt = {}
    r = copy.deepcopy(full_raw)
    r["probe"]["check_store_extra_tasks"] = 400
    opt["check_store"] = sub(ld.part(r), full)
    r0 = copy.deepcopy(full_raw)
    r0["probe"]["home_extra_repeats"] = 0
    r1 = copy.deepcopy(r0)
    r1["probe"]["check_store_extra_tasks"] = 400
    opt["check_store_no_extra"] = sub(ld.part(r1), ld.part(r0))
    r = copy.deepcopy(full_raw)
    r["relearn"]["self_tag"] = True
    opt["relearn_tag"] = sub(ld.part(r), full)
    r = copy.deepcopy(full_raw)
    r["relearn"]["pairs"] = "swaps"
    st_sw, plan_sw = ld.plan(r)
    opt["relearn_swaps"] = sub(part_of(plan_sw), full)
    r["relearn"]["self_tag"] = True
    opt["relearn_swaps_tag"] = sub(ld.part(r), full)
    n_relearn_swaps = len(st_sw.relearn.pairs)

    # --- the earlier estimate, rebuilt -----------------------------------------------------------------
    old_raw = copy.deepcopy(base_raw)
    old_raw["build"]["epochs"] = 3
    old = ld.part(old_raw)

    # --- a known overcount: the online none and own runs of a reader in two cells ---------------------
    o_raw = copy.deepcopy(full_raw)
    o_raw["online"]["arms"] = ["none", "own"]
    st_o, plan_o = ld.plan(o_raw)
    n_cells = {}
    for _o, rd in st_o.online.pairs:
        n_cells[rd] = n_cells.get(rd, 0) + 1
    dup = {}
    for (s, m), v in part_of(plan_o).items():
        if s == "online" and n_cells.get(m, 1) > 1:
            f = (n_cells[m] - 1) / n_cells[m]
            dup[(s, m)] = [int(round(v[0] * f)), v[1] * f, v[2] * f]
    dup_readers = sorted(m for m, k in n_cells.items() if k > 1)

    # --- pilot and side studies at the main study's passes (notes only) --------------------------------
    pass_notes = []
    for label, _p, raw in pilots:
        r6 = copy.deepcopy(raw)
        r6["build"]["epochs"] = 6
        pass_notes.append((label, 6, ld.part(r6)))
    for label, _p, raw in sides:
        r5 = copy.deepcopy(raw)
        r5["build"]["epochs"] = 5
        pass_notes.append((label, 5, ld.part(r5)))

    return dict(st=st_full, pr=pr, full=full, base=base, st_base=st_base, new=new_rows, ext=ext_rows,
                pilots=pilots, sides=sides, mem_cfg_says=mem_cfg_says, opt=opt, n_relearn_swaps=n_relearn_swaps,
                old=old, dup=dup, dup_readers=dup_readers, pass_notes=pass_notes, checks=checks)



# ---------------------------------------------------------------------------
# Section 0: what can run with the Anthropic key alone (manager, 24 Nov 2026)
# ---------------------------------------------------------------------------

#: Stages whose calls do not depend on each other's answers, so they could go through Anthropic's
#: Message Batches API (50 % off input and output, results within 24 h). The score phase, relearn and
#: the run after the swap are chains (each answer changes what is shown next): never batched.
BATCHABLE = ("write", "write2", "selfrate", "build0", "probe", "probe0", "probe_extra", "subset", "variant",
             "variant0", "judge")
#: Anthropic prices read on its pricing page on 24 Nov 2026 (USD per million tokens, input / output);
#: the batch price is half of each.
ANTHROPIC_PRICES = {"haiku-4.5": (1.00, 5.00), "haiku-5.5": (0.10, 0.50), "sonnet-4.6": (3.00, 15.00),
                    "sonnet-5.5": (2.00, 10.00)}
AGENT_BLOCK1_USD = 173.65    # legs/memrl/README.md: recommended design, block 1 (Haiku pair + haiku-4.5 -> gpt-6-luna)


def _variant(name: str, tmp: Path, **changes) -> object:
    raw = yaml.safe_load((ROOT / "config" / f"{name}.yaml").read_text(encoding="utf-8"))
    for k, v in changes.items():
        node = raw
        keys = k.split("__")
        for x in keys[:-1]:
            node = node[x]
        node[keys[-1]] = v
    f = tmp / f"{name}_{abs(hash(repr(sorted(changes.items())))) % 10**8}.yaml"
    f.write_text(yaml.safe_dump(raw, sort_keys=False), encoding="utf-8")
    return load_study(f)


def anthropic_options(tmp: Path) -> list:
    """[(label, calls, USD at list price, USD with batches where possible, Haiku 4.5 USD, hours at 4 / 8 /
    16 calls at once and 1 s per call)] for the Anthropic-only designs."""
    sys.path.insert(0, str(ROOT / "docs" / "dress_rehearsal"))
    import project_real as PR
    out = []
    for label, name, ch in (
            ("A: Haiku pair, the whole design (5 passes, both streams, 3 orders, every stage)", "study_anthropic_a", {}),
            ("A, DDXPlus only", "study_anthropic_a", {"streams": ["ddxplus"]}),
            ("A, BIRD only", "study_anthropic_a", {"streams": ["bird"]}),
            ("A, one order (0), both streams", "study_anthropic_a", {"seeds": [0]}),
            ("A, DDXPlus, one order", "study_anthropic_a", {"streams": ["ddxplus"], "seeds": [0]}),
            ("A without relearn and judge", "study_anthropic_a", {"relearn__enabled": False, "judge__enabled": False}),
            ("B: Haiku and Sonnet pairs, the whole design", "study_anthropic_b", {}),
            ("B, DDXPlus, one order", "study_anthropic_b", {"streams": ["ddxplus"], "seeds": [0]})):
        st = _variant(name, tmp, **ch)
        p = plan_calls(st)
        n = sum(sum(v.values()) for v in p["calls"].values())
        lst = sum(sum(v.values()) for v in p["usd"].values())
        bat = sum(v * (0.5 if s in BATCHABLE else 1.0) for s, d in p["usd"].items() for v in d.values())
        h45 = sum(d.get("haiku-4.5", 0.0) for d in p["usd"].values())
        hrs = []
        for W in (4, 8, 16):
            sec = PR.stage_seconds(st, W, 1.0, 0.003, 0.09)
            hrs.append(sum(v for v in sec.values() if isinstance(v, (int, float))) / 3600)
        out.append((label, n, lst, bat, h45, hrs))
    return out


def write_anthropic_section(w, rows: list) -> None:
    w("## 0. What can run with the Anthropic key alone")
    w("")
    w("Only the Anthropic key works today. Two designs use nothing else (`config/study_anthropic_a.yaml`, "
      "`config/study_anthropic_b.yaml`). Every call they make on the Haiku pair is a call the full 12-model "
      "study makes anyway: the same prompts, seeds, repeat numbers and answer-cache keys, and the cache in "
      "`runs/_cache/` is shared. So the full study later reads those answers from the cache: nothing is paid twice.")
    w("- **Option A: the Haiku pair only.** Its 2 x 2 cells (two home cells, the upgrade and the downgrade), both "
      "streams, 3 orders, every stage that needs only these two models (second bank, subsets, second wording, "
      "judge, self-rating, relearn of the two swaps, the run after the swap for the two swaps). No cross-maker cell.")
    w("- **Option B: A plus the Sonnet pair** (`sonnet-4.6` -> `sonnet-5.5`) as a 4 x 4 grid. \"Same line\" "
      "(Haiku -> Haiku, Sonnet -> Sonnet) plays the part of \"same maker\", and Haiku <-> Sonnet the part of "
      "\"cross maker\". The Sonnet cells are extra: Sonnet is not in the main study.")
    w("")
    w("Prices were read on Anthropic's pricing page on 24 Nov 2026, in USD per million tokens, input / output: "
      "Haiku 4.5 1 / 5, Haiku 5.5 0.10 / 0.50, Sonnet 4.6 3 / 15, Sonnet 5.5 2 / 10. Haiku 5.5 and Sonnet 5.5 "
      "use the newer tokenizer, about 30 % more tokens for the same text; the estimate counts it. The Message "
      "Batches API halves both prices.")
    w("")
    w("| design | calls | USD at list price | USD with batches where possible | of which Haiku 4.5 (list) | "
      "hours at 4 / 8 / 16 calls at once (1 s per call) |")
    w("|---|---:|---:|---:|---:|---|")
    for label, n, lst, bat, h45, hrs in rows:
        w(f"| {label} | {n:,} | {money(lst)} | {money(bat)} | {money(h45)} | "
          f"{hrs[0]:.0f} / {hrs[1]:.0f} / {hrs[2]:.0f} |")
    w("")
    under = [r for r in rows if r[2] <= 100 or r[3] <= 100]
    w("**What fits under USD 100** (about USD 150 of credit is on the account, and it also pays for the owner's "
      "coding agent):")
    for label, n, lst, bat, *_ in under:
        w(f"- {label}: USD {money(lst)} at list price" + (f", USD {money(bat)} with batches." if bat < lst else "."))
    w("- The whole of option A needs USD " + money(rows[0][2]) + " at list price, or USD " + money(rows[0][3]) +
      " with batches; Haiku 4.5 is about 90 % of it. Option B is far above USD 100: the Sonnet models cost 20 to 30 "
      "times Haiku 5.5.")
    w(f"- The agent leg's Anthropic block (recommended design, block 1, `legs/memrl/README.md`) is about USD "
      f"{AGENT_BLOCK1_USD:.2f}, and part of it (the swap haiku-4.5 -> gpt-6-luna) also needs the OpenAI key. It does "
      "not fit next to option A under USD 100.")
    w("")
    w("**Which stages could use the Batch API, and what building it would take (not built).** Batchable: the "
      "stages whose calls do not wait for each other's answers: " + ", ".join(f"`{s}`" for s in BATCHABLE) +
      ". Not batchable: the score phase (`build`, `selfmark`), `relearn` and the run after the swap (`online`), "
      "because each answer decides what is shown next. Building the route means, in `msr/llm.py`: collect a "
      "stage's calls, send them as Message Batches (at most 100,000 requests each), save each batch id on disk so "
      "a stop never loses a sent batch, poll until done (usually within an hour, at most 24 h), write every answer "
      "into the ordinary answer cache under the ordinary key with the batch price, and then run the stage as now: "
      "every answer comes from the cache, so results are identical to the call-by-call route. The two sessions of "
      "a probe cell become two batches sent at least the gap apart. About one day with tests (a fake batch "
      "client), plus a small paid trial.")
    w("")
    w("The wall hours count only the calls (no rate limit, a steady 1 s per call; one measured Haiku 4.5 call took "
      "3.1 s cold and one Haiku 5.5 call 0.8 s). The account's rate limits decide how many calls can run at once; "
      "the pilots start at 4.")
    w("")

def write_report(R: dict) -> tuple:
    st, pr = R["st"], R["pr"]
    T = pr.triple
    lines: list = []
    w = lines.append

    # ---- rows of the summary table ----
    ext_label = {
        ("mistral-small-3", "mistral-small-3.2"): "Extension pair Mistral Small 3 -> 3.2 (all stages, the new ones too)",
        ("deepseek-v4.1-flash", "deepseek-v4.1-flash-1017"):
            "Extension pair DeepSeek V4.1-Flash -> V4.1-Flash-1017 (all stages, the new ones too)",
    }
    st_b = R["st_base"]
    n_main_cells = len(st_b.cells)
    rl_main = len(load_relearn_pairs(R))
    rows = []
    for label, p, _raw in R["pilots"]:
        rows.append((label, p))
    rows.append(("Main grid, existing stages, 5 passes (8 models; write, build0, build, selfmark, probe, probe0, "
                 "probe_extra, subset, variant, variant0, online without the re-exploration arms)", R["base"]))
    for pair, d in R["ext"]:
        rows.append((ext_label.get(tuple(pair), f"Extension pair {pair[0]} -> {pair[1]}"), d))
    nw = R["new"]
    rows.append((f"B1 New model as judge (main grid: {n_main_cells} cells, one call per stored item per cell)",
                 nw["judge"]))
    rows.append(("B2 Writer's self-rating at write time (stage selfrate)", nw["selfrate"]))
    rows.append((f"B3 Relearn on the frozen items, registered subset (main grid: {rl_main} swaps; "
                 f"no self-tags)", nw["relearn"]))
    rows.append(("B4 Re-exploration arms reexplore_25 and reexplore_50 (in stage online)", nw["reexplore"]))
    rows.append(("B5 Second no-memory answer to each write task (stage write2); selection probabilities "
                 "(logged, 0 calls)", nw["write2"]))
    rows.append(("B6 Fresh home result per task: 0 new calls (read from the probe stage's home cells)", {}))
    for label, p, _raw in R["sides"]:
        rows.append((label, p))
    everything = add(*(p for _l, p in rows))
    fee = pr.fee(everything)
    tot = add_t(T(everything), fee)

    w("# Cost of the paid study (24 Nov 2026)")
    w("")
    w("**The Anthropic key expires on 24 Dec 2026: every Anthropic call of the study must be finished before "
      "then.**")
    w("")
    w("Written by `python scripts/cost_report.py` from the pipeline's own call counts (`msr.study.plan_calls`). "
      "No model was called. Prices are US dollars from `config/models.yaml` as of today.")
    w("")
    w("Everyday picture: a caterer counts every plate on the menu and prices it from today's list. Then he asks two "
      "questions. What if the portions come out twice as big and the special offers end (the high case)? What if "
      "they come out a bit smaller and some plates are copies of plates already made (the low case)?")
    w("")
    hp0 = only(everything, models={"haiku-4.5"})
    w("In short:")
    w(f"- Everything below (pilots, main study, side studies, OpenRouter fee): {calls(everything):,} calls, "
      f"USD {money(tot['central'])} central, between USD {money(tot['low'])} and USD {money(tot['high'])}.")
    w(f"- The main study alone (`config/study.yaml`): {calls(R['full']):,} calls, USD {money(T(R['full'])['central'])} "
      f"central, before the fee. The earlier estimate was USD {EARLIER['usd']} (section 7).")
    w(f"- Haiku 4.5 is USD {money(T(hp0)['central'])} of it ({pct(T(hp0)['central'], tot['central'])}), and it must "
      "run first.")
    w(f"- Not included: the agent leg (about USD {AGENT_LEG_USD}) and the options of section 5.")
    w("")
    write_anthropic_section(w, R["anthropic"])
    w("## 1. Summary")
    w("")
    w(HEAD)
    for label, p in rows:
        w(row(label, calls(p), T(p)))
    w(row("OpenRouter credit fee (5.5 % of the money spent through OpenRouter, paid when buying credits)", "", fee))
    w(row("**Total**", calls(everything), tot))
    w(row("*Option, not in the total:* 400 more tasks per order in the same-maker home and swap cells "
          "(`check_store_extra_tasks: 400`), with its OpenRouter fee",
          calls(R["opt"]["check_store"]), add_t(T(R["opt"]["check_store"]), pr.fee(R["opt"]["check_store"]))))
    w("")
    study_t = T(R["full"])
    w(f"- The main study is the rows from \"Main grid\" to \"B6\". They add up to {calls(R['full']):,} calls and "
      f"USD {money(study_t['central'])}, exactly what `python run.py --study config/study.yaml --estimate` prints. "
      "Each new stage is the difference between the study with and without it, so nothing is counted twice.")
    w("- The pilots and the two side studies are costed as their files are today: 3 passes and none of the new "
      "stages (their files were not changed for revision 2). See section 6 for their cost at more passes.")
    mem_s, mem_k = R["mem_cfg_says"]
    if mem_s == ["ddxplus"] and mem_k == [0]:
        w("- The labelled-item side study is costed as ruled (DDXPlus, stream order 0 only). Its file already says so.")
    else:
        w(f"- The labelled-item side study is costed as ruled (DDXPlus, stream order 0 only). Its file says streams "
          f"{mem_s} and orders {mem_k}; the ruling was applied in memory, the file was not changed.")
    w("- B6: the paired keep-or-drop check reads fresh home results that the probe stage already makes: "
      f"{st.evaluate.calib_tasks} calibration tasks x {st.probe.candidates} candidates x {st.probe.repeats} repeats "
      f"= {st.evaluate.calib_tasks * st.probe.candidates * st.probe.repeats:,} calls per owner, stream and order, "
      "inside the home cell. So it adds no call. More tasks for this check are the option in the last row "
      "(section 5).")
    w("")

    # ---- Haiku 4.5 ----
    h = "haiku-4.5"
    hp = only(everything, models={h})
    ht = T(hp)
    w("## 2. Haiku 4.5 first")
    w("")
    w(f"Haiku 4.5 may retire from {HAIKU45_EARLIEST_RETIREMENT} (60 days' notice, no guaranteed date), so all its "
      "calls run first. Its fee share is 0 (Anthropic is paid directly).")
    w("")
    w(HEAD)
    parts_h = [("Pilots", add(*(p for _l, p, _r in R["pilots"]))),
               ("Main grid, existing stages", R["base"]),
               ("New stages (B1 to B5)", add(*R["new"].values())),
               ("Side studies", add(*(p for _l, p, _r in R["sides"])))]
    for label, p in parts_h:
        q = only(p, models={h})
        if calls(q):
            w(row(label, calls(q), T(q)))
    w(row("**Haiku 4.5 in all**", calls(hp), ht))
    w(f"| Share of the total (fee included) | {pct(calls(hp), calls(everything))} | {pct(ht['low'], tot['low'])} | "
      f"{pct(ht['central'], tot['central'])} | {pct(ht['high'], tot['high'])} |")
    w("")
    w(f"Haiku 4.5 makes {pct(calls(hp), calls(everything))} of the calls but {pct(ht['central'], tot['central'])} "
      "of the money (central case): it is the dearest model by far (USD 1 / 5 per million tokens).")
    w("")

    # ---- by stage ----
    w("## 3. By stage and by provider")
    w("")
    w("By stage (the main study, all 12 models), then the pilots and side studies as single lines:")
    w("")
    w(HEAD)
    for s in STAGES:
        q = only(R["full"], stages={s})
        if calls(q):
            w(row(f"`{s}`", calls(q), T(q)))
    w(row("Pilots (all stages)", calls(add(*(p for _l, p, _r in R["pilots"]))),
          T(add(*(p for _l, p, _r in R["pilots"])))))
    w(row("Side studies (all stages)", calls(add(*(p for _l, p, _r in R["sides"]))),
          T(add(*(p for _l, p, _r in R["sides"])))))
    w(row("OpenRouter credit fee (5.5 %)", "", fee))
    w(row("**Total**", calls(everything), tot))
    w("")
    w("By provider and host (everything in the total):")
    w("")
    w(HEAD)
    hosts: dict = {}
    for (s, m), v in everything.items():
        hosts.setdefault(pr.host(m), {})[(s, m)] = v
    order = ["Anthropic", "OpenAI", "OpenRouter -> DeepInfra", "OpenRouter -> Parasail"]
    for hname in order + sorted(set(hosts) - set(order)):
        if hname in hosts:
            w(row(hname, calls(hosts[hname]), T(hosts[hname])))
    w(row("OpenRouter credit fee (5.5 %)", "", fee))
    w(row("**Total**", calls(everything), tot))
    w("")
    w("DeepInfra serves Qwen3.5-27B, Qwen3.8-27B (both temperatures), both Mistral models and both DeepSeek models; "
      "Parasail serves the two Gemma models. Both are reached through OpenRouter, so the fee applies to both.")
    w("")

    # ---- the three cases ----
    w("## 4. How low, central and high are made")
    w("")
    w("- **Central**: the pipeline's count as it is. Prompt sizes are measured on the real prompts "
      "(`data/prompt_sizes.json`, characters / 4). Answer sizes are the study's own guesses "
      f"(`estimate:` {st.estimate.out_tokens['ddxplus']:g} tokens on DDXPlus, {st.estimate.out_tokens['bird']:g} on "
      f"BIRD, {st.estimate.selfmark_out_tokens:g} for a tag or a rating; Haiku 5.5 counts 30 % more tokens). Prices "
      "are today's, from `config/models.yaml`.")
    w(f"- **High**: answers twice as long, prompts 10 % longer, every discounted price back at its list price "
      "(Qwen3.8-27B 0.20 / 2.50 instead of 0.15 / 1.875, at both temperatures; both DeepSeek models 0.20 / 0.60), "
      "and 3 % of calls asked again after an error.")
    w("- **Low**: answers a quarter shorter, and 10 % of the money saved because identical prompts come back from the "
      "answer cache (for example, a reader shown two owners' items with the same text).")
    w("- The count is of call invocations. A call whose exact prompt was already answered comes from the cache and "
      "costs nothing, so the real spend is at most the central figure, apart from the high case's assumptions.")
    w("- The OpenRouter fee is 5.5 % of each case's OpenRouter money. No batch discount is assumed.")
    w("")

    # ---- options ----
    o = R["opt"]
    w("## 5. Options and their prices (not in the total)")
    w("")
    w("Each figure includes its 5.5 % OpenRouter fee.")
    w("")
    w(HEAD)
    for label, p in (
            ("Relearn with the reader's own self-tags (`relearn.self_tag: true`; doubles the relearn calls)",
             o["relearn_tag"]),
            (f"Relearn on every swap (`relearn.pairs: swaps`, {R['n_relearn_swaps']} swaps instead of 20)",
             o["relearn_swaps"]),
            ("Both of the above together", o["relearn_swaps_tag"]),
            ("400 more tasks per order in the same-maker home and swap cells (`check_store_extra_tasks: 400`)",
             o["check_store"]),
            ("The same, without the two extra home repeats on the new tasks", o["check_store_no_extra"])):
        w(row(label, calls(p), add_t(T(p), pr.fee(p))))
    w("")
    sm_swaps = [c for c in st.cells if c[0] != c[1] and st.kind(*c) == "same_family"]
    w("About the extra tasks for the keep-or-drop check (`check_store_extra_tasks`):")
    w(f"- It is an option that is costed, not built: `run.py` stops if it is above 0. As counted, it adds the new "
      f"tasks to the {len(sm_swaps)} same-maker swaps and to the home cells of their {len({m for c in sm_swaps for m in c})} "
      "models (with the two extra home repeats and the two no-memory repeats, as the home cells have now). "
      "The last row shows it without the extra home repeats.")
    w("- The study uses 1,500 tasks per stream order (750 build, 500 probe, 250 test). DDXPlus has 1,764 tasks, so 264 "
      "are unused in each order. BIRD has 1,534; one is excluded, so 1,533 are usable and only 33 are unused.")
    w("- So 400 more tasks per order exist only if the 250 test tasks are reused as well. On BIRD that gives 283 at most "
      "(33 + 250). The option as worded (400) cannot be met on BIRD without reusing tasks; on DDXPlus it needs 136 of "
      "the test tasks.")
    w("")

    # ---- other notes ----
    w("## 6. What is not in the total, and other notes")
    w("")
    w(f"- **The agent leg** (MemRL's own code, the recommended design, about USD {AGENT_LEG_USD}) is not included. "
      "The manager adds it.")
    w(f"- **The forecast's {FORECAST_CALLS:,} calls per swap day are already in the study**: they are the new model's "
      "no-memory answers in stages `write`, `build0` and `probe0`, which every model makes, the extension models too.")
    pn = R["pass_notes"]
    w("- **Passes in the pilots and side studies.** The pilot rule picks the passes (the first of 3 to 6 at which 150 "
      "of the 250 items have 5 or more visits), so a pilot may have to run past 3 passes. At more passes (central, "
      "without the fee):")
    for label, k, p in pn:
        w(f"  - {label} at {k} passes: {calls(p):,} calls, USD {money(T(p)['central'])}.")
    w("  If the pilot also has to restart at exploration 0.5, Haiku 4.5's DDXPlus score phase runs a second time.")
    dt = T(R["dup"])
    w(f"- **A known overcount (about {calls(R['dup']):,} calls, USD {money(dt['central'])} central).** "
      f"{len(R['dup_readers'])} models ({', '.join(NICE.get(m, m) for m in R['dup_readers'])}) read in two online cells. Their `none` run "
      "(no memory) and their `own` run (their own bank) do not depend on the owner, so the second cell asks exactly "
      "the same prompts, and the answers come from the cache. The plan counts them twice. This is within \"at most\".")
    w("- **The spending cap** in `config/models.yaml` is USD 30 today. It must be raised, step by step, with the "
      "owner's yes before each paid run.")
    w("")

    # ---- earlier estimate ----
    old, base = R["old"], R["base"]
    ot = T(old)
    passes_d = T(base)["central"] - ot["central"]
    new_d = T(add(*R["new"].values()))["central"]
    ext_d = T(add(*(d for _p, d in R["ext"])))["central"]
    w("## 7. Against the earlier estimate (USD 670)")
    w("")
    w(f"The earlier estimate was USD {EARLIER['usd']} for {EARLIER['calls']:,} calls: 8 models at 3 passes, without "
      f"the new stages, without the fee. The same design priced today gives {calls(old):,} calls and "
      f"USD {money(ot['central'])}. The study now costs USD {money(study_t['central'])} ({calls(R['full']):,} calls), "
      "also without the fee:")
    w(f"- 3 passes -> 5 passes: + USD {money(passes_d)} (more score-phase calls and self-tags; the pilot may still "
      "set 3 or 4).")
    w(f"- the new stages B1 to B5 on the main grid: + USD {money(new_d)} (relearn is most of it).")
    w(f"- the two extension pairs, all stages: + USD {money(ext_d)} (cheap models: many calls, little money).")
    w("")
    w("## 8. Checks made by the script")
    w("")
    for c in R["checks"]:
        w(f"- {c}.")
    w(f"- the central figure of every row is recomputed from tokens and prices and equals `plan_calls`' own dollars "
      "for the full study.")
    w("")
    summary = {"rows": [(label, calls(p), T(p)) for label, p in rows], "fee": fee, "total": (calls(everything), tot),
               "haiku": (calls(hp), ht), "option": (calls(o["check_store"]),
                                                  add_t(T(o["check_store"]), pr.fee(o["check_store"])))}
    return "\n".join(lines) + "\n", summary


def load_relearn_pairs(R: dict) -> list:
    """The registered relearn swaps of the main grid (no extension pairs), from a load of the main grid."""
    return [p for p in R["st"].relearn.pairs if p[0] in R["st"].main_models and p[1] in R["st"].main_models]


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out", default=str(DEFAULT_OUT), help="where the markdown goes")
    a = ap.parse_args(argv)
    with tempfile.TemporaryDirectory(prefix="cost_report_") as tmp:
        R = build_report(Path(tmp))
        R["anthropic"] = anthropic_options(Path(tmp))
    text, s = write_report(R)
    out = Path(a.out)
    out.write_text(text, encoding="utf-8")
    print(f"wrote {out.relative_to(ROOT) if out.is_relative_to(ROOT) else out}")
    w = max(len(l) for l, _n, _t in s["rows"])
    w = min(w, 70)
    print(f"{'':<{w}} {'calls':>10} {'low':>9} {'central':>9} {'high':>9}")
    for label, n, t in s["rows"]:
        print(f"{label[:w]:<{w}} {n:>10,} {t['low']:>9.2f} {t['central']:>9.2f} {t['high']:>9.2f}")
    f = s["fee"]
    print(f"{'OpenRouter credit fee (5.5 %)':<{w}} {'':>10} {f['low']:>9.2f} {f['central']:>9.2f} {f['high']:>9.2f}")
    n, t = s["total"]
    print(f"{'TOTAL':<{w}} {n:>10,} {t['low']:>9.2f} {t['central']:>9.2f} {t['high']:>9.2f}")
    n, t = s["option"]
    print(f"{'option: check_store 400 (not in total)':<{w}} {n:>10,} {t['low']:>9.2f} {t['central']:>9.2f} "
          f"{t['high']:>9.2f}")
    n, t = s["haiku"]
    print(f"Haiku 4.5: {n:,} calls, USD {t['low']:.2f} / {t['central']:.2f} / {t['high']:.2f}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
