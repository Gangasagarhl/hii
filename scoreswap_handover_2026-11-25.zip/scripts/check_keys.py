"""Say which API keys are present in .env (never shows the keys themselves)."""
import os, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from msr.llm import load_config, load_env, opencode_key, provider_key

load_env()
cfg = load_config()
needed = {}
for name, m in cfg["models"].items():
    needed.setdefault(m["provider"], []).append(name)
if cfg.get("embedding", {}).get("provider") not in (None, "local"):
    needed.setdefault(cfg["embedding"]["provider"], []).append("embedding")
for prov, models in needed.items():
    env = (cfg["providers"].get(prov) or {}).get("key_env")
    if not env:
        print(f"{'(no key needed)':20s} {'ok':8s} {prov}: {', '.join(models)}")
        continue
    if os.environ.get(env):
        state = "present"
    elif provider_key(cfg, prov):
        state = "opencode"   # no key in .env; the key held by the opencode tool is used
    else:
        state = "MISSING"
    print(f"{env:20s} {state:8s} needed for: {', '.join(models)}")
