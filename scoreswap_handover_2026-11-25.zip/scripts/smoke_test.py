"""One tiny call to each model whose key is present, to prove the API route works.

  python scripts/smoke_test.py            # shows what it would do, spends nothing
  python scripts/smoke_test.py --yes      # really calls (a fraction of a cent per model)
  python scripts/smoke_test.py --yes --only haiku-4.5 haiku-5.5
  python scripts/smoke_test.py --yes --fresh   # ask again even if an answer is cached

Checks: the model answers, the exact model ID it reports, that our settings
(thinking off, no temperature) are accepted, tokens and cost. Also:
- the served-model check (msr/llm.py check_served): the model that answered must be the one
  asked for, and on OpenRouter the host must be the pinned one; the served model and host are
  printed with the result of the pin check;
- for every model whose settings switch reasoning off (extra_body.reasoning.enabled false,
  reasoning.effort none, reasoning_effort "none", extra_body.enable_thinking false, Anthropic
  thinking "disabled" or "between_tools"), the reply must carry NO reasoning: any reasoning
  token or any reasoning field in the reply fails the test loudly. Qwen3.8 is the known risk
  (OpenRouter shows reasoning on by default for it).
The exit code is 1 when any model fails, 0 otherwise. Without --yes nothing is called.
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from msr.llm import (LLM, ServedModelMismatch, load_config, load_env, pinned_hosts,  # noqa: E402
                     provider_key)

PROMPT = "Reply with exactly one word: OK"
MAX_TOKENS = 16


def reasoning_off_setting(m: dict) -> str | None:
    """The setting that switches a model's reasoning off, in words, or None when it has none."""
    eb = m.get("extra_body") or {}
    r = eb.get("reasoning")
    if isinstance(r, dict):
        if r.get("enabled") is False:
            return "extra_body.reasoning.enabled: false"
        if str(r.get("effort", "")).lower() == "none":
            return "extra_body.reasoning.effort: none"
    if str(m.get("reasoning_effort", "")).lower() == "none":
        return 'reasoning_effort: "none"'
    if str(eb.get("reasoning_effort", "")).lower() == "none":
        return 'extra_body.reasoning_effort: "none"'
    if eb.get("enable_thinking") is False:
        return "extra_body.enable_thinking: false"
    t = m.get("anthropic_thinking")
    if isinstance(t, dict) and t.get("type") in ("disabled", "between_tools"):
        # between_tools is Sonnet 5.5's thinking-off setting (it cannot take "disabled").
        return f"anthropic_thinking: {t.get('type')}"
    return None


def pin_line(m: dict, served_by: str | None) -> str:
    """The pin check's result, in words (check_served has already stopped a wrong host)."""
    hosts = pinned_hosts(m) if m.get("provider") == "openrouter" else []
    only = ((m.get("extra_body") or {}).get("provider") or {}).get("only")
    if not hosts:
        return "host pin: none set"
    if not served_by:
        return f"host pin {only}: NOT CHECKED (the reply did not name the host)"
    return f"host pin {only}: ok (served by {served_by})"


def check_one(llm: LLM, cfg: dict, name: str, repeat: int = 0) -> tuple[bool, list[str]]:
    """Call one model once and judge the reply. Returns (passed, lines to print)."""
    m = cfg["models"][name]
    pad = " " * 15
    try:
        r = llm.call(name, user=PROMPT, repeat=repeat, max_tokens=MAX_TOKENS, meta={"purpose": "smoke_test"})
    except ServedModelMismatch as e:
        return False, [f"{name:14s} FAILED served-model check: {e}"]
    except Exception as e:  # show the API's own message, it names the bad setting
        return False, [f"{name:14s} FAILED {type(e).__name__}: {str(e)[:300]}"]
    lines = [f"{name:14s} OK  answer={r.answer.strip()!r:10s} model_id={r.model_id}  "
             f"in={r.tokens_in} out={r.tokens_out} cost=${r.cost_usd:.6f} "
             f"{'(cached)' if r.cached else f'{r.latency_s}s'} stop={r.stop_reason}",
             f"{pad}served model: {r.model_id} (asked for {m['api_model']}): ok; "
             f"served by: {r.served_by or 'not named'}"]
    if m.get("provider") == "openrouter":
        lines.append(pad + pin_line(m, r.served_by))
    rt, rf = r.reasoning_tokens, r.reasoning_fields
    tokens = "not reported" if rt is None else str(rt)
    off = reasoning_off_setting(m)
    if not off:
        lines.append(f"{pad}reasoning: no off switch in the settings; reasoning tokens {tokens}")
        return True, lines
    problems = []
    if rt is not None and rt > 0:
        problems.append(f"{rt} reasoning tokens came back")
    if rf:
        problems.append("the reply carried " + ", ".join(rf))
    if rf is None:
        problems.append("the reply's reasoning fields were not recorded (an answer cached by older code); "
                        "run again with --fresh")
    if problems:
        lines[0] = f"{name:14s} FAILED reasoning is switched off ({off}) but " + "; ".join(problems)
        return False, lines
    lines.append(f"{pad}reasoning off ({off}): confirmed, reasoning tokens {tokens}, no reasoning field")
    return True, lines


def main(argv=None, cfg: dict | None = None, llm: LLM | None = None, out=print) -> int:
    ap = argparse.ArgumentParser(description="One tiny call per model (needs --yes to spend).")
    ap.add_argument("--yes", action="store_true", help="really call the APIs")
    ap.add_argument("--only", nargs="*", help="model names to test")
    ap.add_argument("--fresh", action="store_true",
                    help="ask again even if an earlier answer is cached (a new repeat number)")
    a = ap.parse_args(argv)

    load_env()
    cfg = cfg or load_config()
    names = a.only or list(cfg["models"])
    llm = llm or LLM(run_name="smoke_test", max_tokens=MAX_TOKENS, config=cfg)
    repeat = int(time.time()) if a.fresh else 0
    failed = []
    for name in names:
        m = cfg["models"].get(name)
        if m is None:
            out(f"{name:14s} FAILED: no such model in config/models.yaml")
            failed.append(name)
            continue
        if m["provider"] == "sim":
            out(f"{name:14s} simulated model (free, no key): nothing to test here")
            continue
        key_env = (cfg["providers"].get(m["provider"]) or {}).get("key_env")
        if key_env and not provider_key(cfg, m["provider"]):
            out(f"{name:14s} skipped (no {key_env} in .env)")
            continue
        if not a.yes:
            off = reasoning_off_setting(m)
            hosts = pinned_hosts(m) if m["provider"] == "openrouter" else []
            out(f"{name:14s} would call {m['api_model']} (worst case "
                f"${llm.worst_case_cost(name, PROMPT, None, MAX_TOKENS):.6f})"
                + (f"; would check reasoning is off ({off})" if off else "")
                + (f"; would check the host pin {'/'.join(hosts)}" if hosts else ""))
            continue
        ok, lines = check_one(llm, cfg, name, repeat=repeat)
        for line in lines:
            out(line)
        if not ok:
            failed.append(name)
    if a.yes:
        out(f"Total spent so far in this folder: ${llm.spent():.6f}")
    if failed:
        msg = (f"SMOKE TEST FAILED for {len(failed)} model(s): {', '.join(failed)}. "
               f"Do not start a paid run until each is fixed (see the lines above).")
        out("!" * 80)
        out(msg)
        out("!" * 80)
        print(msg, file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
