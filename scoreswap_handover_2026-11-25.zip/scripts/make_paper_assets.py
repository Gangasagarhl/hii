"""Build every number, table and figure of the paper from one study's result files.

    python scripts/make_paper_assets.py --study sim            (free practice study)
    python scripts/make_paper_assets.py --study study --draws 10000

Steps: run the pre-registered analysis (msr.analysis -> runs/<study>/analysis/), draw the figures
(msr.figures -> paper/assets/*.pdf|png), then write
  paper/assets/numbers.tex       one LaTeX macro per headline number, each with its source CSV row
  paper/assets/MACROS.md         every macro with its value, its meaning and its source (for the authors)
  paper/assets/table_main.tex    one row per ordered pair: theta (the retained ranking signal), D, R, main arms
  paper/assets/table_groups.tex  the 12 primary tests under Holm (revision 2: PC1 drop, material drop and no
                                 material drop, PC2, in each swap group), with each group's between-pair SD and
                                 the prediction interval for a new pair
  paper/assets/table_secondary.tex  PC3 and PC4 (secondary, outside the family), with the owner-reader base-rate
                                 gap and the sensitivity with the level target at the reader's with-item success
  paper/assets/table_stakes.tex  what is at stake, in success points, per swap group (home and after the swap)
  paper/assets/table_arms.tex    every arm by swap group (first-shown success, level-corrected log score)
  paper/assets/table_costs.tex   calls, tokens and dollars per model, and per swap-day rule
  paper/assets/table_decision.tex  (revision 3, E4) what to do on swap day by kind of swap and check budget:
                                 the registered tests and the cross-fitted best check rule only; descriptive
and the three additions, each with its tables in runs/<study>/analysis/ and its figures here:
  msr.theory      the transfer decomposition        decomp_*.csv (law_*.csv before the renaming), fig_decomp_*
  msr.forecast    the forecast before the swap      forecast_*.csv,   fig_forecast_*
  msr.sequential  the stop-when-sure swap-day check sequential_*.csv, fig_sequential_*
Their headline numbers join numbers.tex under the same prefix. An addition the study cannot
support (too few models, one repeat only) is skipped with a one-line note, in the printout and as
a comment in numbers.tex.

Labels follow the study kind that msr.analysis writes into meta.csv (study_kind):
  simulated    (a simulated model in the study)        macros \\Sim..., banner "SIMULATED DATA"
  preliminary  (a model through the opencode_cli wrapper) macros \\Pre..., banner "PRELIMINARY: free
               models through a wrapper"
  real         (anything else)                         no prefix, no banner
so a simulated or preliminary number can never be mistaken for a real one. The tables need
\\usepackage{booktabs}.
"""
from __future__ import annotations

import argparse
import json
import csv
import math
import re
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

DIGITS = ("Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine")
GROUPS = ("upgrade", "downgrade", "cross")
GROUP_TEX = {"upgrade": "Same-maker upgrades", "downgrade": "Same-maker downgrades", "cross": "Cross-maker",
             "same_maker": "All same-maker", "all_swaps": "All swaps", "home": "Home (self-swap)",
             "upgrade_core": "Same-maker upgrades, core grid", "downgrade_core": "Same-maker downgrades, core grid"}
#: revision 3 (E3): the displayed words of the decomposition factor (CSV columns and macro names keep "order")
AGREEMENT = "retained agreement"
NOT_ESTIMATED = "not estimated (reader's spread below z = 2 on the calibration tasks)"
NOT_VALID = "not valid: repeats not independent"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def read_csv(path: Path) -> list:
    if not path.exists():
        return []
    with open(path, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def num(v) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return float("nan")


def fin(v) -> bool:
    return math.isfinite(num(v))


def camel(*parts) -> str:
    """Letters only (LaTeX macro names): 'PC1' -> 'PCOne', 'fixed_0.5' -> 'FixedZeroFive', 'k32' -> 'KThreeTwo'."""
    out = []
    for p in parts:
        p = str(p)
        buf = ""
        for ch in p:
            if ch.isdigit():
                buf += " " + DIGITS[int(ch)] + " "
            elif ch.isalpha():
                buf += ch
            else:
                buf += " "
        for w in buf.split():
            out.append(w[0].upper() + w[1:])
    return "".join(out)


def tex_escape(s: str) -> str:
    s = str(s)
    for a, b in (("\\", r"\textbackslash{}"), ("&", r"\&"), ("%", r"\%"), ("#", r"\#"), ("_", r"\_"),
                 ("{", r"\{"), ("}", r"\}"), ("$", r"\$"), ("~", r"\textasciitilde{}"), ("^", r"\^{}")):
        s = s.replace(a, b)
    s = s.replace("->", "→").replace(">=", "≥").replace("<=", "≤")
    for a, b in (("→", r"$\to$"), ("≥", r"$\geq$"), ("≤", r"$\leq$"), ("<", r"$<$"), (">", r"$>$"),
                 ("−", "-"), ("λ", r"$\lambda$"), ("τ", r"$\tau$"), ("κ", r"$\kappa$")):
        s = s.replace(a, b)
    return s


def lint_tex(text: str) -> list:
    """Problems that break a LaTeX build in a generated table or macro file: an unescaped %, # or _ (outside
    $...$; the "}% source:" comment after a macro definition is allowed), and tabular rows whose number of
    unescaped & does not match the column count. Returns [(line number, problem, line)]."""
    probs = []
    ncols = None
    for i, line in enumerate(text.splitlines(), 1):
        st = line.strip()
        if not st or st.startswith("%"):
            continue
        m = re.match(r"\\begin\{tabular\}\{([^}]*)\}", st)
        if m:
            ncols = len(re.findall(r"[lrcX]|p\{", m.group(1)))
            continue
        body = line
        cut = re.search(r"(?<!\\)%", body)
        if cut:
            if st.startswith("\\newcommand") and body[:cut.start()].rstrip().endswith("}"):
                body = body[:cut.start()]
            else:
                probs.append((i, "unescaped %", line))
                body = body[:cut.start()]
        plain = re.sub(r"(?<!\\)\$[^$]*(?<!\\)\$", "", body)
        for ch in ("#", "_"):
            if re.search(r"(?<!\\)" + re.escape(ch), plain):
                probs.append((i, f"unescaped {ch}", line))
        if st.startswith("\\newcommand") and re.search(r"(?<!\\)&", plain):
            probs.append((i, "unescaped & in a macro", line))
        if ncols and st.endswith("\\\\") and not st.startswith(("\\multicolumn", "\\toprule", "\\midrule",
                                                                    "\\bottomrule")):
            amp = len(re.findall(r"(?<!\\)&", plain))
            span = amp + 1 + sum(int(n) - 1 for n in re.findall(r"\\multicolumn\{(\d+)\}", plain))
            if span != ncols:
                probs.append((i, f"{span} columns for a {ncols}-column tabular", line))
        if st.startswith("\\end{tabular}"):
            ncols = None
    return probs


def fmt(v, d=3) -> str:
    x = num(v)
    if not math.isfinite(x):
        return "--" if not (isinstance(v, str) and v in ("inf", "-inf")) else (r"$\infty$" if v == "inf" else r"$-\infty$")
    s = f"{x:.{d}f}"
    return s.replace("-", "$-$") if s.startswith("-") else s


def fmt_p(v) -> str:
    x = num(v)
    if not math.isfinite(x):
        return "--"
    return "$<$0.0001" if x < 1e-4 else f"{x:.4f}"


def ci_tex(r: dict, k: str, lo: str, hi: str, d=3) -> str:
    if not fin(r.get(k)):
        return "--"
    if r.get(lo) == "-inf" or r.get(hi) == "inf":
        return f"{fmt(r[k], d)} [unbounded]"
    return f"{fmt(r[k], d)} [{fmt(r.get(lo), d)}, {fmt(r.get(hi), d)}]"


def val_or_inf(v, d=3) -> str:
    """fmt, but an unbounded end ('inf' / '-inf' in the CSV) is printed as infinity, not a dash."""
    return fmt(v, d)


def has_val(v) -> bool:
    """A number or an unbounded end ('inf' / '-inf')."""
    return fin(v) or (isinstance(v, str) and v in ("inf", "-inf"))


#: words of the round-1 decisions that revision 2 withdrew (the 5-point "practical size" reading of PC2)
OLD_DECISION_WORDS = (" (practical size, >= 5 points)", " (detected, below the 5-point threshold)")
#: revision 2: the primary family is PC1 (three members) and PC2; PC3 and PC4 are secondary
PRIMARY_COMPARISONS = ("PC1-drop", "PC1-MD", "PC1-NI", "PC2")
SECONDARY_COMPARISONS = ("PC3", "PC4")
#: the additivity assumption under which PC3 / PC4 (swap minus home) identify a swap effect (R6 W7)
ADDITIVITY = ("swap minus home measures an effect of the swap only if a rule's gain over keep adds up as "
              "(gain at home) + (effect of the swap); a difference in base rate between owner and reader moves "
              "the contrast by itself")


def reading(r: dict) -> str:
    """The registered reading of one test row: its label (revision 2), else its decision without the
    withdrawn 'practical size' words (older result files)."""
    lab = (r.get("label") or "").strip()
    if lab:
        return lab
    d = r.get("decision", "") or ""
    for w in OLD_DECISION_WORDS:
        d = d.replace(w, "")
    return d


def is_secondary(r: dict) -> bool:
    """PC3 / PC4 rows (role 'secondary'; in files written before revision 2, by their comparison)."""
    role = (r.get("role") or "").strip().lower()
    if role:
        return role == "secondary"
    return r.get("comparison") in SECONDARY_COMPARISONS


def truthy(v) -> bool:
    return str(v).strip().lower() in ("true", "1", "yes")


def not_valid(v) -> bool:
    """A cell that carries the later-session check's words (spec E6) instead of a number."""
    return isinstance(v, str) and v.strip().lower().startswith("not valid")


def status_words(s) -> str:
    """The displayed words of an agreement (order) status (revision 3, E3): 'defined' stays, the old and new
    'not identifiable' / 'not estimated' statuses become NOT_ESTIMATED, 'not valid ...' is kept as it is."""
    s = (s or "").strip()
    low = s.lower()
    if low.startswith("not identifiable") or low.startswith("not estimated"):
        return NOT_ESTIMATED
    return s


def agreement_cell(v, status=None, d=3) -> str | None:
    """The printed value of an agreement / stakes / cw_agreement cell: the 'not valid' words when the cell (or its
    status) carries them, a number (an unbounded end as infinity) when there is one, else None."""
    if not_valid(v):
        return tex_escape(v.strip())
    if status is not None and not_valid(status):
        return tex_escape(str(status).strip())
    if has_val(v):
        return val_or_inf(v, d)
    return None


def holm_adjust(ps: list) -> list:
    """Holm step-down adjusted p-values, in the input order."""
    m = len(ps)
    order = sorted(range(m), key=lambda i: ps[i])
    out = [float("nan")] * m
    run = 0.0
    for rank, i in enumerate(order):
        run = max(run, min(1.0, (m - rank) * ps[i]))
        out[i] = run
    return out


class Macros:
    def __init__(self, prefix: str):
        self.prefix = prefix
        self.lines: list = []
        self.names: set = set()
        self.entries: list = []          # (name, value, meaning, source) for MACROS.md
        self.notes: list = []            # one-line comments for the head of numbers.tex

    def add(self, name_parts, value: str, source: str, meaning: str = "") -> None:
        name = self.prefix + camel(*name_parts)
        if name in self.names:
            raise ValueError(f"duplicate macro {name}")
        self.names.add(name)
        self.lines.append(f"\\newcommand*{{\\{name}}}{{{value}}}% source: {source}")
        self.entries.append((name, value, meaning or guess_meaning(name_parts), source))

    def add_raw(self, name: str, value: str, source: str, meaning: str = "") -> None:
        """A macro whose full name (prefix included) is given by its producer (construct_macros.csv)."""
        if name in self.names:
            raise ValueError(f"duplicate macro {name}")
        self.names.add(name)
        self.lines.append(f"\\newcommand*{{\\{name}}}{{{value}}}% source: {source}")
        self.entries.append((name, value, meaning, source))

    def text(self) -> str:
        return "\n".join(self.lines)


GROUP_WORDS = {"upgrade": "the same-maker upgrades", "downgrade": "the same-maker downgrades",
               "cross": "the cross-maker swaps", "all_swaps": "all swaps", "same_maker": "all same-maker swaps",
               "same_family": "all same-maker swaps", "home": "the home cells (self-swap reference)",
               "upgrade_core": "the same-maker upgrades of the core grid (without the two extension pairs)",
               "downgrade_core": "the same-maker downgrades of the core grid (without the two extension pairs)"}


def guess_meaning(parts) -> str:
    """A plain meaning for a macro from its name parts (used when the caller gives none)."""
    p = [str(x) for x in parts]
    g = next((GROUP_WORDS[x] for x in p if x in GROUP_WORDS), "")
    tail = {"Lo": "lower end of its 95 % interval", "Hi": "upper end of its 95 % interval",
            "P": "p-value", "Decision": "decision label"}
    last = p[-1] if p else ""
    return (f"{' '.join(p)}" + (f" ({g})" if g else "") + (f"; {tail[last]}" if last in tail else ""))


KIND = {  # study kind -> (macro prefix, banner); written by msr.analysis into meta.csv (study_kind)
    "simulated": ("Sim", "SIMULATED DATA"),
    "preliminary": ("Pre", "PRELIMINARY: free models through a wrapper"),
    "real": ("", ""),
}


def norm_kind(kind) -> str:
    """'simulated' | 'preliminary' | 'real' (True / False accepted for simulated / real)."""
    if kind is True:
        return "simulated"
    if kind in (False, None, ""):
        return "real"
    return kind if kind in KIND else "real"


def banner(kind, ncols: int) -> str:
    text = KIND[norm_kind(kind)][1]
    if not text:
        return ""
    tail = {"simulated": "simulated models with a known truth; not a result",
            "preliminary": "not the pre-registered models or routes; not a confirmatory result"}[norm_kind(kind)]
    return f"\\multicolumn{{{ncols}}}{{c}}{{\\textbf{{{tex_escape(text)}}} --- {tail}}}\\\\\n\\midrule\n"


def header_comment(name: str, study: str, kind, what: str) -> str:
    lines = [f"% {name}: {what}",
             f"% Made by scripts/make_paper_assets.py from runs/{study}/analysis/ (do not edit by hand).",
             "% Needs \\usepackage{booktabs}."]
    text = KIND[norm_kind(kind)][1]
    if text:
        lines.insert(0, f"% {text}: study kind {norm_kind(kind)}. Not a confirmatory result.")
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
# numbers.tex
# ---------------------------------------------------------------------------


def write_numbers(adir: Path, out: Path, study: str, kind, notes: list | None = None) -> Path:
    kind = norm_kind(kind)
    mc = Macros(KIND[kind][0])
    meta = {r["key"]: r["value"] for r in read_csv(adir / "meta.csv")}
    H = meta.get("headline_family", "ema_grade")
    for key, parts, mean in (("n_swaps", ("N", "Swaps"), "number of ordered swaps"),
                             ("n_upgrades", ("N", "Upgrades"), "number of same-maker upgrades"),
                             ("n_downgrades", ("N", "Downgrades"), "number of same-maker downgrades"),
                             ("n_cross", ("N", "Cross"), "number of cross-maker swaps"),
                             ("bootstrap_draws", ("N", "Draws"), "task-only bootstrap draws (secondary intervals)"),
                             ("primary_k", ("Primary", "K"), "fresh checks k of the calibrated arm in PC4"),
                             ("primary_family_size", ("N", "Primary", "Tests"), "members of the primary Holm family"),
                             ("task_clusters", ("N", "Task", "Clusters"), "task-id clusters of the two-way variance"),
                             ("item_clusters", ("N", "Item", "Clusters"), "item clusters of the two-way variance")):
        if key in meta:
            mc.add(parts, meta[key], f"meta.csv key={key}", mean)
    mc.add(("N", "Models"), str(len(meta.get("models", "").split())), "meta.csv key=models (count)", "number of models")
    # ---- the primary tests (revision 2: 12 = PC1 drop, material drop, no material drop and PC2, x 3 groups,
    # each PC1 member an intersection-union test with the home-signal test); PC3 / PC4 rows are secondary
    tests = read_csv(adir / "primary_tests.csv")
    fam_rows = [r for r in tests if truthy(r.get("in_family"))]
    fam_n = meta.get("primary_family_size") or str(len(fam_rows))
    hyp_words = {"PC1-drop": "drop test on theta (H1 theta < 1, with the home-signal test and the self-swap reference)",
                 "PC1-MD": "material-drop test (H1 theta < 0.75, with the home-signal test)",
                 "PC1-NI": "no-material-drop test (H1 theta > 0.75, with the home-signal test)",
                 "PC2": "keep minus wipe, first-shown success after the swap",
                 "PC3": "fixed discount minus keep, level-corrected log score, swap minus home",
                 "PC4": "recal minus keep (and minus wipe), level-corrected log score, swap minus home"}
    for r in tests:
        base = (r["comparison"], r["group"])
        g = GROUP_WORDS.get(r["group"], r["group"])
        sec = is_secondary(r)
        hw = ("secondary, outside the Holm family: " if sec else "") + hyp_words.get(r["comparison"], r["comparison"])
        src = f"primary_tests.csv test={r['test']}"
        if not r["comparison"].startswith("PC1"):
            for col, nm, d, what in (("est", "Est", 4, "estimate"), ("lo", "Lo", 4, "lower end of the two-way 95 % CI"),
                                     ("hi", "Hi", 4, "upper end of the two-way 95 % CI")):
                if fin(r.get(col)):
                    mc.add(base + (nm,), fmt(r[col], d), f"{src} column={col}", f"{hw}, {g}: {what}")
        mc.add(base + ("P",), fmt_p(r.get("p_holm_input")), f"{src} column=p_holm_input",
               f"{hw}, {g}: " + ("its unadjusted p (not in the family)" if sec else "the p-value entering Holm"))
        mc.add(base + ("P", "Holm"), fmt_p(r.get("holm_adjusted_p")), f"{src} column=holm_adjusted_p",
               f"{hw}, {g}: " + ("no Holm adjustment (not in the family)" if sec
                                 else f"Holm-adjusted p (family of {fam_n})"))
        mc.add(base + ("Decision",), tex_escape(reading(r)), f"{src} column={'label' if r.get('label') else 'decision'}",
               f"{hw}, {g}: the registered reading")
        if truthy(r.get("in_family")) and not sec:
            mc.add(base + ("Holm", "Reject"), "rejected" if truthy(r.get("holm_reject")) else "not rejected",
                   f"{src} column=holm_reject", f"{hw}, {g}: Holm decision of this member")
            for col, nm, d, what in (("item_share", ("Item", "Share"), 2,
                                      "share of the variance that comes from the items (two-way jackknife)"),
                                     ("eff_items", ("Eff", "Items"), 1,
                                      "effective number of item clusters (a few = a few items carry the variance)")):
                if fin(r.get(col)):
                    mc.add(base + nm, fmt(r[col], d), f"{src} column={col}", f"{hw}, {g}: {what}")
        # revision 3 (E1): the same test with items coded per owner (the analysis before revision 3), a
        # sensitivity column only, never in the family
        if fin(r.get("p_owner_coding")):
            mc.add(base + ("P", "Owner", "Coding"), fmt_p(r["p_owner_coding"]), f"{src} column=p_owner_coding",
                   f"{hw}, {g}: sensitivity, unadjusted p with items coded per owner (not in any family)")
        if r["comparison"] == "PC2" and (r.get("label") or "").strip():
            mc.add(base + ("Label",), tex_escape(r["label"]), f"{src} column=label",
                   f"keep minus wipe, {g}: the registered reading after Holm")
        if r["comparison"] == "PC2":
            for col, nm, what in (("home_est", ("Home",), "the same contrast at home"),
                                  ("home_lo", ("Home", "Lo"), "at home, lower end"), ("home_hi", ("Home", "Hi"), "at home, upper end")):
                if fin(r.get(col)):
                    mc.add(base + nm, fmt(r[col], 4), f"{src} column={col}", f"keep minus wipe, {g}: {what}")
        if r["comparison"] in ("PC3", "PC4"):
            for col, nm, what in (("swap_est", ("Swap",), "the arm difference after the swap"),
                                  ("home_est", ("Home",), "the same arm difference at home"),
                                  ("fs_did", ("FS",), "first-shown success, swap minus home (success points)"),
                                  ("fs_did_lo", ("FS", "Lo"), "first-shown success, swap minus home, lower end"),
                                  ("fs_did_hi", ("FS", "Hi"), "first-shown success, swap minus home, upper end"),
                                  ("raw_log_did", ("Raw", "Log"), "uncorrected log score, swap minus home"),
                                  ("est_b", ("Est", "B"), "recal minus wipe, swap minus home"),
                                  ("lo_b", ("Lo", "B"), "recal minus wipe, lower end"),
                                  ("hi_b", ("Hi", "B"), "recal minus wipe, upper end"),
                                  ("fs_did_b", ("FS", "B"), "recal minus wipe, first-shown success, swap minus home"),
                                  ("base_gap", ("Base", "Gap"), "owner minus reader no-memory success (success "
                                   "points): the base-rate gap that moves the contrast by itself"),
                                  ("est_lcw", ("Est", "LCW"), "sensitivity: the same contrast with the level target "
                                   "at the reader's with-item success on the calibration cells"),
                                  ("lo_lcw", ("Lo", "LCW"), "sensitivity estimate, lower end"),
                                  ("hi_lcw", ("Hi", "LCW"), "sensitivity estimate, upper end")):
                if fin(r.get(col)):
                    mc.add(base + nm, fmt(r[col], 4), f"{src} column={col}", f"{hw}, {g}: {what}")
            if fin(r.get("p_lcw")):
                mc.add(base + ("P", "LCW"), fmt_p(r["p_lcw"]), f"{src} column=p_lcw",
                       f"{hw}, {g}: sensitivity, unadjusted p")
        for col, nm, what in (("spread_min", ("Spread", "Min"), "smallest per-pair value"),
                              ("spread_max", ("Spread", "Max"), "largest per-pair value"),
                              ("spread_opposite_share", ("Spread", "Opposite"), "share of pairs with the opposite sign"),
                              ("spread_sd_between", ("Spread", "SD"), "between-pair SD of the source-and-target "
                               "model (one model-based SD shared by all groups, not a per-group SD; the per-group SD "
                               "is the Spread...SD macro of the group)")):
            if r["comparison"] not in ("PC1-NI", "PC1-MD") and fin(r.get(col)):
                mc.add(base + nm, fmt(r[col], 3), f"{src} column={col}", f"{hw}, {g}: spread, {what}")
    # PC1 per group: the reading from its three Holm decisions, and the home-signal test inside each member
    for g in GROUPS:
        pc1 = [r for r in tests if r["group"] == g and r["comparison"].startswith("PC1")]
        if not pc1:
            continue
        lab = next(((r.get("label") or "").strip() for r in pc1 if (r.get("label") or "").strip()), "")
        if lab:
            mc.add(("PC1", g, "Label"), tex_escape(lab), f"primary_tests.csv test=PC1-*-{g} column=label",
                   f"PC1 reading of {GROUP_WORDS[g]} from its three Holm decisions (material drop shown / drop "
                   "shown / small drop shown / no material drop shown / inconclusive)")
        ph = next((r.get("p_home") for r in pc1 if fin(r.get("p_home"))), None)
        if ph is not None:
            mc.add(("PC1", g, "P", "Home"), fmt_p(ph), f"primary_tests.csv test=PC1-drop-{g} column=p_home",
                   f"p of the home-signal test (H1 V at home > 0), part of every PC1 member, {GROUP_WORDS[g]}")
    if fam_rows:
        mc.add(("N", "Primary", "Members"), str(len(fam_rows)), "primary_tests.csv in_family=true (count)",
               "members of the primary Holm family in these result files (12 when every group has swaps)")
        mc.add(("N", "Primary", "Rejected"), str(sum(truthy(r.get("holm_reject")) for r in fam_rows)),
               "primary_tests.csv in_family=true holm_reject=true (count)", "members the Holm procedure rejected")
    # ---- per-group between-pair SD and the prediction interval for a new pair (random effects per group;
    # revision 3, E2: crossed owner + reader random effects for the cross-maker group, DerSimonian-Laird for the
    # same-maker groups)
    for r in group_re_rows(adir, tests):
        comp = r.get("comparison", "")
        stem = "Theta" if comp.startswith("PC1") else "Keep Wipe"
        g = GROUP_WORDS.get(r["group"], r["group"])
        what = "theta" if stem == "Theta" else "keep minus wipe (first-shown success)"
        src = f"{r['_src']} comparison={comp} group={r['group']}"
        crossed = is_crossed(r)
        how = ("crossed owner + reader random effects, REML; a new pair = a new owner and a new reader"
               if crossed else "random effects")
        for col, nm, words in (("tau", ("SD",), f"between-pair SD of {what} within the group ({how})"),
                               ("tau_lo", ("SD", "Lo"), "between-pair SD, lower end of its 95 % interval"),
                               ("tau_hi", ("SD", "Hi"), "between-pair SD, upper end of its 95 % interval"),
                               ("tau_owner", ("SD", "Owner"), f"between-owner SD of {what} ({how})"),
                               ("tau_reader", ("SD", "Reader"), f"between-reader SD of {what} ({how})"),
                               ("re_mean", ("Mean",), f"random-effects mean of {what} over the group's pairs"),
                               ("pi_lo", ("PI", "Lo"), f"95 % prediction interval of {what} for a new pair, lower end "
                                                       f"({how})"),
                               ("pi_hi", ("PI", "Hi"), f"95 % prediction interval of {what} for a new pair, upper end "
                                                       f"({how})"),
                               ("k", ("K",), "pairs in the group")):
            if has_val(r.get(col)):
                v = str(int(num(r[col]))) if col == "k" else val_or_inf(r[col])
                mc.add(("Spread", stem, r["group"]) + nm, v, f"{src} column={r['_cols'].get(col, col)}",
                       f"{words}, {g}")
        dfc = "df" if fin(r.get("df")) else "pi_df" if fin(r.get("pi_df")) else None
        if dfc:
            mc.add(("Spread", stem, r["group"], "PI", "DF"), str(int(round(num(r[dfc])))),
                   f"{src} column={dfc}", f"degrees of freedom of the t reference of the prediction interval "
                   f"({'min(owners, readers) - 1' if crossed else 'k - 2'}), {g}")
        if (r.get("method") or "").strip():
            mc.add(("Spread", stem, r["group"], "Method"), tex_escape(r["method"].strip()), f"{src} column=method",
                   f"how the between-pair spread and the prediction interval were estimated, {g}")
    # ---- theta, the headline (retained ranking signal), per group and score family
    ne_counts = pairs_not_estimated(adir, H)
    for r in read_csv(adir / "theta_groups.csv"):
        if r["level"] != "all":
            continue
        g = GROUP_WORDS.get(r["group"], r["group"])
        head = r["family"] == H
        base = ("Theta", r["group"]) if head else ("Theta", r["family"], r["group"])
        src = f"theta_groups.csv family={r['family']} group={r['group']} level=all"
        fw = "" if head else f", score family {r['family']}"
        for col, nm, what in (("theta", (), "retained ranking signal theta"),
                              ("theta_lo", ("Lo",), "theta, lower end of the two-way 95 % Fieller interval"),
                              ("theta_hi", ("Hi",), "theta, upper end of the two-way 95 % Fieller interval"),
                              ("theta_lo_task_boot", ("Lo", "Task"), "theta, lower end of the task-only bootstrap interval (secondary)"),
                              ("theta_hi_task_boot", ("Hi", "Task"), "theta, upper end of the task-only bootstrap interval (secondary)"),
                              ("theta_self", ("Self",), "self-swap theta of the group's owners (repeats 3-4; about 1)"),
                              ("p_drop", ("P", "Drop"), "unadjusted p of the drop test"),
                              ("p_ni", ("P", "NI"), "unadjusted p of the no-material-drop test"),
                              ("p_md", ("P", "MD"), "unadjusted p of the material-drop test (theta < 0.75)"),
                              ("p_home", ("P", "Home"), "unadjusted p of the home-signal test (V at home > 0)")):
            if fin(r.get(col)) and (r["group"] != "home" or col in ("theta", "theta_lo", "theta_hi")):
                v = fmt_p(r[col]) if col.startswith("p_") else fmt(r[col])
                mc.add(base + nm, v, f"{src} column={col}", f"{what}, {g}{fw}")
        if head and r["group"] != "home":
            # revision 2 (D2), words of revision 3 (E3): theta = retained agreement x stakes, each with its two-way
            # interval (CSV columns and macro names keep "order"); a cell with the later-session check's words
            # ("not valid: repeats not independent") prints them instead of a number
            for col, nm, what in (("order", ("Order",), f"{AGREEMENT}: the noise-corrected correlation of the two "
                                   "models' item-effect differences as seen through the old scores (theta = "
                                   "agreement x stakes)"),
                                  ("order_lo", ("Order", "Lo"), f"{AGREEMENT}, lower end of its two-way 95 % interval"),
                                  ("order_hi", ("Order", "Hi"), f"{AGREEMENT}, upper end of its two-way 95 % interval"),
                                  ("stakes", ("Stakes",), "stakes: how much the reader's success depends on which "
                                   "item it gets, relative to the owner's (square root of S reader / S owner)"),
                                  ("stakes_lo", ("Stakes", "Lo"), "stakes, lower end of its two-way 95 % interval"),
                                  ("stakes_hi", ("Stakes", "Hi"), "stakes, upper end of its two-way 95 % interval"),
                                  ("cw_agreement", ("Cw", "Agreement"), "rank companion of the retained agreement: "
                                   "weighted concordance of the new model's results with the old model's results "
                                   "on the same tasks and items; raw, attenuated toward 0.5 by repeat noise"),
                                  ("cw_agreement_lo", ("Cw", "Agreement", "Lo"), "rank companion, lower end of its "
                                   "two-way 95 % interval"),
                                  ("cw_agreement_hi", ("Cw", "Agreement", "Hi"), "rank companion, upper end of its "
                                   "two-way 95 % interval")):
                v = agreement_cell(r.get(col), r.get("order_status"))
                if v is not None:
                    mc.add(base + nm, v, f"{src} column={col}", f"{what}, {g}")
            if (r.get("order_status") or "").strip():
                mc.add(base + ("Order", "Status"), tex_escape(status_words(r["order_status"])),
                       f"{src} column=order_status",
                       f"whether the {AGREEMENT} is estimated (the reader's item spread on its calibration tasks "
                       f"at z >= 2), {g}")
            if fin(r.get("n_pairs_agreement_not_estimated")):
                mc.add(base + ("N", "Pairs", "Agreement", "Not", "Estimated"),
                       str(int(num(r["n_pairs_agreement_not_estimated"]))),
                       f"{src} column=n_pairs_agreement_not_estimated",
                       f"pairs whose {AGREEMENT} is {NOT_ESTIMATED}, {g}")
            elif r["group"] in ne_counts:
                n_ne, n_all = ne_counts[r["group"]]
                mc.add(base + ("N", "Pairs", "Agreement", "Not", "Estimated"), str(n_ne),
                       f"theta_pairs.csv family={H} level=all group={r['group']} column=order_status (count of "
                       "'not identifiable' / 'not estimated' among owner != reader)",
                       f"pairs (of {n_all}) whose {AGREEMENT} is {NOT_ESTIMATED}, {g}")
            # revision 3 (E1): the owner coding of the items, a sensitivity only
            for col, nm, what in (("lo_owner_coding", ("Owner", "Coding", "Lo"), "lower end"),
                                  ("hi_owner_coding", ("Owner", "Coding", "Hi"), "upper end"),
                                  ("p_drop_owner_coding", ("Owner", "Coding", "P", "Drop"), "unadjusted p of the drop test"),
                                  ("p_md_owner_coding", ("Owner", "Coding", "P", "MD"), "unadjusted p of the "
                                   "material-drop test"),
                                  ("p_ni_owner_coding", ("Owner", "Coding", "P", "NI"), "unadjusted p of the "
                                   "no-material-drop test")):
                if has_val(r.get(col)):
                    v = fmt_p(r[col]) if col.startswith("p_") else val_or_inf(r[col])
                    mc.add(base + nm, v, f"{src} column={col}",
                           f"sensitivity with items coded per owner (the coding before revision 3): theta, {what}, {g}")
            # revision 3 (E2): unweighted mean of per-pair theta (pairs whose home flag passes) and the
            # leave-one-pair-out range of the group theta (registered sensitivities)
            for col, nm, what in (("theta_pair_mean", ("Pair", "Mean"), "unweighted mean of per-pair theta over the "
                                   "pairs whose home flag passes"),
                                  ("theta_pair_mean_lo", ("Pair", "Mean", "Lo"), "unweighted mean of per-pair theta, "
                                   "lower end of its two-way 95 % interval"),
                                  ("theta_pair_mean_hi", ("Pair", "Mean", "Hi"), "unweighted mean of per-pair theta, "
                                   "upper end of its two-way 95 % interval"),
                                  ("theta_pair_mean_n", ("Pair", "Mean", "N"), "pairs in the unweighted mean"),
                                  ("theta_lopo_min", ("Lopo", "Min"), "smallest group theta when one pair is left out"),
                                  ("theta_lopo_max", ("Lopo", "Max"), "largest group theta when one pair is left out")):
                if has_val(r.get(col)):
                    v = str(int(num(r[col]))) if col.endswith("_n") else val_or_inf(r[col])
                    mc.add(base + nm, v, f"{src} column={col}", f"{what}, {g}")
            if r["group"].endswith("_core"):
                lab_col = "label" if (r.get("label") or "").strip() else "label_unadjusted"
                if (r.get(lab_col) or "").strip():
                    mc.add(base + ("Label",), tex_escape(r[lab_col].strip()), f"{src} column={lab_col}",
                           f"PC1 reading of {g} from its unadjusted tests (outside the primary family; the "
                           "family's groups have six pairs)")
        mc.add(base + ("Status",), tex_escape(r.get("theta_status_calibration", r.get("theta_status", ""))),
               f"{src} column=theta_status_calibration",
               f"reporting flag of theta (owner's signal on its calibration tasks >= 2 SE), {g}{fw}")
    # ---- secondary: concordance, D and R by group (every family)
    for r in read_csv(adir / "group_validity.csv"):
        if r["level"] != "all" or r["group"] not in GROUPS + ("all_swaps", "home"):
            continue
        base = ("Cw", r["family"], r["group"])
        g = GROUP_WORDS.get(r["group"], r["group"])
        src = f"group_validity.csv family={r['family']} group={r['group']} level=all"
        if r["R_status"] == "reported":
            mc.add(base + ("R",), fmt(r["R"]), f"{src} column=R",
                   f"secondary: concordance ratio R (moves with the reader's outcome noise), {g}, family {r['family']}")
        mc.add(base + ("D",), fmt(r["D"]), f"{src} column=D",
               f"secondary: drop in weighted concordance D in concordance points, {g}, family {r['family']}")
        if r["family"] == H:
            for col, nm, what in (("C_home", ("Home",), "weighted concordance at home"),
                                  ("C_swap", ("Swap",), "weighted concordance after the swap")):
                if fin(r.get(col)):
                    mc.add(base + nm, fmt(r[col]), f"{src} column={col}", f"secondary: {what}, {g}")
            if str(r.get("R_adj_status", "")).startswith("reported") and fin(r.get("R_adj")):
                mc.add(base + ("R", "Adj"), fmt(r["R_adj"]), f"{src} column=R_adj",
                       f"secondary: noise-adjusted ratio R_adj, {g}")
    # ---- what is at stake, in success points
    for r in read_csv(adir / "stakes.csv"):
        g = GROUP_WORDS.get(r["group"], r["group"])
        src = f"stakes.csv group={r['group']} contrast={r['contrast']}"
        for tag in ("home", "swap", "swap_minus_home"):
            words = {"home": "at home", "swap": "after the swap", "swap_minus_home": "after the swap minus at home"}[tag]
            for col, nm in ((tag, ()), (f"{tag}_lo", ("Lo",)), (f"{tag}_hi", ("Hi",))):
                if fin(r.get(col)):
                    mc.add(("Stakes", r["contrast"], r["group"], tag) + nm, fmt(r[col]), f"{src} column={col}",
                           f"first-shown success, {r['contrast']}, {words}, {g} (0.01 = 1 success point)"
                           + ("; lower end" if nm == ("Lo",) else "; upper end" if nm == ("Hi",) else ""))
    # ---- capability gap and error consistency beside the maker term (R5 W9), per pair -> one fit
    tag = {"maker only": "Maker Only", "maker + capability gap + error consistency": "Controlled"}
    seen = set()
    for r in read_csv(adir / "capability_fit.csv"):
        model = tag.get((r.get("model") or "").strip(), camel(r.get("model", "")))
        term = r.get("term", "")
        key = (model, term)
        if key in seen or not term:
            continue
        seen.add(key)
        src = f"capability_fit.csv model={r.get('model')} term={term}"
        mw = ("maker term alone" if model == "Maker Only" else
              "with the capability gap and error consistency as controls")
        for col, nm in (("coef", "Coef"), ("se", "SE")):
            if fin(r.get(col)):
                mc.add(("Capability", model, term, nm), fmt(r[col]), f"{src} column={col}",
                       f"theta per pair regressed on {term} ({mw}): {'coefficient' if nm == 'Coef' else 'its SE'}; "
                       "descriptive (pairs share models)")
    caps = read_csv(adir / "capability_fit.csv")
    if caps and fin(caps[0].get("n_pairs")):
        mc.add(("Capability", "N", "Pairs"), str(int(num(caps[0]["n_pairs"]))), "capability_fit.csv column=n_pairs",
               "swap pairs in the capability fit")
    # ---- predictions (reported in the appendix). Revision 3 (manager's ruling): P1 is EXPLORATORY, reported with
    # its unadjusted p; the prediction family is P2-P4 (Holm over those three)
    for r in prediction_rows(adir):
        src = f"predictions.csv prediction={r['prediction']}"
        st_ = r.get("statement", "")
        expl = r["_status"] == "exploratory"
        tag = (f"{r['prediction']} (exploratory, outside the prediction family)" if expl
               else f"{r['prediction']} (registered)")
        mc.add((r["prediction"], "Value"), fmt(r.get("value")), f"{src} column=value", f"{tag} ({st_}): statistic")
        mc.add((r["prediction"], "P"), fmt_p(r.get("p_one_sided")), f"{src} column=p_one_sided",
               f"{tag}: one-sided p" + (", unadjusted" if expl else ""))
        if expl:
            mc.add((r["prediction"], "P", "Holm"), PENDING, f"{src} {r['_status_src']}; no Holm p",
                   f"{tag}: no Holm-adjusted p (exploratory; the Holm family of the predictions is P2-P4); "
                   f"read its unadjusted p")
        else:
            mc.add((r["prediction"], "P", "Holm"), fmt_p(r.get("_p_holm")), f"{src} {r['_p_holm_src']}",
                   f"{tag}: Holm-adjusted p over P2-P4 (the testable ones)")
        mc.add((r["prediction"], "Status"), r["_status"], f"{src} {r['_status_src']}",
               f"{r['prediction']}: exploratory or registered (revision 3: P1 exploratory, P2-P4 registered)")
        mc.add((r["prediction"], "Result"), tex_escape(r["_result"]), f"{src} column=result",
               f"{tag}: result" + ("; exploratory, judged by its unadjusted p only" if expl else ""))
    # ---- controls
    for r in read_csv(adir / "validity_extras_groups.csv"):
        if r["family"] == H and r["group"] in ("all_swaps", "home"):
            mc.add(("Shuffled", "Cw", r["group"]), fmt(r["swap_shuffled"]),
                   f"validity_extras_groups.csv family={H} group={r['group']} column=swap_shuffled",
                   f"content-only control: concordance of shuffled scores, {GROUP_WORDS.get(r['group'])}")
    # ---- arms by group: first-shown success and log scores of the main arms
    lam = meta.get("primary_lambda", "0.5")
    K = meta.get("primary_k", "")
    main = ["none", "relevance", "keep", "wipe", "constant", f"fixed_{float(lam):g}", "shuffled", f"recal_{K}", "own",
            "split_half", "ceiling"]
    mwords = {"value": "first-shown success", "log": "held-out log score (raw)", "log_lc": "held-out log score, level-corrected"}
    for r in read_csv(adir / "arms_groups.csv"):
        if r["level"] != "all" or r["group"] not in GROUPS + ("all_swaps", "home") or r["arm"] not in main:
            continue
        if r["family"] not in (H, "-") or r["metric"] not in mwords:
            continue
        src = f"arms_groups.csv family={r['family']} arm={r['arm']} metric={r['metric']} group={r['group']} level=all"
        mc.add(("Arm", r["arm"], r["metric"], r["group"]), fmt(r["est"]), f"{src} column=est",
               f"arm {r['arm']}: {mwords[r['metric']]}, {GROUP_WORDS.get(r['group'])}")
    # ---- post-swap run, all swaps
    for r in read_csv(adir / "online_groups.csv"):
        if r["group"] == "all_swaps":
            mc.add(("Online", r["arm"], "all"), fmt(r["S_all"]),
                   f"online_groups.csv group=all_swaps arm={r['arm']} column=S_all",
                   f"run after the swap: mean success of arm {r['arm']} over all test tasks, all swaps run")
    # ---- cost
    for r in read_csv(adir / "costs_by_model.csv"):
        if r["model"] == "all":
            mc.add(("Total", "Calls"), f"{int(num(r['calls'])):,}".replace(",", "{,}"),
                   "costs_by_model.csv model=all column=calls", "all model calls of the study")
            mc.add(("Total", "USD"), f"{num(r['usd']):.2f}", "costs_by_model.csv model=all column=usd",
                   "US dollars spent by the study")
    addition_macros(mc, adir, meta.get("headline_family", "ema_grade"))
    check_macros(mc, adir)              # the swap-day check numbers (msr.sequential; theory hand-over section 1)
    paper_macros(mc, adir)              # the names the paper asks for (paper/assets/REQUESTED_MACROS.md)
    construct_reading_macros(mc, adir)  # the registered construct reading words (Part 8.2.24), per kind of swap
    method_macros(mc)                   # simulation checks of the method (docs/power/), unprefixed \Method...
    construct_macros(mc, adir)          # msr.construct's numbers (construct_macros.csv), same file, same rules
    head = [f"% numbers.tex: one macro per headline number of study `{study}`.",
            f"% Made by scripts/make_paper_assets.py from runs/{study}/analysis/ (do not edit by hand).",
            "% Every macro carries the CSV file and row it comes from; paper/assets/MACROS.md lists their meanings."]
    if KIND[kind][1]:
        head.insert(0, f"% {KIND[kind][1]}: study kind {kind}; every macro starts with \\{KIND[kind][0]}.")
    head += [f"% {n}" for n in list(notes or []) + mc.notes]
    p = out / "numbers.tex"
    p.write_text("\n".join(head) + "\n" + mc.text() + "\n", encoding="utf-8")
    write_macros_md(mc, out, study, kind)
    return p


def prediction_rows(adir: Path) -> list:
    """Rows of predictions.csv with revision 3's reading (manager's ruling: P1 exploratory, Holm over P2-P4):
    '_status' ('exploratory' / 'registered', from the column `status`, else P1 exploratory and the others
    registered), '_p_holm' (column `p_holm` when the analysis wrote it; in a file written before revision 3 the
    column holm_adjusted_p when P1 was not in that file's Holm family, else Holm recomputed from p_one_sided over
    the testable registered rows), '_result' (for an exploratory row, never a pass / fail judged by Holm) and the
    source words of each."""
    rows = [dict(r) for r in read_csv(Path(adir) / "predictions.csv")]
    if not rows:
        return rows
    has_status = "status" in rows[0]
    has_new_holm = "p_holm" in rows[0]
    for r in rows:
        st_ = (r.get("status") or "").strip().lower() if has_status else ""
        if st_ not in ("exploratory", "registered"):
            st_ = "exploratory" if r.get("prediction") == "P1" else "registered"
            r["_status_src"] = "(no status column: P1 exploratory by the revision-3 ruling, the others registered)"
        else:
            r["_status_src"] = "column=status"
        r["_status"] = st_
    reg = [r for r in rows if r["_status"] == "registered"]
    old_family_had_p1 = any(r["_status"] == "exploratory" and truthy(r.get("testable_here"))
                            and fin(r.get("holm_adjusted_p")) for r in rows)
    if has_new_holm:
        for r in reg:
            r["_p_holm"], r["_p_holm_src"] = r.get("p_holm"), "column=p_holm"
    elif not old_family_had_p1:
        for r in reg:
            r["_p_holm"] = r.get("holm_adjusted_p")
            r["_p_holm_src"] = "column=holm_adjusted_p (no exploratory row in this file's Holm family)"
    else:
        tested = [r for r in reg if truthy(r.get("testable_here")) and fin(r.get("p_one_sided"))]
        for r, adj in zip(tested, holm_adjust([num(r["p_one_sided"]) for r in tested])):
            r["_p_holm"] = adj
        for r in reg:
            r.setdefault("_p_holm", float("nan"))
            r["_p_holm_src"] = ("column=p_one_sided, Holm recomputed over the testable rows of P2-P4 (the file's "
                                "holm_adjusted_p included P1; its result words were judged against that)")
    for r in rows:
        res = (r.get("result") or "").strip()
        if r["_status"] == "exploratory" and not res.lower().startswith("exploratory"):
            if res in ("pass", "fail"):
                res = f"exploratory: one-sided p {fmt_p(r.get('p_one_sided')).replace('$<$', '< ')}, unadjusted"
            else:
                res = "exploratory; " + res if res else "exploratory"
        r["_result"] = res
    return rows


def is_crossed(r: dict) -> bool:
    """A group_re row of the crossed owner + reader random-effects model (revision 3, E2)."""
    return "crossed" in (r.get("method") or "").lower()


def pairs_not_estimated(adir: Path, H: str) -> dict:
    """{group: (pairs whose retained agreement is not estimated, swap pairs)} counted from theta_pairs.csv
    (headline family, level all, owner != reader) for the swap groups, same_maker and all_swaps; {} when the
    file or its order_status column is missing. Used only where theta_groups.csv has no
    n_pairs_agreement_not_estimated column."""
    rows = [r for r in read_csv(Path(adir) / "theta_pairs.csv") if r.get("family") == H and r.get("level") == "all"
            and r.get("owner") != r.get("reader") and r.get("group") in GROUPS]
    if not rows or "order_status" not in rows[0]:
        return {}
    out = {}
    for g, members in (("upgrade", ("upgrade",)), ("downgrade", ("downgrade",)), ("cross", ("cross",)),
                       ("same_maker", ("upgrade", "downgrade")), ("all_swaps", GROUPS)):
        sel = [r for r in rows if r["group"] in members]
        if sel:
            out[g] = (sum(status_words(r.get("order_status")) == NOT_ESTIMATED for r in sel), len(sel))
    return out


def group_re_rows(adir: Path, tests: list | None = None) -> list:
    """Rows of group_re.csv (revision 2: per-group between-pair SD and the prediction interval for a
    new pair) for PC1 theta and PC2 in the three swap groups; when the file is missing, the same
    numbers from the primary-test rows (group_sd, pi_lo, ... of PC1-drop and PC2). Each row carries
    '_src' (file) and '_cols' (column names used) for the macro source. Revision 3 (E2): one row per
    (comparison, group): for the cross-maker group the crossed owner + reader random-effects row
    (method 'crossed owner + reader REML') when the file has one, else the DerSimonian-Laird row; rows of the
    headline family before rows of other families."""
    meta = {r["key"]: r["value"] for r in read_csv(Path(adir) / "meta.csv")}
    H = meta.get("headline_family", "ema_grade")
    pick: dict = {}
    for r in read_csv(Path(adir) / "group_re.csv"):
        comp = r.get("comparison", "")
        if r.get("group") not in GROUPS or not (comp.startswith("PC1") or comp.startswith("PC2")):
            continue
        key = (comp, r["group"])
        rank = (r.get("family") in (H, "", None), is_crossed(r) if r["group"] == "cross" else not is_crossed(r))
        if key not in pick or rank > pick[key][0]:
            pick[key] = (rank, dict(r, _src=f"group_re.csv family={r.get('family', '')}"
                                    + (f" method={r['method']}" if is_crossed(r) else ""), _cols={}))
    out = [v[1] for v in pick.values()]
    if out:
        return out
    cols = {"tau": "group_sd", "tau_lo": "group_sd_lo", "tau_hi": "group_sd_hi", "pi_lo": "pi_lo", "pi_hi": "pi_hi",
            "re_mean": "re_mean", "k": "n_swaps"}
    for r in tests if tests is not None else read_csv(Path(adir) / "primary_tests.csv"):
        if r.get("comparison") in ("PC1-drop", "PC2") and r.get("group") in GROUPS and fin(r.get("group_sd")):
            row = {k: r.get(v, "") for k, v in cols.items()}
            row.update(comparison="PC1 theta" if r["comparison"] == "PC1-drop" else "PC2 keep - wipe",
                       group=r["group"], _src=f"primary_tests.csv test={r['test']}", _cols=cols)
            out.append(row)
    return out


def write_macros_md(mc: "Macros", out: Path, study: str, kind) -> Path:
    """paper/assets/MACROS.md: every macro of numbers.tex with its value in this study, its meaning and
    its source row, grouped by stem, for the paper's authors."""
    kind = norm_kind(kind)
    pre = KIND[kind][0]
    L = ["# Number macros of the paper (`paper/assets/numbers.tex`)", "",
         f"Made by `scripts/make_paper_assets.py` from study `{study}` (study kind: {kind}). Do not edit by hand.",
         "",
         "How the names are built: the prefix (" + (f"`\\{pre}`" if pre else "none") + " for this study kind: `\\Sim` "
         "for simulated, `\\Pre` for preliminary, no prefix for the real study), then the stem, then the parts "
         "CamelCased with digits spelled out (PC1 -> PCOne, 0.5 -> ZeroFive, k = 64 -> SixFour). Suffixes: `Lo`, "
         "`Hi` = ends of the 95 % interval (two-way task x item unless the name says `Task`), `P` = p-value, "
         "`PHolm` = Holm-adjusted p, `Decision` = the registered decision label.",
         "",
         "Words (round-1 revision): the headline is **theta**, called the *retained ranking signal* in prose "
         "(V after the swap / V at home; 1 = all of the home ranking signal kept). Swap groups are *same-maker "
         "upgrades*, *same-maker downgrades* and *cross-maker swaps*; \"score family\" means one of the five score "
         "types only. The self-swap is the *self-swap reference*. `split_half` (formerly `oracle`) picks on one "
         "repeat and scores on the other: a reference, not a bound; `ceiling` is the in-sample best candidate. "
         "R, D and R_adj are secondary. Macros about the transfer decomposition use the stem `Decomp`.",
         "",
         "Revision 2, words of revision 3: theta = **agreement** x **stakes** (`Theta<group>Order`, "
         "`Theta<group>Stakes`; macro and CSV names keep `Order`): the *retained agreement* is the noise-corrected "
         "correlation of the two models' item-effect differences as seen through the old scores (a correlation, not "
         "an order count); stakes = how much the reader's success depends on which item it gets, relative to the "
         "owner's. Its rank companion `Theta<group>CwAgreement` is the weighted concordance of the new model's "
         "results with the old model's, raw (attenuated toward 0.5 by repeat noise). An agreement the data cannot "
         f"estimate is \"{NOT_ESTIMATED}\"; agreement, stakes and the companion print \"{NOT_VALID}\" when the "
         "later-session check flags a model of the swap. The primary family has 12 members: in each swap group PC1-drop (theta < 1), "
         "PC1-MD (material drop, theta < 0.75), PC1-NI (no material drop, theta > 0.75), each together with the "
         "home-signal test (V at home > 0), and PC2 (keep minus wipe); the PC1 reading of a group "
         "(`PCOne<group>Label`) is one of: material drop shown, drop shown, small drop shown, no material drop shown, "
         "inconclusive. PC3 and PC4 are secondary (outside the family), reported with the owner-reader base-rate gap "
         "and a sensitivity with the level target at the reader's with-item success; they measure an effect of the "
         "swap only under the additivity assumption. `Spread<stat><group>SD` is the between-pair SD within the "
         "group and `...PILo`/`...PIHi` the 95 % prediction interval for a new pair; `ItemShare` and `EffItems` say "
         "how much of a test's variance comes from a few items. `Capability...` = theta per pair against the "
         "capability gap and error consistency beside the maker term (descriptive).",
         "",
         "Revision 3: items are clustered by write task within stream (shared across owners) in every statistic "
         "that pools owners; the owner coding is a sensitivity only (`...OwnerCoding...`). Same-maker groups are also "
         "reported on the core grid (`ThetaUpgradeCore...`, `ThetaDowngradeCore...`, outside the family); "
         "`Theta<group>PairMean...` is the unweighted mean of per-pair theta and `Theta<group>LopoMin/Max` the "
         "leave-one-pair-out range. The cross-maker prediction interval comes from crossed owner + reader random "
         "effects (`SpreadThetaCrossSDOwner`, `...SDReader`, `...PIDF`). P1 is exploratory (unadjusted p only); the "
         "prediction family is P2-P4. `ArmBestCheckMinusKeepCross` is cross-fitted (rule chosen on one half of the "
         "tasks, its gain over keep measured on the other half, both ways averaged); the largest of the rules on the "
         "same data is kept only as `ArmBestCheckNaiveMinusKeepCross` (winner's curse; not used for advice). The "
         "conversion of the 0.75 margin to success points (`MarginPointsAllSwaps`) is withdrawn.",
         ""]
    stems: dict = {}
    for name, value, meaning, source in mc.entries:
        core = name[len(pre):] if pre and name.startswith(pre) else name
        stem = next((s for s in ("Theta", "Stakes", "PCOne", "PCTwo", "PCThree", "PCFour", "Cw", "Arm", "Online",
                                 "Decomp", "Forecast", "Check", "POne", "PTwo", "PThree", "PFour", "Shuffled",
                                 "Spread", "Capability", "Order", "Reanswer", "Constr", "Fam", "Method", "N",
                                 "Total", "Primary") if core.startswith(s)), "Other")
        stems.setdefault(stem, []).append((name, value, meaning, source))
    titles = {"Theta": "theta, the headline (retained ranking signal), with retained agreement and stakes",
              "PCOne": "PC1: drop, material-drop and no-material-drop tests (each with the home-signal test)",
              "Spread": "Between-pair SD per group and prediction interval for a new pair",
              "Capability": "theta against capability gap and error consistency, beside the maker term",
              "PCTwo": "PC2: keep minus wipe", "PCThree": "PC3 (secondary): fixed discount, swap minus home",
              "PCFour": "PC4 (secondary): calibrated discount, swap minus home",
              "Stakes": "What is at stake, in success points",
              "Cw": "Secondary: concordance, D, R", "Arm": "Arms by swap group", "Online": "Run after the swap",
              "Decomp": "Transfer decomposition (msr.theory)", "Forecast": "Forecast before the swap (msr.forecast)",
              "Check": "Stop-when-sure check (msr.sequential)",
              "POne": "Prediction P1 (exploratory, outside the prediction family; appendix)",
              "PTwo": "Prediction P2 (registered; Holm over P2-P4; appendix)",
              "PThree": "Prediction P3 (registered; Holm over P2-P4; appendix)",
              "PFour": "Prediction P4 (registered; Holm over P2-P4; appendix)",
              "Order": "Retained agreement and stakes ratio per kind of swap (macro names keep `Order`)",
              "Reanswer": "Re-answer's home value (msr.secondary_stages)",
              "Constr": "Construct checks (msr.construct), with the registered reading",
              "Fam": "Family T of the transfer decomposition (registered Holm members)",
              "Method": "Simulation checks of the method (docs/power/; no study prefix; not results)",
              "Shuffled": "Content-only control", "N": "Counts", "Total": "Cost", "Primary": "Design constants",
              "Other": "Other"}
    for stem in ("N", "Primary", "Theta", "Order", "PCOne", "PCTwo", "Spread", "PCThree", "PCFour", "Stakes",
                 "Capability", "Cw", "Arm", "Reanswer", "Online", "Shuffled", "Decomp", "Fam", "Forecast", "Check",
                 "POne", "PTwo", "PThree", "PFour", "Constr", "Method", "Total", "Other"):
        rows = stems.get(stem)
        if not rows:
            continue
        L += [f"## {titles[stem]}", "", "| macro | value here | meaning | source |", "|---|---|---|---|"]
        for name, value, meaning, source in rows:
            v = str(value).replace("|", "\\|")
            L.append(f"| `\\{name}` | {v} | {meaning.replace('|', '/')} | {source.replace('|', '/')} |")
        L.append("")
    p = out / "MACROS.md"
    p.write_text("\n".join(L) + "\n", encoding="utf-8")
    return p


# ---------------------------------------------------------------------------
# The three additions: transfer law, forecast before the swap, stop-when-sure check
# ---------------------------------------------------------------------------


#: revision 3 (E3): displayed words of the decomposition factor in method meanings
_METHOD_WORDS = (("the order (retained agreement) set", "the retained-agreement set (CSV name order)"),
                 ("the order set", "the retained-agreement set (CSV name order)"))


def _method_value(v) -> str:
    """A method value as LaTeX text: a number as written (a minus sign as $-$), anything else escaped."""
    s = str(v).strip()
    if re.fullmatch(r"-?\d+(\.\d+)?", s):
        return "$-$" + s[1:] if s.startswith("-") else s
    return tex_escape(s)


def method_macros(mc: "Macros", pw: Path | None = None) -> list:
    """Simulation checks of the METHOD (properties of the registered tests, not of any study): size and
    coverage from docs/power/ outputs, as unprefixed \\Method... macros so the submission may print them
    (manager's ruling). Revision 3: docs/power/revision3_method.json ({name: {value, source, meaning}}, write-task
    coding of the items) is read FIRST and supersedes the older files for the same names; a name with anything but
    letters is skipped (noted in numbers.tex). Older sources, for names the new file lacks: coverage_items_t.json
    (registered jackknife; reviewer's worlds and ours), order_stakes_results*.json (agreement and stakes sets;
    measured with the round-1 variance). Returns the names added."""
    pw = Path(pw) if pw is not None else ROOT / "docs" / "power"
    added = []

    def add(name, value, source, meaning):
        if name not in mc.names:
            mc.add_raw(name, value, source, meaning)
            added.append(name)

    try:
        rev3 = json.loads((pw / "revision3_method.json").read_text(encoding="utf-8"))
        rev3 = rev3 if isinstance(rev3, dict) else {}
    except (OSError, ValueError):
        rev3 = {}
    skipped = []
    for key, e in rev3.items():
        if not isinstance(e, dict) or "value" not in e:
            continue
        if not re.fullmatch(r"[A-Za-z]+", str(key)):
            skipped.append(str(key))
            continue
        meaning = str(e.get("meaning", ""))
        for a, b in _METHOD_WORDS:
            meaning = meaning.replace(a, b)
        add("Method" + str(key), _method_value(e["value"]),
            "docs/power/revision3_method.json " + str(key) + ": " + str(e.get("source", "")).replace("\n", " "), meaning)
    if skipped:
        mc.notes.append("docs/power/revision3_method.json: skipped (a macro name must be letters only): "
                        + ", ".join(skipped))

    try:
        cov = json.loads((pw / "coverage_items_t.json").read_text())
    except (OSError, ValueError):
        cov = {}
    for tag, prefix in (("Indep", "r6|"), ("Ours", "ours|")):
        rows = {k: v for k, v in cov.items() if k.startswith(prefix)}
        if not rows:
            continue
        covers = [v["cover_normal"] for v in rows.values()]
        sizes = []
        for k, v in rows.items():
            th = float(k.split("|")[2])
            if th >= 1.0:
                sizes.append(v["drop_rej05_normal"])
            elif abs(th - 0.75) < 1e-9:
                sizes += [v["ni_rej05_normal"], v["md_rej05_normal"]]
        shares = [v.get("ni_item_share", float("nan")) for v in rows.values()] + \
                 [v.get("drop_item_share", float("nan")) for v in rows.values()]
        src = f"docs/power/coverage_items_t.json rows {prefix}* (registered jackknife, normal reference)"
        who = "an independently written simulator (the reviewer's worlds)" if tag == "Indep" else "our simulator"
        add(f"MethodCoverageTheta{tag}Lo", f"{min(covers):.3f}", src + " min cover_normal",
            f"lowest coverage of theta's 95% Fieller set over the worlds of {who}")
        add(f"MethodCoverageTheta{tag}Hi", f"{max(covers):.3f}", src + " max cover_normal",
            f"highest coverage of theta's 95% Fieller set over the worlds of {who}")
        if sizes and tag == "Indep":    # ours: the 5,000-replication cells below (MethodSizeOursLo/Hi) are the precise ones
            add(f"MethodWorstSize{tag}", f"{max(sizes):.3f}", src + " max boundary rejection rate",
                f"largest rejection rate of a one-sided PC1 contrast at its boundary, nominal 0.05, {who}")
        ok = [x for x in shares if isinstance(x, float) and math.isfinite(x)]
        if ok:
            add(f"MethodItemShare{tag}Hi", f"{max(ok):.2f}", src + " max median item share",
                f"largest median share of the variance due to items over the worlds of {who}")
    try:                                   # our boundary size, 5,000 replications per cell (variance_items.md)
        post = json.loads((pw / "variance_items_post.json").read_text()).get("size", [])
        sz = [r["size 0.05 jk"] for r in post if isinstance(r.get("size 0.05 jk"), (int, float))]
    except (OSError, ValueError, AttributeError):
        sz = []
    if sz:
        src = "docs/power/variance_items_post.json size rows (5,000 replications per boundary cell, registered jackknife)"
        add("MethodSizeOursLo", f"{min(sz):.3f}", src + " min", "smallest boundary size of a one-sided PC1 contrast, "
            "nominal 0.05, our simulator (21 world x group cells)")
        add("MethodSizeOursHi", f"{max(sz):.3f}", src + " max", "largest boundary size of a one-sided PC1 contrast, "
            "nominal 0.05, our simulator (21 world x group cells)")
    for tag, f in (("Ours", "order_stakes_results.json"), ("Indep", "order_stakes_results_r6.json")):
        try:
            rows = json.loads((pw / f).read_text())
        except (OSError, ValueError):
            continue
        rows = [r for r in rows if not r.get("cache")]
        for q, nm in (("order", "Order"), ("stakes", "Stakes")):
            vals = [r[q].get("cover_identifiable" if q == "order" else "cover") for r in rows if isinstance(r.get(q), dict)]
            vals = [v for v in vals if isinstance(v, (int, float)) and math.isfinite(v)]
            if vals:
                src = f"docs/power/{f} (no caching; {'among replications whose agreement is estimated, key cover_identifiable' if q == 'order' else 'all'})"
                qw = "retained-agreement (CSV name order)" if q == "order" else q
                add(f"MethodCoverage{nm}{tag}Lo", f"{min(vals):.3f}", src, f"lowest coverage of the {qw} set ({tag})")
                add(f"MethodCoverage{nm}{tag}Hi", f"{max(vals):.3f}", src, f"highest coverage of the {qw} set ({tag})")
    return added


def _add_once(mc: "Macros", parts, value, source, meaning="") -> None:
    """mc.add unless another writer has already made that name (the first writer's row is kept)."""
    if mc.prefix + camel(*parts) not in mc.names:
        mc.add(parts, value, source, meaning)


def check_macros(mc: "Macros", adir: Path) -> None:
    """The swap-day check numbers of the theory hand-over (docs/handover/theory_round2.md, section 1), each
    from its named row; a missing file or row gives no macro (the paper then fails loudly on the name)."""
    adir = Path(adir)

    def num0(v, d=0):
        return fmt(v, d) if fin(v) else None

    m0 = read_csv(adir / "sequential_margin0.csv")
    for version, nm in (("first_shown", "FirstShown"), ("ranking", "Ranking")):
        r = next((x for x in m0 if x.get("world") == "study" and x.get("version") == version
                  and x.get("part") == "needed" and fin(x.get("theta")) and abs(num(x["theta"]) - 1.0) < 1e-9), None)
        if r is None:
            continue
        src = f"sequential_margin0.csv world=study version={version} part=needed theta=1"
        what = {"first_shown": "first-shown keep-vs-wipe test (margin 0)", "ranking": "ranking test (margin 0)"}[version]
        v = num0(r.get("checks_median"))
        if v is not None:
            _add_once(mc, ("Check", "Margin", "Zero", nm, "Checks"), v, f"{src} column=checks_median",
                   f"{what}: median checks of the new model to a decision (no old-model call)")
        v = num0(r.get("bound_checks"))
        if v is not None:
            basis = (r.get("bound_basis") or "").strip()
            _add_once(mc, ("Check", "Margin", "Zero", nm, "Bound", "Checks"), v, f"{src} column=bound_checks",
                   f"{what}: information lower bound in checks (no valid rule needs fewer, in expectation)"
                   + (f"; {basis}" if basis else ""))
        # theory hand-over round 3, section 8: the mean number of checks beside the median
        v = num0(r.get("checks_mean"))
        if v is not None:
            _add_once(mc, ("Check", "Margin", "Zero", nm, "Mean", "Checks"), v, f"{src} column=checks_mean",
                      f"{what}: mean checks of the new model to a decision (no old-model call)")
    bc = [x for x in read_csv(adir / "sequential_bound_curve.csv") if x.get("curve") == "margin"
          and fin(x.get("theta_0")) and abs(num(x["theta_0"]) - 0.75) < 1e-9]
    src = "sequential_bound_curve.csv curve=margin theta_0=0.75"
    if not bc:
        bc = [x for x in read_csv(adir / "sequential_bound.csv") if x.get("setting") == "table_plugin"
              and x.get("decision") == "keep" and fin(x.get("power")) and abs(num(x["power"]) - 0.8) < 1e-9]
        src = "sequential_bound.csv setting=table_plugin decision=keep power=0.8"
    if bc:
        r = bc[0]
        what = "tasks of four checks any rule that checks whole random tasks needs to show at most a quarter lost"
        # revision 3: bound_tasks_chi2_lo/hi are the two-way (task id x write task) interval when the file also has
        # the revision-2 bootstrap in bound_tasks_chi2_boot_lo/hi; in older files they are that bootstrap
        iv = ("two-way (task id x write task) 95% interval" if "bound_tasks_chi2_boot_lo" in r
              else "95% interval (task bootstrap, file written before revision 3)")
        for col, nm, w in (("bound_tasks_chi2", (), what + " (second-order approximation)"),
                           ("bound_tasks_chi2_lo", ("Lo",), what + f"; lower end of its {iv}"),
                           ("bound_tasks_chi2_hi", ("Hi",), what + f"; upper end of its {iv}")):
            v = num0(r.get(col))
            if v is not None:
                _add_once(mc, ("Check", "Bound", "Keep", "Tasks") + nm, v, f"{src} column={col}", w)
    # theory hand-over round 3, section 8: the guaranteed floor of the bound (sequential_bound.csv table_plugin,
    # keep, power 0.8; else the margin curve's row at theta_0 = 0.75)
    fl = [(x, "sequential_bound.csv setting=table_plugin decision=keep power=0.8")
          for x in read_csv(adir / "sequential_bound.csv") if x.get("setting") == "table_plugin"
          and x.get("decision") == "keep" and fin(x.get("power")) and abs(num(x["power"]) - 0.8) < 1e-9
          and fin(x.get("bound_tasks_floor"))]
    fl += [(x, "sequential_bound_curve.csv curve=margin theta_0=0.75")
           for x in read_csv(adir / "sequential_bound_curve.csv") if x.get("curve") == "margin"
           and fin(x.get("theta_0")) and abs(num(x["theta_0"]) - 0.75) < 1e-9 and fin(x.get("bound_tasks_floor"))]
    if fl:
        r, fsrc = fl[0]
        what = ("guaranteed floor: fewest tasks of four checks any rule that checks whole random tasks needs, on "
                "average, to show at most a quarter lost (power 0.8, 5% error)")
        for col, nm, w in (("bound_tasks_floor", (), what), ("bound_tasks_floor_lo", ("Lo",), what + "; lower end of "
                           "its two-way 95% interval"), ("bound_tasks_floor_hi", ("Hi",), what + "; upper end of its "
                           "two-way 95% interval")):
            v = num0(r.get(col))
            if v is not None:
                _add_once(mc, ("Check", "Bound", "Keep", "Floor", "Tasks") + nm, v, f"{fsrc} column={col}", w)
    r = next((x for x in read_csv(adir / "sequential_curve.csv") if fin(x.get("theta"))
              and abs(num(x["theta"]) - 1.0) < 1e-9 and x.get("source", "sequential") == "sequential"), None)
    if r is not None and fin(r.get("tasks_q50")):
        _add_once(mc, ("Check", "Paired", "Median", "Tasks"), fmt(r["tasks_q50"], 0), "sequential_curve.csv theta=1 column=tasks_q50",
               "paired 0.75 test: median tasks to a decision at theta = 1")
    if r is not None and fin(r.get("tasks_mean_capped")):
        _add_once(mc, ("Check", "Paired", "Mean", "Tasks"), fmt(r["tasks_mean_capped"], 0),
                  "sequential_curve.csv theta=1 column=tasks_mean_capped",
                  "paired 0.75 test: mean tasks to a decision at theta = 1 (a run without a decision counted at "
                  "the horizon)")


def addition_macros(mc: "Macros", adir: Path, H: str = "ema_grade") -> None:
    """Headline numbers of the additions whose CSVs exist in adir (none when they were not run)."""
    adir = Path(adir)
    # transfer decomposition (msr.theory): decomp_summary.csv (law_summary.csv before the theory worker's
    # renaming), headline family, both streams; stem "Decomp"
    dfile = "decomp_summary.csv" if (adir / "decomp_summary.csv").exists() else "law_summary.csv"
    seen = set()
    for r in read_csv(adir / dfile):
        if r.get("family") != H or r.get("level") != "all" or r.get("group") not in ("all_swaps", "same_maker",
                                                                                     "same_family", "cross"):
            continue
        m_ = r.get("metric", "")
        if not any(t in m_ for t in ("gap", "mae", "R_V", "theta", "gamma", "rho", "coverage", "n_pairs", "perm_p",
                                     "tost", "spread")) or m_.startswith("truth") or m_.startswith("lomo"):
            continue
        grp = "same_maker" if r["group"] == "same_family" else r["group"]
        if (m_, grp) in seen:
            continue
        seen.add((m_, grp))
        src = f"{dfile} family={H} level=all group={r['group']} metric={m_}"
        base = ("Decomp", m_, grp)
        what = f"transfer decomposition, {r.get('detail') or m_}, {GROUP_WORDS.get(grp, grp)}"
        if m_.startswith(("gamma", "mean_gamma")) and not (fin(r.get("lo")) and fin(r.get("hi"))):
            continue                     # the transfer slope itself is printed only with its Fieller interval (theory, 6)
        if fin(r.get("value")):
            v = (fmt_p(r["value"]) if m_.startswith("perm_p") or m_.startswith("tost")
                 else fmt(r["value"], 0) if m_.startswith("n_pairs") else fmt(r["value"]))
            mc.add(base + ("Value",), v, f"{src} column=value", what)
        for col, nm in (("lo", "Lo"), ("hi", "Hi")):
            if fin(r.get(col)):
                mc.add(base + (nm,), fmt(r[col]), f"{src} column={col}", what + f"; {'lower' if nm == 'Lo' else 'upper'} end")
        if fin(r.get("p")) and not m_.startswith("perm_p"):
            mc.add(base + ("P",), fmt_p(r["p"]), f"{src} column=p", what + "; p-value")
    # forecast before the swap (msr.forecast), primary target theta ("T" in older files)
    for r in read_csv(adir / "forecast_models.csv"):
        if r.get("target") not in ("theta", "T"):
            continue
        model = r["model"].replace(" - ", " minus ")
        src = f"forecast_models.csv target={r['target']} model={r['model']}"
        for col, nm in (("r2_oof", ("R", "Two")), ("r2_oof_lo", ("R", "Two", "Lo")), ("r2_oof_hi", ("R", "Two", "Hi")),
                        ("mae_oof", ("MAE",)), ("mae_oof_lo", ("MAE", "Lo")), ("mae_oof_hi", ("MAE", "Hi")),
                        ("spearman_oof", ("Spearman",))):
            if fin(r.get(col)):
                mc.add(("Forecast", model, "Theta") + nm, fmt(r[col]), f"{src} column={col}",
                       f"forecast of theta before the swap, model {r['model']}: {col}")
    # ADDED (paper synchronising pass, 24 Nov 2026): the F1 control models (same_gap, ec_same_gap, their difference,
    # and the leave-both-models-out versions) are written even where they could not be fitted (a study with too few
    # models), so the forecast appendix always has a macro to print: "not fitted" with the CSV's note as its meaning.
    for r in read_csv(adir / "forecast_models.csv"):
        if r.get("target") not in ("theta", "T") or "same_gap" not in r.get("model", ""):
            continue
        model = r["model"].replace(" - ", " minus ")
        src = f"forecast_models.csv target={r['target']} model={r['model']}"
        for col, nm in (("r2_oof", ("R", "Two")), ("r2_oof_lo", ("R", "Two", "Lo")), ("r2_oof_hi", ("R", "Two", "Hi")),
                        ("mae_oof", ("MAE",)), ("mae_oof_lo", ("MAE", "Lo")), ("mae_oof_hi", ("MAE", "Hi"))):
            name = mc.prefix + camel("Forecast", model, "Theta", *nm)
            if name not in mc.names:
                mc.add(("Forecast", model, "Theta") + nm, "not fitted", f"{src} column={col} (empty)",
                       f"forecast of theta before the swap, model {r['model']}: {col}; empty in this study "
                       f"({(r.get('note') or 'not fitted').strip()})")
    # ADDED (paper synchronising pass, 24 Nov 2026): family T as registered (Part 11.2.4), nine separate Holm members:
    # T1-diff and T1-eq in each of the three swap groups and T2 for each other score family. Value and Holm-adjusted p
    # from the family_T rows of decomp_summary.csv; the raw p and the decision word are read from their 'detail'
    # text (written there by msr.theory.family_t); intervals from the matching per-group rows (T1-eq has none).
    dsum = read_csv(adir / dfile)
    by = {(r.get("family"), r.get("level"), r.get("group"), r.get("metric")): r for r in dsum}
    for r in dsum:
        if r.get("group") != "family_T" or r.get("family") != H:
            continue
        name = r["metric"]                                  # T1diff_<g>, T1eq_<g>, T2_<family>
        kind_, _, arg = name.partition("_")
        part = {"T1diff": "Spec", "T1eq": "Eq", "T2": "Diff"}.get(kind_)
        if part is None:
            continue
        src = f"{dfile} family={H} group=family_T metric={name}"
        detail = r.get("detail", "")
        what = {"Spec": f"family T, specification test T1-diff, {GROUP_WORDS.get(arg, arg)}",
                "Eq": f"family T, equivalence test T1-eq (margin 0.02 in Cw), {GROUP_WORDS.get(arg, arg)}",
                "Diff": f"family T, T2: pooled theta of score family {arg} minus the headline's"}[part]
        base = ("Fam", "T", part, arg)
        if fin(r.get("value")):
            mc.add(base + ("Value",), fmt(r["value"]), f"{src} column=value", what + "; estimate")
        mc.add(base + ("P", "Holm"), fmt_p(r.get("p")), f"{src} column=p", what + "; Holm-adjusted p over the family T members")
        raw = detail.split(";")[0].replace("raw p", "").strip() if detail.startswith("raw p") else ""
        mc.add(base + ("P",), fmt_p(raw), f"{src} column=detail (raw p)", what + "; unadjusted p")
        mc.add(base + ("Decision",), tex_escape(detail.split("; ")[-1]) if "; " in detail else "--",
               f"{src} column=detail (decision word)", what + "; decision")
        src_row = by.get((H, "all", arg, "spec_gap_cw_2way")) if part == "Spec" else \
            by.get((arg, "all", "all_swaps", "family_pooled_theta_minus_headline_2way")) if part == "Diff" else None
        if src_row is not None:
            for col, nm in (("lo", "Lo"), ("hi", "Hi")):
                if fin(src_row.get(col)):
                    mc.add(base + (nm,), fmt(src_row[col]),
                           f"{dfile} family={src_row['family']} group={src_row['group']} metric={src_row['metric']} column={col}",
                           what + f"; {'lower' if nm == 'Lo' else 'upper'} end of the two-way 95% interval")
    for r in read_csv(adir / "forecast_tests.csv"):
        src = f"forecast_tests.csv test={r['test']}"
        if fin(r.get("value")):
            mc.add(("Forecast", r["test"], "Value"), fmt(r["value"]), f"{src} column=value")
        mc.add(("Forecast", r["test"], "P"), fmt_p(r.get("p_one_sided")), f"{src} column=p_one_sided")
        mc.add(("Forecast", r["test"], "Min", "P"), fmt_p(r.get("min_attainable_p")), f"{src} column=min_attainable_p")
        mc.add(("Forecast", r["test"], "Result"), tex_escape(r.get("result", "")), f"{src} column=result")
        mc.add(("Forecast", r["test"], "Models", "Needed"), r.get("models_needed_to_be_testable", ""),
               f"{src} column=models_needed_to_be_testable")
    for r in read_csv(adir / "forecast_reliability.csv"):
        if r.get("predictor") == "ec":
            for col, nm in (("reliability_from_se", ("Reliability",)), ("spearman_brown", ("Split", "Half"))):
                if fin(r.get(col)):
                    mc.add(("Forecast", "EC") + nm, fmt(r[col]), f"forecast_reliability.csv predictor=ec column={col}")
    # stop-when-sure check (msr.sequential)
    for r in read_csv(adir / "sequential_rules.csv"):
        if r.get("kind") != "all_home_ok" or r["rule"] not in ("sequential", "audit_8", "audit_64", "plugin_64",
                                                                "audit_equal_cost", "plugin_equal_cost"):
            continue
        src = f"sequential_rules.csv rule={r['rule']} kind=all_home_ok"
        for col, nm in (("false_keep_rate", ("False", "Keep")), ("false_drop_rate", ("False", "Drop")),
                        ("undecided_share", ("Undecided",)), ("tasks_mean", ("Tasks",)), ("calls_mean", ("Calls",))):
            if fin(r.get(col)):
                mc.add(("Check", r["rule"]) + nm, fmt(r[col]), f"{src} column={col}")
    for r in read_csv(adir / "sequential_pairs.csv"):
        if r.get("owner") == "(summary)" and r.get("kind") in ("all swaps", "all swaps, home signal ok"):
            tag = ("All",) if r["kind"] == "all swaps" else ("Home", "Ok")
            src = f"sequential_pairs.csv owner=(summary) kind={r['kind']}"
            for col, nm in (("share_cell_orders_undecided_within_table", ("Undecided", "In", "Table")),
                            ("undecided_share", ("Undecided", "Replays")), ("pool_tasks_mean", ("Pool", "Tasks"))):
                if fin(r.get(col)):
                    mc.add(("Check",) + tag + nm, fmt(r[col]), f"{src} column={col}")
    null = read_csv(adir / "sequential_null.csv")
    if null:
        mc.add(("Check", "Null", "Max", "Error"), fmt(max(num(r["error_rate"]) for r in null)),
               "sequential_null.csv max of column=error_rate over all rows")
    simt = read_csv(adir / "sequential_simtruth.csv")
    for col, nm in (("false_keep", "Keep"), ("false_drop", "Drop")):
        v = [num(r[col]) for r in simt if fin(r.get(col))]
        if v:
            mc.add(("Check", "Known", "Truth", "Max", "False", nm), fmt(max(v)),
                   f"sequential_simtruth.csv max of column={col} over all rows")
    for r in read_csv(adir / "sequential_curve.csv"):
        if r.get("theta") in ("1", "0"):
            th = "One" if r["theta"] == "1" else "Zero"
            src = f"sequential_curve.csv theta={r['theta']}"
            for col, nm in (("tasks_q50", ("Median", "Tasks")), ("keep_share", ("Keep",)), ("drop_share", ("Drop",))):
                if fin(r.get(col)):
                    mc.add(("Check", "Theta", th) + nm, fmt(r[col], 3 if "share" in col else 0), f"{src} column={col}")
            dec = [k for k in r if k.startswith("decided_by_")]
            for k in dec:
                if fin(r.get(k)):
                    mc.add(("Check", "Theta", th, "Decided", "By", k.split("_")[-1]), fmt(r[k]), f"{src} column={k}")
    # ADDED (paper synchronising pass, 24 Nov 2026): the information lower bound of 11.4.10 at the study's own signal
    # (setting table_plugin), power 0.8, second-order (chi2) form, in tasks; the abstract quotes the KEEP value.
    for r in read_csv(adir / "sequential_bound.csv"):
        if r.get("setting") == "table_plugin" and r.get("decision") in ("keep", "drop") and fin(r.get("power")) \
                and abs(num(r["power"]) - 0.8) < 1e-9 and fin(r.get("bound_tasks_chi2")):
            nm = "Keep" if r["decision"] == "keep" else "Drop"
            mc.add(("Check", "Bound", nm, "Tasks"), fmt(r["bound_tasks_chi2"], 0),
                   f"sequential_bound.csv setting=table_plugin decision={r['decision']} power=0.8 column=bound_tasks_chi2",
                   meaning=f"information lower bound: fewest fresh-check tasks (4 checks each) any rule with 5% error "
                           f"control needs to {r['decision']} a swap with theta={r['theta_1']} with probability 0.8, "
                           f"at the study's own home signal")


def addition_skip_reason(name: str, st) -> str:
    """'' when the study supports the addition, else the one-line reason it is skipped."""
    n_models = len(st.models)
    n_swaps = len([p for p in st.pairs if p[0] != p[1]])
    if n_swaps == 0:
        return "the study has no swap (owner different from reader)"
    if name == "theory" and int(st.probe.repeats) < 2:
        return f"the transfer law needs 2 repeats of the old model on every probe cell (probe.repeats = {st.probe.repeats})"
    if name == "forecast" and n_models < 3:
        return f"leave-one-model-out needs at least 3 models (the study has {n_models})"
    if name == "forecast" and not st.build.no_memory_run:
        return "the forecast needs the no-memory run of the score tasks (build.no_memory_run is false)"
    return ""


def run_additions(study: str, out: Path, runs_dir=None, draws: int | None = None, quiet: bool = False,
                  settings: dict | None = None) -> tuple:
    """Run the three additions (tables to runs/<study>/analysis/, figures to out). Returns
    (figure paths, one-line notes). settings: optional keyword arguments per addition, e.g.
    {"sequential": {"replays": 100}}, for quick runs (the tests); the defaults are the registered ones."""
    import contextlib
    from msr import analysis as A
    from msr import forecast as FC
    from msr import llm as L
    from msr import sequential as SQ
    from msr import theory as TH
    settings = settings or {}
    paths, notes = [], []

    @contextlib.contextmanager
    def runs_at(d):
        old = L.RUNS
        if d:
            L.RUNS = Path(d).resolve()
        try:
            yield
        finally:
            L.RUNS = old

    with runs_at(runs_dir):
        st = A.resolve_study(study)
        for name in ("theory", "forecast", "sequential"):
            why = addition_skip_reason(name, st)
            if why:
                notes.append(f"{name}: skipped ({why})")
                continue
            kw = dict(settings.get(name) or {})
            if name == "theory":
                res = TH.run(st.name, draws=kw.pop("draws", draws), fig_dir=out,
                             printer=(lambda *a, **k: None) if quiet else print, **kw)
                paths += [Path(x) for x in res.get("figures", [])]
            elif name == "forecast":
                res = FC.run(st.name, n_boot=kw.pop("n_boot", draws), fig_dir=out, verbose=not quiet, **kw)
                paths += [v for k, v in res.items() if k.startswith("fig:")]
            else:
                res = SQ.run(st.name, fig_dir=out, verbose=not quiet, **kw)
                paths += [v for k, v in res.items() if k.startswith("fig:")]
            notes.append(f"{name}: run")
    return paths, notes


# ---------------------------------------------------------------------------
# Tables
# ---------------------------------------------------------------------------


def _short(v, d=2) -> str:
    return fmt(v, d)


def write_table_main(adir: Path, out: Path, study: str, kind) -> Path:
    meta = {r["key"]: r["value"] for r in read_csv(adir / "meta.csv")}
    H = meta.get("headline_family", "ema_grade")
    K = meta.get("primary_k", "")
    lam = f"fixed_{float(meta.get('primary_lambda', '0.5')):g}"
    tp = [r for r in read_csv(adir / "theta_pairs.csv") if r["family"] == H and r["level"] == "all"
          and r["owner"] != r["reader"]]
    ap = {(r["family"], r["arm"], r["owner"], r["reader"]): r for r in read_csv(adir / "arms_pairs.csv")
          if r["metric"] == "value" and r["level"] == "all"}
    arms = [("keep", H), ("wipe", H), (lam, H), (f"recal_{K}", H), ("own", H), ("ceiling", "-")]
    cols = ["Owner $\\to$ reader", "$\\theta$ [95\\% CI]", "$D$", "$R$"] + [tex_escape(a) for a, _ in arms]
    n = len(cols)
    L = [header_comment("table_main.tex", study, kind, f"one row per ordered pair (score family {H}, pooled over "
                        "streams); theta = retained ranking signal with its two-way (task x item) Fieller interval "
                        "(always shown; dagger = flag 'home signal too weak on the calibration tasks'); "
                        "D = drop in weighted concordance and R = concordance ratio (secondary); arm columns = "
                        "first-shown success [task-only 95% CI]; ceiling = in-sample best candidate. "
                        "Sources: theta_pairs.csv (level=all), arms_pairs.csv (metric=value, level=all)."),
         "\\begin{tabular}{l" + "r" * (n - 1) + "}", "\\toprule", " & ".join(cols) + "\\\\", "\\midrule"]
    b = banner(kind, n)
    if b:
        L.append(b.rstrip("\n"))
    for g in GROUPS:
        rows = [r for r in tp if r["group"] == g]
        if not rows:
            continue
        L.append(f"\\multicolumn{{{n}}}{{l}}{{\\emph{{{GROUP_TEX[g]}}}}}\\\\")
        for r in rows:
            th = ci_tex(r, "theta", "theta_lo", "theta_hi", 2) + \
                ("" if r.get("theta_status_calibration", r["theta_status"]) == "defined" else "$^{\\dagger}$")
            cells = [tex_escape(f"{r['owner']} → {r['reader']}"), th, _short(r.get("D"), 3), _short(r.get("R"))]
            for a, f in arms:
                x = ap.get((f, a, r["owner"], r["reader"]))
                cells.append(ci_tex(x, "est", "lo", "hi", 2) if x else "--")
            L.append(" & ".join(cells) + "\\\\")
        if g != GROUPS[-1]:
            L.append("\\midrule")
    L += ["\\bottomrule", "\\end{tabular}"]
    p = out / "table_main.tex"
    p.write_text("\n".join(L) + "\n", encoding="utf-8")
    return p


def write_table_groups(adir: Path, out: Path, study: str, kind) -> Path:
    """The primary family (revision 2): PC1 drop, material drop and no material drop (each with the
    home-signal test) and PC2, in each swap group, under Holm; each group's between-pair SD and the
    95 % prediction interval for a new pair (PC1 rows: of theta; PC2 rows: of keep - wipe), and the
    share of each test's variance that comes from the items. PC3 / PC4 go to table_secondary.tex."""
    rows = [r for r in read_csv(adir / "primary_tests.csv") if not is_secondary(r)]
    fam_n = sum(1 for r in rows if truthy(r.get("in_family")))
    spread = {(("PC1" if r["comparison"].startswith("PC1") else "PC2"), r["group"]): r for r in group_re_rows(adir)}
    cols = ["Test", "Group", "Estimate [95\\% CI]", "$p$", "Holm $p$", "Reading", "Range of pairs",
            "SD between pairs", "New pair [95\\% PI]", "Item share"]
    n = len(cols)
    L = [header_comment("table_groups.tex", study, kind, f"the {fam_n} primary tests (PC1 drop, material drop and no "
                        "material drop, each an intersection-union test with the home-signal test, and PC2 keep - "
                        "wipe; x 3 swap groups), Holm over all of them; two-way (task x item, jackknife) intervals; "
                        "each group's range of per-pair estimates (theta for PC1), its between-pair SD and the 95% "
                        "prediction interval for a new pair (same-maker groups: DerSimonian-Laird random effects "
                        "within the group, t(k - 2); cross-maker, revision 3: crossed owner + reader random effects "
                        "by REML, a new pair = a new owner and a new reader, t with min(owners, readers) - 1 df, an "
                        "approximation since pairs share tasks and items; its SD cell gives owner SD / reader SD), "
                        "and the share of the test's variance that comes from the items. PC3 and PC4 are secondary: "
                        "table_secondary.tex. Source: primary_tests.csv, group_re.csv."),
         "\\begin{tabular}{llrrrlrrrr}", "\\toprule", " & ".join(cols) + "\\\\", "\\midrule"]
    b = banner(kind, n)
    if b:
        L.append(b.rstrip("\n"))
    stat = {"PC1-drop": "PC1 drop ($\\theta<1$)", "PC1-MD": "PC1 material drop ($\\theta<0.75$)",
            "PC1-NI": "PC1 no material drop ($\\theta>0.75$)", "PC2": "PC2 keep $-$ wipe, success"}
    prev = None
    for r in rows:
        c = r["comparison"]
        if prev and prev != c:
            L.append("\\midrule")
        prev = c
        est = ci_tex(r, "est", "lo", "hi", 3)
        if c == "PC1-drop" and fin(r.get("spread_min")):    # the spread is of the loss 1 - theta
            rng = f"{fmt(1 - num(r['spread_max']), 2)} \\ldots {fmt(1 - num(r['spread_min']), 2)}"
        elif c == "PC2" and fin(r.get("spread_min")):
            rng = f"{fmt(r.get('spread_min'), 2)} \\ldots {fmt(r.get('spread_max'), 2)}"
        else:
            rng = ""
        sp = spread.get(("PC1" if c.startswith("PC1") else "PC2", r["group"])) if c in ("PC1-drop", "PC2") else None
        if sp and is_crossed(sp) and has_val(sp.get("tau_owner")) and has_val(sp.get("tau_reader")):
            sd = f"{val_or_inf(sp.get('tau_owner'))} / {val_or_inf(sp.get('tau_reader'))}"
        else:
            sd = fmt(sp.get("tau"), 3) if sp and has_val(sp.get("tau")) else ""
        pi = (f"[{val_or_inf(sp.get('pi_lo'), 2)}, {val_or_inf(sp.get('pi_hi'), 2)}]"
              if sp and has_val(sp.get("pi_lo")) and has_val(sp.get("pi_hi")) else "")
        L.append(" & ".join([stat.get(c, tex_escape(c)), GROUP_TEX.get(r["group"], r["group"]), est,
                             fmt_p(r.get("p_holm_input")), fmt_p(r.get("holm_adjusted_p")),
                             tex_escape(reading(r)), rng, sd, pi,
                             fmt(r.get("item_share"), 2) if fin(r.get("item_share")) else ""]) + "\\\\")
    L += ["\\bottomrule", "\\end{tabular}"]
    p = out / "table_groups.tex"
    p.write_text("\n".join(L) + "\n", encoding="utf-8")
    return p


def write_table_secondary(adir: Path, out: Path, study: str, kind) -> Path:
    """PC3 and PC4 (revision 2: secondary, outside the Holm family): the swap-minus-home contrast of the
    level-corrected log score, its unadjusted p, the owner-reader base-rate gap beside it, and the
    sensitivity analysis with the level target set to the reader's with-item success on the
    calibration cells (R6 W7). The note states the additivity assumption."""
    rows = [r for r in read_csv(adir / "primary_tests.csv") if is_secondary(r)]
    cols = ["Contrast", "Group", "Swap $-$ home [95\\% CI]", "$p$ (unadjusted)", "Base-rate gap",
            "With-item target [95\\% CI]", "$p$ (with-item)"]
    n = len(cols)
    assumption = next(((r.get("assumption") or "").strip() for r in rows if (r.get("assumption") or "").strip()),
                      ADDITIVITY)
    L = [header_comment("table_secondary.tex", study, kind, "PC3 (fixed discount - keep) and PC4 (recal - keep; "
                        "recal - wipe after the semicolon): swap minus home, held-out log score level-corrected to "
                        "the reader's no-memory success; SECONDARY, not in the Holm family, p unadjusted. Base-rate "
                        "gap = owner minus reader no-memory success (success points). With-item target = the same "
                        "contrast with the level target at the reader's with-item success on the calibration cells. "
                        "Source: primary_tests.csv (role=secondary)."),
         f"% Assumption: {assumption}.",
         "\\begin{tabular}{llrrrrr}", "\\toprule", " & ".join(cols) + "\\\\", "\\midrule"]
    b = banner(kind, n)
    if b:
        L.append(b.rstrip("\n"))
    stat = {"PC3": "PC3 fixed $-$ keep", "PC4": "PC4 recal $-$ keep; $-$ wipe"}
    prev = None
    for r in rows:
        c = r["comparison"]
        if prev and prev != c:
            L.append("\\midrule")
        prev = c
        est = ci_tex(r, "est", "lo", "hi", 3)
        if c == "PC4" and fin(r.get("est_b")):
            est += "; " + ci_tex(r, "est_b", "lo_b", "hi_b", 3)
        L.append(" & ".join([stat.get(c, tex_escape(c)), GROUP_TEX.get(r["group"], r["group"]), est,
                             fmt_p(r.get("p_holm_input")),
                             fmt(r.get("base_gap"), 3), ci_tex(r, "est_lcw", "lo_lcw", "hi_lcw", 3),
                             fmt_p(r.get("p_lcw"))]) + "\\\\")
    L.append("\\midrule")
    L.append(f"\\multicolumn{{{n}}}{{p{{0.95\\linewidth}}}}{{\\footnotesize Assumption: "
             f"{tex_escape(assumption)}.}}\\\\")
    L += ["\\bottomrule", "\\end{tabular}"]
    p = out / "table_secondary.tex"
    p.write_text("\n".join(L) + "\n", encoding="utf-8")
    return p


def write_table_stakes(adir: Path, out: Path, study: str, kind) -> Path:
    rows = read_csv(adir / "stakes.csv")
    cols = ["Group", "Contrast", "At home", "After the swap", "After $-$ home"]
    L = [header_comment("table_stakes.tex", study, kind, "what is at stake, in success points (first-shown success; "
                        "0.01 = 1 point): keep - wipe, keep - shuffled, ceiling - keep and keep - none, at home (each "
                        "swap's owner on its own bank) and after the swap, two-way 95% CI. Source: stakes.csv."),
         "\\begin{tabular}{llrrr}", "\\toprule", " & ".join(cols) + "\\\\", "\\midrule"]
    b = banner(kind, len(cols))
    if b:
        L.append(b.rstrip("\n"))
    prev = None
    for r in rows:
        if r["group"] not in GROUPS + ("all_swaps",):
            continue
        if prev and prev != r["group"]:
            L.append("\\midrule")
        prev = r["group"]
        L.append(" & ".join([GROUP_TEX.get(r["group"], r["group"]), tex_escape(r["contrast"]),
                             ci_tex(r, "home", "home_lo", "home_hi", 3), ci_tex(r, "swap", "swap_lo", "swap_hi", 3),
                             ci_tex(r, "swap_minus_home", "swap_minus_home_lo", "swap_minus_home_hi", 3)]) + "\\\\")
    L += ["\\bottomrule", "\\end{tabular}"]
    p = out / "table_stakes.tex"
    p.write_text("\n".join(L) + "\n", encoding="utf-8")
    return p


def write_table_family_t(adir: Path, out: Path, study: str, kind) -> Path:
    """ADDED (paper synchronising pass, 24 Nov 2026): family T of Part 11.2.4, the nine registered Holm members, from
    the family_T rows of decomp_summary.csv (value, Holm-adjusted p; raw p and decision word from 'detail') and the
    matching per-group rows (two-way 95% interval; none is written for the equivalence members)."""
    meta = {r["key"]: r["value"] for r in read_csv(adir / "meta.csv")}
    H = meta.get("headline_family", "ema_grade")
    dsum = read_csv(adir / "decomp_summary.csv")
    by = {(r.get("family"), r.get("level"), r.get("group"), r.get("metric")): r for r in dsum}
    cols = ["Member", "Group or score family", "Estimate [95\\% CI]", "$p$", "Holm $p$", "Decision"]
    L = [header_comment("table_family_t.tex", study, kind, "family T of the transfer decomposition (pre-registration "
                        "11.2.4): T1-diff (specification test) and T1-eq (equivalence within 0.02 in Cw) in each swap "
                        "group, T2 (pooled theta of each other score family minus the headline's); "
                        f"{sum(1 for r in dsum if r.get('group') == 'family_T' and r.get('family') == H)} Holm members. "
                        "Source: decomp_summary.csv (group=family_T and the per-group rows)."),
         "\\begin{tabular}{llrrrl}", "\\toprule", " & ".join(cols) + "\\\\", "\\midrule"]
    b = banner(kind, len(cols))
    if b:
        L.append(b.rstrip("\n"))
    label = {"T1diff": "T1-diff (specification)", "T1eq": "T1-eq (equivalence)", "T2": "T2 (score family)"}
    for r in dsum:
        if r.get("group") != "family_T" or r.get("family") != H:
            continue
        kind_, _, arg = r["metric"].partition("_")
        if kind_ not in label:
            continue
        detail = r.get("detail", "")
        src = by.get((H, "all", arg, "spec_gap_cw_2way")) if kind_ == "T1diff" else \
            by.get((arg, "all", "all_swaps", "family_pooled_theta_minus_headline_2way")) if kind_ == "T2" else None
        est = ci_tex(src, "value", "lo", "hi", 3) if src is not None else fmt(r.get("value"))
        raw = detail.split(";")[0].replace("raw p", "").strip() if detail.startswith("raw p") else ""
        L.append(" & ".join([label[kind_], GROUP_TEX.get(arg, tex_escape(arg)), est, fmt_p(raw), fmt_p(r.get("p")),
                             tex_escape(detail.split("; ")[-1]) if "; " in detail else "--"]) + "\\\\")
    L += ["\\bottomrule", "\\end{tabular}"]
    p = out / "table_family_t.tex"
    p.write_text("\n".join(L) + "\n", encoding="utf-8")
    return p


def write_table_arms(adir: Path, out: Path, study: str, kind) -> Path:
    meta = {r["key"]: r["value"] for r in read_csv(adir / "meta.csv")}
    H = meta.get("headline_family", "ema_grade")
    ag = {(r["family"], r["arm"], r["metric"], r["group"]): r for r in read_csv(adir / "arms_groups.csv")
          if r["level"] == "all"}
    K = meta.get("primary_k", "")
    lam = f"fixed_{float(meta.get('primary_lambda', '0.5')):g}"
    arms = ["none", "relevance", "keep", "wipe", "constant", lam, "shuffled"] + \
        [f"{a}_{K}" for a in ("powerprior", "recal", "retest", "audit", "pooled", "fresh")] + ["own", "split_half", "ceiling"]
    gs = [g for g in GROUPS + ("home",) if any(k[3] == g for k in ag)]
    lmetric = "log_lc" if any(k[2] == "log_lc" for k in ag) else "log"
    cols = ["Rule"] + [f"{GROUP_TEX[g]}" for g in gs] + [f"{GROUP_TEX[g]}" for g in gs]
    n = len(cols)
    L = [header_comment("table_arms.tex", study, kind, f"every swap-day rule by swap group (score family {H}, pooled "
                        f"over streams): first-shown success, then held-out log score ({lmetric}: level-corrected to "
                        "the reader's no-memory success), each [task-only 95% CI]; Home = the owners on their own "
                        "banks. split_half = pick on one repeat, score on the other (a reference, not a bound); "
                        "ceiling = in-sample best candidate; constant = every item at the reader's no-memory "
                        "success. Source: arms_groups.csv (level=all)."),
         "\\begin{tabular}{l" + "r" * (n - 1) + "}", "\\toprule",
         f" & \\multicolumn{{{len(gs)}}}{{c}}{{First-shown success}} & \\multicolumn{{{len(gs)}}}{{c}}{{Held-out log score, level-corrected}}\\\\",
         f"\\cmidrule(lr){{2-{1 + len(gs)}}}\\cmidrule(lr){{{2 + len(gs)}-{1 + 2 * len(gs)}}}",
         " & ".join(cols) + "\\\\", "\\midrule"]
    b = banner(kind, n)
    if b:
        L.append(b.rstrip("\n"))
    for a in arms:
        fam = "-" if a in ("none", "relevance", "split_half", "ceiling", "oracle") else H
        cells = [tex_escape(a)]
        any_ = False
        for m in ("value", lmetric):
            for g in gs:
                r = ag.get((fam, a, m, g))
                cells.append(ci_tex(r, "est", "lo", "hi", 3) if r else "--")
                any_ = any_ or r is not None
        if any_:
            L.append(" & ".join(cells) + "\\\\")
    L += ["\\bottomrule", "\\end{tabular}"]
    p = out / "table_arms.tex"
    p.write_text("\n".join(L) + "\n", encoding="utf-8")
    return p


def write_table_costs(adir: Path, out: Path, study: str, kind) -> Path:
    rows = [r for r in read_csv(adir / "costs_by_model.csv") if r["stage"] == "total"]
    arms = read_csv(adir / "costs_by_arm.csv")
    L = [header_comment("table_costs.tex", study, kind, "calls, tokens and US dollars per model (all stages), then the "
                        "extra reader calls and dollars one swap day costs under each rule. Sources: "
                        "costs_by_model.csv (stage=total), costs_by_arm.csv.")]
    cols = ["Model", "Calls", "Fresh calls", "Input tokens", "Output tokens", "USD"]
    L += ["\\begin{tabular}{lrrrrr}", "\\toprule", " & ".join(cols) + "\\\\", "\\midrule"]
    b = banner(kind, len(cols))
    if b:
        L.append(b.rstrip("\n"))
    for r in rows:
        if r["model"] == "all":
            L.append("\\midrule")
        L.append(" & ".join([tex_escape(r["model"] if r["model"] != "all" else "All models"),
                             f"{int(num(r['calls'])):,}", f"{int(num(r['fresh_calls'])):,}",
                             f"{int(num(r['tokens_in'])):,}", f"{int(num(r['tokens_out'])):,}",
                             f"{num(r['usd']):.2f}"]).replace(",", "{,}") + "\\\\")
    L += ["\\bottomrule", "\\end{tabular}", "", "\\medskip", ""]
    # revision 2: own = ONE reader build; the level information is one shared fixed row (Part 6.4)
    cols = ["Swap-day rule", "Reader calls per swap day", "Old-model calls before the swap", "USD per swap day"]
    L += ["\\begin{tabular}{lrrr}", "\\toprule", " & ".join(cols) + "\\\\", "\\midrule"]
    if b:
        L.append(banner(kind, len(cols)).rstrip("\n"))
    for r in arms:
        calls = num(r["reader_calls_per_swap_day"])
        oc = num(r.get("owner_calls_before_swap", 0))
        shared = "shared" in str(r.get("cost_kind", ""))
        L.append(" & ".join([tex_escape(r["arm"] + (" (shared, once per swap day)" if shared else "")),
                             "--" if not math.isfinite(calls) else f"{calls:,.0f}".replace(",", "{,}"),
                             "--" if not math.isfinite(oc) else f"{oc:,.0f}".replace(",", "{,}"),
                             "--" if not fin(r.get("usd_per_swap_day")) else f"{num(r['usd_per_swap_day']):.4f}"]) + "\\\\")
    L += ["\\bottomrule", "\\end{tabular}"]
    p = out / "table_costs.tex"
    p.write_text("\n".join(L) + "\n", encoding="utf-8")
    return p


# ---------------------------------------------------------------------------
# Construct checks (msr/construct.py, scripts/make_construct_assets.py): the correctness table, the free
# baselines table and the ONE cost table of the paper. Column meanings: runs/<study>/analysis/CONSTRUCT.md.


def construct_macros(mc: "Macros", adir: Path) -> int:
    """Load construct_macros.csv (msr.construct) into the macro file, with its sources and meanings, the
    same way as every other macro. Its names already carry the study-kind prefix; a name whose prefix
    differs from this study's is skipped (a stale file of another study). Returns the number loaded."""
    n = 0
    for r in read_csv(Path(adir) / "construct_macros.csv"):
        name = (r.get("macro") or "").lstrip("\\").strip()
        if not name or not name.startswith(mc.prefix + "Constr") or name in mc.names:
            continue
        mc.add_raw(name, r.get("value", ""), "construct_macros.csv: " + (r.get("source") or ""), r.get("meaning") or "")
        n += 1
    return n


#: columns of construct_correctness.csv that msr.construct.reading reads (registered rule, Part 8.2.24)
READING_COLS = ("home_flag", "home_flag_res_ols", "correct_share_home_ols", "correct_share_home_ols_lo",
                "correct_share_home_ols_hi")


def construct_reading(row: dict) -> tuple:
    """(label, source words) of the registered construct reading for one construct_correctness.csv row: the CSV's
    own label when a column `reading` / `reading_label` carries it, else msr.construct.reading (the registered rule)
    applied to the row's home flags and the grade's share of the home signal. ('', '') when neither works."""
    for col in ("reading_label", "reading"):
        if (row.get(col) or "").strip():
            return row[col].strip(), f"column={col}"
    if not all(c in row for c in READING_COLS):
        return "", ""
    try:
        from msr import construct as C_
    except Exception:                    # the module cannot be imported here: no macro
        return "", ""
    r = {k: (num(v) if k.startswith("correct_share") else (v or "").strip()) for k, v in row.items()}
    try:
        lab, _ = C_.reading(r)
    except Exception:
        return "", ""
    return lab, "columns=" + ", ".join(READING_COLS) + " read by msr.construct.reading (registered rule)"


def construct_reading_macros(mc: "Macros", adir: Path) -> int:
    """ConstructReading<Group>: the registered reading words of the construct check (Part 8.2.24; "mostly a
    correctness detector", "partly ...", "signal beyond correctness", "inconclusive", "cannot tell") for the headline
    score, per kind of swap and all swaps, pooled over streams (level all). The label is in no CSV column today
    (msr.construct writes it to CONSTRUCT.md only), so it is made from the row by the same function; a missing file
    or row gives no macro. Returns the number added."""
    rows = read_csv(Path(adir) / "construct_correctness.csv")
    if not rows:
        return 0
    meta = {r["key"]: r["value"] for r in read_csv(Path(adir) / "meta.csv")}
    H = meta.get("headline_family", "ema_grade")
    n = 0
    for g in ("upgrade", "downgrade", "cross", "all_swaps"):
        r = next((x for x in rows if x.get("score") == H and x.get("scope") == "group" and x.get("group") == g
                  and x.get("level") == "all"), None)
        if r is None:
            continue
        lab, how = construct_reading(r)
        name = mc.prefix + camel("Construct", "Reading", g)
        if not lab or name in mc.names:
            continue
        mc.add(("Construct", "Reading", g), tex_escape(lab),
               f"construct_correctness.csv score={H} scope=group group={g} level=all {how}",
               f"registered reading of the construct check (Part 8.2.24) for {GROUP_WORDS.get(g, g)}, all streams: is "
               "the learned score mainly a detector of correct stored answers? (cannot tell / mostly a correctness "
               "detector / partly a correctness detector / signal beyond correctness / inconclusive)")
        n += 1
    return n


def _ci(r: dict, k: str, lo: str, hi: str, d: int = 3) -> str:
    if not fin(r.get(k)):
        return "--"
    x = f"{num(r[k]):.{d}f}"
    if fin(r.get(lo)) and fin(r.get(hi)):
        x += f" [{num(r[lo]):.{d}f}, {num(r[hi]):.{d}f}]"
    elif str(r.get(lo, "")).strip() in ("-inf", "inf") or str(r.get(hi, "")).strip() in ("-inf", "inf"):
        x += " [unbounded]"
    return x


def _f3(x, d: int = 3) -> str:
    return f"{num(x):.{d}f}" if fin(x) else "--"


def write_table_correctness(adir: Path, out: Path, study: str, kind) -> Path | None:
    """table_correctness.tex: does the learned score do more than detect a correct stored answer? Per group
    (pooled over streams): Cw of the stored-answer-correct reference and of the learned score at home and
    after the swap; the share of the home signal the grade carries (1 - V_resid / V, 95 % interval); theta
    within correct-correct, wrong-wrong and mixed pairs; theta of the residualised score (95 % interval)."""
    cor = read_csv(Path(adir) / "construct_correctness.csv")
    ref = read_csv(Path(adir) / "construct_reference.csv")
    if not cor or not ref:
        return None
    meta = {r["key"]: r["value"] for r in read_csv(Path(adir) / "meta.csv")}
    H = meta.get("headline_family", "ema_grade")
    pick = lambda rows, score, g: next((r for r in rows if r.get("score") == score and r.get("scope") == "group"  # noqa: E731
                                        and r.get("group") == g and r.get("level") == "all"), {})
    cols = ["Group", "Cw correct (home / after)", f"Cw {H} (home / after)", "Grade's share of home signal",
            "theta cc", "theta ii", "theta mixed", "theta residualised"]
    L = [header_comment("table_correctness.tex", study, kind,
                        "the learned score beside the stored-answer-correct reference (decision D7, R5 W1). Sources: "
                        "construct_reference.csv (score=correct and the headline family; scope=group, level=all), "
                        "construct_correctness.csv (columns correct_share_home_ols, theta_cc, theta_ii, theta_mixed, "
                        "theta_res_ols); meanings in CONSTRUCT.md.")]
    L += ["\\begin{tabular}{lccccccc}", "\\toprule", " & ".join(tex_escape(c) for c in cols) + "\\\\", "\\midrule"]
    b = banner(kind, len(cols))
    if b:
        L.append(b.rstrip("\n"))
    for g in ("home", "upgrade", "downgrade", "cross", "all_swaps"):
        rc, rl, cc = pick(ref, "correct", g), pick(ref, H, g), pick(cor, H, g)
        if not (rc or rl or cc):
            continue
        swap = g != "home"
        L.append(" & ".join([
            tex_escape(GROUP_WORDS.get(g, g)),
            f"{_f3(rc.get('C_home'))} / {_f3(rc.get('C_swap')) if swap else '--'}",
            f"{_f3(rl.get('C_home'))} / {_f3(rl.get('C_swap')) if swap else '--'}",
            _ci(cc, "correct_share_home_ols", "correct_share_home_ols_lo", "correct_share_home_ols_hi", 2),
            _f3(cc.get("theta_cc")) if swap else "--", _f3(cc.get("theta_ii")) if swap else "--",
            _f3(cc.get("theta_mixed")) if swap else "--",
            _ci(cc, "theta_res_ols", "theta_res_ols_lo", "theta_res_ols_hi") if swap else "--"]) + "\\\\")
    L += ["\\bottomrule", "\\end{tabular}", "",
          "% cc = both candidates' stored answers graded correct, ii = both wrong, mixed = one of each. The residualised "
          "score is the learned score minus its mean over the bank's items of the same grade (ols); the grade's share "
          "= 1 - V(residualised) / V at home. theta = V after the swap / V at home within those pairs."]
    p = Path(out) / "table_correctness.tex"
    p.write_text("\n".join(L) + "\n", encoding="utf-8")
    return p


BASELINE_RULES = (("keep", "keep:{H}", "the owner's scores"), ("wipe", "wipe:{H}", "the start value"),
                  ("stored answer correct", "correct", "the write-time grade of each stored answer"),
                  ("re-answer", "reanswer", "the reader's own answer agrees with the stored one"),
                  ("propensity-weighted (IPS)", "ips", "self-normalised inverse-propensity success when shown"),
                  ("doubly robust", "dr", "IPS with the owner's no-memory result as the direct model"))


#: the registered secondary paid-stage rules (msr.secondary_stages, open point 30) printed below the free baselines
STAGE_RULES = (("new model as judge", "judge", "the new model's 1-10 rating of each stored item"),
               ("owner's self-rating", "self_rating", "the old model's write-time 1-10 rating of each item"),
               ("relearn", "relearn", "the new model re-earns the scores on the frozen items"))


def write_table_baselines(adir: Path, out: Path, study: str, kind) -> Path | None:
    """table_baselines.tex: keep, wipe and the free baselines (stored-answer-correct, re-answer, the two
    propensity-weighted scores), all swaps pooled over streams: first-shown success, its difference to keep
    and to wipe (two-way 95 % intervals) and the level-corrected log score. Revision 3 (open point 30): below them
    the paid secondary rules judge, self-rating and relearn from secondary_stage_groups.csv (no log score: a rating
    is not a probability), and re-answer's success columns from the same file when it has re-answer's row."""
    rows = read_csv(Path(adir) / "construct_baselines.csv")
    if not rows:
        return None
    meta = {r["key"]: r["value"] for r in read_csv(Path(adir) / "meta.csv")}
    H = meta.get("headline_family", "ema_grade")
    ssg = {r.get("rule"): r for r in read_csv(Path(adir) / "secondary_stage_groups.csv")
           if r.get("group") == "all_swaps" and r.get("level") == "all"}
    cols = ["Rule", "Uses", "First-shown success", "minus keep [95 %]", "minus wipe [95 %]", "Log score (level-corr.)"]
    L = [header_comment("table_baselines.tex", study, kind,
                        "keep, wipe and the free swap-day baselines (decision D7, R5 W4-W6), then the registered "
                        "secondary paid rules (judge, self-rating, relearn; no log score). Source: "
                        "construct_baselines.csv (scope=group, group=all_swaps, level=all); meanings in CONSTRUCT.md; "
                        "secondary_stage_groups.csv (group=all_swaps, level=all; two-way intervals, items clustered by "
                        "write task) for the paid rules and, when it has the row, for re-answer's success columns.")]
    L += ["\\begin{tabular}{llcccc}", "\\toprule", " & ".join(tex_escape(c) for c in cols) + "\\\\", "\\midrule"]
    b = banner(kind, len(cols))
    if b:
        L.append(b.rstrip("\n"))

    def stage_cells(x):
        return [_f3(x.get("value_rule")), _ci(x, "minus_keep", "minus_keep_lo", "minus_keep_hi"),
                _ci(x, "minus_wipe", "minus_wipe_lo", "minus_wipe_hi")]

    for name, rule, uses in BASELINE_RULES:
        rule = rule.format(H=H)
        r = next((x for x in rows if x.get("rule") == rule and x.get("scope") == "group" and x.get("group") == "all_swaps"
                  and x.get("level") == "all"), None)
        if r is None:
            continue
        x = ssg.get(rule) if rule == "reanswer" else None
        if x is not None and fin(x.get("value_rule")):
            mid = stage_cells(x)
        else:
            mid = [_f3(r.get("value")),
                   "--" if rule.startswith("keep:") else
                   _ci(r, "value_minus_keep", "value_minus_keep_lo", "value_minus_keep_hi"),
                   "--" if rule.startswith("wipe:") else
                   _ci(r, "value_minus_wipe", "value_minus_wipe_lo", "value_minus_wipe_hi")]
        L.append(" & ".join([tex_escape(name), tex_escape(uses)] + mid + [_f3(r.get("log_lc"), 4)]) + "\\\\")
    stage = [(name, uses, ssg[rule]) for name, rule, uses in STAGE_RULES if rule in ssg]
    if stage:
        L.append("\\midrule")
        for name, uses, x in stage:
            L.append(" & ".join([tex_escape(name), tex_escape(uses)] + stage_cells(x) + ["--"]) + "\\\\")
    L += ["\\bottomrule", "\\end{tabular}"]
    p = Path(out) / "table_baselines.tex"
    p.write_text("\n".join(L) + "\n", encoding="utf-8")
    return p


def _cost_groups(rows: list) -> list:
    """Rows of the ONE cost table: (label, row) with the k-check rules collapsed per k (they cost the same)."""
    by = {r["rule"]: r for r in rows}
    out = []
    for rule, label in (("none", "none, relevance (nothing bought)"),
                        ("keep", "keep, wipe, shuffled, fixed discount, constant"),
                        ("correct", "stored answer correct, IPS, doubly robust (logged, free)"),
                        ("reanswer", "re-answer")):
        if rule in by:
            out.append((label, by[rule]))
    ks = sorted({int(r["rule"].split("_")[-1]) for r in rows if r["rule"].startswith("recal_")})
    for k in ks:
        if f"recal_{k}" in by:
            out.append((f"k-check rules, k = {k} (recal, power prior, audit, retest, pooled, fresh)", by[f"recal_{k}"]))
    for rule, label in (("own", "own (the reader builds its own bank)"),
                        ("sequential_cap8", "paired keep-or-drop test, at most 8 tasks"),
                        ("sequential_cap64", "paired keep-or-drop test, at most 64 tasks"),
                        ("sequential", "paired keep-or-drop test, no cap"),
                        ("forecast", "pre-swap forecast"), ("forecast_20_checks", "forecast's 20-check baseline"),
                        ("split_half", "split-half, ceiling (references, not deployable)")):
        if rule in by:
            out.append((label, by[rule]))
    return out


def write_table_cost_one(adir: Path, out: Path, study: str, kind) -> Path | None:
    """table_cost_one.tex: the ONE cost table (decision D7): calls of one swap day (one owner bank, one
    reader, one stream, one order) by who makes them and when, for this study's sizes and the registered
    study's. The level information (the reader's no-memory runs of the calibration tasks behind every
    level-corrected log / Brier score, PC3 and PC4) is a SHARED FIXED row, bought once per swap day and not
    added to each rule (Part 6.4); first-shown success (PC2) needs none. Source: construct_costs.csv."""
    rows = read_csv(Path(adir) / "construct_costs.csv")
    if not rows:
        return None
    lv = {sz: num(next((r[f"swap_day_reader_level_{sz}"] for r in rows if fin(r.get(f"swap_day_reader_level_{sz}"))
                        and num(r[f"swap_day_reader_level_{sz}"]) > 0), "nan")) for sz in ("practice", "real")}

    def cell(r, sz, col):
        v = r.get(f"{col}_{sz}")
        return f"{num(v):,.0f}".replace(",", "{,}") if fin(v) else "--"

    def total_wo_level(r, sz):
        parts = [num(r.get(f"{c}_{sz}")) for c in ("pre_swap_owner_calls", "swap_day_reader_checks",
                                                   "swap_day_reader_other")]
        if not all(math.isfinite(x) for x in parts):
            return "--"
        return f"{sum(parts):,.0f}".replace(",", "{,}")

    cols = ["Rule", "Old model, before the swap", "Reader checks", "Reader, other", "Total (this study)",
            "Old model, before (registered)", "Reader (registered)", "Total (registered)"]
    L = [header_comment("table_cost_one.tex", study, kind,
                        "calls per swap day by who makes them and when (decision D7). The level information is one "
                        "shared fixed row, not added to each rule (Part 6.4). Source: construct_costs.csv "
                        "(_practice = this study's sizes, _real = config/study.yaml); meanings in CONSTRUCT.md.")]
    L += ["\\begin{tabular}{lrrrrrrr}", "\\toprule", " & ".join(tex_escape(c) for c in cols) + "\\\\", "\\midrule"]
    b = banner(kind, len(cols))
    if b:
        L.append(b.rstrip("\n"))
    fmt0 = lambda x: f"{x:,.0f}".replace(",", "{,}") if math.isfinite(x) else "--"  # noqa: E731
    L.append(" & ".join(["level information (shared by every rule read on the log or Brier score; PC3, PC4)", "0",
                         "0", fmt0(lv["practice"]), fmt0(lv["practice"]), "0", fmt0(lv["real"]), fmt0(lv["real"])])
             + "\\\\")
    L.append("\\midrule")
    # the registered study's swap-day rows of the keep-or-drop tests and the forecast come from the theory
    # worker's functions (msr.sequential.swap_day_calls, msr.forecast.forecast_calls), not from copies of them
    from msr import forecast as FC
    from msr import sequential as SQ
    reg = {}
    m0 = read_csv(Path(adir) / "sequential_margin0.csv")
    for version in ("ranking", "first_shown"):
        r = next((x for x in m0 if x.get("world") == "study" and x.get("version") == version
                  and x.get("part") == "needed" and fin(x.get("theta")) and abs(num(x["theta"]) - 1.0) < 1e-9), None)
        if r is not None and fin(r.get("checks_median")):
            per = SQ.CHECKS_PER_TASK if version == "ranking" else 2
            reg[f"margin0_{version}"] = SQ.swap_day_calls(f"margin0_{version}", num(r["checks_median"]) / per)
    curve = next((x for x in read_csv(Path(adir) / "sequential_curve.csv") if fin(x.get("theta"))
                  and abs(num(x["theta"]) - 1.0) < 1e-9), None)
    n_med = num(curve["tasks_q50"]) if curve is not None and fin(curve.get("tasks_q50")) else float("nan")
    reg["paired_store200"] = SQ.swap_day_calls("sequential", 200, 200)
    if math.isfinite(n_med):
        reg["paired_median"] = SQ.swap_day_calls("sequential", n_med, n_med)
    fc = FC.forecast_calls()
    for label, r in _cost_groups(rows):
        reader_real = [num(r.get(f"swap_day_reader_{c}_real")) for c in ("checks", "other")]
        if label.startswith("paired keep-or-drop test") or label.startswith("pre-swap forecast"):
            continue                     # replaced below by the rows from the functions
        L.append(" & ".join([tex_escape(label), cell(r, "practice", "pre_swap_owner_calls"),
                             cell(r, "practice", "swap_day_reader_checks"), cell(r, "practice", "swap_day_reader_other"),
                             total_wo_level(r, "practice"), cell(r, "real", "pre_swap_owner_calls"),
                             fmt0(sum(reader_real)) if all(math.isfinite(x) for x in reader_real) else "--",
                             total_wo_level(r, "real")]) + "\\\\")
    L.append("\\midrule")
    for key, label in (("margin0_first_shown", "break-even test, first-shown (median checks at theta = 1)"),
                       ("margin0_ranking", "break-even test, ranking (median checks at theta = 1)"),
                       ("paired_store200", "paired 0.75 test, store of 200 tasks (the replay's)"),
                       ("paired_median", f"paired 0.75 test, store for its median ({n_med:,.0f} tasks)"
                        if math.isfinite(n_med) else "")):
        if key not in reg:
            continue
        c = reg[key]
        old_, new_ = num(c["old_model_calls_before_retirement"]), num(c["new_model_calls"])
        L.append(" & ".join([tex_escape(label), "", "", "", "", fmt0(old_), fmt0(new_), fmt0(old_ + new_)]) + "\\\\")
    L.append(" & ".join([tex_escape("pre-swap forecast (no-memory calls of both models)"), "", "", "", "",
                         fmt0(num(fc["old_model_calls"])), fmt0(num(fc["new_model_calls_before_swap"])),
                         fmt0(num(fc["total_calls"]))]) + "\\\\")
    # the four new paid arms (pipeline stages being built): DESIGN COUNTS, to be replaced by logged counts
    L.append("% design count, replace with logged count: the four rows below")
    sz = {}
    try:
        from msr import analysis as A_
        from msr import construct as C_
        sz = {"practice": C_.sizes_of(A_.resolve_study(study)), "real": C_.sizes_of(A_.resolve_study("config/study.yaml"))}
    except Exception:            # a study file that cannot be read: the rows keep their dashes
        sz = {}
    for label, who, f in (("new model as judge (one new-model call per stored item)", "new", lambda z: z["n_write"]),
                          ("owner's write-time self-rating (one old-model call per item)", "old", lambda z: z["n_write"]),
                          ("relearn on frozen content (one score phase by the new model)", "new",
                           lambda z: z["epochs"] * z["n_score"]),
                          ("re-exploration after the swap (its m tasks)", "new", None)):
        cells = []
        for k in ("practice", "real"):
            z = sz.get(k)
            v = float(f(z)) if (z and f is not None) else float("nan")
            cells.append((v if who == "old" else float("nan"), v if who == "new" else float("nan"), v))
        (po, pn, pt), (ro, rn, rt) = cells
        L.append(" & ".join([tex_escape(label), fmt0(po) if who == "old" else "0", "0",
                             fmt0(pn) if who == "new" else "0", fmt0(pt) if f else "m",
                             fmt0(ro) if who == "old" else "0", fmt0(rn) if who == "new" else ("0" if f else "m"),
                             fmt0(rt) if f else "m"]) + "\\\\")
    L += ["\\bottomrule", "\\end{tabular}", "",
          "% Totals exclude the shared level information (first row). own: ONE reader build on this stream and order. "
          "The last rows (registered study only) come from msr.sequential.swap_day_calls and "
          "msr.forecast.forecast_calls: the paired 0.75 test needs 8 old-model calls per stored check task plus the home "
          "flag's 800, all before the old model retires; the break-even (margin-0) tests need no old-model call; the "
          "forecast needs 1,150 calls (950 new-model, 200 old-model). -- = not applicable at these sizes (k larger than "
          "the calibration pool)."]
    p = Path(out) / "table_cost_one.tex"
    p.write_text("\n".join(L) + "\n", encoding="utf-8")
    return p


# ---------------------------------------------------------------------------
# The names the paper asks for (paper/assets/REQUESTED_MACROS.md), each from its named row.


PENDING = "--"          # printed where the study has not produced the number yet (the meaning says why)


def best_crossfit_row(adir: Path, group: str, k=None) -> dict | None:
    """The row of best_rule_crossfit.csv (revision 3, E4) for a swap group: the one at the study's primary k when the
    file has several budgets, else the group's only row; None when the file or the group is missing."""
    rows = [r for r in read_csv(Path(adir) / "best_rule_crossfit.csv") if r.get("group") == group]
    if not rows:
        return None
    if k not in (None, "") and len(rows) > 1:
        at = [r for r in rows if fin(r.get("k")) and fin(k) and abs(num(r["k"]) - num(k)) < 1e-9]
        if at:
            return at[0]
    return rows[0]


def paper_macros(mc: "Macros", adir: Path) -> None:
    """The macros requested by the paper worker that no other writer makes. A number this study cannot
    produce (a stage not yet run, a prediction interval with fewer than 3 pairs, a test that is not made)
    gets the value '--' and a meaning that says why, so the paper never prints 'missing'."""
    adir = Path(adir)
    meta = {r["key"]: r["value"] for r in read_csv(adir / "meta.csv")}
    H = meta.get("headline_family", "ema_grade")
    tests = {r["test"]: r for r in read_csv(adir / "primary_tests.csv")}

    def add(parts, value, source, meaning):
        name = mc.prefix + camel(*parts)
        if name not in mc.names:
            mc.add(parts, value, source, meaning)

    for g in GROUPS:
        r = tests.get(f"PC1-drop-{g}", {})
        src = f"primary_tests.csv test=PC1-drop-{g}"
        words = GROUP_WORDS.get(g, g)
        status = str(r.get("order_status", "") or "")
        defined = status == "defined"
        # revision 3 (E3): "retained agreement" in every displayed word; "not identifiable" -> NOT_ESTIMATED; a cell or
        # status with the later-session check's words prints them (the macro names keep "Order")
        if not_valid(r.get("order")) or not_valid(status):
            ov = tex_escape((r["order"] if not_valid(r.get("order")) else status).strip())
        elif defined and fin(r.get("order")):
            ov = fmt(r["order"])
        elif not r:
            ov = PENDING
        else:
            ov = NOT_ESTIMATED
        add(("Order", g), ov, f"{src} column=order (order_status={status})",
            f"{AGREEMENT} (theta / stakes: the noise-corrected correlation of the two models' item-effect differences "
            f"as seen through the old scores), {words}; '{NOT_ESTIMATED}' when the readers' spread on the calibration "
            f"tasks is under z = 2; '{NOT_VALID}' when the later-session check flags a model of the group"
            + ("; the PC1-drop row is missing in this study" if not r else ""))
        for col, nm in (("order_lo", "Lo"), ("order_hi", "Hi")):
            cv = r.get(col)
            v = tex_escape((cv if not_valid(cv) else status).strip()) if (not_valid(cv) or not_valid(status)) \
                else (fmt(cv) if defined and fin(cv) else PENDING)
            add(("Order", g, nm), v, f"{src} column={col}",
                f"{AGREEMENT}, {words}; {'lower' if nm == 'Lo' else 'upper'} end of its 95 % interval")
        nv_words = lambda cv: (cv if not_valid(cv) else status).strip()  # noqa: E731
        sv = r.get("stakes")
        add(("Stakes", "Ratio", g), tex_escape(nv_words(sv)) if (not_valid(sv) or not_valid(status))
            else (fmt(sv) if fin(sv) else PENDING),
            f"{src} column=stakes", f"stakes ratio sqrt(S_reader / S_owner), {words}")
        for col, nm in (("stakes_lo", "Lo"), ("stakes_hi", "Hi")):
            cv = r.get(col)
            add(("Stakes", "Ratio", g, nm), tex_escape(nv_words(cv)) if (not_valid(cv) or not_valid(status))
                else (fmt(cv) if fin(cv) else PENDING),
                f"{src} column={col}", f"stakes ratio, {words}; {'lower' if nm == 'Lo' else 'upper'} end of its 95 % "
                "interval")
        add(("Theta", g, "Decision"), tex_escape(r.get("label") or r.get("decision") or PENDING),
            f"{src} column=label", f"the registered PC1 reading of {words} (msr.metrics.pc1_label of its three Holm "
            "decisions, each with the home-signal test)")
    for r in group_re_rows(adir):
        if r.get("comparison") != "PC1 theta" or not r["_src"].startswith("group_re.csv") \
                or r.get("family") not in (H, None, ""):
            continue
        src = f"group_re.csv comparison=PC1 theta group={r['group']}" + (" method=" + r["method"] if is_crossed(r) else "")
        k = int(num(r.get("k"))) if fin(r.get("k")) else int(num(r.get("n_swaps"))) if fin(r.get("n_swaps")) else 0
        how = ("crossed owner + reader random effects (REML): a new owner and a new reader, t with min(owners, "
               "readers) - 1 df; an approximation (pairs share tasks and items; few levels)" if is_crossed(r)
               else "random effects within the group, t(k - 2)")
        for col, nm in (("pi_lo", "PILo"), ("pi_hi", "PIHi")):
            add(("Theta", r["group"], nm), fmt(r[col]) if fin(r.get(col)) else PENDING, f"{src} column={col}",
                f"95 % prediction interval of theta for a new pair of this kind ({k} pairs; none with fewer than 3; "
                f"{how})")
    # the maker term beside capability gap and error consistency (R5 W9): msr.forecast's regression
    reg = next((r for r in read_csv(adir / "forecast_capability_regression.csv")
                if r.get("target") == "theta" and r.get("term") == "same_maker"), None)
    if reg is not None:
        src = "forecast_capability_regression.csv target=theta term=same_maker"
        add(("Maker", "Term", "Est"), fmt(reg["coef"]), f"{src} column=coef",
            "maker term: coefficient of the same-maker flag in theta ~ 1 + same maker + gap + |gap| + error consistency")
        for col, nm in (("lo", "Lo"), ("hi", "Hi")):
            if fin(reg.get(col)):
                add(("Maker", "Term", nm), fmt(reg[col]), f"{src} column={col}",
                    "maker term; " + ("lower" if nm == "Lo" else "upper") + " end of its task-bootstrap interval (descriptive)")
        p = reg.get("p_one_sided_maker_relabelings")
        add(("Maker", "Term", "P"), fmt_p(p) if fin(p) else PENDING, f"{src} column=p_one_sided_maker_relabelings",
            "maker term: no test is made (pairs share models, and maker-preserving relabellings cannot move the maker "
            "flag); report its interval instead")
    # revision 3 (E3, theory hand-over round 3 section 5): the conversion of the 0.75 margin to success points
    # (MarginPointsAllSwaps) is WITHDRAWN; the margin is a registered convention on the ranking signal
    for comp, nm in (("PC3", "Three"), ("PC4", "Four")):
        r = tests.get(f"{comp}-cross", {})
        add(("PC", nm, "Cross", "No", "Level", "Est"), fmt(r["raw_log_did"], 4) if fin(r.get("raw_log_did")) else PENDING,
            f"primary_tests.csv test={comp}-cross column=raw_log_did",
            f"{comp} swap-minus-home contrast on the raw log score (no level information), cross-maker swaps")
    # the registered secondary paid-stage rules (open point 30): msr.secondary_stages writes
    # secondary_stage_groups.csv (rule, group, level, minus_keep, ...); the older sources are the fallback
    ssg = {(r.get("rule"), r.get("group"), r.get("level")): r for r in read_csv(adir / "secondary_stage_groups.csv")}
    arms = [r for r in read_csv(adir / "arms_groups.csv") if r.get("family") == H and r.get("metric") == "value"
            and r.get("group") == "cross" and r.get("level") == "all"]
    base = next((r for r in read_csv(adir / "construct_baselines.csv") if r.get("rule") == "reanswer"
                 and r.get("scope") == "group" and r.get("group") == "cross" and r.get("level") == "all"), None)
    for rule, nm, what in (("reanswer", "Reanswer", "re-answer"), ("judge", "Judge", "the new model as judge"),
                           ("self_rating", "Self Rating", "the owner's write-time self-rating"),
                           ("relearn", "Relearn", "relearn on frozen content")):
        r = ssg.get((rule, "cross", "all"))
        if r is not None and fin(r.get("minus_keep")):
            src = f"secondary_stage_groups.csv rule={rule} group=cross level=all"
            add(("Arm", nm, "Minus", "Keep", "Cross"), fmt(r["minus_keep"]), f"{src} column=minus_keep",
                f"first-shown success, {what} minus keep, cross-maker swaps (registered secondary, not in any family)")
            for col, sfx in (("minus_keep_lo", "Lo"), ("minus_keep_hi", "Hi")):
                if fin(r.get(col)):
                    add(("Arm", nm, "Minus", "Keep", "Cross", sfx), fmt(r[col]), f"{src} column={col}",
                        f"first-shown success, {what} minus keep, cross-maker swaps; "
                        f"{'lower' if sfx == 'Lo' else 'upper'} end of its two-way 95 % interval")
            if fin(r.get("minus_keep_p")):
                add(("Arm", nm, "Minus", "Keep", "Cross", "P"), fmt_p(r["minus_keep_p"]), f"{src} column=minus_keep_p",
                    f"first-shown success, {what} minus keep, cross-maker swaps; unadjusted two-sided p")
        elif rule == "reanswer":
            add(("Arm", nm, "Minus", "Keep", "Cross"),
                fmt(base["value_minus_keep"]) if base is not None and fin(base.get("value_minus_keep")) else PENDING,
                "construct_baselines.csv rule=reanswer group=cross level=all column=value_minus_keep",
                "first-shown success, re-answer minus keep, cross-maker swaps")
        elif rule in ("judge", "relearn"):
            x = next((a for a in arms if a.get("arm") == rule), None)
            add(("Arm", nm, "Minus", "Keep", "Cross"),
                fmt(x["minus_keep"]) if x is not None and fin(x.get("minus_keep")) else PENDING,
                f"arms_groups.csv family={H} arm={rule} metric=value group=cross level=all column=minus_keep",
                f"first-shown success, {rule} minus keep, cross-maker swaps" + ("" if x is not None else
                                                                               f"; the {rule} stage has not run in this study"))
        else:
            add(("Arm", nm, "Minus", "Keep", "Cross"), PENDING,
                "secondary_stage_groups.csv rule=self_rating group=cross level=all column=minus_keep (missing)",
                f"first-shown success, {what} minus keep, cross-maker swaps; the stage's table is not written in this "
                "study")
        if r is not None and has_val(r.get("theta")):
            src = f"secondary_stage_groups.csv rule={rule} group=cross level=all"
            for col, sfx, w in (("theta", (), "theta of the rule's scores (share of its home signal kept)"),
                                ("theta_lo", ("Lo",), "theta of the rule's scores, lower end of its two-way Fieller set"),
                                ("theta_hi", ("Hi",), "theta of the rule's scores, upper end of its two-way Fieller set")):
                if has_val(r.get(col)):
                    add(("Arm", nm, "Theta", "Cross") + sfx, val_or_inf(r[col]), f"{src} column={col}",
                        f"{what}: {w}, cross-maker swaps")
    home = [num(r["agree_rate"]) for r in read_csv(adir / "reanswer_home.csv") if fin(r.get("agree_rate"))]
    if home:
        add(("Reanswer", "Home", "Agree", "Rate"), fmt(sum(home) / len(home)),
            f"reanswer_home.csv mean of column=agree_rate over {len(home)} rows (owner x stream x seed)",
            "re-answer's home value: how often the owner's second no-memory answer to a write task agrees with its "
            "stored answer, mean over the owners' banks")
    for r in read_csv(adir / "theta_visit_thirds.csv"):
        if r.get("family") != H or r.get("group") not in GROUPS + ("all_swaps",):
            continue
        src = f"theta_visit_thirds.csv third={r['third']} group={r['group']}"
        words = f"theta of the headline score within the {r['third']} visit tercile (Part 8.2.7), {GROUP_WORDS.get(r['group'], r['group'])}"
        add(("Theta", "Visits", "Third", r["third"], r["group"]), fmt(r["theta"]) if fin(r.get("theta")) else PENDING,
            f"{src} column=theta", words)
        for col, nm in (("theta_lo", "Lo"), ("theta_hi", "Hi")):
            add(("Theta", "Visits", "Third", r["third"], r["group"], nm), fmt(r[col]) if fin(r.get(col)) else PENDING,
                f"{src} column={col}", words + f"; {'lower' if nm == 'Lo' else 'upper'} end of its two-way Fieller interval")
    # revision 3 (E4): "the best rule with checks" is CROSS-FITTED (best_rule_crossfit.csv): the check rule chosen on
    # one half of the evaluation tasks, its gain over keep measured on the other half, both ways averaged. The
    # largest of the rules on the same data is kept only as ...Naive... (winner's curse; never used for advice).
    k = meta.get("primary_k", "")
    for g in GROUPS:
        r = best_crossfit_row(adir, g, k)
        gw = GROUP_WORDS.get(g, g)
        if r is None and g != "cross":
            continue
        src = (f"best_rule_crossfit.csv group={g}" + (f" k={r.get('k')}" if r is not None and r.get("k") else ""))
        what = (f"first-shown success, cross-fitted: the check rule chosen on one half of the tasks, its gain over keep "
                f"measured on the other half, both ways averaged ({gw})")
        add(("Arm", "Best", "Check", "Minus", "Keep", g), fmt(r["est"]) if r is not None and fin(r.get("est")) else PENDING,
            f"{src} column=est", what + ("" if r is not None else "; best_rule_crossfit.csv is not written in this study"))
        for col, sfx in (("lo", "Lo"), ("hi", "Hi")):
            add(("Arm", "Best", "Check", "Minus", "Keep", g, sfx),
                fmt(r[col]) if r is not None and fin(r.get(col)) else PENDING, f"{src} column={col}",
                what + f"; {'lower' if sfx == 'Lo' else 'upper'} end of its two-way 95 % interval (task id x write "
                "task, both halves)")
        if r is not None and fin(r.get("p_two")):
            add(("Arm", "Best", "Check", "Minus", "Keep", g, "P"), fmt_p(r["p_two"]), f"{src} column=p_two",
                what + "; two-sided p, unadjusted")
        if r is not None and (r.get("rule_on_A") or r.get("rule_on_B")):
            add(("Arm", "Best", "Check", "Rules", g),
                tex_escape(f"{r.get('rule_on_A') or '--'} / {r.get('rule_on_B') or '--'}"),
                f"{src} columns=rule_on_A, rule_on_B",
                f"the check rules chosen on half A and on half B (each then measured on the other half), {gw}")
    chk = [x for x in arms if x.get("k") == str(k) and fin(x.get("minus_keep"))
           and x.get("arm_base") in ("recal", "powerprior", "powerprior_flat", "audit", "retest", "pooled", "fresh")]
    best = max(chk, key=lambda x: num(x["minus_keep"])) if chk else None
    naive_src = f"arms_groups.csv family={H} metric=value group=cross level=all k={k} column=minus_keep (largest)"
    if best is None:
        cf = best_crossfit_row(adir, "cross", k)
        if cf is not None and fin(cf.get("naive_est")):
            best = {"minus_keep": cf["naive_est"], "arm": cf.get("naive_best_rule") or "none"}
            naive_src = "best_rule_crossfit.csv group=cross column=naive_est"
    add(("Arm", "Best", "Check", "Naive", "Minus", "Keep", "Cross"),
        fmt(best["minus_keep"]) if best is not None else PENDING, naive_src,
        f"largest of the rules on the same data (winner's curse; not used for advice): first-shown success of the "
        f"largest k = {k} check rule ({best['arm'] if best is not None else 'none'}) minus keep, cross-maker swaps")


def _pts(x, d: int = 1) -> str:
    return f"{100 * num(x):.{d}f}" if fin(x) else "--"


def write_table_stakes_body(adir: Path, out: Path, study: str, kind) -> Path | None:
    """table_stakes_body.tex: the body's small stakes table (one column, at most 8 rows): keep - wipe and keep -
    shuffled per kind of swap (and relearn - keep when that arm exists), at home, after the swap and after minus
    home, in success points with two-way 95 % intervals. Source: stakes.csv (and arms_groups.csv)."""
    rows = read_csv(Path(adir) / "stakes.csv")
    if not rows:
        return None
    by = {(r["group"], r["contrast"]): r for r in rows}
    sel = [(g, c) for g in GROUPS for c in ("keep - wipe", "keep - shuffled") if (g, c) in by]
    rel = [(g, "relearn - keep") for g in ("upgrade", "cross") if (g, "relearn - keep") in by]
    sel = (sel + rel)[:8]
    cols = ["Swaps", "Contrast", "Home", "After", "After - home"]
    L = [header_comment("table_stakes_body.tex", study, kind,
                        "what the order is worth, in success points (x 100) with two-way 95 % intervals; body version "
                        "(one column, at most 8 rows). Source: stakes.csv.")]
    L += ["\\begin{tabular}{llrrr}", "\\toprule", " & ".join(tex_escape(c) for c in cols) + "\\\\", "\\midrule"]
    b = banner(kind, len(cols))
    if b:
        L.append(b.rstrip("\n"))
    short = {"upgrade": "Upgrades", "downgrade": "Downgrades", "cross": "Cross-maker"}

    def c3(r, k):
        if not fin(r.get(k)):
            return "--"
        return f"{_pts(r[k])} [{_pts(r.get(k + '_lo'))}, {_pts(r.get(k + '_hi'))}]"

    for g, c in sel:
        r = by[(g, c)]
        L.append(" & ".join([tex_escape(short[g]), tex_escape(c), c3(r, "home"), c3(r, "swap"),
                             c3(r, "swap_minus_home")]) + "\\\\")
    L += ["\\bottomrule", "\\end{tabular}"]
    p = Path(out) / "table_stakes_body.tex"
    p.write_text("\n".join(L) + "\n", encoding="utf-8")
    return p


def write_table_decision(adir: Path, out: Path, study: str, kind) -> Path | None:
    """table_decision.tex (revision 3, E4): what to do on swap day by kind of swap and check budget, from the
    registered tests and the cross-fitted estimates ONLY, labelled descriptive: per swap group theta with its PC1
    reading and keep - wipe with its PC2 reading (the primary family, Holm over its 12 members), then for each check
    budget k in best_rule_crossfit.csv the cross-fitted gain over keep of the best check rule (chosen on one half of
    the evaluation tasks, measured on the other half, both ways averaged; two-way 95 % interval) with the rules the
    two halves chose. No largest-of-several comparison enters. None when both files are missing."""
    tests = {r["test"]: r for r in read_csv(Path(adir) / "primary_tests.csv") if not is_secondary(r)}
    cf = read_csv(Path(adir) / "best_rule_crossfit.csv")
    if not any(f"{c}-{g}" in tests for c in ("PC1-drop", "PC2") for g in GROUPS) and not cf:
        return None
    meta = {r["key"]: r["value"] for r in read_csv(Path(adir) / "meta.csv")}
    ks = sorted({num(r["k"]) for r in cf if fin(r.get("k"))})
    if not ks:
        ks = [num(meta["primary_k"])] if fin(meta.get("primary_k")) else [float("nan")]
    kword = lambda k: f"$k={k:g}$" if math.isfinite(k) else "$k$"  # noqa: E731
    cols = ["Kind of swap", "$\\theta$ [95\\% CI]", "PC1 reading", "Keep $-$ wipe [95\\% CI]", "PC2 reading"] + \
        [f"Best check rule $-$ keep, {kword(k)} (cross-fitted) [95\\% CI]" for k in ks]
    n = len(cols)
    L = [header_comment("table_decision.tex", study, kind,
                        "DESCRIPTIVE decision table by kind of swap and check budget (revision 3, E4): only the "
                        "registered tests (PC1 reading and PC2 keep - wipe with their Holm decisions; two-way "
                        "intervals) and the cross-fitted gain over keep of the best check rule (the rule chosen on one "
                        "half of the evaluation tasks, its gain over keep measured on the other half, both ways "
                        "averaged; two-way task id x write task interval; the rules chosen on half A / half B in "
                        "parentheses). The halves share write tasks, so the choice is not fully independent of the "
                        "estimate when items carry much of the variance. No largest-of-several comparison is used. "
                        "Sources: primary_tests.csv, best_rule_crossfit.csv."),
         "\\begin{tabular}{l" + "r" * (n - 1) + "}", "\\toprule", " & ".join(cols) + "\\\\", "\\midrule"]
    b = banner(kind, n)
    if b:
        L.append(b.rstrip("\n"))
    for g in GROUPS:
        t1, t2 = tests.get(f"PC1-drop-{g}"), tests.get(f"PC2-{g}")
        grows = [r for r in cf if r.get("group") == g]
        if t1 is None and t2 is None and not grows:
            continue
        cells = [GROUP_TEX[g], ci_tex(t1, "est", "lo", "hi", 2) if t1 else "--",
                 tex_escape(reading(t1)) if t1 else "--", ci_tex(t2, "est", "lo", "hi", 3) if t2 else "--",
                 tex_escape(reading(t2)) if t2 else "--"]
        for k in ks:
            r = next((x for x in grows if fin(x.get("k")) and abs(num(x["k"]) - k) < 1e-9), None)
            if r is None and len(grows) == 1 and not fin(grows[0].get("k")):
                r = grows[0]
            if r is None or not fin(r.get("est")):
                cells.append("--")
                continue
            rules = f" ({r.get('rule_on_A') or '--'} / {r.get('rule_on_B') or '--'})"
            cells.append(ci_tex(r, "est", "lo", "hi", 3) + tex_escape(rules))
        L.append(" & ".join(cells) + "\\\\")
    L.append("\\midrule")
    L.append(f"\\multicolumn{{{n}}}{{p{{0.95\\linewidth}}}}{{\\footnotesize Descriptive: registered tests and "
             "cross-fitted estimates only (the check rule chosen on one half of the tasks, its gain over keep measured "
             "on the other half, both ways averaged); no advice rests on the largest of several rules on the same "
             "data.}\\\\")
    L += ["\\bottomrule", "\\end{tabular}"]
    p = Path(out) / "table_decision.tex"
    p.write_text("\n".join(L) + "\n", encoding="utf-8")
    return p


def write_table_strata(adir: Path, out: Path, study: str, kind) -> Path | None:
    """table_strata.tex: theta by construct stratum, per kind of swap and all swaps (headline score, pooled over
    streams): the share of informative pairs with an answer-matching / near-duplicate candidate (after the swap),
    theta without either, and theta by the visit stratum of the pair's less-visited candidate (0, 1-2, 3-5, 6+),
    with two-way 95 % intervals. Sources: construct_overlap.csv, construct_visits_theta.csv (CONSTRUCT.md)."""
    ov = read_csv(Path(adir) / "construct_overlap.csv")
    vt = read_csv(Path(adir) / "construct_visits_theta.csv")
    if not ov and not vt:
        return None
    meta = {r["key"]: r["value"] for r in read_csv(Path(adir) / "meta.csv")}
    H = meta.get("headline_family", "ema_grade")
    strata = sorted({r["stratum"] for r in vt if r.get("score") == H}, key=lambda x: (len(x), x))
    cols = ["Swaps", "Share match", "Share near-dup.", "theta without either"] + [f"theta, visits {s}" for s in strata]
    L = [header_comment("table_strata.tex", study, kind,
                        "theta by construct stratum (decision D7). Sources: construct_overlap.csv, "
                        "construct_visits_theta.csv (scope=group, level=all, headline score); meanings in CONSTRUCT.md.")]
    L += ["\\begin{tabular}{l" + "r" * (len(cols) - 1) + "}", "\\toprule",
          " & ".join(tex_escape(c) for c in cols) + "\\\\", "\\midrule"]
    b = banner(kind, len(cols))
    if b:
        L.append(b.rstrip("\n"))
    pick = lambda rows, g, **kw: next((r for r in rows if r.get("score") == H and r.get("scope") == "group"  # noqa: E731
                                       and r.get("group") == g and r.get("level") == "all"
                                       and all(r.get(k) == v for k, v in kw.items())), {})
    for g in ("upgrade", "downgrade", "cross", "all_swaps"):
        o = pick(ov, g)
        cells = [tex_escape(GROUP_WORDS.get(g, g)), _f3(o.get("share_pairs_match_swap")),
                 _f3(o.get("share_pairs_neardup_swap")),
                 _ci(o, "theta_excl_either", "theta_excl_either_lo", "theta_excl_either_hi")]
        for s in strata:
            v = pick(vt, g, stratum=s)
            cells.append(_ci(v, "theta", "theta_lo", "theta_hi"))
        L.append(" & ".join(cells) + "\\\\")
    L += ["\\bottomrule", "\\end{tabular}"]
    th = [r for r in read_csv(Path(adir) / "theta_visit_thirds.csv") if r.get("family") == H]
    if th:
        by = {(r["group"], r["third"]): r for r in th}
        cols2 = ["Swaps", "theta, lowest visit third", "theta, middle third", "theta, highest third"]
        L += ["", "\\medskip", "% registered analysis (Part 8.2.7): visit terciles over the owner's bank, a pair classed by "
              "its less-visited item; source theta_visit_thirds.csv; the fixed bins above are the registered sensitivity",
              "\\begin{tabular}{lrrr}", "\\toprule", " & ".join(tex_escape(c) for c in cols2) + "\\\\", "\\midrule"]
        for g in ("upgrade", "downgrade", "cross", "all_swaps"):
            if not any((g, t_) in by for t_ in ("low", "mid", "high")):
                continue
            L.append(" & ".join([tex_escape(GROUP_WORDS.get(g, g))] + [
                _ci(by.get((g, t_), {}), "theta", "theta_lo", "theta_hi") for t_ in ("low", "mid", "high")]) + "\\\\")
        L += ["\\bottomrule", "\\end{tabular}"]
    p = Path(out) / "table_strata.tex"
    p.write_text("\n".join(L) + "\n", encoding="utf-8")
    return p


#: the agent leg's registered directed swaps (legs/memrl/README.md, recommended design)
AGENT_LEG_SWAPS = (("haiku-4.5", "haiku-5.5"), ("haiku-5.5", "haiku-4.5"), ("gpt-5.6-luna", "gpt-6-luna"),
                   ("gpt-6-luna", "gpt-5.6-luna"), ("qwen3.5-27b", "qwen3.8-27b"), ("qwen3.8-27b", "qwen3.5-27b"),
                   ("gemma-3-27b", "gemma-4-31b"), ("gemma-4-31b", "gemma-3-27b"), ("haiku-4.5", "gpt-6-luna"),
                   ("gpt-5.6-luna", "qwen3.8-27b"), ("qwen3.5-27b", "gemma-4-31b"), ("gemma-3-27b", "haiku-5.5"))


def write_table_agent_leg(adir: Path, out: Path, study: str, kind) -> Path:
    """table_agent_leg.tex: the agent leg's registered rows (legs/memrl/README.md): per directed swap, the home gate
    (keep minus shuffle_visit for the old model on its own bank, p_H), the swap contrast (the same for the new model,
    p_S) and the registered reading. Filled from agent_leg.csv in the analysis folder when the leg's collect step
    has written it; until then an empty shell with the registered rows."""
    got = {(r.get("owner"), r.get("reader")): r for r in read_csv(Path(adir) / "agent_leg.csv")}
    cols = ["Directed swap", "Home gate (old model) [95 %]", "p_H", "Swap contrast (new model) [95 %]", "p_S",
            "Reading"]
    L = [header_comment("table_agent_leg.tex", study, kind,
                        "agent leg (MemRL), per directed swap: keep minus shuffle_visit at home (the gate) and after "
                        "the swap, registered reading (uninformative / survives / lost / undetermined). Source: "
                        "agent_leg.csv from the leg's collect step" + ("" if got else "; NOT RUN YET: empty shell") + ".")]
    L += ["\\begin{tabular}{lrrrrl}", "\\toprule", " & ".join(tex_escape(c) for c in cols) + "\\\\", "\\midrule"]
    for o, r in AGENT_LEG_SWAPS:
        x = got.get((o, r), {})
        L.append(" & ".join([tex_escape(f"{o} -> {r}"), _ci(x, "home_gate", "home_gate_lo", "home_gate_hi"),
                             fmt_p(x["p_H"]) if fin(x.get("p_H")) else "--",
                             _ci(x, "swap_contrast", "swap_contrast_lo", "swap_contrast_hi"),
                             fmt_p(x["p_S"]) if fin(x.get("p_S")) else "--",
                             tex_escape(x.get("reading") or "not run")]) + "\\\\")
    L += ["\\bottomrule", "\\end{tabular}"]
    p = Path(out) / "table_agent_leg.tex"
    p.write_text("\n".join(L) + "\n", encoding="utf-8")
    return p


# ---------------------------------------------------------------------------


def make_assets(study: str, draws: int | None = None, out=None, skip_analysis: bool = False,
                runs_dir=None, quiet: bool = False, additions: bool = True,
                addition_settings: dict | None = None) -> dict:
    from msr import analysis as A
    from msr import figures as F
    from msr import llm as L
    t0 = time.time()
    out = Path(out) if out else ROOT / "paper" / "assets"
    out.mkdir(parents=True, exist_ok=True)
    st = A.resolve_study(study, runs_dir)
    adir = (Path(runs_dir) if runs_dir else Path(L.RUNS)) / st.name / "analysis"
    if not skip_analysis:
        A.run_analysis(study, draws, runs_dir=runs_dir, quiet=quiet)
    t1 = time.time()
    meta = {r["key"]: r["value"] for r in read_csv(adir / "meta.csv")}
    kind = meta.get("study_kind") or ("simulated" if str(meta.get("all_models_simulated", "")).lower() == "true"
                                      else "real")
    kind = norm_kind(kind)
    paths = F.make_all(adir, out, printer=None if quiet else print)
    notes = []
    if additions:
        add_paths, notes = run_additions(st.name, out, runs_dir, draws, quiet, addition_settings)
        paths += add_paths
        if not quiet:
            for n in notes:
                print(f"  addition {n}")
    # revision 2 (R5 W9): the capability table reads the forecast in the folder now (written just above when
    # the additions ran), not the one the analysis saw
    A.refresh_capability(adir)
    paths += [write_numbers(adir, out, st.name, kind, notes), write_table_main(adir, out, st.name, kind),
              write_table_groups(adir, out, st.name, kind), write_table_secondary(adir, out, st.name, kind),
              write_table_stakes(adir, out, st.name, kind),
              write_table_family_t(adir, out, st.name, kind),
              write_table_arms(adir, out, st.name, kind),
              write_table_costs(adir, out, st.name, kind)]
    # the construct checks' tables (msr.construct; skipped when its files are missing)
    paths += [x for x in (write_table_correctness(adir, out, st.name, kind), write_table_baselines(adir, out, st.name, kind),
                          write_table_cost_one(adir, out, st.name, kind), write_table_stakes_body(adir, out, st.name, kind),
                          write_table_decision(adir, out, st.name, kind),
                          write_table_strata(adir, out, st.name, kind), write_table_agent_leg(adir, out, st.name, kind))
              if x is not None]
    res = {"paths": paths, "analysis_s": t1 - t0, "assets_s": time.time() - t1, "kind": kind, "out": out,
           "addition_notes": notes}
    if not quiet:
        for p in paths:
            print(f"  {p}")
        pre, text = KIND[kind]
        print(f"analysis {res['analysis_s']:.1f} s, figures and tables {res['assets_s']:.1f} s; study kind {kind}"
              + (f": macros carry \\{pre}, tables carry the banner \"{text}\"" if text else ": no prefix, no banner"))
    return res


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Build the paper's numbers, tables and figures from one study.")
    ap.add_argument("--study", required=True)
    ap.add_argument("--draws", type=int, default=None, help="bootstrap draws (default 10,000)")
    ap.add_argument("--out", default=None, help="default paper/assets/")
    ap.add_argument("--skip-analysis", action="store_true", help="reuse runs/<study>/analysis/ as it is")
    ap.add_argument("--runs-dir", default=None)
    ap.add_argument("--no-additions", action="store_true",
                    help="skip the transfer law, the forecast and the stop-when-sure check")
    a = ap.parse_args(argv)
    make_assets(a.study, a.draws, a.out, a.skip_analysis, a.runs_dir, additions=not a.no_additions)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
