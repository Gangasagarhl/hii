"""Print a study's results as short, numbered pages that can be photographed.

Nothing leaves the machine: the pages are only printed on the screen and saved to
runs/<study>/RESULTS_FOR_PHOTO.txt. Each page has at most 36 lines of at most 100 characters,
a header "page i of N", and a "sum" line under every table so a reader can check the digits.

    .venv/bin/python scripts/print_results.py --study four_versions            # all pages
    .venv/bin/python scripts/print_results.py --study four_versions --page 2   # one page

It reads only files the evaluate stage wrote (results/retained.csv, arms.csv, costs.csv, gate.json).
No model is called.
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
WIDTH = 100
LINES = 36
ARMS = ["none", "relevance", "keep", "wipe", "shuffled", "recal_16", "recal_64", "pooled_16",
        "fresh_16", "split_half", "ceiling"]
NAMES = {"relevance": "relev", "shuffled": "shuf", "recal_16": "rec16", "recal_64": "rec64",
         "pooled_16": "pool16", "fresh_16": "fres16", "split_half": "half", "ceiling": "ceil"}


def rows(path: pathlib.Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open(newline="") as f:
        return list(csv.DictReader(f))


def num(x, nd=3):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return None
    if v != v:  # NaN
        return None
    return round(v, nd)


def fmt(v, nd=3, w=7):
    return ("-" if v is None else f"{v:.{nd}f}").rjust(w)


def short(name: str, w: int) -> str:
    return name if len(name) <= w else name[: w - 1] + "~"


def table_validity(res: pathlib.Path, family: str) -> list[list[str]]:
    """One block per stream: old scores at home and after the swap."""
    out = []
    data = [r for r in rows(res / "retained.csv") if r.get("family") == family]
    streams = sorted({r.get("stream", "") for r in data})
    if len([s for s in streams if s != "all"]) == 1:      # one benchmark: its rows equal the pooled rows
        streams = [s for s in streams if s != "all"]
    for st in streams:
        blk = [f"OLD SCORES, AT HOME AND AFTER THE SWAP   stream {st}   score type {family}",
               "C = how often the higher-scored of two stored examples did better (0.5 = coin toss).",
               "kept = value kept after the swap / value at home (1 = all kept, 0 = none). Flag 'weak home': the",
               "home signal is too weak on the check tasks to trust 'kept' for this row.",
               f"{'owner -> reader':<27}{'kind':<11}{'C home':>7}{'C swap':>7}{'drop':>7}{'lo':>7}{'hi':>7}"
               f"{'kept':>7}{'lo':>7}{'hi':>7} flag"]
        sums = [0.0] * 8
        for r in [x for x in data if x.get("stream") == st]:
            vals = [num(r.get("c_home")), num(r.get("c_swap")), num(r.get("drop")), num(r.get("drop_lo")),
                    num(r.get("drop_hi")), num(r.get("theta")), num(r.get("theta_lo_task")),
                    num(r.get("theta_hi_task"))]
            status = (r.get("theta_status_calibration") or r.get("theta_status") or "")
            flag = "ok" if status.strip().lower() in ("", "defined", "ok") else "weak home"
            for i, v in enumerate(vals):
                sums[i] += v or 0.0
            pair = short(f"{r.get('owner')} -> {r.get('reader')}", 26)
            blk.append(f"{pair:<27}{short(r.get('kind', ''), 10):<11}" + "".join(fmt(v) for v in vals) + " " + flag)
        blk.append(f"{'sum of each column':<38}" + "".join(fmt(round(s, 3)) for s in sums))
        out.append(blk)
    return out


def table_arms(res: pathlib.Path, family: str) -> list[list[str]]:
    """One block per stream: percent of tasks solved with the first-shown example, per rule."""
    out = []
    data = rows(res / "arms.csv")
    streams = sorted({r.get("stream", "") for r in data})
    for st in streams:
        cells: dict[tuple, dict[str, list[float]]] = {}
        for r in data:
            if r.get("stream") != st or r.get("arm") not in ARMS:
                continue
            if r.get("family") not in (family, "-", "", None):
                continue
            v = num(r.get("value"), 6)
            if v is None:
                continue
            cells.setdefault((r.get("owner"), r.get("reader")), {}).setdefault(r["arm"], []).append(v)
        blk = [f"PERCENT OF TASKS SOLVED WITH THE FIRST-SHOWN EXAMPLE   stream {st}   score type {family}",
               "none = no memory; keep = use the old scores; wipe = forget the scores; recal_k = k fresh checks.",
               f"{'owner -> reader':<24}" + "".join(NAMES.get(a, a)[:6].rjust(7) for a in ARMS)]
        sums = [0.0] * len(ARMS)
        for (o, rd), d in cells.items():
            vals = [round(100 * sum(d[a]) / len(d[a]), 1) if a in d else None for a in ARMS]
            for i, v in enumerate(vals):
                sums[i] += v or 0.0
            blk.append(f"{short(f'{o} -> {rd}', 23):<24}" + "".join(fmt(v, 1) for v in vals))
        blk.append(f"{'sum of each column':<24}" + "".join(fmt(round(s, 1), 1) for s in sums))
        out.append(blk)
    return out


def table_gates(res: pathlib.Path) -> list[str]:
    p = res / "gate.json"
    blk = ["PILOT GATES (one line per model and stream)"]
    if not p.exists():
        return blk + ["no gate file"]
    try:
        gates = json.loads(p.read_text())
    except json.JSONDecodeError:
        return blk + ["gate file unreadable"]
    blk.append(f"{'model':<22}{'stream':<9}{'memory gain pts':>16}{'lo':>7}{'hi':>7}{'C home':>8}{'lo':>7}{'hi':>7}")
    for g in gates if isinstance(gates, list) else []:
        blk.append(f"{short(str(g.get('model')), 21):<22}{short(str(g.get('stream')), 8):<9}"
                   f"{fmt(num(g.get('memory_gain_pts'), 1), 1, 16)}{fmt(num(g.get('memory_gain_lo'), 1), 1)}"
                   f"{fmt(num(g.get('memory_gain_hi'), 1), 1)}{fmt(num(g.get('home_cw_ema_grade')), 3, 8)}"
                   f"{fmt(num(g.get('home_cw_ema_grade_lo')))}{fmt(num(g.get('home_cw_ema_grade_hi')))}")
    return blk


def table_costs(res: pathlib.Path) -> list[str]:
    data = rows(res / "costs.csv")
    blk = ["CALLS PER MODEL (all stages together)",
           f"{'model':<26}{'calls':>10}{'from cache':>12}{'tokens in':>14}{'tokens out':>12}{'refused':>9}"
           f"{'unreadable':>11}"]
    agg: dict[str, list[float]] = {}
    for r in data:
        a = agg.setdefault(r.get("model", "?"), [0, 0, 0, 0, 0, 0])
        for i, k in enumerate(["calls", "cached_calls", "tokens_in", "tokens_out", "refusals", "unparseable"]):
            a[i] += num(r.get(k), 0) or 0
    tot = [0.0] * 6
    for m, a in agg.items():
        tot = [t + x for t, x in zip(tot, a)]
        blk.append(f"{short(m, 25):<26}{int(a[0]):>10}{int(a[1]):>12}{int(a[2]):>14}{int(a[3]):>12}{int(a[4]):>9}"
                   f"{int(a[5]):>11}")
    blk.append(f"{'sum':<26}{int(tot[0]):>10}{int(tot[1]):>12}{int(tot[2]):>14}{int(tot[3]):>12}{int(tot[4]):>9}"
               f"{int(tot[5]):>11}")
    return blk


def paginate(blocks: list[list[str]], title: str) -> list[list[str]]:
    pages, cur = [], []
    room = LINES - 3
    for b in blocks:
        b = [ln[:WIDTH] for ln in b]
        while len(b) > room:                       # a table longer than a page: split it, repeat its heading
            head, body = b[:5], b[5:]
            take = room - len(head)
            pages.append(head + body[:take])
            b = head + body[take:]
        if cur and len(cur) + 1 + len(b) > room:
            pages.append(cur)
            cur = []
        cur = cur + ([""] if cur else []) + b
    if cur:
        pages.append(cur)
    n = len(pages)
    return [[f"{title}   page {i + 1} of {n}", "=" * WIDTH] + p + ["=" * WIDTH] for i, p in enumerate(pages)]


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--study", required=True, help="the study's name (its folder under runs/)")
    ap.add_argument("--family", default="ema_grade", help="score type to show (default: the headline type)")
    ap.add_argument("--page", type=int, default=0, help="print only this page (1 = first)")
    a = ap.parse_args()
    run = ROOT / "runs" / a.study
    res = run / "results"
    if not res.exists():
        print(f"No results yet in runs/{a.study}/results: run the evaluate stage first.")
        return 1
    stamp = dt.datetime.now().strftime("%Y-%m-%d %H:%M")
    blocks = [table_gates(res)] + table_validity(res, a.family) + table_arms(res, a.family) + [table_costs(res)]
    pages = paginate(blocks, f"ScoreSwap results | study {a.study} | printed {stamp} |")
    text = "\n\n".join("\n".join(p) for p in pages) + "\n"
    (run / "RESULTS_FOR_PHOTO.txt").write_text(text)
    if a.page:
        if not 1 <= a.page <= len(pages):
            print(f"There are {len(pages)} pages.")
            return 1
        print("\n".join(pages[a.page - 1]))
    else:
        print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
