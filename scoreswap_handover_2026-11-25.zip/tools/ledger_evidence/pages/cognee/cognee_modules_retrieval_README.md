# cognee/modules/retrieval — SearchType → retriever map

Every `SearchType` (`cognee/modules/search/types/SearchType.py`) is served by one
retriever class in this package. The dispatch lives in
`cognee/modules/search/methods/get_search_type_retriever_instance.py`
(`search_core_registry`); the table below mirrors it and is checked by
`cognee/tests/unit/modules/retrieval/retriever_readme_index_test.py`, so update both
together.

| SearchType | Retriever | Module | LLM answer? | Notes |
|---|---|---|---|---|
| `HYBRID_COMPLETION` | `HybridRetriever` | `hybrid_retriever.py` | yes | Default. Chunk + entity (+ global-context) lanes. Defers to `GRAPH_COMPLETION` for a custom `node_type`, `neighborhood_depth`, `feedback_influence > 0`, or a missing chunk collection (`search/methods/hybrid_deferral.py`); `node_name` with `node_type=None` raises `QueryValidationError` like on every type (`search/methods/node_name_scope.py`) |
| `HYBRID_COMPLETION_DECOMPOSITION` | `HybridDecompositionRetriever` | `hybrid_decomposition_retriever.py` | yes | Hybrid pass for the full question, then LLM decomposition of question + that context into up to `max_subqueries` subqueries (default 7, at most 20), each retrieved through the hybrid lanes and unioned by id. Single query only. A missing decomposition prompt or a failed planning call fails the search. **Cost:** the union is not capped, so each lane can hold `1 + max_subqueries` times its top-k (8 times by default) and an entity keeps the edges of every retrieval, beyond `max_edges_per_entity`; the pass-1 context is sent to the model twice (planner, then answer); one search makes two LLM calls and up to `1 + max_subqueries` embedding calls. In a session it always runs sequentially. Never defers: on the conditions that defer `HYBRID_COMPLETION` (a custom `node_type`, `neighborhood_depth`, `feedback_influence > 0`, or a missing chunk collection) it raises `QueryValidationError` naming the reason and pointing at `GRAPH_COMPLETION_DECOMPOSITION`; `node_name` is applied as node-set tags only. A plan with no usable subquery logs a warning and searches with the original question. `retriever_specific_config`: `max_subqueries`, `decomposition_system_prompt`, `decomposition_system_prompt_path`, plus every hybrid key |
| `GRAPH_COMPLETION` | `GraphCompletionRetriever` | `graph_completion_retriever.py` | yes | Triplet search + neighbourhood expansion; base for the variants below |
| `GRAPH_COMPLETION_COT` | `GraphCompletionCotRetriever` | `graph_completion_cot_retriever.py` | yes | Chain-of-thought rounds |
| `GRAPH_COMPLETION_CONTEXT_EXTENSION` | `GraphCompletionContextExtensionRetriever` | `graph_completion_context_extension_retriever.py` | yes | Iteratively widens context |
| `GRAPH_COMPLETION_DECOMPOSITION` | `GraphCompletionDecompositionRetriever` | `graph_completion_decomposition_retriever.py` | yes | Splits the query into sub-queries first |
| `GRAPH_SUMMARY_COMPLETION` | `GraphSummaryCompletionRetriever` | `graph_summary_completion_retriever.py` | yes | Graph context built from summaries |
| `TEMPORAL` | `TemporalHybridRetriever` | `temporal_hybrid_retriever.py` | yes | Hybrid retrieval reranked by time: the adapter returns the `Timestamp` nodes overlapping the window the LLM extracts from the question (`GraphDBInterface.get_timestamps_in_range`), the chunks and entities anchored to them move to the front of the candidate set, nothing is dropped; plain hybrid when the question carries no time or nothing overlaps (`temporal_hybrid/matching.py`) |
| `RAG_COMPLETION` | `CompletionRetriever` | `completion_retriever.py` | yes | Chunk vector search + completion |
| `BROAD` | `BroadRetriever` | `broad_retriever.py` | yes | Questions over a whole dataset (counts, totals, lists, lookups): a small dataset is shown whole; a large one is loaded into SQLite (`broad_store.py`) and answered by one model-written query |
| `TRIPLET_COMPLETION` | `GraphCompletionRetriever` | `graph_completion_retriever.py` | yes | Deprecated, removed in the next release: triplet embeddings were removed, so `search()` / `recall()` resolve it to `GRAPH_COMPLETION` with a `FutureWarning` (`DEPRECATED_SEARCH_TYPES`) |
| `AGENTIC_COMPLETION` | `AgenticRetriever` | `agentic_retriever.py` | yes | Special-cased in the factory (not in the dict): tool loop with `skills`, `tools`, `max_iter` |
| `CHUNKS` | `ChunksRetriever` | `chunks_retriever.py` | no | Vector search over `DocumentChunk_text` |
| `CHUNKS_LEXICAL` | `BM25ChunksRetriever` | `bm25_retriever.py` | no | BM25 over chunks (`LexicalRetriever` subclass) |
| `SUMMARIES` | `SummariesRetriever` | `summaries_retriever.py` | no | Vector search over `TextSummary_text` |
| `SKILLS` | `SkillsRetriever` | `skills_retriever.py` | no | Metadata-only skill discovery; exactly one dataset |
| `CODE` | `CodeRetriever` | `code_retriever.py` | no | Deterministic code-graph operations via `code_query` |
| `CODING_RULES` | `CodingRulesRetriever` | `coding_rules_retriever.py` | no | Returns stored coding rules |
| `CYPHER` | `CypherSearchRetriever` | `cypher_search_retriever.py` | no | Raw Cypher; disabled by default, enabled by `ALLOW_CYPHER_QUERY=true` |
| `NATURAL_LANGUAGE` | `NaturalLanguageRetriever` | `natural_language_retriever.py` | yes | LLM writes Cypher, then runs it; same `ALLOW_CYPHER_QUERY` gate |
| `GRAPH_REPORT` | `GraphReportRetriever` | `graph_report_retriever.py` | partly | Hubs, cross-node-set edges, provenance split, LLM-suggested questions |
| `FEELING_LUCKY` | — | `search/operations/select_search_type.py` | — | An LLM picks one of the types above, then that retriever runs |

Not wired to any `SearchType`: `LexicalRetriever` (`lexical_retriever.py`, the base
for BM25) and `JaccardChunksRetriever` (`jaccard_retrival.py`, unused). Community
retrievers register through `register_retriever.py` and take precedence for their type.

## The contract

All retrievers subclass `BaseRetriever` (`base_retriever.py`) and implement three
async methods, run in order by `get_completion(query)`:

1. `get_retrieved_objects(query, query_batch)` — hit the graph/vector store.
2. `get_context_from_objects(query, query_batch, retrieved_objects)` — format for the LLM.
3. `get_completion_from_context(query, query_batch, retrieved_objects, context)` — answer.
   The "no" rows above return the context unchanged here.

Optional hooks: `extract_context_object_ids` (which nodes/edges fed a session answer),
`merge_retrieved_objects` (combine the raw-query and rewritten-query lanes of a session
turn), `append_references` / `get_context_evidence` (`include_references=True`), and the
class flags `supports_session_turn_preparation` / `supports_prompt_preview`.

### Explicit typed graph scopes

For `GRAPH_COMPLETION` with an explicit non-`NodeSet` `node_type` and `node_name`,
triplet retrieval projects that graph scope before scoring vectors. On LanceDB
(including subprocess mode), PGVector, Turso and Neptune Analytics, `score_by_ids`
scores only its node and edge-type vectors, without an additional candidate cutoff;
a query batch is scored with one `score_by_ids_batch` call per collection: LanceDB
fetches the scoped vectors once and takes every query's distances locally, PGVector and
Turso run one statement with a distance column per query, so a batch costs about one
query.
Unembedded graph members keep the usual missing-distance penalty. Neptune uses
exact `CosineDistance` through `neptune.algo.vectors.distance.byEmbedding`, rather
than its ANN top-k search. NodeSet, unscoped, vector-seeded neighbourhood searches
and supplied memory fragments retain their existing paths. A vector adapter
without `score_by_ids` scans its collections unfiltered for such a scope and maps
the distances onto the projected scope, so it ranks the same triplets, only slower;
the vector `node_name` filter means NodeSet membership and is never applied to a
typed scope, because it would match nothing and penalise every scoped node.

`CHUNKS` and `RAG_COMPLETION` take the same two steps for a typed scope
(`cognee/modules/retrieval/utils/scoped_chunk_search.py`): the graph projects the
named nodes and their one-hop neighbours, the `DocumentChunk` nodes among them are
the scope (a document's chunks, an entity's mentions), and `score_by_ids` scores
exactly those chunk ids; an adapter without it scans the chunk collection
unfiltered and the scope is kept in Python. A search type that cannot apply a
`node_name` filter raises `QueryValidationError` instead of answering unscoped
(`cognee/modules/search/methods/node_name_scope.py` lists which type honours which
scope), and `FEELING_LUCKY` picks only among the types that can.

## Adding a retriever

1. Subclass `BaseRetriever` (or `GraphCompletionRetriever` for a graph variant) in
   a new `*_retriever.py`.
2. Add the `SearchType` member, then the `search_core_registry` entry with the
   constructor kwargs it needs.
3. Add a row to the table above and a `*_test.py` in `cognee/tests/unit/modules/retrieval/`.
4. If it should be reachable from the CLI, add it to `SEARCH_TYPE_CHOICES` in
   `cognee/cli/config.py`; if `recall()` should route to it, add a regex rule to the
   ordered, first-match-wins table in `cognee/api/v1/recall/query_router.py` (`cognee/modules/recall/` is session
   recall, not the router).

Supporting folders: `hybrid/` (the hybrid lanes), `context_providers/` (triplet
context formatting), `entity_extractors/`, `utils/` (completion, evidence, ranking
helpers), `only_context_prompt.py` (the full LLM input an `only_context` search returns), and
`session_aware_completion.py` (the concurrent/sequential session turn).
