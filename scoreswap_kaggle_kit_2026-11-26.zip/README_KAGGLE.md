# Running the real study on free Kaggle GPUs

## The picture first

A school lends you a kitchen for 12 hours at a time, about 30 hours a week, for free. It has two stoves (two
GPUs). Each stove holds one pot (one small model). You bring a toolbox (the project zip), cook in turns, and at
the end of every shift you pack everything into one box (`scoreswap_runs.zip`). At the next shift you bring the
box back, and the kitchen carries on where it stopped. Nothing cooked before is cooked again.

The study needs 18 models (four lines of versions: Qwen, Gemma, Granite, Phi). Each model is loaded about twice:
once to write and score its own notebook of examples and to read the notebooks that already exist, once more
to read the notebooks written after it. The notebook chooses which model comes next by itself.

## What you need once

1. A Kaggle account with a verified phone number (Kaggle asks for it before it gives GPUs and internet).
2. A Hugging Face account. Open these four pages, sign in, and click **Agree and access repository** on each
   (the Gemma terms): `google/gemma-1.1-2b-it`, `google/gemma-2-2b-it`, `google/gemma-3-1b-it`,
   `google/gemma-3n-E2B-it`. Then **Settings -> Access Tokens -> Create new token**, type **Read**. Copy it.
   Keep it secret; the notebook reads it from Kaggle's secret store and never prints it.
3. On the laptop, in the project folder:
   ```
   .venv/bin/python kaggle/make_project_zip.py
   ```
   This writes `kaggle_output/scoreswap_project.zip` (about 11 MB: code, settings, the two public benchmark
   streams and the task vectors; no key, no results).

## Set up the notebook (once)

1. kaggle.com -> **Datasets** -> **New Dataset**. Drag in `scoreswap_project.zip`. Title: `scoreswap-project`.
   Leave it **Private**. Click **Create**.
2. kaggle.com -> **Code** -> **New Notebook**. Menu **File -> Import Notebook** -> choose
   `kaggle/scoreswap_kaggle.ipynb` from the project folder.
3. Right-hand panel, **Session options**: **Accelerator -> GPU T4 x2**. **Internet -> On**.
4. Right-hand panel, **Input -> Add Input -> Datasets -> Your Datasets -> scoreswap-project -> Add**.
5. Menu **Add-ons -> Secrets -> Add a new secret**. Label: `HF_TOKEN`. Value: the Hugging Face token.
   Tick the box so this notebook may use it.
6. Give the notebook a name you will find again, for example `scoreswap-lineage`.

## Part 1: test every model first (a few minutes each; do this before any long run)

Nobody we could find has run Qwen3.5 or Granite 4.0 on this GPU, and the Gemma line is risky. So first every
model gets a short test: start its server, check it, a few dozen calls, stop.

1. In the first code cell set `SMOKE_ONLY = True`, `MODEL = "qwen1.5-1.8b"`, `MODEL_GPU2 = "qwen2-1.5b"`.
2. Click **Save Version** (top right) -> **Save & Run All (Commit)** -> **Save**. It runs without the browser.
3. When it is done (about 15-25 minutes, most of it installing and downloading), open the version, tab
   **Logs** or **Output -> SESSION_REPORT.txt**. For each model you want these lines:
   - `4. check <model>: precision float16 (asked float16)` (float32 for gemma-2-2b and gemma-3-1b);
   - `prompt the model sees (end): ...` with `You are a helpful assistant.` once and no `Today's Date`;
   - `... answers/hour at once, ... readable 70/70` (readable = the grader could read the answer);
   - `5. smoke <model> OK`.
   Write down the line with `answers/hour` for each model: it is the real speed.
4. Repeat with the next two models, until all 18 are done (9 runs):
   `qwen2.5-1.5b`+`qwen3-1.7b`, `qwen3.5-2b`+`gemma-1.1-2b`, `gemma-2-2b`+`gemma-3-1b`, `gemma-4-e2b`+`granite-3.0-2b`,
   `granite-3.1-2b`+`granite-3.2-2b`, `granite-3.3-2b`+`granite-4.0-micro`, `phi-2`+`phi-3-mini`,
   `phi-3.5-mini`+`phi-4-mini`.

If a model fails its test:

| What the report says | What to do |
|---|---|
| `the server stopped ... before it answered` (vLLM cannot load it) | Set `ENGINES = {"<model>": "transformers"}` and test it again. Keep that line in EVERY later session. |
| `PROBLEM ... served in bfloat16` or another precision | Stop and ask; do not run that model. |
| `PROBLEM ... the template added its own text` or `open thinking block` | Stop and ask. |
| `readable` far below the number of answers (for example 20/70) | Run it anyway only if it is Phi-2 (a base model); else ask. |
| A Gemma model fails even with `transformers` | Use the fallback below. |
| `is gated on Hugging Face` | Accept the licence on its page (above) and check the `HF_TOKEN` secret. |

**Gemma fallback** (decided in advance): run the Gemma versions that pass (three is still a chain;
`gemma-3n-e2b` may stand in for `gemma-4-e2b`) and add the small Qwen chain as a fifth line:
`qwen1.5-0.5b`, `qwen2-0.5b`, `qwen2.5-0.5b`, `qwen3-0.6b`, `qwen3.5-0.8b`. The study file
`config/study_lineage.yaml` says how (comments at its top). Test those five the same way.

If `vllm` itself does not install or start for any model: set `VLLM_VERSION = "0.18.0"` (the version others ran
on a Kaggle T4) and test again. Whatever version works, keep it for the whole study.

## Part 2: the study sessions

1. In the first code cell: `SMOKE_ONLY = False`, `MODEL = "next"`, `MODEL_GPU2 = "next"`, `HOURS = 11.5`.
2. **Save Version -> Save & Run All (Commit)**. It works until about 11 hours after the start, then packs
   everything into `scoreswap_runs.zip` in the version's output (it also saves a checkpoint every hour). With
   `"next"`, a GPU whose model has finished takes the next model by itself while at least an hour is left.
3. **Next session**: right-hand panel **Input -> Add Input -> Your Work** -> choose this notebook
   (`scoreswap-lineage`) -> its latest version -> **Add**. Then **Save Version -> Save & Run All** again.
   The notebook finds every `scoreswap_runs.zip` under its inputs, joins them, and carries on. Before each new
   session, make sure the input points at the LATEST version (the version number is shown next to the input).
   If Kaggle does not let a notebook use its own output: download `scoreswap_runs.zip` from the version's
   **Output** tab, upload it as a new version of a private dataset `scoreswap-runs`, and attach that dataset.
4. Keep going until the report says `THE STUDY IS COMPLETE`. The report of every session (`SESSION_REPORT.txt`)
   lists what each model did, the speed, and what is still missing.

To see the whole order from the start, or what is missing now (on the laptop, or in a notebook cell):
`python -m msr.schedule --study config/study_lineage.yaml --plan` and
`python -m msr.schedule --study config/study_lineage.yaml` (add `--model qwen2-1.5b` for one model).

**When a session dies** (Kaggle stops it, the page shows an error, the internet breaks): attach the output of
that version if it has one (the hourly checkpoint), otherwise the version before it, and run again. Nothing
already answered is asked again; at most the calls after the last checkpoint are made again.

**Two notebooks at once** are not needed (the weekly quota is the limit, not the number of notebooks). If you do
run two, never give them the same model; join their outputs on the laptop with `kaggle/merge_runs.py` (below).

## How long it takes (ESTIMATE, before any measured speed)

From `kaggle/estimate_hours.py`: per call 1,000 tokens in and 40 (low) or 250 (high) tokens out, the speed one
team reported for Qwen2.5-1.5B on a Kaggle T4 (948.7 answer tokens per second with 16 requests at once, 68.1 one
at a time), scaled by model size; float32 and the plain-transformers server are slower. Hours on one GPU:

| model | precision | calls | hours (40 out) | hours (250 out) |
|---|---|---:|---:|---:|
| qwen1.5-1.8b | float16 | 48,250 | 4.1 | 12.0 |
| qwen2-1.5b | float16 | 31,250 | 2.1 | 5.8 |
| qwen2.5-1.5b | float16 | 31,250 | 2.1 | 5.8 |
| qwen3-1.7b | float16 | 31,250 | 2.8 | 7.7 |
| qwen3.5-2b | float16 | 43,250 | 4.1 | 10.7 |
| gemma-1.1-2b | float16 | 39,250 | 4.1 | 11.0 |
| gemma-2-2b | float32 | 27,250 | 13.2 | 29.6 |
| gemma-3-1b | float32 | 27,250 | 4.7 | 9.3 |
| gemma-4-e2b | float16, transformers | 39,250 | 12.0 | 58.9 |
| granite-3.0-2b | float16 | 48,250 | 5.9 | 17.2 |
| granite-3.1-2b | float16 | 31,250 | 3.5 | 9.6 |
| granite-3.2-2b | float16 | 31,250 | 3.5 | 9.6 |
| granite-3.3-2b | float16 | 31,250 | 3.5 | 9.6 |
| granite-4.0-micro | float16 | 43,250 | 6.1 | 16.0 |
| phi-2 | float16 | 39,250 | 4.8 | 13.7 |
| phi-3-mini | float16 | 27,250 | 5.3 | 17.3 |
| phi-3.5-mini | float16 | 27,250 | 5.3 | 17.3 |
| phi-4-mini | float16 | 39,250 | 6.3 | 16.9 |
| **all** | | **636,500** | **93** | **278** |

With both GPUs busy, quota hours are about half the GPU hours plus about 0.4 hours per session for installing and
saving: **about 54 (low) to 146 (high) quota hours, at least 18 sessions, about 2 to 5 weeks** at about 30 hours a
week. The 12-hour session limit and the 30-hour weekly quota are from other people's write-ups, not from a Kaggle
page: read the quota your own account shows (**Settings** or the GPU meter next to the accelerator). After Part 1,
`kaggle/estimate_hours.py --measured` gives the hours from the speed really measured.

## How to check what a model really got

Every session writes `runs/lineage/servers/<model>/check_<time>.json` (inside the zip): the repository and commit,
the precision asked and the precision the server reports, the server's settings, the end of the prompt exactly
as the model sees it, and the measured speed. The study's own record of every model's request settings is
`runs/lineage/model_settings.json`. A session stops before any study call when the precision or the prompt is not
the one in `config/models.yaml`.

## After the last session (on the laptop)

1. Download the last `scoreswap_runs.zip` (and the zips of any notebooks that ran side by side).
2. In the project folder:
   ```
   .venv/bin/python kaggle/merge_runs.py --into runs scoreswap_runs.zip --study config/study_lineage.yaml
   .venv/bin/python run.py --study config/study_lineage.yaml --stage evaluate
   .venv/bin/python -m msr.analysis --study lineage
   .venv/bin/python -m msr.lineage --study lineage
   .venv/bin/python scripts/make_lineage_assets.py --study lineage
   .venv/bin/python scripts/make_paper_assets.py --study lineage
   .venv/bin/python scripts/print_results.py --study lineage
   ```
   Long steps under `systemd-run --user` with a memory limit (the project's rule; `msr.analysis` needs about
   8 GB on the full-size study).
3. The paper: in `paper/internal_draft.tex` change `\newcommand*{\ResultsSource}{simulated}` to `{real}`.

## Licences of the models (what they say about the answers we store)

| models | licence | about outputs |
|---|---|---|
| Qwen2, Qwen2.5-1.5B, Qwen3, Qwen3.5, all Granite, Gemma 4 | Apache-2.0 | nothing |
| all Phi | MIT | nothing |
| Gemma 1.1, 2, 3 (and 3n) | Gemma Terms of Use (gated) | Google claims no rights in outputs |
| Qwen1.5-1.8B (and 0.5B) | Tongyi Qianwen RESEARCH licence, non-commercial | outputs may not be used to improve another model: its stored answers are published as identifiers and hashes only |

## Things that are flagged on purpose

- Phi-2 is a base model (no instruction tuning), asked in its maker's "Instruct: ... Output:" format, with a
  512-token answer limit because its window is 2,048 tokens.
- Gemma 3 has no 2B: gemma-3-1b-it (1.0 B) is a size drop. Granite 4.0 is 3.4 B after four 2.5 B versions.
- Gemma 2 and 3 run in float32 (vLLM refuses float16 for them); Gemma 4 runs on plain transformers (vLLM cannot
  run it on this GPU). Both are written in every check record.
- Every model gets the same one-sentence system text, "You are a helpful assistant.", because several chat
  templates insert their own default text (Granite 3.1-3.3 even today's date) when none is given. Gemma 1.1 and 2
  refuse a system turn, so for them the sentence opens the user turn, as Gemma 3's own template does.
- Thinking is off for every model (Qwen3, Qwen3.5, Granite 3.2/3.3, Gemma 4 have a switch); a thinking block in
  any answer stops the session at the check.
- Repeat 2 of each probe runs in a new process but not 6 hours later (our own server keeps no answer cache);
  `probe.repeat_gap_hours` in `config/study_lineage.yaml` says why and how to follow the written plan instead.
